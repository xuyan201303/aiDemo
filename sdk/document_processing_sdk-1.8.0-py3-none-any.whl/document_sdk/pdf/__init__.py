"""Public local PDF APIs."""

from importlib import import_module
from typing import TYPE_CHECKING

from document_sdk.pdf.errors import (
    PdfLimitExceededError,
    PdfRenderLimitExceededError,
)
from document_sdk.pdf.extraction import extract_native_text
from document_sdk.pdf.inspection import inspect_pdf
from document_sdk.pdf.local_evidence import (
    PdfEvidenceBox,
    PdfLocalDrawingEvidence,
    PdfLocalEvidence,
    PdfLocalImageEvidence,
    PdfLocalPageEvidence,
    PdfLocalPathSegment,
    PdfLocalTextEvidence,
)
from document_sdk.pdf.local_evidence_members import (
    PdfLocalEvidenceV2,
    PdfLocalEvidenceV3,
    PdfLocalPageEvidenceV2,
    PdfLocalPageEvidenceV3,
    PdfLocalSourceAnchoredOverflowProof,
    PdfLocalTextMember,
)
from document_sdk.pdf.models import PdfProcessingLimits
from document_sdk.pdf.rendering import render_page, render_region
from document_sdk.pdf.unified import (
    UNIFIED_PDF_HYBRID_RESULT_VERSION,
    UNIFIED_PDF_RESULT_VERSION,
    PdfAnalysisMode,
    UnifiedPdfAnalysisOptions,
    UnifiedPdfHybridCapabilityOutcome,
    UnifiedPdfHybridResult,
    UnifiedPdfHybridSummary,
    UnifiedPdfPage,
    UnifiedPdfResult,
    UnifiedPdfTable,
    UnifiedPdfTableCell,
    analyze_pdf,
)

if TYPE_CHECKING:
    from document_sdk.pdf._document_objects_v6 import PdfDocumentObjects
    from document_sdk.pdf._source_objects_v7 import (
        PdfSourceObjectLimitsV7,
        PdfSourceObjectsV7,
    )
    from document_sdk.pdf.local_first import analyze_pdf_local_first
    from document_sdk.pdf.local_first_models import (
        PdfFallbackCell,
        PdfFallbackContent,
        PdfFallbackPage,
        PdfFallbackTable,
        PdfLocalFirstMode,
        PdfLocalFirstResult,
        PdfLocalFirstStatus,
    )
    from document_sdk.pdf.semantic_v5 import (
        UNIFIED_PDF_RESULT_V5_VERSION,
        PdfSemanticContext,
        UnifiedPdfResultV5,
        analyze_pdf_v5,
    )
    from document_sdk.pdf.semantic_v6 import (
        UNIFIED_PDF_RESULT_V6_VERSION,
        PdfDocumentObjectLossReceipt,
        UnifiedPdfResultV6,
        analyze_pdf_v6,
    )
    from document_sdk.pdf.semantic_v7 import (
        UNIFIED_PDF_RESULT_V7_VERSION,
        PdfInputRecoveryReceipt,
        PdfSourceInformationLossReceipt,
        UnifiedPdfResultV7,
        analyze_pdf_v7,
    )
    from document_sdk.pdf.source_text import PdfSourceText


def __getattr__(name: str) -> object:  # noqa: PLR0911 - additive lazy export families.
    """Keep opt-in semantic dependencies out of legacy package imports."""
    if name == "analyze_pdf_local_first":
        return getattr(import_module("document_sdk.pdf.local_first"), name)
    if name in {
        "PdfFallbackCell",
        "PdfFallbackContent",
        "PdfFallbackPage",
        "PdfFallbackTable",
        "PdfLocalFirstMode",
        "PdfLocalFirstResult",
        "PdfLocalFirstStatus",
    }:
        return getattr(import_module("document_sdk.pdf.local_first_models"), name)
    if name in {
        "UNIFIED_PDF_RESULT_V5_VERSION",
        "PdfSemanticContext",
        "UnifiedPdfResultV5",
        "analyze_pdf_v5",
    }:
        return getattr(import_module("document_sdk.pdf.semantic_v5"), name)
    if name == "PdfDocumentObjects":
        return getattr(import_module("document_sdk.pdf._document_objects_v6"), name)
    if name in {
        "UNIFIED_PDF_RESULT_V6_VERSION",
        "PdfDocumentObjectLossReceipt",
        "UnifiedPdfResultV6",
        "analyze_pdf_v6",
    }:
        return getattr(import_module("document_sdk.pdf.semantic_v6"), name)
    if name in {"PdfSourceObjectLimitsV7", "PdfSourceObjectsV7"}:
        return getattr(import_module("document_sdk.pdf._source_objects_v7"), name)
    if name == "PdfSourceText":
        return getattr(import_module("document_sdk.pdf.source_text"), name)
    if name in {
        "UNIFIED_PDF_RESULT_V7_VERSION",
        "PdfInputRecoveryReceipt",
        "PdfSourceInformationLossReceipt",
        "UnifiedPdfResultV7",
        "analyze_pdf_v7",
    }:
        return getattr(import_module("document_sdk.pdf.semantic_v7"), name)
    raise AttributeError(name)


__all__ = [
    "UNIFIED_PDF_HYBRID_RESULT_VERSION",
    "UNIFIED_PDF_RESULT_V5_VERSION",
    "UNIFIED_PDF_RESULT_V6_VERSION",
    "UNIFIED_PDF_RESULT_V7_VERSION",
    "UNIFIED_PDF_RESULT_VERSION",
    "PdfAnalysisMode",
    "PdfDocumentObjectLossReceipt",
    "PdfDocumentObjects",
    "PdfEvidenceBox",
    "PdfFallbackCell",
    "PdfFallbackContent",
    "PdfFallbackPage",
    "PdfFallbackTable",
    "PdfInputRecoveryReceipt",
    "PdfLimitExceededError",
    "PdfLocalDrawingEvidence",
    "PdfLocalEvidence",
    "PdfLocalEvidenceV2",
    "PdfLocalEvidenceV3",
    "PdfLocalFirstMode",
    "PdfLocalFirstResult",
    "PdfLocalFirstStatus",
    "PdfLocalImageEvidence",
    "PdfLocalPageEvidence",
    "PdfLocalPageEvidenceV2",
    "PdfLocalPageEvidenceV3",
    "PdfLocalPathSegment",
    "PdfLocalSourceAnchoredOverflowProof",
    "PdfLocalTextEvidence",
    "PdfLocalTextMember",
    "PdfProcessingLimits",
    "PdfRenderLimitExceededError",
    "PdfSemanticContext",
    "PdfSourceInformationLossReceipt",
    "PdfSourceObjectLimitsV7",
    "PdfSourceObjectsV7",
    "PdfSourceText",
    "UnifiedPdfAnalysisOptions",
    "UnifiedPdfHybridCapabilityOutcome",
    "UnifiedPdfHybridResult",
    "UnifiedPdfHybridSummary",
    "UnifiedPdfPage",
    "UnifiedPdfResult",
    "UnifiedPdfResultV5",
    "UnifiedPdfResultV6",
    "UnifiedPdfResultV7",
    "UnifiedPdfTable",
    "UnifiedPdfTableCell",
    "analyze_pdf",
    "analyze_pdf_local_first",
    "analyze_pdf_v5",
    "analyze_pdf_v6",
    "analyze_pdf_v7",
    "extract_native_text",
    "inspect_pdf",
    "render_page",
    "render_region",
]

"""One Local analysis followed, when authorized, by one full Azure analysis."""

# Fixed sanitized boundary messages and the approved six-argument contract.
# ruff: noqa: EM101, TRY003, PLR0913, PLR0917

from __future__ import annotations

import inspect
import os
import shutil
import stat
import sys
import tempfile
from contextlib import contextmanager
from hashlib import sha256
from pathlib import Path
from types import FunctionType
from typing import TYPE_CHECKING, cast

from document_sdk.core._exceptions import redact_exception
from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.errors import (
    DocumentProcessingError,
    DocumentSourceChangedError,
    EncryptedDocumentError,
    FileAccessError,
    InvalidSourceReferenceError,
    ProviderAuthenticationError,
    ProviderAuthorizationError,
    ProviderConfigurationError,
    ProviderRateLimitError,
    ProviderRequestError,
    ProviderResponseError,
    ProviderTimeoutError,
    ProviderUnavailableError,
    UnsupportedFileError,
)
from document_sdk.core.models import (
    CloudExecutionAttemptEvidence,
    CloudExecutionPolicy,
    Document,
    FileDescriptor,
    PdfSourceReference,
    ProviderUsage,
)
from document_sdk.core.results import ProcessingMetadata, ProcessingResult
from document_sdk.files import inspect_file
from document_sdk.pdf._document import preflight_pdf_structure
from document_sdk.pdf.errors import PdfLimitExceededError
from document_sdk.pdf.local_first_models import (
    _MAX_CELLS,
    _MAX_CHARACTERS,
    _MAX_PAGES,
    _MAX_TABLES,
    FailureReason,
    PdfFallbackCell,
    PdfFallbackContent,
    PdfFallbackPage,
    PdfFallbackTable,
    PdfLocalFirstMode,
    PdfLocalFirstResult,
    PdfLocalFirstStatus,
    _has_observation,
    _ResultLimitError,
)
from document_sdk.pdf.models import PdfProcessingLimits
from document_sdk.pdf.unified import (
    PdfAnalysisMode,
    UnifiedPdfAnalysisOptions,
    UnifiedPdfPage,
    UnifiedPdfResult,
    UnifiedPdfTable,
    analyze_pdf,
)

if TYPE_CHECKING:
    from collections.abc import Iterator
    from typing import BinaryIO

    from document_sdk.ocr._azure_models import AzureDocumentIntelligenceConfig
    from document_sdk.ocr.azure import AzureDocumentIntelligenceProvider

_POSITIVE = frozenset(
    {
        "NO_TEXT_LAYER",
        "UPSTREAM_NO_TEXT_LAYER",
        "incomplete_orthogonal_separator_enclosure",
    }
)
_COMPANIONS = frozenset(
    {
        "UPSTREAM_PARTIAL",
        "PAGE_TABLE_PARTIAL",
        "PAGE_AUTHORITY_PARTIAL",
        "LAYOUT_PARTIAL",
        "UPSTREAM_LAYOUT_PARTIAL",
        "UPSTREAM_LAYOUT_PAGE_PARTIAL",
        "READING_STRUCTURE_PARTIAL",
        "DOCUMENT_TABLE_PARTIAL",
        "DOCUMENT_TABLE_INPUT_UNAVAILABLE",
        "TRANSITION_AUTHORITY_PARTIAL",
        "TRANSITION_FINGERPRINT_PARTIAL",
        "UPSTREAM_TABLE_PARTIAL",
        "UPSTREAM_TABLE_AMBIGUOUS",
        "UPSTREAM_TABLE_VALUE_UNAVAILABLE",
        "source_geometry_inventory_incomplete",
    }
)
_DIAGNOSTICS = frozenset(
    {
        "FAMILY_DEFERRED",
        "OCR_NOT_EXECUTED",
        "BORDERLESS_TABLE_INTENT_AMBIGUOUS",
        "borderless_table_intent_not_independently_proven",
    }
)
_RESOURCE = frozenset(
    {
        "file_size_limit_reached",
        "page_limit_reached",
        "selected_page_limit_reached",
        "content_stream_too_large",
        "text_fact_limit_reached",
        "character_limit_reached",
        "text_member_limit_reached",
        "text_member_bytes_limit_reached",
        "drawing_limit_reached",
        "path_segment_limit_reached",
        "image_limit_reached",
        "total_fact_limit_reached",
        "artifact_size_limit_reached",
        "warning_limit_reached",
        "extraction_timeout",
        "UPSTREAM_RESOURCE_LIMIT_EXCEEDED",
        "UPSTREAM_LAYOUT_RESOURCE_LIMIT_EXCEEDED",
        "UPSTREAM_LAYOUT_PAGE_RESOURCE_LIMIT_EXCEEDED",
        "DOCUMENT_TABLE_RESOURCE_LIMITED",
        "table_member_selection_resource_limit",
        "table_text_evidence_resource_limit",
    }
)
_NORMAL_DIAGNOSTICS = frozenset({"FAMILY_DEFERRED", "OCR_NOT_EXECUTED"})
_CONTROL = (KeyboardInterrupt, SystemExit, GeneratorExit)
_CHUNK_BYTES = 1024 * 1024


class _CleanupError(DocumentProcessingError):
    """Report ordinary cleanup failure without obscuring control exceptions."""


def _validate_args(
    source: Path,
    mode: PdfLocalFirstMode,
    limits: PdfProcessingLimits | None,
    password: str | None,
    provider: object,
    *,
    allow_upload: bool,
) -> PdfProcessingLimits:
    invalid = "Local-first PDF request is invalid"
    if type(mode) is not PdfLocalFirstMode or type(allow_upload) is not bool:
        raise InvalidSourceReferenceError(invalid)
    if mode is PdfLocalFirstMode.LOCAL and (
        provider is not None or allow_upload is True
    ):
        raise ProviderConfigurationError("LOCAL does not accept cloud arguments")
    if type(source) is not type(Path()) or source.suffix.lower() != ".pdf":
        raise InvalidSourceReferenceError(invalid)
    if limits is None:
        checked = PdfProcessingLimits()
    elif type(limits) is not PdfProcessingLimits:
        raise InvalidSourceReferenceError(invalid)
    else:
        try:
            checked = _revalidate_model_instance_json(
                limits, PdfProcessingLimits, invalid
            )
        except Exception as exc:  # noqa: BLE001 - fixed public argument boundary.
            redact_exception(exc)
            raise InvalidSourceReferenceError(invalid) from None
    if password is not None and (type(password) is not str or "\0" in password):
        raise InvalidSourceReferenceError(invalid)
    return checked


def _bounded_identity(
    path: Path, size_limit: int, output: BinaryIO | None = None
) -> tuple[str, int]:
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise FileAccessError("Local-first PDF input is not a regular file")
    if before.st_size > size_limit:
        raise PdfLimitExceededError(
            limit_name="max_file_bytes", observed=before.st_size, maximum=size_limit
        )
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as stream:
        opened = os.fstat(stream.fileno())
        if (opened.st_dev, opened.st_ino, opened.st_size) != (
            before.st_dev,
            before.st_ino,
            before.st_size,
        ):
            raise DocumentSourceChangedError("Local-first PDF source changed")
        digest = sha256()
        count = 0
        while chunk := stream.read(min(_CHUNK_BYTES, before.st_size + 1 - count)):
            count += len(chunk)
            if count > before.st_size:
                raise DocumentSourceChangedError("Local-first PDF source changed")
            digest.update(chunk)
            if output is not None:
                output.write(chunk)
        after = path.lstat()
        if (
            count != before.st_size
            or not stat.S_ISREG(after.st_mode)
            or (after.st_dev, after.st_ino, after.st_size)
            != (before.st_dev, before.st_ino, before.st_size)
        ):
            raise DocumentSourceChangedError("Local-first PDF source changed")
    return digest.hexdigest(), count


def _verify_identity(path: Path, descriptor: FileDescriptor) -> None:
    try:
        identity = _bounded_identity(path, descriptor.size_bytes)
    except (OSError, FileAccessError, PdfLimitExceededError) as exc:
        redact_exception(exc)
        raise DocumentSourceChangedError("Local-first PDF source changed") from None
    if identity != (
        descriptor.fingerprint.value,
        descriptor.size_bytes,
    ):
        raise DocumentSourceChangedError("Local-first PDF source changed")


@contextmanager
def _pdf_snapshot(
    source: Path, limits: PdfProcessingLimits
) -> Iterator[tuple[Path, FileDescriptor]]:
    tmpdir = os.environ.get("TMPDIR")
    if tmpdir is not None and (not tmpdir or not Path(tmpdir).is_dir()):
        raise FileAccessError("Local-first PDF temporary directory is unavailable")
    directory = Path(tempfile.mkdtemp(prefix="pdf-local-first-", dir=tmpdir))
    try:
        directory.chmod(0o700)
        snapshot = directory / source.name
        with snapshot.open("xb") as output:
            snapshot.chmod(0o600)
            identity = _bounded_identity(source, limits.max_file_bytes, output)
        descriptor = inspect_file(snapshot)
        if identity != (descriptor.fingerprint.value, descriptor.size_bytes):
            raise DocumentSourceChangedError("Local-first PDF source changed")
        yield snapshot, descriptor
        _verify_identity(source, descriptor)
        _verify_identity(snapshot, descriptor)
    finally:
        active = sys.exc_info()[1]
        try:
            shutil.rmtree(directory)
        except Exception as exc:  # noqa: BLE001 - cleanup is a fixed failure boundary.
            redact_exception(exc)
            if not isinstance(active, _CONTROL):
                raise _CleanupError("Local-first PDF finalization failed") from None


def _checked_local(value: object, descriptor: FileDescriptor) -> UnifiedPdfResult:
    if type(value) is not UnifiedPdfResult:
        raise ValueError("Local-first PDF Local result is invalid")
    result = UnifiedPdfResult.model_validate_json(value.to_json_bytes())
    if (
        result.source_sha256 != descriptor.fingerprint.value
        or result.processing_mode is not PdfAnalysisMode.ADVANCED_LOCAL
        or result.status != "COMPLETED"
        or result.schema_version != "document_sdk.pdf.unified_result.v4"
        or result.page_count < 1
    ):
        raise ValueError("Local-first PDF Local result is invalid")
    if (
        result.availability != "AVAILABLE"
        and not set(result.limitations) - _NORMAL_DIAGNOSTICS
        and all(p.availability == "AVAILABLE" for p in result.pages)
        and all(
            t.availability == "AVAILABLE"
            and all(c.availability == "AVAILABLE" for c in t.cells)
            for t in result.tables
        )
    ):
        raise ValueError("Local-first PDF Local result is inconsistent")
    return result


def _classify_local(result: UnifiedPdfResult) -> tuple[bool, bool, FailureReason]:
    """Classify public fields only; denial precedes every W and CR-02 companion."""
    objects: tuple[UnifiedPdfPage | UnifiedPdfTable, ...] = (
        *result.pages,
        *result.tables,
    )
    normal = (
        result.availability == "AVAILABLE"
        and all(o.availability == "AVAILABLE" for o in objects)
        and all(c.availability == "AVAILABLE" for t in result.tables for c in t.cells)
        and set(result.limitations) <= _NORMAL_DIAGNOSTICS
        and not result.warnings
        and all(not o.limitations for o in objects)
    )
    if normal:
        return True, False, "LOCAL_TECHNICAL_GAP"
    pages = {p.page_number: p for p in result.pages}
    w01_document = (
        result.availability != "AVAILABLE"
        and "NO_TEXT_LAYER" in result.limitations
        and all(not p.text.strip() for p in result.pages)
    )
    w01 = w01_document or any(
        p.availability != "AVAILABLE" and "UPSTREAM_NO_TEXT_LAYER" in p.limitations
        for p in result.pages
    )
    w02 = any(
        (
            pages[t.page_number].availability != "AVAILABLE"
            or t.availability != "AVAILABLE"
        )
        and c.availability != "AVAILABLE"
        and c.text is None
        for t in result.tables
        for c in t.cells
    )
    w03 = any(
        o.availability != "AVAILABLE"
        and "incomplete_orthogonal_separator_enclosure" in o.limitations
        for o in objects
    )
    reasons = set(result.limitations)
    for obj in objects:
        reasons.update(obj.limitations)
    if reasons & _RESOURCE:
        return False, False, "LOCAL_TECHNICAL_GAP"
    allowed = _POSITIVE | _COMPANIONS | _DIAGNOSTICS
    if w02:
        allowed |= {"borderless_cell_ownership_unproven", "short_column_order_unproven"}
    warnings = {"no_text_layer"} if w01 else set()
    if w01_document:  # CR-02 A: the page-level W01 branch is insufficient.
        warnings.add("page_partially_parsed")
    if (
        reasons - allowed
        or set(result.warnings) - warnings
        or any(o.availability != "AVAILABLE" and not o.limitations for o in objects)
    ):
        return False, False, "LOCAL_LIMITATION_UNCLASSIFIED"
    if (
        result.availability != "AVAILABLE"
        and not reasons - _NORMAL_DIAGNOSTICS
        and all(o.availability == "AVAILABLE" for o in objects)
        and all(c.availability == "AVAILABLE" for t in result.tables for c in t.cells)
    ):
        raise ValueError("Local-first PDF Local result is inconsistent")
    return False, w01 or w02 or w03, "LOCAL_TECHNICAL_GAP"


def _bound_projection(pages: int, tables: int, cells: int, characters: int) -> None:
    if (
        pages > _MAX_PAGES
        or tables > _MAX_TABLES
        or cells > _MAX_CELLS
        or characters > _MAX_CHARACTERS
    ):
        raise _ResultLimitError("Local-first PDF result exceeds its limit")


def _project_local(
    result: UnifiedPdfResult, descriptor: FileDescriptor
) -> PdfFallbackContent:
    _bound_projection(
        len(result.pages),
        len(result.tables),
        sum(len(t.cells) for t in result.tables),
        sum(len(p.text) for p in result.pages)
        + sum(
            len(c.text) for t in result.tables for c in t.cells if c.text is not None
        ),
    )
    tables = {t.table_id: t for t in result.tables}
    return PdfFallbackContent(
        file=descriptor,
        pages=tuple(
            PdfFallbackPage(
                page_number=p.page_number,
                text=p.text,
                tables=tuple(
                    PdfFallbackTable(
                        row_count=t.row_count,
                        column_count=t.column_count,
                        cells=tuple(
                            PdfFallbackCell(
                                row_index=c.row_index,
                                column_index=c.column_index,
                                row_span=c.row_span,
                                column_span=c.column_span,
                                text=c.text,
                            )
                            for c in t.cells
                        ),
                    )
                    for t in (tables[identity] for identity in p.table_ids)
                ),
            )
            for p in result.pages
        ),
    )


def _local_result(
    result: UnifiedPdfResult,
    descriptor: FileDescriptor,
    *,
    normal: bool,
    reason: FailureReason,
) -> PdfLocalFirstResult:
    content = _project_local(result, descriptor)
    if not normal and not _has_observation(content):
        return _failed(
            "LOCAL_CONTENT_UNAVAILABLE"
            if reason in {"LOCAL_TECHNICAL_GAP", "LOCAL_LIMITATION_UNCLASSIFIED"}
            else reason
        )
    return PdfLocalFirstResult(
        status=PdfLocalFirstStatus.SUCCESS if normal else PdfLocalFirstStatus.PARTIAL,
        origin="LOCAL",
        content=content,
        failure_reason=None if normal else reason,
    )


def _cloud_admission(  # noqa: PLR0911 - admission returns the first fixed denial.
    provider: object,
    snapshot: Path,
    source: Path,
    descriptor: FileDescriptor,
    local: UnifiedPdfResult,
    limits: PdfProcessingLimits,
) -> tuple[AzureDocumentIntelligenceConfig | None, FailureReason | None]:
    _verify_identity(source, descriptor)
    _verify_identity(snapshot, descriptor)
    _, preflight = preflight_pdf_structure(
        snapshot,
        limits,
        expected_identity=(descriptor.fingerprint.value, descriptor.size_bytes),
    )
    if preflight.page_count != local.page_count or preflight.page_count < 1:
        raise DocumentSourceChangedError("Local-first PDF page inventory changed")
    from document_sdk.ocr._azure_models import AzureDocumentIntelligenceConfig
    from document_sdk.ocr._azure_preflight import effective_azure_page_limit
    from document_sdk.ocr.azure import AzureDocumentIntelligenceProvider

    if type(provider) is not AzureDocumentIntelligenceProvider:
        return None, "CLOUD_CONFIGURATION_INVALID"
    method = inspect.getattr_static(provider, "analyze")
    if (
        type(method) is not FunctionType
        or method is not AzureDocumentIntelligenceProvider.analyze
        or method.__module__ != "document_sdk.ocr.azure"
        or method.__qualname__ != "AzureDocumentIntelligenceProvider.analyze"
    ):
        return None, "CLOUD_CONFIGURATION_INVALID"
    try:
        config = _revalidate_model_instance_json(
            cast("AzureDocumentIntelligenceConfig", provider.context.config),
            AzureDocumentIntelligenceConfig,
            "Local-first cloud configuration is invalid",
        )
        policy = _revalidate_model_instance_json(
            provider._cloud_execution_policy_snapshot(),  # noqa: SLF001 - approved policy reuse.
            CloudExecutionPolicy,
            "Local-first cloud policy is invalid",
        )
    except Exception as exc:  # noqa: BLE001 - no credentials are read at admission.
        redact_exception(exc)
        return None, "CLOUD_CONFIGURATION_INVALID"
    if (
        config.model_id != "prebuilt-layout"
        or config.api_version != "2024-11-30"
        or config.transport_retry_total != 0
        or policy != config.cloud_execution_policy
    ):
        return None, "CLOUD_CONFIGURATION_INVALID"
    if not policy.allow_cloud_execution or not policy.allow_cloud_fallback:
        return None, "CLOUD_POLICY_DENIED"
    if (
        descriptor.size_bytes
        > min(limits.max_file_bytes, config.max_input_bytes, policy.max_input_bytes)
        or local.page_count
        > min(
            limits.max_pages,
            effective_azure_page_limit(
                policy.max_pages_or_frames, public_model_max_pages_or_frames=2000
            ),
        )
        or min(
            policy.max_logical_cloud_operations,
            policy.max_submitted_operations,
            policy.max_paid_or_possibly_paid_operations,
        )
        < 1
    ):
        return None, "CLOUD_LIMIT_EXCEEDED"
    return config, None


def _evidence_matches(
    usage: ProviderUsage | None,
    attempt: CloudExecutionAttemptEvidence | None,
    config: AzureDocumentIntelligenceConfig,
    profile: str,
    descriptor: FileDescriptor,
    count: int,
) -> bool:
    pages = tuple(range(1, count + 1))
    for evidence in (usage, attempt):
        if evidence is not None and (
            evidence.provider_name != config.provider_name
            or evidence.profile_id != profile
            or evidence.model_id != config.model_id
            or evidence.api_version != config.api_version
            or evidence.provider_resource_identity != config.resource_identity
            or evidence.submitted_frames
        ):
            return False
    if usage is not None and (
        usage.submitted_pages != pages
        or usage.returned_pages != pages
        or usage.cloud_logical_operation_count != 1
        or usage.cloud_submitted_operation_count != 1
        or usage.cloud_paid_or_possibly_paid_operation_count != 1
        or usage.cloud_transport_retry_count != 0
        or usage.requested_features
        or usage.query_field_count
    ):
        return False
    return attempt is None or (
        attempt.policy_fingerprint == config.cloud_execution_policy.fingerprint()
        and attempt.requested_entire_input
        and not attempt.requested_pages
        and not attempt.requested_frames
        and (
            attempt.submitted_pages == pages
            if attempt.submitted_operation_count
            else not attempt.submitted_pages
        )
        and (
            attempt.input_bytes == descriptor.size_bytes
            if attempt.submitted_operation_count
            else attempt.input_bytes in {0, descriptor.size_bytes}
        )
    )


def _returned_evidence(
    value: object,
) -> tuple[ProviderUsage | None, CloudExecutionAttemptEvidence | None, bool]:
    if type(value) is not ProcessingResult[Document]:
        return None, None, False
    metadata = object.__getattribute__(value, "__dict__").get("metadata")
    if type(metadata) is not ProcessingMetadata:
        return None, None, False
    fields = object.__getattribute__(metadata, "__dict__")
    usage, attempt, valid = None, None, True
    try:
        if fields.get("provider_usage") is not None:
            usage = _revalidate_model_instance_json(
                fields["provider_usage"], ProviderUsage, "Cloud usage is invalid"
            )
    except Exception as exc:  # noqa: BLE001 - invalid Usage cannot erase a valid Attempt.
        redact_exception(exc)
        valid = False
    try:
        if fields.get("cloud_execution_attempt") is not None:
            attempt = _revalidate_model_instance_json(
                fields["cloud_execution_attempt"],
                CloudExecutionAttemptEvidence,
                "Cloud attempt is invalid",
            )
    except Exception as exc:  # noqa: BLE001 - invalid Attempt cannot erase a valid Usage.
        redact_exception(exc)
        valid = False
    try:
        if usage is not None and attempt is not None:
            from document_sdk.ocr._azure_execution import (
                _validated_completed_cloud_result,
            )

            usage, attempt = _validated_completed_cloud_result(usage, attempt)
    except Exception as exc:  # noqa: BLE001 - inconsistent pairs cannot be exposed together.
        redact_exception(exc)
        valid = False
        usage = None
    return usage, attempt, valid


def _checked_document(
    value: object, descriptor: FileDescriptor, count: int
) -> ProcessingResult[Document]:
    from document_sdk.ocr._provider_boundary import (
        _revalidate_document_processing_result,
    )

    result = _revalidate_document_processing_result(value)
    document = result.data
    if document is None or result.errors:
        raise ProviderResponseError("Local-first cloud result is invalid")
    actual = document.file
    if (
        actual.fingerprint != descriptor.fingerprint
        or actual.size_bytes != descriptor.size_bytes
        or actual.filename != descriptor.filename
        or actual.extension != ".pdf"
        or actual.mime_type != "application/pdf"
        or tuple(sorted(p.page_number for p in document.pages))
        != tuple(range(1, count + 1))
        or any(type(p.source) is not PdfSourceReference for p in document.pages)
    ):
        raise ProviderResponseError("Local-first cloud result is invalid")
    for page in document.pages:
        sources = (
            page.source,
            *(block.source for block in page.text_blocks),
            *(table.source for table in page.tables),
            *(cell.source for table in page.tables for cell in table.cells),
        )
        if any(
            type(s) is not PdfSourceReference
            or s.file_id != actual.file_id
            or s.page_number != page.page_number
            for s in sources
        ):
            raise ProviderResponseError("Local-first cloud page attribution is invalid")
    return result


def _project_azure(document: Document) -> PdfFallbackContent:
    tables = tuple(t for p in document.pages for t in p.tables)
    _bound_projection(
        len(document.pages),
        len(tables),
        sum(len(t.cells) for t in tables),
        sum(
            sum(len(b.text) for b in p.text_blocks) + max(0, len(p.text_blocks) - 1)
            for p in document.pages
        )
        + sum(len(c.text) for t in tables for c in t.cells),
    )
    pages: list[PdfFallbackPage] = []
    for page in sorted(document.pages, key=lambda p: p.page_number):
        projected: list[PdfFallbackTable] = []
        for table in page.tables:
            if table.row_count is None or table.column_count is None:
                raise ValueError("Local-first cloud table dimensions are unavailable")
            projected.append(
                PdfFallbackTable(
                    row_count=table.row_count,
                    column_count=table.column_count,
                    cells=tuple(
                        PdfFallbackCell(
                            row_index=c.row - 1,
                            column_index=c.column - 1,
                            row_span=c.row_span,
                            column_span=c.column_span,
                            text=c.text,
                        )
                        for c in table.cells
                    ),
                )
            )
        pages.append(
            PdfFallbackPage(
                page_number=page.page_number,
                text="\n".join(b.text for b in page.text_blocks),
                tables=tuple(projected),
            )
        )
    return PdfFallbackContent(file=document.file, pages=tuple(pages))


def _failed(
    reason: FailureReason,
    usage: ProviderUsage | None = None,
    attempt: CloudExecutionAttemptEvidence | None = None,
) -> PdfLocalFirstResult:
    return PdfLocalFirstResult(
        status=PdfLocalFirstStatus.FAILED,
        failure_reason=reason,
        provider_usage=usage,
        cloud_attempt=attempt,
    )


def _failure_code(error: Exception, phase: str) -> FailureReason:  # noqa: PLR0911, C901 - fixed failure priority.
    if isinstance(error, _CleanupError):
        return "FINALIZATION_FAILED"
    if isinstance(error, DocumentSourceChangedError):
        return "SOURCE_CHANGED"
    if isinstance(error, _ResultLimitError):
        return "RESULT_LIMIT_EXCEEDED"
    if phase in {"input", "preflight"} or isinstance(
        error,
        (
            FileAccessError,
            UnsupportedFileError,
            EncryptedDocumentError,
            PdfLimitExceededError,
        ),
    ):
        return "INPUT_REJECTED"
    if phase == "local":
        return "LOCAL_ANALYSIS_FAILED"
    if phase in {"local_result", "classification", "project_local"}:
        return "LOCAL_RESULT_INVALID"
    if phase == "final":
        return "FINALIZATION_FAILED"
    if phase == "project_azure":
        return "AZURE_PROJECTION_FAILED"
    for error_type, code in (
        (ProviderTimeoutError, "AZURE_TIMEOUT"),
        (ProviderAuthenticationError, "AZURE_AUTHENTICATION_FAILED"),
        (ProviderAuthorizationError, "AZURE_AUTHORIZATION_FAILED"),
        (ProviderRateLimitError, "AZURE_RATE_LIMITED"),
        (ProviderRequestError, "AZURE_REQUEST_REJECTED"),
        (ProviderUnavailableError, "AZURE_UNAVAILABLE"),
        (ProviderResponseError, "AZURE_RESPONSE_INVALID"),
    ):
        if isinstance(error, error_type):
            return cast("FailureReason", code)
    return (
        "AZURE_RESPONSE_INVALID"
        if phase == "azure_result"
        else "AZURE_EXECUTION_FAILED"
    )


def analyze_pdf_local_first(  # noqa: C901, PLR0912, PLR0915 - one bounded sequential operation.
    source: Path,
    *,
    mode: PdfLocalFirstMode = PdfLocalFirstMode.LOCAL,
    limits: PdfProcessingLimits | None = None,
    password: str | None = None,
    azure_provider: AzureDocumentIntelligenceProvider | None = None,
    allow_full_document_upload: bool = False,
) -> PdfLocalFirstResult:
    """Analyze locally once, then optionally replace all content with Azure.

    LOCAL rejects cloud arguments before accessing their attributes. HYBRID
    needs an eligible public Local gap, explicit full-upload authorization,
    and the customer's execution and fallback policy. No exception rescue,
    partial merge, credential lookup outside the Provider, or retry is added.
    """
    checked_limits = _validate_args(
        source,
        mode,
        limits,
        password,
        azure_provider,
        allow_upload=allow_full_document_upload,
    )
    usage: ProviderUsage | None = None
    attempt: CloudExecutionAttemptEvidence | None = None
    phase = "input"
    cloud_called = False
    try:
        with _pdf_snapshot(source, checked_limits) as (snapshot, descriptor):
            phase = "local"
            raw = analyze_pdf(
                snapshot,
                options=UnifiedPdfAnalysisOptions(
                    mode=PdfAnalysisMode.ADVANCED_LOCAL, limits=checked_limits
                ),
                password=password,
            )
            phase = "local_result"
            local = _checked_local(raw, descriptor)
            phase = "classification"
            normal, eligible, reason = _classify_local(local)
            config = None
            if not normal and eligible and mode is PdfLocalFirstMode.HYBRID:
                if not allow_full_document_upload:
                    reason = "FULL_UPLOAD_NOT_AUTHORIZED"
                elif azure_provider is None:
                    reason = "AZURE_PROVIDER_REQUIRED"
                else:
                    phase = "preflight"
                    config, denied = _cloud_admission(
                        azure_provider,
                        snapshot,
                        source,
                        descriptor,
                        local,
                        checked_limits,
                    )
                    if denied is not None:
                        reason = denied
            if config is None:
                phase = "project_local"
                candidate = _local_result(
                    local, descriptor, normal=normal, reason=reason
                )
            else:
                from document_sdk.ocr.models import OcrAnalysisOptions

                phase = "cloud"
                cloud_called = True
                assert azure_provider is not None  # noqa: S101 - admitted above.
                try:
                    returned = azure_provider.analyze(
                        snapshot, options=OcrAnalysisOptions()
                    )
                except Exception as exc:
                    from document_sdk.ocr._azure_execution import (
                        read_cloud_execution_attempt,
                        read_completed_cloud_result,
                    )

                    completed = read_completed_cloud_result(exc)
                    if completed is not None:
                        usage, attempt = completed
                    else:
                        attempt = read_cloud_execution_attempt(exc)
                    raise
                usage, attempt, valid = _returned_evidence(returned)
                phase = "azure_result"
                if not valid or not _evidence_matches(
                    usage,
                    attempt,
                    config,
                    azure_provider.context.profile_id,
                    descriptor,
                    local.page_count,
                ):
                    if not _evidence_matches(
                        usage,
                        None,
                        config,
                        azure_provider.context.profile_id,
                        descriptor,
                        local.page_count,
                    ):
                        usage = None
                    if not _evidence_matches(
                        None,
                        attempt,
                        config,
                        azure_provider.context.profile_id,
                        descriptor,
                        local.page_count,
                    ):
                        attempt = None
                    raise ProviderResponseError("Local-first cloud evidence is invalid")  # noqa: TRY301 - evidence already retained.
                checked = _checked_document(returned, descriptor, local.page_count)
                phase = "project_azure"
                assert checked.data is not None  # noqa: S101 - checked above.
                content = _project_azure(checked.data)
                if not _has_observation(content):
                    candidate = _failed("AZURE_CONTENT_UNAVAILABLE", usage, attempt)
                else:
                    candidate = PdfLocalFirstResult(
                        status=PdfLocalFirstStatus.PARTIAL
                        if checked.warnings
                        else PdfLocalFirstStatus.SUCCESS,
                        origin="AZURE",
                        content=content,
                        failure_reason="AZURE_RESULT_LIMITED"
                        if checked.warnings
                        else None,
                        provider_usage=usage,
                        cloud_attempt=attempt,
                    )
            phase = "final"
            candidate = PdfLocalFirstResult.model_validate_json(
                candidate.model_dump_json()
            )
    except Exception as exc:  # noqa: BLE001 - sanitized bounded orchestration.
        if cloud_called:
            from document_sdk.ocr._azure_execution import (
                read_cloud_execution_attempt,
                read_completed_cloud_result,
            )

            completed = read_completed_cloud_result(exc)
            if completed is not None:
                usage, attempt = completed
            elif attempt is None:
                attempt = read_cloud_execution_attempt(exc)
        reason = _failure_code(exc, phase)
        redact_exception(exc)
        return _failed(reason, usage, attempt)
    else:
        return candidate

"""Bounded common content for the opt-in local-first PDF API."""

from __future__ import annotations

from enum import StrEnum
from typing import Any, Literal, Self, cast

from pydantic import ConfigDict, Field, field_validator, model_validator

from document_sdk.core._validation import (
    SanitizedPublicModel,
    _revalidate_model_instance_json,
)
from document_sdk.core.errors import DocumentProcessingError
from document_sdk.core.models import (
    CloudExecutionAttemptEvidence,
    FileDescriptor,
    ProviderUsage,
)

_MAX_PAGES = 2_048
_MAX_TABLES = 65_536
_MAX_CELLS = 2_000_000
_MAX_CHARACTERS = 100_000_000
_MAX_JSON_BYTES = 512 * 1024 * 1024
_INVALID = "Local-first PDF result is invalid"

type FailureReason = Literal[
    "INPUT_REJECTED",
    "SOURCE_CHANGED",
    "LOCAL_ANALYSIS_FAILED",
    "LOCAL_RESULT_INVALID",
    "LOCAL_CONTENT_UNAVAILABLE",
    "LOCAL_TECHNICAL_GAP",
    "LOCAL_LIMITATION_UNCLASSIFIED",
    "FULL_UPLOAD_NOT_AUTHORIZED",
    "AZURE_PROVIDER_REQUIRED",
    "CLOUD_POLICY_DENIED",
    "CLOUD_CONFIGURATION_INVALID",
    "CLOUD_LIMIT_EXCEEDED",
    "AZURE_EXECUTION_FAILED",
    "AZURE_TIMEOUT",
    "AZURE_AUTHENTICATION_FAILED",
    "AZURE_AUTHORIZATION_FAILED",
    "AZURE_RATE_LIMITED",
    "AZURE_REQUEST_REJECTED",
    "AZURE_UNAVAILABLE",
    "AZURE_RESPONSE_INVALID",
    "AZURE_RESULT_LIMITED",
    "AZURE_CONTENT_UNAVAILABLE",
    "AZURE_PROJECTION_FAILED",
    "RESULT_LIMIT_EXCEEDED",
    "FINALIZATION_FAILED",
]


class PdfLocalFirstMode(StrEnum):
    """Select local-only processing or explicitly authorized full fallback."""

    LOCAL = "LOCAL"
    HYBRID = "HYBRID"


class PdfLocalFirstStatus(StrEnum):
    """Describe completion of the bounded common content contract."""

    SUCCESS = "SUCCESS"
    PARTIAL = "PARTIAL"
    FAILED = "FAILED"


class _ResultLimitError(DocumentProcessingError):
    """Stop rather than truncate a common result that exceeds its limits."""


def _bounded_array(value: object, limit: int) -> tuple[object, ...]:
    if type(value) not in {tuple, list}:
        raise ValueError(_INVALID)
    items = cast("list[object] | tuple[object, ...]", value)
    if len(items) > limit:
        raise _ResultLimitError(_INVALID)
    return tuple(items)


class PdfFallbackCell(SanitizedPublicModel):
    """One zero-based cell; unavailable text remains distinct from empty text."""

    _validation_error_type = DocumentProcessingError
    _validation_error_message = _INVALID
    model_config = ConfigDict(
        strict=True,
        frozen=True,
        extra="forbid",
        revalidate_instances="always",
        allow_inf_nan=False,
    )
    row_index: int = Field(ge=0, le=_MAX_CELLS)
    column_index: int = Field(ge=0, le=_MAX_CELLS)
    row_span: int = Field(ge=1, le=_MAX_CELLS)
    column_span: int = Field(ge=1, le=_MAX_CELLS)
    text: str | None = Field(max_length=_MAX_CHARACTERS)


class PdfFallbackTable(SanitizedPublicModel):
    """One page table without inferred cells or dimensions."""

    _validation_error_type = DocumentProcessingError
    _validation_error_message = _INVALID
    model_config = ConfigDict(
        strict=True,
        frozen=True,
        extra="forbid",
        revalidate_instances="always",
        allow_inf_nan=False,
    )
    row_count: int = Field(ge=1, le=_MAX_CELLS)
    column_count: int = Field(ge=1, le=_MAX_CELLS)
    cells: tuple[PdfFallbackCell, ...]

    @field_validator("cells", mode="before")
    @classmethod
    def bound_cells(cls, value: object) -> tuple[object, ...]:
        """Bound raw collections before validating their children."""
        return _bounded_array(value, _MAX_CELLS)

    @model_validator(mode="after")
    def validate_cells(self) -> Self:
        """Reject duplicate anchors and spans outside declared dimensions."""
        anchors: set[tuple[int, int]] = set()
        for cell in self.cells:
            anchor = (cell.row_index, cell.column_index)
            if (
                anchor in anchors
                or cell.row_index + cell.row_span > self.row_count
                or cell.column_index + cell.column_span > self.column_count
            ):
                raise ValueError(_INVALID)
            anchors.add(anchor)
        return self


class PdfFallbackPage(SanitizedPublicModel):
    """Original page text and its page-local tables."""

    _validation_error_type = DocumentProcessingError
    _validation_error_message = _INVALID
    model_config = ConfigDict(
        strict=True,
        frozen=True,
        extra="forbid",
        revalidate_instances="always",
        allow_inf_nan=False,
    )
    page_number: int = Field(ge=1, le=_MAX_PAGES)
    text: str = Field(max_length=_MAX_CHARACTERS)
    tables: tuple[PdfFallbackTable, ...]

    @field_validator("tables", mode="before")
    @classmethod
    def bound_tables(cls, value: object) -> tuple[object, ...]:
        """Reject unbounded or caller-defined table iterators."""
        return _bounded_array(value, _MAX_TABLES)


class PdfFallbackContent(SanitizedPublicModel):
    """One file identity and the complete ordered original page inventory."""

    _validation_error_type = DocumentProcessingError
    _validation_error_message = _INVALID
    model_config = ConfigDict(
        strict=True,
        frozen=True,
        extra="forbid",
        revalidate_instances="always",
        allow_inf_nan=False,
    )
    file: FileDescriptor
    pages: tuple[PdfFallbackPage, ...]

    @field_validator("pages", mode="before")
    @classmethod
    def bound_pages(cls, value: object) -> tuple[object, ...]:
        """Bound pages without deleting any empty original page."""
        return _bounded_array(value, _MAX_PAGES)

    @model_validator(mode="after")
    def validate_inventory(self) -> Self:
        """Enforce PDF identity, contiguous pages, and cumulative output limits."""
        descriptor = _revalidate_model_instance_json(
            self.file, FileDescriptor, _INVALID
        )
        object.__setattr__(self, "file", descriptor)
        if (
            descriptor.extension != ".pdf"
            or descriptor.mime_type != "application/pdf"
            or not self.pages
            or tuple(p.page_number for p in self.pages)
            != tuple(range(1, len(self.pages) + 1))
        ):
            raise ValueError(_INVALID)
        tables = cells = characters = 0
        for page in self.pages:
            tables += len(page.tables)
            characters += len(page.text)
            for table in page.tables:
                cells += len(table.cells)
                characters += sum(
                    len(c.text) for c in table.cells if c.text is not None
                )
        if tables > _MAX_TABLES or cells > _MAX_CELLS or characters > _MAX_CHARACTERS:
            raise _ResultLimitError(_INVALID)
        return self


def _has_observation(content: PdfFallbackContent) -> bool:
    return any(
        page.text.strip()
        or any(
            cell.text is not None and cell.text.strip()
            for table in page.tables
            for cell in table.cells
        )
        for page in content.pages
    )


class PdfLocalFirstResult(SanitizedPublicModel):
    """One final content origin and actual, optional cloud execution evidence."""

    _validation_error_type = DocumentProcessingError
    _validation_error_message = _INVALID
    model_config = ConfigDict(
        strict=True,
        frozen=True,
        extra="forbid",
        revalidate_instances="always",
        allow_inf_nan=False,
    )
    status: PdfLocalFirstStatus
    origin: Literal["LOCAL", "AZURE"] | None = None
    content: PdfFallbackContent | None = None
    failure_reason: FailureReason | None = None
    provider_usage: ProviderUsage | None = None
    cloud_attempt: CloudExecutionAttemptEvidence | None = None

    @model_validator(mode="after")
    def validate_state(self) -> Self:  # noqa: C901 - closed state and evidence invariants.
        """Keep failure, origin, observations, and evidence consistent."""
        if self.status is PdfLocalFirstStatus.FAILED:
            if (
                self.origin is not None
                or self.content is not None
                or self.failure_reason is None
            ):
                raise ValueError(_INVALID)
        elif self.content is None or self.origin is None:
            raise ValueError(_INVALID)
        elif self.status is PdfLocalFirstStatus.SUCCESS:
            if self.failure_reason is not None:
                raise ValueError(_INVALID)
        elif self.failure_reason is None or not _has_observation(self.content):
            raise ValueError(_INVALID)
        if self.origin == "LOCAL" and (
            self.provider_usage is not None or self.cloud_attempt is not None
        ):
            raise ValueError(_INVALID)
        if (
            self.origin == "AZURE"
            and self.content is not None
            and not _has_observation(self.content)
        ):
            raise ValueError(_INVALID)
        for name, model in (
            ("provider_usage", ProviderUsage),
            ("cloud_attempt", CloudExecutionAttemptEvidence),
        ):
            value = getattr(self, name)
            if value is not None:
                object.__setattr__(
                    self, name, _revalidate_model_instance_json(value, model, _INVALID)
                )
        if self.provider_usage is not None and self.cloud_attempt is not None:
            # Failed attempts need not have Usage. A present pair is completed evidence.
            from document_sdk.ocr._azure_execution import (
                _validated_completed_cloud_result,
            )

            _validated_completed_cloud_result(self.provider_usage, self.cloud_attempt)
        return self

    @classmethod
    def model_validate_json(
        cls, json_data: str | bytes | bytearray, **kwargs: Any
    ) -> Self:
        """Reject an oversized JSON payload before parsing it."""
        size = (
            len(json_data.encode("utf-8"))
            if isinstance(json_data, str)
            else len(json_data)
        )
        if size > _MAX_JSON_BYTES:
            raise _ResultLimitError(_INVALID)
        return super().model_validate_json(json_data, **kwargs)

    def model_dump_json(self, **kwargs: Any) -> str:
        """Emit bounded UTF-8 JSON with all six fields by default."""
        payload = super().model_dump_json(**kwargs)
        if len(payload.encode("utf-8")) > _MAX_JSON_BYTES:
            raise _ResultLimitError(_INVALID)
        return payload

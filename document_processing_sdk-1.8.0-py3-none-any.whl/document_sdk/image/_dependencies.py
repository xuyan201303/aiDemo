"""Optional dependency boundary for local image support."""

from importlib import import_module

from document_sdk.core import DependencyNotInstalledError
from document_sdk.core.errors import _raise_redacted_translation

IMAGE_DEPENDENCY_MESSAGE = """Image support is not installed.
Install it with:
  pip install "document-processing-sdk[image]"
or:
  uv add "document-processing-sdk[image]\""""

IMAGE_OPENCV_DEPENDENCY_MESSAGE = """OpenCV image support is not installed.
Install it with:
  pip install "document-processing-sdk[image-opencv]"
or:
  uv add "document-processing-sdk[image-opencv]\""""


def require_image_support() -> None:
    """Raise actionable guidance when Pillow is unavailable."""
    try:
        import_module("PIL")
    except ImportError as exc:
        _raise_redacted_translation(
            exc,
            DependencyNotInstalledError(IMAGE_DEPENDENCY_MESSAGE),
        )


def require_image_opencv_support() -> None:
    """Raise actionable guidance when NumPy or OpenCV is unavailable."""
    try:
        import_module("numpy")
        import_module("cv2")
    except ImportError as exc:
        _raise_redacted_translation(
            exc,
            DependencyNotInstalledError(IMAGE_OPENCV_DEPENDENCY_MESSAGE),
        )

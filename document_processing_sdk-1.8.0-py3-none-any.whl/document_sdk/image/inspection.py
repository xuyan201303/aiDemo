"""Bounded local image inspection."""

from __future__ import annotations

import warnings
from typing import TYPE_CHECKING, Literal, cast

from document_sdk.core import (
    DocumentSdkError,
    ImageFrameInspection,
    ImageInspection,
    ImageLimitExceededError,
    ImageProcessingError,
    ImageProcessingLimits,
    ImageSourceReference,
    UnsupportedFileError,
)
from document_sdk.core.errors import _raise_redacted_translation, safe_file_label
from document_sdk.files import inspect_file
from document_sdk.files._source_identity import verify_open_binary
from document_sdk.image._dependencies import require_image_support
from document_sdk.image._io import _validated_image_limits, has_alpha

if TYPE_CHECKING:
    from pathlib import Path

    from PIL.Image import Image as PillowImage

type _ImageFormat = Literal["PNG", "JPEG", "TIFF", "BMP", "WEBP"]
type _ImageMimeType = Literal[
    "image/png",
    "image/jpeg",
    "image/tiff",
    "image/bmp",
    "image/webp",
]
type _ImageLimitName = Literal[
    "frame count",
    "pixels per frame",
    "total pixels",
]

_EXIF_ORIENTATION_TAG = 274
_MIN_EXIF_ORIENTATION = 1
_MAX_EXIF_ORIENTATION = 8
_FORMAT_MIME_TYPES: dict[_ImageFormat, _ImageMimeType] = {
    "BMP": "image/bmp",
    "PNG": "image/png",
    "JPEG": "image/jpeg",
    "TIFF": "image/tiff",
    "WEBP": "image/webp",
}


def _enforce_limit(
    *,
    limit_name: _ImageLimitName,
    observed: int,
    maximum: int,
) -> None:
    """Raise a structured failure before full image decoding."""
    if observed > maximum:
        raise ImageLimitExceededError(
            limit_name=limit_name,
            observed=observed,
            maximum=maximum,
        )


def _supported_format(image: PillowImage) -> _ImageFormat:
    """Return the normalized supported format reported by Pillow."""
    image_format = image.format
    if image_format not in _FORMAT_MIME_TYPES:
        msg = "Image format is not supported"
        raise UnsupportedFileError(msg)
    return cast("_ImageFormat", image_format)


def _exif_orientation(
    image: PillowImage,
    *,
    frame_number: int,
    inspection_warnings: list[str],
) -> int | None:
    """Return valid EXIF orientation without exposing other EXIF metadata."""
    orientation = image.getexif().get(_EXIF_ORIENTATION_TAG)
    if orientation is None:
        return None
    if (
        isinstance(orientation, int)
        and not isinstance(orientation, bool)
        and _MIN_EXIF_ORIENTATION <= orientation <= _MAX_EXIF_ORIENTATION
    ):
        return orientation
    inspection_warnings.append(
        f"Frame {frame_number} has invalid EXIF orientation metadata."
    )
    return None


def _inspect_open_image(
    image: PillowImage,
    *,
    descriptor_file_id: str,
    limits: ImageProcessingLimits,
    verify_decode: bool,
) -> tuple[_ImageFormat, tuple[ImageFrameInspection, ...], tuple[str, ...]]:
    """Inspect all frame metadata, enforce limits, then optionally decode."""
    image_format = _supported_format(image)

    facts: list[tuple[int, int, str, bool, int | None]] = []
    inspection_warnings: list[str] = []
    total_pixels = 0
    for frame_index in range(limits.max_frames + 1):
        try:
            image.seek(frame_index)
        except EOFError:
            break
        if frame_index == limits.max_frames:
            _enforce_limit(
                limit_name="frame count",
                observed=frame_index + 1,
                maximum=limits.max_frames,
            )
        width, height = image.size
        pixel_count = width * height
        _enforce_limit(
            limit_name="pixels per frame",
            observed=pixel_count,
            maximum=limits.max_pixels_per_frame,
        )
        total_pixels += pixel_count
        _enforce_limit(
            limit_name="total pixels",
            observed=total_pixels,
            maximum=limits.max_total_pixels,
        )
        frame_number = frame_index + 1
        facts.append(
            (
                width,
                height,
                image.mode,
                has_alpha(image),
                _exif_orientation(
                    image,
                    frame_number=frame_number,
                    inspection_warnings=inspection_warnings,
                ),
            )
        )

    if verify_decode:
        for frame_index in range(len(facts)):
            image.seek(frame_index)
            image.load()

    frames = tuple(
        ImageFrameInspection(
            frame_number=frame_number,
            width=width,
            height=height,
            mode=mode,
            pixel_count=width * height,
            has_alpha=has_alpha,
            exif_orientation=exif_orientation,
            decode_verified=verify_decode,
            source=ImageSourceReference(
                file_id=descriptor_file_id,
                frame_number=frame_number,
            ),
        )
        for frame_number, (
            width,
            height,
            mode,
            has_alpha,
            exif_orientation,
        ) in enumerate(facts, start=1)
    )
    return image_format, frames, tuple(inspection_warnings)


def inspect_image(
    path: Path,
    *,
    limits: ImageProcessingLimits | None = None,
    verify_decode: bool = True,
) -> ImageInspection:
    """Inspect supported local image frames within explicit safety limits."""
    effective_limits = _validated_image_limits(limits)
    require_image_support()
    descriptor = inspect_file(path)

    from PIL import Image

    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with path.open("rb") as stream:
                verify_open_binary(
                    stream,
                    expected_fingerprint=descriptor.fingerprint.value,
                    expected_size=descriptor.size_bytes,
                    mismatch_message="Image changed after inspection",
                )
                with Image.open(stream) as image:
                    image_format, frames, inspection_warnings = _inspect_open_image(
                        image,
                        descriptor_file_id=descriptor.file_id,
                        limits=effective_limits,
                        verify_decode=verify_decode,
                    )
    except DocumentSdkError:
        raise
    except (Image.DecompressionBombWarning, Image.DecompressionBombError) as exc:
        msg = (
            "Image exceeds Pillow's decompression safety threshold: "
            f"{safe_file_label(path)}"
        )
        _raise_redacted_translation(exc, ImageProcessingError(msg))
    except Exception as exc:  # noqa: BLE001 - adapter boundary normalizes Pillow.
        msg = f"Unable to inspect image: {safe_file_label(path)}"
        _raise_redacted_translation(exc, ImageProcessingError(msg))

    mime_type = _FORMAT_MIME_TYPES[image_format]
    if descriptor.mime_type != mime_type:
        msg = f"Image file extension does not match its format: {safe_file_label(path)}"
        raise UnsupportedFileError(msg)
    return ImageInspection(
        file=descriptor,
        format=image_format,
        mime_type=mime_type,
        frame_count=len(frames),
        animated=len(frames) > 1,
        frames=frames,
        warnings=inspection_warnings,
    )

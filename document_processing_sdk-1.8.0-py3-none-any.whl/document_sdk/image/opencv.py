"""OpenCV normalization with deterministic ordering for a fixed backend."""

from __future__ import annotations

# OpenCV APIs use positional booleans and image-array dimension constants.
# ruff: noqa: FBT003, PLR2004
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal, cast

from document_sdk.core import (
    ImageProcessingError,
    ImageProcessingLimits,
    ImageSourceReference,
)
from document_sdk.image._dependencies import require_image_opencv_support
from document_sdk.image._io import (
    _document_rgb_frame,
    _prepare_selected_frame,
    _validated_image_limits,
    _validated_image_model,
    encode_image,
    enforce_output_dimensions,
    enforce_working_dimensions,
    open_verified_image,
    sanitized_image_adapter,
    selected_frame,
)
from document_sdk.image.errors import ImageAlignmentError
from document_sdk.image.models import (
    DocumentNormalizationOptions,
    DocumentNormalizationResult,
    EncodedImage,
    ImageAlignmentEvidence,
    ImageAlignmentOptions,
    ImageAlignmentResult,
    ImageFormat,
)

if TYPE_CHECKING:
    from pathlib import Path


@dataclass(frozen=True, slots=True)
class _DocumentNormalizationInput:
    """Decoded document pixels plus their original storage geometry."""

    array: Any
    source: ImageSourceReference
    storage_width: int
    storage_height: int
    exif_orientation: int | None
    alpha_composited: bool


def _libraries() -> tuple[Any, Any]:
    require_image_opencv_support()
    import cv2
    import numpy as np

    return cv2, np


def _load_array(
    path: Path,
    *,
    frame_number: int,
    limits: ImageProcessingLimits,
    alpha_mode: Literal["compare", "ignore", "composite_white"] = "ignore",
) -> tuple[Any, ImageSourceReference]:
    cv2, np = _libraries()
    with open_verified_image(path, action="load image for OpenCV processing") as (
        descriptor,
        image,
    ):
        frame = selected_frame(
            image,
            frame_number=frame_number,
            limits=limits,
            normalize_orientation=True,
        )
        converted = frame.convert(
            "RGBA" if alpha_mode in {"compare", "composite_white"} else "RGB"
        )
        try:
            array = np.asarray(converted, dtype=np.uint8).copy()
        finally:
            converted.close()
            frame.close()
    if array.shape[2] == 4:
        array = cv2.cvtColor(array, cv2.COLOR_RGBA2BGRA)
        if alpha_mode == "composite_white":
            alpha = array[:, :, 3:4].astype(np.float32) / 255
            array = np.rint(
                array[:, :, :3].astype(np.float32) * alpha + 255 * (1 - alpha)
            ).astype(np.uint8)
    else:
        array = cv2.cvtColor(array, cv2.COLOR_RGB2BGR)
    return (
        array,
        ImageSourceReference(
            file_id=descriptor.file_id,
            frame_number=frame_number,
        ),
    )


def _load_document_normalization_input(
    path: Path,
    *,
    frame_number: int,
    normalize_orientation: bool,
    limits: ImageProcessingLimits,
) -> _DocumentNormalizationInput:
    """Load one document frame with Local-OCR-equivalent alpha semantics."""
    cv2, np = _libraries()
    with open_verified_image(path, action="load document image for normalization") as (
        descriptor,
        image,
    ):
        prepared = _prepare_selected_frame(
            image,
            frame_number=frame_number,
            limits=limits,
            normalize_orientation=normalize_orientation,
        )
        frame = prepared.image
        try:
            rgb, alpha_composited = _document_rgb_frame(frame)
            try:
                array = np.asarray(rgb, dtype=np.uint8).copy()
            finally:
                if rgb is not frame:
                    rgb.close()
        finally:
            frame.close()
    return _DocumentNormalizationInput(
        array=cv2.cvtColor(array, cv2.COLOR_RGB2BGR),
        source=ImageSourceReference(
            file_id=descriptor.file_id,
            frame_number=frame_number,
        ),
        storage_width=prepared.storage_width,
        storage_height=prepared.storage_height,
        exif_orientation=prepared.exif_orientation,
        alpha_composited=alpha_composited,
    )


def _exif_orientation_matrix(
    orientation: int | None,
    *,
    width: int,
    height: int,
) -> tuple[tuple[float, float, float], ...]:
    """Map storage-pixel coordinates into the EXIF-normalized pixel plane."""
    matrices: dict[int, tuple[tuple[float, float, float], ...]] = {
        1: ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0)),
        2: ((-1.0, 0.0, width - 1.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0)),
        3: (
            (-1.0, 0.0, width - 1.0),
            (0.0, -1.0, height - 1.0),
            (0.0, 0.0, 1.0),
        ),
        4: ((1.0, 0.0, 0.0), (0.0, -1.0, height - 1.0), (0.0, 0.0, 1.0)),
        5: ((0.0, 1.0, 0.0), (1.0, 0.0, 0.0), (0.0, 0.0, 1.0)),
        6: ((0.0, -1.0, height - 1.0), (1.0, 0.0, 0.0), (0.0, 0.0, 1.0)),
        7: (
            (0.0, -1.0, height - 1.0),
            (-1.0, 0.0, width - 1.0),
            (0.0, 0.0, 1.0),
        ),
        8: ((0.0, 1.0, 0.0), (-1.0, 0.0, width - 1.0), (0.0, 0.0, 1.0)),
    }
    return matrices[orientation or 1]


def _to_gray(array: Any) -> Any:
    """Convert BGR or BGRA arrays to grayscale without discarding by accident."""
    cv2, _ = _libraries()
    if len(array.shape) == 2:
        return array
    if array.shape[2] == 4:
        return cv2.cvtColor(array, cv2.COLOR_BGRA2GRAY)
    return cv2.cvtColor(array, cv2.COLOR_BGR2GRAY)


def _encode_array(
    array: Any,
    *,
    source: ImageSourceReference,
    image_format: ImageFormat,
    limits: ImageProcessingLimits,
) -> EncodedImage:
    cv2, _ = _libraries()
    from PIL import Image

    if len(array.shape) == 2:
        image = Image.fromarray(array, mode="L")
    elif array.shape[2] == 4:
        image = Image.fromarray(cv2.cvtColor(array, cv2.COLOR_BGRA2RGBA), mode="RGBA")
    else:
        image = Image.fromarray(cv2.cvtColor(array, cv2.COLOR_BGR2RGB), mode="RGB")
    try:
        return encode_image(
            image,
            image_format=image_format,
            source=source,
            limits=limits,
        )
    finally:
        image.close()


def _normalized_corners(
    corners: tuple[tuple[float, float], ...],
    *,
    width: int,
    height: int,
) -> Any:
    _, np = _libraries()
    normalized = []
    for x_value, y_value in corners:
        x = x_value * (width - 1) if 0 <= x_value <= 1 else x_value
        y = y_value * (height - 1) if 0 <= y_value <= 1 else y_value
        normalized.append((x, y))
    return _validated_corners(
        np.asarray(normalized, dtype=np.float64),
        width=width,
        height=height,
    )


def _validated_corners(points: Any, *, width: int, height: int) -> Any:
    """Validate finite, in-bounds, non-degenerate perspective geometry."""
    _, np = _libraries()
    if not np.isfinite(points).all():
        msg = "Perspective corners must be finite"
        raise ImageProcessingError(msg)
    if len({(float(x), float(y)) for x, y in points}) != 4:
        msg = "Perspective corners must be distinct"
        raise ImageProcessingError(msg)
    if (
        np.any(points[:, 0] < 0)
        or np.any(points[:, 0] > width - 1)
        or np.any(points[:, 1] < 0)
        or np.any(points[:, 1] > height - 1)
    ):
        msg = "Perspective corners must be within source bounds"
        raise ImageProcessingError(msg)
    ordered = _ordered_corners(points)
    x_values = ordered[:, 0]
    y_values = ordered[:, 1]
    area = 0.5 * abs(
        float(
            np.dot(x_values, np.roll(y_values, -1))
            - np.dot(y_values, np.roll(x_values, -1))
        )
    )
    crosses = []
    for index in range(4):
        first = ordered[(index + 1) % 4] - ordered[index]
        second = ordered[(index + 2) % 4] - ordered[(index + 1) % 4]
        crosses.append(float(first[0] * second[1] - first[1] * second[0]))
    if (
        area <= 1e-6
        or any(abs(value) <= 1e-6 for value in crosses)
        or not (
            all(value > 0 for value in crosses) or all(value < 0 for value in crosses)
        )
    ):
        msg = "Perspective corners form a degenerate quadrilateral"
        raise ImageProcessingError(msg)
    return points.astype(np.float32)


def _perspective_candidate(image: Any) -> tuple[Any | None, float]:
    cv2, np = _libraries()
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150)
    contours, _ = cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    image_area = image.shape[0] * image.shape[1]
    for contour in sorted(contours, key=cv2.contourArea, reverse=True)[:20]:
        perimeter = cv2.arcLength(contour, True)
        polygon = cv2.approxPolyDP(contour, 0.02 * perimeter, True)
        if len(polygon) == 4:
            area = float(cv2.contourArea(polygon))
            confidence = min(1.0, area / image_area)
            return np.asarray(polygon[:, 0], dtype=np.float32), confidence
    return None, 0.0


def _ordered_corners(points: Any) -> Any:
    _, np = _libraries()
    center = points.mean(axis=0)
    angles = np.arctan2(points[:, 1] - center[1], points[:, 0] - center[0])
    ordered = points[np.argsort(angles)]
    top_left_index = int(np.argmin(ordered.sum(axis=1)))
    return np.roll(ordered, -top_left_index, axis=0).astype(np.float32)


def _warp_perspective(
    image: Any,
    corners: Any,
    limits: ImageProcessingLimits,
) -> tuple[Any, Any]:
    cv2, np = _libraries()
    source = _ordered_corners(
        _validated_corners(
            corners,
            width=image.shape[1],
            height=image.shape[0],
        )
    )
    top_width = np.linalg.norm(source[1] - source[0])
    bottom_width = np.linalg.norm(source[2] - source[3])
    left_height = np.linalg.norm(source[3] - source[0])
    right_height = np.linalg.norm(source[2] - source[1])
    width = max(1, round(max(top_width, bottom_width)))
    height = max(1, round(max(left_height, right_height)))
    enforce_working_dimensions(width, height, limits)
    enforce_output_dimensions(width, height, limits)
    destination = np.asarray(
        ((0, 0), (width - 1, 0), (width - 1, height - 1), (0, height - 1)),
        dtype=np.float32,
    )
    matrix = cv2.getPerspectiveTransform(source, destination)
    return cv2.warpPerspective(image, matrix, (width, height)), matrix


def _deskew(
    image: Any,
    limits: ImageProcessingLimits,
) -> tuple[Any, Any, float]:
    cv2, np = _libraries()
    gray = image if len(image.shape) == 2 else cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    points = np.column_stack(np.where(gray < 245))
    if len(points) < 20:
        return image, np.eye(3, dtype=np.float64), 0.0
    angle = float(cv2.minAreaRect(points[:, ::-1].astype(np.float32))[-1])
    if angle < -45:
        angle += 90
    center = (image.shape[1] / 2, image.shape[0] / 2)
    affine = cv2.getRotationMatrix2D(center, angle, 1.0)
    enforce_working_dimensions(image.shape[1], image.shape[0], limits)
    enforce_output_dimensions(image.shape[1], image.shape[0], limits)
    transformed = cv2.warpAffine(
        image,
        affine,
        (image.shape[1], image.shape[0]),
        borderValue=255,
    )
    matrix = np.vstack((affine, (0.0, 0.0, 1.0)))
    return transformed, matrix, angle


@sanitized_image_adapter("normalize document image")
def normalize_document_image(  # noqa: C901, PLR0912, PLR0915
    path: Path,
    options: DocumentNormalizationOptions | None = None,
    *,
    limits: ImageProcessingLimits | None = None,
) -> DocumentNormalizationResult:
    """Apply explicitly configured OpenCV scan normalization."""
    effective_options = (
        DocumentNormalizationOptions()
        if options is None
        else _validated_image_model(
            options,
            DocumentNormalizationOptions,
            "Document image normalization options are invalid",
        )
    )
    effective_limits = _validated_image_limits(limits)
    cv2, np = _libraries()
    loaded = _load_document_normalization_input(
        path,
        frame_number=effective_options.frame_number,
        normalize_orientation=effective_options.normalize_orientation,
        limits=effective_limits,
    )
    image = loaded.array
    source = loaded.source
    matrix = (
        np.asarray(
            _exif_orientation_matrix(
                loaded.exif_orientation,
                width=loaded.storage_width,
                height=loaded.storage_height,
            ),
            dtype=np.float64,
        )
        if effective_options.normalize_orientation
        else np.eye(3, dtype=np.float64)
    )
    operations: list[str] = []
    if effective_options.normalize_orientation and loaded.exif_orientation is not None:
        operations.append(f"exif_orientation_{loaded.exif_orientation}")
    if loaded.alpha_composited:
        operations.append("alpha_composite_white")
    warnings: list[str] = []
    confidence: float | None = None
    corners = None
    if effective_options.perspective_corners is not None:
        corners = _normalized_corners(
            effective_options.perspective_corners,
            width=image.shape[1],
            height=image.shape[0],
        )
        confidence = 1.0
    elif effective_options.auto_perspective:
        corners, confidence = _perspective_candidate(image)
        if confidence < effective_options.minimum_corner_confidence:
            corners = None
            warnings.append("Perspective candidate confidence was below threshold.")
    if corners is not None:
        image, perspective = _warp_perspective(
            image,
            corners,
            effective_limits,
        )
        matrix = perspective @ matrix
        operations.append("perspective")
    if effective_options.deskew:
        image, rotation, angle = _deskew(image, effective_limits)
        matrix = rotation @ matrix
        if angle:
            operations.append("deskew")
    if effective_options.grayscale and len(image.shape) == 3:
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        operations.append("grayscale")
    if effective_options.normalize_background:
        background = cv2.morphologyEx(
            image,
            cv2.MORPH_CLOSE,
            np.ones((15, 15), np.uint8),
        )
        image = cv2.divide(image, background, scale=255)
        operations.append("background_normalization")
    if effective_options.denoise_strength:
        image = cv2.fastNlMeansDenoising(
            image,
            None,
            effective_options.denoise_strength,
            7,
            21,
        )
        operations.append("denoise")
    if effective_options.threshold == "global":
        _, image = cv2.threshold(
            image,
            effective_options.global_threshold,
            255,
            cv2.THRESH_BINARY,
        )
        operations.append("global_threshold")
    elif effective_options.threshold == "adaptive":
        image = cv2.adaptiveThreshold(
            image,
            255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY,
            31,
            11,
        )
        operations.append("adaptive_threshold")
    if effective_options.remove_small_noise:
        image = cv2.morphologyEx(
            image,
            cv2.MORPH_OPEN,
            np.ones((2, 2), np.uint8),
        )
        operations.append("small_noise_removal")
    if effective_options.enhance_lines:
        image = cv2.morphologyEx(
            image,
            cv2.MORPH_CLOSE,
            np.ones((1, 3), np.uint8),
        )
        operations.append("line_enhancement")
    if effective_options.crop_blank_margins:
        gray = (
            image if len(image.shape) == 2 else cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        )
        points = cv2.findNonZero((gray < 250).astype(np.uint8))
        if points is not None:
            x, y, width, height = cv2.boundingRect(points)
            image = image[y : y + height, x : x + width]
            translation = np.asarray(
                ((1.0, 0.0, -x), (0.0, 1.0, -y), (0.0, 0.0, 1.0)),
                dtype=np.float64,
            )
            matrix = translation @ matrix
            operations.append("blank_margin_crop")
    if image.shape[0] * image.shape[1] > effective_limits.max_working_pixels:
        from document_sdk.core import ImageLimitExceededError

        raise ImageLimitExceededError(
            limit_name="working pixels",
            observed=image.shape[0] * image.shape[1],
            maximum=effective_limits.max_working_pixels,
        )
    encoded = _encode_array(
        image,
        source=source,
        image_format=effective_options.output_format,
        limits=effective_limits,
    )
    return DocumentNormalizationResult(
        image=encoded,
        transformation_matrix=cast(
            "tuple[tuple[float, float, float], ...]",
            tuple(tuple(float(value) for value in row) for row in matrix),
        ),
        applied_operations=tuple(operations),
        perspective_confidence=confidence,
        warnings=tuple(warnings),
    )


def _feature_alignment(
    reference: Any,
    candidate: Any,
    options: ImageAlignmentOptions,
    limits: ImageProcessingLimits,
    *,
    white_border: bool = False,
) -> tuple[Any, ImageAlignmentEvidence]:
    cv2, np = _libraries()
    reference_gray = _to_gray(reference)
    candidate_gray = _to_gray(candidate)
    if white_border:
        border_value: int | tuple[int, ...] = tuple(
            255 for _ in range(candidate.shape[2])
        )
    elif len(candidate.shape) == 3:
        border_value = tuple(0 for _ in range(candidate.shape[2]))
    else:
        border_value = 0
    if options.mode == "translation":
        shift, response = cv2.phaseCorrelate(
            reference_gray.astype(np.float32),
            candidate_gray.astype(np.float32),
        )
        matrix = np.asarray(
            ((1.0, 0.0, -shift[0]), (0.0, 1.0, -shift[1])),
            dtype=np.float64,
        )
        enforce_working_dimensions(reference.shape[1], reference.shape[0], limits)
        enforce_output_dimensions(reference.shape[1], reference.shape[0], limits)
        aligned = cv2.warpAffine(
            candidate,
            matrix,
            (reference.shape[1], reference.shape[0]),
            borderValue=border_value,
        )
        evidence = ImageAlignmentEvidence(
            mode=options.mode,
            transformation_matrix=tuple(
                tuple(float(value) for value in row) for row in matrix
            ),
            matched_feature_count=0,
            inlier_count=0,
            inlier_ratio=0,
            alignment_score=max(0.0, float(response)),
        )
        return aligned, evidence
    detector = cv2.ORB_create(nfeatures=options.max_features)
    reference_keypoints, reference_descriptors = detector.detectAndCompute(
        reference_gray,
        None,
    )
    candidate_keypoints, candidate_descriptors = detector.detectAndCompute(
        candidate_gray,
        None,
    )
    if reference_descriptors is None or candidate_descriptors is None:
        msg = "Insufficient features for image alignment"
        raise ImageAlignmentError(msg)
    matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    matches = sorted(
        matcher.match(candidate_descriptors, reference_descriptors),
        key=lambda match: (match.distance, match.queryIdx, match.trainIdx),
    )
    if len(matches) < options.minimum_matches:
        msg = "Insufficient feature matches for image alignment"
        raise ImageAlignmentError(msg)
    candidate_points = np.float32(
        [candidate_keypoints[match.queryIdx].pt for match in matches]
    )
    reference_points = np.float32(
        [reference_keypoints[match.trainIdx].pt for match in matches]
    )
    if options.mode == "affine":
        matrix, mask = cv2.estimateAffinePartial2D(
            candidate_points,
            reference_points,
            method=cv2.RANSAC,
            ransacReprojThreshold=options.ransac_threshold,
        )
        if matrix is None or mask is None:
            msg = "Affine alignment could not be estimated"
            raise ImageAlignmentError(msg)
        enforce_working_dimensions(reference.shape[1], reference.shape[0], limits)
        enforce_output_dimensions(reference.shape[1], reference.shape[0], limits)
        aligned = cv2.warpAffine(
            candidate,
            matrix,
            (reference.shape[1], reference.shape[0]),
            borderValue=border_value,
        )
    else:
        matrix, mask = cv2.findHomography(
            candidate_points,
            reference_points,
            cv2.RANSAC,
            options.ransac_threshold,
        )
        if matrix is None or mask is None:
            msg = "Homography alignment could not be estimated"
            raise ImageAlignmentError(msg)
        enforce_working_dimensions(reference.shape[1], reference.shape[0], limits)
        enforce_output_dimensions(reference.shape[1], reference.shape[0], limits)
        aligned = cv2.warpPerspective(
            candidate,
            matrix,
            (reference.shape[1], reference.shape[0]),
            borderValue=border_value,
        )
    inliers = int(mask.ravel().sum())
    ratio = inliers / len(matches)
    evidence = ImageAlignmentEvidence(
        mode=options.mode,
        transformation_matrix=tuple(
            tuple(float(value) for value in row) for row in matrix
        ),
        matched_feature_count=len(matches),
        inlier_count=inliers,
        inlier_ratio=ratio,
        alignment_score=ratio,
    )
    return aligned, evidence


@sanitized_image_adapter("align images")
def align_images(
    reference_path: Path,
    candidate_path: Path,
    options: ImageAlignmentOptions | None = None,
    *,
    limits: ImageProcessingLimits | None = None,
) -> ImageAlignmentResult:
    """Align deterministically without promising cross-version bit identity."""
    effective_options = (
        ImageAlignmentOptions()
        if options is None
        else _validated_image_model(
            options,
            ImageAlignmentOptions,
            "Image alignment options are invalid",
        )
    )
    effective_limits = _validated_image_limits(limits)
    reference, reference_source = _load_array(
        reference_path,
        frame_number=1,
        limits=effective_limits,
    )
    candidate, candidate_source = _load_array(
        candidate_path,
        frame_number=1,
        limits=effective_limits,
    )
    aligned, evidence = _feature_alignment(
        reference,
        candidate,
        effective_options,
        effective_limits,
    )
    encoded = (
        _encode_array(
            aligned,
            source=candidate_source,
            image_format=effective_options.output_format,
            limits=effective_limits,
        )
        if effective_options.include_aligned_image
        else None
    )
    return ImageAlignmentResult(
        reference=reference_source,
        candidate=candidate_source,
        evidence=evidence,
        output_width=reference.shape[1],
        output_height=reference.shape[0],
        aligned_image=encoded,
    )


def load_alignment_arrays(
    reference_path: Path,
    candidate_path: Path,
    options: ImageAlignmentOptions | None,
    limits: ImageProcessingLimits,
    *,
    alpha_mode: Literal["compare", "ignore", "composite_white"] = "ignore",
) -> tuple[
    Any,
    Any,
    ImageSourceReference,
    ImageSourceReference,
    ImageAlignmentEvidence | None,
]:
    """Load and optionally align arrays for difference extraction."""
    reference, reference_source = _load_array(
        reference_path,
        frame_number=1,
        limits=limits,
        alpha_mode=alpha_mode,
    )
    candidate, candidate_source = _load_array(
        candidate_path,
        frame_number=1,
        limits=limits,
        alpha_mode=alpha_mode,
    )
    evidence = None
    if options is not None:
        candidate, evidence = _feature_alignment(
            reference,
            candidate,
            options,
            limits,
            white_border=alpha_mode == "composite_white",
        )
    elif reference.shape != candidate.shape:
        msg = "Image dimensions differ and no alignment was requested"
        raise ImageAlignmentError(msg)
    return reference, candidate, reference_source, candidate_source, evidence


def encode_cv_image(
    array: Any,
    source: ImageSourceReference,
    image_format: ImageFormat,
    limits: ImageProcessingLimits,
) -> EncodedImage:
    """Expose safe internal array encoding to the comparison module."""
    return _encode_array(
        cast("Any", array),
        source=source,
        image_format=image_format,
        limits=limits,
    )

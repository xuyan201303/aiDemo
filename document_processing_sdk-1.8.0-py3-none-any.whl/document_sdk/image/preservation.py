"""Conservative image metadata and frame-preservation analysis."""

from __future__ import annotations

from typing import TYPE_CHECKING

from document_sdk.core import ImageProcessingLimits  # noqa: TC001 - public annotation.
from document_sdk.image._io import (
    _validated_image_limits,
    _validated_image_model,
    has_alpha,
    open_verified_image,
    pillow_format,
)
from document_sdk.image.models import (
    ImagePreservationItem,
    ImagePreservationReport,
    ImageTransformRequest,
    PreservationStatus,
)

if TYPE_CHECKING:
    from pathlib import Path

_STATUS_RANK: dict[PreservationStatus, int] = {
    "SAFE": 0,
    "SAFE_WITH_WARNINGS": 1,
    "UNSUPPORTED": 2,
}
_TIFF_COMPRESSION_TAG = 259
_COMPRESSION_INFO_KEYS = frozenset(
    {
        "compression",
        "compress_level",
        "progressive",
        "progression",
        "quality",
    }
)
_EXPLICIT_INFO_KEYS = frozenset(
    {
        "dpi",
        "exif",
        "icc_profile",
        "transparency",
        "xmp",
        "XML:com.adobe.xmp",
    }
)
_ANIMATION_INFO_KEYS = frozenset({"duration", "loop"})
_EXPLICIT_TEXT_KEYS = frozenset({"xmp", "XML:com.adobe.xmp"})


def _status_for_metadata(
    *,
    present: bool,
    same_format: bool,
    requested: bool,
) -> PreservationStatus:
    if not present:
        return "SAFE"
    if not requested or not same_format:
        return "UNSUPPORTED"
    return "SAFE_WITH_WARNINGS"


def _frame_count(image: object, maximum: int) -> int:
    count = 0
    for index in range(maximum + 1):
        try:
            image.seek(index)  # type: ignore[attr-defined]
        except EOFError:
            return count
        count += 1
        if count > maximum:
            from document_sdk.core import ImageLimitExceededError

            raise ImageLimitExceededError(
                limit_name="frame count",
                observed=count,
                maximum=maximum,
            )
    return count


def _has_compression_metadata(image: object, info: dict[str, object]) -> bool:
    """Return true only for compression evidence exposed by the decoder."""
    if any(key in info for key in _COMPRESSION_INFO_KEYS):
        return True
    tags = getattr(image, "tag_v2", None)
    return tags is not None and _TIFF_COMPRESSION_TAG in tags


def _has_unhandled_metadata(
    image: object,
    info: dict[str, object],
    *,
    animation_present: bool,
) -> bool:
    """Detect embedded metadata categories without inspecting their values."""
    handled_keys = _EXPLICIT_INFO_KEYS | _COMPRESSION_INFO_KEYS
    if animation_present:
        handled_keys |= _ANIMATION_INFO_KEYS
    observed_keys: set[object] = set(info)
    text_metadata = getattr(image, "text", None)
    if isinstance(text_metadata, dict):
        if any(key not in _EXPLICIT_TEXT_KEYS for key in text_metadata):
            return True
        observed_keys.update(text_metadata)
    return any(key not in handled_keys for key in observed_keys)


def assess_image_preservation(
    path: Path,
    request: ImageTransformRequest,
    *,
    limits: ImageProcessingLimits | None = None,
) -> ImagePreservationReport:
    """Assess evidence and risks for one explicit transform request."""
    effective_request = _validated_image_model(
        request,
        ImageTransformRequest,
        "Image transform request is invalid",
    )
    effective_limits = _validated_image_limits(limits)
    with open_verified_image(path, action="assess image preservation") as (
        descriptor,
        image,
    ):
        source_format = pillow_format(image.format)
        frame_count = _frame_count(image, effective_limits.max_frames)
        image.seek(0)
        exif = image.getexif()
        info = image.info
        alpha_present = has_alpha(image)
        compression_metadata_present = _has_compression_metadata(image, info)
        animation_present = frame_count > 1 and source_format in {"WEBP", "PNG"}
        unhandled_metadata_present = _has_unhandled_metadata(
            image,
            info,
            animation_present=animation_present,
        )
        request = effective_request
        lossy_reencoding = request.output_format in {"JPEG", "WEBP"}
        same_format = source_format == request.output_format
        preserving_frames = frame_count == 1 or (
            request.preserve_all_frames and request.output_format == "TIFF"
        )
        feature_facts = (
            ("pixel_content", True, "SAFE", "Explicit deterministic transform."),
            (
                "frame_count_order",
                frame_count > 1,
                "SAFE" if preserving_frames else "UNSUPPORTED",
                "All frames are preserved only by an explicit TIFF request.",
            ),
            (
                "exif",
                bool(exif),
                _status_for_metadata(
                    present=bool(exif),
                    same_format=same_format,
                    requested=request.preserve_metadata,
                ),
                "EXIF retention is backend-supported but not byte-for-byte guaranteed.",
            ),
            (
                "exif_orientation",
                exif.get(274) is not None,
                "SAFE"
                if request.normalize_orientation
                else _status_for_metadata(
                    present=exif.get(274) is not None,
                    same_format=same_format,
                    requested=request.preserve_metadata,
                ),
                "Normalization removes orientation dependence from pixels.",
            ),
            (
                "icc_profile",
                bool(info.get("icc_profile")),
                _status_for_metadata(
                    present=bool(info.get("icc_profile")),
                    same_format=same_format,
                    requested=request.preserve_icc_profile,
                ),
                "ICC retention depends on target encoder support.",
            ),
            (
                "dpi",
                bool(info.get("dpi")),
                _status_for_metadata(
                    present=bool(info.get("dpi")),
                    same_format=same_format,
                    requested=request.preserve_dpi or request.dpi is not None,
                ),
                "DPI is preserved or explicitly replaced where supported.",
            ),
            (
                "xmp",
                bool(info.get("xmp") or info.get("XML:com.adobe.xmp")),
                "UNSUPPORTED"
                if info.get("xmp") or info.get("XML:com.adobe.xmp")
                else "SAFE",
                "XMP is not claimed as preserved.",
            ),
            (
                "alpha_transparency",
                alpha_present,
                "UNSUPPORTED"
                if alpha_present
                and request.output_format == "JPEG"
                and request.background_rgb is None
                else ("SAFE_WITH_WARNINGS" if alpha_present else "SAFE"),
                "Alpha requires an alpha-capable target or explicit compositing.",
            ),
            (
                "palette",
                image.mode == "P",
                "SAFE_WITH_WARNINGS"
                if image.mode == "P" and same_format
                else ("UNSUPPORTED" if image.mode == "P" else "SAFE"),
                "Palette indices may be expanded or re-encoded.",
            ),
            (
                "color_mode",
                True,
                "SAFE"
                if request.output_mode in {None, image.mode}
                else "SAFE_WITH_WARNINGS",
                "Requested color conversion is explicit.",
            ),
            (
                "tiff_tags",
                source_format == "TIFF",
                "SAFE_WITH_WARNINGS"
                if source_format == request.output_format == "TIFF"
                else ("UNSUPPORTED" if source_format == "TIFF" else "SAFE"),
                "Private TIFF tags are not guaranteed byte-for-byte.",
            ),
            (
                "animation_timing",
                animation_present,
                "UNSUPPORTED" if animation_present else "SAFE",
                "Animation timing semantics are outside current transforms.",
            ),
            (
                "compression_metadata",
                compression_metadata_present,
                (
                    "SAFE_WITH_WARNINGS"
                    if compression_metadata_present and same_format
                    else ("UNSUPPORTED" if compression_metadata_present else "SAFE")
                ),
                (
                    "Present encoder metadata may be regenerated; absent or "
                    "unknown metadata is not claimed as preserved."
                ),
            ),
            (
                "unhandled_metadata",
                unhandled_metadata_present,
                "UNSUPPORTED" if unhandled_metadata_present else "SAFE",
                (
                    "Unhandled embedded metadata is not copied to the output; "
                    "metadata values are never reported."
                ),
            ),
            (
                "lossy_reencoding",
                lossy_reencoding,
                "SAFE_WITH_WARNINGS" if lossy_reencoding else "SAFE",
                (
                    "The selected target encoder can introduce additional lossy "
                    "compression, so pixel preservation is not claimed."
                ),
            ),
        )
        items = tuple(
            ImagePreservationItem(
                feature=name,
                present=present,
                status=status,  # type: ignore[arg-type]
                details=details,
            )
            for name, present, status, details in feature_facts
        )
        overall = max(items, key=lambda item: _STATUS_RANK[item.status]).status
        warnings = tuple(
            f"{item.feature}: {item.details}"
            for item in items
            if item.present and item.status != "SAFE"
        )
        return ImagePreservationReport(
            source=descriptor,
            target_format=request.output_format,
            overall_status=overall,
            items=items,
            warnings=warnings,
        )

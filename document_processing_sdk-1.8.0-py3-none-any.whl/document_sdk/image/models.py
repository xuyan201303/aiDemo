"""Strict public models for deterministic local image processing."""

from __future__ import annotations

import math
from typing import Literal

from pydantic import ConfigDict, Field, model_validator

from document_sdk.core import (
    BoundingBox,  # noqa: TC001 - Pydantic resolves runtime annotations.
    FileDescriptor,  # noqa: TC001 - Pydantic resolves runtime annotations.
    ImageSourceReference,  # noqa: TC001 - Pydantic resolves runtime annotations.
)
from document_sdk.core.models import SdkModel

type ImageFormat = Literal["PNG", "JPEG", "TIFF", "BMP", "WEBP"]
type ImageMimeType = Literal[
    "image/png",
    "image/jpeg",
    "image/tiff",
    "image/bmp",
    "image/webp",
]
type ImageColorMode = Literal["RGB", "RGBA", "CMYK", "L", "1"]
type PreservationStatus = Literal["SAFE", "SAFE_WITH_WARNINGS", "UNSUPPORTED"]
type AlignmentMode = Literal["translation", "affine", "homography"]

_MAX_COLOR_COMPONENT = 255
_HASH_DISTANCE_BITS = 64


class _ImageModel(SdkModel):
    """Image model base with safe base64 JSON serialization for bytes."""

    model_config = SdkModel.model_config | ConfigDict(
        ser_json_bytes="base64",
        val_json_bytes="base64",
    )


class EncodedImage(_ImageModel):
    """Backend-neutral encoded image bytes and source traceability."""

    data: bytes = Field(min_length=1)
    format: ImageFormat
    mime_type: ImageMimeType
    width: int = Field(gt=0)
    height: int = Field(gt=0)
    mode: str = Field(min_length=1)
    source: ImageSourceReference


class ImageTransformRequest(_ImageModel):
    """Explicit deterministic operations applied in declaration order."""

    frame_number: int | None = Field(default=None, ge=1)
    preserve_all_frames: bool = False
    normalize_orientation: bool = False
    rotation_degrees: float = Field(default=0, ge=-360, le=360)
    flip_horizontal: bool = False
    flip_vertical: bool = False
    crop: BoundingBox | None = None
    resize_width: int | None = Field(default=None, gt=0)
    resize_height: int | None = Field(default=None, gt=0)
    preserve_aspect_ratio: bool = True
    output_mode: ImageColorMode | None = None
    background_rgb: tuple[int, int, int] | None = None
    output_format: ImageFormat
    quality: int = Field(default=90, ge=1, le=100)
    tiff_compression: Literal["raw", "tiff_lzw", "tiff_adobe_deflate"] = "tiff_lzw"
    preserve_dpi: bool = True
    dpi: tuple[float, float] | None = None
    preserve_icc_profile: bool = True
    preserve_metadata: bool = False
    strict_preservation: bool = False

    @model_validator(mode="after")
    def validate_frame_selection(self) -> ImageTransformRequest:
        """Validate mutually exclusive selection and numeric transform options."""
        if self.frame_number is not None and self.preserve_all_frames:
            msg = "frame_number and preserve_all_frames are mutually exclusive"
            raise ValueError(msg)
        if self.background_rgb is not None and any(
            component < 0 or component > _MAX_COLOR_COMPONENT
            for component in self.background_rgb
        ):
            msg = "background_rgb components must be between 0 and 255"
            raise ValueError(msg)
        if self.dpi is not None and any(
            not math.isfinite(value) or value <= 0 for value in self.dpi
        ):
            msg = "dpi values must be positive"
            raise ValueError(msg)
        return self


class ImagePreservationItem(_ImageModel):
    """Evidence-based preservation status for one feature."""

    feature: str = Field(min_length=1)
    present: bool
    status: PreservationStatus
    details: str = Field(min_length=1)


class ImagePreservationReport(_ImageModel):
    """Conservative preservation assessment for a requested transformation."""

    source: FileDescriptor
    target_format: ImageFormat
    overall_status: PreservationStatus
    items: tuple[ImagePreservationItem, ...]
    warnings: tuple[str, ...] = ()


class ImageTransformResult(_ImageModel):
    """Verified atomic transform output."""

    source: FileDescriptor
    output: FileDescriptor
    frame_count: int = Field(ge=1)
    preservation: ImagePreservationReport
    warnings: tuple[str, ...] = ()


class ImageQualityOptions(_ImageModel):
    """Deterministic thresholds for objective quality evidence."""

    frame_number: int = Field(default=1, ge=1)
    near_black_level: int = Field(default=5, ge=0, le=255)
    near_white_level: int = Field(default=250, ge=0, le=255)
    blank_level: int = Field(default=245, ge=0, le=255)
    minimum_effective_dpi: float = Field(default=150, gt=0)
    advanced: bool = False


class ImageQualityReport(_ImageModel):
    """Objective Pillow metrics plus optional OpenCV evidence."""

    source: ImageSourceReference
    width: int = Field(gt=0)
    height: int = Field(gt=0)
    brightness: float = Field(ge=0, le=255)
    contrast: float = Field(ge=0)
    black_clipping_ratio: float = Field(ge=0, le=1)
    white_clipping_ratio: float = Field(ge=0, le=1)
    near_blank_ratio: float = Field(ge=0, le=1)
    entropy: float = Field(ge=0)
    effective_dpi: tuple[float, float] | None = None
    alpha_coverage: float = Field(ge=0, le=1)
    blur_score: float | None = Field(default=None, ge=0)
    edge_density: float | None = Field(default=None, ge=0, le=1)
    estimated_noise: float | None = Field(default=None, ge=0)
    skew_angle_candidate: float | None = None
    skew_confidence: float | None = Field(default=None, ge=0, le=1)
    background_uniformity: float | None = Field(default=None, ge=0, le=1)
    warnings: tuple[str, ...] = ()


class DocumentNormalizationOptions(_ImageModel):
    """Explicit OpenCV document-scan normalization operations."""

    frame_number: int = Field(default=1, ge=1)
    normalize_orientation: bool = True
    grayscale: bool = True
    deskew: bool = False
    perspective_corners: (
        tuple[
            tuple[float, float],
            tuple[float, float],
            tuple[float, float],
            tuple[float, float],
        ]
        | None
    ) = None
    auto_perspective: bool = False
    minimum_corner_confidence: float = Field(default=0.8, ge=0, le=1)
    threshold: Literal["none", "global", "adaptive"] = "none"
    global_threshold: int = Field(default=127, ge=0, le=255)
    normalize_background: bool = False
    denoise_strength: int = Field(default=0, ge=0, le=20)
    remove_small_noise: bool = False
    crop_blank_margins: bool = False
    enhance_lines: bool = False
    output_format: ImageFormat = "PNG"

    @model_validator(mode="after")
    def validate_threshold_mode(self) -> DocumentNormalizationOptions:
        """Thresholding requires the explicitly enabled grayscale operation."""
        if self.threshold != "none" and not self.grayscale:
            msg = "threshold operations require grayscale=True"
            raise ValueError(msg)
        return self


class DocumentNormalizationResult(_ImageModel):
    """Normalized scan and applied geometric evidence."""

    image: EncodedImage
    transformation_matrix: tuple[tuple[float, float, float], ...]
    applied_operations: tuple[str, ...]
    perspective_confidence: float | None = Field(default=None, ge=0, le=1)
    warnings: tuple[str, ...] = ()


class ImageAlignmentOptions(_ImageModel):
    """Bounded deterministic alignment configuration."""

    mode: AlignmentMode = "translation"
    max_features: int = Field(default=1_000, gt=0, le=10_000)
    minimum_matches: int = Field(default=8, gt=0)
    ransac_threshold: float = Field(default=3, gt=0)
    include_aligned_image: bool = True
    output_format: ImageFormat = "PNG"

    @model_validator(mode="after")
    def validate_match_budget(self) -> ImageAlignmentOptions:
        """Keep the requested match minimum within the feature budget."""
        if self.minimum_matches > self.max_features:
            msg = "minimum_matches must not exceed max_features"
            raise ValueError(msg)
        return self


class ImageAlignmentEvidence(_ImageModel):
    """Serializable alignment evidence shared with comparison results."""

    mode: AlignmentMode
    transformation_matrix: tuple[tuple[float, ...], ...]
    matched_feature_count: int = Field(ge=0)
    inlier_count: int = Field(ge=0)
    inlier_ratio: float = Field(ge=0, le=1)
    alignment_score: float = Field(ge=0)


class ImageAlignmentResult(_ImageModel):
    """Deterministic geometric alignment result."""

    reference: ImageSourceReference
    candidate: ImageSourceReference
    evidence: ImageAlignmentEvidence
    output_width: int = Field(gt=0)
    output_height: int = Field(gt=0)
    aligned_image: EncodedImage | None = None
    warnings: tuple[str, ...] = ()


class ImageComparisonOptions(_ImageModel):
    """Pixel-difference extraction configuration."""

    align: ImageAlignmentOptions | None = None
    color_mode: Literal["grayscale", "color"] = "grayscale"
    pixel_threshold: int = Field(default=16, ge=0, le=255)
    morphology_size: int = Field(default=0, ge=0, le=31)
    minimum_region_area: int = Field(default=1, gt=0)
    max_difference_regions: int = Field(default=100, gt=0)
    ignored_border: int = Field(default=0, ge=0)
    alpha_mode: Literal["compare", "ignore", "composite_white"] = "compare"
    visualization: Literal["mask", "overlay", "red_blue"] = "overlay"


class ImageDifferenceRegion(_ImageModel):
    """One bounded connected visual-difference region."""

    bounding_box: BoundingBox
    pixel_area: int = Field(gt=0)


class ImageComparisonResult(_ImageModel):
    """Objective visual differences without business classification."""

    reference: ImageSourceReference
    candidate: ImageSourceReference
    width: int = Field(gt=0)
    height: int = Field(gt=0)
    changed_pixel_count: int = Field(ge=0)
    changed_pixel_ratio: float = Field(ge=0, le=1)
    difference_regions: tuple[ImageDifferenceRegion, ...]
    difference_mask: EncodedImage
    visualization: EncodedImage
    alignment: ImageAlignmentEvidence | None = None
    warnings: tuple[str, ...] = ()


class ImageSimilarityOptions(_ImageModel):
    """Explicit similarity methods and optional caller threshold."""

    frame_number: int = Field(default=1, ge=1)
    threshold_method: (
        Literal[
            "average_hash",
            "difference_hash",
            "perceptual_hash",
            "histogram",
        ]
        | None
    ) = None
    threshold: float | None = Field(default=None, ge=0)
    include_histogram: bool = True
    include_perceptual_hash: bool = False

    @model_validator(mode="after")
    def validate_threshold_configuration(self) -> ImageSimilarityOptions:
        """Reject incomplete, disabled, or out-of-range threshold requests."""
        if (self.threshold_method is None) != (self.threshold is None):
            msg = "threshold_method and threshold must be provided together"
            raise ValueError(msg)
        if self.threshold_method == "perceptual_hash" and not (
            self.include_perceptual_hash
        ):
            msg = "perceptual_hash threshold requires include_perceptual_hash=True"
            raise ValueError(msg)
        if self.threshold_method == "histogram" and not self.include_histogram:
            msg = "histogram threshold requires include_histogram=True"
            raise ValueError(msg)
        if self.threshold is not None:
            if self.threshold_method == "histogram" and self.threshold > 1:
                msg = "histogram threshold must be between 0 and 1"
                raise ValueError(msg)
            if (
                self.threshold_method
                in {"average_hash", "difference_hash", "perceptual_hash"}
                and self.threshold > _HASH_DISTANCE_BITS
            ):
                msg = "hash threshold must be between 0 and 64"
                raise ValueError(msg)
        return self


class ImageSimilarityResult(_ImageModel):
    """Multiple clearly labeled duplicate/similarity evidence methods."""

    reference: ImageSourceReference
    candidate: ImageSourceReference
    exact_file_sha_equal: bool
    exact_decoded_pixels_equal: bool
    normalized_pixels_equal: bool
    average_hash_reference: str
    average_hash_candidate: str
    average_hash_distance: int = Field(ge=0)
    difference_hash_reference: str
    difference_hash_candidate: str
    difference_hash_distance: int = Field(ge=0)
    perceptual_hash_reference: str | None = None
    perceptual_hash_candidate: str | None = None
    perceptual_hash_distance: int | None = Field(default=None, ge=0)
    histogram_similarity: float | None = Field(default=None, ge=-1, le=1)
    threshold_method: str | None = None
    threshold: float | None = None
    threshold_met: bool | None = None
    warnings: tuple[str, ...] = ()

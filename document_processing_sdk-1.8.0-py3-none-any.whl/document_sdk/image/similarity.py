"""Deterministic exact and perceptual image similarity evidence."""

from __future__ import annotations

import math
from typing import TYPE_CHECKING

from document_sdk.core import ImageProcessingLimits  # noqa: TC001 - public annotation.
from document_sdk.image._dependencies import require_image_opencv_support
from document_sdk.image._io import (
    _validated_image_limits,
    _validated_image_model,
    open_verified_image,
    selected_frame,
)
from document_sdk.image.models import ImageSimilarityOptions, ImageSimilarityResult

if TYPE_CHECKING:
    from pathlib import Path

    from PIL.Image import Image as PillowImage

    from document_sdk.core import ImageSourceReference


def _bits_to_hex(bits: list[bool]) -> str:
    value = 0
    for bit in bits:
        value = (value << 1) | int(bit)
    return f"{value:0{len(bits) // 4}x}"


def _average_hash(image: PillowImage) -> str:
    from PIL import Image

    converted = image.convert("L")
    try:
        small = converted.resize((8, 8), Image.Resampling.LANCZOS)
    finally:
        converted.close()
    try:
        values = list(small.tobytes())
    finally:
        small.close()
    mean = sum(values) / len(values)
    return _bits_to_hex([value >= mean for value in values])


def _difference_hash(image: PillowImage) -> str:
    from PIL import Image

    converted = image.convert("L")
    try:
        small = converted.resize((9, 8), Image.Resampling.LANCZOS)
    finally:
        converted.close()
    try:
        values = list(small.tobytes())
    finally:
        small.close()
    bits = [
        values[row * 9 + column] > values[row * 9 + column + 1]
        for row in range(8)
        for column in range(8)
    ]
    return _bits_to_hex(bits)


def _hamming(first: str, second: str) -> int:
    return (int(first, 16) ^ int(second, 16)).bit_count()


def _normalized_bytes(image: PillowImage) -> bytes:
    from PIL import Image

    converted = image.convert("RGB")
    try:
        normalized = converted.resize((64, 64), Image.Resampling.LANCZOS)
    finally:
        converted.close()
    try:
        return normalized.tobytes()
    finally:
        normalized.close()


def _histogram_similarity(first: PillowImage, second: PillowImage) -> float:
    first_rgb = first.convert("RGB")
    second_rgb = second.convert("RGB")
    try:
        first_histogram = first_rgb.histogram()
        second_histogram = second_rgb.histogram()
    finally:
        first_rgb.close()
        second_rgb.close()
    numerator = sum(
        a * b for a, b in zip(first_histogram, second_histogram, strict=True)
    )
    first_norm = math.sqrt(sum(value * value for value in first_histogram))
    second_norm = math.sqrt(sum(value * value for value in second_histogram))
    if not numerator:
        return 0.0
    return min(1.0, float(numerator / (first_norm * second_norm)))


def _perceptual_hash(image: PillowImage) -> str:
    require_image_opencv_support()
    import cv2
    import numpy as np

    converted = image.convert("L")
    try:
        resized = converted.resize((32, 32))
    finally:
        converted.close()
    try:
        gray = np.asarray(resized, dtype=np.float32).copy()
    finally:
        resized.close()
    dct = cv2.dct(gray)[:8, :8]
    median = float(np.median(dct[1:]))
    return _bits_to_hex([float(value) >= median for value in dct.flat])


def _threshold_result(
    options: ImageSimilarityOptions,
    *,
    average_distance: int,
    difference_distance: int,
    perceptual_distance: int | None,
    histogram: float | None,
) -> bool | None:
    if options.threshold_method is None or options.threshold is None:
        return None
    values = {
        "average_hash": float(average_distance),
        "difference_hash": float(difference_distance),
        "perceptual_hash": (
            float(perceptual_distance) if perceptual_distance is not None else None
        ),
        "histogram": histogram,
    }
    value = values[options.threshold_method]
    if value is None:
        return None
    if options.threshold_method == "histogram":
        return value >= options.threshold
    return value <= options.threshold


def compare_image_similarity(
    reference_path: Path,
    candidate_path: Path,
    options: ImageSimilarityOptions | None = None,
    *,
    limits: ImageProcessingLimits | None = None,
) -> ImageSimilarityResult:
    """Return labeled exact, hash, and optional histogram evidence."""
    effective_options = (
        ImageSimilarityOptions()
        if options is None
        else _validated_image_model(
            options,
            ImageSimilarityOptions,
            "Image similarity options are invalid",
        )
    )
    effective_limits = _validated_image_limits(limits)
    with (
        open_verified_image(reference_path, action="compare image similarity") as (
            reference_descriptor,
            reference_image,
        ),
        open_verified_image(candidate_path, action="compare image similarity") as (
            candidate_descriptor,
            candidate_image,
        ),
    ):
        reference = selected_frame(
            reference_image,
            frame_number=effective_options.frame_number,
            limits=effective_limits,
            normalize_orientation=True,
        )
        candidate = selected_frame(
            candidate_image,
            frame_number=effective_options.frame_number,
            limits=effective_limits,
            normalize_orientation=True,
        )
        try:
            average_reference = _average_hash(reference)
            average_candidate = _average_hash(candidate)
            difference_reference = _difference_hash(reference)
            difference_candidate = _difference_hash(candidate)
            average_distance = _hamming(average_reference, average_candidate)
            difference_distance = _hamming(
                difference_reference,
                difference_candidate,
            )
            perceptual_reference = None
            perceptual_candidate = None
            perceptual_distance = None
            if effective_options.include_perceptual_hash:
                perceptual_reference = _perceptual_hash(reference)
                perceptual_candidate = _perceptual_hash(candidate)
                perceptual_distance = _hamming(
                    perceptual_reference,
                    perceptual_candidate,
                )
            histogram = (
                _histogram_similarity(reference, candidate)
                if effective_options.include_histogram
                else None
            )
            return ImageSimilarityResult(
                reference=reference_descriptor_to_source(
                    reference_descriptor.file_id,
                    effective_options.frame_number,
                ),
                candidate=reference_descriptor_to_source(
                    candidate_descriptor.file_id,
                    effective_options.frame_number,
                ),
                exact_file_sha_equal=(
                    reference_descriptor.fingerprint == candidate_descriptor.fingerprint
                ),
                exact_decoded_pixels_equal=(
                    reference.mode == candidate.mode
                    and reference.size == candidate.size
                    and reference.tobytes() == candidate.tobytes()
                ),
                normalized_pixels_equal=(
                    _normalized_bytes(reference) == _normalized_bytes(candidate)
                ),
                average_hash_reference=average_reference,
                average_hash_candidate=average_candidate,
                average_hash_distance=average_distance,
                difference_hash_reference=difference_reference,
                difference_hash_candidate=difference_candidate,
                difference_hash_distance=difference_distance,
                perceptual_hash_reference=perceptual_reference,
                perceptual_hash_candidate=perceptual_candidate,
                perceptual_hash_distance=perceptual_distance,
                histogram_similarity=histogram,
                threshold_method=effective_options.threshold_method,
                threshold=effective_options.threshold,
                threshold_met=_threshold_result(
                    effective_options,
                    average_distance=average_distance,
                    difference_distance=difference_distance,
                    perceptual_distance=perceptual_distance,
                    histogram=histogram,
                ),
            )
        finally:
            reference.close()
            candidate.close()


def reference_descriptor_to_source(
    file_id: str,
    frame_number: int,
) -> ImageSourceReference:
    """Build a source without importing backend types."""
    from document_sdk.core import ImageSourceReference

    return ImageSourceReference(file_id=file_id, frame_number=frame_number)

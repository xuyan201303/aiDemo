"""Bounded objective visual-difference extraction."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from document_sdk.core import (
    BoundingBox,
    ImageLimitExceededError,
    ImageProcessingError,
    ImageProcessingLimits,
)
from document_sdk.image._dependencies import require_image_opencv_support
from document_sdk.image._io import (
    _validated_image_limits,
    _validated_image_model,
    sanitized_image_adapter,
)
from document_sdk.image.models import (
    ImageComparisonOptions,
    ImageComparisonResult,
    ImageDifferenceRegion,
)
from document_sdk.image.opencv import (
    _to_gray,
    encode_cv_image,
    load_alignment_arrays,
)

if TYPE_CHECKING:
    from pathlib import Path

_RGBA_CHANNELS = 4
_OPAQUE = 255


def _difference_mask(
    reference: Any,
    candidate: Any,
    options: ImageComparisonOptions,
    cv2: Any,
    np: Any,
) -> Any:
    if options.color_mode == "grayscale":
        delta = cv2.absdiff(_to_gray(reference), _to_gray(candidate))
        if options.alpha_mode == "compare" and reference.shape[2] == _RGBA_CHANNELS:
            delta = np.maximum(
                delta,
                cv2.absdiff(reference[:, :, 3], candidate[:, :, 3]),
            )
    else:
        delta = cv2.absdiff(reference, candidate).max(axis=2)
    mask = (delta > options.pixel_threshold).astype(np.uint8) * _OPAQUE
    border = options.ignored_border
    if border:
        height, width = mask.shape
        if border * 2 >= width or border * 2 >= height:
            msg = "ignored_border cannot erase the full compared image"
            raise ImageProcessingError(msg)
        mask[:border, :] = 0
        mask[-border:, :] = 0
        mask[:, :border] = 0
        mask[:, -border:] = 0
    if options.morphology_size:
        size = options.morphology_size
        kernel = np.ones((size, size), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    return mask


def _difference_regions(
    mask: Any,
    options: ImageComparisonOptions,
    cv2: Any,
) -> tuple[ImageDifferenceRegion, ...]:
    candidates = []
    component_count, _, stats, _ = cv2.connectedComponentsWithStats(
        mask,
        connectivity=8,
    )
    for label in range(1, component_count):
        area = int(stats[label, cv2.CC_STAT_AREA])
        if area >= options.minimum_region_area:
            x = int(stats[label, cv2.CC_STAT_LEFT])
            y = int(stats[label, cv2.CC_STAT_TOP])
            region_width = int(stats[label, cv2.CC_STAT_WIDTH])
            region_height = int(stats[label, cv2.CC_STAT_HEIGHT])
            candidates.append((x, y, region_width, region_height, area))
    candidates.sort(key=lambda item: (-item[4], item[1], item[0]))
    if len(candidates) > options.max_difference_regions:
        raise ImageLimitExceededError(
            limit_name="difference regions",
            observed=len(candidates),
            maximum=options.max_difference_regions,
        )
    height, width = mask.shape
    return tuple(
        ImageDifferenceRegion(
            bounding_box=BoundingBox(
                left=x / width,
                top=y / height,
                right=(x + region_width) / width,
                bottom=(y + region_height) / height,
            ),
            pixel_area=area,
        )
        for x, y, region_width, region_height, area in candidates
    )


def _visualization(
    reference: Any,
    candidate: Any,
    mask: Any,
    options: ImageComparisonOptions,
    cv2: Any,
) -> Any:
    if options.visualization == "red_blue":
        overlay = reference.copy()
        overlay.fill(0)
        overlay[:, :, 2] = _to_gray(reference)
        overlay[:, :, 0] = _to_gray(candidate)
        if overlay.shape[2] == _RGBA_CHANNELS:
            overlay[:, :, 3] = _OPAQUE
        return overlay
    if options.visualization == "mask":
        conversion = (
            cv2.COLOR_GRAY2BGRA
            if reference.shape[2] == _RGBA_CHANNELS
            else cv2.COLOR_GRAY2BGR
        )
        return cv2.cvtColor(mask, conversion)
    overlay = reference.copy()
    highlight = (
        (0, 0, _OPAQUE, _OPAQUE)
        if reference.shape[2] == _RGBA_CHANNELS
        else (0, 0, _OPAQUE)
    )
    overlay[mask > 0] = highlight
    return overlay


@sanitized_image_adapter("compare images")
def compare_images(
    reference_path: Path,
    candidate_path: Path,
    options: ImageComparisonOptions | None = None,
    *,
    limits: ImageProcessingLimits | None = None,
) -> ImageComparisonResult:
    """Report thresholded visual differences and bounded regions."""
    effective_options = (
        ImageComparisonOptions()
        if options is None
        else _validated_image_model(
            options,
            ImageComparisonOptions,
            "Image comparison options are invalid",
        )
    )
    effective_limits = _validated_image_limits(limits)
    require_image_opencv_support()
    import cv2
    import numpy as np

    reference, candidate, reference_source, candidate_source, alignment = (
        load_alignment_arrays(
            reference_path,
            candidate_path,
            effective_options.align,
            effective_limits,
            alpha_mode=effective_options.alpha_mode,
        )
    )
    mask = _difference_mask(
        reference,
        candidate,
        effective_options,
        cv2,
        np,
    )
    regions = _difference_regions(
        mask,
        effective_options,
        cv2,
    )
    height, width = mask.shape
    overlay = _visualization(
        reference,
        candidate,
        mask,
        effective_options,
        cv2,
    )
    changed = int(np.count_nonzero(mask))
    return ImageComparisonResult(
        reference=reference_source,
        candidate=candidate_source,
        width=width,
        height=height,
        changed_pixel_count=changed,
        changed_pixel_ratio=changed / mask.size,
        difference_regions=regions,
        difference_mask=encode_cv_image(
            mask,
            reference_source,
            "PNG",
            effective_limits,
        ),
        visualization=encode_cv_image(
            overlay,
            reference_source,
            "PNG",
            effective_limits,
        ),
        alignment=alignment,
    )

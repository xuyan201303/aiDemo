"""Bounded image transformation with verified atomic output."""

from __future__ import annotations

import math
import tempfile
from typing import TYPE_CHECKING, Any, cast

from document_sdk.core import (
    ImageLimitExceededError,
    ImageProcessingError,
    ImageProcessingLimits,
)
from document_sdk.core.errors import _raise_redacted_translation, safe_file_label
from document_sdk.files import inspect_file
from document_sdk.image._io import (
    FORMAT_BY_SUFFIX,
    _CappedSeekableWriter,
    _validated_image_limits,
    _validated_image_model,
    enforce_input_dimensions,
    enforce_limit,
    enforce_output_dimensions,
    enforce_working_dimensions,
    normalized_crop_box,
    open_verified_image,
)
from document_sdk.image.errors import ImagePreservationError
from document_sdk.image.models import (
    ImagePreservationReport,
    ImageTransformRequest,
    ImageTransformResult,
)
from document_sdk.image.preservation import assess_image_preservation

if TYPE_CHECKING:
    from pathlib import Path

    from PIL.Image import Image as PillowImage


def _resize_target(
    width: int,
    height: int,
    request: ImageTransformRequest,
) -> tuple[int, int]:
    if request.resize_width is None and request.resize_height is None:
        return width, height
    requested_width = request.resize_width
    requested_height = request.resize_height
    if requested_width is None:
        requested_height = cast("int", requested_height)
        target = (round(width * requested_height / height), requested_height)
    elif requested_height is None:
        target = (requested_width, round(height * requested_width / width))
    elif request.preserve_aspect_ratio:
        scale = min(requested_width / width, requested_height / height)
        target = (max(1, round(width * scale)), max(1, round(height * scale)))
    else:
        target = (requested_width, requested_height)
    return target


def _resize(
    image: PillowImage,
    request: ImageTransformRequest,
) -> PillowImage:
    target = _resize_target(*image.size, request)
    if target == image.size:
        return image
    from PIL import Image

    resized = image.resize(target, Image.Resampling.LANCZOS)
    image.close()
    return resized


def _composite_background(
    image: PillowImage,
    background: tuple[int, int, int],
) -> PillowImage:
    from PIL import Image

    rgba = image.convert("RGBA")
    canvas = Image.new("RGB", rgba.size, background)
    alpha = rgba.getchannel("A")
    try:
        canvas.paste(rgba, mask=alpha)
    finally:
        alpha.close()
        rgba.close()
        image.close()
    return canvas


def _rotation_dimensions(
    width: int,
    height: int,
    degrees: float,
) -> tuple[int, int]:
    """Conservatively estimate Pillow's expanded arbitrary rotation geometry."""
    radians = math.radians(degrees % 180)
    cosine = abs(math.cos(radians))
    sine = abs(math.sin(radians))
    rotated_width = max(1, math.ceil(width * cosine + height * sine - 1e-9))
    rotated_height = max(1, math.ceil(width * sine + height * cosine - 1e-9))
    return rotated_width, rotated_height


def _preflight_transform_geometry(
    image: PillowImage,
    request: ImageTransformRequest,
    limits: ImageProcessingLimits,
) -> None:
    """Validate every transformed allocation before executing the pipeline."""
    width, height = image.size
    if request.normalize_orientation and image.getexif().get(274) in {5, 6, 7, 8}:
        width, height = height, width
    if request.crop is not None:
        left, top, right, bottom = normalized_crop_box(
            request.crop,
            width=width,
            height=height,
        )
        width, height = right - left, bottom - top
    if request.rotation_degrees:
        width, height = _rotation_dimensions(
            width,
            height,
            request.rotation_degrees,
        )
        enforce_working_dimensions(width, height, limits)
    width, height = _resize_target(width, height, request)
    enforce_working_dimensions(width, height, limits)
    enforce_output_dimensions(width, height, limits)


def _transform_frame(  # noqa: C901 - ordered explicit transformation pipeline.
    image: PillowImage,
    request: ImageTransformRequest,
    limits: ImageProcessingLimits,
) -> PillowImage:
    from PIL import Image, ImageOps

    _preflight_transform_geometry(image, request, limits)
    frame = image.copy()
    if request.normalize_orientation:
        oriented = ImageOps.exif_transpose(frame)
        if oriented is not frame:
            frame.close()
            frame = oriented
    if request.crop is not None:
        cropped = frame.crop(
            normalized_crop_box(
                request.crop,
                width=frame.width,
                height=frame.height,
            )
        )
        frame.close()
        frame = cropped
    if request.rotation_degrees:
        rotated = frame.rotate(
            -request.rotation_degrees,
            expand=True,
            resample=Image.Resampling.BICUBIC,
        )
        frame.close()
        frame = rotated
    if request.flip_horizontal:
        flipped = ImageOps.mirror(frame)
        frame.close()
        frame = flipped
    if request.flip_vertical:
        flipped = ImageOps.flip(frame)
        frame.close()
        frame = flipped
    frame = _resize(frame, request)
    enforce_output_dimensions(*frame.size, limits)
    if request.background_rgb is not None and frame.mode in {"RGBA", "LA", "P"}:
        frame = _composite_background(frame, request.background_rgb)
    if request.output_format == "JPEG" and frame.mode in {"RGBA", "LA", "P"}:
        frame.close()
        msg = "JPEG output with alpha requires background_rgb"
        raise ImageProcessingError(msg)
    if request.output_mode is not None and frame.mode != request.output_mode:
        converted = frame.convert(request.output_mode)
        frame.close()
        frame = converted
    elif frame.mode == "CMYK" and request.output_format not in {"JPEG", "TIFF"}:
        converted = frame.convert("RGB")
        frame.close()
        frame = converted
    if request.output_format == "JPEG" and frame.mode not in {"RGB", "L", "CMYK"}:
        converted = frame.convert("RGB")
        frame.close()
        frame = converted
    return frame


def _save_options(
    image: PillowImage,
    request: ImageTransformRequest,
) -> dict[str, object]:
    options: dict[str, object] = {}
    if request.output_format in {"JPEG", "WEBP"}:
        options["quality"] = request.quality
    if request.output_format == "TIFF":
        options["compression"] = request.tiff_compression
    if request.dpi is not None:
        options["dpi"] = request.dpi
    elif request.preserve_dpi and image.info.get("dpi"):
        options["dpi"] = image.info["dpi"]
    if request.preserve_icc_profile and image.info.get("icc_profile"):
        options["icc_profile"] = image.info["icc_profile"]
    if request.preserve_metadata:
        exif = image.getexif()
        orientation_tag = 274
        if request.normalize_orientation and orientation_tag in exif:
            del exif[orientation_tag]
        if exif:
            options["exif"] = exif.tobytes()
    return options


def _verify_output(path: Path, limits: ImageProcessingLimits) -> int:
    from PIL import Image

    with Image.open(path) as image:
        count = 0
        total_pixels = 0
        for index in range(limits.max_frames + 1):
            try:
                image.seek(index)
            except EOFError:
                break
            if index == limits.max_frames:
                raise ImageLimitExceededError(
                    limit_name="frame count",
                    observed=index + 1,
                    maximum=limits.max_frames,
                )
            width, height = image.size
            pixels = width * height
            enforce_limit(
                "pixels per frame",
                pixels,
                limits.max_pixels_per_frame,
            )
            enforce_working_dimensions(width, height, limits)
            enforce_output_dimensions(width, height, limits)
            total_pixels += pixels
            enforce_limit(
                "total pixels",
                total_pixels,
                limits.max_total_pixels,
            )
            count += 1
        for index in range(count):
            image.seek(index)
            image.load()
    return count


def _validate_output_request(
    source_path: Path,
    output_path: Path,
    request: ImageTransformRequest,
) -> None:
    if source_path.resolve() == output_path.resolve():
        msg = "Image transform output must differ from source"
        raise ImageProcessingError(msg)
    expected_format = FORMAT_BY_SUFFIX.get(output_path.suffix.lower())
    if expected_format != request.output_format:
        msg = "Image output extension does not match output_format"
        raise ImageProcessingError(msg)
    if request.preserve_all_frames and request.output_format != "TIFF":
        msg = "All-frame preservation currently requires TIFF output"
        raise ImageProcessingError(msg)


def _selected_indexes(
    image: PillowImage,
    request: ImageTransformRequest,
    limits: ImageProcessingLimits,
) -> tuple[int, ...]:
    sizes: list[tuple[int, int]] = []
    for index in range(limits.max_frames + 1):
        try:
            image.seek(index)
        except EOFError:
            break
        if index == limits.max_frames:
            raise ImageLimitExceededError(
                limit_name="frame count",
                observed=index + 1,
                maximum=limits.max_frames,
            )
        sizes.append(image.size)
    if request.preserve_all_frames:
        total_pixels = 0
        for width, height in sizes:
            enforce_input_dimensions(width, height, limits)
            total_pixels += width * height
            enforce_limit(
                "total pixels",
                total_pixels,
                limits.max_total_pixels,
            )
        return tuple(range(len(sizes)))
    if request.frame_number is not None:
        if request.frame_number > len(sizes):
            msg = "Image frame does not exist"
            raise ImageProcessingError(msg)
        enforce_input_dimensions(*sizes[request.frame_number - 1], limits)
        return (request.frame_number - 1,)
    if len(sizes) > 1:
        msg = "Multi-frame input requires frame_number or preserve_all_frames"
        raise ImageProcessingError(msg)
    enforce_input_dimensions(*sizes[0], limits)
    return (0,)


def _reject_strict_risks(report: ImagePreservationReport) -> None:
    unsupported = tuple(
        item.feature for item in report.items if item.present and item.status != "SAFE"
    )
    if unsupported:
        msg = "Strict image preservation rejected: " + ", ".join(unsupported)
        raise ImagePreservationError(msg)


def _verify_assessed_source(
    descriptor_fingerprint: object,
    preservation: ImagePreservationReport,
) -> None:
    if descriptor_fingerprint != preservation.source.fingerprint:
        msg = "Image changed after preservation assessment"
        raise ImageProcessingError(msg)


def _enforce_output_size(path: Path, limits: ImageProcessingLimits) -> None:
    output_size = path.stat().st_size
    if output_size > limits.max_output_bytes:
        from document_sdk.core import ImageLimitExceededError

        raise ImageLimitExceededError(
            limit_name="output bytes",
            observed=output_size,
            maximum=limits.max_output_bytes,
        )


def transform_image(
    path: Path,
    request: ImageTransformRequest,
    output_path: Path,
    *,
    limits: ImageProcessingLimits | None = None,
) -> ImageTransformResult:
    """Transform an image into a verified same-directory atomic output."""
    effective_request = _validated_image_model(
        request,
        ImageTransformRequest,
        "Image transform request is invalid",
    )
    effective_limits = _validated_image_limits(limits)
    _validate_output_request(path, output_path, effective_request)
    preservation = assess_image_preservation(
        path,
        effective_request,
        limits=effective_limits,
    )
    if effective_request.strict_preservation:
        _reject_strict_risks(preservation)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path: Path | None = None
    frames: list[PillowImage] = []
    try:
        with open_verified_image(path, action="transform image") as (
            descriptor,
            image,
        ):
            _verify_assessed_source(descriptor.fingerprint, preservation)
            indexes = _selected_indexes(image, effective_request, effective_limits)
            first_options: dict[str, object] | None = None
            for index in indexes:
                image.seek(index)
                image.load()
                if first_options is None:
                    first_options = _save_options(image, effective_request)
                frames.append(
                    _transform_frame(image, effective_request, effective_limits)
                )
            with tempfile.NamedTemporaryFile(
                prefix=".document-sdk-image-",
                suffix=output_path.suffix,
                dir=output_path.parent,
                delete=False,
            ) as temporary:
                temporary_path = type(output_path)(temporary.name)
                writer = _CappedSeekableWriter(
                    cast("Any", temporary),
                    effective_limits.max_output_bytes,
                )
                options = first_options or {}
                save_first = cast("Any", frames[0].save)
                if len(frames) > 1:
                    save_first(
                        writer,
                        format=effective_request.output_format,
                        save_all=True,
                        append_images=frames[1:],
                        **options,
                    )
                else:
                    save_first(
                        writer,
                        format=effective_request.output_format,
                        **options,
                    )
                writer.flush()
            _enforce_output_size(temporary_path, effective_limits)
            frame_count = _verify_output(temporary_path, effective_limits)
            temporary_path.replace(output_path)
            temporary_path = None
            output = inspect_file(output_path)
            return ImageTransformResult(
                source=descriptor,
                output=output,
                frame_count=frame_count,
                preservation=preservation,
                warnings=preservation.warnings,
            )
    except (ImageProcessingError, ImagePreservationError):
        raise
    except Exception as exc:  # noqa: BLE001 - local encoder adapter boundary.
        msg = f"Unable to transform image: {safe_file_label(path)}"
        _raise_redacted_translation(exc, ImageProcessingError(msg))
    finally:
        for frame in frames:
            frame.close()
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)

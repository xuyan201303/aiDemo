"""Shared bounded Pillow I/O without backend objects in public results."""

from __future__ import annotations

import os
import warnings
from contextlib import ExitStack, contextmanager
from dataclasses import dataclass, field
from functools import wraps
from io import BytesIO
from typing import TYPE_CHECKING, Any, Literal, ParamSpec, TypeVar, cast

from pydantic import BaseModel

from document_sdk.core import (
    DocumentSdkError,
    ImageLimitExceededError,
    ImageProcessingError,
    ImageProcessingLimits,
    ImageSourceReference,
)
from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.errors import _raise_redacted_translation, safe_file_label
from document_sdk.files import inspect_file
from document_sdk.files._source_identity import verify_open_binary
from document_sdk.image._dependencies import require_image_support
from document_sdk.image.models import EncodedImage, ImageFormat

if TYPE_CHECKING:
    from collections.abc import Callable, Iterator
    from io import BufferedIOBase
    from pathlib import Path

    from PIL.Image import Image as PillowImage

    from document_sdk.core import BoundingBox, FileDescriptor

type _Mime = Literal[
    "image/png",
    "image/jpeg",
    "image/tiff",
    "image/bmp",
    "image/webp",
]
_P = ParamSpec("_P")
_R = TypeVar("_R")
_EXIF_ORIENTATION_TAG = 274
_TIFF_IMAGE_WIDTH_TAG = 256
_TIFF_IMAGE_HEIGHT_TAG = 257
_MIN_EXIF_ORIENTATION = 1
_MAX_EXIF_ORIENTATION = 8
_TRANSPOSED_EXIF_ORIENTATIONS = frozenset({5, 6, 7, 8})

MIME_BY_FORMAT: dict[ImageFormat, _Mime] = {
    "BMP": "image/bmp",
    "JPEG": "image/jpeg",
    "PNG": "image/png",
    "TIFF": "image/tiff",
    "WEBP": "image/webp",
}
FORMAT_BY_SUFFIX: dict[str, ImageFormat] = {
    ".bmp": "BMP",
    ".jpeg": "JPEG",
    ".jpg": "JPEG",
    ".png": "PNG",
    ".tif": "TIFF",
    ".tiff": "TIFF",
    ".webp": "WEBP",
}


def _validated_image_model[ModelT: BaseModel](
    value: BaseModel,
    expected_type: type[ModelT],
    message: str,
) -> ModelT:
    """Revalidate one public image model without invoking instance hooks."""
    try:
        return _revalidate_model_instance_json(value, expected_type, message)
    except Exception as exc:  # noqa: BLE001 - public model boundary is redacted.
        _raise_redacted_translation(exc, ImageProcessingError(message))


def _validated_image_limits(
    limits: ImageProcessingLimits | None,
) -> ImageProcessingLimits:
    """Return trusted image limits before dependency or file access."""
    if limits is None:
        return ImageProcessingLimits()
    return _validated_image_model(
        limits,
        ImageProcessingLimits,
        "Image processing limits are invalid",
    )


@dataclass(frozen=True, slots=True)
class _ImageFramePixels:
    """Private immutable decoded pixels with content-safe source identity."""

    width: int
    height: int
    mode: Literal["RGB"]
    pixels: bytes = field(repr=False)
    descriptor: FileDescriptor
    source: ImageSourceReference


@dataclass(frozen=True, slots=True)
class _PreparedImageFrame:
    """One decoded frame plus immutable encoded-storage orientation facts."""

    image: PillowImage
    storage_width: int
    storage_height: int
    exif_orientation: int | None


class _ImageSourceIdentityMismatchError(ImageProcessingError):
    """Private signal for an exact-stream identity mismatch."""


class _ImageFramePixelStream:
    """One verified Pillow handle that decodes selected frames on demand."""

    __slots__ = (
        "_descriptor",
        "_image",
        "_limits",
        "_normalize_orientation",
        "_read_frames",
        "_selected_frames",
    )

    def __init__(
        self,
        *,
        descriptor: FileDescriptor,
        image: PillowImage,
        limits: ImageProcessingLimits,
        normalize_orientation: bool,
        selected_frame_numbers: tuple[int, ...],
    ) -> None:
        self._descriptor = descriptor
        self._image = image
        self._limits = limits
        self._normalize_orientation = normalize_orientation
        self._selected_frames = frozenset(selected_frame_numbers)
        self._read_frames: set[int] = set()

    def read_frame(self, frame_number: int) -> _ImageFramePixels:
        """Decode one bounded frame without retaining its returned buffer."""
        from PIL import Image

        if (
            not isinstance(frame_number, int)
            or isinstance(frame_number, bool)
            or frame_number not in self._selected_frames
            or frame_number in self._read_frames
        ):
            msg = "Image frame is not available in this verified stream"
            raise ImageProcessingError(msg)
        self._read_frames.add(frame_number)
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("error", Image.DecompressionBombWarning)
                return _decode_image_frame_pixels(
                    self._image,
                    descriptor=self._descriptor,
                    frame_number=frame_number,
                    normalize_orientation=self._normalize_orientation,
                    limits=self._limits,
                )
        except DocumentSdkError:
            raise
        except (Image.DecompressionBombWarning, Image.DecompressionBombError) as exc:
            msg = "Image exceeds Pillow's decompression safety threshold"
            _raise_redacted_translation(exc, ImageProcessingError(msg))
        except Exception as exc:  # noqa: BLE001 - Pillow adapter boundary.
            msg = "Unable to read image frame pixels"
            _raise_redacted_translation(exc, ImageProcessingError(msg))


def sanitized_image_adapter(
    action: str,
) -> Callable[[Callable[_P, _R]], Callable[_P, _R]]:
    """Translate unexpected backend failures without leaking their messages."""

    def decorate(function: Callable[_P, _R]) -> Callable[_P, _R]:
        @wraps(function)
        def call(*args: _P.args, **kwargs: _P.kwargs) -> _R:
            try:
                return function(*args, **kwargs)
            except DocumentSdkError:
                raise
            except Exception as exc:  # noqa: BLE001 - backend adapter boundary.
                msg = f"Unable to {action}"
                _raise_redacted_translation(exc, ImageProcessingError(msg))

        return call

    return decorate


def enforce_limit(name: str, observed: int, maximum: int) -> None:
    """Reject an image resource expansion with structured evidence."""
    if observed > maximum:
        raise ImageLimitExceededError(
            limit_name=name,
            observed=observed,
            maximum=maximum,
        )


def enforce_input_dimensions(
    width: int,
    height: int,
    limits: ImageProcessingLimits,
) -> None:
    """Check encoded input dimensions before decoding a frame."""
    pixels = width * height
    enforce_limit("pixels per frame", pixels, limits.max_pixels_per_frame)
    enforce_limit("working pixels", pixels, limits.max_working_pixels)


def enforce_working_dimensions(
    width: int,
    height: int,
    limits: ImageProcessingLimits,
) -> None:
    """Check one intermediate allocation independently of output dimensions."""
    enforce_limit("working pixels", width * height, limits.max_working_pixels)


def enforce_output_dimensions(
    width: int,
    height: int,
    limits: ImageProcessingLimits,
) -> None:
    """Check final output dimensions and allocation size."""
    enforce_working_dimensions(width, height, limits)
    enforce_limit("output width", width, limits.max_output_width)
    enforce_limit("output height", height, limits.max_output_height)


def has_alpha(image: PillowImage) -> bool:
    """Report an alpha band or evidenced keyed/palette transparency."""
    alpha_band = any(band.upper() == "A" for band in image.getbands())
    palette_alpha = (
        image.mode == "P"
        and image.palette is not None
        and image.palette.mode.endswith("A")
    )
    return alpha_band or "transparency" in image.info or palette_alpha


def _validated_exif_orientation(orientation: object | None) -> int | None:
    """Return one trusted EXIF orientation without exposing other metadata."""
    if orientation is None:
        return None
    if (
        isinstance(orientation, int)
        and not isinstance(orientation, bool)
        and _MIN_EXIF_ORIENTATION <= orientation <= _MAX_EXIF_ORIENTATION
    ):
        return orientation
    msg = "Image EXIF orientation metadata is invalid"
    raise ImageProcessingError(msg)


def _raw_exif_orientation(image: PillowImage) -> object | None:
    """Capture selected-frame orientation before a backend may consume it."""
    if image.format == "TIFF":
        tags = getattr(image, "tag_v2", None)
        if tags is not None:
            orientation = tags.get(_EXIF_ORIENTATION_TAG)
            if orientation is not None:
                return cast("object", orientation)
    return image.getexif().get(_EXIF_ORIENTATION_TAG)


def _encoded_storage_size(image: PillowImage) -> tuple[int, int]:
    """Return encoded dimensions before Pillow applies TIFF orientation."""
    if image.format != "TIFF":
        return image.size
    tags = getattr(image, "tag_v2", None)
    width = None if tags is None else tags.get(_TIFF_IMAGE_WIDTH_TAG)
    height = None if tags is None else tags.get(_TIFF_IMAGE_HEIGHT_TAG)
    if (
        not isinstance(width, int)
        or isinstance(width, bool)
        or width <= 0
        or not isinstance(height, int)
        or isinstance(height, bool)
        or height <= 0
    ):
        msg = "TIFF encoded storage dimensions are invalid"
        raise ImageProcessingError(msg)
    return width, height


def _neutralize_pillow_tiff_orientation(
    image: PillowImage,
    *,
    storage_size: tuple[int, int],
    raw_orientation: object | None,
) -> None:
    """Prevent Pillow's TIFF loader from applying orientation during decode."""
    if image.format != "TIFF" or raw_orientation is None:
        return
    backend = cast("Any", image)
    backend.tag_v2[_EXIF_ORIENTATION_TAG] = 1
    image.getexif()[_EXIF_ORIENTATION_TAG] = 1
    backend._size = storage_size  # noqa: SLF001 - bounded Pillow TIFF adapter.


def _prepared_output_size(
    storage_size: tuple[int, int],
    *,
    orientation: int | None,
    normalize_orientation: bool,
) -> tuple[int, int]:
    """Predict prepared-frame dimensions from encoded-storage facts."""
    if normalize_orientation and orientation in _TRANSPOSED_EXIF_ORIENTATIONS:
        return storage_size[1], storage_size[0]
    return storage_size


def _document_rgb_frame(image: PillowImage) -> tuple[PillowImage, bool]:
    """Return deterministic RGB document pixels using an opaque white canvas."""
    if not has_alpha(image):
        return (image if image.mode == "RGB" else image.convert("RGB")), False

    from PIL import Image

    rgba = image.convert("RGBA")
    rgb = Image.new("RGB", rgba.size, (255, 255, 255))
    alpha = rgba.getchannel("A")
    try:
        rgb.paste(rgba, mask=alpha)
    except BaseException:
        rgb.close()
        raise
    finally:
        alpha.close()
        rgba.close()
    return rgb, True


class _CappedSeekableWriter:
    """Seekable encoder target that rejects writes beyond a byte budget."""

    def __init__(self, stream: BufferedIOBase | BytesIO, maximum: int) -> None:
        self._stream = stream
        self._maximum = maximum
        self._high_water = 0

    def write(self, data: bytes) -> int:
        observed = max(self._high_water, self._stream.tell() + len(data))
        enforce_limit("output bytes", observed, self._maximum)
        written = self._stream.write(data)
        self._high_water = max(self._high_water, self._stream.tell())
        return written

    def read(self, size: int = -1) -> bytes:
        return self._stream.read(size)

    def seek(self, offset: int, whence: int = 0) -> int:
        return self._stream.seek(offset, whence)

    def tell(self) -> int:
        return self._stream.tell()

    def truncate(self, size: int | None = None) -> int:
        target = self._stream.tell() if size is None else size
        enforce_limit("output bytes", target, self._maximum)
        truncated = self._stream.truncate(size)
        self._high_water = min(self._high_water, truncated)
        return truncated

    def flush(self) -> None:
        self._stream.flush()

    def readable(self) -> bool:
        return self._stream.readable()

    def writable(self) -> bool:
        return self._stream.writable()

    def seekable(self) -> bool:
        return self._stream.seekable()

    def fileno(self) -> int:
        return self._stream.fileno()

    @property
    def closed(self) -> bool:
        return self._stream.closed

    @property
    def name(self) -> object:
        return getattr(self._stream, "name", None)


@contextmanager
def open_verified_image(
    path: Path,
    *,
    action: str,
) -> Iterator[tuple[FileDescriptor, PillowImage]]:
    """Open, identity-check, and yield the exact stream consumed by Pillow."""
    require_image_support()
    descriptor = inspect_file(path)
    from PIL import Image

    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with path.open("rb") as stream:
                verify_open_binary(
                    stream,
                    expected_fingerprint=descriptor.fingerprint.value,
                    expected_size=descriptor.size_bytes,
                    mismatch_message="Image changed after inspection",
                )
                with Image.open(stream) as image:
                    yield descriptor, image
    except DocumentSdkError:
        raise
    except (Image.DecompressionBombWarning, Image.DecompressionBombError) as exc:
        msg = (
            "Image exceeds Pillow's decompression safety threshold: "
            f"{safe_file_label(path)}"
        )
        _raise_redacted_translation(exc, ImageProcessingError(msg))
    except Exception as exc:  # noqa: BLE001 - Pillow adapter boundary.
        msg = f"Unable to {action}: {safe_file_label(path)}"
        _raise_redacted_translation(exc, ImageProcessingError(msg))


def selected_frame(
    image: PillowImage,
    *,
    frame_number: int,
    limits: ImageProcessingLimits,
    normalize_orientation: bool,
) -> PillowImage:
    """Decode exactly one explicitly selected one-based frame."""
    return _prepare_selected_frame(
        image,
        frame_number=frame_number,
        limits=limits,
        normalize_orientation=normalize_orientation,
    ).image


def _prepare_selected_frame(
    image: PillowImage,
    *,
    frame_number: int,
    limits: ImageProcessingLimits,
    normalize_orientation: bool,
    enforce_output_limits: bool = False,
) -> _PreparedImageFrame:
    """Decode one frame from captured encoded-storage orientation facts."""
    _seek_selected_frame(image, frame_number=frame_number, limits=limits)
    storage_size = _encoded_storage_size(image)
    enforce_input_dimensions(*storage_size, limits)
    raw_orientation = (
        _raw_exif_orientation(image)
        if image.format == "TIFF" or normalize_orientation
        else None
    )
    orientation = (
        _validated_exif_orientation(raw_orientation)
        if normalize_orientation
        else (
            raw_orientation
            if isinstance(raw_orientation, int)
            and not isinstance(raw_orientation, bool)
            and _MIN_EXIF_ORIENTATION <= raw_orientation <= _MAX_EXIF_ORIENTATION
            else None
        )
    )
    expected_size = _prepared_output_size(
        storage_size,
        orientation=orientation,
        normalize_orientation=normalize_orientation,
    )
    if enforce_output_limits:
        enforce_output_dimensions(*expected_size, limits)
    _neutralize_pillow_tiff_orientation(
        image,
        storage_size=storage_size,
        raw_orientation=raw_orientation,
    )
    frame = image.copy()
    try:
        if normalize_orientation and orientation is not None:
            from PIL import ImageOps

            frame.getexif()[_EXIF_ORIENTATION_TAG] = orientation
            ImageOps.exif_transpose(frame, in_place=True)
        if frame.size != expected_size:
            msg = "Image orientation metadata changed during frame decoding"
            raise ImageProcessingError(msg)  # noqa: TRY301 - frame closes below.
        enforce_working_dimensions(*frame.size, limits)
    except BaseException:
        frame.close()
        raise
    return _PreparedImageFrame(
        image=frame,
        storage_width=storage_size[0],
        storage_height=storage_size[1],
        exif_orientation=orientation,
    )


def _seek_selected_frame(
    image: PillowImage,
    *,
    frame_number: int,
    limits: ImageProcessingLimits,
) -> None:
    """Seek and bound one frame without decoding its pixel payload."""
    if frame_number > limits.max_frames:
        enforce_limit("frame count", frame_number, limits.max_frames)
    try:
        image.seek(frame_number - 1)
    except EOFError as exc:
        msg = "Image frame does not exist"
        _raise_redacted_translation(exc, ImageProcessingError(msg))
    width, height = image.size
    enforce_input_dimensions(width, height, limits)


def _decode_image_frame_pixels(
    image: PillowImage,
    *,
    descriptor: FileDescriptor,
    frame_number: int,
    normalize_orientation: bool,
    limits: ImageProcessingLimits,
) -> _ImageFramePixels:
    """Decode one frame from an already verified open image handle."""
    prepared = _prepare_selected_frame(
        image,
        frame_number=frame_number,
        normalize_orientation=normalize_orientation,
        limits=limits,
        enforce_output_limits=True,
    )
    frame = prepared.image
    width, height = frame.size
    enforce_working_dimensions(width, height, limits)
    enforce_limit("output width", width, limits.max_output_width)
    enforce_limit("output height", height, limits.max_output_height)
    expected_bytes = width * height * 3
    enforce_limit(
        "raw pixel bytes",
        expected_bytes,
        limits.max_working_pixels * 3,
    )

    try:
        rgb, _ = _document_rgb_frame(frame)
        try:
            pixels = rgb.tobytes()
        finally:
            if rgb is not frame:
                rgb.close()
    finally:
        frame.close()

    if len(pixels) != expected_bytes:
        msg = "Decoded image pixel buffer has an invalid length"
        raise ImageProcessingError(msg)
    return _ImageFramePixels(
        width=width,
        height=height,
        mode="RGB",
        pixels=pixels,
        descriptor=descriptor,
        source=ImageSourceReference(
            file_id=descriptor.file_id,
            frame_number=frame_number,
        ),
    )


@contextmanager
def _open_image_frame_pixel_stream(
    path: Path,
    *,
    descriptor: FileDescriptor,
    selected_frame_numbers: tuple[int, ...],
    normalize_orientation: bool = False,
    limits: ImageProcessingLimits | None = None,
    _verified_snapshot: bool = False,
) -> Iterator[_ImageFramePixelStream]:
    """Open, verify, and parse one reusable image snapshot exactly once."""
    require_image_support()
    effective_limits = limits or ImageProcessingLimits()
    if (
        not selected_frame_numbers
        or any(
            not isinstance(frame_number, int)
            or isinstance(frame_number, bool)
            or frame_number < 1
            or frame_number > effective_limits.max_frames
            for frame_number in selected_frame_numbers
        )
        or len(set(selected_frame_numbers)) != len(selected_frame_numbers)
    ):
        msg = "Selected image frames are invalid"
        raise ImageProcessingError(msg)
    from PIL import Image

    stack = ExitStack()
    try:
        stream = stack.enter_context(path.open("rb"))
        if _verified_snapshot:
            if os.fstat(stream.fileno()).st_size != descriptor.size_bytes:
                msg = "Image changed after inspection"
                raise _ImageSourceIdentityMismatchError(msg)  # noqa: TRY301
        else:
            try:
                verify_open_binary(
                    stream,
                    expected_fingerprint=descriptor.fingerprint.value,
                    expected_size=descriptor.size_bytes,
                    mismatch_message="Image changed after inspection",
                )
            except ValueError as exc:
                msg = "Image changed after inspection"
                _raise_redacted_translation(
                    exc,
                    _ImageSourceIdentityMismatchError(msg),
                )
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            image = Image.open(stream)
        stack.callback(image.close)
    except _ImageSourceIdentityMismatchError:
        stack.close()
        raise
    except DocumentSdkError:
        stack.close()
        raise
    except (Image.DecompressionBombWarning, Image.DecompressionBombError) as exc:
        stack.close()
        msg = (
            "Image exceeds Pillow's decompression safety threshold: "
            f"{safe_file_label(path)}"
        )
        _raise_redacted_translation(exc, ImageProcessingError(msg))
    except Exception as exc:  # noqa: BLE001 - Pillow adapter boundary.
        stack.close()
        msg = f"Unable to read image frame pixels: {safe_file_label(path)}"
        _raise_redacted_translation(exc, ImageProcessingError(msg))

    try:
        yield _ImageFramePixelStream(
            descriptor=descriptor,
            image=image,
            limits=effective_limits,
            normalize_orientation=normalize_orientation,
            selected_frame_numbers=selected_frame_numbers,
        )
    finally:
        stack.close()


def _read_image_frame_pixels(
    path: Path,
    frame_number: int = 1,
    *,
    normalize_orientation: bool = False,
    limits: ImageProcessingLimits | None = None,
    _pixel_stream: _ImageFramePixelStream | None = None,
) -> _ImageFramePixels:
    """Decode one selected frame directly to bounded immutable RGB pixels."""
    if _pixel_stream is not None:
        return _pixel_stream.read_frame(frame_number)
    descriptor = inspect_file(path)
    with _open_image_frame_pixel_stream(
        path,
        descriptor=descriptor,
        selected_frame_numbers=(frame_number,),
        normalize_orientation=normalize_orientation,
        limits=limits,
    ) as stream:
        return stream.read_frame(frame_number)


def normalized_crop_box(
    box: BoundingBox,
    *,
    width: int,
    height: int,
) -> tuple[int, int, int, int]:
    """Convert a normalized top-left box to a non-empty pixel box."""
    left = min(width - 1, int(box.left * width))
    top = min(height - 1, int(box.top * height))
    right = max(left + 1, min(width, int(box.right * width + 0.999999)))
    bottom = max(top + 1, min(height, int(box.bottom * height + 0.999999)))
    return left, top, right, bottom


def encode_image(  # noqa: PLR0913 - explicit encoder safety options.
    image: PillowImage,
    *,
    image_format: ImageFormat,
    source: ImageSourceReference,
    limits: ImageProcessingLimits,
    quality: int = 90,
    save_options: dict[str, object] | None = None,
) -> EncodedImage:
    """Encode one bounded Pillow image into a backend-neutral result."""
    enforce_output_dimensions(*image.size, limits)
    if image_format == "JPEG" and image.mode in {"RGBA", "LA", "P"}:
        msg = "JPEG output cannot contain alpha without an explicit background"
        raise ImageProcessingError(msg)
    options: dict[str, object] = dict(save_options or {})
    if image_format in {"JPEG", "WEBP"}:
        options.setdefault("quality", quality)
    stream = BytesIO()
    writer = _CappedSeekableWriter(stream, limits.max_output_bytes)
    save_image = cast("Any", image.save)
    save_image(
        cast("Any", writer),
        format=image_format,
        **options,
    )
    data = stream.getvalue()
    return EncodedImage(
        data=data,
        format=image_format,
        mime_type=MIME_BY_FORMAT[image_format],
        width=image.width,
        height=image.height,
        mode=image.mode,
        source=source,
    )


def pillow_format(value: str | None) -> ImageFormat:
    """Normalize a supported Pillow format."""
    if value not in MIME_BY_FORMAT:
        msg = "Image format is not supported"
        raise ImageProcessingError(msg)
    return cast("ImageFormat", value)

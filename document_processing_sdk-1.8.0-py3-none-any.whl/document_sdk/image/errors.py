"""Image-specific public exceptions."""

from document_sdk.core import ImageProcessingError


class ImagePreservationError(ImageProcessingError):
    """Raised when strict image preservation cannot be guaranteed."""


class ImageAlignmentError(ImageProcessingError):
    """Raised when bounded alignment has insufficient geometric evidence."""

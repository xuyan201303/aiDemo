"""Objective local image-quality evidence."""

from __future__ import annotations

import math
from typing import TYPE_CHECKING

from document_sdk.core import ImageProcessingLimits, ImageSourceReference
from document_sdk.image._dependencies import require_image_opencv_support
from document_sdk.image._io import (
    _validated_image_limits,
    _validated_image_model,
    open_verified_image,
    selected_frame,
)
from document_sdk.image.models import ImageQualityOptions, ImageQualityReport

if TYPE_CHECKING:
    from pathlib import Path

    from PIL.Image import Image as PillowImage

_MAX_SKEW_CANDIDATE = 45
_DPI_TUPLE_LENGTH = 2
_MIN_DOCUMENT_DIMENSION = 500


def _histogram_metrics(
    image: PillowImage,
    options: ImageQualityOptions,
) -> tuple[float, float, float, float, float]:
    gray = image.convert("L")
    try:
        histogram = gray.histogram()
    finally:
        gray.close()
    total = sum(histogram)
    brightness = sum(index * count for index, count in enumerate(histogram)) / total
    variance = (
        sum(
            ((index - brightness) ** 2) * count for index, count in enumerate(histogram)
        )
        / total
    )
    black = sum(histogram[: options.near_black_level + 1]) / total
    white = sum(histogram[options.near_white_level :]) / total
    blank = sum(histogram[options.blank_level :]) / total
    return brightness, math.sqrt(variance), black, white, blank


def _alpha_coverage(image: PillowImage) -> float:
    if "A" not in image.getbands():
        return 1.0
    alpha = image.getchannel("A")
    try:
        histogram = alpha.histogram()
    finally:
        alpha.close()
    total = sum(histogram)
    return sum(count for value, count in enumerate(histogram) if value > 0) / total


def _advanced_metrics(
    image: PillowImage,
) -> tuple[float, float, float, float | None, float, float]:
    require_image_opencv_support()
    import cv2
    import numpy as np

    converted = image.convert("L")
    try:
        gray = np.asarray(converted, dtype=np.uint8).copy()
    finally:
        converted.close()
    blur = float(cv2.Laplacian(gray, cv2.CV_64F).var())
    edges = cv2.Canny(gray, 50, 150)
    edge_density = float(np.count_nonzero(edges) / edges.size)
    smoothed = cv2.GaussianBlur(gray, (3, 3), 0)
    noise = float(np.mean(np.abs(gray.astype(np.float32) - smoothed)))
    lines = cv2.HoughLines(edges, 1, np.pi / 180, max(20, min(gray.shape) // 4))
    angle: float | None = None
    confidence = 0.0
    if lines is not None and len(lines):
        candidates = [
            float(theta * 180 / np.pi - 90)
            for rho, theta in lines[:, 0]
            if abs(float(theta * 180 / np.pi - 90)) <= _MAX_SKEW_CANDIDATE
        ]
        if candidates:
            angle = float(np.median(candidates))
            confidence = min(1.0, len(candidates) / 20)
    background_uniformity = max(0.0, 1.0 - float(np.std(gray)) / 128)
    return blur, edge_density, noise, angle, confidence, background_uniformity


def analyze_image_quality(
    path: Path,
    options: ImageQualityOptions | None = None,
    *,
    limits: ImageProcessingLimits | None = None,
) -> ImageQualityReport:
    """Return objective quality values without a universal verdict."""
    effective_options = (
        ImageQualityOptions()
        if options is None
        else _validated_image_model(
            options,
            ImageQualityOptions,
            "Image quality options are invalid",
        )
    )
    effective_limits = _validated_image_limits(limits)
    with open_verified_image(path, action="analyze image quality") as (
        descriptor,
        image,
    ):
        frame = selected_frame(
            image,
            frame_number=effective_options.frame_number,
            limits=effective_limits,
            normalize_orientation=True,
        )
        try:
            brightness, contrast, black, white, blank = _histogram_metrics(
                frame,
                effective_options,
            )
            gray = frame.convert("L")
            try:
                entropy = float(gray.entropy())
            finally:
                gray.close()
            dpi_value = image.info.get("dpi")
            dpi = (
                (float(dpi_value[0]), float(dpi_value[1]))
                if isinstance(dpi_value, tuple) and len(dpi_value) == _DPI_TUPLE_LENGTH
                else None
            )
            warnings: list[str] = []
            if dpi is not None and min(dpi) < effective_options.minimum_effective_dpi:
                warnings.append("Image DPI is below the configured minimum.")
            if (
                frame.width < _MIN_DOCUMENT_DIMENSION
                or frame.height < _MIN_DOCUMENT_DIMENSION
            ):
                warnings.append("Image resolution is small for document processing.")
            if frame.mode in {"CMYK", "P", "1"}:
                warnings.append(f"Image uses {frame.mode} color mode.")
            advanced: tuple[
                float | None,
                float | None,
                float | None,
                float | None,
                float | None,
                float | None,
            ] = (None, None, None, None, None, None)
            if effective_options.advanced:
                advanced = _advanced_metrics(frame)
            return ImageQualityReport(
                source=ImageSourceReference(
                    file_id=descriptor.file_id,
                    frame_number=effective_options.frame_number,
                ),
                width=frame.width,
                height=frame.height,
                brightness=brightness,
                contrast=contrast,
                black_clipping_ratio=black,
                white_clipping_ratio=white,
                near_blank_ratio=blank,
                entropy=entropy,
                effective_dpi=dpi,
                alpha_coverage=_alpha_coverage(frame),
                blur_score=advanced[0],
                edge_density=advanced[1],
                estimated_noise=advanced[2],
                skew_angle_candidate=advanced[3],
                skew_confidence=advanced[4],
                background_uniformity=advanced[5],
                warnings=tuple(warnings),
            )
        finally:
            frame.close()

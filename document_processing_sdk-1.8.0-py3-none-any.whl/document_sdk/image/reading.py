"""Safe frame and normalized-region reading."""

from __future__ import annotations

from typing import TYPE_CHECKING

from document_sdk.core import (
    BoundingBox,
    ImageProcessingLimits,
    ImageSourceReference,
)
from document_sdk.image._io import (
    _validated_image_limits,
    _validated_image_model,
    encode_image,
    normalized_crop_box,
    open_verified_image,
    selected_frame,
)
from document_sdk.image.models import (
    EncodedImage,  # noqa: TC001 - public return annotation.
    ImageColorMode,  # noqa: TC001 - public parameter annotation.
    ImageFormat,  # noqa: TC001 - public parameter annotation.
)

if TYPE_CHECKING:
    from pathlib import Path


def read_image_frame(  # noqa: PLR0913 - explicit safe output controls.
    path: Path,
    frame_number: int = 1,
    *,
    normalize_orientation: bool = False,
    output_mode: ImageColorMode | None = None,
    output_format: ImageFormat = "PNG",
    quality: int = 90,
    limits: ImageProcessingLimits | None = None,
) -> EncodedImage:
    """Read and safely encode exactly one selected image frame."""
    effective_limits = _validated_image_limits(limits)
    with open_verified_image(path, action="read image frame") as (descriptor, image):
        frame = selected_frame(
            image,
            frame_number=frame_number,
            limits=effective_limits,
            normalize_orientation=normalize_orientation,
        )
        try:
            if output_mode is not None and frame.mode != output_mode:
                converted = frame.convert(output_mode)
                frame.close()
                frame = converted
            elif frame.mode == "CMYK" and output_format not in {"JPEG", "TIFF"}:
                converted = frame.convert("RGB")
                frame.close()
                frame = converted
            return encode_image(
                frame,
                image_format=output_format,
                source=ImageSourceReference(
                    file_id=descriptor.file_id,
                    frame_number=frame_number,
                ),
                limits=effective_limits,
                quality=quality,
            )
        finally:
            frame.close()


def read_image_region(  # noqa: PLR0913 - explicit safe output controls.
    path: Path,
    region: BoundingBox,
    frame_number: int = 1,
    *,
    normalize_orientation: bool = False,
    output_mode: ImageColorMode | None = None,
    output_format: ImageFormat = "PNG",
    quality: int = 90,
    limits: ImageProcessingLimits | None = None,
) -> EncodedImage:
    """Read one normalized top-left region with source traceability."""
    effective_region = _validated_image_model(
        region,
        BoundingBox,
        "Image region is invalid",
    )
    effective_limits = _validated_image_limits(limits)
    with open_verified_image(path, action="read image region") as (descriptor, image):
        frame = selected_frame(
            image,
            frame_number=frame_number,
            limits=effective_limits,
            normalize_orientation=normalize_orientation,
        )
        try:
            cropped = frame.crop(
                normalized_crop_box(
                    effective_region,
                    width=frame.width,
                    height=frame.height,
                )
            )
            try:
                if output_mode is not None and cropped.mode != output_mode:
                    converted = cropped.convert(output_mode)
                    cropped.close()
                    cropped = converted
                elif cropped.mode == "CMYK" and output_format not in {"JPEG", "TIFF"}:
                    converted = cropped.convert("RGB")
                    cropped.close()
                    cropped = converted
                return encode_image(
                    cropped,
                    image_format=output_format,
                    source=ImageSourceReference(
                        file_id=descriptor.file_id,
                        frame_number=frame_number,
                        bounding_box=effective_region,
                    ),
                    limits=effective_limits,
                    quality=quality,
                )
            finally:
                cropped.close()
        finally:
            frame.close()

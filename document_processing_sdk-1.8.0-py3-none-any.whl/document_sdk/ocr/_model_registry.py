"""Single authoritative registry for approved Local OCR model capability."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class _ApprovedLocalOcrModel:
    """One immutable path-free approved Engine and model definition."""

    engine_name: str
    engine_distribution: str
    engine_version: str
    model_id: str
    language_profile: str
    languages: tuple[str, ...]
    device_class: str
    execution_provider: str
    backend_language_code: str
    model_files: tuple[tuple[str, str], ...]

    @property
    def model_hashes(self) -> tuple[str, ...]:
        """Return approved hashes in canonical model-file order."""
        return tuple(model_hash for _name, model_hash in self.model_files)


RAPIDOCR_ZH_EN_MODEL = _ApprovedLocalOcrModel(
    engine_name="rapidocr-cpu",
    engine_distribution="rapidocr",
    engine_version="3.9.2",
    model_id="rapidocr-3.9.2-ppocrv6-small",
    language_profile="zh_en",
    languages=("zh", "en"),
    device_class="cpu",
    execution_provider="CPUExecutionProvider",
    backend_language_code="ch",
    model_files=(
        (
            "PP-OCRv6_det_small.onnx",
            "090f04abcd9d9a7498bc4ebf677e4cb9bdce1fe4197ddb7e529f1ef44e1ff94f",
        ),
        (
            "ch_ppocr_mobile_v2.0_cls_mobile.onnx",
            "e47acedf663230f8863ff1ab0e64dd2d82b838fceb5957146dab185a89d6215c",
        ),
        (
            "PP-OCRv6_rec_small.onnx",
            "6f327246b50388f3c176ae304bd95767ea6dc0c9ae92153ef8cbe210b3c14884",
        ),
    ),
)

APPROVED_LOCAL_OCR_MODELS = (RAPIDOCR_ZH_EN_MODEL,)

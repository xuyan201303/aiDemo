"""Sanitized errors for the optional RapidOCR CPU Engine adapter."""

from document_sdk.ocr.local_errors import LocalOcrError


class RapidOcrError(LocalOcrError):
    """Base for controlled RapidOCR adapter failures."""


class RapidOcrEngineInitializationError(RapidOcrError):
    """Raised when the fixed CPU runtime cannot be initialized safely."""


class RapidOcrModelValidationError(RapidOcrError):
    """Raised when a local ONNX model set violates its declared identity."""


class RapidOcrExecutionError(RapidOcrError):
    """Raised for inference failures or unsupported third-party output."""

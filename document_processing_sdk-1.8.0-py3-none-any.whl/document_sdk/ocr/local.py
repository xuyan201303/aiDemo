"""Provider-neutral Local OCR over SDK-decoded or SDK-rendered images."""

from __future__ import annotations

import hashlib
import inspect
import math
import weakref
from collections.abc import Sequence, Sized
from contextlib import contextmanager
from dataclasses import dataclass, field, replace
from io import BytesIO
from threading import Condition, RLock
from time import perf_counter
from typing import TYPE_CHECKING, Literal, Never, TypeGuard, cast

from pydantic import JsonValue, ValidationError

from document_sdk.core import (
    BoundingBox,
    Document,
    DocumentPage,
    FileDescriptor,
    ImageInspection,
    ImageLimitExceededError,
    ImageProcessingLimits,
    ImageSourceReference,
    PageDimensions,
    PdfInspection,
    PdfSourceReference,
    ProcessingMetadata,
    ProcessingResult,
    ProviderUsage,
    TextBlock,
)
from document_sdk.core._exceptions import redact_exception
from document_sdk.core._metadata import thaw_json_mapping
from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.errors import DocumentSdkError, redacted_cause
from document_sdk.core.local_ocr_quality import (
    LOCAL_OCR_QUALITY_ALGORITHM_VERSION,
    LOCAL_OCR_QUALITY_AREA_SCALE,
    LocalOcrInputQualityAssessment,
    LocalOcrIntrinsicQualityPolicy,
    LocalOcrQualityDecision,
    LocalOcrQualityPolicy,
    LocalOcrQualityReport,
    _ratio_micro,
    create_local_ocr_input_quality_assessment,
    create_local_ocr_quality_report,
    local_ocr_quality_identity,
    local_ocr_quality_policy_fingerprint,
)
from document_sdk.image import inspect_image
from document_sdk.image._io import (
    _ImageFramePixelStream,
    _ImageSourceIdentityMismatchError,
    _open_image_frame_pixel_stream,
    _read_image_frame_pixels,
)
from document_sdk.ocr._preprocessing_selection import (
    _PreprocessingCandidate,
    _select_preprocessing_candidate,
)
from document_sdk.ocr.local_errors import (
    LocalOcrEngineInitializationError,
    LocalOcrExecutionError,
    LocalOcrInvalidResultError,
    LocalOcrLimitExceededError,
    LocalOcrQualityConfigurationError,
    LocalOcrQualityEvaluationError,
    LocalOcrUnsupportedInputError,
    _attach_attempt_usage,
)
from document_sdk.ocr.local_models import (
    LocalOcrEngine,
    LocalOcrEngineIdentity,
    LocalOcrEngineRegion,
    LocalOcrEngineResult,
    LocalOcrImageInput,
    LocalOcrProcessingLimits,
    LocalOcrRawRegion,
    LocalOcrRawResult,
)
from document_sdk.ocr.models import OcrAnalysisOptions
from document_sdk.ocr.preprocessing import (
    _pillow_preprocessing_backend_identity,
    preprocess_local_ocr_rgb,
)
from document_sdk.ocr.preprocessing_errors import (
    LocalOcrPreprocessingConfigurationError,
    LocalOcrPreprocessingLimitError,
)
from document_sdk.ocr.preprocessing_models import (
    LOCAL_OCR_PREPROCESSING_ALGORITHM_VERSION,
    LocalOcrPreprocessingAttemptStatus,
    LocalOcrPreprocessingAttemptSummary,
    LocalOcrPreprocessingInputSummary,
    LocalOcrPreprocessingPolicy,
    LocalOcrPreprocessingProfile,
    LocalOcrPreprocessingReport,
    LocalOcrPreprocessingSelectionReason,
    local_ocr_preprocessing_policy_fingerprint,
)
from document_sdk.pdf import (
    PdfLimitExceededError,
    PdfProcessingLimits,
    PdfRenderLimitExceededError,
    inspect_pdf,
    render_page,
)
from document_sdk.providers import ProviderConfig, ProviderContext
from document_sdk.providers.metadata import ProviderMetadata

if TYPE_CHECKING:
    from collections.abc import Iterator
    from pathlib import Path

    from document_sdk.document.models import (
        DocumentEnvelope,
        DocumentTypeDetection,
    )

_LOCAL_PROVIDER_NAME = "local_ocr"
_MIN_REGION_POINTS = 4
_MAX_REGION_POINTS = 16
_POINT_COORDINATE_COUNT = 2
_UNICODE_REPLACEMENT = 0xFFFD
_SURROGATE_MIN = 0xD800
_SURROGATE_MAX = 0xDFFF
_NONCHARACTER_MIN = 0xFDD0
_NONCHARACTER_MAX = 0xFDEF
_UNICODE_MAX = 0x10FFFF
_UNICODE_PLANE_MASK = 0xFFFF
_NONCHARACTER_PLANE_SUFFIXES = frozenset({0xFFFE, 0xFFFF})
_C0_LIMIT = 0x20
_ALLOWED_C0 = frozenset({0x09, 0x0A, 0x0D})
_C1_MIN = 0x7F
_C1_MAX = 0x9F
_PRIVATE_USE_RANGES = (
    (0xE000, 0xF8FF),
    (0xF0000, 0xFFFFD),
    (0x100000, 0x10FFFD),
)

type _ExpectedRuntimeType = type[object] | tuple[type[object], ...]


def _sanitized_cause(exc: BaseException) -> Exception:
    """Create a type-only cause and scrub the retained untrusted exception."""
    cause = redacted_cause(exc)
    redact_exception(exc)
    return cause


def _raise_redacted_translation(exc: BaseException, error: Exception) -> Never:
    """Raise with a type-only cause and no reference to untrusted context."""
    cause = _sanitized_cause(exc)
    try:
        raise error from cause
    finally:
        error.__context__ = None


@dataclass(frozen=True, slots=True)
class _LocalOcrUsageBudget:
    """Private per-call ceiling used by deterministic Batch accounting."""

    operations: int
    regions: int
    pixels: int
    characters: int
    preprocessing_attempts: int = 1_000_000
    preprocessing_pixels: int = 10_000_000_000
    preprocessing_operations: int = 1_000_000


@dataclass(frozen=True, slots=True)
class _LocalOcrPreparedSource:
    """Content-free inspection evidence reusable by Local OCR routes."""

    detection: DocumentTypeDetection
    inspection: ImageInspection | PdfInspection
    snapshot_sha256: str
    snapshot_size_bytes: int
    source_kind: Literal["image", "pdf"]
    inspection_limits: ImageProcessingLimits | PdfProcessingLimits
    selected_indexes: tuple[int, ...] = ()


@dataclass(frozen=True, slots=True)
class _InputGeometry:
    """Safe pre-decode geometry for one selected frame or page."""

    width: int
    height: int
    pixel_count: int


@dataclass(frozen=True, slots=True)
class _ValidatedInput:
    """One fully bounded Engine result with single-pass text counts."""

    result: LocalOcrRawResult
    regions: int
    characters: int
    lines: int
    words: int
    quality_assessment: LocalOcrInputQualityAssessment | None = None

    def counts(self) -> dict[str, int]:
        """Return mutable counters for the existing streaming accumulator."""
        return {
            "regions": self.regions,
            "characters": self.characters,
            "lines": self.lines,
            "words": self.words,
        }


@dataclass(frozen=True, slots=True)
class _RemainingOutputBudget:
    """Remaining document-or-Batch result budgets for one Engine call."""

    regions: int
    characters: int
    lines: int
    words: int


@dataclass(slots=True)
class _TextQualityAccumulator:
    """Optional fixed-size evidence filled by the existing text scan."""

    suspicious_characters: int = 0


@dataclass(slots=True)
class _AttemptUsageTracker:
    """Accumulate content-free evidence at exact Engine boundaries."""

    provider_name: str
    profile_id: str
    model_id: str | None
    source_kind: Literal["image", "pdf"] | None = None
    submitted: list[int] = field(default_factory=list)
    returned: list[int] = field(default_factory=list)
    pixels: int = 0
    regions: int = 0
    characters: int = 0
    attempted_regions: int = 0
    attempted_characters: int = 0
    attempted_lines: int = 0
    attempted_words: int = 0
    preprocessing_attempts: int = 0
    preprocessing_operations: int = 0
    preprocessing_pixels: int = 0

    def record_submission(
        self,
        *,
        source_kind: Literal["image", "pdf"],
        index: int,
        pixel_count: int,
    ) -> None:
        """Record one actual Engine invocation immediately before it starts."""
        if self.source_kind is None:
            self.source_kind = source_kind
        elif self.source_kind != source_kind:
            msg = "Local OCR attempt usage mixed source kinds"
            raise LocalOcrInvalidResultError(msg)
        self.submitted.append(index)
        self.pixels += pixel_count

    def record_return(
        self,
        *,
        index: int,
        region_count: int,
        character_count: int,
    ) -> None:
        """Record only an Engine result that completed normalized mapping."""
        self.returned.append(index)
        self.regions += region_count
        self.characters += character_count

    def record_attempted_regions(self, count: int) -> None:
        """Record one safely counted raw Engine Region collection."""
        self.attempted_regions += count

    def record_attempted_characters(self, count: int) -> None:
        """Record one safely measured Engine text length without rereading it."""
        self.attempted_characters += count

    def record_attempted_lines_words(self, *, lines: int, words: int) -> None:
        """Record bounded text counts from one successfully validated result."""
        self.attempted_lines += lines
        self.attempted_words += words

    def record_preprocessing_attempt(self, pixel_count: int) -> None:
        """Record one retry transform before its allocation begins."""
        self.preprocessing_attempts += 1
        self.preprocessing_pixels += pixel_count

    def record_preprocessing_operation(self) -> None:
        """Record one transformed input submitted to the Engine."""
        self.preprocessing_operations += 1

    def projection(self) -> ProviderUsage | None:
        """Freeze the current content-free attempt evidence."""
        if not self.submitted or self.source_kind is None:
            return None
        is_pdf = self.source_kind == "pdf"
        return ProviderUsage(
            provider_name=self.provider_name,
            profile_id=self.profile_id,
            model_id=self.model_id,
            submitted_pages=tuple(self.submitted) if is_pdf else (),
            returned_pages=tuple(self.returned) if is_pdf else (),
            submitted_frames=tuple(self.submitted) if not is_pdf else (),
            returned_frames=tuple(self.returned) if not is_pdf else (),
            local_operation_count=len(self.submitted),
            local_page_count=len(self.submitted) if is_pdf else 0,
            local_frame_count=len(self.submitted) if not is_pdf else 0,
            local_region_count=self.regions,
            local_attempted_region_count=self.attempted_regions,
            local_input_pixel_count=self.pixels,
            local_output_character_count=self.characters,
            local_attempted_output_character_count=self.attempted_characters,
            local_preprocessing_attempt_count=self.preprocessing_attempts,
            local_preprocessing_operation_count=self.preprocessing_operations,
            local_preprocessing_pixel_count=self.preprocessing_pixels,
            azure_operation_count=0,
            paid_operation_count=0,
        )


class _NoCredentialResolver:
    """Local marker that must never be resolved by LocalOcrProvider."""

    def resolve(self) -> object:
        """Fail if another component violates the no-Credential contract."""
        msg = "Local OCR must not resolve credentials"
        raise AssertionError(msg)


class _EngineGate:
    """One adjustable strict concurrency gate shared by an Engine object."""

    __slots__ = ("__active", "__condition", "__limit")

    def __init__(self, limit: int) -> None:
        self.__active = 0
        self.__condition = Condition()
        self.__limit = limit

    def tighten(self, limit: int) -> None:
        """Apply the most restrictive limit requested by any Provider."""
        with self.__condition:
            self.__limit = min(self.__limit, limit)
            self.__condition.notify_all()

    @contextmanager
    def acquire(self) -> Iterator[None]:
        """Acquire and reliably release one Engine inference slot."""
        with self.__condition:
            while self.__active >= self.__limit:
                self.__condition.wait()
            self.__active += 1
        try:
            yield
        finally:
            with self.__condition:
                self.__active -= 1
                self.__condition.notify()


_ENGINE_GATES_LOCK = RLock()
_ENGINE_GATES: dict[int, tuple[weakref.ReferenceType[object], _EngineGate]] = {}


def _shared_engine_gate(engine: object, *, limit: int) -> _EngineGate:
    """Return a weakly retained shared gate for exactly one Engine instance."""
    key = id(engine)
    with _ENGINE_GATES_LOCK:
        existing = _ENGINE_GATES.get(key)
        if existing is not None and existing[0]() is engine:
            existing[1].tighten(limit)
            return existing[1]

        def discard(
            dead: weakref.ReferenceType[object],
            *,
            engine_id: int = key,
        ) -> None:
            with _ENGINE_GATES_LOCK:
                current = _ENGINE_GATES.get(engine_id)
                if current is not None and current[0] is dead:
                    _ENGINE_GATES.pop(engine_id, None)

        try:
            reference = weakref.ref(engine, discard)
        except TypeError as exc:
            msg = "Local OCR Engine must support weak references"
            _raise_redacted_translation(
                exc,
                LocalOcrEngineInitializationError(msg),
            )
        gate = _EngineGate(limit)
        _ENGINE_GATES[key] = (reference, gate)
        return gate


def _limit(name: str, observed: int, maximum: int) -> None:
    if observed > maximum:
        raise LocalOcrLimitExceededError(
            limit_name=name,
            observed=observed,
            maximum=maximum,
        )


def _normalized_box(
    region: LocalOcrRawRegion,
    *,
    width: int,
    height: int,
) -> BoundingBox:
    xs = tuple(point[0] for point in region.polygon)
    ys = tuple(point[1] for point in region.polygon)
    if max(xs) > width or max(ys) > height:
        msg = "Local OCR region is outside image bounds"
        raise LocalOcrInvalidResultError(msg)
    try:
        return BoundingBox(
            left=min(xs) / width,
            top=min(ys) / height,
            right=max(xs) / width,
            bottom=max(ys) / height,
        )
    except ValidationError as exc:
        msg = "Local OCR region geometry is invalid"
        _raise_redacted_translation(exc, LocalOcrInvalidResultError(msg))


def _quality_micro(value: float) -> int:
    """Quantize a validated ratio once with deterministic half-up semantics."""
    return _ratio_micro(value)


def _region_area_micro(
    region: LocalOcrRawRegion,
    *,
    width: int,
    height: int,
) -> int:
    """Return shoelace area without a pixel-sized mask or raw Polygon reread."""
    points = region.polygon
    doubled_area = 0.0
    for index, point in enumerate(points):
        next_point = points[(index + 1) % len(points)]
        if point[0] > width or point[1] > height:
            msg = "Local OCR region is outside image bounds"
            raise LocalOcrInvalidResultError(msg)
        doubled_area += point[0] * next_point[1] - next_point[0] * point[1]
    area = abs(doubled_area) / 2
    return int(area * LOCAL_OCR_QUALITY_AREA_SCALE + 0.5)


def _rgb_pixels(
    encoded: bytes,
    *,
    source_kind: Literal["image", "pdf"],
    index: int,
) -> LocalOcrImageInput:
    try:
        from PIL import Image

        with Image.open(BytesIO(encoded)) as image:
            image.load()
            if image.mode in {"RGBA", "LA"} or "transparency" in image.info:
                rgba = image.convert("RGBA")
                background = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
                background.alpha_composite(rgba)
                rgb = background.convert("RGB")
                rgba.close()
                background.close()
            else:
                rgb = image.convert("RGB")
            try:
                width, height = rgb.size
                pixels = rgb.tobytes()
            finally:
                rgb.close()
    except Exception as exc:  # noqa: BLE001 - normalization boundary is redacted.
        msg = "Local OCR image normalization failed"
        _raise_redacted_translation(exc, LocalOcrExecutionError(msg))
    return LocalOcrImageInput(
        width=width,
        height=height,
        mode="RGB",
        pixels=pixels,
        source_kind=source_kind,
        source_index=index,
    )


def _safe_actual_subclass(
    value: object,
    expected_type: _ExpectedRuntimeType,
    *,
    failure_message: str,
    initialization: bool = False,
) -> bool:
    """Check the actual runtime type without consulting ``value.__class__``."""
    try:
        actual_type = type(value)
        return issubclass(actual_type, expected_type)
    except Exception as exc:  # noqa: BLE001 - hostile runtime type boundary.
        safe_failure = _sanitized_cause(exc)
    if initialization:
        raise LocalOcrEngineInitializationError(failure_message) from safe_failure
    raise LocalOcrInvalidResultError(failure_message) from safe_failure


def _safe_sequence_type_facts(
    value: object,
    *,
    failure_message: str,
) -> tuple[bool, bool]:
    """Return safe sized-sequence and excluded scalar facts exactly once."""
    is_sequence = False
    is_sized = False
    is_excluded_scalar = False
    safe_failure: Exception | None = None
    try:
        actual_type = type(value)
        is_sequence = issubclass(actual_type, Sequence)
        is_sized = issubclass(actual_type, Sized)
        is_excluded_scalar = issubclass(
            actual_type,
            (str, bytes, bytearray),
        )
    except Exception as exc:  # noqa: BLE001 - hostile runtime type boundary.
        safe_failure = _sanitized_cause(exc)
    if safe_failure is not None:
        raise LocalOcrInvalidResultError(failure_message) from safe_failure
    return is_sequence and is_sized, is_excluded_scalar


def _engine_result(
    value: object,
) -> tuple[LocalOcrEngineResult, Sequence[object]]:
    is_result = _safe_actual_subclass(
        value,
        LocalOcrEngineResult,
        failure_message="Local OCR Engine returned an unreadable result",
    )
    if not is_result:
        msg = "Local OCR Engine returned an unsupported result container"
        raise LocalOcrInvalidResultError(msg)
    result = cast("LocalOcrEngineResult", value)
    regions_value: object = None
    safe_failure: Exception | None = None
    try:
        regions_value = result.regions
    except Exception as exc:  # noqa: BLE001 - raw Engine object boundary.
        safe_failure = _sanitized_cause(exc)
    if safe_failure is not None:
        msg = "Local OCR Engine returned an unreadable result"
        raise LocalOcrInvalidResultError(msg) from safe_failure
    is_sequence, is_excluded_scalar = _safe_sequence_type_facts(
        regions_value,
        failure_message="Local OCR Engine returned an unreadable result",
    )
    if not is_sequence or is_excluded_scalar:
        msg = "Local OCR Engine regions must be a sized sequence"
        raise LocalOcrInvalidResultError(msg)
    return result, cast("Sequence[object]", regions_value)


def _safe_region_text(
    value: object,
    *,
    attempts: _AttemptUsageTracker,
) -> tuple[str, int]:
    """Read and measure one untrusted text value exactly once for accounting."""
    is_region = _safe_actual_subclass(
        value,
        LocalOcrEngineRegion,
        failure_message="Local OCR Engine returned an unreadable region",
    )
    if not is_region:
        msg = "Local OCR Engine returned an unsupported region shape"
        raise LocalOcrInvalidResultError(msg)
    region = cast("LocalOcrEngineRegion", value)
    text_value: object | None = None
    safe_failure: Exception | None = None
    try:
        text_value = region.text
    except Exception as exc:  # noqa: BLE001 - raw Engine object boundary.
        safe_failure = _sanitized_cause(exc)
    if safe_failure is not None:
        msg = "Local OCR Engine returned an unreadable region"
        raise LocalOcrInvalidResultError(msg) from safe_failure
    is_text = _safe_actual_subclass(
        text_value,
        str,
        failure_message="Local OCR Engine returned unreadable text",
    )
    if not is_text:
        msg = "Local OCR Engine returned an invalid region"
        raise LocalOcrInvalidResultError(msg)
    text = cast("str", text_value)
    character_count: int | None = None
    try:
        character_count = str.__len__(text)
    except Exception as exc:  # noqa: BLE001 - untrusted str subclass boundary.
        safe_failure = _sanitized_cause(exc)
    if safe_failure is not None or character_count is None:
        msg = "Local OCR Engine returned unreadable text"
        raise LocalOcrInvalidResultError(msg) from safe_failure
    attempts.record_attempted_characters(character_count)
    return text, character_count


def _exact_builtin_text(text: str, *, expected_length: int) -> str:
    """Copy one bounded str subclass without invoking any overridden hook."""
    normalized: str | None = None
    safe_failure: Exception | None = None
    try:
        normalized = str.__str__(text)
    except Exception as exc:  # noqa: BLE001 - untrusted str subclass boundary.
        safe_failure = _sanitized_cause(exc)
    if safe_failure is not None or normalized is None:
        msg = "Local OCR Engine returned unreadable text"
        raise LocalOcrInvalidResultError(msg) from safe_failure
    if type(normalized) is not str or str.__len__(normalized) != expected_length:
        msg = "Local OCR Engine returned inconsistent text"
        raise LocalOcrInvalidResultError(msg)
    return normalized


def _raise_quality_evaluation_error(failure: Exception) -> Never:
    """Raise one content-free quality error from an already redacted cause."""
    msg = "Local OCR quality evaluation failed"
    raise LocalOcrQualityEvaluationError(msg) from failure


def _bounded_text_counts(  # noqa: C901, PLR0913 - explicit independent budgets.
    text: str,
    *,
    input_lines: int,
    input_words: int,
    max_input_lines: int,
    max_input_words: int,
    remaining_total_lines: int,
    remaining_total_words: int,
    quality_accumulator: _TextQualityAccumulator | None = None,
    include_private_use_characters: bool = False,
) -> tuple[int, int]:
    """Count words, lines, and enabled Unicode evidence in one bounded scan."""
    if type(text) is not str:
        msg = "Local OCR Engine text was not normalized safely"
        raise LocalOcrInvalidResultError(msg)
    lines = 1
    words = 0
    _limit("lines per input", input_lines + lines, max_input_lines)
    _limit("total lines", lines, remaining_total_lines)
    in_word = False
    safe_failure: Exception | None = None
    try:
        for character in text:
            if character == "\n":
                lines += 1
                _limit("lines per input", input_lines + lines, max_input_lines)
                _limit("total lines", lines, remaining_total_lines)
            if str.isspace(character):
                in_word = False
            elif not in_word:
                words += 1
                _limit("words per input", input_words + words, max_input_words)
                _limit("total words", words, remaining_total_words)
                in_word = True
            if quality_accumulator is not None:
                quality_failure: Exception | None = None
                suspicious = False
                try:
                    suspicious = _is_suspicious_character(
                        character,
                        include_private_use=include_private_use_characters,
                    )
                except Exception as exc:  # noqa: BLE001 - evaluator boundary.
                    quality_failure = _sanitized_cause(exc)
                if quality_failure is not None:
                    _raise_quality_evaluation_error(quality_failure)
                if suspicious:
                    quality_accumulator.suspicious_characters += 1
    except DocumentSdkError:
        raise
    except Exception as exc:  # noqa: BLE001 - untrusted str subclass boundary.
        safe_failure = _sanitized_cause(exc)
    if safe_failure is not None:
        msg = "Local OCR Engine returned unreadable text"
        raise LocalOcrInvalidResultError(msg) from safe_failure
    return lines, words


def _is_suspicious_character(
    character: str,
    *,
    include_private_use: bool,
) -> bool:
    """Classify only deterministic Unicode integrity evidence."""
    code_point = ord(character)
    if code_point == _UNICODE_REPLACEMENT or (
        _SURROGATE_MIN <= code_point <= _SURROGATE_MAX
    ):
        return True
    if _NONCHARACTER_MIN <= code_point <= _NONCHARACTER_MAX or (
        code_point <= _UNICODE_MAX
        and code_point & _UNICODE_PLANE_MASK in _NONCHARACTER_PLANE_SUFFIXES
    ):
        return True
    if (code_point < _C0_LIMIT and code_point not in _ALLOWED_C0) or (
        _C1_MIN <= code_point <= _C1_MAX
    ):
        return True
    return include_private_use and (
        any(start <= code_point <= end for start, end in _PRIVATE_USE_RANGES)
    )


def _safe_polygon_point(value: object) -> tuple[object, object]:
    """Read exactly two coordinates only after a bounded Point shape check."""
    safe_failure: Exception | None = None
    point_length: int | None = None
    is_sequence, is_excluded_scalar = _safe_sequence_type_facts(
        value,
        failure_message="Local OCR Engine returned an unreadable region point",
    )
    if not is_sequence or is_excluded_scalar:
        msg = "Local OCR Engine returned an unsupported region point"
        raise LocalOcrInvalidResultError(msg)
    try:
        point_length = len(cast("Sequence[object]", value))
    except Exception as exc:  # noqa: BLE001 - raw Point boundary.
        safe_failure = _sanitized_cause(exc)
    if safe_failure is not None:
        msg = "Local OCR Engine returned an unreadable region point"
        raise LocalOcrInvalidResultError(msg) from safe_failure
    if point_length != _POINT_COORDINATE_COUNT:
        msg = "Local OCR Engine returned an unsupported region point"
        raise LocalOcrInvalidResultError(msg)

    coordinates: tuple[object, object] | None = None
    try:
        point = cast("Sequence[object]", value)
        coordinates = (point[0], point[1])
    except Exception as exc:  # noqa: BLE001 - raw Point boundary.
        safe_failure = _sanitized_cause(exc)
    if coordinates is None:
        msg = "Local OCR Engine returned an unreadable region point"
        raise LocalOcrInvalidResultError(msg) from safe_failure
    return coordinates


def _safe_region_polygon(
    value: LocalOcrEngineRegion,
) -> tuple[tuple[object, object], ...]:
    """Read at most sixteen Points only after safely bounding Polygon length."""
    polygon_value: object | None = None
    polygon_length: int | None = None
    safe_failure: Exception | None = None
    try:
        polygon_value = cast("object", value.polygon)
    except Exception as exc:  # noqa: BLE001 - raw Polygon boundary.
        safe_failure = _sanitized_cause(exc)
    if safe_failure is not None:
        msg = "Local OCR Engine returned an unreadable region"
        raise LocalOcrInvalidResultError(msg) from safe_failure
    is_sequence, is_excluded_scalar = _safe_sequence_type_facts(
        polygon_value,
        failure_message="Local OCR Engine returned an unreadable region",
    )
    if not is_sequence or is_excluded_scalar:
        msg = "Local OCR Engine returned an unsupported region shape"
        raise LocalOcrInvalidResultError(msg)
    try:
        polygon_length = len(cast("Sequence[object]", polygon_value))
    except Exception as exc:  # noqa: BLE001 - raw Polygon boundary.
        safe_failure = _sanitized_cause(exc)
    if safe_failure is not None:
        msg = "Local OCR Engine returned an unreadable region"
        raise LocalOcrInvalidResultError(msg) from safe_failure
    if polygon_length is None or not (
        _MIN_REGION_POINTS <= polygon_length <= _MAX_REGION_POINTS
    ):
        msg = "Local OCR Engine returned an unsupported region shape"
        raise LocalOcrInvalidResultError(msg)

    points: list[tuple[object, object]] = []
    for index in range(polygon_length):
        point_value: object | None = None
        safe_failure = None
        try:
            point_value = cast("Sequence[object]", polygon_value)[index]
        except Exception as exc:  # noqa: BLE001 - raw Polygon boundary.
            safe_failure = _sanitized_cause(exc)
        if point_value is None:
            msg = "Local OCR Engine returned an unreadable region point"
            raise LocalOcrInvalidResultError(msg) from safe_failure
        points.append(_safe_polygon_point(point_value))
    return tuple(points)


def _safe_region_attributes(
    value: LocalOcrEngineRegion,
) -> tuple[object, object, object]:
    """Read remaining lightweight Region fields behind one redacted boundary."""
    confidence: object | None = None
    reading_order: object | None = None
    language: object | None = None
    safe_failure: Exception | None = None
    try:
        confidence = value.confidence
        reading_order = value.reading_order
        language = value.language
    except Exception as exc:  # noqa: BLE001 - raw Engine object boundary.
        safe_failure = _sanitized_cause(exc)
    if safe_failure is not None:
        msg = "Local OCR Engine returned an unreadable region"
        raise LocalOcrInvalidResultError(msg) from safe_failure
    return confidence, reading_order, language


def _validate_region(value: object, *, text: str) -> LocalOcrRawRegion:
    """Bound Polygon and Point shapes before indexing or Pydantic allocation."""
    is_region = _safe_actual_subclass(
        value,
        LocalOcrEngineRegion,
        failure_message="Local OCR Engine returned an unreadable region",
    )
    if not is_region:
        msg = "Local OCR Engine returned an unsupported region shape"
        raise LocalOcrInvalidResultError(msg)
    region = cast("LocalOcrEngineRegion", value)
    polygon = _safe_region_polygon(region)
    confidence, reading_order, language = _safe_region_attributes(region)

    payload = {
        "text": text,
        "polygon": polygon,
        "confidence": confidence,
        "reading_order": reading_order,
        "language": language,
    }
    validated: LocalOcrRawRegion | None = None
    safe_failure: Exception | None = None
    try:
        validated = LocalOcrRawRegion.model_validate(payload)
    except Exception as exc:  # noqa: BLE001 - validation boundary is redacted.
        safe_failure = _sanitized_cause(exc)
    if validated is None:
        msg = "Local OCR Engine returned an invalid region"
        raise LocalOcrInvalidResultError(msg) from safe_failure
    return validated


def _safe_descriptor(
    descriptor: FileDescriptor,
    envelope: DocumentEnvelope,
) -> FileDescriptor:
    """Project adapter identity back to the original safe source basename."""
    return descriptor.model_copy(
        update={
            "filename": envelope.source_name,
        }
    )


def _validated_local_engine(
    engine_object: object,
) -> tuple[LocalOcrEngine, LocalOcrEngineIdentity]:
    """Validate one caller Engine without invoking its class or recognition hook."""
    member_failure: Exception | None = None
    try:
        inspect.getattr_static(engine_object, "identity")
        inspect.getattr_static(engine_object, "recognize")
    except Exception as exc:  # noqa: BLE001 - Engine boundary is redacted.
        member_failure = _sanitized_cause(exc)
    if member_failure is not None:
        msg = "Local OCR Engine does not implement the required protocol"
        raise LocalOcrEngineInitializationError(msg) from member_failure

    validated_engine = cast("LocalOcrEngine", engine_object)
    recognize_object: object | None = None
    recognize_is_callable = False
    member_failure = None
    try:
        recognize_object = validated_engine.recognize
        recognize_is_callable = callable(recognize_object)
    except Exception as exc:  # noqa: BLE001 - Engine boundary is redacted.
        member_failure = _sanitized_cause(exc)
    if member_failure is not None or not recognize_is_callable:
        msg = "Local OCR Engine does not implement the required protocol"
        raise LocalOcrEngineInitializationError(msg) from member_failure

    identity_object: object | None = None
    identity_failure: Exception | None = None
    try:
        identity_object = validated_engine.identity
    except Exception as exc:  # noqa: BLE001 - Engine boundary is redacted.
        identity_failure = _sanitized_cause(exc)
    if identity_failure is not None:
        msg = "Local OCR Engine identity is invalid"
        raise LocalOcrEngineInitializationError(msg) from identity_failure
    is_identity = _safe_actual_subclass(
        identity_object,
        LocalOcrEngineIdentity,
        failure_message="Local OCR Engine identity is invalid",
        initialization=True,
    )
    if not is_identity:
        msg = "Local OCR Engine identity is invalid"
        raise LocalOcrEngineInitializationError(msg)

    identity: LocalOcrEngineIdentity | None = None
    try:
        identity = _revalidate_model_instance_json(
            cast("LocalOcrEngineIdentity", identity_object),
            LocalOcrEngineIdentity,
            "Local OCR Engine identity is invalid",
        )
    except Exception as exc:  # noqa: BLE001 - Engine boundary is redacted.
        identity_failure = _sanitized_cause(exc)
    if identity is None:
        msg = "Local OCR Engine identity is invalid"
        raise LocalOcrEngineInitializationError(msg) from identity_failure
    return validated_engine, identity


class LocalOcrProvider:
    """Run an explicit caller-supplied Local OCR Engine without credentials."""

    __slots__ = (
        "__context",
        "__engine",
        "__gate",
        "__identity",
        "__limits",
        "__preprocessing_policy",
        "__quality_policy",
    )

    def __init__(
        self,
        *,
        engine: LocalOcrEngine,
        profile_id: str = "local-default",
        limits: LocalOcrProcessingLimits | None = None,
        quality_policy: LocalOcrIntrinsicQualityPolicy | None = None,
        preprocessing_policy: LocalOcrPreprocessingPolicy | None = None,
    ) -> None:
        """Bind one runtime Engine instance and immutable safe identity."""
        try:
            effective_limits = (
                LocalOcrProcessingLimits()
                if limits is None
                else _revalidate_model_instance_json(
                    limits,
                    LocalOcrProcessingLimits,
                    "Local OCR processing limits are invalid",
                )
            )
        except Exception as exc:  # noqa: BLE001 - caller boundary is redacted.
            msg = "Local OCR processing limits are invalid"
            _raise_redacted_translation(
                exc,
                LocalOcrEngineInitializationError(msg),
            )
        effective_quality_policy: LocalOcrIntrinsicQualityPolicy | None = None
        quality_configuration_failure: Exception | None = None
        try:
            effective_quality_policy = (
                None
                if quality_policy is None
                else _revalidate_model_instance_json(
                    quality_policy,
                    LocalOcrIntrinsicQualityPolicy,
                    "Local OCR quality policy is invalid",
                )
            )
        except Exception as exc:  # noqa: BLE001 - caller boundary is redacted.
            quality_configuration_failure = _sanitized_cause(exc)
        if quality_configuration_failure is not None:
            msg = "Local OCR quality policy is invalid"
            raise LocalOcrQualityConfigurationError(
                msg
            ) from quality_configuration_failure
        try:
            effective_preprocessing_policy = (
                LocalOcrPreprocessingPolicy()
                if preprocessing_policy is None
                else _revalidate_model_instance_json(
                    preprocessing_policy,
                    LocalOcrPreprocessingPolicy,
                    "Local OCR preprocessing policy is invalid",
                )
            )
        except Exception as exc:  # noqa: BLE001 - caller boundary is redacted.
            msg = "Local OCR preprocessing policy is invalid"
            _raise_redacted_translation(
                exc,
                LocalOcrPreprocessingConfigurationError(msg),
            )
        if effective_preprocessing_policy.enabled and effective_quality_policy is None:
            msg = "Local OCR preprocessing requires an intrinsic quality policy"
            raise LocalOcrPreprocessingConfigurationError(msg)
        preprocessing_attributes: dict[str, JsonValue] = {}
        if effective_preprocessing_policy.enabled:
            preprocessing_attributes = {
                "preprocessing_algorithm_version": (
                    LOCAL_OCR_PREPROCESSING_ALGORITHM_VERSION
                ),
                "preprocessing_backend_identity": (
                    _pillow_preprocessing_backend_identity()
                ),
                "preprocessing_policy_fingerprint": (
                    local_ocr_preprocessing_policy_fingerprint(
                        effective_preprocessing_policy
                    )
                ),
            }
        engine_object: object = engine
        validated_engine, identity = _validated_local_engine(engine_object)
        gate_limit = (
            1
            if identity.thread_safety == "serialized"
            else effective_limits.max_concurrent_inferences
        )
        limits_fingerprint = hashlib.sha256(
            effective_limits.model_dump_json().encode()
        ).hexdigest()
        identity_payload = identity.model_dump(mode="json")
        config = ProviderConfig(
            provider_name=_LOCAL_PROVIDER_NAME,
            profile_id=profile_id,
            model_id=identity.model_id,
        )
        quality_attributes: dict[str, JsonValue] = {}
        if effective_quality_policy is not None:
            complete_quality_policy = LocalOcrQualityPolicy(
                intrinsic=effective_quality_policy
            )
            quality_attributes = {
                "quality_algorithm_version": (LOCAL_OCR_QUALITY_ALGORITHM_VERSION),
                "quality_identity": local_ocr_quality_identity(
                    intrinsic_policy=effective_quality_policy,
                    structured_policy=None,
                ),
                "quality_policy_fingerprint": (
                    local_ocr_quality_policy_fingerprint(complete_quality_policy)
                ),
            }
        metadata = ProviderMetadata(
            provider_name=_LOCAL_PROVIDER_NAME,
            profile_id=profile_id,
            model_id=identity.model_id,
            attributes={
                **identity_payload,
                "limits_fingerprint": limits_fingerprint,
                "preprocessing": "exif_oriented_rgb_white_alpha",
                **quality_attributes,
                **preprocessing_attributes,
            },
        )
        self.__context = ProviderContext(
            profile_id=profile_id,
            config=config,
            credential_resolver=_NoCredentialResolver(),
            metadata=metadata,
        )
        self.__engine = validated_engine
        self.__identity = identity
        self.__limits = effective_limits
        self.__preprocessing_policy = effective_preprocessing_policy
        self.__quality_policy = effective_quality_policy
        self.__gate = _shared_engine_gate(validated_engine, limit=gate_limit)

    @property
    def context(self) -> ProviderContext:
        """Return immutable non-secret Local Provider context metadata."""
        return self.__context

    @property
    def engine_identity(self) -> LocalOcrEngineIdentity:
        """Return stable Resume-compatible Engine identity."""
        return self.__identity

    @property
    def limits(self) -> LocalOcrProcessingLimits:
        """Return immutable Local OCR processing limits."""
        return self.__limits

    @property
    def quality_policy(self) -> LocalOcrIntrinsicQualityPolicy | None:
        """Return the explicit intrinsic policy, or ``None`` when disabled."""
        return self.__quality_policy

    @property
    def preprocessing_policy(self) -> LocalOcrPreprocessingPolicy:
        """Return the validated explicit preprocessing policy."""
        return self.__preprocessing_policy

    def _call_engine(self, image: LocalOcrImageInput) -> object:
        """Treat every exception raised during caller Engine code as untrusted."""
        safe_failure: Exception | None = None
        try:
            with self.__gate.acquire():
                return self.__engine.recognize(image)
        except Exception as exc:  # noqa: BLE001 - third-party boundary.
            safe_failure = _sanitized_cause(exc)
        msg = "Local OCR Engine execution failed"
        raise LocalOcrExecutionError(msg) from safe_failure

    def _validated_result(  # noqa: C901, PLR0912, PLR0913, PLR0915
        self,
        value: object,
        *,
        remaining: _RemainingOutputBudget,
        attempts: _AttemptUsageTracker,
        source_kind: Literal["image", "pdf"],
        source_index: int,
        width: int,
        height: int,
        quality_policy: LocalOcrIntrinsicQualityPolicy | None,
    ) -> _ValidatedInput:
        """Bound raw collection and text before Polygon or model allocation."""
        _, raw_regions = _engine_result(value)
        safe_failure: Exception | None = None
        region_count: int | None = None
        try:
            region_count = len(raw_regions)
        except Exception as exc:  # noqa: BLE001 - raw Sequence boundary.
            safe_failure = _sanitized_cause(exc)
        if region_count is None:
            msg = "Local OCR Engine regions could not be counted safely"
            raise LocalOcrInvalidResultError(msg) from safe_failure
        attempts.record_attempted_regions(region_count)
        _limit(
            "regions per input",
            region_count,
            self.__limits.max_regions_per_input,
        )
        _limit("total regions", region_count, remaining.regions)
        regions_list: list[LocalOcrRawRegion] = []
        input_characters = 0
        input_lines = 0
        input_words = 0
        confidence_weighted_characters = 0
        low_confidence_characters = 0
        suspicious_characters = 0
        summed_region_area = 0
        low_confidence_micro = (
            None
            if quality_policy is None or quality_policy.low_confidence_threshold is None
            else _quality_micro(quality_policy.low_confidence_threshold)
        )
        for index in range(region_count):
            safe_failure = None
            region: object | None = None
            try:
                region = raw_regions[index]
            except Exception as exc:  # noqa: BLE001 - raw Sequence boundary.
                safe_failure = _sanitized_cause(exc)
            if region is None:
                msg = "Local OCR Engine regions could not be read safely"
                raise LocalOcrInvalidResultError(msg) from safe_failure
            text, character_count = _safe_region_text(region, attempts=attempts)
            _limit(
                "region characters",
                character_count,
                self.__limits.max_region_characters,
            )
            next_input_characters = input_characters + character_count
            _limit(
                "text characters per input",
                next_input_characters,
                self.__limits.max_text_characters_per_input,
            )
            _limit(
                "total text characters",
                next_input_characters,
                remaining.characters,
            )
            text = _exact_builtin_text(
                text,
                expected_length=character_count,
            )
            text_quality = None if quality_policy is None else _TextQualityAccumulator()
            region_lines, region_words = _bounded_text_counts(
                text,
                input_lines=input_lines,
                input_words=input_words,
                max_input_lines=self.__limits.max_lines_per_input,
                max_input_words=self.__limits.max_words_per_input,
                remaining_total_lines=remaining.lines - input_lines,
                remaining_total_words=remaining.words - input_words,
                quality_accumulator=text_quality,
                include_private_use_characters=(
                    quality_policy is not None
                    and quality_policy.include_private_use_characters
                ),
            )
            validated_region = _validate_region(region, text=text)
            regions_list.append(validated_region)
            if quality_policy is not None:
                quality_failure = None
                try:
                    confidence_micro = _quality_micro(validated_region.confidence)
                    confidence_weighted_characters += confidence_micro * character_count
                    if (
                        low_confidence_micro is not None
                        and confidence_micro < low_confidence_micro
                    ):
                        low_confidence_characters += character_count
                    if text_quality is not None:
                        suspicious_characters += text_quality.suspicious_characters
                    summed_region_area += _region_area_micro(
                        validated_region,
                        width=width,
                        height=height,
                    )
                except DocumentSdkError:
                    raise
                except Exception as exc:  # noqa: BLE001 - evaluator boundary.
                    quality_failure = _sanitized_cause(exc)
                if quality_failure is not None:
                    _raise_quality_evaluation_error(quality_failure)
            input_characters = next_input_characters
            input_lines += region_lines
            input_words += region_words
        regions = tuple(regions_list)
        validated: LocalOcrRawResult | None = None
        safe_failure = None
        try:
            validated = LocalOcrRawResult(regions=regions)
        except Exception as exc:  # noqa: BLE001 - validation boundary is redacted.
            safe_failure = _sanitized_cause(exc)
        if validated is None:
            msg = "Local OCR Engine returned inconsistent reading order"
            raise LocalOcrInvalidResultError(msg) from safe_failure
        quality_assessment: LocalOcrInputQualityAssessment | None = None
        if quality_policy is not None:
            denominator = width * height * LOCAL_OCR_QUALITY_AREA_SCALE
            quality_failure = None
            try:
                quality_assessment = create_local_ocr_input_quality_assessment(
                    policy=quality_policy,
                    source_kind=source_kind,
                    source_index=source_index,
                    character_count=input_characters,
                    region_count=region_count,
                    confidence_weighted_character_count=(
                        confidence_weighted_characters
                    ),
                    low_confidence_character_count=low_confidence_characters,
                    suspicious_character_count=suspicious_characters,
                    region_area_numerator=min(summed_region_area, denominator),
                    region_area_denominator=denominator,
                )
            except Exception as exc:  # noqa: BLE001 - quality boundary is redacted.
                quality_failure = _sanitized_cause(exc)
            if quality_failure is not None:
                _raise_quality_evaluation_error(quality_failure)
        return _ValidatedInput(
            result=validated,
            regions=region_count,
            characters=input_characters,
            lines=input_lines,
            words=input_words,
            quality_assessment=quality_assessment,
        )

    def analyze(
        self,
        path: Path,
        *,
        options: OcrAnalysisOptions | None = None,
    ) -> ProcessingResult[Document]:
        """Stream selected image frames or PDF pages through runtime pixels."""
        return self._analyze_bounded(path, options=options, usage_budget=None)

    def _analyze_bounded(
        self,
        path: Path,
        *,
        options: OcrAnalysisOptions | None,
        usage_budget: _LocalOcrUsageBudget | None,
        enable_quality: bool = False,
    ) -> ProcessingResult[Document]:
        """Apply an optional private Batch budget without changing public API."""
        started = perf_counter()
        effective_options = self._validated_options(options)
        quality_policy = self._effective_quality_policy(enable_quality=enable_quality)
        return self._analyze_request(
            path,
            prepared_source=None,
            options=effective_options,
            usage_budget=usage_budget,
            quality_policy=quality_policy,
            started=started,
        )

    def _analyze_prepared(
        self,
        path: Path,
        prepared_source: _LocalOcrPreparedSource,
        *,
        options: OcrAnalysisOptions | None,
        usage_budget: _LocalOcrUsageBudget | None,
        enable_quality: bool = False,
    ) -> ProcessingResult[Document]:
        """Analyze already inspected same-byte evidence without reinspection."""
        started = perf_counter()
        effective_options = self._validated_options(options)
        quality_policy = self._effective_quality_policy(enable_quality=enable_quality)
        return self._analyze_request(
            path,
            prepared_source=prepared_source,
            options=effective_options,
            usage_budget=usage_budget,
            quality_policy=quality_policy,
            started=started,
        )

    def _effective_quality_policy(
        self,
        *,
        enable_quality: object,
    ) -> LocalOcrIntrinsicQualityPolicy | None:
        """Enable empty intrinsic evidence only for an explicit higher-layer gate."""
        if type(enable_quality) is not bool:
            msg = "Local OCR quality enablement is invalid"
            raise LocalOcrQualityConfigurationError(msg)
        if self.__quality_policy is not None:
            return self.__quality_policy
        return LocalOcrIntrinsicQualityPolicy() if enable_quality else None

    def _validated_options(
        self,
        options: OcrAnalysisOptions | None,
    ) -> OcrAnalysisOptions:
        """Validate caller options before identity, inspection, or Engine work."""
        try:
            effective_options = (
                OcrAnalysisOptions()
                if options is None
                else _revalidate_model_instance_json(
                    options,
                    OcrAnalysisOptions,
                    "Local OCR analysis options are invalid",
                )
            )
        except Exception as exc:  # noqa: BLE001 - caller boundary is redacted.
            msg = "Local OCR analysis options are invalid"
            _raise_redacted_translation(exc, LocalOcrInvalidResultError(msg))
        if effective_options.features or effective_options.query_fields:
            msg = "Local OCR does not support Provider analysis features"
            raise LocalOcrInvalidResultError(msg)
        if effective_options.locale is not None:
            msg = "Local OCR does not support per-call locale selection"
            raise LocalOcrInvalidResultError(msg)
        return effective_options

    def _analyze_request(  # noqa: PLR0913
        self,
        path: Path,
        *,
        prepared_source: _LocalOcrPreparedSource | None,
        options: OcrAnalysisOptions,
        usage_budget: _LocalOcrUsageBudget | None,
        quality_policy: LocalOcrIntrinsicQualityPolicy | None,
        started: float,
    ) -> ProcessingResult[Document]:
        """Retain sanitized attempt evidence around one Local OCR request."""
        metadata = self.__context.metadata
        attempts = _AttemptUsageTracker(
            provider_name=metadata.provider_name,
            profile_id=metadata.profile_id,
            model_id=metadata.model_id,
        )
        try:
            if prepared_source is None:
                return self._analyze_effective(
                    path,
                    options=options,
                    usage_budget=usage_budget,
                    quality_policy=quality_policy,
                    attempts=attempts,
                    started=started,
                )
            return self._analyze_prepared_effective(
                path,
                prepared_source=prepared_source,
                options=options,
                usage_budget=usage_budget,
                quality_policy=quality_policy,
                attempts=attempts,
                started=started,
            )
        except Exception as exc:
            _attach_attempt_usage(exc, attempts.projection())
            raise

    def _analyze_effective(  # noqa: PLR0913
        self,
        path: Path,
        *,
        options: OcrAnalysisOptions,
        usage_budget: _LocalOcrUsageBudget | None,
        quality_policy: LocalOcrIntrinsicQualityPolicy | None,
        attempts: _AttemptUsageTracker,
        started: float,
    ) -> ProcessingResult[Document]:
        """Analyze one already validated request and retain attempt evidence."""
        from document_sdk.document import DocumentType
        from document_sdk.document.processing import (
            _adapter_path,
            _assert_source_unchanged,
            _detect_identity,
        )

        detection = _detect_identity(path)
        envelope = detection.envelope
        if envelope.document_type not in {DocumentType.PDF, DocumentType.IMAGE}:
            msg = "Local OCR supports only PDF and image content"
            raise LocalOcrUnsupportedInputError(msg)

        with _adapter_path(
            path,
            envelope.document_format,
            envelope.sha256,
            envelope.byte_size,
            always_snapshot=True,
        ) as adapter:
            _assert_source_unchanged(path, envelope)
            prepared_source = self._prepare_source(
                adapter,
                detection,
                limits=None,
            )
            result = self._analyze_prepared_effective(
                adapter,
                prepared_source=prepared_source,
                options=options,
                usage_budget=usage_budget,
                quality_policy=quality_policy,
                attempts=attempts,
                started=started,
            )
        _assert_source_unchanged(path, envelope)
        return result

    def _prepare_source(
        self,
        path: Path,
        detection: DocumentTypeDetection,
        *,
        limits: ImageProcessingLimits | PdfProcessingLimits | None,
    ) -> _LocalOcrPreparedSource:
        """Inspect one supported source once using Local-aware source limits."""
        from document_sdk.document import DocumentFormat, DocumentType
        from document_sdk.document.processing import (
            _adapter_path,
            _assert_source_unchanged,
            _normalize_image,
            _normalize_pdf,
        )

        envelope = detection.envelope
        if envelope.document_type not in {DocumentType.PDF, DocumentType.IMAGE}:
            msg = "Local OCR supports only PDF and image content"
            raise LocalOcrUnsupportedInputError(msg)
        _assert_source_unchanged(path, envelope)
        if envelope.document_type is DocumentType.PDF:
            if limits is not None and not isinstance(limits, PdfProcessingLimits):
                msg = "Local OCR source limits do not match PDF content"
                raise LocalOcrInvalidResultError(msg)
            pdf_limits = self._effective_pdf_limits(limits)
            try:
                with _adapter_path(
                    path,
                    envelope.document_format,
                    envelope.sha256,
                    envelope.byte_size,
                ) as adapter:
                    inspection: ImageInspection | PdfInspection = _normalize_pdf(
                        inspect_pdf(adapter, limits=pdf_limits),
                        envelope,
                    )
            except PdfLimitExceededError as exc:
                _raise_redacted_translation(
                    exc,
                    LocalOcrLimitExceededError(
                        limit_name=exc.limit_name,
                        observed=math.ceil(exc.observed),
                        maximum=math.floor(exc.maximum),
                    ),
                )
            source_kind: Literal["image", "pdf"] = "pdf"
            inspection_limits: ImageProcessingLimits | PdfProcessingLimits = pdf_limits
        else:
            if limits is not None and not isinstance(limits, ImageProcessingLimits):
                msg = "Local OCR source limits do not match image content"
                raise LocalOcrInvalidResultError(msg)
            image_limits = self._effective_image_limits(limits)
            try:
                with _adapter_path(
                    path,
                    envelope.document_format,
                    envelope.sha256,
                    envelope.byte_size,
                ) as adapter:
                    raw_image = inspect_image(
                        adapter,
                        limits=image_limits,
                        verify_decode=False,
                    )
            except ImageLimitExceededError as exc:
                _raise_redacted_translation(
                    exc,
                    LocalOcrLimitExceededError(
                        limit_name=exc.limit_name,
                        observed=exc.observed,
                        maximum=exc.maximum,
                    ),
                )
            inspection = _normalize_image(raw_image, envelope)
            expected_format = {
                "PNG": DocumentFormat.PNG,
                "JPEG": DocumentFormat.JPEG,
                "TIFF": DocumentFormat.TIFF,
                "WEBP": DocumentFormat.WEBP,
                "BMP": DocumentFormat.BMP,
            }[inspection.format]
            if expected_format is not envelope.document_format:
                msg = "Local OCR image format evidence is inconsistent"
                raise LocalOcrUnsupportedInputError(msg)
            source_kind = "image"
            inspection_limits = image_limits
        _assert_source_unchanged(path, envelope)
        descriptor = inspection.file
        prepared_source = _LocalOcrPreparedSource(
            detection=detection,
            inspection=inspection,
            snapshot_sha256=descriptor.fingerprint.value,
            snapshot_size_bytes=descriptor.size_bytes,
            source_kind=source_kind,
            inspection_limits=inspection_limits,
        )
        self._validate_prepared_source(prepared_source)
        return prepared_source

    def _validate_prepared_source(
        self,
        prepared_source: _LocalOcrPreparedSource,
    ) -> None:
        """Require exact identity, byte size, format, and inspection family."""
        from document_sdk.document import DocumentFormat, DocumentType

        envelope = prepared_source.detection.envelope
        descriptor = prepared_source.inspection.file
        if (
            prepared_source.snapshot_sha256 != envelope.sha256
            or prepared_source.snapshot_size_bytes != envelope.byte_size
            or descriptor.fingerprint.value != envelope.sha256
            or descriptor.size_bytes != envelope.byte_size
        ):
            msg = "Local OCR prepared source identity is inconsistent"
            raise LocalOcrInvalidResultError(msg)
        if prepared_source.source_kind == "pdf":
            valid = (
                envelope.document_type is DocumentType.PDF
                and envelope.document_format is DocumentFormat.PDF
                and isinstance(prepared_source.inspection, PdfInspection)
                and isinstance(prepared_source.inspection_limits, PdfProcessingLimits)
            )
        else:
            image_format = (
                None
                if not isinstance(prepared_source.inspection, ImageInspection)
                else {
                    "PNG": DocumentFormat.PNG,
                    "JPEG": DocumentFormat.JPEG,
                    "TIFF": DocumentFormat.TIFF,
                    "WEBP": DocumentFormat.WEBP,
                    "BMP": DocumentFormat.BMP,
                }.get(prepared_source.inspection.format)
            )
            valid = (
                envelope.document_type is DocumentType.IMAGE
                and image_format is envelope.document_format
                and isinstance(prepared_source.inspection_limits, ImageProcessingLimits)
            )
        if not valid:
            msg = "Local OCR prepared source format is inconsistent"
            raise LocalOcrInvalidResultError(msg)

    def _analyze_prepared_effective(  # noqa: PLR0913
        self,
        path: Path,
        *,
        prepared_source: _LocalOcrPreparedSource,
        options: OcrAnalysisOptions,
        usage_budget: _LocalOcrUsageBudget | None,
        quality_policy: LocalOcrIntrinsicQualityPolicy | None,
        attempts: _AttemptUsageTracker,
        started: float,
    ) -> ProcessingResult[Document]:
        """Select and process one exact prepared source without reinspection."""
        from document_sdk.document.processing import _assert_source_unchanged

        self._validate_prepared_source(prepared_source)
        envelope = prepared_source.detection.envelope
        _assert_source_unchanged(path, envelope)
        operation_limit = self.__limits.max_operations
        if usage_budget is not None:
            operation_limit = min(operation_limit, usage_budget.operations)
        if prepared_source.source_kind == "pdf":
            descriptor, selected, pdf_limits, geometries = self._pdf_selection(
                cast("PdfInspection", prepared_source.inspection),
                cast("PdfProcessingLimits", prepared_source.inspection_limits),
                options,
                operation_limit=operation_limit,
            )
            image_limits = None
            source_kind: Literal["pdf", "image"] = "pdf"
        else:
            descriptor, selected, image_limits, geometries = self._image_selection(
                cast("ImageInspection", prepared_source.inspection),
                cast("ImageProcessingLimits", prepared_source.inspection_limits),
                options,
                operation_limit=operation_limit,
            )
            pdf_limits = None
            source_kind = "image"
        selected_source = replace(
            prepared_source,
            selected_indexes=selected,
        )
        self._validate_prepared_source(selected_source)
        descriptor = _safe_descriptor(descriptor, envelope)
        (
            pages,
            totals,
            quality_assessments,
            original_quality_assessments,
            preprocessing_attempts,
            preprocessing_inputs,
        ) = self._process_selected(
            path,
            descriptor=descriptor,
            source_kind=source_kind,
            selected=selected_source.selected_indexes,
            geometries=geometries,
            image_limits=image_limits,
            pdf_limits=pdf_limits,
            usage_budget=usage_budget,
            quality_policy=quality_policy,
            attempts=attempts,
        )
        _assert_source_unchanged(path, envelope)
        return self._result(
            descriptor,
            pages=pages,
            totals=totals,
            quality_assessments=quality_assessments,
            original_quality_assessments=original_quality_assessments,
            preprocessing_attempts=preprocessing_attempts,
            preprocessing_inputs=preprocessing_inputs,
            quality_policy=quality_policy,
            usage=attempts.projection(),
            started=started,
        )

    def _effective_image_limits(
        self,
        requested: ImageProcessingLimits | None = None,
    ) -> ImageProcessingLimits:
        """Map Local limits to metadata inspection and one-frame encoding."""
        defaults = ImageProcessingLimits()
        local_limits = ImageProcessingLimits(
            max_frames=self.__limits.max_source_image_frames,
            max_pixels_per_frame=(self.__limits.max_source_image_pixels_per_frame),
            max_total_pixels=(self.__limits.max_source_image_total_metadata_pixels),
            max_working_pixels=self.__limits.max_pixels_per_input,
            max_output_bytes=defaults.max_output_bytes,
            max_output_width=self.__limits.max_width,
            max_output_height=self.__limits.max_height,
        )
        if requested is None:
            return local_limits
        return local_limits.model_copy(
            update={
                name: min(getattr(local_limits, name), getattr(requested, name))
                for name in type(local_limits).model_fields
            }
        )

    def _effective_pdf_limits(
        self,
        requested: PdfProcessingLimits | None = None,
    ) -> PdfProcessingLimits:
        """Map Local page and render-allocation limits to PDF preflight."""
        local_limits = PdfProcessingLimits(
            max_pages=self.__limits.max_source_pdf_pages,
            max_native_text_pages=self.__limits.max_source_pdf_pages,
            max_render_dpi=self.__limits.pdf_render_dpi,
            max_render_width=self.__limits.max_width,
            max_render_height=self.__limits.max_height,
            max_render_pixels=self.__limits.max_pixels_per_input,
        )
        if requested is None:
            return local_limits
        return local_limits.model_copy(
            update={
                name: min(getattr(local_limits, name), getattr(requested, name))
                for name in type(local_limits).model_fields
            }
        )

    def _image_selection(
        self,
        inspection: ImageInspection,
        limits: ImageProcessingLimits,
        options: OcrAnalysisOptions,
        *,
        operation_limit: int,
    ) -> tuple[
        FileDescriptor,
        tuple[int, ...],
        ImageProcessingLimits,
        dict[int, _InputGeometry],
    ]:
        available = tuple(range(1, inspection.frame_count + 1))
        selected = available if options.pages is None else options.pages
        if any(frame not in available for frame in selected):
            msg = "Local OCR frame selection is invalid"
            raise LocalOcrInvalidResultError(msg)
        _limit("frame count", len(selected), self.__limits.max_frames)
        _limit("operation count", len(selected), operation_limit)
        geometries: dict[int, _InputGeometry] = {}
        for frame_number in selected:
            frame = inspection.frames[frame_number - 1]
            width, height = frame.width, frame.height
            if frame.exif_orientation in {5, 6, 7, 8}:
                width, height = height, width
            geometry = _InputGeometry(
                width=width,
                height=height,
                pixel_count=frame.pixel_count,
            )
            self._preflight_geometry(geometry)
            geometries[frame_number] = geometry
        return inspection.file, selected, limits, geometries

    def _pdf_selection(
        self,
        inspection: PdfInspection,
        limits: PdfProcessingLimits,
        options: OcrAnalysisOptions,
        *,
        operation_limit: int,
    ) -> tuple[
        FileDescriptor,
        tuple[int, ...],
        PdfProcessingLimits,
        dict[int, _InputGeometry],
    ]:
        selected = (
            tuple(range(1, inspection.page_count + 1))
            if options.pages is None
            else options.pages
        )
        if any(page > inspection.page_count for page in selected):
            msg = "Local OCR PDF page selection is invalid"
            raise LocalOcrInvalidResultError(msg)
        _limit("page count", len(selected), self.__limits.max_pages)
        _limit("operation count", len(selected), operation_limit)
        geometries: dict[int, _InputGeometry] = {}
        scale = self.__limits.pdf_render_dpi / 72
        for page_number in selected:
            page = inspection.pages[page_number - 1]
            width_points = page.dimensions.width
            height_points = page.dimensions.height
            if page.dimensions.rotation in {90, 270}:
                width_points, height_points = height_points, width_points
            width = math.ceil(width_points * scale)
            height = math.ceil(height_points * scale)
            geometries[page_number] = _InputGeometry(
                width=width,
                height=height,
                pixel_count=width * height,
            )
        return inspection.file, selected, limits, geometries

    def _preflight_geometry(self, geometry: _InputGeometry) -> None:
        """Reject one selected allocation using metadata-only dimensions."""
        _limit("width", geometry.width, self.__limits.max_width)
        _limit("height", geometry.height, self.__limits.max_height)
        _limit(
            "pixels per input",
            geometry.pixel_count,
            self.__limits.max_pixels_per_input,
        )

    def _decode_input(  # noqa: PLR0913 - explicit route preparation inputs.
        self,
        path: Path,
        *,
        source_kind: Literal["image", "pdf"],
        index: int,
        image_limits: ImageProcessingLimits | None,
        pdf_limits: PdfProcessingLimits | None,
        image_stream: _ImageFramePixelStream | None,
    ) -> tuple[str, str | None, int | None, LocalOcrImageInput]:
        try:
            if source_kind == "pdf":
                if pdf_limits is None:
                    msg = "Local OCR PDF limits are unavailable"
                    raise LocalOcrInvalidResultError(msg)
                rendered = render_page(
                    path,
                    index,
                    dpi=self.__limits.pdf_render_dpi,
                    limits=pdf_limits,
                )
                file_id = rendered.source.file_id
                fingerprint = None
                size_bytes = None
                image = _rgb_pixels(
                    rendered.image_bytes,
                    source_kind="pdf",
                    index=index,
                )
            else:
                if image_limits is None:
                    msg = "Local OCR image limits are unavailable"
                    raise LocalOcrInvalidResultError(msg)
                decoded = _read_image_frame_pixels(
                    path,
                    index,
                    normalize_orientation=True,
                    limits=image_limits,
                    _pixel_stream=image_stream,
                )
                file_id = decoded.source.file_id
                fingerprint = decoded.descriptor.fingerprint.value
                size_bytes = decoded.descriptor.size_bytes
                image = LocalOcrImageInput(
                    width=decoded.width,
                    height=decoded.height,
                    mode=decoded.mode,
                    pixels=decoded.pixels,
                    source_kind="image",
                    source_index=index,
                )
        except ImageLimitExceededError as exc:
            _raise_redacted_translation(
                exc,
                LocalOcrLimitExceededError(
                    limit_name=exc.limit_name,
                    observed=exc.observed,
                    maximum=exc.maximum,
                ),
            )
        except PdfRenderLimitExceededError as exc:
            _raise_redacted_translation(
                exc,
                LocalOcrLimitExceededError(
                    limit_name=exc.limit_name,
                    observed=math.ceil(exc.observed),
                    maximum=math.floor(exc.maximum),
                ),
            )
        except LocalOcrLimitExceededError:
            raise
        except DocumentSdkError as exc:
            from document_sdk.document.errors import DocumentSourceChangedError

            if isinstance(exc, DocumentSourceChangedError):
                raise
            msg = "Local OCR input preparation failed"
            _raise_redacted_translation(exc, LocalOcrExecutionError(msg))
        return file_id, fingerprint, size_bytes, image

    def _process_selected(  # noqa: C901, PLR0912, PLR0913, PLR0915
        self,
        path: Path,
        *,
        descriptor: FileDescriptor,
        source_kind: Literal["image", "pdf"],
        selected: tuple[int, ...],
        geometries: dict[int, _InputGeometry],
        image_limits: ImageProcessingLimits | None,
        pdf_limits: PdfProcessingLimits | None,
        usage_budget: _LocalOcrUsageBudget | None,
        quality_policy: LocalOcrIntrinsicQualityPolicy | None,
        attempts: _AttemptUsageTracker,
        image_stream: _ImageFramePixelStream | None = None,
    ) -> tuple[
        tuple[DocumentPage, ...],
        dict[str, int],
        tuple[LocalOcrInputQualityAssessment, ...],
        tuple[LocalOcrInputQualityAssessment, ...],
        tuple[LocalOcrPreprocessingAttemptSummary, ...],
        tuple[LocalOcrPreprocessingInputSummary, ...],
    ]:
        if source_kind == "image" and image_stream is None:
            if image_limits is None:
                msg = "Local OCR image limits are unavailable"
                raise LocalOcrInvalidResultError(msg)
            try:
                with _open_image_frame_pixel_stream(
                    path,
                    descriptor=descriptor,
                    selected_frame_numbers=selected,
                    normalize_orientation=True,
                    limits=image_limits,
                ) as verified_stream:
                    return self._process_selected(
                        path,
                        descriptor=descriptor,
                        source_kind=source_kind,
                        selected=selected,
                        geometries=geometries,
                        image_limits=image_limits,
                        pdf_limits=pdf_limits,
                        usage_budget=usage_budget,
                        quality_policy=quality_policy,
                        attempts=attempts,
                        image_stream=verified_stream,
                    )
            except _ImageSourceIdentityMismatchError as exc:
                from document_sdk.document.errors import DocumentSourceChangedError

                msg = "The Local OCR source changed during input preparation"
                _raise_redacted_translation(exc, DocumentSourceChangedError(msg))

        totals = {
            "pixels": 0,
            "regions": 0,
            "characters": 0,
            "lines": 0,
            "words": 0,
        }
        total_pixel_limit = self.__limits.max_total_pixels
        total_region_limit = self.__limits.max_total_regions
        total_character_limit = self.__limits.max_total_text_characters
        operation_limit = self.__limits.max_operations
        if usage_budget is not None:
            operation_limit = min(operation_limit, usage_budget.operations)
            total_pixel_limit = min(total_pixel_limit, usage_budget.pixels)
            total_region_limit = min(total_region_limit, usage_budget.regions)
            total_character_limit = min(
                total_character_limit,
                usage_budget.characters,
            )
        pages: list[DocumentPage] = []
        quality_assessments: list[LocalOcrInputQualityAssessment] = []
        original_quality_assessments: list[LocalOcrInputQualityAssessment] = []
        preprocessing_attempt_summaries: list[LocalOcrPreprocessingAttemptSummary] = []
        preprocessing_input_summaries: list[LocalOcrPreprocessingInputSummary] = []
        for index in selected:
            geometry = geometries[index]
            self._preflight_geometry(geometry)
            _limit(
                "total pixels",
                attempts.pixels + geometry.pixel_count,
                total_pixel_limit,
            )
            effective_pdf_limits = pdf_limits
            if effective_pdf_limits is not None:
                remaining_pixels = total_pixel_limit - attempts.pixels
                effective_pdf_limits = effective_pdf_limits.model_copy(
                    update={
                        "max_render_pixels": min(
                            self.__limits.max_pixels_per_input,
                            remaining_pixels,
                        )
                    }
                )
            file_id, fingerprint, size_bytes, image = self._decode_input(
                path,
                source_kind=source_kind,
                index=index,
                image_limits=image_limits,
                pdf_limits=effective_pdf_limits,
                image_stream=image_stream,
            )
            if file_id != descriptor.file_id or (
                fingerprint is not None
                and (
                    fingerprint != descriptor.fingerprint.value
                    or size_bytes != descriptor.size_bytes
                )
            ):
                from document_sdk.document.errors import DocumentSourceChangedError

                msg = "The Local OCR source changed during input preparation"
                raise DocumentSourceChangedError(msg)
            _limit("width", image.width, self.__limits.max_width)
            _limit("height", image.height, self.__limits.max_height)
            input_pixels = image.width * image.height
            _limit(
                "pixels per input",
                input_pixels,
                self.__limits.max_pixels_per_input,
            )
            width = image.width
            height = image.height
            original_pixels = image.pixels
            _limit(
                "operation count",
                len(attempts.submitted) + 1,
                operation_limit,
            )
            _limit(
                "total pixels",
                attempts.pixels + input_pixels,
                total_pixel_limit,
            )
            attempts.record_submission(
                source_kind=source_kind,
                index=index,
                pixel_count=input_pixels,
            )
            try:
                raw_object = self._call_engine(image)
            finally:
                del image
            validated_input = self._validated_result(
                raw_object,
                remaining=_RemainingOutputBudget(
                    regions=total_region_limit - attempts.attempted_regions,
                    characters=(total_character_limit - attempts.attempted_characters),
                    lines=self.__limits.max_total_lines - attempts.attempted_lines,
                    words=self.__limits.max_total_words - attempts.attempted_words,
                ),
                attempts=attempts,
                source_kind=source_kind,
                source_index=index,
                width=width,
                height=height,
                quality_policy=quality_policy,
            )
            attempts.record_attempted_lines_words(
                lines=validated_input.lines,
                words=validated_input.words,
            )
            candidates = [
                _PreprocessingCandidate(
                    profile=LocalOcrPreprocessingProfile.ORIGINAL,
                    profile_order=0,
                    assessment=cast(
                        "LocalOcrInputQualityAssessment",
                        validated_input.quality_assessment,
                    ),
                    payload=validated_input,
                )
            ]
            baseline_assessment = validated_input.quality_assessment
            input_attempts: list[LocalOcrPreprocessingAttemptSummary] = []
            if self.__preprocessing_policy.enabled:
                if baseline_assessment is None:
                    msg = "Local OCR baseline quality evidence is unavailable"
                    raise LocalOcrPreprocessingConfigurationError(msg)
                original_quality_assessments.append(baseline_assessment)
                input_attempts.append(
                    LocalOcrPreprocessingAttemptSummary(
                        source_kind=source_kind,
                        source_index=index,
                        profile=LocalOcrPreprocessingProfile.ORIGINAL,
                        attempt_ordinal=0,
                        status=LocalOcrPreprocessingAttemptStatus.COMPLETED,
                        operation_count=1,
                        input_pixel_count=input_pixels,
                        output_pixel_count=input_pixels,
                        quality_assessment=baseline_assessment,
                    )
                )
            if (
                self.__preprocessing_policy.enabled
                and validated_input.quality_assessment is not None
                and validated_input.quality_assessment.decision.value == "fail"
            ):
                for profile_order, profile in enumerate(
                    self.__preprocessing_policy.profiles, start=1
                ):
                    prep_limits = self.__preprocessing_policy.limits
                    preprocessing_attempt_limit = min(
                        prep_limits.max_extra_attempts_per_document,
                        (
                            usage_budget.preprocessing_attempts
                            if usage_budget is not None
                            else prep_limits.max_extra_attempts_per_document
                        ),
                    )
                    preprocessing_pixel_limit = min(
                        prep_limits.max_total_preprocessing_pixels,
                        (
                            usage_budget.preprocessing_pixels
                            if usage_budget is not None
                            else prep_limits.max_total_preprocessing_pixels
                        ),
                    )
                    preprocessing_operation_limit = min(
                        prep_limits.max_extra_attempts_per_document,
                        (
                            usage_budget.preprocessing_operations
                            if usage_budget is not None
                            else prep_limits.max_extra_attempts_per_document
                        ),
                    )
                    if attempts.preprocessing_attempts >= preprocessing_attempt_limit:
                        raise LocalOcrPreprocessingLimitError(
                            limit_name="preprocessing attempts per document",
                            observed=attempts.preprocessing_attempts + 1,
                            maximum=preprocessing_attempt_limit,
                        )
                    if (
                        attempts.preprocessing_pixels + input_pixels
                        > preprocessing_pixel_limit
                    ):
                        raise LocalOcrPreprocessingLimitError(
                            limit_name="total preprocessing pixels",
                            observed=attempts.preprocessing_pixels + input_pixels,
                            maximum=preprocessing_pixel_limit,
                        )
                    if (
                        attempts.preprocessing_operations + 1
                        > preprocessing_operation_limit
                    ):
                        raise LocalOcrPreprocessingLimitError(
                            limit_name="preprocessing operations",
                            observed=attempts.preprocessing_operations + 1,
                            maximum=preprocessing_operation_limit,
                        )
                    _limit(
                        "operation count",
                        len(attempts.submitted) + 1,
                        operation_limit,
                    )
                    _limit(
                        "total pixels",
                        attempts.pixels + input_pixels,
                        total_pixel_limit,
                    )
                    attempts.record_preprocessing_attempt(input_pixels)
                    retry_pixels = preprocess_local_ocr_rgb(
                        original_pixels,
                        width=width,
                        height=height,
                        profile=profile,
                        limits=prep_limits,
                    )
                    retry_image = LocalOcrImageInput(
                        width=width,
                        height=height,
                        mode="RGB",
                        pixels=retry_pixels,
                        source_kind=source_kind,
                        source_index=index,
                    )
                    attempts.record_preprocessing_operation()
                    attempts.record_submission(
                        source_kind=source_kind,
                        index=index,
                        pixel_count=input_pixels,
                    )
                    try:
                        retry_raw = self._call_engine(retry_image)
                    finally:
                        del retry_image, retry_pixels
                    retry_validated = self._validated_result(
                        retry_raw,
                        remaining=_RemainingOutputBudget(
                            regions=(total_region_limit - attempts.attempted_regions),
                            characters=(
                                total_character_limit - attempts.attempted_characters
                            ),
                            lines=(
                                self.__limits.max_total_lines - attempts.attempted_lines
                            ),
                            words=(
                                self.__limits.max_total_words - attempts.attempted_words
                            ),
                        ),
                        attempts=attempts,
                        source_kind=source_kind,
                        source_index=index,
                        width=width,
                        height=height,
                        quality_policy=quality_policy,
                    )
                    attempts.record_attempted_lines_words(
                        lines=retry_validated.lines,
                        words=retry_validated.words,
                    )
                    assessment = retry_validated.quality_assessment
                    if assessment is None:
                        msg = "Local OCR retry quality evidence is unavailable"
                        raise LocalOcrPreprocessingConfigurationError(msg)
                    candidates.append(
                        _PreprocessingCandidate(
                            profile=profile,
                            profile_order=profile_order,
                            assessment=assessment,
                            payload=retry_validated,
                        )
                    )
                    input_attempts.append(
                        LocalOcrPreprocessingAttemptSummary(
                            source_kind=source_kind,
                            source_index=index,
                            profile=profile,
                            attempt_ordinal=profile_order,
                            status=LocalOcrPreprocessingAttemptStatus.COMPLETED,
                            operation_count=1,
                            input_pixel_count=input_pixels,
                            output_pixel_count=input_pixels,
                            quality_assessment=assessment,
                        )
                    )
                    if assessment.decision.value == "pass":
                        break
                selected_candidate = _select_preprocessing_candidate(tuple(candidates))
                validated_input = cast("_ValidatedInput", selected_candidate.payload)
            elif self.__preprocessing_policy.enabled:
                selected_candidate = candidates[0]
            if self.__preprocessing_policy.enabled:
                selected_ordinal = selected_candidate.profile_order
                input_attempts[selected_ordinal] = input_attempts[
                    selected_ordinal
                ].model_copy(update={"selected": True})
                final_assessment = cast(
                    "LocalOcrInputQualityAssessment",
                    validated_input.quality_assessment,
                )
                reason = (
                    LocalOcrPreprocessingSelectionReason.BASELINE_PASSED
                    if cast(
                        "LocalOcrInputQualityAssessment", baseline_assessment
                    ).decision
                    is LocalOcrQualityDecision.PASS
                    else LocalOcrPreprocessingSelectionReason.RETRY_PASSED
                    if final_assessment.decision is LocalOcrQualityDecision.PASS
                    else LocalOcrPreprocessingSelectionReason.BEST_AVAILABLE
                )
                preprocessing_attempt_summaries.extend(input_attempts)
                preprocessing_input_summaries.append(
                    LocalOcrPreprocessingInputSummary(
                        source_kind=source_kind,
                        source_index=index,
                        selected_profile=selected_candidate.profile,
                        selected_attempt_ordinal=selected_ordinal,
                        selection_reason=reason,
                        original_decision=cast(
                            "LocalOcrInputQualityAssessment", baseline_assessment
                        ).decision,
                        final_decision=final_assessment.decision,
                        attempt_count=len(input_attempts),
                        preprocessing_pixel_count=input_pixels
                        * (len(input_attempts) - 1),
                        extra_operation_count=len(input_attempts) - 1,
                    )
                )
            totals["pixels"] += input_pixels
            del original_pixels
            page, input_counts = self._map_page(
                validated_input,
                descriptor=descriptor,
                source_kind=source_kind,
                index=index,
                width=width,
                height=height,
            )
            pages.append(page)
            if validated_input.quality_assessment is not None:
                quality_assessments.append(validated_input.quality_assessment)
            for name, count in input_counts.items():
                totals[name] += count
            _limit(
                "total regions",
                totals["regions"],
                total_region_limit,
            )
            _limit(
                "total text characters",
                totals["characters"],
                total_character_limit,
            )
            _limit("total lines", totals["lines"], self.__limits.max_total_lines)
            _limit("total words", totals["words"], self.__limits.max_total_words)
            attempts.record_return(
                index=index,
                region_count=input_counts["regions"],
                character_count=input_counts["characters"],
            )
        return (
            tuple(pages),
            totals,
            tuple(quality_assessments),
            tuple(original_quality_assessments),
            tuple(preprocessing_attempt_summaries),
            tuple(preprocessing_input_summaries),
        )

    def _map_page(  # noqa: PLR0913 - explicit normalized page evidence.
        self,
        validated_input: _ValidatedInput,
        *,
        descriptor: FileDescriptor,
        source_kind: Literal["image", "pdf"],
        index: int,
        width: int,
        height: int,
    ) -> tuple[DocumentPage, dict[str, int]]:
        """Map one validated Engine result without retaining its pixel buffer."""
        result = validated_input.result
        input_counts = validated_input.counts()
        blocks: list[TextBlock] = []
        for region in result.regions:
            box = _normalized_box(region, width=width, height=height)
            source = (
                PdfSourceReference(
                    file_id=descriptor.file_id,
                    page_number=index,
                    bounding_box=box,
                )
                if source_kind == "pdf"
                else ImageSourceReference(
                    file_id=descriptor.file_id,
                    frame_number=index,
                    bounding_box=box,
                )
            )
            blocks.append(
                TextBlock(
                    text=region.text,
                    confidence=region.confidence,
                    element_id=f"local-ocr-{index}-{region.reading_order}",
                    source=source,
                )
            )
        page_source = (
            PdfSourceReference(file_id=descriptor.file_id, page_number=index)
            if source_kind == "pdf"
            else ImageSourceReference(file_id=descriptor.file_id, frame_number=index)
        )
        return (
            DocumentPage(
                page_number=index,
                dimensions=PageDimensions(
                    width=width,
                    height=height,
                    unit="pixels",
                ),
                text_blocks=tuple(blocks),
                source=page_source,
            ),
            input_counts,
        )

    def _result(  # noqa: PLR0913
        self,
        descriptor: FileDescriptor,
        *,
        pages: tuple[DocumentPage, ...],
        totals: dict[str, int],
        quality_assessments: tuple[LocalOcrInputQualityAssessment, ...],
        original_quality_assessments: tuple[LocalOcrInputQualityAssessment, ...],
        preprocessing_attempts: tuple[LocalOcrPreprocessingAttemptSummary, ...],
        preprocessing_inputs: tuple[LocalOcrPreprocessingInputSummary, ...],
        quality_policy: LocalOcrIntrinsicQualityPolicy | None,
        usage: ProviderUsage | None,
        started: float,
    ) -> ProcessingResult[Document]:
        if usage is None:
            msg = "Local OCR completed without attempt usage"
            raise LocalOcrInvalidResultError(msg)
        metadata = self.__context.metadata
        if (
            usage.returned_pages != usage.submitted_pages
            or usage.returned_frames != usage.submitted_frames
            or usage.local_region_count != totals["regions"]
            or usage.local_input_pixel_count - usage.local_preprocessing_pixel_count
            != totals["pixels"]
            or usage.local_output_character_count != totals["characters"]
            or usage.local_attempted_region_count < totals["regions"]
            or usage.local_attempted_output_character_count < totals["characters"]
        ):
            msg = "Local OCR successful usage is inconsistent"
            raise LocalOcrInvalidResultError(msg)
        quality_report: LocalOcrQualityReport | None = None
        preprocessing_report: LocalOcrPreprocessingReport | None = None
        if quality_policy is not None:
            quality_failure: Exception | None = None
            try:
                quality_report = create_local_ocr_quality_report(
                    intrinsic_policy=quality_policy,
                    assessments=quality_assessments,
                )
            except Exception as exc:  # noqa: BLE001 - quality boundary is redacted.
                quality_failure = _sanitized_cause(exc)
            if quality_failure is not None:
                _raise_quality_evaluation_error(quality_failure)
            if self.__preprocessing_policy.enabled:
                try:
                    original_report = create_local_ocr_quality_report(
                        intrinsic_policy=quality_policy,
                        assessments=original_quality_assessments,
                    )
                    preprocessing_report = LocalOcrPreprocessingReport(
                        policy_fingerprint=local_ocr_preprocessing_policy_fingerprint(
                            self.__preprocessing_policy
                        ),
                        policy=self.__preprocessing_policy,
                        quality_policy=quality_policy,
                        source_kind=preprocessing_inputs[0].source_kind,
                        input_indexes=tuple(
                            item.source_index for item in preprocessing_inputs
                        ),
                        input_summaries=preprocessing_inputs,
                        original_quality_summary=original_report.summary,
                        final_quality_summary=cast(
                            "LocalOcrQualityReport", quality_report
                        ).summary,
                        total_preprocessing_pixels=usage.local_preprocessing_pixel_count,
                        total_extra_ocr_operations=sum(
                            item.extra_operation_count for item in preprocessing_inputs
                        ),
                        attempts=preprocessing_attempts,
                    )
                except Exception as exc:  # noqa: BLE001 - redacted model boundary.
                    _raise_redacted_translation(
                        exc,
                        LocalOcrInvalidResultError(
                            "Local OCR preprocessing evidence is invalid"
                        ),
                    )
        elif quality_assessments:
            msg = "Local OCR quality evidence was produced while disabled"
            raise LocalOcrQualityEvaluationError(msg)
        return ProcessingResult[Document](
            data=Document(file=descriptor, pages=pages),
            metadata=ProcessingMetadata(
                operation="ocr.analyze.local",
                provider_name=metadata.provider_name,
                profile_id=metadata.profile_id,
                model_id=metadata.model_id,
                provider_usage=usage,
                local_ocr_quality_report=quality_report,
                local_ocr_preprocessing_report=preprocessing_report,
                duration_ms=(perf_counter() - started) * 1000,
                attributes=thaw_json_mapping(metadata.attributes)
                | {
                    "local_page_count": usage.local_page_count,
                    "local_frame_count": usage.local_frame_count,
                    "local_region_count": usage.local_region_count,
                    "azure_operations": 0,
                    "paid_operations": 0,
                },
            ),
        )


def _is_local_ocr_provider_instance(
    value: object | None,
) -> TypeGuard[LocalOcrProvider]:
    """Classify a real Local Provider type without reading instance attributes."""
    if value is None:
        return False
    try:
        return issubclass(type(value), LocalOcrProvider)
    except Exception:  # noqa: BLE001 - hostile Provider type boundary.
        return False


def _is_exact_local_ocr_provider_instance(
    value: object | None,
) -> TypeGuard[LocalOcrProvider]:
    """Reserve SDK-private cumulative budgets for the exact Local Provider."""
    return type(value) is LocalOcrProvider


def _uses_local_ocr_prepared_route(
    value: object | None,
) -> TypeGuard[LocalOcrProvider]:
    """Use prepared input only when public analyze remains the SDK base method."""
    if not _is_local_ocr_provider_instance(value):
        return False
    try:
        return inspect.getattr_static(
            type(value),
            "analyze",
        ) is inspect.getattr_static(LocalOcrProvider, "analyze")
    except Exception:  # noqa: BLE001 - static Provider inspection is best effort.
        return False


def _local_ocr_quality_policy(
    value: object | None,
) -> LocalOcrIntrinsicQualityPolicy | None:
    """Read only the validated base slot of a genuine Local Provider type."""
    if not _is_local_ocr_provider_instance(value):
        return None
    policy: object | None = None
    safe_failure: Exception | None = None
    try:
        quality_policy_slot = LocalOcrProvider.__dict__[
            "_LocalOcrProvider__quality_policy"
        ]
        policy = quality_policy_slot.__get__(
            value,
            LocalOcrProvider,
        )
    except Exception as exc:  # noqa: BLE001 - hostile subclass boundary.
        safe_failure = _sanitized_cause(exc)
    if safe_failure is not None:
        msg = "Local OCR quality policy is unavailable"
        raise LocalOcrQualityConfigurationError(msg) from safe_failure
    if policy is None:
        return None
    if type(policy) is not LocalOcrIntrinsicQualityPolicy:
        msg = "Local OCR quality policy is invalid"
        raise LocalOcrQualityConfigurationError(msg)
    return policy


class DeterministicLocalOcrEngine:
    """Content-independent deterministic Engine for routing evaluation."""

    __slots__ = ("__identity", "__regions", "__weakref__")

    def __init__(
        self,
        *,
        regions: Sequence[LocalOcrEngineRegion | LocalOcrRawRegion] = (),
        identity: LocalOcrEngineIdentity | None = None,
    ) -> None:
        """Create a deterministic result fixture with stable identity."""
        try:
            effective_identity = (
                LocalOcrEngineIdentity(
                    engine_name="deterministic-fake",
                    engine_version="1",
                    model_id="synthetic-routing-only",
                    thread_safety="thread_safe",
                )
                if identity is None
                else _revalidate_model_instance_json(
                    identity,
                    LocalOcrEngineIdentity,
                    "Local OCR Engine identity is invalid",
                )
            )
        except Exception as exc:  # noqa: BLE001 - public model boundary is redacted.
            msg = "Local OCR Engine identity is invalid"
            _raise_redacted_translation(
                exc,
                LocalOcrEngineInitializationError(msg),
            )
        normalized_regions: list[LocalOcrEngineRegion] = []
        region_values: tuple[LocalOcrEngineRegion | LocalOcrRawRegion, ...] | None = (
            None
        )
        safe_failure: Exception | None = None
        try:
            region_values = tuple(regions)
        except Exception as exc:  # noqa: BLE001 - caller boundary is redacted.
            safe_failure = _sanitized_cause(exc)
        if region_values is None:
            msg = "Local OCR deterministic Engine regions are invalid"
            raise LocalOcrEngineInitializationError(msg) from safe_failure
        for region in region_values:
            is_engine_region = _safe_actual_subclass(
                region,
                LocalOcrEngineRegion,
                failure_message="Local OCR deterministic Engine region is invalid",
                initialization=True,
            )
            is_raw_region = _safe_actual_subclass(
                region,
                LocalOcrRawRegion,
                failure_message="Local OCR deterministic Engine region is invalid",
                initialization=True,
            )
            if is_engine_region:
                normalized_regions.append(cast("LocalOcrEngineRegion", region))
                continue
            if not is_raw_region:
                msg = "Local OCR deterministic Engine region is invalid"
                raise LocalOcrEngineInitializationError(msg)
            raw_region = cast("LocalOcrRawRegion", region)
            normalized_region: LocalOcrEngineRegion | None = None
            safe_failure = None
            try:
                normalized_region = LocalOcrEngineRegion(
                    text=raw_region.text,
                    polygon=raw_region.polygon,
                    confidence=raw_region.confidence,
                    reading_order=raw_region.reading_order,
                    language=raw_region.language,
                )
            except Exception as exc:  # noqa: BLE001 - caller boundary is redacted.
                safe_failure = _sanitized_cause(exc)
            if normalized_region is None:
                msg = "Local OCR deterministic Engine region is invalid"
                raise LocalOcrEngineInitializationError(msg) from safe_failure
            normalized_regions.append(normalized_region)
        self.__regions = tuple(normalized_regions)
        self.__identity = effective_identity

    @property
    def identity(self) -> LocalOcrEngineIdentity:
        """Return the fake Engine's stable identity."""
        return self.__identity

    def recognize(self, image: LocalOcrImageInput) -> LocalOcrEngineResult:
        """Return the configured content-independent result."""
        del image
        return LocalOcrEngineResult(regions=self.__regions)

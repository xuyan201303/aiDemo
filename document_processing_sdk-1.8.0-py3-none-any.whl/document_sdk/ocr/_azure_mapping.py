"""Azure response normalization into SDK-owned document models."""

from __future__ import annotations

import math
from collections import defaultdict
from contextvars import ContextVar
from dataclasses import dataclass
from datetime import date, time
from decimal import Decimal, InvalidOperation
from typing import Any, Literal, Never, cast, overload

from document_sdk.core import (
    AnalyzedDocument,
    BoundingBox,
    Document,
    DocumentAddressValue,
    DocumentBarcode,
    DocumentCaption,
    DocumentContentScope,
    DocumentCurrencyValue,
    DocumentElementReference,
    DocumentField,
    DocumentFigure,
    DocumentFootnote,
    DocumentFormula,
    DocumentKeyValueElement,
    DocumentKeyValuePair,
    DocumentLanguage,
    DocumentPage,
    DocumentParagraph,
    DocumentSection,
    DocumentSelectionMark,
    DocumentSpan,
    DocumentTextStyle,
    FileDescriptor,
    ImageSourceReference,
    PageDimensions,
    PdfSourceReference,
    ProcessingWarning,
    ProviderResponseError,
    Table,
    TableCell,
    TextBlock,
)

_GEOMETRY_DRIFT_RATIO = 1e-6
_MIN_POLYGON_COORDINATES = 6
_MIN_PAGE_ANGLE = -180
_MAX_PAGE_ANGLE = 180
_MAX_ELEMENT_PATH_LENGTH = 256
_MAX_ELEMENT_PATH_INDEX = 1_000_000
_ELEMENT_PATH_PARTS = 3
_KNOWN_PARAGRAPH_ROLES = frozenset(
    {
        "pageHeader",
        "pageFooter",
        "pageNumber",
        "title",
        "sectionHeading",
        "footnote",
        "formulaBlock",
    }
)
_KNOWN_FIELD_TYPES = frozenset(
    {
        "string",
        "date",
        "time",
        "phoneNumber",
        "number",
        "integer",
        "selectionMark",
        "countryRegion",
        "signature",
        "array",
        "object",
        "currency",
        "address",
        "boolean",
        "selectionGroup",
    }
)
type _ReferenceElementType = Literal[
    "paragraph",
    "table",
    "figure",
    "section",
    "key_value_pair",
    "analyzed_document",
]
type _ElementPathKey = tuple[str, int]
type _ElementRegistry = dict[
    _ElementPathKey,
    tuple[DocumentElementReference, ...],
]
_ELEMENT_ROOT_TYPES: dict[str, _ReferenceElementType] = {
    "paragraphs": "paragraph",
    "tables": "table",
    "figures": "figure",
    "sections": "section",
    "keyValuePairs": "key_value_pair",
    "documents": "analyzed_document",
}
_MAPPING_STAGE: ContextVar[str] = ContextVar(
    "azure_mapping_stage",
    default="document_invariant_invalid",
)
_SAFE_MAPPING_SUBCODES = frozenset(
    {
        "page_list_invalid",
        "page_coverage_missing",
        "page_coverage_extra",
        "page_duplicate",
        "page_geometry_invalid",
        "page_span_invalid",
        "line_content_invalid",
        "line_geometry_invalid",
        "line_span_invalid",
        "selection_mark_invalid",
        "barcode_invalid",
        "formula_invalid",
    }
)
_SAFE_ELEMENT_CATEGORIES = frozenset(
    {
        "page",
        "line",
        "selection_mark",
        "barcode",
        "formula",
    }
)
_SAFE_COORDINATE_VIOLATIONS = frozenset(
    {
        "incomplete_polygon",
        "invalid_coordinate",
        "non_finite_coordinate",
        "outside_page",
    }
)
_MAX_DIAGNOSTIC_INTEGER = 1_000_000
_MAX_DIAGNOSTIC_PAGE_NUMBERS = 1_000
_MAX_DIAGNOSTIC_OVERFLOW = 1_000_000.0


@dataclass(frozen=True, slots=True)
class _MappingDiagnostic:
    mapping_subcode: str | None = None
    page_number: int | None = None
    element_category: str | None = None
    element_index: int | None = None
    expected_page_count: int | None = None
    returned_page_count: int | None = None
    missing_page_numbers: tuple[int, ...] = ()
    extra_page_numbers: tuple[int, ...] = ()
    coordinate_violation: str | None = None
    maximum_normalized_overflow: float | None = None


_MAPPING_DIAGNOSTIC: ContextVar[_MappingDiagnostic | None] = ContextVar(
    "azure_mapping_diagnostic",
    default=None,
)


class _AzureMappingResponseError(ProviderResponseError):
    """One sanitized response error with a stable content-free mapping stage."""

    mapping_code: str
    mapping_subcode: str | None
    page_number: int | None
    element_category: str | None
    element_index: int | None
    expected_page_count: int | None
    returned_page_count: int | None
    missing_page_numbers: tuple[int, ...]
    extra_page_numbers: tuple[int, ...]
    coordinate_violation: str | None
    maximum_normalized_overflow: float | None
    safe_request_id: str | None

    def __init__(
        self,
        message: str,
        *,
        mapping_code: str,
        diagnostic: _MappingDiagnostic | None = None,
    ) -> None:
        super().__init__(message)
        safe = _safe_diagnostic(diagnostic or _MappingDiagnostic())
        self.mapping_code = mapping_code
        self.mapping_subcode = safe.mapping_subcode
        self.page_number = safe.page_number
        self.element_category = safe.element_category
        self.element_index = safe.element_index
        self.expected_page_count = safe.expected_page_count
        self.returned_page_count = safe.returned_page_count
        self.missing_page_numbers = safe.missing_page_numbers
        self.extra_page_numbers = safe.extra_page_numbers
        self.coordinate_violation = safe.coordinate_violation
        self.maximum_normalized_overflow = safe.maximum_normalized_overflow
        self.safe_request_id = None

    def safe_diagnostics(self) -> dict[str, object]:
        """Serialize only approved content-free mapping evidence."""
        values: dict[str, object] = {
            "mapping_code": self.mapping_code,
            "mapping_subcode": self.mapping_subcode,
            "page_number": self.page_number,
            "element_category": self.element_category,
            "element_index": self.element_index,
            "expected_page_count": self.expected_page_count,
            "returned_page_count": self.returned_page_count,
            "missing_page_numbers": self.missing_page_numbers,
            "extra_page_numbers": self.extra_page_numbers,
            "coordinate_violation": self.coordinate_violation,
            "maximum_normalized_overflow": self.maximum_normalized_overflow,
            "safe_request_id": self.safe_request_id,
        }
        return {
            name: value
            for name, value in values.items()
            if value is not None and value != ()
        }


@dataclass(frozen=True, slots=True)
class AzureMappingOutcome:
    """Normalized Azure result plus safe aggregate evidence."""

    document: Document
    warnings: tuple[ProcessingWarning, ...]
    page_count: int
    table_count: int


@dataclass(frozen=True, slots=True)
class _PageFacts:
    number: int
    width: float
    height: float
    dimensions: PageDimensions


@dataclass(frozen=True, slots=True)
class _TableCellFacts:
    row: int
    column: int
    row_span: int
    column_span: int
    text: str
    kind: str | None
    confidence: float | None
    page_number: int | None
    bounding_box: BoundingBox | None
    sources: tuple[PdfSourceReference | ImageSourceReference, ...]
    spans: tuple[DocumentSpan, ...]
    elements: tuple[DocumentElementReference, ...]


def _safe_positive_integer(value: object) -> int | None:
    """Return a bounded positive non-boolean diagnostic integer."""
    if type(value) is int and 1 <= value <= _MAX_DIAGNOSTIC_INTEGER:
        return value
    return None


def _safe_non_negative_integer(value: object) -> int | None:
    """Return a bounded non-negative non-boolean diagnostic integer."""
    if type(value) is int and 0 <= value <= _MAX_DIAGNOSTIC_INTEGER:
        return value
    return None


def _safe_page_numbers(values: object) -> tuple[int, ...]:
    """Return a bounded deterministic set of safe page numbers."""
    if not isinstance(values, tuple | list | set | frozenset):
        return ()
    normalized_values: list[int] = []
    for number in values:
        safe_number = _safe_positive_integer(number)
        if safe_number is not None:
            normalized_values.append(safe_number)
    normalized = tuple(sorted(set(normalized_values)))
    return normalized[:_MAX_DIAGNOSTIC_PAGE_NUMBERS]


def _safe_diagnostic(value: _MappingDiagnostic) -> _MappingDiagnostic:
    """Return a copy containing only bounded, allowlisted evidence."""
    overflow = value.maximum_normalized_overflow
    if (
        isinstance(overflow, bool)
        or not isinstance(overflow, int | float)
        or not math.isfinite(float(overflow))
        or not 0 <= float(overflow) <= _MAX_DIAGNOSTIC_OVERFLOW
    ):
        safe_overflow = None
    else:
        safe_overflow = float(overflow)
    return _MappingDiagnostic(
        mapping_subcode=(
            value.mapping_subcode
            if value.mapping_subcode in _SAFE_MAPPING_SUBCODES
            else None
        ),
        page_number=_safe_positive_integer(value.page_number),
        element_category=(
            value.element_category
            if value.element_category in _SAFE_ELEMENT_CATEGORIES
            else None
        ),
        element_index=_safe_positive_integer(value.element_index),
        expected_page_count=_safe_non_negative_integer(value.expected_page_count),
        returned_page_count=_safe_non_negative_integer(value.returned_page_count),
        missing_page_numbers=_safe_page_numbers(value.missing_page_numbers),
        extra_page_numbers=_safe_page_numbers(value.extra_page_numbers),
        coordinate_violation=(
            value.coordinate_violation
            if value.coordinate_violation in _SAFE_COORDINATE_VIOLATIONS
            else None
        ),
        maximum_normalized_overflow=safe_overflow,
    )


def _set_diagnostic(  # noqa: PLR0913
    mapping_subcode: str,
    *,
    page_number: int | None = None,
    element_category: str | None = None,
    element_index: int | None = None,
    expected_page_count: int | None = None,
    returned_page_count: int | None = None,
    missing_page_numbers: tuple[int, ...] = (),
    extra_page_numbers: tuple[int, ...] = (),
) -> None:
    """Set the safe context for the immediately following mapping operation."""
    _MAPPING_DIAGNOSTIC.set(
        _MappingDiagnostic(
            mapping_subcode=mapping_subcode,
            page_number=page_number,
            element_category=element_category,
            element_index=element_index,
            expected_page_count=expected_page_count,
            returned_page_count=returned_page_count,
            missing_page_numbers=missing_page_numbers,
            extra_page_numbers=extra_page_numbers,
        )
    )


def _fail(
    message: str,
    *,
    coordinate_violation: str | None = None,
    maximum_normalized_overflow: float | None = None,
) -> Never:
    """Raise one controlled malformed-response error."""
    diagnostic = _MAPPING_DIAGNOSTIC.get() or _MappingDiagnostic()
    if coordinate_violation is not None or maximum_normalized_overflow is not None:
        diagnostic = _MappingDiagnostic(
            mapping_subcode=diagnostic.mapping_subcode,
            page_number=diagnostic.page_number,
            element_category=diagnostic.element_category,
            element_index=diagnostic.element_index,
            expected_page_count=diagnostic.expected_page_count,
            returned_page_count=diagnostic.returned_page_count,
            missing_page_numbers=diagnostic.missing_page_numbers,
            extra_page_numbers=diagnostic.extra_page_numbers,
            coordinate_violation=coordinate_violation,
            maximum_normalized_overflow=maximum_normalized_overflow,
        )
    raise _AzureMappingResponseError(
        message,
        mapping_code=_MAPPING_STAGE.get(),
        diagnostic=diagnostic,
    )


def _finite_number(value: object, *, name: str) -> float:
    """Require one finite non-boolean response number."""
    if isinstance(value, bool) or not isinstance(value, int | float):
        _fail(f"Azure response {name} is invalid")
    number = float(value)
    if not math.isfinite(number):
        _fail(f"Azure response {name} is not finite")
    return number


def _positive_int(value: object, *, name: str) -> int:
    """Require one positive non-boolean response integer."""
    if type(value) is not int or value < 1:
        _fail(f"Azure response {name} is invalid")
    return value


def _non_negative_int(value: object, *, name: str) -> int:
    """Require one non-negative non-boolean response integer."""
    if type(value) is not int or value < 0:
        _fail(f"Azure response {name} is invalid")
    return value


def _enum_value(value: object) -> str | None:
    """Return a stable string from a generated Azure enum or string."""
    if value is None:
        return None
    raw = getattr(value, "value", value)
    return str(raw)


def _optional_confidence(value: object) -> float | None:
    """Return a service confidence when that response item exposes one."""
    raw_confidence = getattr(value, "confidence", None)
    if raw_confidence is None:
        return None
    confidence = _finite_number(raw_confidence, name="confidence")
    if not 0 <= confidence <= 1:
        _fail("Azure response confidence is outside supported bounds")
    return confidence


def _page_dimensions(page: Any) -> _PageFacts:
    """Validate exact service page geometry and preserve its angle."""
    page_number = _positive_int(
        getattr(page, "page_number", None),
        name="page number",
    )
    width = _finite_number(getattr(page, "width", None), name="page width")
    height = _finite_number(getattr(page, "height", None), name="page height")
    if width <= 0 or height <= 0:
        _fail("Azure response page dimensions must be positive")
    unit = _enum_value(getattr(page, "unit", None))
    if unit == "inch":
        public_width = width * 72
        public_height = height * 72
        public_unit: Literal["points", "pixels"] = "points"
    elif unit in {"pixel", "pixels"}:
        public_width = width
        public_height = height
        public_unit = "pixels"
    else:
        _fail("Azure response page unit is unsupported")
    raw_angle = getattr(page, "angle", None)
    angle = None if raw_angle is None else _finite_number(raw_angle, name="page angle")
    if angle is not None and not _MIN_PAGE_ANGLE <= angle <= _MAX_PAGE_ANGLE:
        _fail("Azure response page angle is outside supported bounds")
    return _PageFacts(
        number=page_number,
        width=width,
        height=height,
        dimensions=PageDimensions(
            width=public_width,
            height=public_height,
            unit=public_unit,
            angle_degrees=angle,
        ),
    )


def _normalized_polygon(
    polygon: object,
    *,
    page: _PageFacts,
) -> BoundingBox | None:
    """Normalize an Azure 1.0.2 flat coordinate polygon."""
    if polygon is None:
        return None
    if (
        not isinstance(polygon, list | tuple)
        or len(polygon) < _MIN_POLYGON_COORDINATES
        or len(polygon) % 2
    ):
        _fail(
            "Azure response polygon is incomplete",
            coordinate_violation="incomplete_polygon",
        )
    coordinates: list[float] = []
    for value in polygon:
        if isinstance(value, bool) or not isinstance(value, int | float):
            _fail(
                "Azure response polygon coordinate is invalid",
                coordinate_violation="invalid_coordinate",
            )
        number = float(value)
        if not math.isfinite(number):
            _fail(
                "Azure response polygon coordinate is not finite",
                coordinate_violation="non_finite_coordinate",
            )
        coordinates.append(number)
    xs = coordinates[0::2]
    ys = coordinates[1::2]
    tolerance_x = page.width * _GEOMETRY_DRIFT_RATIO
    tolerance_y = page.height * _GEOMETRY_DRIFT_RATIO
    maximum_normalized_overflow = max(
        0.0,
        -min(xs) / page.width,
        (max(xs) - page.width) / page.width,
        -min(ys) / page.height,
        (max(ys) - page.height) / page.height,
    )
    if (
        min(xs) < -tolerance_x
        or max(xs) > page.width + tolerance_x
        or min(ys) < -tolerance_y
        or max(ys) > page.height + tolerance_y
    ):
        _fail(
            "Azure response polygon is outside its page",
            coordinate_violation="outside_page",
            maximum_normalized_overflow=maximum_normalized_overflow,
        )
    left = min(max(min(xs) / page.width, 0), 1)
    right = min(max(max(xs) / page.width, 0), 1)
    top = min(max(min(ys) / page.height, 0), 1)
    bottom = min(max(max(ys) / page.height, 0), 1)
    return BoundingBox(left=left, top=top, right=right, bottom=bottom)


def _source(
    *,
    source_kind: Literal["pdf", "image"],
    file_id: str,
    page_number: int,
    bounding_box: BoundingBox | None = None,
) -> PdfSourceReference | ImageSourceReference:
    """Create the input-kind-specific normalized source."""
    if source_kind == "pdf":
        return PdfSourceReference(
            file_id=file_id,
            page_number=page_number,
            bounding_box=bounding_box,
        )
    return ImageSourceReference(
        file_id=file_id,
        frame_number=page_number,
        bounding_box=bounding_box,
    )


def _warning(category: str, count: int) -> ProcessingWarning:
    """Create a content-free structured warning."""
    return ProcessingWarning(
        code=f"azure.{category}",
        message=f"Azure response contained {count} {category} item(s).",
        category=category,
        count=count,
    )


def _primary_region(
    regions: object,
    *,
    pages: dict[int, _PageFacts],
) -> tuple[Any | None, int]:
    """Choose the lowest-page region, preserving service order as a tiebreaker."""
    if not regions:
        return None, 0
    if not isinstance(regions, list | tuple):
        _fail("Azure response bounding regions are invalid")
    indexed_regions = tuple(enumerate(regions))
    for _, region in indexed_regions:
        page_number = _positive_int(
            getattr(region, "page_number", None),
            name="bounding-region page number",
        )
        if page_number not in pages:
            _fail("Azure response references an unknown page")
    _, primary = min(
        indexed_regions,
        key=lambda item: (item[1].page_number, item[0]),
    )
    return primary, len(indexed_regions)


def _regions_by_page(
    regions: object,
    *,
    pages: dict[int, _PageFacts],
) -> tuple[dict[int, Any], int]:
    """Return the first valid region for each real page in service order."""
    if not regions:
        return {}, 0
    if not isinstance(regions, list | tuple):
        _fail("Azure response bounding regions are invalid")
    by_page: dict[int, Any] = {}
    for region in regions:
        page_number = _positive_int(
            getattr(region, "page_number", None),
            name="bounding-region page number",
        )
        if page_number not in pages:
            _fail("Azure response references an unknown page")
        by_page.setdefault(page_number, region)
    return by_page, len(regions)


def _unsupported_warnings(
    result: Any,
) -> list[ProcessingWarning]:
    """Preserve only genuinely unsupported service warning evidence."""
    warnings: list[ProcessingWarning] = []
    service_warning_count = len(getattr(result, "warnings", None) or ())
    if service_warning_count:
        warnings.append(_warning("service_warnings", service_warning_count))
    return warnings


def _content_scope(  # noqa: PLR0913
    result: Any,
    *,
    source_kind: Literal["pdf", "image"],
    page_numbers: tuple[int, ...],
    provider_name: str,
    profile_id: str,
    model_id: str | None,
    max_content_characters: int,
) -> DocumentContentScope:
    """Map the service concatenated content into one explicit offset scope."""
    content = getattr(result, "content", None)
    if not isinstance(content, str):
        _fail("Azure response content is invalid")
    if len(content) > max_content_characters:
        _fail("Azure response content character limit exceeded")
    raw_string_index_type = _enum_value(getattr(result, "string_index_type", None))
    if raw_string_index_type != "unicodeCodePoint":
        _fail("Azure response string index type does not match the request")
    string_index_type = cast(
        'Literal["unicodeCodePoint"]',
        raw_string_index_type,
    )
    location = (
        {"page_numbers": page_numbers}
        if source_kind == "pdf"
        else {"frame_numbers": page_numbers}
    )
    return DocumentContentScope(
        scope_id="ocr-provider-content",
        content=content,
        indexed_length=len(content),
        string_index_type=string_index_type,
        origin="ocr_provider",
        provider_name=provider_name,
        profile_id=profile_id,
        model_id=model_id,
        **location,
    )


def _spans(
    raw_spans: object,
    *,
    scope: DocumentContentScope | None,
    validate_scope_bounds: bool = False,
) -> tuple[DocumentSpan, ...]:
    """Map service spans without exposing an ambiguous offset space."""
    if raw_spans is None:
        return ()
    if not isinstance(raw_spans, list | tuple):
        _fail("Azure response spans are invalid")
    if raw_spans and scope is None:
        _fail("Azure response spans have no content scope")
    if scope is None:
        return ()
    mapped = tuple(
        DocumentSpan(
            scope_id=scope.scope_id,
            offset=_non_negative_int(getattr(span, "offset", None), name="span offset"),
            length=_non_negative_int(getattr(span, "length", None), name="span length"),
        )
        for span in raw_spans
    )
    if validate_scope_bounds and any(
        span.offset + span.length > scope.indexed_length for span in mapped
    ):
        _fail("Azure response span exceeds its content scope")
    return tuple(sorted(set(mapped), key=lambda span: (span.offset, span.length)))


def _single_span(
    raw_span: object,
    *,
    scope: DocumentContentScope | None,
) -> DocumentSpan:
    """Map one required service span."""
    spans = _spans([] if raw_span is None else [raw_span], scope=scope)
    if len(spans) != 1:
        _fail("Azure response item span is missing")
    return spans[0]


def _sources(
    raw_regions: object,
    *,
    source_kind: Literal["pdf", "image"],
    file_id: str,
    pages: dict[int, _PageFacts],
) -> tuple[PdfSourceReference | ImageSourceReference, ...]:
    """Map every distinct service region into deterministic SDK evidence."""
    if not raw_regions:
        return ()
    if not isinstance(raw_regions, list | tuple):
        _fail("Azure response bounding regions are invalid")
    mapped = []
    for region in raw_regions:
        page_number = _positive_int(
            getattr(region, "page_number", None),
            name="bounding-region page number",
        )
        if page_number not in pages:
            _fail("Azure response references an unknown page")
        mapped.append(
            _source(
                source_kind=source_kind,
                file_id=file_id,
                page_number=page_number,
                bounding_box=_normalized_polygon(
                    getattr(region, "polygon", None),
                    page=pages[page_number],
                ),
            )
        )
    unique = {source.model_dump_json(): source for source in mapped}
    return tuple(
        sorted(
            unique.values(),
            key=lambda source: (
                _document_number(source),
                source.model_dump_json(),
            ),
        )
    )


def _document_number(
    source: PdfSourceReference | ImageSourceReference,
) -> int:
    """Return a page/frame number from one document source."""
    if isinstance(source, PdfSourceReference):
        return source.page_number
    return source.frame_number


def _union_sources(
    *groups: tuple[PdfSourceReference | ImageSourceReference, ...],
) -> tuple[PdfSourceReference | ImageSourceReference, ...]:
    """Combine source groups without losing regions."""
    unique = {source.model_dump_json(): source for group in groups for source in group}
    return tuple(
        sorted(
            unique.values(),
            key=lambda source: (
                _document_number(source),
                source.model_dump_json(),
            ),
        )
    )


def _span_sources(  # noqa: PLR0913
    spans: tuple[DocumentSpan, ...],
    *,
    page_spans: dict[int, tuple[DocumentSpan, ...]],
    source_kind: Literal["pdf", "image"],
    file_id: str,
    warnings: list[ProcessingWarning],
    warning_category: str,
) -> tuple[PdfSourceReference | ImageSourceReference, ...]:
    """Derive every real page/frame whose declared content range overlaps."""
    matched_numbers = {
        page_number
        for page_number, candidates in page_spans.items()
        if any(
            span.scope_id == candidate.scope_id
            and span.offset < candidate.offset + candidate.length
            and candidate.offset < span.offset + span.length
            for span in spans
            for candidate in candidates
        )
    }
    if not matched_numbers:
        warnings.append(_warning(warning_category, 1))
        return ()
    return tuple(
        _source(
            source_kind=source_kind,
            file_id=file_id,
            page_number=page_number,
        )
        for page_number in sorted(matched_numbers)
    )


def _parse_element_path(
    value: object,
) -> tuple[_ElementPathKey | None, str | None]:
    """Parse one documented Azure element path without evaluating it."""
    if not isinstance(value, str) or not 1 <= len(value) <= _MAX_ELEMENT_PATH_LENGTH:
        return None, "malformed_element_references"
    candidate = value.removeprefix("#")
    parts = candidate.split("/")
    if (
        len(parts) != _ELEMENT_PATH_PARTS
        or parts[0]
        or not parts[1]
        or not parts[2]
        or not parts[2].isascii()
        or not parts[2].isdigit()
    ):
        return None, "malformed_element_references"
    root = parts[1]
    if (
        not root.isascii()
        or not root[0].isalpha()
        or not all(character.isalnum() for character in root)
    ):
        return None, "malformed_element_references"
    if root not in _ELEMENT_ROOT_TYPES:
        return None, "unsupported_element_reference_roots"
    index = int(parts[2])
    if index > _MAX_ELEMENT_PATH_INDEX:
        return None, "malformed_element_references"
    return (root, index), None


def _resolve_references(
    raw_elements: object,
    *,
    registry: _ElementRegistry,
    warnings: list[ProcessingWarning],
    blocked_paths: frozenset[_ElementPathKey] = frozenset(),
) -> tuple[DocumentElementReference, ...]:
    """Resolve private service paths into public deterministic SDK references."""
    if not raw_elements:
        return ()
    if not isinstance(raw_elements, list | tuple):
        _fail("Azure response element references are invalid")
    resolved: list[DocumentElementReference] = []
    warning_counts: dict[str, int] = defaultdict(int)
    for raw_path in raw_elements:
        path, issue = _parse_element_path(raw_path)
        if issue is not None:
            warning_counts[issue] += 1
            continue
        if path is None or path in blocked_paths:
            continue
        references = registry.get(path)
        if references is None:
            warning_counts["out_of_range_element_references"] += 1
            continue
        if not references:
            warning_counts["unmappable_element_references"] += 1
            continue
        resolved.extend(references)
    warnings.extend(
        _warning(category, count) for category, count in sorted(warning_counts.items())
    )
    unique = {reference.model_dump_json(): reference for reference in resolved}
    return tuple(
        sorted(
            unique.values(),
            key=lambda reference: (reference.element_type, reference.element_id),
        )
    )


def _decimal(value: object, *, name: str) -> Decimal:
    """Convert a finite service number into a precision-preserving Decimal."""
    number = _finite_number(value, name=name)
    try:
        return Decimal(str(number))
    except InvalidOperation:
        _fail(f"Azure response {name} is invalid")


def _address(raw: object) -> DocumentAddressValue:
    """Copy only documented Azure 1.0.2 address components."""
    if raw is None:
        _fail("Azure response address value is missing")
    names = (
        "house_number",
        "po_box",
        "road",
        "city",
        "state",
        "postal_code",
        "country_region",
        "street_address",
        "unit",
        "city_district",
        "state_district",
        "suburb",
        "house",
        "level",
    )
    values: dict[str, str | None] = {}
    for name in names:
        value = getattr(raw, name, None)
        if value is not None and not isinstance(value, str):
            _fail("Azure response address component is invalid")
        values[name] = value
    return DocumentAddressValue(**values)


@dataclass(slots=True)
class _FieldBudget:
    count: int
    maximum: int
    max_depth: int


def _field(  # noqa: C901, PLR0912, PLR0913, PLR0915
    raw: object,
    *,
    depth: int,
    budget: _FieldBudget,
    scope: DocumentContentScope | None,
    source_kind: Literal["pdf", "image"],
    file_id: str,
    pages: dict[int, _PageFacts],
    warnings: list[ProcessingWarning],
) -> DocumentField:
    """Map one bounded recursive Azure 1.0.2 document field."""
    if depth > budget.max_depth:
        _fail("Azure response document field depth limit exceeded")
    budget.count += 1
    if budget.count > budget.maximum:
        _fail("Azure response document field count limit exceeded")
    field_type = _enum_value(getattr(raw, "type", None))
    if not field_type:
        _fail("Azure response document field type is invalid")
    content = getattr(raw, "content", None)
    confidence = _optional_confidence(raw)
    mapped_spans = _spans(getattr(raw, "spans", None), scope=scope)
    mapped_sources = _sources(
        getattr(raw, "bounding_regions", None),
        source_kind=source_kind,
        file_id=file_id,
        pages=pages,
    )
    if content is not None and not isinstance(content, str):
        _fail("Azure response document field content is invalid")
    if field_type not in _KNOWN_FIELD_TYPES:
        warnings.append(_warning("unknown_document_field_types", 1))
        return DocumentField(
            field_type=field_type,
            normalization_status="unsupported_type",
            value=None,
            content=content,
            confidence=confidence,
            spans=mapped_spans,
            sources=mapped_sources,
            unsupported=True,
        )
    attribute = {
        "string": "value_string",
        "date": "value_date",
        "time": "value_time",
        "phoneNumber": "value_phone_number",
        "number": "value_number",
        "integer": "value_integer",
        "selectionMark": "value_selection_mark",
        "countryRegion": "value_country_region",
        "signature": "value_signature",
        "array": "value_array",
        "object": "value_object",
        "currency": "value_currency",
        "address": "value_address",
        "boolean": "value_boolean",
        "selectionGroup": "value_selection_group",
    }[field_type]
    raw_value = getattr(raw, attribute, None)
    if raw_value is None:
        warnings.append(_warning("document_field_normalization_unavailable", 1))
        return DocumentField(
            field_type=field_type,
            normalization_status="raw_only",
            value=None,
            content=content,
            confidence=confidence,
            spans=mapped_spans,
            sources=mapped_sources,
        )
    value: object
    if field_type == "number":
        value = _decimal(raw_value, name="document field number")
    elif field_type == "integer":
        if type(raw_value) is not int:
            _fail("Azure response document field integer is invalid")
        value = raw_value
    elif field_type == "boolean":
        if type(raw_value) is not bool:
            _fail("Azure response document field boolean is invalid")
        value = raw_value
    elif field_type == "date":
        if not isinstance(raw_value, date):
            _fail("Azure response document field date is invalid")
        value = raw_value
    elif field_type == "time":
        if not isinstance(raw_value, time):
            _fail("Azure response document field time is invalid")
        value = raw_value
    elif field_type == "array":
        if not isinstance(raw_value, list | tuple):
            _fail("Azure response document field array is invalid")
        value = tuple(
            _field(
                item,
                depth=depth + 1,
                budget=budget,
                scope=scope,
                source_kind=source_kind,
                file_id=file_id,
                pages=pages,
                warnings=warnings,
            )
            for item in raw_value
        )
    elif field_type == "object":
        if not isinstance(raw_value, dict):
            _fail("Azure response document field object is invalid")
        value = {
            name: _field(
                item,
                depth=depth + 1,
                budget=budget,
                scope=scope,
                source_kind=source_kind,
                file_id=file_id,
                pages=pages,
                warnings=warnings,
            )
            for name, item in sorted(raw_value.items())
            if isinstance(name, str) and name
        }
        if len(value) != len(raw_value):
            _fail("Azure response document field object name is invalid")
    elif field_type == "currency":
        if raw_value is None:
            _fail("Azure response currency value is missing")
        value = DocumentCurrencyValue(
            amount=_decimal(
                getattr(raw_value, "amount", None),
                name="currency amount",
            ),
            currency_code=getattr(raw_value, "currency_code", None),
            currency_symbol=getattr(raw_value, "currency_symbol", None),
        )
    elif field_type == "address":
        value = _address(raw_value)
    elif field_type == "selectionGroup":
        if not isinstance(raw_value, list | tuple) or not all(
            isinstance(item, str) for item in raw_value
        ):
            _fail("Azure response selection group is invalid")
        value = tuple(raw_value)
    else:
        value = (
            _enum_value(raw_value)
            if field_type
            in {
                "selectionMark",
                "signature",
            }
            else raw_value
        )
        if not isinstance(value, str):
            _fail("Azure response document field string value is invalid")
    return DocumentField(
        field_type=field_type,
        value=value,
        content=content,
        confidence=confidence,
        spans=mapped_spans,
        sources=mapped_sources,
    )


def _items(value: object, *, name: str) -> tuple[Any, ...]:
    """Return one optional service collection as a tuple."""
    if value is None:
        return ()
    if not isinstance(value, list | tuple):
        _fail(f"Azure response {name} are invalid")
    return tuple(value)


@overload
def _caption_or_footnote(
    raw: object,
    *,
    element_id: str,
    caption: Literal[True],
    scope: DocumentContentScope | None,
    source_kind: Literal["pdf", "image"],
    file_id: str,
    pages: dict[int, _PageFacts],
    registry: _ElementRegistry,
    warnings: list[ProcessingWarning],
) -> DocumentCaption: ...


@overload
def _caption_or_footnote(
    raw: object,
    *,
    element_id: str,
    caption: Literal[False],
    scope: DocumentContentScope | None,
    source_kind: Literal["pdf", "image"],
    file_id: str,
    pages: dict[int, _PageFacts],
    registry: _ElementRegistry,
    warnings: list[ProcessingWarning],
) -> DocumentFootnote: ...


def _caption_or_footnote(  # noqa: PLR0913
    raw: object,
    *,
    element_id: str,
    caption: bool,
    scope: DocumentContentScope | None,
    source_kind: Literal["pdf", "image"],
    file_id: str,
    pages: dict[int, _PageFacts],
    registry: _ElementRegistry,
    warnings: list[ProcessingWarning],
) -> DocumentCaption | DocumentFootnote:
    """Map a table or figure annotation with complete evidence."""
    content = getattr(raw, "content", None)
    if not isinstance(content, str):
        _fail("Azure response annotation content is invalid")
    sources = _sources(
        getattr(raw, "bounding_regions", None),
        source_kind=source_kind,
        file_id=file_id,
        pages=pages,
    )
    if not sources:
        warnings.append(_warning("missing_annotation_geometry", 1))
    spans = _spans(getattr(raw, "spans", None), scope=scope)
    elements = _resolve_references(
        getattr(raw, "elements", None),
        registry=registry,
        warnings=warnings,
    )
    if caption:
        return DocumentCaption(
            element_id=element_id,
            content=content,
            spans=spans,
            sources=sources,
            elements=elements,
        )
    return DocumentFootnote(
        element_id=element_id,
        content=content,
        spans=spans,
        sources=sources,
        elements=elements,
    )


def _cyclic_section_paths(
    raw_sections: tuple[Any, ...],
) -> frozenset[_ElementPathKey]:
    """Find section nodes participating in a cycle without recursive traversal."""
    paths = tuple(("sections", index) for index in range(len(raw_sections)))
    path_set = set(paths)
    graph: dict[_ElementPathKey, tuple[_ElementPathKey, ...]] = {}
    for path, section in zip(paths, raw_sections, strict=True):
        elements = getattr(section, "elements", None) or ()
        if not isinstance(elements, list | tuple):
            _fail("Azure response section element references are invalid")
        graph[path] = tuple(
            parsed
            for element in elements
            for parsed, issue in (_parse_element_path(element),)
            if issue is None and parsed in path_set
        )
    state: dict[_ElementPathKey, int] = {}
    cyclic: set[_ElementPathKey] = set()
    for start in paths:
        if state.get(start, 0):
            continue
        stack: list[tuple[_ElementPathKey, int]] = [(start, 0)]
        active_indexes: dict[_ElementPathKey, int] = {}
        while stack:
            path, next_index = stack[-1]
            if state.get(path, 0) == 0:
                state[path] = 1
                active_indexes[path] = len(stack) - 1
            targets = graph[path]
            if next_index >= len(targets):
                state[path] = 2
                active_indexes.pop(path, None)
                stack.pop()
                continue
            target = targets[next_index]
            stack[-1] = (path, next_index + 1)
            target_state = state.get(target, 0)
            if target_state == 0:
                stack.append((target, 0))
            elif target_state == 1:
                cycle_start = active_indexes[target]
                cyclic.update(node for node, _ in stack[cycle_start:])
    return frozenset(cyclic)


def _table_reference_pages(
    raw_table: Any,
    *,
    pages: dict[int, _PageFacts],
) -> tuple[int, ...]:
    """Collect the exact pages that will own one mapped table."""
    table_regions, _ = _regions_by_page(
        getattr(raw_table, "bounding_regions", None),
        pages=pages,
    )
    proven_pages = set(table_regions)
    raw_cells = getattr(raw_table, "cells", None)
    if not isinstance(raw_cells, list):
        _fail("Azure response table cells are invalid")
    for raw_cell in raw_cells:
        primary_region, _ = _primary_region(
            getattr(raw_cell, "bounding_regions", None),
            pages=pages,
        )
        if primary_region is not None:
            proven_pages.add(
                _positive_int(
                    getattr(primary_region, "page_number", None),
                    name="table cell page number",
                )
            )
    return tuple(sorted(proven_pages))


def _register_element_paths(
    result: Any,
    *,
    pages: dict[int, _PageFacts],
    registry: _ElementRegistry,
) -> tuple[tuple[int, ...], ...]:
    """Preallocate every supported top-level ID before resolving references."""
    collections = (
        ("paragraphs", "paragraphs", "paragraph"),
        ("key_value_pairs", "keyValuePairs", "key-value-pair"),
        ("figures", "figures", "figure"),
        ("sections", "sections", "section"),
        ("documents", "documents", "analyzed-document"),
    )
    for attribute, root, id_prefix in collections:
        items = _items(getattr(result, attribute, None), name=attribute)
        for index, _ in enumerate(items):
            registry[(root, index)] = (
                DocumentElementReference(
                    element_type=_ELEMENT_ROOT_TYPES[root],
                    element_id=f"{id_prefix}-{index + 1}",
                ),
            )
    raw_tables = _items(getattr(result, "tables", None), name="tables")
    table_pages = tuple(
        _table_reference_pages(raw_table, pages=pages) for raw_table in raw_tables
    )
    for table_index, page_numbers in enumerate(table_pages):
        registry[("tables", table_index)] = tuple(
            DocumentElementReference(
                element_type="table",
                element_id=f"table-{table_index + 1}-p{page_number}",
            )
            for page_number in page_numbers
        )
    return table_pages


def _registered_element_id(
    registry: _ElementRegistry,
    *,
    root: str,
    index: int,
) -> str:
    """Return one preallocated single-target element ID."""
    references = registry.get((root, index))
    if references is None or len(references) != 1:
        _fail("Azure response element registry is inconsistent")
    return references[0].element_id


def _map_advanced_structures(  # noqa: C901, PLR0912, PLR0913, PLR0915
    result: Any,
    *,
    scope: DocumentContentScope | None,
    source_kind: Literal["pdf", "image"],
    file_id: str,
    pages: dict[int, _PageFacts],
    page_spans: dict[int, tuple[DocumentSpan, ...]],
    registry: _ElementRegistry,
    warnings: list[ProcessingWarning],
    max_advanced_elements: int,
    max_field_depth: int,
    max_field_count: int,
    max_element_references: int,
) -> dict[str, tuple[Any, ...]]:
    """Map all document-level advanced structures and resolve references."""
    _MAPPING_STAGE.set("advanced_reference_invalid")
    raw_paragraphs = _items(getattr(result, "paragraphs", None), name="paragraphs")
    raw_pairs = _items(getattr(result, "key_value_pairs", None), name="key-value pairs")
    raw_figures = _items(getattr(result, "figures", None), name="figures")
    raw_sections = _items(getattr(result, "sections", None), name="sections")
    raw_languages = _items(getattr(result, "languages", None), name="languages")
    raw_styles = _items(getattr(result, "styles", None), name="styles")
    raw_documents = _items(getattr(result, "documents", None), name="documents")
    collection_count = sum(
        len(items)
        for items in (
            raw_paragraphs,
            raw_pairs,
            raw_figures,
            raw_sections,
            raw_languages,
            raw_styles,
            raw_documents,
        )
    )
    if collection_count > max_advanced_elements:
        _fail("Azure response advanced element limit exceeded")

    paragraphs: list[DocumentParagraph] = []
    for index, raw in enumerate(raw_paragraphs):
        element_id = _registered_element_id(
            registry,
            root="paragraphs",
            index=index,
        )
        content = getattr(raw, "content", None)
        if not isinstance(content, str):
            _fail("Azure response paragraph content is invalid")
        role = _enum_value(getattr(raw, "role", None))
        if role is not None and role not in _KNOWN_PARAGRAPH_ROLES:
            warnings.append(_warning("unknown_paragraph_roles", 1))
        sources = _sources(
            getattr(raw, "bounding_regions", None),
            source_kind=source_kind,
            file_id=file_id,
            pages=pages,
        )
        if not sources:
            warnings.append(_warning("missing_paragraph_geometry", 1))
        paragraphs.append(
            DocumentParagraph(
                element_id=element_id,
                content=content,
                role=role,
                spans=_spans(getattr(raw, "spans", None), scope=scope),
                sources=sources,
            )
        )

    pairs: list[DocumentKeyValuePair] = []
    for index, raw in enumerate(raw_pairs):
        element_id = _registered_element_id(
            registry,
            root="keyValuePairs",
            index=index,
        )

        def map_element(value: object) -> DocumentKeyValueElement:
            if value is None:
                _fail("Azure response key-value key is missing")
            content = getattr(value, "content", None)
            if not isinstance(content, str):
                _fail("Azure response key-value content is invalid")
            return DocumentKeyValueElement(
                content=content,
                spans=_spans(getattr(value, "spans", None), scope=scope),
                sources=_sources(
                    getattr(value, "bounding_regions", None),
                    source_kind=source_kind,
                    file_id=file_id,
                    pages=pages,
                ),
            )

        key = map_element(getattr(raw, "key", None))
        raw_value = getattr(raw, "value", None)
        value = None if raw_value is None else map_element(raw_value)
        pair_sources = _union_sources(
            cast(
                "tuple[PdfSourceReference | ImageSourceReference, ...]",
                key.sources,
            ),
            (
                ()
                if value is None
                else cast(
                    "tuple[PdfSourceReference | ImageSourceReference, ...]",
                    value.sources,
                )
            ),
        )
        if not pair_sources:
            warnings.append(_warning("missing_key_value_geometry", 1))
        pairs.append(
            DocumentKeyValuePair(
                element_id=element_id,
                key=key,
                value=value,
                confidence=_optional_confidence(raw),
                spans=tuple(
                    sorted(
                        set(key.spans + (() if value is None else value.spans)),
                        key=lambda span: (span.offset, span.length),
                    )
                ),
                sources=pair_sources,
            )
        )

    languages: list[DocumentLanguage] = []
    for raw in raw_languages:
        spans = _spans(getattr(raw, "spans", None), scope=scope)
        locale = getattr(raw, "locale", None)
        if not isinstance(locale, str) or not locale:
            _fail("Azure response language locale is invalid")
        languages.append(
            DocumentLanguage(
                locale=locale,
                confidence=_optional_confidence(raw),
                spans=spans,
                sources=_span_sources(
                    spans,
                    page_spans=page_spans,
                    source_kind=source_kind,
                    file_id=file_id,
                    warnings=warnings,
                    warning_category="language_page_provenance_unavailable",
                ),
            )
        )
    styles: list[DocumentTextStyle] = []
    for raw in raw_styles:
        spans = _spans(getattr(raw, "spans", None), scope=scope)
        styles.append(
            DocumentTextStyle(
                is_handwritten=getattr(raw, "is_handwritten", None),
                font_family=getattr(raw, "similar_font_family", None),
                font_style=_enum_value(getattr(raw, "font_style", None)),
                font_weight=_enum_value(getattr(raw, "font_weight", None)),
                foreground_color=getattr(raw, "color", None),
                background_color=getattr(raw, "background_color", None),
                confidence=_optional_confidence(raw),
                spans=spans,
                sources=_span_sources(
                    spans,
                    page_spans=page_spans,
                    source_kind=source_kind,
                    file_id=file_id,
                    warnings=warnings,
                    warning_category="style_page_provenance_unavailable",
                ),
            )
        )

    document_ids = tuple(
        _registered_element_id(registry, root="documents", index=index)
        for index in range(len(raw_documents))
    )
    figure_ids = tuple(
        _registered_element_id(registry, root="figures", index=index)
        for index in range(len(raw_figures))
    )
    section_ids = tuple(
        _registered_element_id(registry, root="sections", index=index)
        for index in range(len(raw_sections))
    )

    reference_count = 0
    for raw in (*raw_figures, *raw_sections):
        elements = getattr(raw, "elements", None) or ()
        if not isinstance(elements, list | tuple):
            _fail("Azure response element references are invalid")
        reference_count += len(elements)
    for raw in raw_figures:
        caption = getattr(raw, "caption", None)
        if caption is not None:
            reference_count += len(getattr(caption, "elements", None) or ())
        for footnote in getattr(raw, "footnotes", None) or ():
            reference_count += len(getattr(footnote, "elements", None) or ())
    if reference_count > max_element_references:
        _fail("Azure response element reference limit exceeded")

    _MAPPING_STAGE.set("document_field_invalid")
    analyzed_documents: list[AnalyzedDocument] = []
    field_budget = _FieldBudget(
        count=0,
        maximum=max_field_count,
        max_depth=max_field_depth,
    )
    for element_id, raw in zip(document_ids, raw_documents, strict=True):
        document_type = getattr(raw, "doc_type", None)
        if not isinstance(document_type, str) or not document_type:
            _fail("Azure response analyzed document type is invalid")
        raw_fields = getattr(raw, "fields", None) or {}
        if not isinstance(raw_fields, dict):
            _fail("Azure response analyzed document fields are invalid")
        fields = {
            name: _field(
                field,
                depth=1,
                budget=field_budget,
                scope=scope,
                source_kind=source_kind,
                file_id=file_id,
                pages=pages,
                warnings=warnings,
            )
            for name, field in sorted(raw_fields.items())
            if isinstance(name, str) and name
        }
        if len(fields) != len(raw_fields):
            _fail("Azure response analyzed document field name is invalid")
        sources = _sources(
            getattr(raw, "bounding_regions", None),
            source_kind=source_kind,
            file_id=file_id,
            pages=pages,
        )
        if not sources:
            warnings.append(_warning("missing_analyzed_document_geometry", 1))
        analyzed_documents.append(
            AnalyzedDocument(
                element_id=element_id,
                document_type=document_type,
                confidence=_optional_confidence(raw),
                spans=_spans(getattr(raw, "spans", None), scope=scope),
                sources=sources,
                fields=fields,
            )
        )

    _MAPPING_STAGE.set("advanced_reference_invalid")
    figures: list[DocumentFigure] = []
    for element_id, raw in zip(figure_ids, raw_figures, strict=True):
        sources = _sources(
            getattr(raw, "bounding_regions", None),
            source_kind=source_kind,
            file_id=file_id,
            pages=pages,
        )
        if not sources:
            warnings.append(_warning("missing_figure_geometry", 1))
        raw_caption = getattr(raw, "caption", None)
        caption = (
            None
            if raw_caption is None
            else _caption_or_footnote(
                raw_caption,
                element_id=f"{element_id}-caption",
                caption=True,
                scope=scope,
                source_kind=source_kind,
                file_id=file_id,
                pages=pages,
                registry=registry,
                warnings=warnings,
            )
        )
        footnotes = tuple(
            _caption_or_footnote(
                footnote,
                element_id=f"{element_id}-footnote-{footnote_index + 1}",
                caption=False,
                scope=scope,
                source_kind=source_kind,
                file_id=file_id,
                pages=pages,
                registry=registry,
                warnings=warnings,
            )
            for footnote_index, footnote in enumerate(
                _items(getattr(raw, "footnotes", None), name="figure footnotes")
            )
        )
        figures.append(
            DocumentFigure(
                element_id=element_id,
                spans=_spans(getattr(raw, "spans", None), scope=scope),
                sources=sources,
                elements=_resolve_references(
                    getattr(raw, "elements", None),
                    registry=registry,
                    warnings=warnings,
                ),
                caption=caption,
                footnotes=footnotes,
            )
        )

    cyclic_paths = _cyclic_section_paths(raw_sections)
    if cyclic_paths:
        warnings.append(_warning("circular_section_references", len(cyclic_paths)))
    sections: list[DocumentSection] = []
    for element_id, raw in zip(section_ids, raw_sections, strict=True):
        spans = _spans(getattr(raw, "spans", None), scope=scope)
        sections.append(
            DocumentSection(
                element_id=element_id,
                spans=spans,
                elements=_resolve_references(
                    getattr(raw, "elements", None),
                    registry=registry,
                    warnings=warnings,
                    blocked_paths=cyclic_paths,
                ),
                sources=_span_sources(
                    spans,
                    page_spans=page_spans,
                    source_kind=source_kind,
                    file_id=file_id,
                    warnings=warnings,
                    warning_category="section_page_provenance_unavailable",
                ),
            )
        )
    return {
        "paragraphs": tuple(paragraphs),
        "key_value_pairs": tuple(pairs),
        "figures": tuple(figures),
        "sections": tuple(sections),
        "languages": tuple(languages),
        "styles": tuple(styles),
        "analyzed_documents": tuple(analyzed_documents),
    }


def map_azure_result(  # noqa: C901, PLR0912, PLR0913, PLR0915
    result: Any,
    *,
    descriptor: FileDescriptor,
    source_kind: Literal["pdf", "image"],
    expected_page_count: int,
    selected_pages: tuple[int, ...] | None = None,
    provider_name: str = "azure-document-intelligence",
    profile_id: str = "azure-profile",
    model_id: str | None = None,
    max_advanced_elements: int = 20_000,
    max_field_depth: int = 20,
    max_field_count: int = 10_000,
    max_element_references: int = 20_000,
    max_content_characters: int = 5_000_000,
) -> AzureMappingOutcome:
    """Normalize one AnalyzeResult without retaining Azure-owned objects."""
    _MAPPING_STAGE.set("page_mapping_invalid")
    _set_diagnostic(
        "page_list_invalid",
        element_category="page",
        expected_page_count=expected_page_count,
    )
    raw_pages = getattr(result, "pages", None)
    if not isinstance(raw_pages, list) or not raw_pages:
        _fail("Azure response does not contain valid pages")
    azure_pages = tuple(raw_pages)
    mapped_page_facts: list[_PageFacts] = []
    for page_index, page in enumerate(azure_pages):
        _set_diagnostic(
            "page_geometry_invalid",
            page_number=_safe_positive_integer(getattr(page, "page_number", None)),
            element_category="page",
            element_index=page_index + 1,
            expected_page_count=expected_page_count,
            returned_page_count=len(azure_pages),
        )
        mapped_page_facts.append(_page_dimensions(page))
    page_facts = tuple(mapped_page_facts)
    facts_by_number = {facts.number: facts for facts in page_facts}
    if len(facts_by_number) != len(page_facts):
        seen_pages: set[int] = set()
        duplicate_page: int | None = None
        for facts in page_facts:
            if facts.number in seen_pages:
                duplicate_page = facts.number
                break
            seen_pages.add(facts.number)
        _set_diagnostic(
            "page_duplicate",
            page_number=duplicate_page,
            element_category="page",
            expected_page_count=expected_page_count,
            returned_page_count=len(page_facts),
        )
        _fail("Azure response contains duplicate page numbers")
    expected_pages = (
        frozenset(range(1, expected_page_count + 1))
        if selected_pages is None
        else frozenset(selected_pages)
    )
    returned_pages = frozenset(facts_by_number)
    missing_pages = tuple(sorted(expected_pages - returned_pages))
    extra_pages = tuple(sorted(returned_pages - expected_pages))
    if extra_pages:
        _set_diagnostic(
            "page_coverage_extra",
            element_category="page",
            expected_page_count=len(expected_pages),
            returned_page_count=len(returned_pages),
            missing_page_numbers=missing_pages,
            extra_page_numbers=extra_pages,
        )
        if selected_pages is None:
            _fail("Azure response page exceeds the local input")
        _fail("Azure response contains an unrequested page")
    if missing_pages:
        _set_diagnostic(
            "page_coverage_missing",
            element_category="page",
            expected_page_count=len(expected_pages),
            returned_page_count=len(returned_pages),
            missing_page_numbers=missing_pages,
        )
        _fail("Azure response page coverage is incomplete")

    ordered_page_numbers = tuple(sorted(facts_by_number))
    _MAPPING_STAGE.set("content_scope_invalid")
    scope = _content_scope(
        result,
        source_kind=source_kind,
        page_numbers=ordered_page_numbers,
        provider_name=provider_name,
        profile_id=profile_id,
        model_id=model_id,
        max_content_characters=max_content_characters,
    )
    _MAPPING_STAGE.set("page_mapping_invalid")
    warnings = _unsupported_warnings(result)
    registry: _ElementRegistry = {}
    _MAPPING_STAGE.set("advanced_reference_invalid")
    registered_table_pages = _register_element_paths(
        result,
        pages=facts_by_number,
        registry=registry,
    )
    _MAPPING_STAGE.set("page_mapping_invalid")
    text_by_page: dict[int, list[TextBlock]] = defaultdict(list)
    marks_by_page: dict[int, list[DocumentSelectionMark]] = defaultdict(list)
    barcodes_by_page: dict[int, list[DocumentBarcode]] = defaultdict(list)
    formulas_by_page: dict[int, list[DocumentFormula]] = defaultdict(list)
    page_spans: dict[int, tuple[DocumentSpan, ...]] = {}
    missing_line_geometry = 0
    page_level_count = 0
    for page_index, (azure_page, facts) in enumerate(
        zip(azure_pages, page_facts, strict=True)
    ):
        _set_diagnostic(
            "page_span_invalid",
            page_number=facts.number,
            element_category="page",
            element_index=page_index + 1,
        )
        page_spans[facts.number] = _spans(
            getattr(azure_page, "spans", None),
            scope=scope,
            validate_scope_bounds=True,
        )
        _set_diagnostic(
            "line_content_invalid",
            page_number=facts.number,
            element_category="line",
        )
        lines = getattr(azure_page, "lines", None) or ()
        if not isinstance(lines, list | tuple):
            _fail("Azure response page lines are invalid")
        for line_index, line in enumerate(lines):
            _set_diagnostic(
                "line_content_invalid",
                page_number=facts.number,
                element_category="line",
                element_index=line_index + 1,
            )
            content = getattr(line, "content", None)
            if not isinstance(content, str):
                _fail("Azure response line content is invalid")
            confidence = _optional_confidence(line)
            _set_diagnostic(
                "line_geometry_invalid",
                page_number=facts.number,
                element_category="line",
                element_index=line_index + 1,
            )
            bounding_box = _normalized_polygon(
                getattr(line, "polygon", None),
                page=facts,
            )
            if bounding_box is None:
                missing_line_geometry += 1
            element_id = f"text-block-p{facts.number}-{line_index + 1}"
            _set_diagnostic(
                "line_span_invalid",
                page_number=facts.number,
                element_category="line",
                element_index=line_index + 1,
            )
            mapped_line_spans = _spans(
                getattr(line, "spans", None),
                scope=scope,
                validate_scope_bounds=True,
            )
            text_by_page[facts.number].append(
                TextBlock(
                    text=content,
                    source=_source(
                        source_kind=source_kind,
                        file_id=descriptor.file_id,
                        page_number=facts.number,
                        bounding_box=bounding_box,
                    ),
                    confidence=confidence,
                    element_id=element_id,
                    spans=mapped_line_spans,
                )
            )
        for mark_index, mark in enumerate(
            _items(
                getattr(azure_page, "selection_marks", None),
                name="selection marks",
            )
        ):
            _set_diagnostic(
                "selection_mark_invalid",
                page_number=facts.number,
                element_category="selection_mark",
                element_index=mark_index + 1,
            )
            raw_state = _enum_value(getattr(mark, "state", None))
            if raw_state == "selected":
                state: Literal["selected", "unselected"] = "selected"
            elif raw_state == "unselected":
                state = "unselected"
            else:
                _fail("Azure response selection mark state is invalid")
            box = _normalized_polygon(getattr(mark, "polygon", None), page=facts)
            if box is None:
                warnings.append(_warning("missing_selection_mark_geometry", 1))
            marks_by_page[facts.number].append(
                DocumentSelectionMark(
                    element_id=f"selection-mark-p{facts.number}-{mark_index + 1}",
                    state=state,
                    confidence=_optional_confidence(mark),
                    span=_single_span(getattr(mark, "span", None), scope=scope),
                    sources=(
                        _source(
                            source_kind=source_kind,
                            file_id=descriptor.file_id,
                            page_number=facts.number,
                            bounding_box=box,
                        ),
                    ),
                )
            )
            page_level_count += 1
        for barcode_index, barcode in enumerate(
            _items(getattr(azure_page, "barcodes", None), name="barcodes")
        ):
            _set_diagnostic(
                "barcode_invalid",
                page_number=facts.number,
                element_category="barcode",
                element_index=barcode_index + 1,
            )
            kind = _enum_value(getattr(barcode, "kind", None))
            value = getattr(barcode, "value", None)
            if not kind or not isinstance(value, str):
                _fail("Azure response barcode is invalid")
            box = _normalized_polygon(getattr(barcode, "polygon", None), page=facts)
            if box is None:
                warnings.append(_warning("missing_barcode_geometry", 1))
            barcodes_by_page[facts.number].append(
                DocumentBarcode(
                    element_id=f"barcode-p{facts.number}-{barcode_index + 1}",
                    kind=kind,
                    value=value,
                    confidence=_optional_confidence(barcode),
                    span=_single_span(getattr(barcode, "span", None), scope=scope),
                    sources=(
                        _source(
                            source_kind=source_kind,
                            file_id=descriptor.file_id,
                            page_number=facts.number,
                            bounding_box=box,
                        ),
                    ),
                )
            )
            page_level_count += 1
        for formula_index, formula in enumerate(
            _items(getattr(azure_page, "formulas", None), name="formulas")
        ):
            _set_diagnostic(
                "formula_invalid",
                page_number=facts.number,
                element_category="formula",
                element_index=formula_index + 1,
            )
            kind = _enum_value(getattr(formula, "kind", None))
            value = getattr(formula, "value", None)
            if not kind or not isinstance(value, str):
                _fail("Azure response formula is invalid")
            box = _normalized_polygon(getattr(formula, "polygon", None), page=facts)
            if box is None:
                warnings.append(_warning("missing_formula_geometry", 1))
            formulas_by_page[facts.number].append(
                DocumentFormula(
                    element_id=f"formula-p{facts.number}-{formula_index + 1}",
                    kind=kind,
                    value=value,
                    confidence=_optional_confidence(formula),
                    span=_single_span(getattr(formula, "span", None), scope=scope),
                    sources=(
                        _source(
                            source_kind=source_kind,
                            file_id=descriptor.file_id,
                            page_number=facts.number,
                            bounding_box=box,
                        ),
                    ),
                )
            )
            page_level_count += 1
    if page_level_count > max_advanced_elements:
        _fail("Azure response advanced element limit exceeded")
    if missing_line_geometry:
        warnings.append(_warning("missing_line_geometry", missing_line_geometry))

    _MAPPING_STAGE.set("advanced_reference_invalid")
    _MAPPING_STAGE.set("table_mapping_invalid")
    tables_by_page: dict[int, list[Table]] = defaultdict(list)
    table_reference_count = 0
    raw_tables = getattr(result, "tables", None) or ()
    if not isinstance(raw_tables, list | tuple):
        _fail("Azure response tables are invalid")
    for table_index, azure_table in enumerate(raw_tables):
        row_count = _positive_int(
            getattr(azure_table, "row_count", None),
            name="table row count",
        )
        column_count = _positive_int(
            getattr(azure_table, "column_count", None),
            name="table column count",
        )
        table_regions, table_region_count = _regions_by_page(
            getattr(azure_table, "bounding_regions", None),
            pages=facts_by_number,
        )
        if table_region_count > 1:
            warnings.append(_warning("table_multiple_regions", table_region_count))

        raw_cells = getattr(azure_table, "cells", None)
        if not isinstance(raw_cells, list):
            _fail("Azure response table cells are invalid")
        raw_caption = getattr(azure_table, "caption", None)
        raw_footnotes = _items(
            getattr(azure_table, "footnotes", None),
            name="table footnotes",
        )
        annotations = (() if raw_caption is None else (raw_caption,)) + raw_footnotes
        for annotation in annotations:
            table_reference_count += len(
                _items(
                    getattr(annotation, "elements", None),
                    name="table annotation element references",
                )
            )
        cell_facts: list[_TableCellFacts] = []
        for azure_cell in raw_cells:
            row_index = _non_negative_int(
                getattr(azure_cell, "row_index", None),
                name="table cell row index",
            )
            column_index = _non_negative_int(
                getattr(azure_cell, "column_index", None),
                name="table cell column index",
            )
            raw_row_span = getattr(azure_cell, "row_span", None)
            raw_column_span = getattr(azure_cell, "column_span", None)
            row_span = (
                1
                if raw_row_span is None
                else _positive_int(raw_row_span, name="table cell row span")
            )
            column_span = (
                1
                if raw_column_span is None
                else _positive_int(
                    raw_column_span,
                    name="table cell column span",
                )
            )
            if (
                row_index + row_span > row_count
                or column_index + column_span > column_count
            ):
                _fail("Azure response table cell exceeds table bounds")
            content = getattr(azure_cell, "content", None)
            if not isinstance(content, str):
                _fail("Azure response table cell content is invalid")
            cell_region, cell_region_count = _primary_region(
                getattr(azure_cell, "bounding_regions", None),
                pages=facts_by_number,
            )
            cell_sources = _sources(
                getattr(azure_cell, "bounding_regions", None),
                source_kind=source_kind,
                file_id=descriptor.file_id,
                pages=facts_by_number,
            )
            if cell_region_count > 1:
                warnings.append(_warning("cell_multiple_regions", cell_region_count))
            cell_page_number = None
            cell_box = None
            if cell_region is not None:
                cell_page_number = _positive_int(
                    getattr(cell_region, "page_number", None),
                    name="table cell page number",
                )
                cell_box = _normalized_polygon(
                    getattr(cell_region, "polygon", None),
                    page=facts_by_number[cell_page_number],
                )
            if cell_box is None:
                warnings.append(_warning("missing_cell_geometry", 1))
            raw_cell_elements = getattr(azure_cell, "elements", None)
            table_reference_count += len(
                _items(raw_cell_elements, name="table cell element references")
            )
            cell_facts.append(
                _TableCellFacts(
                    row=row_index + 1,
                    column=column_index + 1,
                    row_span=row_span,
                    column_span=column_span,
                    text=content,
                    kind=_enum_value(getattr(azure_cell, "kind", None)),
                    confidence=_optional_confidence(azure_cell),
                    page_number=cell_page_number,
                    bounding_box=cell_box,
                    sources=cell_sources,
                    spans=_spans(
                        getattr(azure_cell, "spans", None),
                        scope=scope,
                    ),
                    elements=_resolve_references(
                        raw_cell_elements,
                        registry=registry,
                        warnings=warnings,
                    ),
                )
            )
        if table_reference_count > max_element_references:
            _fail("Azure response element reference limit exceeded")

        proven_pages = set(table_regions)
        proven_pages.update(
            cell.page_number for cell in cell_facts if cell.page_number is not None
        )
        if not proven_pages:
            warnings.append(_warning("unmappable_table", 1))
            continue
        if len(proven_pages) > 1:
            warnings.append(_warning("table_split_across_pages", 1))
        expected_table_pages = registered_table_pages[table_index]
        if tuple(sorted(proven_pages)) != expected_table_pages:
            _fail("Azure response element registry is inconsistent")
        registered_table_references = registry[("tables", table_index)]
        table_ids_by_page = {
            page_number: reference.element_id
            for page_number, reference in zip(
                expected_table_pages,
                registered_table_references,
                strict=True,
            )
        }

        inherited_page = next(iter(proven_pages)) if len(proven_pages) == 1 else None
        if inherited_page is None:
            unmappable_cells = sum(cell.page_number is None for cell in cell_facts)
            if unmappable_cells:
                warnings.append(_warning("unmappable_table_cells", unmappable_cells))

        for page_number in sorted(proven_pages):
            table_region = table_regions.get(page_number)
            table_box = (
                None
                if table_region is None
                else _normalized_polygon(
                    getattr(table_region, "polygon", None),
                    page=facts_by_number[page_number],
                )
            )
            if table_box is None:
                warnings.append(_warning("missing_table_geometry", 1))
            cells = tuple(
                TableCell(
                    row=cell.row,
                    column=cell.column,
                    row_span=cell.row_span,
                    column_span=cell.column_span,
                    text=cell.text,
                    kind=cell.kind,
                    source=_source(
                        source_kind=source_kind,
                        file_id=descriptor.file_id,
                        page_number=page_number,
                        bounding_box=cell.bounding_box,
                    ),
                    confidence=cell.confidence,
                    spans=cell.spans,
                    sources=cell.sources,
                    elements=cell.elements,
                )
                for cell in cell_facts
                if cell.page_number == page_number
                or (cell.page_number is None and inherited_page == page_number)
            )
            table_element_id = table_ids_by_page[page_number]
            caption = (
                None
                if raw_caption is None
                else _caption_or_footnote(
                    raw_caption,
                    element_id=f"{table_element_id}-caption",
                    caption=True,
                    scope=scope,
                    source_kind=source_kind,
                    file_id=descriptor.file_id,
                    pages=facts_by_number,
                    registry=registry,
                    warnings=warnings,
                )
            )
            footnotes = tuple(
                _caption_or_footnote(
                    footnote,
                    element_id=f"{table_element_id}-footnote-{index + 1}",
                    caption=False,
                    scope=scope,
                    source_kind=source_kind,
                    file_id=descriptor.file_id,
                    pages=facts_by_number,
                    registry=registry,
                    warnings=warnings,
                )
                for index, footnote in enumerate(raw_footnotes)
            )
            tables_by_page[page_number].append(
                Table(
                    cells=cells,
                    source=_source(
                        source_kind=source_kind,
                        file_id=descriptor.file_id,
                        page_number=page_number,
                        bounding_box=table_box,
                    ),
                    row_count=row_count,
                    column_count=column_count,
                    element_id=table_element_id,
                    spans=_spans(
                        getattr(azure_table, "spans", None),
                        scope=scope,
                    ),
                    sources=_sources(
                        getattr(azure_table, "bounding_regions", None),
                        source_kind=source_kind,
                        file_id=descriptor.file_id,
                        pages=facts_by_number,
                    ),
                    caption=caption,
                    footnotes=footnotes,
                )
            )
    advanced = _map_advanced_structures(
        result,
        scope=scope,
        source_kind=source_kind,
        file_id=descriptor.file_id,
        pages=facts_by_number,
        page_spans=page_spans,
        registry=registry,
        warnings=warnings,
        max_advanced_elements=max_advanced_elements - page_level_count,
        max_field_depth=max_field_depth,
        max_field_count=max_field_count,
        max_element_references=max_element_references - table_reference_count,
    )
    _MAPPING_STAGE.set("document_invariant_invalid")
    document_pages = tuple(
        DocumentPage(
            page_number=facts.number,
            dimensions=facts.dimensions,
            text_blocks=tuple(text_by_page[facts.number]),
            tables=tuple(tables_by_page[facts.number]),
            selection_marks=tuple(marks_by_page[facts.number]),
            barcodes=tuple(barcodes_by_page[facts.number]),
            formulas=tuple(formulas_by_page[facts.number]),
            content_spans=page_spans[facts.number],
            source=_source(
                source_kind=source_kind,
                file_id=descriptor.file_id,
                page_number=facts.number,
            ),
        )
        for facts in sorted(page_facts, key=lambda item: item.number)
    )
    return AzureMappingOutcome(
        document=Document(
            file=descriptor,
            pages=document_pages,
            content_scopes=() if scope is None else (scope,),
            paragraphs=advanced["paragraphs"],
            key_value_pairs=advanced["key_value_pairs"],
            figures=advanced["figures"],
            sections=advanced["sections"],
            languages=advanced["languages"],
            styles=advanced["styles"],
            analyzed_documents=advanced["analyzed_documents"],
        ),
        warnings=tuple(warnings),
        page_count=len(document_pages),
        table_count=sum(len(page.tables) for page in document_pages),
    )

"""Deterministic geometry-preserving in-memory OCR preprocessing."""

from __future__ import annotations

from contextlib import ExitStack
from importlib import import_module
from importlib import metadata as importlib_metadata
from typing import TYPE_CHECKING, Any, Never

if TYPE_CHECKING:
    from pydantic import JsonValue

from document_sdk.core._exceptions import redact_exception
from document_sdk.core.errors import (
    DependencyNotInstalledError,
    _raise_redacted_translation,
    redacted_cause,
)
from document_sdk.image._dependencies import (
    IMAGE_DEPENDENCY_MESSAGE,
    require_image_support,
)
from document_sdk.ocr.preprocessing_errors import (
    LocalOcrPreprocessingConfigurationError,
    LocalOcrPreprocessingExecutionError,
    LocalOcrPreprocessingLimitError,
)
from document_sdk.ocr.preprocessing_models import (
    LOCAL_OCR_PREPROCESSING_ALGORITHM_VERSION,
    LocalOcrPreprocessingLimits,
    LocalOcrPreprocessingProfile,
)

_LOW_CONTRAST_THRESHOLD = 160
_BINARY_THRESHOLD = 128
_PROFILE_IMPLEMENTATION_VERSION = "pillow-geometry-preserving-v1"
_MAX_BACKEND_VERSION_LENGTH = 64
_SAFE_BACKEND_VERSION_CHARACTERS = frozenset(
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._+-!"
)


def _reject_backend_version() -> Never:
    msg = "Pillow preprocessing backend version is invalid"
    raise ValueError(msg)


def _pillow_preprocessing_backend_identity() -> dict[str, JsonValue]:
    """Return one bounded content-safe identity for the selected backend."""
    try:
        backend_version = importlib_metadata.version("Pillow")
        if (
            type(backend_version) is not str
            or not 1 <= len(backend_version) <= _MAX_BACKEND_VERSION_LENGTH
            or not backend_version[0].isalnum()
            or not backend_version[0].isascii()
            or any(
                character not in _SAFE_BACKEND_VERSION_CHARACTERS
                for character in backend_version
            )
        ):
            _reject_backend_version()
    except importlib_metadata.PackageNotFoundError as exc:
        _raise_redacted_translation(
            exc,
            DependencyNotInstalledError(IMAGE_DEPENDENCY_MESSAGE),
        )
    except Exception as exc:  # noqa: BLE001 - package metadata is untrusted.
        _raise_redacted_translation(
            exc,
            LocalOcrPreprocessingConfigurationError(
                "Local OCR preprocessing backend identity is unavailable"
            ),
        )
    return {
        "algorithm_version": LOCAL_OCR_PREPROCESSING_ALGORITHM_VERSION,
        "backend_name": "pillow",
        "backend_version": backend_version,
        "profile_implementation_version": _PROFILE_IMPLEMENTATION_VERSION,
    }


def _fail_redacted(exc: BaseException) -> Never:
    cause = redacted_cause(exc)
    redact_exception(exc)
    error = LocalOcrPreprocessingExecutionError("Local OCR preprocessing failed")
    try:
        raise error from cause
    finally:
        error.__context__ = None


def preprocess_local_ocr_rgb(  # noqa: C901, PLR0912
    pixels: bytes,
    *,
    width: int,
    height: int,
    profile: LocalOcrPreprocessingProfile,
    limits: LocalOcrPreprocessingLimits,
) -> bytes:
    """Transform one exact immutable RGB buffer without files or geometry changes."""
    if type(pixels) is not bytes or type(width) is not int or type(height) is not int:
        msg = "Local OCR RGB input is invalid"
        raise LocalOcrPreprocessingExecutionError(msg)
    if width <= 0 or height <= 0 or len(pixels) != width * height * 3:
        msg = "Local OCR RGB input is invalid"
        raise LocalOcrPreprocessingExecutionError(msg)
    pixel_count = width * height
    if pixel_count > limits.max_preprocessing_pixels_per_input:
        raise LocalOcrPreprocessingLimitError(
            limit_name="preprocessing pixels per input",
            observed=pixel_count,
            maximum=limits.max_preprocessing_pixels_per_input,
        )
    # Source RGB, grayscale, one profile intermediate, and output RGB may be
    # alive together. Enforce the conservative raster budget before Pillow
    # performs any allocation.
    working_pixels = pixel_count * 4
    if working_pixels > limits.max_working_pixels:
        raise LocalOcrPreprocessingLimitError(
            limit_name="preprocessing working pixels",
            observed=working_pixels,
            maximum=limits.max_working_pixels,
        )
    output_bytes = pixel_count * 3
    if output_bytes > limits.max_profile_output_bytes:
        raise LocalOcrPreprocessingLimitError(
            limit_name="preprocessing output bytes",
            observed=output_bytes,
            maximum=limits.max_profile_output_bytes,
        )
    if profile is LocalOcrPreprocessingProfile.ORIGINAL:
        return pixels
    try:
        require_image_support()
        image_module = import_module("PIL.Image")
        enhance_module = import_module("PIL.ImageEnhance")
        ops_module = import_module("PIL.ImageOps")
        with ExitStack() as stack:
            image = stack.enter_context(
                image_module.frombytes("RGB", (width, height), pixels)
            )
            gray = stack.enter_context(ops_module.grayscale(image))
            output: Any
            if profile is LocalOcrPreprocessingProfile.DOCUMENT_CLEAN:
                intermediate = stack.enter_context(
                    ops_module.autocontrast(gray, cutoff=0)
                )
                output = stack.enter_context(intermediate.convert("RGB"))
            elif profile is LocalOcrPreprocessingProfile.LOW_CONTRAST:
                enhanced = stack.enter_context(
                    enhance_module.Contrast(gray).enhance(2.0)
                )
                thresholded = stack.enter_context(
                    enhanced.point(
                        lambda value: 255 if value >= _LOW_CONTRAST_THRESHOLD else 0
                    )
                )
                output = stack.enter_context(thresholded.convert("RGB"))
            else:
                thresholded = stack.enter_context(
                    gray.point(lambda value: 255 if value >= _BINARY_THRESHOLD else 0)
                )
                output = stack.enter_context(thresholded.convert("RGB"))
            result = output.tobytes()
        if type(result) is not bytes or len(result) != width * height * 3:
            msg = "Local OCR preprocessing output is invalid"
            raise LocalOcrPreprocessingExecutionError(msg)  # noqa: TRY301
        if len(result) > limits.max_profile_output_bytes:
            raise LocalOcrPreprocessingLimitError(  # noqa: TRY301
                limit_name="preprocessing output bytes",
                observed=len(result),
                maximum=limits.max_profile_output_bytes,
            )
    except (
        DependencyNotInstalledError,
        LocalOcrPreprocessingExecutionError,
        LocalOcrPreprocessingLimitError,
    ):
        raise
    except Exception as exc:  # noqa: BLE001 - Pillow boundary is redacted.
        _fail_redacted(exc)
    else:
        return result

"""Azure Document Intelligence OCR provider."""

from __future__ import annotations

import re
from collections.abc import Callable, Mapping
from contextlib import ExitStack
from time import perf_counter
from typing import TYPE_CHECKING, Any, Never, Protocol, cast

from pydantic import BaseModel

from document_sdk.core import (
    CloudCancellationStatus,
    CloudExecutionAttemptStatus,
    CloudExecutionPolicy,
    CredentialResolutionError,
    DependencyNotInstalledError,
    Document,
    DocumentProcessingError,
    DocumentSdkError,
    FileAccessError,
    ProcessingMetadata,
    ProcessingResult,
    ProviderAuthenticationError,
    ProviderAuthorizationError,
    ProviderConfigurationError,
    ProviderRateLimitError,
    ProviderRequestError,
    ProviderResponseError,
    ProviderTimeoutError,
    ProviderUnavailableError,
    ProviderUsage,
)
from document_sdk.core._exceptions import redact_exception
from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.errors import (
    DocumentSourceChangedError,
    _raise_redacted_translation,
)
from document_sdk.files._source_identity import verify_open_binary
from document_sdk.ocr._azure_dependencies import (
    require_azure_document_intelligence_support,
)
from document_sdk.ocr._azure_execution import (
    attach_cloud_execution_attempt,
    azure_execution_attempt,
    read_cloud_execution_attempt,
)
from document_sdk.ocr._azure_mapping import (
    _AzureMappingResponseError,
    map_azure_result,
)
from document_sdk.ocr._azure_models import AzureDocumentIntelligenceConfig
from document_sdk.ocr._azure_preflight import (
    AZURE_DOCUMENT_INTELLIGENCE_MAX_PAGES_OR_FRAMES,
    AzureInputPreflight,
    azure_page_expression,
    effective_azure_page_limit,
    preflight_azure_input,
    snapshot_azure_input,
    validate_azure_image_snapshot,
)
from document_sdk.ocr.models import DocumentAnalysisFeature
from document_sdk.providers import ProviderContext, ProviderMetadata

if TYPE_CHECKING:
    from pathlib import Path
    from typing import BinaryIO

    from pydantic import JsonValue

    from document_sdk.ocr.models import OcrAnalysisOptions
    from document_sdk.providers import CredentialResolver

_SAFE_SERVICE_CODE = re.compile(r"^[A-Za-z][A-Za-z0-9_.-]{0,127}$")
_SAFE_OPERATION_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$")
_HTTP_STATUS_MIN = 100
_HTTP_STATUS_MAX = 599
_HTTP_UNAUTHORIZED = 401
_HTTP_FORBIDDEN = 403
_HTTP_RATE_LIMITED = 429
_HTTP_SERVER_ERROR_MIN = 500
_MAX_QUERY_FIELDS = 20
_AZURE_DOCUMENT_INTELLIGENCE_BINARY_CONTENT_TYPE = "application/octet-stream"
_AZURE_FEATURE_VALUES = {
    DocumentAnalysisFeature.KEY_VALUE_PAIRS: "keyValuePairs",
    DocumentAnalysisFeature.BARCODES: "barcodes",
    DocumentAnalysisFeature.LANGUAGES: "languages",
    DocumentAnalysisFeature.FORMULAS: "formulas",
    DocumentAnalysisFeature.STYLE_FONT: "styleFont",
    DocumentAnalysisFeature.HIGH_RESOLUTION: "ocrHighResolution",
    DocumentAnalysisFeature.QUERY_FIELDS: "queryFields",
}
_PREBUILT_READ_INCOMPATIBLE_FEATURES = frozenset(
    {
        DocumentAnalysisFeature.KEY_VALUE_PAIRS,
        DocumentAnalysisFeature.FORMULAS,
        DocumentAnalysisFeature.QUERY_FIELDS,
    }
)


class _AzurePoller(Protocol):
    """Minimum generated poller surface consumed by the provider."""

    @property
    def details(self) -> object:
        """Return safe operation facts supplied by Azure Core."""
        ...

    def result(self, timeout: float | None = None) -> object:
        """Wait for and return the analysis result."""
        ...


class _AzureClient(Protocol):
    """Minimum generated client surface consumed by the provider."""

    def begin_analyze_document(
        self,
        model_id: str,
        *,
        body: BinaryIO,
        **kwargs: object,
    ) -> _AzurePoller:
        """Start one analysis operation."""
        ...

    def close(self) -> None:
        """Release the client's transport resources."""
        ...


def _create_azure_client(
    *,
    endpoint: str,
    credential: object,
    api_version: str,
    transport_retry_total: int,
) -> _AzureClient:
    """Construct one per-provider-call Azure client with logging disabled."""
    require_azure_document_intelligence_support()
    from azure.ai.documentintelligence import DocumentIntelligenceClient

    return cast(
        "_AzureClient",
        DocumentIntelligenceClient(
            endpoint=endpoint,
            credential=cast("Any", credential),
            api_version=api_version,
            logging_enable=False,
            retry_total=transport_retry_total,
            retry_connect=transport_retry_total,
            retry_read=transport_retry_total,
            retry_status=transport_retry_total,
        ),
    )


def _safe_status_code(exc: BaseException) -> int | None:
    """Extract only a bounded HTTP status integer from an Azure exception."""
    try:
        status = getattr(exc, "status_code", None)
        if status is None:
            response = getattr(exc, "response", None)
            status = getattr(response, "status_code", None)
        if type(status) is int and _HTTP_STATUS_MIN <= status <= _HTTP_STATUS_MAX:
            return status
    except Exception as access_error:  # noqa: BLE001 - external hook boundary.
        redact_exception(access_error)
        return None
    return None


def _safe_error_code(exc: BaseException) -> str | None:
    """Extract only a syntactically safe Azure service error code."""
    try:
        error = getattr(exc, "error", None)
        code = getattr(error, "code", None)
        if type(code) is str and _SAFE_SERVICE_CODE.fullmatch(code):
            return code
    except Exception as access_error:  # noqa: BLE001 - external hook boundary.
        redact_exception(access_error)
        return None
    return None


def _raise_azure_failure(exc: BaseException) -> Never:
    """Translate Azure transport/service exceptions without backend text."""
    status_code = _safe_status_code(exc)
    error_code = _safe_error_code(exc)
    actual_exception_type = type(exc)
    is_timeout = issubclass(actual_exception_type, TimeoutError)
    exception_name = actual_exception_type.__name__
    timeout_names = {
        "ServiceRequestTimeoutError",
        "ServiceResponseTimeoutError",
    }
    error: DocumentSdkError
    if is_timeout or exception_name in timeout_names:
        error = ProviderTimeoutError("Azure OCR polling timed out")
    elif status_code == _HTTP_UNAUTHORIZED:
        error = ProviderAuthenticationError(
            "Azure OCR authentication failed",
            status_code=status_code,
            error_code=error_code,
        )
    elif status_code == _HTTP_FORBIDDEN:
        error = ProviderAuthorizationError(
            "Azure OCR authorization failed",
            status_code=status_code,
            error_code=error_code,
        )
    elif status_code == _HTTP_RATE_LIMITED:
        error = ProviderRateLimitError(
            "Azure OCR request was rate limited",
            status_code=status_code,
            error_code=error_code,
        )
    elif status_code is not None and status_code >= _HTTP_SERVER_ERROR_MIN:
        error = ProviderUnavailableError(
            "Azure OCR service is unavailable",
            status_code=status_code,
            error_code=error_code,
            retryable=True,
        )
    elif status_code is not None:
        error = ProviderRequestError(
            "Azure OCR request was rejected",
            status_code=status_code,
            error_code=error_code,
        )
    elif exception_name == "CredentialUnavailableError":
        error = CredentialResolutionError(
            "Azure credential could not be resolved",
        )
    elif exception_name in {
        "AuthenticationRequiredError",
        "ClientAuthenticationError",
    }:
        error = ProviderAuthenticationError(
            "Azure OCR authentication failed",
            error_code=error_code,
        )
    else:
        error = ProviderUnavailableError(
            "Azure OCR transport failed",
            error_code=error_code,
            retryable=True,
        )
    _raise_redacted_translation(exc, error)


def _validate_result_identity(
    result: object,
    *,
    model_id: str,
    api_version: str,
) -> None:
    """Reject a response that identifies a different model or API version."""
    try:
        actual_model_id = getattr(result, "model_id", None)
        actual_api_version = getattr(result, "api_version", None)
    except Exception as exc:  # noqa: BLE001 - Azure response is untrusted.
        msg = "Azure response identity could not be validated safely"
        _raise_redacted_translation(exc, ProviderResponseError(msg))
    if type(actual_model_id) is not str or actual_model_id != model_id:
        msg = "Azure response model ID does not match the request"
        raise ProviderResponseError(msg)
    if type(actual_api_version) is not str or actual_api_version != api_version:
        msg = "Azure response API version does not match the request"
        raise ProviderResponseError(msg)


def _operation_id(poller: _AzurePoller) -> str | None:
    """Return a bounded non-secret Azure operation identifier when present."""
    try:
        details = poller.details
        if not isinstance(details, Mapping):
            return None
        value = details.get("operation_id")
        if type(value) is str and _SAFE_OPERATION_ID.fullmatch(value):
            return value
    except Exception as exc:  # noqa: BLE001 - optional metadata is best effort.
        redact_exception(exc)
        return None
    return None


def _revalidate_azure_model[ModelT: BaseModel](
    value: object,
    expected_type: type[ModelT],
    *,
    message: str,
) -> ModelT:
    """Rebuild one Azure input model without trusting instance methods."""
    try:
        return _revalidate_model_instance_json(
            cast("BaseModel", value),
            expected_type,
            message,
        )
    except Exception as exc:  # noqa: BLE001 - public input is untrusted.
        _raise_redacted_translation(exc, ProviderConfigurationError(message))


def _validated_options(
    options: OcrAnalysisOptions | None,
) -> OcrAnalysisOptions | None:
    """Revalidate OCR options before any feature, preflight, or I/O access."""
    if options is None:
        return None
    from document_sdk.ocr.models import OcrAnalysisOptions

    return _revalidate_azure_model(
        options,
        OcrAnalysisOptions,
        message="Azure OCR analysis options are invalid",
    )


def _validated_context_parts(
    context: object,
) -> tuple[
    ProviderContext,
    AzureDocumentIntelligenceConfig,
    ProviderMetadata,
    CredentialResolver,
]:
    """Safely bind validated serializable context parts without resolving."""
    if type(context) is not ProviderContext:
        msg = "Azure OCR provider context is invalid"
        raise ProviderConfigurationError(msg)
    try:
        profile_id = context.profile_id
        config_value = context.config
        metadata_value = context.metadata
        resolver = context.credential_resolver
    except Exception as exc:  # noqa: BLE001 - context boundary is untrusted.
        msg = "Azure OCR provider context could not be read safely"
        _raise_redacted_translation(exc, ProviderConfigurationError(msg))
    config = _revalidate_azure_model(
        config_value,
        AzureDocumentIntelligenceConfig,
        message="Azure OCR provider configuration is invalid",
    )
    metadata = _revalidate_azure_model(
        metadata_value,
        ProviderMetadata,
        message="Azure OCR provider metadata is invalid",
    )
    if metadata.provider_name != config.provider_name:
        msg = "Azure OCR provider context has a mismatched provider name"
        raise ProviderConfigurationError(msg)
    if metadata.model_id != config.model_id:
        msg = "Azure OCR provider context has a mismatched model ID"
        raise ProviderConfigurationError(msg)
    if type(profile_id) is not str or metadata.profile_id != profile_id:
        msg = "Azure OCR provider context has a mismatched profile ID"
        raise ProviderConfigurationError(msg)
    try:
        validated_context = ProviderContext(
            profile_id=profile_id,
            config=config,
            credential_resolver=resolver,
            metadata=metadata,
        )
    except Exception as exc:  # noqa: BLE001 - rebuilt context must stay sanitized.
        msg = "Azure OCR provider context is invalid"
        _raise_redacted_translation(exc, ProviderConfigurationError(msg))
    return validated_context, config, metadata, resolver


def _resolve_credential(resolver: CredentialResolver) -> object:
    """Invoke an untrusted resolver without accepting its classifications."""
    try:
        return resolver.resolve()
    except DependencyNotInstalledError as exc:
        msg = (
            "Azure OCR credential dependency is unavailable; install "
            '"document-processing-sdk[azure-document-intelligence]"'
        )
        _raise_redacted_translation(exc, DependencyNotInstalledError(msg))
    except Exception as exc:  # noqa: BLE001 - resolver boundary is untrusted.
        msg = "Azure OCR credential resolution failed"
        _raise_redacted_translation(exc, CredentialResolutionError(msg))


def _close_client(client: _AzureClient) -> None:
    """Best-effort close without leaking a transport exception."""
    try:
        client.close()
    except Exception:  # noqa: BLE001 - cleanup must not mask the operation.
        return


def _validate_cloud_authorization(
    config: AzureDocumentIntelligenceConfig,
    *,
    fallback: bool,
) -> None:
    """Require explicit direct and, when applicable, fallback authorization."""
    policy = config.cloud_execution_policy
    if not policy.allow_cloud_execution:
        msg = "Cloud execution is not authorized"
        raise ProviderConfigurationError(msg)
    if fallback and not policy.allow_cloud_fallback:
        msg = "Cloud fallback execution is not authorized"
        raise ProviderConfigurationError(msg)


def _validate_cloud_preflight_budget(
    preflight: AzureInputPreflight,
    *,
    config: AzureDocumentIntelligenceConfig,
    options: OcrAnalysisOptions | None,
) -> None:
    """Enforce finite policy budgets before credential or client access."""
    policy = config.cloud_execution_policy
    selected_count = (
        preflight.page_count
        if options is None or options.pages is None
        else len(options.pages)
    )
    if (
        policy.max_logical_cloud_operations < 1
        or policy.max_submitted_operations < 1
        or policy.max_paid_or_possibly_paid_operations < 1
    ):
        msg = "Cloud operation budget is exhausted"
        raise ProviderConfigurationError(msg)
    if selected_count > policy.max_pages_or_frames:
        msg = "Cloud page or frame budget is exceeded"
        raise DocumentProcessingError(msg)
    if preflight.descriptor.size_bytes > policy.max_input_bytes:
        msg = "Cloud input byte budget is exceeded"
        raise DocumentProcessingError(msg)


def _cancel_timed_out_operation(poller: _AzurePoller) -> CloudCancellationStatus:
    """Request cancellation only through an available bounded poller method."""
    try:
        cancel = getattr(poller, "cancel", None)
    except Exception as exc:  # noqa: BLE001 - external property boundary.
        redact_exception(exc)
        return CloudCancellationStatus.FAILED
    if not callable(cancel):
        return CloudCancellationStatus.NOT_SUPPORTED
    try:
        outcome = cancel()
    except Exception as exc:  # noqa: BLE001 - cancellation is best effort.
        redact_exception(exc)
        return CloudCancellationStatus.FAILED
    return (
        CloudCancellationStatus.SUCCEEDED
        if outcome is True
        else CloudCancellationStatus.REQUESTED
    )


def _azure_features(
    options: OcrAnalysisOptions | None,
    *,
    model_id: str,
) -> tuple[str, ...]:
    """Validate explicit feature/model combinations and map exact wire values."""
    try:
        features = () if options is None else getattr(options, "features", ())
    except Exception as exc:  # noqa: BLE001 - request boundary is redacted.
        msg = "Azure OCR requested features could not be prepared"
        _raise_redacted_translation(exc, ProviderConfigurationError(msg))
    if not isinstance(features, tuple) or not all(
        isinstance(feature, DocumentAnalysisFeature) for feature in features
    ):
        msg = "Azure OCR requested features are invalid"
        raise ProviderConfigurationError(msg)
    if model_id == "prebuilt-read" and any(
        feature in _PREBUILT_READ_INCOMPATIBLE_FEATURES for feature in features
    ):
        msg = "Requested Azure OCR feature is incompatible with prebuilt-read"
        raise ProviderConfigurationError(msg)
    return tuple(_AZURE_FEATURE_VALUES[feature] for feature in features)


def _azure_query_fields(options: OcrAnalysisOptions | None) -> tuple[str, ...]:
    """Defensively validate exact Query Fields before local inspection."""
    try:
        query_fields = () if options is None else getattr(options, "query_fields", ())
        features = () if options is None else getattr(options, "features", ())
    except Exception as exc:  # noqa: BLE001 - request boundary is redacted.
        msg = "Azure OCR Query Fields could not be prepared"
        _raise_redacted_translation(exc, ProviderConfigurationError(msg))
    if (
        not isinstance(query_fields, tuple)
        or not all(isinstance(value, str) and value for value in query_fields)
        or len(query_fields) > _MAX_QUERY_FIELDS
        or tuple(sorted(set(query_fields))) != query_fields
        or (bool(query_fields) != (DocumentAnalysisFeature.QUERY_FIELDS in features))
    ):
        msg = "Azure OCR Query Fields are invalid"
        raise ProviderConfigurationError(msg)
    return query_fields


class AzureDocumentIntelligenceProvider:
    """Analyze one local PDF or image through an isolated Azure resource."""

    __slots__ = ("__config", "__context", "__metadata", "__resolver")

    def __init__(self, *, context: ProviderContext) -> None:
        """Bind configuration and a resolver without creating Azure resources."""
        validated_context, config, metadata, resolver = _validated_context_parts(
            context
        )
        self.__context = validated_context
        self.__config = config
        self.__metadata = metadata
        self.__resolver = resolver

    @property
    def context(self) -> ProviderContext:
        """Return this provider instance's isolated runtime context."""
        return self.__context

    def _cloud_execution_policy_snapshot(self) -> CloudExecutionPolicy:
        """Return the already validated immutable policy for SDK orchestration."""
        return self.__config.cloud_execution_policy

    def analyze(
        self,
        path: Path,
        *,
        options: OcrAnalysisOptions | None = None,
    ) -> ProcessingResult[Document]:
        """Analyze one input after explicit direct-cloud authorization."""
        return self._analyze_cloud(path, options=options, fallback=False)

    def _analyze_fallback(
        self,
        path: Path,
        *,
        options: OcrAnalysisOptions | None = None,
    ) -> ProcessingResult[Document]:
        """Analyze one isolated fallback input under both cloud authorizations."""
        return self._analyze_cloud(path, options=options, fallback=True)

    def _analyze_cloud(  # noqa: C901, PLR0912, PLR0913, PLR0915
        self,
        path: Path,
        *,
        options: OcrAnalysisOptions | None,
        fallback: bool,
        preflight_validator: Callable[[AzureInputPreflight], None] | None = None,
        immutable_input_snapshot: bool = False,
        prepared_input_preflight: AzureInputPreflight | None = None,
    ) -> ProcessingResult[Document]:
        """Execute one bounded cloud operation with conservative attempt evidence."""
        started = perf_counter()
        config = self.__config
        metadata = self.__metadata
        validated_options: OcrAnalysisOptions | None = None
        preflight: AzureInputPreflight | None = None
        attempt = azure_execution_attempt(
            config=config,
            metadata=metadata,
            status=CloudExecutionAttemptStatus.NOT_SUBMITTED,
        )
        try:
            validated_options = _validated_options(options)
            attempt = azure_execution_attempt(
                config=config,
                metadata=metadata,
                status=CloudExecutionAttemptStatus.NOT_SUBMITTED,
                options=validated_options,
            )
            azure_features = _azure_features(
                validated_options,
                model_id=config.model_id,
            )
            query_fields = _azure_query_fields(validated_options)
            _validate_cloud_authorization(config, fallback=fallback)
            if prepared_input_preflight is None:
                preflight = preflight_azure_input(
                    path,
                    config=config,
                    options=validated_options,
                )
            else:
                if (
                    type(prepared_input_preflight) is not AzureInputPreflight
                    or prepared_input_preflight.source_kind != "image"
                ):
                    msg = "Prepared Azure OCR input preflight is invalid"
                    raise ProviderConfigurationError(msg)
                preflight = prepared_input_preflight
                if preflight.descriptor.size_bytes > config.max_input_bytes:
                    msg = "Azure OCR input byte limit exceeded"
                    raise DocumentProcessingError(msg)
            _validate_cloud_preflight_budget(
                preflight,
                config=config,
                options=validated_options,
            )
            attempt = azure_execution_attempt(
                config=config,
                metadata=metadata,
                status=CloudExecutionAttemptStatus.FAILED_BEFORE_SUBMIT,
                preflight=preflight,
                options=validated_options,
            )
            if preflight_validator is not None:
                preflight_validator(preflight)
            snapshot_required = (
                immutable_input_snapshot or preflight.source_kind == "image"
            )
            try:
                stream = path.open("rb")
            except OSError as exc:
                if snapshot_required:
                    msg = "Azure OCR input changed before request snapshot"
                    _raise_redacted_translation(exc, DocumentSourceChangedError(msg))
                else:
                    msg = "Azure OCR input could not be opened after local inspection"
                    _raise_redacted_translation(exc, FileAccessError(msg))

            with ExitStack() as stack:
                source_stream = stack.enter_context(stream)
                if snapshot_required:
                    request_stream = stack.enter_context(
                        snapshot_azure_input(
                            source_stream,
                            preflight,
                            max_input_bytes=min(
                                config.max_input_bytes,
                                config.cloud_execution_policy.max_input_bytes,
                            ),
                        )
                    )
                    source_stream.close()
                else:
                    try:
                        verify_open_binary(
                            source_stream,
                            expected_fingerprint=(
                                preflight.descriptor.fingerprint.value
                            ),
                            expected_size=preflight.descriptor.size_bytes,
                            mismatch_message=(
                                "Azure OCR input changed after local inspection"
                            ),
                        )
                    except (OSError, ValueError) as exc:
                        msg = "Azure OCR input changed after local inspection"
                        _raise_redacted_translation(exc, DocumentProcessingError(msg))
                    request_stream = source_stream

                if preflight.source_kind == "image":
                    max_frames = effective_azure_page_limit(
                        config.cloud_execution_policy.max_pages_or_frames,
                        public_model_max_pages_or_frames=(
                            AZURE_DOCUMENT_INTELLIGENCE_MAX_PAGES_OR_FRAMES
                        ),
                    )
                    validate_azure_image_snapshot(
                        request_stream,
                        preflight,
                        validated_options,
                        max_frames=max_frames,
                    )

                credential = _resolve_credential(self.__resolver)
                try:
                    client = _create_azure_client(
                        endpoint=config.endpoint,
                        credential=credential,
                        api_version=config.api_version,
                        transport_retry_total=config.transport_retry_total,
                    )
                except (
                    CredentialResolutionError,
                    DependencyNotInstalledError,
                    ProviderConfigurationError,
                ):
                    raise
                except Exception as exc:  # noqa: BLE001 - Azure boundary is redacted.
                    _raise_azure_failure(exc)

                try:
                    try:
                        request_options: dict[str, object] = {
                            "content_type": (
                                _AZURE_DOCUMENT_INTELLIGENCE_BINARY_CONTENT_TYPE
                            ),
                            "logging_enable": False,
                            "string_index_type": "unicodeCodePoint",
                        }
                        pages = azure_page_expression(validated_options)
                        if pages is not None:
                            request_options["pages"] = pages
                        if (
                            validated_options is not None
                            and validated_options.locale is not None
                        ):
                            request_options["locale"] = validated_options.locale
                        if azure_features:
                            request_options["features"] = list(azure_features)
                        if query_fields:
                            request_options["query_fields"] = list(query_fields)
                    except DocumentSdkError:
                        raise
                    except Exception as exc:  # noqa: BLE001 - redacted boundary.
                        msg = "Azure OCR request options could not be prepared"
                        _raise_redacted_translation(
                            exc,
                            ProviderConfigurationError(msg),
                        )
                    try:
                        poller = client.begin_analyze_document(
                            config.model_id,
                            body=request_stream,
                            **request_options,
                        )
                    except Exception as exc:  # noqa: BLE001 - Azure boundary.
                        try:
                            _raise_azure_failure(exc)
                        except DocumentSdkError as translated:
                            attempt = azure_execution_attempt(
                                config=config,
                                metadata=metadata,
                                status=CloudExecutionAttemptStatus.POSSIBLY_PAID,
                                preflight=preflight,
                                options=validated_options,
                            )
                            attach_cloud_execution_attempt(translated, attempt)
                            raise
                    attempt = azure_execution_attempt(
                        config=config,
                        metadata=metadata,
                        status=CloudExecutionAttemptStatus.SUBMITTED,
                        preflight=preflight,
                        options=validated_options,
                    )
                    try:
                        azure_result = poller.result(
                            timeout=float(config.polling_timeout_seconds)
                        )
                    except Exception as exc:  # noqa: BLE001 - Azure boundary.
                        try:
                            _raise_azure_failure(exc)
                        except DocumentSdkError as translated:
                            cancellation_status = (
                                _cancel_timed_out_operation(poller)
                                if isinstance(translated, ProviderTimeoutError)
                                else CloudCancellationStatus.NOT_ATTEMPTED
                            )
                            attempt = azure_execution_attempt(
                                config=config,
                                metadata=metadata,
                                status=CloudExecutionAttemptStatus.POSSIBLY_PAID,
                                preflight=preflight,
                                options=validated_options,
                                cancellation_status=cancellation_status,
                            )
                            attach_cloud_execution_attempt(translated, attempt)
                            raise
                    attempt = azure_execution_attempt(
                        config=config,
                        metadata=metadata,
                        status=CloudExecutionAttemptStatus.POSSIBLY_PAID,
                        preflight=preflight,
                        options=validated_options,
                    )
                    _validate_result_identity(
                        azure_result,
                        model_id=config.model_id,
                        api_version=config.api_version,
                    )
                    try:
                        outcome = map_azure_result(
                            azure_result,
                            descriptor=preflight.descriptor,
                            source_kind=preflight.source_kind,
                            expected_page_count=preflight.page_count,
                            selected_pages=(
                                None
                                if validated_options is None
                                else validated_options.pages
                            ),
                            provider_name=metadata.provider_name,
                            profile_id=metadata.profile_id,
                            model_id=metadata.model_id,
                            max_advanced_elements=config.max_advanced_elements,
                            max_field_depth=config.max_field_depth,
                            max_field_count=config.max_field_count,
                            max_element_references=config.max_element_references,
                            max_content_characters=config.max_content_characters,
                        )
                    except _AzureMappingResponseError as exc:
                        exc.safe_request_id = _operation_id(poller)
                        raise
                    except ProviderResponseError:
                        raise
                    except Exception as exc:  # noqa: BLE001 - mapping is untrusted.
                        msg = "Azure response could not be normalized safely"
                        error = _AzureMappingResponseError(
                            msg,
                            mapping_code="document_invariant_invalid",
                        )
                        error.safe_request_id = _operation_id(poller)
                        _raise_redacted_translation(exc, error)
                    operation_id = _operation_id(poller)
                finally:
                    _close_client(client)

            completed_attempt = azure_execution_attempt(
                config=config,
                metadata=metadata,
                status=CloudExecutionAttemptStatus.COMPLETED,
                preflight=preflight,
                options=validated_options,
            )
            attributes: dict[str, JsonValue] = {
                "api_version": config.api_version,
                "page_count": outcome.page_count,
                "table_count": outcome.table_count,
            }
            if operation_id is not None:
                attributes["operation_id"] = operation_id
            returned_pages = tuple(page.page_number for page in outcome.document.pages)
            usage = ProviderUsage(
                provider_name=metadata.provider_name,
                profile_id=metadata.profile_id,
                model_id=metadata.model_id,
                api_version=config.api_version,
                provider_resource_identity=config.resource_identity,
                submitted_pages=completed_attempt.submitted_pages,
                returned_pages=(
                    returned_pages if preflight.source_kind == "pdf" else ()
                ),
                submitted_frames=completed_attempt.submitted_frames,
                returned_frames=(
                    returned_pages if preflight.source_kind == "image" else ()
                ),
                requested_features=(
                    ()
                    if validated_options is None
                    else tuple(feature.value for feature in validated_options.features)
                ),
                query_field_count=len(query_fields),
                azure_operation_count=1,
                paid_operation_count=1,
                cloud_logical_operation_count=1,
                cloud_submitted_operation_count=1,
                cloud_paid_or_possibly_paid_operation_count=1,
                cloud_transport_retry_count=0,
            )
            return ProcessingResult[Document](
                data=outcome.document,
                warnings=outcome.warnings,
                metadata=ProcessingMetadata(
                    operation="ocr.analyze",
                    provider_name=metadata.provider_name,
                    profile_id=metadata.profile_id,
                    model_id=metadata.model_id,
                    provider_usage=usage,
                    cloud_execution_attempt=completed_attempt,
                    duration_ms=(perf_counter() - started) * 1_000,
                    attributes=attributes,
                ),
            )
        except (KeyboardInterrupt, SystemExit, GeneratorExit):
            raise
        except DocumentSdkError as exc:
            if read_cloud_execution_attempt(exc) is None:
                attach_cloud_execution_attempt(exc, attempt)
            raise

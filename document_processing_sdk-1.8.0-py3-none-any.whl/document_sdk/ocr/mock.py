"""Deterministic, isolated mock OCR provider."""

from __future__ import annotations

from typing import TYPE_CHECKING

from document_sdk.core import (
    CredentialResolutionError,
    Document,
    DocumentProcessingError,
    FileAccessError,
    PdfSourceReference,
    ProcessingError,
    ProcessingMetadata,
    ProcessingResult,
    ProcessingWarning,
    ProviderUsage,
)
from document_sdk.core._metadata import thaw_json_mapping
from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.errors import _raise_redacted_translation, safe_file_label
from document_sdk.files import calculate_sha256
from document_sdk.ocr.models import OcrAnalysisOptions

if TYPE_CHECKING:
    from pathlib import Path

    from document_sdk.providers import ProviderContext


def _validated_options(
    options: OcrAnalysisOptions | None,
) -> OcrAnalysisOptions | None:
    """Revalidate caller options before path or Credential access."""
    if options is None:
        return None
    try:
        return _revalidate_model_instance_json(
            options,
            OcrAnalysisOptions,
            "Mock OCR analysis options are invalid",
        )
    except Exception as exc:  # noqa: BLE001 - public input is untrusted.
        msg = "Mock OCR analysis options are invalid"
        _raise_redacted_translation(exc, DocumentProcessingError(msg))


class MockOcrProvider:
    """Return injected normalized OCR data without network access."""

    __slots__ = (
        "__context",
        "__document",
        "__errors",
        "__failure",
        "__warnings",
    )

    def __init__(
        self,
        *,
        context: ProviderContext,
        document: Document,
        warnings: tuple[ProcessingWarning, ...] = (),
        errors: tuple[ProcessingError, ...] = (),
        failure: Exception | None = None,
    ) -> None:
        """Bind injected results and failures to exactly one context."""
        self.__context = context
        self.__document = document
        self.__warnings = tuple(warnings)
        self.__errors = tuple(errors)
        self.__failure = failure

    @property
    def context(self) -> ProviderContext:
        """Return this instance's immutable provider context."""
        return self.__context

    def analyze(
        self,
        path: Path,
        *,
        options: OcrAnalysisOptions | None = None,
    ) -> ProcessingResult[Document]:
        """Return injected OCR data and safe provider metadata.

        Args:
            path: Existing local regular file representing the explicit input.
            options: Optional provider-neutral analysis options. The deterministic
                mock accepts and ignores these options.

        Returns:
            The injected document, warnings, errors, and safe provider identity.

        Raises:
            FileAccessError: If the explicit input is not a regular file.
            CredentialResolutionError: If runtime credential resolution fails.
            DocumentProcessingError: If an injected provider failure occurs.
        """
        effective_options = _validated_options(options)

        if not path.exists():
            msg = f"File does not exist: {safe_file_label(path)}"
            raise FileAccessError(msg)
        if not path.is_file():
            msg = f"Path is not a regular file: {safe_file_label(path)}"
            raise FileAccessError(msg)

        try:
            self.__context.credential_resolver.resolve()
        except Exception as exc:  # noqa: BLE001 - provider boundary redacts failures.
            msg = "Credential resolution failed"
            _raise_redacted_translation(exc, CredentialResolutionError(msg))

        fingerprint = calculate_sha256(path)
        if self.__document.file.fingerprint != fingerprint:
            msg = "Injected OCR document does not match the analyzed file"
            raise DocumentProcessingError(msg)

        if self.__failure is not None:
            msg = "Mock OCR provider failed"
            _raise_redacted_translation(
                self.__failure,
                DocumentProcessingError(msg),
            )

        provider_metadata = self.__context.metadata
        returned_pages = tuple(page.page_number for page in self.__document.pages)
        is_pdf = not self.__document.pages or isinstance(
            self.__document.pages[0].source,
            PdfSourceReference,
        )
        submitted_pages = (
            returned_pages
            if effective_options is None or effective_options.pages is None
            else effective_options.pages
        )
        return ProcessingResult[Document](
            data=self.__document,
            warnings=self.__warnings,
            errors=self.__errors,
            metadata=ProcessingMetadata(
                operation="ocr.analyze",
                provider_name=provider_metadata.provider_name,
                profile_id=provider_metadata.profile_id,
                model_id=provider_metadata.model_id,
                provider_usage=ProviderUsage(
                    provider_name=provider_metadata.provider_name,
                    profile_id=provider_metadata.profile_id,
                    model_id=provider_metadata.model_id,
                    submitted_pages=submitted_pages if is_pdf else (),
                    returned_pages=returned_pages if is_pdf else (),
                    submitted_frames=submitted_pages if not is_pdf else (),
                    returned_frames=returned_pages if not is_pdf else (),
                    requested_features=(
                        ()
                        if effective_options is None
                        else tuple(
                            feature.value for feature in effective_options.features
                        )
                    ),
                    query_field_count=(
                        0
                        if effective_options is None
                        else len(effective_options.query_fields)
                    ),
                ),
                attributes=thaw_json_mapping(provider_metadata.attributes),
            ),
        )

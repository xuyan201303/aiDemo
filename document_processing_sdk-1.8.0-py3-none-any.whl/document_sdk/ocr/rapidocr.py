"""Official RapidOCR adapter for the provider-neutral Local OCR protocol."""

from __future__ import annotations

import hashlib
import json
import math
import os
import stat
from contextlib import suppress
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path
from tempfile import TemporaryDirectory
from threading import Lock
from typing import TYPE_CHECKING, Any, Literal, Never, cast
from weakref import finalize

from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.ocr._model_registry import RAPIDOCR_ZH_EN_MODEL
from document_sdk.ocr._rapidocr_dependencies import (
    _RapidOcrDependencies,
    _require_rapidocr_support,
)
from document_sdk.ocr.local_models import (
    LocalOcrEngineIdentity,
    LocalOcrEngineRegion,
    LocalOcrEngineResult,
    LocalOcrImageInput,
)
from document_sdk.ocr.model_policy import (
    LocalOcrModelSelectionPolicy,
    _validated_model_selection_policy,
)
from document_sdk.ocr.rapidocr_errors import (
    RapidOcrEngineInitializationError,
    RapidOcrExecutionError,
    RapidOcrModelValidationError,
)
from document_sdk.ocr.rapidocr_models import (
    _APPROVED_MODEL_HASHES,
    _APPROVED_MODEL_ID,
    RapidOcrEngineConfig,
    RapidOcrModelSet,
)

if TYPE_CHECKING:
    from collections.abc import Sequence

_HASH_CHUNK_BYTES = 1024 * 1024
_CPU_PROVIDER = RAPIDOCR_ZH_EN_MODEL.execution_provider
RAPIDOCR_TEXT_SCORE = 0.0
_OUTPUT_DIMENSIONS = 3
_POINT_DIMENSIONS = 2
_CONFIDENCE_QUANTUM = Decimal("0.000001")
_SNAPSHOT_MODEL_NAMES = ("det.onnx", "cls.onnx", "rec.onnx")
_NATIVE_PATH_TYPE = type(Path())
_MODEL_SET_FIELDS = frozenset(
    {
        "classification_model",
        "classification_sha256",
        "detection_model",
        "detection_sha256",
        "model_id",
        "recognition_model",
        "recognition_sha256",
    }
)
_RUNTIME_IMAGE_FIELDS = {
    "height",
    "mode",
    "pixels",
    "source_index",
    "source_kind",
    "width",
}
_DEFAULT_MODELS = RAPIDOCR_ZH_EN_MODEL.model_files


def _fail_model(message: str) -> Never:
    raise RapidOcrModelValidationError(message)


def _fail_initialization(message: str) -> Never:
    raise RapidOcrEngineInitializationError(message)


def _fail_execution(message: str) -> Never:
    raise RapidOcrExecutionError(message)


def _default_model_set(dependencies: _RapidOcrDependencies) -> RapidOcrModelSet:
    model_root = dependencies.package_root / "models"
    paths = tuple(model_root / name for name, _ in _DEFAULT_MODELS)
    hashes = tuple(expected_hash for _, expected_hash in _DEFAULT_MODELS)
    return RapidOcrModelSet(
        model_id=_APPROVED_MODEL_ID,
        detection_model=paths[0],
        classification_model=paths[1],
        recognition_model=paths[2],
        detection_sha256=hashes[0],
        classification_sha256=hashes[1],
        recognition_sha256=hashes[2],
    )


def _open_model(path: Path) -> int:
    flags = os.O_RDONLY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    return os.open(path, flags)


def _hash_model(
    path: Path,
    *,
    maximum_bytes: int,
    require_single_link: bool = False,
) -> tuple[str, int]:
    try:
        file_stat = path.lstat()
        if (
            not stat.S_ISREG(file_stat.st_mode)
            or (require_single_link and file_stat.st_nlink != 1)
            or path.is_symlink()
            or path.suffix.casefold() != ".onnx"
        ):
            _fail_model("RapidOCR model is not a safe ONNX file")
        if file_stat.st_size > maximum_bytes:
            _fail_model("RapidOCR model file limit exceeded")
        digest = hashlib.sha256()
        observed = 0
        with os.fdopen(_open_model(path), "rb") as stream:
            opened_stat = os.fstat(stream.fileno())
            if (
                not stat.S_ISREG(opened_stat.st_mode)
                or (require_single_link and opened_stat.st_nlink != 1)
                or (opened_stat.st_dev, opened_stat.st_ino, opened_stat.st_size)
                != (file_stat.st_dev, file_stat.st_ino, file_stat.st_size)
            ):
                _fail_model("RapidOCR model identity changed")
            while chunk := stream.read(_HASH_CHUNK_BYTES):
                observed += len(chunk)
                if observed > maximum_bytes:
                    _fail_model("RapidOCR model file limit exceeded")
                digest.update(chunk)
            completed_stat = os.fstat(stream.fileno())
        if observed != file_stat.st_size or (
            completed_stat.st_dev,
            completed_stat.st_ino,
            completed_stat.st_size,
        ) != (
            opened_stat.st_dev,
            opened_stat.st_ino,
            opened_stat.st_size,
        ):
            _fail_model("RapidOCR model identity changed")
        return digest.hexdigest(), observed
    except RapidOcrModelValidationError:
        raise
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception as exc:  # noqa: BLE001 - filesystem boundary is redacted.
        _raise_redacted_translation(
            exc,
            RapidOcrModelValidationError("RapidOCR model validation failed"),
        )


def _validate_models(
    model_set: RapidOcrModelSet,
    config: RapidOcrEngineConfig,
) -> tuple[str, str, str]:
    paths = model_set.runtime_paths
    if (
        model_set.model_id != _APPROVED_MODEL_ID
        or model_set.expected_hashes != _APPROVED_MODEL_HASHES
        or len(paths) != config.max_model_files
        or len(set(paths)) != len(paths)
    ):
        _fail_model("RapidOCR model set is invalid")
    total_bytes = 0
    actual_hashes: list[str] = []
    for path, approved_hash in zip(
        paths,
        _APPROVED_MODEL_HASHES,
        strict=True,
    ):
        actual_hash, size_bytes = _hash_model(
            path,
            maximum_bytes=config.max_model_file_bytes,
        )
        total_bytes += size_bytes
        if total_bytes > config.max_total_model_bytes:
            _fail_model("RapidOCR model set limit exceeded")
        if actual_hash != approved_hash:
            _fail_model("RapidOCR model identity mismatch")
        actual_hashes.append(actual_hash)
    return cast("tuple[str, str, str]", tuple(actual_hashes))


def _copy_model_to_snapshot(
    source: Path,
    destination: Path,
    *,
    approved_hash: str,
    maximum_bytes: int,
) -> int:
    """Copy one exact verified source handle into a private fixed-name file."""
    try:
        return _copy_model_to_snapshot_unchecked(
            source,
            destination,
            approved_hash=approved_hash,
            maximum_bytes=maximum_bytes,
        )
    except RapidOcrModelValidationError:
        raise
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception as exc:  # noqa: BLE001 - filesystem boundary is redacted.
        _raise_redacted_translation(
            exc,
            RapidOcrModelValidationError("RapidOCR model snapshot failed"),
        )


def _copy_model_to_snapshot_unchecked(
    source: Path,
    destination: Path,
    *,
    approved_hash: str,
    maximum_bytes: int,
) -> int:
    source_stat = source.lstat()
    if (
        not stat.S_ISREG(source_stat.st_mode)
        or source.is_symlink()
        or source.suffix.casefold() != ".onnx"
        or source_stat.st_size > maximum_bytes
    ):
        _fail_model("RapidOCR model is not a safe ONNX file")
    source_digest = hashlib.sha256()
    observed = 0
    destination_flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    with (
        os.fdopen(_open_model(source), "rb") as source_stream,
        os.fdopen(
            os.open(destination, destination_flags, 0o600),
            "wb",
        ) as destination_stream,
    ):
        opened_stat = os.fstat(source_stream.fileno())
        if not stat.S_ISREG(opened_stat.st_mode) or (
            opened_stat.st_dev,
            opened_stat.st_ino,
            opened_stat.st_size,
        ) != (source_stat.st_dev, source_stat.st_ino, source_stat.st_size):
            _fail_model("RapidOCR model identity changed")
        while chunk := source_stream.read(_HASH_CHUNK_BYTES):
            observed += len(chunk)
            if observed > maximum_bytes:
                _fail_model("RapidOCR model file limit exceeded")
            source_digest.update(chunk)
            destination_stream.write(chunk)
        destination_stream.flush()
        os.fsync(destination_stream.fileno())
        completed_stat = os.fstat(source_stream.fileno())
    if (
        observed != source_stat.st_size
        or source_digest.hexdigest() != approved_hash
        or (
            completed_stat.st_dev,
            completed_stat.st_ino,
            completed_stat.st_size,
        )
        != (opened_stat.st_dev, opened_stat.st_ino, opened_stat.st_size)
    ):
        _fail_model("RapidOCR model identity changed")
    snapshot_hash, snapshot_bytes = _hash_model(
        destination,
        maximum_bytes=maximum_bytes,
        require_single_link=True,
    )
    if snapshot_hash != approved_hash or snapshot_bytes != observed:
        _fail_model("RapidOCR model snapshot validation failed")
    return observed


def _snapshot_models(
    model_set: RapidOcrModelSet,
    config: RapidOcrEngineConfig,
) -> tuple[TemporaryDirectory[str], tuple[Path, Path, Path]]:
    snapshot: TemporaryDirectory[str] | None = None
    try:
        snapshot = TemporaryDirectory(
            prefix="document-sdk-rapidocr-",
            ignore_cleanup_errors=True,
        )
        root = Path(snapshot.name)
        root.chmod(0o700)
        paths = cast(
            "tuple[Path, Path, Path]",
            tuple(root / name for name in _SNAPSHOT_MODEL_NAMES),
        )
        total_bytes = 0
        for source, destination, approved_hash in zip(
            model_set.runtime_paths,
            paths,
            _APPROVED_MODEL_HASHES,
            strict=True,
        ):
            total_bytes += _copy_model_to_snapshot(
                source,
                destination,
                approved_hash=approved_hash,
                maximum_bytes=config.max_model_file_bytes,
            )
            if total_bytes > config.max_total_model_bytes:
                _fail_model("RapidOCR model set limit exceeded")
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        _cleanup_snapshot(snapshot)
        raise
    except RapidOcrModelValidationError:
        _cleanup_snapshot(snapshot)
        raise
    except Exception as exc:  # noqa: BLE001 - filesystem boundary is redacted.
        _cleanup_snapshot(snapshot)
        _raise_redacted_translation(
            exc,
            RapidOcrModelValidationError("RapidOCR model snapshot failed"),
        )
    else:
        return snapshot, paths


def _cleanup_snapshot(snapshot: TemporaryDirectory[str] | None) -> None:
    if snapshot is None:
        return
    with suppress(Exception):
        snapshot.cleanup()


def _validate_snapshot_models(
    paths: Sequence[Path],
    config: RapidOcrEngineConfig,
) -> None:
    total_bytes = 0
    for path, approved_hash in zip(paths, _APPROVED_MODEL_HASHES, strict=True):
        actual_hash, size_bytes = _hash_model(
            path,
            maximum_bytes=config.max_model_file_bytes,
            require_single_link=True,
        )
        total_bytes += size_bytes
        if actual_hash != approved_hash or total_bytes > config.max_total_model_bytes:
            _fail_model("RapidOCR model snapshot validation failed")


def _identity_digest(
    *,
    config: RapidOcrEngineConfig,
    model_set: RapidOcrModelSet,
    model_hashes: tuple[str, str, str],
    dependencies: _RapidOcrDependencies,
) -> str:
    evidence = {
        "model_id": model_set.model_id,
        "model_sha256": model_hashes,
        "package_version": dependencies.package_version,
        "runtime_version": dependencies.runtime_version,
        "numpy_version": dependencies.numpy_version,
        "opencv_distribution": dependencies.opencv_distribution,
        "opencv_version": dependencies.opencv_version,
        "dependency_versions": dict(dependencies.dependency_versions),
        "device_class": "cpu",
        "language_policy": config.language_policy,
        "preprocess_policy": config.preprocess_policy,
        "text_score": RAPIDOCR_TEXT_SCORE,
        "max_candidates": config.max_candidates,
        "max_output_regions": config.max_output_regions,
        "intra_op_num_threads": config.intra_op_num_threads,
        "inter_op_num_threads": config.inter_op_num_threads,
        "thread_safety": "serialized",
        "output_canonicalization_version": config.output_canonicalization_version,
    }
    encoded = json.dumps(evidence, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def _validated_config(config: RapidOcrEngineConfig | None) -> RapidOcrEngineConfig:
    if config is None:
        return RapidOcrEngineConfig()
    try:
        return _revalidate_model_instance_json(
            config,
            RapidOcrEngineConfig,
            "RapidOCR configuration is invalid",
        )
    except (TypeError, ValueError) as exc:
        _raise_redacted_translation(
            exc,
            RapidOcrEngineInitializationError("RapidOCR configuration is invalid"),
        )


def _validated_model_set(model_set: RapidOcrModelSet) -> RapidOcrModelSet:
    try:
        if type(model_set) is not RapidOcrModelSet:
            _fail_model("RapidOCR model configuration is invalid")
        raw_fields = object.__getattribute__(model_set, "__dict__")
        if type(raw_fields) is not dict:
            _fail_model("RapidOCR model configuration is invalid")
        field_names = tuple(raw_fields)
        if (
            len(field_names) != len(_MODEL_SET_FIELDS)
            or any(type(name) is not str for name in field_names)
            or frozenset(field_names) != _MODEL_SET_FIELDS
        ):
            _fail_model("RapidOCR model configuration is invalid")
        model_id = raw_fields.get("model_id")
        detection_model = raw_fields.get("detection_model")
        classification_model = raw_fields.get("classification_model")
        recognition_model = raw_fields.get("recognition_model")
        detection_sha256 = raw_fields.get("detection_sha256")
        classification_sha256 = raw_fields.get("classification_sha256")
        recognition_sha256 = raw_fields.get("recognition_sha256")
        if (
            type(model_id) is not str
            or type(detection_sha256) is not str
            or type(classification_sha256) is not str
            or type(recognition_sha256) is not str
            or type(detection_model) is not _NATIVE_PATH_TYPE
            or type(classification_model) is not _NATIVE_PATH_TYPE
            or type(recognition_model) is not _NATIVE_PATH_TYPE
        ):
            _fail_model("RapidOCR model configuration is invalid")
        return RapidOcrModelSet(
            model_id=model_id,
            detection_model=detection_model,
            classification_model=cast("Path", classification_model),
            recognition_model=cast("Path", recognition_model),
            detection_sha256=detection_sha256,
            classification_sha256=classification_sha256,
            recognition_sha256=recognition_sha256,
        )
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except RapidOcrModelValidationError:
        raise
    except Exception as exc:  # noqa: BLE001 - forged model boundary is redacted.
        _raise_redacted_translation(
            exc,
            RapidOcrModelValidationError("RapidOCR model configuration is invalid"),
        )


def _validated_runtime_image_input(image: LocalOcrImageInput) -> LocalOcrImageInput:
    """Rebuild one exact runtime-only input without invoking caller hooks."""
    try:
        if type(image) is not LocalOcrImageInput:
            _fail_execution("RapidOCR input is invalid")
        fields = object.__getattribute__(image, "__dict__")
        if type(fields) is not dict or set(fields) != _RUNTIME_IMAGE_FIELDS:
            _fail_execution("RapidOCR input is invalid")
        width = fields.get("width")
        height = fields.get("height")
        mode = fields.get("mode")
        pixels = fields.get("pixels")
        source_kind = fields.get("source_kind")
        source_index = fields.get("source_index")
        if (
            type(width) is not int
            or type(height) is not int
            or type(mode) is not str
            or type(pixels) is not bytes
            or type(source_kind) is not str
            or type(source_index) is not int
        ):
            _fail_execution("RapidOCR input is invalid")
        return LocalOcrImageInput(
            width=width,
            height=height,
            mode=cast("Literal['RGB', 'L']", mode),
            pixels=pixels,
            source_kind=cast("Literal['image', 'pdf']", source_kind),
            source_index=source_index,
        )
    except RapidOcrExecutionError:
        raise
    except Exception as exc:  # noqa: BLE001 - forged runtime input is redacted.
        _raise_redacted_translation(
            exc,
            RapidOcrExecutionError("RapidOCR input is invalid"),
        )


def _canonical_confidence(score: object) -> float:
    if type(score) not in {float, int}:
        _fail_execution("RapidOCR returned an invalid region")
    confidence = float(cast("float | int", score))
    if not math.isfinite(confidence) or not 0 <= confidence <= 1:
        _fail_execution("RapidOCR returned an invalid region")
    canonical = float(
        Decimal(str(confidence)).quantize(
            _CONFIDENCE_QUANTUM,
            rounding=ROUND_HALF_UP,
        )
    )
    return 0.0 if canonical == 0 else canonical


def _canonical_polygon(
    box: object,
    *,
    width: int,
    height: int,
) -> tuple[tuple[float, float], ...]:
    polygon: list[tuple[float, float]] = []
    for point in cast("Any", box):
        if len(point) != _POINT_DIMENSIONS:
            _fail_execution("RapidOCR returned an invalid region")
        x_coordinate = float(point[0])
        y_coordinate = float(point[1])
        if (
            not math.isfinite(x_coordinate)
            or not math.isfinite(y_coordinate)
            or not 0 <= x_coordinate <= width
            or not 0 <= y_coordinate <= height
        ):
            _fail_execution("RapidOCR returned an invalid region")
        polygon.append((x_coordinate, y_coordinate))
    return tuple(polygon)


class RapidOcrEngine:
    """Pinned, lazy, CPU-only RapidOCR implementation of ``LocalOcrEngine``."""

    def __init__(
        self,
        *,
        model_policy: LocalOcrModelSelectionPolicy | None = None,
        config: RapidOcrEngineConfig | None = None,
        model_set: RapidOcrModelSet | None = None,
    ) -> None:
        """Validate dependency, model identity, and deterministic policy."""
        self._model_policy = _validated_model_selection_policy(model_policy)
        self._config = _validated_config(config)
        self._dependencies = _require_rapidocr_support()
        self._model_set = _validated_model_set(
            model_set
            if model_set is not None
            else _default_model_set(self._dependencies)
        )
        self._model_hashes = _validate_models(self._model_set, self._config)
        digest = _identity_digest(
            config=self._config,
            model_set=self._model_set,
            model_hashes=self._model_hashes,
            dependencies=self._dependencies,
        )
        self._identity = LocalOcrEngineIdentity(
            engine_name=RAPIDOCR_ZH_EN_MODEL.engine_name,
            engine_version=self._dependencies.package_version,
            model_id=f"rapidocr-{digest[:48]}",
            languages=self._config.language_policy,
            device_class="cpu",
            thread_safety="serialized",
        )
        self._runtime: Any | None = None
        self._model_snapshot: TemporaryDirectory[str] | None = None
        self._snapshot_finalizer: finalize[[], RapidOcrEngine] | None = None
        self._initialize_lock = Lock()

    @property
    def identity(self) -> LocalOcrEngineIdentity:
        """Return path-free identity without initializing inference sessions."""
        return self._identity

    @property
    def model_selection_policy(self) -> LocalOcrModelSelectionPolicy:
        """Return the canonical path-free model selection policy."""
        return self._model_policy

    def _initialize(self) -> Any:
        if self._runtime is not None:
            return self._runtime
        with self._initialize_lock:
            if self._runtime is not None:
                return self._runtime  # type: ignore[unreachable]  # lock recheck
            snapshot, paths = _snapshot_models(self._model_set, self._config)
            params: dict[str, object] = {
                "Global.log_level": "error",
                "Global.return_word_box": False,
                "Global.return_single_char_box": False,
                "Global.text_score": RAPIDOCR_TEXT_SCORE,
                "Det.model_path": str(paths[0]),
                "Det.engine_type": self._dependencies.onnxruntime_engine_type,
                "Det.lang_type": RAPIDOCR_ZH_EN_MODEL.backend_language_code,
                "Det.max_candidates": self._config.max_candidates,
                "Cls.model_path": str(paths[1]),
                "Cls.engine_type": self._dependencies.onnxruntime_engine_type,
                "Cls.lang_type": RAPIDOCR_ZH_EN_MODEL.backend_language_code,
                "Rec.model_path": str(paths[2]),
                "Rec.engine_type": self._dependencies.onnxruntime_engine_type,
                "Rec.lang_type": RAPIDOCR_ZH_EN_MODEL.backend_language_code,
                "EngineConfig.onnxruntime.use_cuda": False,
                "EngineConfig.onnxruntime.use_dml": False,
                "EngineConfig.onnxruntime.use_cann": False,
                "EngineConfig.onnxruntime.use_coreml": False,
                "EngineConfig.onnxruntime.intra_op_num_threads": (
                    self._config.intra_op_num_threads
                ),
                "EngineConfig.onnxruntime.inter_op_num_threads": (
                    self._config.inter_op_num_threads
                ),
            }
            try:
                candidate = self._dependencies.rapidocr_type(params=params)
                self._verify_cpu_sessions(candidate)
                _validate_snapshot_models(paths, self._config)
            except (KeyboardInterrupt, SystemExit, GeneratorExit):
                _cleanup_snapshot(snapshot)
                raise
            except RapidOcrModelValidationError:
                _cleanup_snapshot(snapshot)
                raise
            except RapidOcrEngineInitializationError:
                _cleanup_snapshot(snapshot)
                raise
            except Exception as exc:  # noqa: BLE001 - third-party boundary is redacted.
                _cleanup_snapshot(snapshot)
                _raise_redacted_translation(
                    exc,
                    RapidOcrEngineInitializationError(
                        "RapidOCR CPU runtime initialization failed"
                    ),
                )
            try:
                snapshot_finalizer = finalize(self, snapshot.cleanup)
            except (KeyboardInterrupt, SystemExit, GeneratorExit):
                _cleanup_snapshot(snapshot)
                raise
            except Exception as exc:  # noqa: BLE001 - lifecycle boundary is redacted.
                _cleanup_snapshot(snapshot)
                _raise_redacted_translation(
                    exc,
                    RapidOcrEngineInitializationError(
                        "RapidOCR CPU runtime initialization failed"
                    ),
                )
            self._model_snapshot = snapshot
            self._snapshot_finalizer = snapshot_finalizer
            self._runtime = candidate
            return candidate

    def _verify_cpu_sessions(self, runtime: Any) -> None:
        try:
            sessions = (
                runtime.text_det.session.session,
                runtime.text_cls.session.session,
                runtime.text_rec.session.session,
            )
            if any(
                type(session) is not self._dependencies.onnxruntime_session_type
                or session.get_providers() != [_CPU_PROVIDER]
                for session in sessions
            ):
                _fail_initialization(
                    "RapidOCR runtime selected an unsupported execution provider"
                )
        except RapidOcrEngineInitializationError:
            raise
        except (AttributeError, TypeError) as exc:
            _raise_redacted_translation(
                exc,
                RapidOcrEngineInitializationError(
                    "RapidOCR CPU provider verification failed"
                ),
            )

    def recognize(self, image: LocalOcrImageInput) -> LocalOcrEngineResult:
        """Run one RGB in-memory inference and return canonical SDK regions."""
        validated_image = _validated_runtime_image_input(image)
        expected_bytes = validated_image.width * validated_image.height * 3
        if (
            validated_image.mode != "RGB"
            or len(validated_image.pixels) != expected_bytes
        ):
            _fail_execution("RapidOCR input is not packed RGB")
        numpy = self._dependencies.numpy
        try:
            rgb = numpy.frombuffer(
                validated_image.pixels,
                dtype=numpy.uint8,
            )
            rgb = rgb.reshape(
                validated_image.height,
                validated_image.width,
                3,
            )
            bgr = numpy.ascontiguousarray(rgb[..., ::-1])
        except (KeyboardInterrupt, SystemExit, GeneratorExit):
            raise
        except Exception as exc:  # noqa: BLE001 - NumPy boundary is redacted.
            _raise_redacted_translation(
                exc,
                RapidOcrExecutionError("RapidOCR input conversion failed"),
            )
        del rgb
        try:
            runtime = self._initialize()
            output = runtime(bgr, text_score=RAPIDOCR_TEXT_SCORE)
            return self._map_output(output, image=validated_image)
        except (KeyboardInterrupt, SystemExit, GeneratorExit):
            raise
        except RapidOcrModelValidationError:
            raise
        except RapidOcrEngineInitializationError:
            raise
        except RapidOcrExecutionError:
            raise
        except Exception as exc:  # noqa: BLE001 - third-party boundary is redacted.
            _raise_redacted_translation(
                exc,
                RapidOcrExecutionError("RapidOCR inference failed"),
            )
        finally:
            del bgr

    def _map_output(
        self,
        output: object,
        *,
        image: LocalOcrImageInput,
    ) -> LocalOcrEngineResult:
        if type(output) is not self._dependencies.output_type:
            _fail_execution("RapidOCR returned an unsupported result")
        supported_output = cast("Any", output)
        boxes = supported_output.boxes
        texts = supported_output.txts
        scores = supported_output.scores
        if boxes is None and texts is None and scores is None:
            return LocalOcrEngineResult()
        if (
            type(boxes) is not self._dependencies.numpy.ndarray
            or type(texts) is not tuple
            or type(scores) is not tuple
            or boxes.ndim != _OUTPUT_DIMENSIONS
            or boxes.shape[1:] != (4, 2)
            or len(boxes) != len(texts)
            or len(texts) != len(scores)
            or len(texts) > self._config.max_output_regions
        ):
            _fail_execution("RapidOCR returned an unsupported result")
        regions: list[LocalOcrEngineRegion] = []
        for index, (box, text, score) in enumerate(
            zip(boxes, texts, scores, strict=True)
        ):
            if type(text) is not str:
                _fail_execution("RapidOCR returned an invalid region")
            regions.append(
                LocalOcrEngineRegion(
                    text=text,
                    polygon=_canonical_polygon(
                        box,
                        width=image.width,
                        height=image.height,
                    ),
                    confidence=_canonical_confidence(score),
                    reading_order=index,
                )
            )
        return LocalOcrEngineResult(regions=tuple(regions))

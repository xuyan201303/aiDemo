"""Private trust boundary for caller-supplied OCR Providers and results."""

from __future__ import annotations

import inspect
import json
import math
import re
from dataclasses import dataclass
from hashlib import sha256
from typing import TYPE_CHECKING, cast

from document_sdk.core import (
    Document,
    DocumentProcessingError,
    DocumentSdkError,
    ProcessingResult,
    ProviderUsage,
)
from document_sdk.core._metadata import (
    _is_sensitive_metadata_key,
    _looks_like_absolute_path,
    _metadata_key_components,
)
from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.ocr._azure_models import AzureDocumentIntelligenceConfig
from document_sdk.ocr.azure import AzureDocumentIntelligenceProvider
from document_sdk.ocr.fallback_models import _looks_like_host_or_endpoint
from document_sdk.ocr.local import LocalOcrProvider
from document_sdk.ocr.local_errors import _attempt_usage
from document_sdk.ocr.mock import MockOcrProvider
from document_sdk.providers.config import ProviderConfig
from document_sdk.providers.context import ProviderContext
from document_sdk.providers.metadata import ProviderMetadata

if TYPE_CHECKING:
    from collections.abc import Callable
    from typing import Any

    from pydantic import BaseModel

_DOCUMENT_PROCESSING_RESULT = ProcessingResult[Document]
_TRUSTED_METHOD_IMPLEMENTATIONS: dict[
    str,
    tuple[tuple[type[object], object], ...],
] = {
    "analyze": (
        (LocalOcrProvider, inspect.getattr_static(LocalOcrProvider, "analyze")),
        (
            AzureDocumentIntelligenceProvider,
            inspect.getattr_static(AzureDocumentIntelligenceProvider, "analyze"),
        ),
        (MockOcrProvider, inspect.getattr_static(MockOcrProvider, "analyze")),
    ),
    "_analyze_bounded": (
        (
            LocalOcrProvider,
            inspect.getattr_static(LocalOcrProvider, "_analyze_bounded"),
        ),
    ),
    "_analyze_prepared": (
        (
            LocalOcrProvider,
            inspect.getattr_static(LocalOcrProvider, "_analyze_prepared"),
        ),
    ),
}
_TRUSTED_LOCAL_METHOD_DESCRIPTORS = (
    inspect.getattr_static(LocalOcrProvider, "_analyze_bounded"),
    inspect.getattr_static(LocalOcrProvider, "_analyze_prepared"),
)
_PROJECTION_MAX_DEPTH = 20
_PROJECTION_MAX_ITEMS = 10_000
_URI_EVIDENCE = re.compile(r"^[A-Za-z][A-Za-z0-9+.-]*://")
_FORBIDDEN_PROJECTION_KEY_COMPONENTS = frozenset(
    {"endpoint", "path", "resolver", "uri", "url"}
)


@dataclass(slots=True)
class _LocalOcrInvocationState:
    """Carry one private Batch budget and its validated Local usage projection."""

    usage_budget: object | None = None
    provider_usage: ProviderUsage | None = None
    batch_narrowed_limit_names: frozenset[str] = frozenset()


@dataclass(frozen=True, slots=True)
class _ProviderContextProjection:
    """Validated identity and deterministic content-safe Resume evidence."""

    metadata: ProviderMetadata
    processing_identity: dict[str, object]
    canonical_resume_payload: str
    resume_fingerprint: str


def _reject_untrusted_invocation_state() -> None:
    msg = "Local OCR invocation state requires an SDK base method"
    raise TypeError(msg)


def _canonical_json(serializer: Any, value: object) -> str:
    """Serialize through one trusted model schema and canonicalize key order."""
    serialized = serializer.to_json(
        value,
        round_trip=True,
        warnings="error",
    )
    payload = json.loads(serialized)
    return json.dumps(
        payload,
        allow_nan=False,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    )


def _require_lossless_result(original_json: str, validated_json: str) -> None:
    """Reject validation that normalizes caller-controlled result evidence."""
    if original_json != validated_json:
        msg = "OCR Provider result changed during validation"
        raise ValueError(msg)


def _require_valid_provider_identity(
    provider_name: object,
    profile_id: object,
    model_id: object,
) -> None:
    """Require canonical non-empty built-in string identity components."""
    if (
        type(provider_name) is not str
        or not provider_name
        or type(profile_id) is not str
        or not profile_id
        or (model_id is not None and (type(model_id) is not str or not model_id))
    ):
        msg = "OCR Provider Context identity is invalid"
        raise ValueError(msg)


def _validated_provider_metadata(context: object) -> ProviderMetadata:
    """Losslessly rebuild Context metadata without instance serialization hooks."""
    metadata = cast("Any", context).metadata
    validated = _revalidate_model_instance_json(
        cast("BaseModel", metadata),
        ProviderMetadata,
        "OCR Provider Context metadata is invalid",
    )
    serializer = ProviderMetadata.__pydantic_serializer__
    _require_lossless_result(
        _canonical_json(serializer, metadata),
        _canonical_json(serializer, validated),
    )
    _require_valid_provider_identity(
        validated.provider_name,
        validated.profile_id,
        validated.model_id,
    )
    return validated


def _projection_key_is_unsafe(key: str) -> bool:
    """Reject secret, endpoint, path, and runtime-resolver key evidence."""
    return bool(
        _is_sensitive_metadata_key(key)
        or _looks_like_absolute_path(key)
        or _FORBIDDEN_PROJECTION_KEY_COMPONENTS.intersection(
            _metadata_key_components(key)
        )
    )


def _projection_string_is_unsafe(value: str) -> bool:
    """Reject path and endpoint-shaped string evidence without resolving it."""
    return bool(
        _looks_like_absolute_path(value)
        or "/" in value
        or "\\" in value
        or _URI_EVIDENCE.match(value)
        or _looks_like_host_or_endpoint(value)
    )


def _normalize_provider_projection(  # noqa: C901, PLR0912
    value: object,
    *,
    depth: int = 0,
    seen: set[int] | None = None,
    item_count: list[int] | None = None,
) -> object:
    """Copy an untrusted JSON projection using exact built-in container types."""
    if depth > _PROJECTION_MAX_DEPTH:
        msg = "Provider Context projection exceeds its nesting limit"
        raise ValueError(msg)
    actual_type = type(value)
    if value is None or actual_type in {bool, int}:
        return value
    if actual_type is float:
        if not math.isfinite(cast("float", value)):
            msg = "Provider Context projection contains a non-finite number"
            raise ValueError(msg)
        return value
    if actual_type is str:
        text = cast("str", value)
        if _projection_string_is_unsafe(text):
            msg = "Provider Context projection contains unsafe string evidence"
            raise ValueError(msg)
        return text
    if actual_type not in {dict, list, tuple}:
        msg = "Provider Context projection contains a non-JSON value"
        raise TypeError(msg)

    identities = seen if seen is not None else set()
    identity = id(value)
    if identity in identities:
        msg = "Provider Context projection contains a cycle"
        raise ValueError(msg)
    identities.add(identity)
    counter = item_count if item_count is not None else [0]
    try:
        if actual_type is dict:
            normalized: dict[str, object] = {}
            for key, nested in cast("dict[object, object]", value).items():
                counter[0] += 1
                if counter[0] > _PROJECTION_MAX_ITEMS:
                    msg = "Provider Context projection exceeds its item limit"
                    raise ValueError(msg)
                if type(key) is not str or _projection_key_is_unsafe(key):
                    msg = "Provider Context projection contains an unsafe key"
                    raise ValueError(msg)
                normalized[key] = _normalize_provider_projection(
                    nested,
                    depth=depth + 1,
                    seen=identities,
                    item_count=counter,
                )
            return normalized
        normalized_items: list[object] = []
        for nested in cast("list[object] | tuple[object, ...]", value):
            counter[0] += 1
            if counter[0] > _PROJECTION_MAX_ITEMS:
                msg = "Provider Context projection exceeds its item limit"
                raise ValueError(msg)
            normalized_items.append(
                _normalize_provider_projection(
                    nested,
                    depth=depth + 1,
                    seen=identities,
                    item_count=counter,
                )
            )
        return normalized_items
    finally:
        identities.remove(identity)


def _trusted_context_projection(
    context: ProviderContext,
    metadata: ProviderMetadata,
) -> dict[str, object] | None:
    """Project known SDK Context configs without calling instance dump hooks."""
    profile_id = object.__getattribute__(context, "_ProviderContext__profile_id")
    config = object.__getattribute__(context, "_ProviderContext__config")
    if type(profile_id) is not str or profile_id != metadata.profile_id:
        msg = "OCR Provider Context profile identity is invalid"
        raise ValueError(msg)

    config_type = type(config)
    expected_type: type[ProviderConfig | AzureDocumentIntelligenceConfig]
    if issubclass(config_type, ProviderConfig):
        expected_type = ProviderConfig
    elif issubclass(config_type, AzureDocumentIntelligenceConfig):
        expected_type = AzureDocumentIntelligenceConfig
    else:
        return None
    validated_config = _revalidate_model_instance_json(
        cast("BaseModel", config),
        expected_type,
        "OCR Provider Context configuration is invalid",
    )
    serializer = expected_type.__pydantic_serializer__
    original_json = _canonical_json(serializer, config)
    validated_json = _canonical_json(serializer, validated_config)
    _require_lossless_result(original_json, validated_json)
    config_payload = json.loads(validated_json)
    if type(config_payload) is not dict:
        msg = "OCR Provider Context configuration is invalid"
        raise TypeError(msg)
    config_payload.pop("endpoint", None)
    if expected_type is ProviderConfig:
        provider_config = cast("ProviderConfig", validated_config)
        if (
            provider_config.provider_name != metadata.provider_name
            or provider_config.profile_id != metadata.profile_id
            or provider_config.model_id != metadata.model_id
        ):
            msg = "OCR Provider Context configuration identity is inconsistent"
            raise ValueError(msg)
    if expected_type is AzureDocumentIntelligenceConfig:
        azure_config = cast("AzureDocumentIntelligenceConfig", validated_config)
        if (
            azure_config.provider_name != metadata.provider_name
            or azure_config.model_id != metadata.model_id
        ):
            msg = "OCR Provider Context configuration identity is inconsistent"
            raise ValueError(msg)
        config_payload["provider_resource_identity"] = azure_config.resource_identity
    metadata_payload = json.loads(
        _canonical_json(ProviderMetadata.__pydantic_serializer__, metadata)
    )
    return {
        "profile_id": profile_id,
        "config": config_payload,
        "metadata": metadata_payload,
    }


def _generic_context_projection(
    context: object,
    metadata: ProviderMetadata,
) -> dict[str, object]:
    """Bind generic safe processing identity to authoritative Provider metadata."""
    safe_dict = cast("Any", context).safe_dict
    metadata_payload = json.loads(
        _canonical_json(ProviderMetadata.__pydantic_serializer__, metadata)
    )
    return {
        "profile_id": metadata.profile_id,
        "metadata": metadata_payload,
        "processing_identity": safe_dict(),
    }


def _require_projection_mapping(value: object) -> dict[str, object]:
    """Require one exact normalized JSON object projection."""
    if type(value) is not dict:
        msg = "Provider Context projection must be a JSON object"
        raise TypeError(msg)
    return cast("dict[str, object]", value)


def _read_provider_context_projection_safely(
    provider: object,
    *,
    error: DocumentSdkError,
) -> _ProviderContextProjection:
    """Return validated Provider metadata and deterministic safe Resume identity."""
    try:
        context = cast("Any", provider).context
        metadata = _validated_provider_metadata(context)
        raw_projection: object | None = None
        if type(context) is ProviderContext:
            raw_projection = _trusted_context_projection(context, metadata)
        if raw_projection is None:
            raw_projection = _generic_context_projection(context, metadata)
        processing_identity = _require_projection_mapping(
            _normalize_provider_projection(raw_projection)
        )
        canonical_payload = json.dumps(
            processing_identity,
            allow_nan=False,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        )
        fingerprint = sha256(canonical_payload.encode()).hexdigest()
    except Exception as exc:  # noqa: BLE001 - caller-owned Context boundary.
        _raise_redacted_translation(exc, error)
    return _ProviderContextProjection(
        metadata=metadata,
        processing_identity=processing_identity,
        canonical_resume_payload=canonical_payload,
        resume_fingerprint=fingerprint,
    )


def _read_provider_identity_safely(
    provider: object,
    *,
    error: DocumentSdkError,
) -> tuple[str, str, str | None]:
    """Return one losslessly rebuilt, content-safe Provider identity."""
    try:
        context = cast("Any", provider).context
        metadata = _validated_provider_metadata(context)
        provider_name = metadata.provider_name
        profile_id = metadata.profile_id
        model_id = metadata.model_id
    except Exception as exc:  # noqa: BLE001 - caller-owned Context boundary.
        _raise_redacted_translation(exc, error)
    return provider_name, profile_id, model_id


def _invoke_ocr_provider_safely(
    provider: object,
    method_name: str,
    *args: object,
    error_message: str,
    invocation_state: _LocalOcrInvocationState | None = None,
    **kwargs: object,
) -> ProcessingResult[Document]:
    """Invoke one Provider method without trusting caller-controlled overrides."""
    trusted_sdk_method = False
    try:
        actual_type = type(provider)
        try:
            descriptor = inspect.getattr_static(actual_type, method_name)
        except AttributeError:
            descriptor = None
        trusted_sdk_method = any(
            actual_type is sdk_provider_type and descriptor is trusted
            for sdk_provider_type, trusted in _TRUSTED_METHOD_IMPLEMENTATIONS.get(
                method_name,
                (),
            )
        )
        if invocation_state is not None:
            if actual_type is not LocalOcrProvider or not any(
                descriptor is trusted for trusted in _TRUSTED_LOCAL_METHOD_DESCRIPTORS
            ):
                _reject_untrusted_invocation_state()
            kwargs["usage_budget"] = invocation_state.usage_budget
        if trusted_sdk_method:
            method = cast("Any", descriptor).__get__(
                provider,
                actual_type,
            )
        else:
            method = cast("Callable[..., object]", getattr(provider, method_name))
        untrusted_result = method(*args, **kwargs)
    except Exception as exc:
        if invocation_state is not None and trusted_sdk_method:
            invocation_state.provider_usage = _attempt_usage(exc)
        if trusted_sdk_method and issubclass(type(exc), DocumentSdkError):
            raise
        _raise_redacted_translation(
            exc,
            DocumentProcessingError(error_message),
        )
    result = _revalidate_document_processing_result(untrusted_result)
    if invocation_state is not None:
        invocation_state.provider_usage = result.metadata.provider_usage
    return result


def _revalidate_document_processing_result(
    value: object,
) -> ProcessingResult[Document]:
    """Losslessly rebuild an untrusted OCR result before any field access."""
    try:
        result = _revalidate_model_instance_json(
            cast("BaseModel", value),
            _DOCUMENT_PROCESSING_RESULT,
            "OCR Provider result is invalid",
        )
        serializer = _DOCUMENT_PROCESSING_RESULT.__pydantic_serializer__
        original_json = _canonical_json(serializer, value)
        validated_json = _canonical_json(serializer, result)
        _require_lossless_result(original_json, validated_json)
    except Exception as exc:  # noqa: BLE001 - untrusted result boundary.
        _raise_redacted_translation(
            exc,
            DocumentProcessingError("OCR Provider result is invalid"),
        )
    return result

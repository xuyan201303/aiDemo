"""Local Azure OCR input preflight before credential resolution."""

from __future__ import annotations

import subprocess
import sys
import warnings
from contextlib import contextmanager
from dataclasses import dataclass
from hashlib import sha256
from tempfile import TemporaryFile
from typing import TYPE_CHECKING, Literal, Never

from document_sdk.core import (
    DocumentProcessingError,
    DocumentSdkError,
    FileDescriptor,
    ImageFrameInspection,
    ImageProcessingError,
    ImageProcessingLimits,
    UnsupportedFileError,
)
from document_sdk.core.errors import (
    DocumentSourceChangedError,
    _raise_redacted_translation,
)
from document_sdk.files import inspect_file

if TYPE_CHECKING:
    from collections.abc import Iterator
    from pathlib import Path
    from typing import BinaryIO

    from document_sdk.ocr._azure_models import AzureDocumentIntelligenceConfig
    from document_sdk.ocr.models import OcrAnalysisOptions

_SUPPORTED_EXTENSIONS = frozenset(
    {".bmp", ".jpeg", ".jpg", ".pdf", ".png", ".tif", ".tiff"}
)
_SUPPORTED_MIME_TYPES = {
    ".bmp": "image/bmp",
    ".jpeg": "image/jpeg",
    ".jpg": "image/jpeg",
    ".pdf": "application/pdf",
    ".png": "image/png",
    ".tif": "image/tiff",
    ".tiff": "image/tiff",
}
type _AzureImageFormat = Literal["BMP", "JPEG", "PNG", "TIFF"]

_IMAGE_FORMAT_BY_EXTENSION: dict[str, _AzureImageFormat] = {
    ".bmp": "BMP",
    ".jpeg": "JPEG",
    ".jpg": "JPEG",
    ".png": "PNG",
    ".tif": "TIFF",
    ".tiff": "TIFF",
}
AZURE_DOCUMENT_INTELLIGENCE_MAX_PAGES_OR_FRAMES = 2_000
_MIN_IMAGE_DIMENSION = 50
_MAX_IMAGE_DIMENSION = 10_000
_SNAPSHOT_CHUNK_SIZE = 1024 * 1024
_SNAPSHOT_FAILURE_MESSAGE = "Azure OCR input snapshot could not be created"
_SOURCE_CHANGED_MESSAGE = "Azure OCR input changed while creating request snapshot"
_IMAGE_DECODE_FAILURE_MESSAGE = "Azure OCR image input could not be decoded safely"
_STRICT_IMAGE_DECODE_COMMAND = (
    "from document_sdk.ocr._azure_preflight import "
    "_run_isolated_image_decode_worker as _run;raise SystemExit(_run())"
)
_ISOLATED_WORKER_ARGUMENT_COUNT = 7
_SHA256_HEX_LENGTH = 64
_WORKER_FILE_ID = "0" * _SHA256_HEX_LENGTH


@dataclass(frozen=True, slots=True)
class AzureInputPreflight:
    """Safe local facts needed for Azure request and source mapping."""

    descriptor: FileDescriptor
    page_count: int
    source_kind: Literal["pdf", "image"]
    image_format: _AzureImageFormat | None = None


def _raise_snapshot_failure() -> Never:
    raise DocumentProcessingError(_SNAPSHOT_FAILURE_MESSAGE)


def _raise_source_changed() -> Never:
    raise DocumentSourceChangedError(_SOURCE_CHANGED_MESSAGE)


def _raise_isolated_decode_failure() -> Never:
    raise ImageProcessingError(_IMAGE_DECODE_FAILURE_MESSAGE)


def _read_snapshot_source(stream: BinaryIO, size: int) -> bytes:
    try:
        return stream.read(size)
    except OSError:
        _raise_source_changed()


def _write_snapshot(snapshot: BinaryIO, chunk: bytes) -> None:
    try:
        snapshot.write(chunk)
    except OSError:
        _raise_snapshot_failure()


@contextmanager
def snapshot_azure_input(
    stream: BinaryIO,
    preflight: AzureInputPreflight,
    *,
    max_input_bytes: int,
) -> Iterator[BinaryIO]:
    """Copy one exact preflight-bound input into an anonymous bounded stream."""
    expected_size = preflight.descriptor.size_bytes
    expected_fingerprint = preflight.descriptor.fingerprint.value
    if expected_size > max_input_bytes:
        msg = "Azure OCR input byte limit exceeded while creating request snapshot"
        raise DocumentProcessingError(msg)
    try:
        snapshot_context = TemporaryFile(  # noqa: SIM115 - entered below after redaction.
            mode="w+b"
        )
    except OSError:
        _raise_snapshot_failure()
    with snapshot_context as snapshot:
        digest = sha256()
        total = 0
        while total < expected_size:
            remaining = expected_size - total
            chunk = _read_snapshot_source(
                stream,
                min(_SNAPSHOT_CHUNK_SIZE, remaining),
            )
            if not chunk:
                break
            if len(chunk) > remaining:
                _raise_source_changed()
            total += len(chunk)
            if total > max_input_bytes:
                msg = (
                    "Azure OCR input byte limit exceeded while creating request "
                    "snapshot"
                )
                raise DocumentProcessingError(msg)
            digest.update(chunk)
            _write_snapshot(snapshot, chunk)
        extra = _read_snapshot_source(stream, 1)
        if (
            extra
            or total != expected_size
            or digest.hexdigest() != expected_fingerprint
        ):
            _raise_source_changed()
        try:
            snapshot.seek(0)
        except OSError:
            _raise_snapshot_failure()
        yield snapshot


def _azure_image_limits(max_frames: int) -> ImageProcessingLimits:
    """Return the finite image limits shared by path and snapshot validation."""
    max_pixels = _MAX_IMAGE_DIMENSION * _MAX_IMAGE_DIMENSION
    return ImageProcessingLimits(
        max_frames=max_frames,
        max_pixels_per_frame=max_pixels,
        max_total_pixels=max_frames * max_pixels,
    )


def _validate_azure_image_dimensions(
    frames: tuple[ImageFrameInspection, ...],
) -> None:
    """Reject decoded image geometry outside Azure's supported bounds."""
    for frame in frames:
        width = getattr(frame, "width", 0)
        height = getattr(frame, "height", 0)
        if (
            width < _MIN_IMAGE_DIMENSION
            or height < _MIN_IMAGE_DIMENSION
            or width > _MAX_IMAGE_DIMENSION
            or height > _MAX_IMAGE_DIMENSION
        ):
            msg = "Image dimensions are outside Azure OCR supported bounds"
            raise UnsupportedFileError(msg)


def _run_isolated_image_decode_worker() -> int:  # noqa: PLR0911  # pragma: no cover
    """Strictly decode selected frames in a fresh interpreter process."""
    try:
        if len(sys.argv) != _ISOLATED_WORKER_ARGUMENT_COUNT:
            return 2
        expected_format = sys.argv[1]
        expected_frame_count = int(sys.argv[2])
        max_frames = int(sys.argv[3])
        selected_frames = tuple(int(value) for value in sys.argv[4].split(","))
        expected_size = int(sys.argv[5])
        expected_fingerprint = sys.argv[6]
        if (
            expected_format not in _IMAGE_FORMAT_BY_EXTENSION.values()
            or expected_frame_count < 1
            or max_frames < expected_frame_count
            or not selected_frames
            or tuple(sorted(set(selected_frames))) != selected_frames
            or selected_frames[0] < 1
            or selected_frames[-1] > expected_frame_count
            or expected_size < 1
            or len(expected_fingerprint) != _SHA256_HEX_LENGTH
            or any(value not in "0123456789abcdef" for value in expected_fingerprint)
        ):
            return 2

        from PIL import Image, ImageFile

        from document_sdk.image.inspection import _inspect_open_image

        ImageFile.LOAD_TRUNCATED_IMAGES = False
        with TemporaryFile(mode="w+b") as isolated_snapshot:
            digest = sha256()
            total = 0
            while True:
                chunk = sys.stdin.buffer.read(
                    min(_SNAPSHOT_CHUNK_SIZE, expected_size - total + 1)
                )
                if not chunk:
                    break
                total += len(chunk)
                if total > expected_size:
                    return 1
                digest.update(chunk)
                isolated_snapshot.write(chunk)
            if total != expected_size or digest.hexdigest() != expected_fingerprint:
                return 1
            isolated_snapshot.seek(0)
            with warnings.catch_warnings():
                warnings.simplefilter("error", Image.DecompressionBombWarning)
                with Image.open(isolated_snapshot) as image:
                    image_format, frames, _inspection_warnings = _inspect_open_image(
                        image,
                        descriptor_file_id=_WORKER_FILE_ID,
                        limits=_azure_image_limits(max_frames),
                        verify_decode=False,
                    )
                    _validate_azure_image_dimensions(frames)
                    if (
                        image_format != expected_format
                        or len(frames) != expected_frame_count
                    ):
                        return 1
                    for frame_number in selected_frames:
                        image.seek(frame_number - 1)
                        image.load()
    except Exception:  # noqa: BLE001 - isolated decoder reports only its status.
        return 1
    return 0


def _decode_azure_image_frames_isolated(  # noqa: PLR0913
    snapshot: BinaryIO,
    *,
    expected_format: _AzureImageFormat,
    expected_frame_count: int,
    selected_frames: tuple[int, ...],
    max_frames: int,
    expected_size: int,
    expected_fingerprint: str,
) -> None:
    """Run strict Pillow decode without mutating the caller process."""
    try:
        snapshot.seek(0)
        with subprocess.Popen(  # noqa: S603 - arguments are internal.
            (
                sys.executable,
                "-I",
                "-c",
                _STRICT_IMAGE_DECODE_COMMAND,
                expected_format,
                str(expected_frame_count),
                str(max_frames),
                ",".join(str(frame) for frame in selected_frames),
                str(expected_size),
                expected_fingerprint,
            ),
            stdin=subprocess.PIPE,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        ) as process:
            worker_input = process.stdin
            if worker_input is None:
                _raise_isolated_decode_failure()
            while chunk := snapshot.read(_SNAPSHOT_CHUNK_SIZE):
                worker_input.write(chunk)
            worker_input.close()
            returncode = process.wait()
    except OSError as exc:
        _raise_redacted_translation(
            exc,
            ImageProcessingError(_IMAGE_DECODE_FAILURE_MESSAGE),
        )
    if returncode:
        _raise_isolated_decode_failure()


def validate_azure_image_snapshot(
    snapshot: BinaryIO,
    preflight: AzureInputPreflight,
    options: OcrAnalysisOptions | None,
    *,
    max_frames: int,
) -> None:
    """Fully decode the selected immutable image frames before Provider access."""
    if preflight.source_kind != "image":
        msg = "Azure OCR image snapshot preflight is inconsistent"
        raise DocumentProcessingError(msg)

    from document_sdk.image._dependencies import require_image_support
    from document_sdk.image.inspection import _inspect_open_image

    require_image_support()
    from PIL import Image

    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(snapshot) as image:
                image_format, frames, _inspection_warnings = _inspect_open_image(
                    image,
                    descriptor_file_id=preflight.descriptor.file_id,
                    limits=_azure_image_limits(max_frames),
                    verify_decode=False,
                )
                _validate_azure_image_dimensions(frames)
                expected_format = (
                    preflight.image_format
                    or _IMAGE_FORMAT_BY_EXTENSION.get(preflight.descriptor.extension)
                )
                if expected_format is None or image_format != expected_format:
                    msg = "Azure OCR image format does not match its input descriptor"
                    raise UnsupportedFileError(msg)  # noqa: TRY301
                if len(frames) != preflight.page_count:
                    msg = "Azure OCR image frame count changed before submission"
                    raise DocumentSourceChangedError(msg)  # noqa: TRY301
                selected_frames = (
                    tuple(range(1, len(frames) + 1))
                    if options is None or options.pages is None
                    else options.pages
                )
        _decode_azure_image_frames_isolated(
            snapshot,
            expected_format=expected_format,
            expected_frame_count=len(frames),
            selected_frames=selected_frames,
            max_frames=max_frames,
            expected_size=preflight.descriptor.size_bytes,
            expected_fingerprint=preflight.descriptor.fingerprint.value,
        )
    except DocumentSdkError:
        raise
    except (Image.DecompressionBombWarning, Image.DecompressionBombError) as exc:
        msg = "Azure OCR image exceeds the decompression safety threshold"
        _raise_redacted_translation(exc, ImageProcessingError(msg))
    except Exception as exc:  # noqa: BLE001 - Pillow boundary is redacted.
        msg = "Azure OCR image input could not be decoded safely"
        _raise_redacted_translation(exc, ImageProcessingError(msg))
    try:
        snapshot.seek(0)
    except OSError:
        _raise_snapshot_failure()


def effective_azure_page_limit(
    caller_max_pages_or_frames: int,
    *,
    public_model_max_pages_or_frames: int,
) -> int:
    """Return the finite page boundary shared by planning and execution."""
    return min(
        caller_max_pages_or_frames,
        AZURE_DOCUMENT_INTELLIGENCE_MAX_PAGES_OR_FRAMES,
        public_model_max_pages_or_frames,
    )


def _validate_selected_pages(
    options: OcrAnalysisOptions | None,
    page_count: int,
) -> None:
    """Reject selected pages that do not exist in the local input."""
    if options is None or options.pages is None:
        return
    invalid_pages = tuple(page for page in options.pages if page > page_count)
    if invalid_pages:
        msg = "OCR selected pages exceed the local document page count"
        raise DocumentProcessingError(msg)


def _preflight_pdf(
    path: Path,
    config: AzureDocumentIntelligenceConfig,
    options: OcrAnalysisOptions | None,
    *,
    max_pages: int,
) -> int:
    """Inspect PDF page count, geometry, and encryption without reading text."""
    from document_sdk.pdf import PdfProcessingLimits
    from document_sdk.pdf._document import preflight_pdf_structure

    _descriptor, preflight = preflight_pdf_structure(
        path,
        PdfProcessingLimits(
            max_file_bytes=config.max_input_bytes,
            max_pages=max_pages,
            max_native_text_pages=max_pages,
        ),
    )
    _validate_selected_pages(options, preflight.page_count)
    return preflight.page_count


def _preflight_image(
    path: Path,
    options: OcrAnalysisOptions | None,
    *,
    max_frames: int,
) -> int:
    """Inspect image frame counts and Azure-compatible dimensions locally."""
    from document_sdk.image import inspect_image

    inspection = inspect_image(
        path,
        limits=_azure_image_limits(max_frames),
        verify_decode=False,
    )
    _validate_azure_image_dimensions(inspection.frames)
    _validate_selected_pages(options, inspection.frame_count)
    return inspection.frame_count


def preflight_azure_input(
    path: Path,
    *,
    config: AzureDocumentIntelligenceConfig,
    options: OcrAnalysisOptions | None,
) -> AzureInputPreflight:
    """Validate file type, size, pages, and geometry before credentials."""
    policy_max = config.cloud_execution_policy.max_pages_or_frames
    max_pages_or_frames = effective_azure_page_limit(
        policy_max or AZURE_DOCUMENT_INTELLIGENCE_MAX_PAGES_OR_FRAMES,
        public_model_max_pages_or_frames=(
            AZURE_DOCUMENT_INTELLIGENCE_MAX_PAGES_OR_FRAMES
        ),
    )
    descriptor = inspect_file(path)
    if descriptor.extension not in _SUPPORTED_EXTENSIONS:
        msg = "Azure OCR supports only PDF, PNG, JPEG, TIFF, and BMP inputs"
        raise UnsupportedFileError(msg)
    if descriptor.mime_type != _SUPPORTED_MIME_TYPES[descriptor.extension]:
        msg = "Azure OCR input MIME type does not match its supported extension"
        raise UnsupportedFileError(msg)
    if descriptor.size_bytes > config.max_input_bytes:
        msg = (
            "Azure OCR input byte limit exceeded: "
            f"observed {descriptor.size_bytes}, maximum {config.max_input_bytes}"
        )
        raise DocumentProcessingError(msg)
    if descriptor.extension == ".pdf":
        page_count = _preflight_pdf(
            path,
            config,
            options,
            max_pages=max_pages_or_frames,
        )
        source_kind: Literal["pdf", "image"] = "pdf"
        image_format = None
    else:
        page_count = _preflight_image(
            path,
            options,
            max_frames=max_pages_or_frames,
        )
        source_kind = "image"
        image_format = _IMAGE_FORMAT_BY_EXTENSION[descriptor.extension]
    if page_count > max_pages_or_frames:
        msg = "Azure OCR input exceeds the supported page or frame count"
        raise DocumentProcessingError(msg)
    return AzureInputPreflight(
        descriptor=descriptor,
        page_count=page_count,
        source_kind=source_kind,
        image_format=image_format,
    )


def azure_page_expression(options: OcrAnalysisOptions | None) -> str | None:
    """Convert normalized pages into Azure's canonical comma/range syntax."""
    if options is None or options.pages is None:
        return None
    if not options.pages:
        msg = "Azure OCR pages must contain at least one page"
        raise ValueError(msg)
    ranges: list[str] = []
    start = previous = options.pages[0]
    for page in options.pages[1:]:
        if page == previous + 1:
            previous = page
            continue
        ranges.append(str(start) if start == previous else f"{start}-{previous}")
        start = previous = page
    ranges.append(str(start) if start == previous else f"{start}-{previous}")
    return ",".join(ranges)

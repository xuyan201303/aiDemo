"""Private isolated-input execution for explicit Azure page-level fallback."""

# ruff: noqa: BLE001, C901, EM101, PLR0912, PLR0913, PLR0915, TRY003, TRY301

from __future__ import annotations

import hashlib
import inspect
import io
import json
import os
import stat
import tempfile
from collections.abc import Mapping
from contextlib import contextmanager, nullcontext, suppress
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal, Never, cast

from pydantic import BaseModel

from document_sdk.core import (
    CloudExecutionAttemptEvidence,
    CloudExecutionAttemptStatus,
    CloudExecutionPolicy,
    Document,
    DocumentContentScope,
    DocumentElementReference,
    DocumentField,
    DocumentPage,
    DocumentSpan,
    DocxSourceReference,
    ExcelSourceReference,
    FileDescriptor,
    ImageProcessingLimits,
    ImageSourceReference,
    LocalOcrQualityDecision,
    LocalOcrQualityReport,
    PdfSourceReference,
    ProcessingMetadata,
    ProcessingResult,
    ProviderUsage,
)
from document_sdk.core._exceptions import redact_exception
from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.errors import (
    DocumentSdkError,
    DocumentSourceChangedError,
    redacted_cause,
)
from document_sdk.core.models import SdkModel
from document_sdk.files import inspect_file
from document_sdk.image._io import _open_image_frame_pixel_stream
from document_sdk.ocr._azure_execution import (
    _validated_completed_cloud_result,
    read_cloud_execution_attempt,
)
from document_sdk.ocr.azure import AzureDocumentIntelligenceProvider
from document_sdk.ocr.fallback_errors import (
    AzureFallbackConfigurationError,
    AzureFallbackError,
    AzureFallbackExecutionError,
    AzureFallbackInvalidResultError,
    AzureFallbackLimitError,
    AzureFallbackMappingError,
    AzureFallbackPayloadError,
    AzureFallbackProviderTypeError,
    AzureFallbackSourceChangedError,
)
from document_sdk.ocr.fallback_models import (
    AzureFallbackAttemptEvidence,
    AzureFallbackProviderIdentity,
    AzurePageFallbackPolicy,
    AzurePageFallbackReport,
    AzurePageFallbackResult,
    AzurePageFallbackStatus,
    _validate_azure_fallback_policy,
    _validate_azure_fallback_result,
)
from document_sdk.ocr.preprocessing_models import (
    LocalOcrPreprocessingReport,
    _validate_preprocessing_quality_lineage,
)
from document_sdk.pdf import PdfProcessingLimits, render_page

if TYPE_CHECKING:
    from collections.abc import Callable, Iterator

_CHUNK_SIZE = 1024 * 1024


def _raise_redacted_translation(exc: BaseException, error: Exception) -> Never:
    """Raise with a type-only cause and no reference to the untrusted context."""
    cause = redacted_cause(exc)
    redact_exception(exc)
    try:
        raise error from cause
    finally:
        error.__context__ = None


def _is_actual_azure_provider(value: object) -> bool:
    """Check the actual Python type without consulting a hostile __class__."""
    actual_type = type(value)
    try:
        return issubclass(actual_type, AzureDocumentIntelligenceProvider)
    except TypeError:
        return False


def _fallback_candidates(
    report: LocalOcrQualityReport,
    document: Document,
) -> tuple[Literal["page", "frame"], tuple[int, ...]]:
    """Validate that retry candidates are an exact subset of evaluated inputs."""
    summary = report.summary
    page_sources = tuple(page.source for page in document.pages)
    if not page_sources:
        raise AzureFallbackMappingError("Fallback document has no source inputs")
    is_pdf = isinstance(page_sources[0], PdfSourceReference)
    if any(isinstance(source, PdfSourceReference) != is_pdf for source in page_sources):
        raise AzureFallbackMappingError(
            "Fallback document source types are inconsistent"
        )
    if summary.decision is not LocalOcrQualityDecision.FAIL:
        if summary.recommended_retry_pages or summary.recommended_retry_frames:
            raise AzureFallbackInvalidResultError(
                "Non-failing quality evidence contains fallback candidates"
            )
        return ("page" if is_pdf else "frame"), ()
    candidates = (
        summary.recommended_retry_pages if is_pdf else summary.recommended_retry_frames
    )
    evaluated = summary.evaluated_pages if is_pdf else summary.evaluated_frames
    if not candidates or tuple(sorted(set(candidates))) != candidates:
        raise AzureFallbackInvalidResultError(
            "Failing quality evidence has invalid fallback candidates"
        )
    if not set(candidates).issubset(evaluated):
        raise AzureFallbackInvalidResultError(
            "Fallback candidates are outside evaluated Local OCR inputs"
        )
    document_indexes = {page.page_number for page in document.pages}
    if not set(candidates).issubset(document_indexes):
        raise AzureFallbackInvalidResultError(
            "Fallback candidates are outside the analyzed document"
        )
    if not set(evaluated).issubset(document_indexes):
        raise AzureFallbackInvalidResultError(
            "Evaluated Local OCR inputs are outside the analyzed document"
        )
    return ("page" if is_pdf else "frame"), candidates


def _enforce_candidate_limits(
    *,
    kind: Literal["page", "frame"],
    count: int,
    policy: AzurePageFallbackPolicy,
) -> None:
    maximum = (
        policy.max_fallback_pages_per_document
        if kind == "page"
        else policy.max_fallback_frames_per_document
    )
    if count > maximum:
        raise AzureFallbackLimitError("Fallback source-index limit exceeded")
    if count > policy.max_fallback_inputs_per_document:
        raise AzureFallbackLimitError("Fallback input limit exceeded")
    if count > policy.max_fallback_operations_per_document:
        raise AzureFallbackLimitError("Fallback operation limit exceeded")
    if count and (
        policy.max_payload_bytes_per_input == 0
        or policy.max_payload_bytes_per_document == 0
    ):
        raise AzureFallbackLimitError("Fallback payload byte budget is exhausted")


def _content_family(signature: bytes) -> str | None:
    if signature.startswith(b"%PDF-"):
        return "page"
    if signature.startswith(
        (b"\x89PNG\r\n\x1a\n", b"\xff\xd8\xff", b"II*\x00", b"MM\x00*", b"BM")
    ) or (signature.startswith(b"RIFF") and signature[8:12] == b"WEBP"):
        return "frame"
    return None


def _measure_source_stream(
    input_stream: Any,
    *,
    expected_size: int,
    output_stream: Any | None = None,
) -> tuple[str, int, bytes]:
    """Measure bounded chunks, optionally copying the exact measured bytes."""
    digest = hashlib.sha256()
    size = 0
    signature = b""
    remaining = expected_size + 1
    while remaining:
        chunk = input_stream.read(min(_CHUNK_SIZE, remaining))
        if not chunk:
            break
        if not signature:
            signature = chunk[:16]
        digest.update(chunk)
        size += len(chunk)
        remaining -= len(chunk)
        if output_stream is not None:
            output_stream.write(chunk)
    return digest.hexdigest(), size, signature


def _source_identity_matches(
    measured: tuple[str, int, bytes],
    *,
    descriptor: FileDescriptor,
    expected_kind: str,
) -> bool:
    fingerprint, size, signature = measured
    return (
        fingerprint == descriptor.fingerprint.value
        and size == descriptor.size_bytes
        and _content_family(signature) == expected_kind
    )


def _verify_source_identity_without_copy(
    source: Path,
    *,
    descriptor: FileDescriptor,
    expected_kind: str,
) -> None:
    """Verify a non-candidate source without creating a private Snapshot."""
    try:
        with source.open("rb") as input_stream:
            measured = _measure_source_stream(
                input_stream,
                expected_size=descriptor.size_bytes,
            )
        if not _source_identity_matches(
            measured,
            descriptor=descriptor,
            expected_kind=expected_kind,
        ):
            raise AzureFallbackPayloadError(
                "Fallback source identity does not match the Local document"
            )
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except AzureFallbackError:
        raise
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            AzureFallbackPayloadError("Fallback source identity could not be verified"),
        )


@contextmanager
def _verified_source_snapshot(
    source: Path,
    *,
    descriptor: FileDescriptor,
    expected_kind: str,
) -> Iterator[Path]:
    """Copy and verify the exact source bytes before any adapter can consume them."""
    suffix = ".pdf" if expected_kind == "page" else descriptor.extension
    temporary: str | None = None
    try:
        with (
            source.open("rb") as input_stream,
            tempfile.NamedTemporaryFile(
                suffix=suffix,
                delete=False,
            ) as output_stream,
        ):
            temporary = output_stream.name
            measured = _measure_source_stream(
                input_stream,
                expected_size=descriptor.size_bytes,
                output_stream=output_stream,
            )
        if not _source_identity_matches(
            measured,
            descriptor=descriptor,
            expected_kind=expected_kind,
        ):
            raise AzureFallbackPayloadError(
                "Fallback source identity does not match the Local document"
            )
        Path(temporary).chmod(0o600)
        yield Path(temporary)
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except AzureFallbackError:
        raise
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            AzureFallbackPayloadError("Fallback source snapshot could not be created"),
        )
    finally:
        if temporary is not None:
            with suppress(OSError):
                Path(temporary).unlink(missing_ok=True)


def _snapshot_token(path: Path, descriptor: FileDescriptor) -> tuple[int, ...]:
    try:
        measured = path.lstat()
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            AzureFallbackPayloadError("Fallback source snapshot could not be verified"),
        )
    if (
        not stat.S_ISREG(measured.st_mode)
        or stat.S_ISLNK(measured.st_mode)
        or measured.st_size != descriptor.size_bytes
    ):
        raise AzureFallbackPayloadError("Fallback source snapshot changed")
    return (
        measured.st_dev,
        measured.st_ino,
        measured.st_size,
        measured.st_mtime_ns,
        measured.st_ctime_ns,
    )


def _provider_identity(
    provider: AzureDocumentIntelligenceProvider,
) -> AzureFallbackProviderIdentity:
    try:
        context = provider.context
        metadata = context.metadata
        config = cast("Any", context.config)
        return AzureFallbackProviderIdentity(
            provider_name=cast("Any", metadata.provider_name),
            profile_id=metadata.profile_id,
            model_id=metadata.model_id,
            api_version=config.api_version,
            provider_resource_identity=config.resource_identity,
        )
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            AzureFallbackProviderTypeError(
                "Azure fallback Provider identity is unavailable"
            ),
        )


def _provider_cloud_execution_policy(
    provider: AzureDocumentIntelligenceProvider,
) -> CloudExecutionPolicy | None:
    """Read the production provider's validated policy without credentials."""
    try:
        return AzureDocumentIntelligenceProvider._cloud_execution_policy_snapshot(  # noqa: SLF001 - internal Provider trust boundary.
            provider,
        )
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception as exc:
        if type(provider) is not AzureDocumentIntelligenceProvider:
            return None
        _raise_redacted_translation(
            exc,
            AzureFallbackProviderTypeError(
                "Azure fallback cloud execution policy is unavailable"
            ),
        )


def _encode_frame_payload(pixel_stream: Any, index: int) -> bytes:
    try:
        from PIL import Image

        pixels = pixel_stream.read_frame(index)
        with (
            Image.frombytes(
                pixels.mode,
                (pixels.width, pixels.height),
                pixels.pixels,
            ) as image,
            io.BytesIO() as output,
        ):
            image.save(output, format="PNG")
            return output.getvalue()
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except DocumentSdkError:
        raise
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            AzureFallbackPayloadError(
                "An isolated Azure fallback payload could not be encoded"
            ),
        )


def _write_payload(directory: Path, ordinal: int, payload: bytes) -> Path:
    path = directory / f"input-{ordinal:05d}.png"
    try:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(payload)
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            AzureFallbackPayloadError(
                "An isolated Azure fallback payload could not be created"
            ),
        )
    return path


def _mapped_usage(
    usage: ProviderUsage,
    *,
    kind: str,
    index: int,
) -> ProviderUsage:
    update: dict[str, object] = {
        "submitted_pages": (),
        "returned_pages": (),
        "submitted_frames": (),
        "returned_frames": (),
    }
    if kind == "page":
        update.update(submitted_pages=(index,), returned_pages=(index,))
    else:
        update.update(submitted_frames=(index,), returned_frames=(index,))
    return ProviderUsage.model_validate(usage.model_dump(mode="python") | update)


def _is_actual_provider_usage(value: object) -> bool:
    """Accept only the SDK model type without consulting a hostile __class__."""
    actual_type = type(value)
    try:
        return actual_type is ProviderUsage or (
            actual_type.__module__.startswith("document_sdk.")
            and issubclass(actual_type, ProviderUsage)
        )
    except (AttributeError, TypeError):
        return False


def _validate_isolated_payload_usage(
    value: object,
    *,
    identity: AzureFallbackProviderIdentity,
    policy: AzurePageFallbackPolicy,
) -> ProviderUsage:
    """Validate the real one-frame PNG Usage before source-index remapping."""
    if not _is_actual_provider_usage(value):
        raise ValueError("Azure fallback payload usage has an invalid type")
    usage_value = cast("ProviderUsage", value)
    raw = BaseModel.model_dump(
        usage_value,
        mode="python",
        round_trip=True,
        warnings="error",
    )
    usage = _revalidate_model_instance_json(
        usage_value,
        ProviderUsage,
        "Azure fallback payload usage is invalid",
    )
    features = policy.azure_options.features
    local_fields = (
        "local_operation_count",
        "local_page_count",
        "local_frame_count",
        "local_region_count",
        "local_attempted_region_count",
        "local_input_pixel_count",
        "local_output_character_count",
        "local_attempted_output_character_count",
    )
    if (
        raw.get("provider_name") != identity.provider_name
        or raw.get("profile_id") != identity.profile_id
        or raw.get("model_id") != identity.model_id
        or raw.get("api_version") != identity.api_version
        or raw.get("provider_resource_identity") != identity.provider_resource_identity
        or tuple(raw.get("submitted_pages", ()))
        or tuple(raw.get("returned_pages", ()))
        or tuple(raw.get("submitted_frames", ())) != (1,)
        or tuple(raw.get("returned_frames", ())) != (1,)
        or tuple(raw.get("requested_features", ())) != features
        or raw.get("query_field_count") != len(policy.azure_options.query_fields)
        or any(raw.get(name) != 0 for name in local_fields)
        or raw.get("azure_operation_count") != 1
        or raw.get("paid_operation_count") != 1
        or raw.get("cloud_logical_operation_count") != 1
        or raw.get("cloud_submitted_operation_count") != 1
        or raw.get("cloud_paid_or_possibly_paid_operation_count") != 1
        or raw.get("cloud_transport_retry_count") != 0
    ):
        raise ValueError("Azure fallback payload usage is inconsistent")
    return usage


def _attempt_evidence(
    *,
    summary: Any,
    kind: Literal["page", "frame"],
    prepared_indexes: tuple[int, ...],
    invoked_indexes: tuple[int, ...],
    prepared_payload_byte_counts: tuple[int, ...],
    payload_bytes: int,
    completed: tuple[ProviderUsage, ...],
    completed_cloud: tuple[CloudExecutionAttemptEvidence, ...] = (),
    policy: AzurePageFallbackPolicy,
    current: ProviderUsage | None = None,
    current_cloud: CloudExecutionAttemptEvidence | None = None,
) -> AzureFallbackAttemptEvidence:
    return AzureFallbackAttemptEvidence(
        source_kind=kind,
        provider_invocation_count=len(invoked_indexes),
        trigger_quality_summary=summary,
        provider_identity_summary=policy.expected_provider_identity,
        requested_features=policy.azure_options.features,
        query_field_count=len(policy.azure_options.query_fields),
        completed_azure_usages=completed,
        current_attempt_usage=current,
        completed_cloud_execution_attempts=completed_cloud,
        current_cloud_execution_attempt=current_cloud,
        prepared_pages=prepared_indexes if kind == "page" else (),
        prepared_frames=prepared_indexes if kind == "frame" else (),
        invoked_pages=invoked_indexes if kind == "page" else (),
        invoked_frames=invoked_indexes if kind == "frame" else (),
        prepared_payload_byte_counts=prepared_payload_byte_counts,
        payload_count=len(prepared_indexes),
        payload_byte_count=payload_bytes,
    )


def _completed_fallback_attempt_evidence(
    result: AzurePageFallbackResult,
) -> AzureFallbackAttemptEvidence:
    """Project a completed fallback result into safe retained attempt evidence."""
    report = result.report
    if bool(report.submitted_pages) == bool(report.submitted_frames):
        raise AzureFallbackInvalidResultError(
            "Completed Azure fallback source evidence is invalid"
        )
    kind: Literal["page", "frame"] = "page" if report.submitted_pages else "frame"
    indexes = report.submitted_pages or report.submitted_frames
    return _attempt_evidence(
        summary=report.trigger_quality_summary,
        kind=kind,
        prepared_indexes=indexes,
        invoked_indexes=indexes,
        prepared_payload_byte_counts=tuple(
            attempt.input_bytes for attempt in result.cloud_execution_attempts
        ),
        payload_bytes=report.payload_byte_count,
        completed=result.azure_provider_usage,
        completed_cloud=result.cloud_execution_attempts,
        policy=result.policy,
    )


@contextmanager
def _fallback_attempt_phase(
    evidence: AzureFallbackAttemptEvidence,
    error_type: type[AzureFallbackError],
    message: str,
) -> Iterator[None]:
    """Retain the latest safe attempt state across one downstream phase."""
    try:
        yield
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except AzureFallbackError as exc:
        if exc.attempt_evidence is None:
            exc.attempt_evidence = evidence
        raise
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            error_type(
                message,
                attempt_evidence=evidence,
            ),
        )


def _safe_attached_usage(
    exc: BaseException,
    *,
    kind: str,
    index: int,
    identity: AzureFallbackProviderIdentity,
    policy: AzurePageFallbackPolicy,
) -> ProviderUsage | None:
    sentinel = object()
    try:
        value = inspect.getattr_static(exc, "attempt_usage", sentinel)
    except Exception:
        return None
    if value is sentinel or not _is_actual_provider_usage(value):
        return None
    try:
        usage = _validate_isolated_payload_usage(
            value,
            identity=identity,
            policy=policy,
        )
        return _mapped_usage(usage, kind=kind, index=index)
    except Exception:
        return None


def _mapped_cloud_attempt(
    attempt: CloudExecutionAttemptEvidence,
    *,
    kind: str,
    index: int,
) -> CloudExecutionAttemptEvidence:
    """Map one isolated image-frame attempt to its original page or frame."""
    submitted = attempt.status in {
        CloudExecutionAttemptStatus.SUBMITTED,
        CloudExecutionAttemptStatus.COMPLETED,
        CloudExecutionAttemptStatus.POSSIBLY_PAID,
    }
    return CloudExecutionAttemptEvidence.model_validate(
        attempt.model_dump(mode="python")
        | {
            "requested_entire_input": False,
            "requested_pages": (index,) if kind == "page" else (),
            "requested_frames": (index,) if kind == "frame" else (),
            "submitted_pages": (index,) if submitted and kind == "page" else (),
            "submitted_frames": (index,) if submitted and kind == "frame" else (),
        }
    )


def _safe_attached_cloud_attempt(
    exc: BaseException,
    *,
    kind: str,
    index: int,
    input_bytes: int,
    identity: AzureFallbackProviderIdentity,
) -> CloudExecutionAttemptEvidence | None:
    """Recover SDK-owned cloud evidence without reading untrusted properties."""
    attempt = read_cloud_execution_attempt(exc)
    if attempt is None:
        return None
    try:
        mapped = _mapped_cloud_attempt(attempt, kind=kind, index=index)
        if (
            mapped.provider_name != identity.provider_name
            or mapped.profile_id != identity.profile_id
            or mapped.model_id != identity.model_id
            or mapped.api_version != identity.api_version
            or mapped.provider_resource_identity != identity.provider_resource_identity
            or (mapped.submitted_operation_count and mapped.input_bytes != input_bytes)
        ):
            return None
        return mapped  # noqa: TRY300 - the validated projection is the success path.
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception:
        return None


def _safe_result_cloud_projection(  # noqa: PLR0911
    value: object,
    *,
    kind: str,
    index: int,
    input_bytes: int,
    identity: AzureFallbackProviderIdentity,
    policy: AzurePageFallbackPolicy,
    cloud_policy: CloudExecutionPolicy | None,
) -> tuple[ProviderUsage | None, CloudExecutionAttemptEvidence | None]:
    """Recover a lossless matching Usage/attempt pair from an invalid result."""
    try:
        if cloud_policy is None:
            return None, None
        actual_type = type(value)
        if not issubclass(actual_type, ProcessingResult):
            return None, None
        payload = BaseModel.model_dump(
            cast("BaseModel", value),
            mode="python",
            round_trip=True,
            warnings="error",
        )
        metadata_payload = payload.get("metadata")
        if type(metadata_payload) is not dict:
            return None, None
        usage_payload = metadata_payload.get("provider_usage")
        attempt_payload = metadata_payload.get("cloud_execution_attempt")
        if type(usage_payload) is not dict or type(attempt_payload) is not dict:
            return None, None
        usage = ProviderUsage.model_validate(usage_payload)
        attempt = CloudExecutionAttemptEvidence.model_validate(attempt_payload)
        normalized_usage_payload = usage.model_dump(
            mode="python",
            round_trip=True,
            warnings="error",
        )
        normalized_attempt_payload = attempt.model_dump(
            mode="python",
            round_trip=True,
            warnings="error",
        )
        serialized_usage = json.dumps(
            usage_payload,
            allow_nan=False,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        )
        normalized_usage = json.dumps(
            normalized_usage_payload,
            allow_nan=False,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        )
        serialized_attempt = json.dumps(
            attempt_payload,
            allow_nan=False,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        )
        normalized_attempt = json.dumps(
            normalized_attempt_payload,
            allow_nan=False,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        )
        if (
            serialized_usage != normalized_usage
            or serialized_attempt != normalized_attempt
        ):
            return None, None
        validated = _validate_isolated_payload_usage(
            usage,
            identity=identity,
            policy=policy,
        )
        validated, attempt = _validated_completed_cloud_result(validated, attempt)
        if (
            attempt.provider_name != identity.provider_name
            or attempt.profile_id != identity.profile_id
            or attempt.model_id != identity.model_id
            or attempt.api_version != identity.api_version
            or attempt.provider_resource_identity != identity.provider_resource_identity
            or attempt.policy_fingerprint != cloud_policy.fingerprint()
            or attempt.status is not CloudExecutionAttemptStatus.COMPLETED
            or not attempt.requested_entire_input
            or attempt.requested_pages
            or attempt.requested_frames
            or attempt.submitted_pages
            or attempt.submitted_frames != (1,)
            or attempt.input_bytes != input_bytes
        ):
            return None, None
        return (
            _mapped_usage(validated, kind=kind, index=index),
            _mapped_cloud_attempt(attempt, kind=kind, index=index),
        )
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception:
        return None, None


_SOURCE_REFERENCE_TYPES = (
    PdfSourceReference,
    ImageSourceReference,
    ExcelSourceReference,
    DocxSourceReference,
)


def _is_actual_sdk_model(
    value: object,
    expected_type: type[SdkModel] = SdkModel,
) -> bool:
    """Accept only real SDK model classes, never duck-typed customer values."""
    actual_type = type(value)
    try:
        return actual_type.__module__.startswith("document_sdk.") and issubclass(
            actual_type,
            expected_type,
        )
    except (AttributeError, TypeError):
        return False


def _validate_azure_provider_result_metadata(
    value: object,
    *,
    evidence: AzureFallbackAttemptEvidence,
    identity: AzureFallbackProviderIdentity,
    policy: AzurePageFallbackPolicy,
) -> tuple[
    ProcessingMetadata,
    ProviderUsage | None,
    CloudExecutionAttemptEvidence | None,
]:
    """Project untrusted result metadata into SDK-owned validated models."""
    try:
        if not _is_actual_sdk_model(value, ProcessingResult):
            raise TypeError("Azure fallback result has an invalid type")
        result = cast("ProcessingResult[Any]", value)
        metadata_value = result.metadata
        if not _is_actual_sdk_model(metadata_value, ProcessingMetadata):
            raise TypeError("Azure fallback result metadata has an invalid type")
        metadata_model = metadata_value
        usage_value = metadata_model.provider_usage
        metadata = _revalidate_model_instance_json(
            metadata_model,
            ProcessingMetadata,
            "Azure fallback result metadata is invalid",
        )
        usage: ProviderUsage | None = None
        if usage_value is not None:
            if not _is_actual_provider_usage(usage_value):
                raise TypeError("Azure fallback usage has an invalid type")
            normalized_usage = _revalidate_model_instance_json(
                usage_value,
                ProviderUsage,
                "Azure fallback usage is invalid",
            )
            usage = _validate_isolated_payload_usage(
                usage_value,
                identity=identity,
                policy=policy,
            )
        else:
            normalized_usage = None
        if metadata.provider_usage != normalized_usage:
            raise ValueError("Azure fallback result usage is inconsistent")
        cloud_attempt = metadata.cloud_execution_attempt
        if cloud_attempt is not None:
            cloud_attempt = _revalidate_model_instance_json(
                cloud_attempt,
                CloudExecutionAttemptEvidence,
                "Azure fallback cloud attempt is invalid",
            )
        if (
            usage is not None
            and usage.cloud_logical_operation_count
            and (
                cloud_attempt is None
                or cloud_attempt.status is not CloudExecutionAttemptStatus.COMPLETED
            )
        ):
            raise ValueError("Azure fallback cloud attempt evidence is incomplete")
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            AzureFallbackInvalidResultError(
                "Azure fallback returned unreadable result metadata",
                attempt_evidence=evidence,
            ),
        )
    return metadata, usage, cloud_attempt


def _validate_azure_provider_result_data(
    value: object,
    *,
    evidence: AzureFallbackAttemptEvidence,
) -> Document | None:
    """Project untrusted result data without traversing it before validation."""
    try:
        if not _is_actual_sdk_model(value, ProcessingResult):
            raise TypeError("Azure fallback result has an invalid type")
        result = cast("ProcessingResult[Any]", value)
        data_value = result.data
        if data_value is None:
            return None
        if not _is_actual_sdk_model(data_value, Document):
            raise TypeError("Azure fallback result data has an invalid type")
        return _revalidate_model_instance_json(
            data_value,
            Document,
            "Azure fallback result data is invalid",
        )
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            AzureFallbackInvalidResultError(
                "Azure fallback returned unreadable document evidence",
                attempt_evidence=evidence,
            ),
        )


def _is_actual_source_reference(value: object) -> bool:
    return any(
        _is_actual_sdk_model(value, expected_type)
        for expected_type in _SOURCE_REFERENCE_TYPES
    )


def _walk_sdk_models(value: object) -> Iterator[SdkModel]:
    """Traverse only actual SDK models and recursively typed DocumentFields."""
    if _is_actual_sdk_model(value, DocumentField):
        field = cast("DocumentField", value)
        yield field
        yield from _walk_sdk_models(field.sources)
        yield from _walk_sdk_models(field.spans)
        if field.field_type == "array" and isinstance(field.value, tuple):
            for nested in field.value:
                if _is_actual_sdk_model(nested, DocumentField):
                    yield from _walk_sdk_models(nested)
        elif field.field_type == "object" and isinstance(field.value, Mapping):
            for nested in field.value.values():
                if _is_actual_sdk_model(nested, DocumentField):
                    yield from _walk_sdk_models(nested)
        return
    if _is_actual_sdk_model(value):
        model = cast("SdkModel", value)
        yield model
        for field_name in type(model).model_fields:
            yield from _walk_sdk_models(getattr(model, field_name))
        return
    if isinstance(value, tuple | list):
        for nested in value:
            yield from _walk_sdk_models(nested)
        return
    if isinstance(value, Mapping):
        for nested in value.values():
            if _is_actual_sdk_model(nested, DocumentField):
                yield from _walk_sdk_models(nested)


def _element_definition_id(value: SdkModel) -> str | None:
    """Read a structural definition ID without treating references as definitions."""
    if _is_actual_sdk_model(value, DocumentElementReference):
        return None
    if "element_id" not in type(value).model_fields:
        return None
    element_id = cast("Any", value).element_id
    return element_id if isinstance(element_id, str) else None


def _structural_definition_maps(
    document: Document,
    *,
    namespace: str,
) -> tuple[dict[str, str], dict[str, str]]:
    """Collect definitions first so reference remapping can require closure."""
    scope_ids: list[str] = []
    element_ids: list[str] = []
    for model in _walk_sdk_models(document):
        if _is_actual_sdk_model(model, DocumentContentScope):
            scope_ids.append(cast("DocumentContentScope", model).scope_id)
        element_id = _element_definition_id(model)
        if element_id is not None:
            element_ids.append(element_id)
    if len(scope_ids) != len(set(scope_ids)) or len(element_ids) != len(
        set(element_ids)
    ):
        raise AzureFallbackMappingError(
            "Azure fallback structural identities are not unique"
        )
    scope_map = {value: namespace + value for value in scope_ids}
    element_map = {value: namespace + value for value in element_ids}
    if len(set(scope_map.values())) != len(scope_map) or len(
        set(element_map.values())
    ) != len(element_map):
        raise AzureFallbackMappingError(
            "Azure fallback structural identities are not unique"
        )
    return scope_map, element_map


def _transform_sdk_payload(
    value: object,
    payload: object,
    *,
    target: DocumentPage,
    scope_map: dict[str, str],
    element_map: dict[str, str],
) -> None:
    """Remap typed sources, definitions, and references without inspecting content."""
    if _is_actual_source_reference(value):
        if not isinstance(payload, dict):
            raise AzureFallbackMappingError("Azure fallback source payload is invalid")
        replacement = target.source.model_dump(mode="python")
        bounding_box = payload.get("bounding_box")
        payload.clear()
        payload.update(replacement)
        if bounding_box is not None:
            payload["bounding_box"] = bounding_box
        return
    if _is_actual_sdk_model(value, DocumentField):
        if not isinstance(payload, dict):
            raise AzureFallbackMappingError(
                "Azure fallback document-field payload is invalid"
            )
        field = cast("DocumentField", value)
        for field_name, nested in (
            ("sources", field.sources),
            ("spans", field.spans),
        ):
            if field_name not in payload:
                raise AzureFallbackMappingError(
                    "Azure fallback document-field payload is incomplete"
                )
            _transform_sdk_payload(
                nested,
                payload[field_name],
                target=target,
                scope_map=scope_map,
                element_map=element_map,
            )
        nested_value = field.value
        serialized_value = payload.get("value")
        is_nested_field = (
            field.field_type == "array" and isinstance(nested_value, tuple)
        ) or (field.field_type == "object" and isinstance(nested_value, Mapping))
        if is_nested_field:
            _transform_sdk_payload(
                nested_value,
                serialized_value,
                target=target,
                scope_map=scope_map,
                element_map=element_map,
            )
        return
    if _is_actual_sdk_model(value):
        if not isinstance(payload, dict):
            raise AzureFallbackMappingError("Azure fallback model payload is invalid")
        model = cast("SdkModel", value)
        handled_fields: set[str] = set()
        if _is_actual_sdk_model(model, DocumentContentScope):
            scope = cast("DocumentContentScope", model)
            if scope.scope_id not in scope_map:
                raise AzureFallbackMappingError(
                    "Azure fallback content-scope definition is not closed"
                )
            payload["scope_id"] = scope_map[scope.scope_id]
            if _is_actual_sdk_model(target.source, PdfSourceReference):
                payload["page_numbers"] = (target.page_number,)
                payload["frame_numbers"] = ()
            else:
                payload["page_numbers"] = ()
                payload["frame_numbers"] = (target.page_number,)
            handled_fields.update(("scope_id", "page_numbers", "frame_numbers"))
        elif _is_actual_sdk_model(model, DocumentSpan):
            span = cast("DocumentSpan", model)
            if span.scope_id not in scope_map:
                raise AzureFallbackMappingError(
                    "Azure fallback content-scope reference is not closed"
                )
            payload["scope_id"] = scope_map[span.scope_id]
            handled_fields.add("scope_id")
        elif _is_actual_sdk_model(model, DocumentElementReference):
            reference = cast("DocumentElementReference", model)
            if reference.element_id not in element_map:
                raise AzureFallbackMappingError(
                    "Azure fallback element reference is not closed"
                )
            payload["element_id"] = element_map[reference.element_id]
            handled_fields.add("element_id")
        else:
            element_id = _element_definition_id(model)
            if element_id is not None:
                if element_id not in element_map:
                    raise AzureFallbackMappingError(
                        "Azure fallback element definition is not closed"
                    )
                payload["element_id"] = element_map[element_id]
                handled_fields.add("element_id")
        for field_name in type(model).model_fields:
            if field_name in handled_fields:
                continue
            if field_name not in payload:
                raise AzureFallbackMappingError(
                    "Azure fallback model payload is incomplete"
                )
            _transform_sdk_payload(
                getattr(model, field_name),
                payload[field_name],
                target=target,
                scope_map=scope_map,
                element_map=element_map,
            )
        return
    if isinstance(value, tuple | list):
        if not isinstance(payload, tuple | list) or len(value) != len(payload):
            raise AzureFallbackMappingError(
                "Azure fallback sequence payload is invalid"
            )
        for nested, nested_payload in zip(value, payload, strict=True):
            _transform_sdk_payload(
                nested,
                nested_payload,
                target=target,
                scope_map=scope_map,
                element_map=element_map,
            )
        return
    if isinstance(value, Mapping):
        if not isinstance(payload, Mapping):
            raise AzureFallbackMappingError("Azure fallback field payload is invalid")
        for name, nested in value.items():
            if not _is_actual_sdk_model(nested, DocumentField):
                continue
            if name not in payload:
                raise AzureFallbackMappingError(
                    "Azure fallback field payload is incomplete"
                )
            _transform_sdk_payload(
                nested,
                payload[name],
                target=target,
                scope_map=scope_map,
                element_map=element_map,
            )


def _namespace_and_remap_document(
    document: Document,
    *,
    target: DocumentPage,
    file: FileDescriptor,
    namespace: str,
) -> Document:
    payload = document.model_dump(mode="python")
    scope_map, element_map = _structural_definition_maps(
        document,
        namespace=namespace,
    )
    _transform_sdk_payload(
        document,
        payload,
        target=target,
        scope_map=scope_map,
        element_map=element_map,
    )
    payload["file"] = file
    payload["pages"][0]["page_number"] = target.page_number
    payload["pages"][0]["dimensions"] = target.dimensions
    try:
        return Document.model_validate(payload)
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            AzureFallbackMappingError(
                "Azure fallback result could not be mapped safely"
            ),
        )


def _isolated_document(
    result_document: Document,
    *,
    payload_descriptor: FileDescriptor,
) -> Document:
    """Reject every non-local source before remapping can hide it."""
    try:
        if not _is_actual_sdk_model(result_document, Document):
            raise TypeError("Azure fallback isolated result is not a Document")
        normalized_document = _revalidate_model_instance_json(
            result_document,
            Document,
            "Azure fallback isolated document is invalid",
        )
        if (
            normalized_document.file != payload_descriptor
            or len(normalized_document.pages) != 1
        ):
            raise AzureFallbackInvalidResultError(
                "Azure fallback returned invalid isolated source evidence"
            )
        page = normalized_document.pages[0]
        page_source = page.source
        if (
            page.page_number != 1
            or not _is_actual_sdk_model(page_source, ImageSourceReference)
            or cast("ImageSourceReference", page_source).frame_number != 1
        ):
            raise AzureFallbackInvalidResultError(
                "Azure fallback returned invalid isolated source evidence"
            )
        for model in _walk_sdk_models(normalized_document):
            if _is_actual_source_reference(model):
                if (
                    not _is_actual_sdk_model(model, ImageSourceReference)
                    or cast("ImageSourceReference", model).file_id
                    != payload_descriptor.file_id
                    or cast("ImageSourceReference", model).frame_number != 1
                ):
                    raise AzureFallbackInvalidResultError(
                        "Azure fallback returned invalid nested source evidence"
                    )
            elif _is_actual_sdk_model(model, DocumentContentScope):
                scope = cast("DocumentContentScope", model)
                if scope.page_numbers or scope.frame_numbers != (1,):
                    raise AzureFallbackInvalidResultError(
                        "Azure fallback returned invalid content-scope evidence"
                    )
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except AzureFallbackInvalidResultError:
        raise
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            AzureFallbackInvalidResultError(
                "Azure fallback returned invalid isolated document evidence"
            ),
        )
    return normalized_document


def _intersects_source(
    value: object,
    *,
    kind: str,
    indexes: set[int],
    scope_ids: set[str] | None = None,
    element_ids: set[str] | None = None,
) -> bool:
    for model in _walk_sdk_models(value):
        if scope_ids is not None:
            if _is_actual_sdk_model(model, DocumentContentScope) and (
                cast("DocumentContentScope", model).scope_id in scope_ids
            ):
                return True
            if _is_actual_sdk_model(model, DocumentSpan) and (
                cast("DocumentSpan", model).scope_id in scope_ids
            ):
                return True
        if element_ids is not None:
            element_id: str | None
            if _is_actual_sdk_model(model, DocumentElementReference):
                element_id = cast("DocumentElementReference", model).element_id
            else:
                element_id = _element_definition_id(model)
            if element_id in element_ids:
                return True
        matches_pdf_page = (
            kind == "page"
            and _is_actual_sdk_model(model, PdfSourceReference)
            and cast("PdfSourceReference", model).page_number in indexes
        )
        matches_image_frame = (
            kind == "frame"
            and _is_actual_sdk_model(model, ImageSourceReference)
            and cast("ImageSourceReference", model).frame_number in indexes
        )
        if matches_pdf_page or matches_image_frame:
            return True
        if _is_actual_sdk_model(model, DocumentContentScope):
            scope = cast("DocumentContentScope", model)
            numbers = scope.page_numbers if kind == "page" else scope.frame_numbers
            if indexes.intersection(numbers):
                return True
    return False


def _structural_ids(value: object) -> set[str]:
    return {
        element_id
        for model in _walk_sdk_models(value)
        if (element_id := _element_definition_id(model)) is not None
    }


def _merge_documents(
    local: Document,
    *,
    mapped: tuple[Document, ...],
    kind: str,
    candidates: tuple[int, ...],
) -> Document:
    replacements = {item.pages[0].page_number: item.pages[0] for item in mapped}
    indexes = set(candidates)
    aggregate_fields = (
        "tables",
        "content_scopes",
        "paragraphs",
        "key_value_pairs",
        "figures",
        "sections",
        "languages",
        "styles",
        "analyzed_documents",
    )
    update: dict[str, object] = {
        "pages": tuple(replacements.get(page.page_number, page) for page in local.pages)
    }
    candidate_scopes = {
        scope.scope_id
        for scope in local.content_scopes
        if indexes.intersection(
            scope.page_numbers if kind == "page" else scope.frame_numbers
        )
    }
    deleted_ids: set[str] = set()
    for page in local.pages:
        if page.page_number in indexes:
            deleted_ids.update(_structural_ids(page))
    retained_by_field: dict[str, list[object]] = {}
    for field_name in aggregate_fields:
        retained_by_field[field_name] = []
        for item in getattr(local, field_name):
            if _intersects_source(
                item,
                kind=kind,
                indexes=indexes,
                scope_ids=candidate_scopes,
            ):
                deleted_ids.update(_structural_ids(item))
            else:
                retained_by_field[field_name].append(item)
    changed = True
    while changed:
        changed = False
        for field_name in aggregate_fields:
            if field_name == "content_scopes":
                continue
            next_retained: list[object] = []
            for item in retained_by_field[field_name]:
                if _intersects_source(
                    item,
                    kind=kind,
                    indexes=set(),
                    element_ids=deleted_ids,
                ):
                    deleted_ids.update(_structural_ids(item))
                    changed = True
                else:
                    next_retained.append(item)
            retained_by_field[field_name] = next_retained
    for field_name in aggregate_fields:
        retained = tuple(retained_by_field[field_name])
        appended = tuple(
            item for document in mapped for item in getattr(document, field_name)
        )
        update[field_name] = retained + appended
    try:
        return Document.model_validate(local.model_dump(mode="python") | update)
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            AzureFallbackMappingError(
                "Azure fallback documents could not be merged safely"
            ),
        )


def _verify_phase(
    source: Path,
    *,
    descriptor: FileDescriptor,
    token: tuple[int, ...],
    source_verifier: Callable[[], None] | None,
    evidence: AzureFallbackAttemptEvidence | None = None,
) -> None:
    # Snapshot verification is SDK-owned and may retain its precise classification.
    try:
        if _snapshot_token(source, descriptor) != token:
            raise AzureFallbackPayloadError("Fallback source snapshot changed")
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except AzureFallbackError as exc:
        if exc.attempt_evidence is None:
            exc.attempt_evidence = evidence
        raise
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            AzureFallbackPayloadError(
                "Fallback source snapshot could not be verified",
                attempt_evidence=evidence,
            ),
        )
    if source_verifier is None:
        return

    # The caller callback is untrusted and cannot select an SDK error classification.
    try:
        source_verifier()
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except DocumentSourceChangedError as exc:
        _raise_redacted_translation(
            exc,
            AzureFallbackSourceChangedError(
                "Fallback source changed during processing",
                attempt_evidence=evidence,
            ),
        )
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            AzureFallbackPayloadError(
                "Fallback source verification failed",
                attempt_evidence=evidence,
            ),
        )


def _apply_prepared_azure_page_fallback(
    source: Path,
    *,
    local_document: Document,
    quality_report: LocalOcrQualityReport,
    policy: AzurePageFallbackPolicy,
    azure_provider: object,
    pdf_limits: PdfProcessingLimits | None = None,
    image_limits: ImageProcessingLimits | None = None,
    source_verifier: Callable[[], None] | None = None,
) -> AzurePageFallbackResult:
    """Execute fallback against an already verified private source Snapshot."""
    kind, candidates = _fallback_candidates(quality_report, local_document)
    fingerprint = policy.fingerprint()
    features = policy.azure_options.features
    input_indexes = tuple(page.page_number for page in local_document.pages)
    input_pages = input_indexes if kind == "page" else ()
    input_frames = input_indexes if kind == "frame" else ()
    if not _is_actual_azure_provider(azure_provider):
        raise AzureFallbackProviderTypeError(
            "Azure fallback requires the built-in Azure Provider type"
        )
    provider = cast("AzureDocumentIntelligenceProvider", azure_provider)
    if not candidates:
        return _validate_azure_fallback_result(
            AzurePageFallbackResult(
                document=local_document,
                policy=policy,
                report=AzurePageFallbackReport(
                    status=AzurePageFallbackStatus.NOT_APPLICABLE,
                    trigger_quality_summary=quality_report.summary,
                    policy_fingerprint=fingerprint,
                    payload_policy_version=policy.payload_policy_version,
                    requested_features=features,
                    query_field_count=len(policy.azure_options.query_fields),
                    input_pages=input_pages,
                    input_frames=input_frames,
                ),
                azure_provider_usage=(),
            )
        )
    try:
        _enforce_candidate_limits(kind=kind, count=len(candidates), policy=policy)
    except AzureFallbackError as exc:
        if exc.attempt_evidence is None:
            exc.attempt_evidence = _attempt_evidence(
                summary=quality_report.summary,
                kind=kind,
                prepared_indexes=(),
                invoked_indexes=(),
                prepared_payload_byte_counts=(),
                payload_bytes=0,
                completed=(),
                policy=policy,
            )
        raise
    descriptor = local_document.file
    latest_attempt_evidence = _attempt_evidence(
        summary=quality_report.summary,
        kind=kind,
        prepared_indexes=(),
        invoked_indexes=(),
        prepared_payload_byte_counts=(),
        payload_bytes=0,
        completed=(),
        policy=policy,
    )
    cloud_policy = _provider_cloud_execution_policy(provider)
    if cloud_policy is not None:
        if (
            not cloud_policy.allow_cloud_execution
            or not cloud_policy.allow_cloud_fallback
        ):
            raise AzureFallbackConfigurationError(
                "Cloud fallback execution is not authorized",
                attempt_evidence=latest_attempt_evidence,
            )
        if (
            len(candidates) > cloud_policy.max_logical_cloud_operations
            or len(candidates) > cloud_policy.max_submitted_operations
            or len(candidates) > cloud_policy.max_paid_or_possibly_paid_operations
            or len(candidates) > cloud_policy.max_pages_or_frames
        ):
            raise AzureFallbackLimitError(
                "Cloud fallback operation budget is exceeded",
                attempt_evidence=latest_attempt_evidence,
            )
    with _fallback_attempt_phase(
        latest_attempt_evidence,
        AzureFallbackPayloadError,
        "Fallback source snapshot could not be verified",
    ):
        snapshot_token = _snapshot_token(source, descriptor)
    _verify_phase(
        source,
        descriptor=descriptor,
        token=snapshot_token,
        source_verifier=source_verifier,
        evidence=latest_attempt_evidence,
    )
    page_by_index = {page.page_number: page for page in local_document.pages}
    usages: list[ProviderUsage] = []
    cloud_attempts: list[CloudExecutionAttemptEvidence] = []
    mapped_documents: list[Document] = []
    payload_bytes = 0
    prepared_indexes: list[int] = []
    prepared_payload_byte_counts: list[int] = []
    invoked_indexes: list[int] = []
    identity: AzureFallbackProviderIdentity | None = None
    stream_context = (
        _open_image_frame_pixel_stream(
            source,
            descriptor=descriptor,
            selected_frame_numbers=candidates,
            normalize_orientation=True,
            limits=image_limits,
            _verified_snapshot=True,
        )
        if kind == "frame"
        else nullcontext(None)
    )
    try:
        with (
            tempfile.TemporaryDirectory(prefix="document-sdk-fallback-") as temporary,
            stream_context as pixel_stream,
        ):
            for ordinal, index in enumerate(candidates, start=1):
                latest_attempt_evidence = _attempt_evidence(
                    summary=quality_report.summary,
                    kind=kind,
                    prepared_indexes=tuple(prepared_indexes),
                    invoked_indexes=tuple(invoked_indexes),
                    prepared_payload_byte_counts=tuple(prepared_payload_byte_counts),
                    payload_bytes=payload_bytes,
                    completed=tuple(usages),
                    completed_cloud=tuple(cloud_attempts),
                    policy=policy,
                )
                _verify_phase(
                    source,
                    descriptor=descriptor,
                    token=snapshot_token,
                    source_verifier=source_verifier,
                    evidence=latest_attempt_evidence,
                )
                if kind == "page":
                    payload = render_page(
                        source,
                        index,
                        dpi=policy.pdf_render_dpi,
                        limits=pdf_limits,
                    ).image_bytes
                else:
                    payload = _encode_frame_payload(pixel_stream, index)
                payload_size = len(payload)
                latest_attempt_evidence = _attempt_evidence(
                    summary=quality_report.summary,
                    kind=kind,
                    prepared_indexes=(*prepared_indexes, index),
                    invoked_indexes=tuple(invoked_indexes),
                    prepared_payload_byte_counts=(
                        *prepared_payload_byte_counts,
                        payload_size,
                    ),
                    payload_bytes=payload_bytes + payload_size,
                    completed=tuple(usages),
                    completed_cloud=tuple(cloud_attempts),
                    policy=policy,
                )
                if payload_size > policy.max_payload_bytes_per_input:
                    raise AzureFallbackLimitError(
                        "Fallback payload exceeds the per-input byte limit",
                        attempt_evidence=latest_attempt_evidence,
                    )
                if payload_bytes + payload_size > policy.max_payload_bytes_per_document:
                    raise AzureFallbackLimitError(
                        "Fallback payload exceeds the document byte limit",
                        attempt_evidence=latest_attempt_evidence,
                    )
                if (
                    cloud_policy is not None
                    and payload_bytes + payload_size > cloud_policy.max_input_bytes
                ):
                    raise AzureFallbackLimitError(
                        "Cloud fallback input byte budget is exceeded",
                        attempt_evidence=latest_attempt_evidence,
                    )
                payload_path = _write_payload(Path(temporary), ordinal, payload)
                prepared_indexes.append(index)
                prepared_payload_byte_counts.append(payload_size)
                payload_bytes += payload_size
                latest_attempt_evidence = _attempt_evidence(
                    summary=quality_report.summary,
                    kind=kind,
                    prepared_indexes=tuple(prepared_indexes),
                    invoked_indexes=tuple(invoked_indexes),
                    prepared_payload_byte_counts=tuple(prepared_payload_byte_counts),
                    payload_bytes=payload_bytes,
                    completed=tuple(usages),
                    completed_cloud=tuple(cloud_attempts),
                    policy=policy,
                )
                try:
                    _verify_phase(
                        source,
                        descriptor=descriptor,
                        token=snapshot_token,
                        source_verifier=source_verifier,
                        evidence=latest_attempt_evidence,
                    )
                    if identity is None:
                        identity = _provider_identity(provider)
                        if identity != policy.expected_provider_identity:
                            raise AzureFallbackProviderTypeError(
                                "Azure fallback Provider identity does not match "
                                "policy",
                                attempt_evidence=latest_attempt_evidence,
                            )
                    invoked_indexes.append(index)
                    latest_attempt_evidence = _attempt_evidence(
                        summary=quality_report.summary,
                        kind=kind,
                        prepared_indexes=tuple(prepared_indexes),
                        invoked_indexes=tuple(invoked_indexes),
                        prepared_payload_byte_counts=tuple(
                            prepared_payload_byte_counts
                        ),
                        payload_bytes=payload_bytes,
                        completed=tuple(usages),
                        completed_cloud=tuple(cloud_attempts),
                        policy=policy,
                    )
                    try:
                        result = provider._analyze_fallback(  # noqa: SLF001 - bounded internal Provider entry point.
                            payload_path,
                            options=policy.azure_options,
                        )
                    except (KeyboardInterrupt, SystemExit, GeneratorExit):
                        raise
                    except Exception as exc:
                        current = _safe_attached_usage(
                            exc,
                            kind=kind,
                            index=index,
                            identity=identity,
                            policy=policy,
                        )
                        current_cloud = _safe_attached_cloud_attempt(
                            exc,
                            kind=kind,
                            index=index,
                            input_bytes=payload_size,
                            identity=identity,
                        )
                        if (
                            current is not None
                            and current.cloud_logical_operation_count
                            and current_cloud is None
                        ):
                            current = None
                        latest_attempt_evidence = _attempt_evidence(
                            summary=quality_report.summary,
                            kind=kind,
                            prepared_indexes=tuple(prepared_indexes),
                            invoked_indexes=tuple(invoked_indexes),
                            prepared_payload_byte_counts=tuple(
                                prepared_payload_byte_counts
                            ),
                            payload_bytes=payload_bytes,
                            completed=tuple(usages),
                            completed_cloud=tuple(cloud_attempts),
                            policy=policy,
                            current=current,
                            current_cloud=current_cloud,
                        )
                        _raise_redacted_translation(
                            exc,
                            AzureFallbackExecutionError(
                                "Azure fallback execution failed",
                                attempt_evidence=latest_attempt_evidence,
                            ),
                        )
                    from document_sdk.ocr._provider_boundary import (
                        _revalidate_document_processing_result,
                    )

                    try:
                        result = _revalidate_document_processing_result(result)
                    except (KeyboardInterrupt, SystemExit, GeneratorExit):
                        raise
                    except Exception as exc:
                        current, current_cloud = _safe_result_cloud_projection(
                            result,
                            kind=kind,
                            index=index,
                            input_bytes=payload_size,
                            identity=identity,
                            policy=policy,
                            cloud_policy=cloud_policy,
                        )
                        latest_attempt_evidence = _attempt_evidence(
                            summary=quality_report.summary,
                            kind=kind,
                            prepared_indexes=tuple(prepared_indexes),
                            invoked_indexes=tuple(invoked_indexes),
                            prepared_payload_byte_counts=tuple(
                                prepared_payload_byte_counts
                            ),
                            payload_bytes=payload_bytes,
                            completed=tuple(usages),
                            completed_cloud=tuple(cloud_attempts),
                            policy=policy,
                            current=current,
                            current_cloud=current_cloud,
                        )
                        _raise_redacted_translation(
                            exc,
                            AzureFallbackInvalidResultError(
                                "Azure fallback returned an invalid Provider result",
                                attempt_evidence=latest_attempt_evidence,
                            ),
                        )
                    _, usage, cloud_attempt = _validate_azure_provider_result_metadata(
                        result,
                        evidence=latest_attempt_evidence,
                        identity=identity,
                        policy=policy,
                    )
                    current_usage: ProviderUsage | None = None
                    if usage is not None:
                        try:
                            current_usage = _mapped_usage(
                                usage,
                                kind=kind,
                                index=index,
                            )
                        except (KeyboardInterrupt, SystemExit, GeneratorExit):
                            raise
                        except Exception as exc:
                            _raise_redacted_translation(
                                exc,
                                AzureFallbackInvalidResultError(
                                    "Azure fallback returned invalid usage evidence",
                                    attempt_evidence=latest_attempt_evidence,
                                ),
                            )
                    mapped_cloud_attempt: CloudExecutionAttemptEvidence | None = None
                    if cloud_attempt is not None:
                        try:
                            mapped_cloud_attempt = _mapped_cloud_attempt(
                                cloud_attempt,
                                kind=kind,
                                index=index,
                            )
                        except (KeyboardInterrupt, SystemExit, GeneratorExit):
                            raise
                        except Exception as exc:
                            _raise_redacted_translation(
                                exc,
                                AzureFallbackInvalidResultError(
                                    "Azure fallback returned invalid cloud evidence",
                                    attempt_evidence=latest_attempt_evidence,
                                ),
                            )
                    latest_attempt_evidence = _attempt_evidence(
                        summary=quality_report.summary,
                        kind=kind,
                        prepared_indexes=tuple(prepared_indexes),
                        invoked_indexes=tuple(invoked_indexes),
                        prepared_payload_byte_counts=tuple(
                            prepared_payload_byte_counts
                        ),
                        payload_bytes=payload_bytes,
                        completed=tuple(usages),
                        completed_cloud=tuple(cloud_attempts),
                        policy=policy,
                        current=current_usage,
                        current_cloud=mapped_cloud_attempt,
                    )
                    _verify_phase(
                        source,
                        descriptor=descriptor,
                        token=snapshot_token,
                        source_verifier=source_verifier,
                        evidence=latest_attempt_evidence,
                    )
                    if current_usage is None or identity is None:
                        raise AzureFallbackInvalidResultError(
                            "Azure fallback returned invalid usage evidence",
                            attempt_evidence=latest_attempt_evidence,
                        )
                    result_document = _validate_azure_provider_result_data(
                        result,
                        evidence=latest_attempt_evidence,
                    )
                    if result_document is None:
                        raise AzureFallbackInvalidResultError(
                            "Azure fallback returned no document",
                            attempt_evidence=latest_attempt_evidence,
                        )
                    with _fallback_attempt_phase(
                        latest_attempt_evidence,
                        AzureFallbackPayloadError,
                        "Azure fallback payload descriptor could not be verified",
                    ):
                        payload_descriptor = inspect_file(payload_path)
                    with _fallback_attempt_phase(
                        latest_attempt_evidence,
                        AzureFallbackInvalidResultError,
                        "Azure fallback isolated document is invalid",
                    ):
                        isolated = _isolated_document(
                            result_document,
                            payload_descriptor=payload_descriptor,
                        )
                    with _fallback_attempt_phase(
                        latest_attempt_evidence,
                        AzureFallbackMappingError,
                        "Azure fallback candidate could not be mapped safely",
                    ):
                        mapped = _namespace_and_remap_document(
                            isolated,
                            target=page_by_index[index],
                            file=local_document.file,
                            namespace=f"azure-fallback-{kind}-{index}-",
                        )
                        mapped_documents.append(mapped)
                        usages.append(current_usage)
                        if mapped_cloud_attempt is not None:
                            cloud_attempts.append(mapped_cloud_attempt)
                    latest_attempt_evidence = _attempt_evidence(
                        summary=quality_report.summary,
                        kind=kind,
                        prepared_indexes=tuple(prepared_indexes),
                        invoked_indexes=tuple(invoked_indexes),
                        prepared_payload_byte_counts=tuple(
                            prepared_payload_byte_counts
                        ),
                        payload_bytes=payload_bytes,
                        completed=tuple(usages),
                        completed_cloud=tuple(cloud_attempts),
                        policy=policy,
                    )
                finally:
                    payload_path.unlink(missing_ok=True)
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except AzureFallbackError as exc:
        if exc.attempt_evidence is None:
            exc.attempt_evidence = latest_attempt_evidence
        raise
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            AzureFallbackPayloadError(
                "Azure fallback input processing failed",
                attempt_evidence=latest_attempt_evidence,
            ),
        )
    evidence = latest_attempt_evidence
    _verify_phase(
        source,
        descriptor=descriptor,
        token=snapshot_token,
        source_verifier=source_verifier,
        evidence=evidence,
    )
    with _fallback_attempt_phase(
        evidence,
        AzureFallbackMappingError,
        "Azure fallback documents could not be merged safely",
    ):
        merged = _merge_documents(
            local_document,
            mapped=tuple(mapped_documents),
            kind=kind,
            candidates=candidates,
        )
    _verify_phase(
        source,
        descriptor=descriptor,
        token=snapshot_token,
        source_verifier=source_verifier,
        evidence=evidence,
    )
    if identity is None:
        raise AzureFallbackInvalidResultError(
            "Azure fallback Provider identity is unavailable",
            attempt_evidence=evidence,
        )
    submitted_pages = candidates if kind == "page" else ()
    submitted_frames = candidates if kind == "frame" else ()
    with _fallback_attempt_phase(
        evidence,
        AzureFallbackInvalidResultError,
        "Azure fallback final result evidence is invalid",
    ):
        report = AzurePageFallbackReport(
            status=AzurePageFallbackStatus.COMPLETED,
            trigger_quality_summary=quality_report.summary,
            policy_fingerprint=fingerprint,
            payload_policy_version=policy.payload_policy_version,
            requested_features=features,
            query_field_count=len(policy.azure_options.query_fields),
            input_pages=input_pages,
            input_frames=input_frames,
            submitted_pages=submitted_pages,
            submitted_frames=submitted_frames,
            replaced_pages=submitted_pages,
            replaced_frames=submitted_frames,
            reason_codes=quality_report.summary.reason_codes,
            provider_invocation_count=len(invoked_indexes),
            azure_operation_count=len(usages),
            paid_page_count=len(submitted_pages),
            paid_frame_count=len(submitted_frames),
            payload_count=len(prepared_indexes),
            payload_byte_count=payload_bytes,
            structured_recheck_performed=False,
            provider_identity_summary=identity,
        )
        final_result = _validate_azure_fallback_result(
            AzurePageFallbackResult(
                document=merged,
                policy=policy,
                report=report,
                azure_provider_usage=tuple(usages),
                cloud_execution_attempts=tuple(cloud_attempts),
            )
        )
    return final_result  # noqa: RET504 - return only after the phase exits safely.


def apply_azure_page_fallback(
    source: Path,
    *,
    local_document: Document,
    quality_report: LocalOcrQualityReport,
    preprocessing_report: LocalOcrPreprocessingReport | None = None,
    policy: AzurePageFallbackPolicy,
    azure_provider: object,
    pdf_limits: PdfProcessingLimits | None = None,
    image_limits: ImageProcessingLimits | None = None,
    source_verifier: Callable[[], None] | None = None,
) -> AzurePageFallbackResult:
    """Replace only quality-recommended inputs using a verified source Snapshot."""
    try:
        validated_policy = _validate_azure_fallback_policy(policy)
        validated_quality = _revalidate_model_instance_json(
            quality_report,
            LocalOcrQualityReport,
            "Azure fallback quality report is invalid",
        )
        if preprocessing_report is not None:
            _, validated_quality = _validate_preprocessing_quality_lineage(
                preprocessing_report,
                validated_quality,
            )
        validated_document = _revalidate_model_instance_json(
            local_document,
            Document,
            "Azure fallback Local document is invalid",
        )
        validated_pdf_limits = (
            None
            if pdf_limits is None
            else _revalidate_model_instance_json(
                pdf_limits,
                PdfProcessingLimits,
                "Azure fallback PDF limits are invalid",
            )
        )
        validated_image_limits = (
            None
            if image_limits is None
            else _revalidate_model_instance_json(
                image_limits,
                ImageProcessingLimits,
                "Azure fallback image limits are invalid",
            )
        )
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            AzureFallbackInvalidResultError(
                "Azure fallback request evidence is invalid"
            ),
        )
    if not _is_actual_azure_provider(azure_provider):
        raise AzureFallbackProviderTypeError(
            "Azure fallback requires the built-in Azure Provider type"
        )
    provider = cast("AzureDocumentIntelligenceProvider", azure_provider)
    kind, candidates = _fallback_candidates(validated_quality, validated_document)
    if candidates:
        try:
            _enforce_candidate_limits(
                kind=kind,
                count=len(candidates),
                policy=validated_policy,
            )
        except AzureFallbackError as exc:
            if exc.attempt_evidence is None:
                exc.attempt_evidence = _attempt_evidence(
                    summary=validated_quality.summary,
                    kind=kind,
                    prepared_indexes=(),
                    invoked_indexes=(),
                    prepared_payload_byte_counts=(),
                    payload_bytes=0,
                    completed=(),
                    policy=validated_policy,
                )
            raise
    if not candidates:
        _verify_source_identity_without_copy(
            source,
            descriptor=validated_document.file,
            expected_kind=kind,
        )
        return _apply_prepared_azure_page_fallback(
            source,
            local_document=validated_document,
            quality_report=validated_quality,
            policy=validated_policy,
            azure_provider=provider,
            pdf_limits=validated_pdf_limits,
            image_limits=validated_image_limits,
            source_verifier=source_verifier,
        )
    with _verified_source_snapshot(
        source,
        descriptor=validated_document.file,
        expected_kind=kind,
    ) as snapshot:
        return _apply_prepared_azure_page_fallback(
            snapshot,
            local_document=validated_document,
            quality_report=validated_quality,
            policy=validated_policy,
            azure_provider=azure_provider,
            pdf_limits=validated_pdf_limits,
            image_limits=validated_image_limits,
            source_verifier=source_verifier,
        )

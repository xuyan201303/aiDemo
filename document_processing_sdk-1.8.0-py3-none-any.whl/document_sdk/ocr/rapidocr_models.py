"""Strict public configuration for the RapidOCR CPU Engine adapter."""

from __future__ import annotations

from pathlib import Path  # noqa: TC003 - Pydantic resolves this runtime type.
from typing import Annotated, Literal, Self, cast

from pydantic import Field, StringConstraints, model_validator

from document_sdk.core.models import SdkModel
from document_sdk.ocr._model_registry import RAPIDOCR_ZH_EN_MODEL

type Sha256 = Annotated[str, StringConstraints(pattern=r"^[0-9a-f]{64}$")]
type ModelId = Annotated[
    str,
    StringConstraints(
        min_length=1,
        max_length=64,
        pattern=r"^[A-Za-z0-9][A-Za-z0-9._-]*$",
    ),
]

_APPROVED_MODEL_ID = RAPIDOCR_ZH_EN_MODEL.model_id
_APPROVED_MODEL_HASHES = RAPIDOCR_ZH_EN_MODEL.model_hashes


class RapidOcrEngineConfig(SdkModel):
    """JSON-safe deterministic CPU inference policy."""

    intra_op_num_threads: int = Field(default=1, ge=1, le=16)
    inter_op_num_threads: int = Field(default=1, ge=1, le=16)
    language_policy: tuple[Literal["zh"], Literal["en"]] = cast(
        "tuple[Literal['zh'], Literal['en']]",
        RAPIDOCR_ZH_EN_MODEL.languages,
    )
    preprocess_policy: Literal["sdk-rgb-to-rapidocr-bgr-v1"] = (
        "sdk-rgb-to-rapidocr-bgr-v1"
    )
    output_canonicalization_version: Literal["rapidocr-output-v2"] = (
        "rapidocr-output-v2"
    )
    text_score: float = Field(default=0.0, ge=0.0, le=0.0)
    max_candidates: Literal[1000] = 1000
    max_output_regions: int = Field(default=1000, ge=1, le=1000)
    max_model_files: Literal[3] = 3
    max_model_file_bytes: int = Field(default=64_000_000, gt=0, le=64_000_000)
    max_total_model_bytes: int = Field(default=128_000_000, gt=0, le=128_000_000)

    @model_validator(mode="after")
    def validate_model_limits(self) -> Self:
        """Keep caller-tightened model limits internally coherent."""
        if self.max_total_model_bytes < self.max_model_file_bytes:
            msg = "RapidOCR total model limit is smaller than one model limit"
            raise ValueError(msg)
        return self


class RapidOcrModelSet(SdkModel):
    """Runtime-only paths for the single approved ONNX model manifest."""

    model_id: ModelId
    detection_model: Path = Field(exclude=True, repr=False)
    classification_model: Path = Field(exclude=True, repr=False)
    recognition_model: Path = Field(exclude=True, repr=False)
    detection_sha256: Sha256
    classification_sha256: Sha256
    recognition_sha256: Sha256

    @model_validator(mode="after")
    def validate_approved_manifest(self) -> Self:
        """Accept paths only for the one reviewed model ID and hash set."""
        if (
            self.model_id != _APPROVED_MODEL_ID
            or self.expected_hashes != _APPROVED_MODEL_HASHES
        ):
            msg = "RapidOCR model manifest is not approved"
            raise ValueError(msg)
        return self

    @property
    def runtime_paths(self) -> tuple[Path, Path, Path]:
        """Return runtime-only model paths without serializing them."""
        return (
            self.detection_model,
            self.classification_model,
            self.recognition_model,
        )

    @property
    def expected_hashes(self) -> tuple[str, str, str]:
        """Return hashes in the same fixed order as runtime paths."""
        return (
            self.detection_sha256,
            self.classification_sha256,
            self.recognition_sha256,
        )

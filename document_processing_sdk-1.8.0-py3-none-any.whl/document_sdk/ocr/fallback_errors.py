"""Sanitized failures for explicit Azure page-level fallback."""

from document_sdk.core import DocumentProcessingError
from document_sdk.core.errors import DocumentSourceChangedError


class AzureFallbackError(DocumentProcessingError):
    """Base class for controlled Azure fallback failures."""

    def __init__(self, message: str, *, attempt_evidence: object | None = None) -> None:
        """Store only safe structured attempt evidence outside the message."""
        super().__init__(message)
        self.attempt_evidence = attempt_evidence


class AzureFallbackSourceChangedError(
    AzureFallbackError,
    DocumentSourceChangedError,
):
    """Raised when the caller's original source changes during fallback."""


class AzureFallbackConfigurationError(AzureFallbackError):
    """Raised when explicit fallback configuration is incomplete."""


class AzureFallbackProviderTypeError(AzureFallbackConfigurationError):
    """Raised when fallback receives a non-Azure Provider implementation."""


class AzureFallbackPayloadError(AzureFallbackError):
    """Raised when an isolated payload cannot be created safely."""


class AzureFallbackLimitError(AzureFallbackError):
    """Raised before fallback would exceed an explicit resource limit."""


class AzureFallbackExecutionError(AzureFallbackError):
    """Raised when the Azure Provider fails at the fallback boundary."""


class AzureFallbackInvalidResultError(AzureFallbackError):
    """Raised when Azure returns incomplete or inconsistent evidence."""


class AzureFallbackMappingError(AzureFallbackError):
    """Raised when isolated payload results cannot map to source indexes."""


class AzureFallbackResumeIdentityMismatchError(AzureFallbackError):
    """Raised when fallback identity differs from retained Resume evidence."""

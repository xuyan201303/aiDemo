"""Strict provider-neutral Local OCR contracts."""

import re
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Annotated, Literal, Protocol, Self, runtime_checkable

from pydantic import Field, StringConstraints, model_validator

from document_sdk.core._metadata import validate_safe_metadata
from document_sdk.core.models import SdkModel

type SafeIdentity = Annotated[
    str,
    StringConstraints(
        min_length=1,
        max_length=64,
        pattern=r"^[A-Za-z0-9][A-Za-z0-9._-]*$",
    ),
]
type PixelPoint = tuple[
    Annotated[float, Field(ge=0)],
    Annotated[float, Field(ge=0)],
]

_MAX_ENGINE_LANGUAGES = 32
_MAX_LOCAL_OCR_REGION_CHARACTERS = 100_000


class LocalOcrEngineIdentity(SdkModel):
    """Stable sanitized identity used for results and Resume compatibility."""

    engine_name: SafeIdentity
    engine_version: SafeIdentity
    model_id: SafeIdentity
    languages: tuple[SafeIdentity, ...] = Field(
        default=("und",),
        min_length=1,
        max_length=_MAX_ENGINE_LANGUAGES,
    )
    device_class: Literal["cpu"] = "cpu"
    thread_safety: Literal["serialized", "thread_safe"] = "serialized"

    @model_validator(mode="after")
    def validate_identity(self) -> Self:
        """Require deterministic non-credential identifiers only."""
        values = (
            self.engine_name,
            self.engine_version,
            self.model_id,
            *self.languages,
        )
        blocked_components = {
            "api",
            "apikey",
            "authorization",
            "bearer",
            "credential",
            "credentials",
            "key",
            "password",
            "passwd",
            "secret",
            "token",
        }
        if not self.languages or any(
            component == "sk" or component in blocked_components
            for value in values
            for component in re.split(r"[._-]+", value.casefold())
        ):
            msg = "Local OCR identity contains an unsafe identifier"
            raise ValueError(msg)
        normalized_languages = tuple(sorted(set(self.languages)))
        if not 1 <= len(normalized_languages) <= _MAX_ENGINE_LANGUAGES:
            msg = "Local OCR identity has an invalid language count"
            raise ValueError(msg)
        object.__setattr__(self, "languages", normalized_languages)
        validate_safe_metadata(
            {
                "engine_name": self.engine_name,
                "engine_version": self.engine_version,
                "model_id": self.model_id,
                "languages": list(normalized_languages),
                "device_class": self.device_class,
                "thread_safety": self.thread_safety,
            }
        )
        return self


class LocalOcrImageInput(SdkModel):
    """Runtime-only bounded decoded pixels passed to an explicit Engine."""

    width: int = Field(gt=0)
    height: int = Field(gt=0)
    mode: Literal["RGB", "L"]
    pixels: bytes = Field(min_length=1, exclude=True, repr=False)
    source_kind: Literal["image", "pdf"]
    source_index: int = Field(ge=1)

    @model_validator(mode="after")
    def validate_pixel_length(self) -> Self:
        """Require one exact packed RGB or grayscale buffer."""
        channels = 3 if self.mode == "RGB" else 1
        if len(self.pixels) != self.width * self.height * channels:
            msg = "Local OCR pixel buffer has an invalid length"
            raise ValueError(msg)
        return self


@dataclass(frozen=True, slots=True)
class LocalOcrEngineRegion:
    """Lightweight unvalidated Engine region created before SDK models."""

    text: str
    polygon: Sequence[tuple[float, float]]
    confidence: float
    reading_order: int
    language: str | None = None


@dataclass(frozen=True, slots=True)
class LocalOcrEngineResult:
    """Sized lightweight Engine result; generators are deliberately rejected."""

    regions: Sequence[LocalOcrEngineRegion] = ()


class LocalOcrRawRegion(SdkModel):
    """One fully validated safe OCR region in pixel coordinates."""

    text: str = Field(max_length=_MAX_LOCAL_OCR_REGION_CHARACTERS)
    polygon: tuple[PixelPoint, ...] = Field(min_length=4, max_length=16)
    confidence: float = Field(ge=0, le=1)
    reading_order: int = Field(ge=0)
    language: SafeIdentity | None = None


class LocalOcrRawResult(SdkModel):
    """Fully validated safe raw-object-free OCR result."""

    regions: tuple[LocalOcrRawRegion, ...] = ()

    @model_validator(mode="after")
    def validate_reading_order(self) -> Self:
        """Require unique contiguous deterministic reading order."""
        orders = tuple(region.reading_order for region in self.regions)
        if orders != tuple(range(len(orders))):
            msg = "Local OCR reading order must be contiguous and ordered"
            raise ValueError(msg)
        return self


@runtime_checkable
class LocalOcrEngine(Protocol):
    """Stable caller-extensible in-memory Local OCR Engine contract."""

    @property
    def identity(self) -> LocalOcrEngineIdentity:
        """Return stable sanitized Engine and model identity."""
        ...

    def recognize(self, image: LocalOcrImageInput) -> LocalOcrEngineResult:
        """Recognize one bounded runtime-only image without retaining it."""
        ...


class LocalOcrProcessingLimits(SdkModel):
    """Hard limits enforced around Local OCR inference and mapping."""

    max_width: int = Field(default=20_000, gt=0)
    max_height: int = Field(default=20_000, gt=0)
    max_pixels_per_input: int = Field(default=25_000_000, gt=0)
    max_total_pixels: int = Field(default=100_000_000, gt=0)
    max_pages: int = Field(default=100, gt=0)
    max_frames: int = Field(default=100, gt=0)
    max_source_pdf_pages: int = Field(default=1_000, gt=0, le=100_000)
    max_source_image_frames: int = Field(default=100, gt=0, le=100_000)
    max_source_image_pixels_per_frame: int = Field(
        default=25_000_000,
        gt=0,
    )
    max_source_image_total_metadata_pixels: int = Field(
        default=100_000_000,
        gt=0,
    )
    max_regions_per_input: int = Field(default=2_000, gt=0)
    max_total_regions: int = Field(default=10_000, gt=0)
    max_lines_per_input: int = Field(default=2_000, gt=0)
    max_total_lines: int = Field(default=10_000, gt=0)
    max_words_per_input: int = Field(default=20_000, gt=0)
    max_total_words: int = Field(default=100_000, gt=0)
    max_text_characters_per_input: int = Field(default=500_000, gt=0)
    max_total_text_characters: int = Field(default=2_000_000, gt=0)
    max_region_characters: int = Field(
        default=_MAX_LOCAL_OCR_REGION_CHARACTERS,
        gt=0,
        le=_MAX_LOCAL_OCR_REGION_CHARACTERS,
    )
    max_operations: int = Field(default=100, gt=0)
    max_concurrent_inferences: int = Field(default=1, gt=0)
    pdf_render_dpi: int = Field(default=144, ge=1, le=300)

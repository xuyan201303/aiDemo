"""Generic, provider-neutral OCR request options."""

from __future__ import annotations

from enum import StrEnum
from typing import Self

from pydantic import field_validator, model_validator

from document_sdk.core.models import SdkModel

_MAX_QUERY_FIELDS = 20


class DocumentAnalysisFeature(StrEnum):
    """Explicit optional Provider analysis features."""

    KEY_VALUE_PAIRS = "key_value_pairs"
    BARCODES = "barcodes"
    LANGUAGES = "languages"
    FORMULAS = "formulas"
    STYLE_FONT = "style_font"
    HIGH_RESOLUTION = "high_resolution"
    QUERY_FIELDS = "query_fields"


class OcrAnalysisOptions(SdkModel):
    """Optional selective pages and locale for an OCR analysis."""

    pages: tuple[int, ...] | None = None
    locale: str | None = None
    features: tuple[DocumentAnalysisFeature, ...] = ()
    query_fields: tuple[str, ...] = ()

    @field_validator("locale")
    @classmethod
    def normalize_locale(cls, value: str | None) -> str | None:
        """Normalize a non-empty provider-neutral locale hint."""
        if value is None:
            return None
        normalized = value.strip()
        if not normalized:
            msg = "OCR locale must not be blank"
            raise ValueError(msg)
        return normalized

    @model_validator(mode="after")
    def normalize_pages(self) -> Self:
        """Normalize pages, features, and explicit Query Fields."""
        object.__setattr__(
            self,
            "features",
            tuple(sorted(set(self.features), key=lambda feature: feature.value)),
        )
        normalized_query_fields = tuple(
            sorted({field.strip() for field in self.query_fields})
        )
        if any(not field for field in normalized_query_fields):
            msg = "OCR query fields must not be blank"
            raise ValueError(msg)
        if len(normalized_query_fields) > _MAX_QUERY_FIELDS:
            msg = "OCR query fields must contain at most 20 names"
            raise ValueError(msg)
        object.__setattr__(self, "query_fields", normalized_query_fields)
        has_query_feature = DocumentAnalysisFeature.QUERY_FIELDS in self.features
        if bool(normalized_query_fields) != has_query_feature:
            msg = "OCR query fields and their explicit feature must be used together"
            raise ValueError(msg)
        if self.pages is not None:
            if not self.pages:
                msg = "OCR pages must contain at least one page"
                raise ValueError(msg)
            if any(page < 1 for page in self.pages):
                msg = "OCR pages must contain positive one-based integers"
                raise ValueError(msg)
            object.__setattr__(self, "pages", tuple(sorted(set(self.pages))))
        return self

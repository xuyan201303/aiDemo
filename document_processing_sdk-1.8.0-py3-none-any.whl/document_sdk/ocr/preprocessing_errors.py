"""Sanitized Local OCR preprocessing failures."""

from document_sdk.ocr.local_errors import LocalOcrError, LocalOcrLimitExceededError


class LocalOcrPreprocessingError(LocalOcrError):
    """Base preprocessing failure."""


class LocalOcrPreprocessingConfigurationError(LocalOcrPreprocessingError):
    """The explicit preprocessing configuration is invalid."""


class LocalOcrPreprocessingLimitError(
    LocalOcrLimitExceededError, LocalOcrPreprocessingError
):
    """A preprocessing attempt or pixel limit was exceeded."""


class LocalOcrPreprocessingExecutionError(LocalOcrPreprocessingError):
    """An in-memory preprocessing profile failed."""


class LocalOcrPreprocessingSelectionError(LocalOcrPreprocessingError):
    """Candidate quality evidence could not be selected consistently."""

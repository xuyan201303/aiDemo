"""Strict content-free Local OCR preprocessing contracts."""

from __future__ import annotations

import hashlib
from collections.abc import Mapping, Sequence
from enum import StrEnum
from typing import Annotated, Literal, Never, Self, cast

from pydantic import Field, ValidationInfo, model_validator

from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.local_ocr_quality import (
    LocalOcrInputQualityAssessment,
    LocalOcrIntrinsicQualityPolicy,
    LocalOcrQualityDecision,
    LocalOcrQualityReport,
    LocalOcrQualitySummary,
    create_local_ocr_quality_report,
)
from document_sdk.core.models import SdkModel

LOCAL_OCR_PREPROCESSING_ALGORITHM_VERSION = "local-ocr-preprocessing-v1"
LOCAL_OCR_QUALITY_SELECTION_VERSION = "local-ocr-quality-selection-v1"
_MAX_PROFILES = 3
_MAX_EXTRA_ATTEMPTS_PER_INPUT = 3
_MAX_EXTRA_ATTEMPTS_PER_DOCUMENT = 300
_MAX_SOURCE_INPUTS = 100_000
_MAX_REPORT_ATTEMPTS = _MAX_SOURCE_INPUTS + _MAX_EXTRA_ATTEMPTS_PER_DOCUMENT
_MAX_SELECTED_PROFILE_COUNTS = 4
_MAX_PREPROCESSING_PIXELS_PER_INPUT = 25_000_000
_MAX_TOTAL_PREPROCESSING_PIXELS = 100_000_000
_MAX_WORKING_PIXELS = 100_000_000
_MAX_PROFILE_OUTPUT_BYTES = 75_000_000


def _invalid(message: str) -> Never:
    """Raise one compact model-invariant failure."""
    raise ValueError(message)


def _check_bounded_standard_sequence(
    value: object,
    *,
    maximum: int,
    label: str,
) -> None:
    """Bound exact built-in containers before Pydantic visits nested values."""
    if type(value) not in (list, tuple):
        _invalid(f"{label} must use a standard bounded sequence")
    sequence = cast("list[object] | tuple[object, ...]", value)
    if len(sequence) > maximum:
        _invalid(f"{label} exceeds its hard limit")


def _standardize_builtin_sequences(value: object) -> object:
    """Convert only exact built-in JSON arrays after outer bounds succeed."""
    actual_type = type(value)
    if actual_type in (list, tuple):
        sequence = cast("list[object] | tuple[object, ...]", value)
        return tuple(_standardize_builtin_sequences(item) for item in sequence)
    if actual_type is dict:
        mapping = cast("dict[object, object]", value)
        return {
            key: _standardize_builtin_sequences(item) for key, item in mapping.items()
        }
    if (
        actual_type not in {str, bytes}
        and not issubclass(actual_type, StrEnum)
        and issubclass(actual_type, (Mapping, Sequence))
    ):
        _invalid("Preprocessing evidence must use standard containers")
    return value


def _bound_preprocessing_report_raw_evidence(value: object) -> object:
    """Bound report collections before normalizing exact built-in sequences."""
    if type(value) is not dict:
        return _standardize_builtin_sequences(value)
    raw = cast("dict[str, object]", value)
    for field_name in ("input_indexes", "input_summaries"):
        if field_name in raw:
            _check_bounded_standard_sequence(
                raw[field_name],
                maximum=_MAX_SOURCE_INPUTS,
                label="Preprocessing input evidence",
            )
    if "attempts" in raw:
        _check_bounded_standard_sequence(
            raw["attempts"],
            maximum=_MAX_REPORT_ATTEMPTS,
            label="Preprocessing attempt evidence",
        )
    return _standardize_builtin_sequences(raw)


def _group_preprocessing_attempts_linear(  # noqa: C901
    *,
    attempts: tuple[LocalOcrPreprocessingAttemptSummary, ...],
    input_indexes: tuple[int, ...],
    source_kind: Literal["image", "pdf"],
) -> dict[int, tuple[LocalOcrPreprocessingAttemptSummary, ...]]:
    """Group attempts in O(inputs + attempts) with a single pass."""
    input_position_by_index = {
        input_index: input_position
        for input_position, input_index in enumerate(input_indexes)
    }
    grouped_attempts: dict[int, list[LocalOcrPreprocessingAttemptSummary]] = {
        input_index: [] for input_index in input_indexes
    }
    last_ordinal_by_position: dict[int, int] = {}
    seen_profile_and_ordinal: dict[
        int, set[tuple[LocalOcrPreprocessingProfile, int]]
    ] = {}
    last_input_position: int | None = None
    for item in attempts:
        if item.source_kind != source_kind:
            _invalid("Local OCR preprocessing attempt set is inconsistent")
        input_position = input_position_by_index.get(item.source_index)
        if input_position is None:
            _invalid("Local OCR preprocessing attempt set is inconsistent")
        if last_input_position is None:
            if input_position != 0:
                _invalid("Local OCR preprocessing attempt set is inconsistent")
            last_input_position = 0
        elif input_position < last_input_position:
            _invalid("Local OCR preprocessing attempt set is inconsistent")
        elif input_position > last_input_position:
            if input_position != last_input_position + 1:
                _invalid("Local OCR preprocessing attempt set is inconsistent")
            last_input_position = input_position
        attempts_for_position = grouped_attempts[item.source_index]
        last_ordinal = last_ordinal_by_position.get(input_position, -1)
        if item.attempt_ordinal != last_ordinal + 1:
            _invalid("Local OCR preprocessing attempt set is inconsistent")
        last_ordinal_by_position[input_position] = item.attempt_ordinal
        signatures = seen_profile_and_ordinal.setdefault(input_position, set())
        identity = (item.profile, item.attempt_ordinal)
        if identity in signatures:
            _invalid("Local OCR preprocessing attempt set is inconsistent")
        signatures.add(identity)
        attempts_for_position.append(item)
    for input_index in input_indexes:
        if not grouped_attempts[input_index]:
            _invalid("Local OCR preprocessing attempt set is inconsistent")
    return {key: tuple(value) for key, value in grouped_attempts.items()}


class LocalOcrPreprocessingProfile(StrEnum):
    """Fixed geometry-preserving preprocessing profiles."""

    ORIGINAL = "original"
    DOCUMENT_CLEAN = "document_clean"
    LOW_CONTRAST = "low_contrast"
    BINARY_DOCUMENT = "binary_document"


class LocalOcrPreprocessingAttemptStatus(StrEnum):
    """Content-free status of one baseline or retry attempt."""

    COMPLETED = "completed"
    PROFILE_FAILED = "profile_failed"
    ENGINE_FAILED = "engine_failed"


class LocalOcrPreprocessingSelectionReason(StrEnum):
    """Stable reason for the selected local OCR candidate."""

    BASELINE_PASSED = "baseline_passed"
    RETRY_PASSED = "retry_passed"
    BEST_AVAILABLE = "best_available"


class LocalOcrPreprocessingLimits(SdkModel):
    """Finite hard-capped retry and in-memory pixel limits."""

    max_extra_attempts_per_input: int = Field(default=3, ge=0, le=3)
    max_extra_attempts_per_document: int = Field(default=30, ge=0, le=300)
    max_preprocessing_pixels_per_input: int = Field(
        default=25_000_000, gt=0, le=_MAX_PREPROCESSING_PIXELS_PER_INPUT
    )
    max_total_preprocessing_pixels: int = Field(
        default=100_000_000, gt=0, le=_MAX_TOTAL_PREPROCESSING_PIXELS
    )
    max_working_pixels: int = Field(default=100_000_000, gt=0, le=_MAX_WORKING_PIXELS)
    max_profiles: int = Field(default=3, ge=1, le=3)
    max_profile_output_bytes: int = Field(
        default=75_000_000, gt=0, le=_MAX_PROFILE_OUTPUT_BYTES
    )


class LocalOcrPreprocessingPolicy(SdkModel):
    """Explicit ordered preprocessing policy; disabled by default."""

    enabled: bool = False
    profiles: tuple[LocalOcrPreprocessingProfile, ...] = Field(
        default=(), max_length=_MAX_PROFILES
    )
    stop_on_first_pass: Literal[True] = True
    selection_policy_version: Literal["local-ocr-quality-selection-v1"] = (
        "local-ocr-quality-selection-v1"
    )
    limits: LocalOcrPreprocessingLimits = Field(
        default_factory=LocalOcrPreprocessingLimits
    )

    @model_validator(mode="after")
    def validate_profiles(self) -> Self:
        """Require a unique bounded non-baseline sequence only when enabled."""
        if self.enabled != bool(self.profiles):
            msg = "Enabled preprocessing requires at least one profile"
            raise ValueError(msg)
        if LocalOcrPreprocessingProfile.ORIGINAL in self.profiles:
            msg = "The original baseline cannot be a retry profile"
            raise ValueError(msg)
        if len(set(self.profiles)) != len(self.profiles):
            msg = "Preprocessing profiles must be unique"
            raise ValueError(msg)
        if len(self.profiles) > self.limits.max_profiles:
            msg = "Preprocessing profile count exceeds its limit"
            raise ValueError(msg)
        if self.limits.max_extra_attempts_per_input < len(self.profiles):
            msg = "Preprocessing attempts per input are insufficient"
            raise ValueError(msg)
        return self


class LocalOcrPreprocessingAttemptSummary(SdkModel):
    """Safe evidence for one baseline or preprocessing attempt."""

    source_kind: Literal["image", "pdf"]
    source_index: int = Field(ge=1)
    profile: LocalOcrPreprocessingProfile
    attempt_ordinal: int = Field(ge=0, le=_MAX_EXTRA_ATTEMPTS_PER_INPUT)
    status: LocalOcrPreprocessingAttemptStatus
    operation_count: int = Field(ge=0, le=1)
    input_pixel_count: int = Field(gt=0)
    output_pixel_count: int = Field(ge=0)
    quality_assessment: LocalOcrInputQualityAssessment | None = None
    selected: bool = False
    failure_category: Literal["profile", "engine"] | None = None

    @model_validator(mode="after")
    def validate_projection(self) -> Self:  # noqa: C901
        """Cross-check baseline, success, failure, and selection evidence."""
        if (self.profile is LocalOcrPreprocessingProfile.ORIGINAL) != (
            self.attempt_ordinal == 0
        ):
            msg = "Preprocessing baseline ordinal is inconsistent"
            raise ValueError(msg)
        completed = self.status is LocalOcrPreprocessingAttemptStatus.COMPLETED
        if self.profile is LocalOcrPreprocessingProfile.ORIGINAL and not completed:
            msg = "The original preprocessing attempt must complete"
            raise ValueError(msg)
        if completed != (self.quality_assessment is not None):
            msg = "Preprocessing quality evidence is inconsistent"
            raise ValueError(msg)
        if self.quality_assessment is not None and (
            self.quality_assessment.source_kind != self.source_kind
            or self.quality_assessment.source_index != self.source_index
        ):
            msg = "Preprocessing quality source evidence is inconsistent"
            raise ValueError(msg)
        if self.selected and not completed:
            msg = "A failed preprocessing attempt cannot be selected"
            raise ValueError(msg)
        if completed != (self.failure_category is None):
            msg = "Preprocessing failure evidence is inconsistent"
            raise ValueError(msg)
        if completed and self.input_pixel_count != self.output_pixel_count:
            msg = "Preprocessing geometry is inconsistent"
            raise ValueError(msg)
        if self.status is LocalOcrPreprocessingAttemptStatus.PROFILE_FAILED and (
            self.operation_count != 0
            or self.failure_category != "profile"
            or self.output_pixel_count != 0
        ):
            msg = "Preprocessing profile failure evidence is inconsistent"
            raise ValueError(msg)
        if self.status is LocalOcrPreprocessingAttemptStatus.ENGINE_FAILED and (
            self.operation_count != 1
            or self.failure_category != "engine"
            or self.output_pixel_count != self.input_pixel_count
        ):
            msg = "Preprocessing engine failure evidence is inconsistent"
            raise ValueError(msg)
        if completed and self.operation_count != 1:
            msg = "Completed preprocessing operation evidence is inconsistent"
            raise ValueError(msg)
        return self


class LocalOcrPreprocessingInputSummary(SdkModel):
    """Safe selected-attempt evidence for one source input."""

    source_kind: Literal["image", "pdf"]
    source_index: int = Field(ge=1)
    selected_profile: LocalOcrPreprocessingProfile
    selected_attempt_ordinal: int = Field(ge=0, le=_MAX_EXTRA_ATTEMPTS_PER_INPUT)
    selection_reason: LocalOcrPreprocessingSelectionReason
    original_decision: LocalOcrQualityDecision
    final_decision: LocalOcrQualityDecision
    attempt_count: int = Field(ge=1, le=_MAX_EXTRA_ATTEMPTS_PER_INPUT + 1)
    preprocessing_pixel_count: int = Field(ge=0)
    extra_operation_count: int = Field(ge=0, le=_MAX_EXTRA_ATTEMPTS_PER_INPUT)

    @model_validator(mode="after")
    def validate_selection(self) -> Self:
        """Cross-check the selected profile, reason, decisions, and resources."""
        original = self.selected_profile is LocalOcrPreprocessingProfile.ORIGINAL
        if original != (self.selected_attempt_ordinal == 0):
            _invalid("Preprocessing selected ordinal is inconsistent")
        if self.selected_attempt_ordinal >= self.attempt_count:
            _invalid("Preprocessing selected attempt does not exist")
        if self.extra_operation_count != self.attempt_count - 1:
            _invalid("Preprocessing operation count is inconsistent")
        if self.attempt_count == 1:
            if (
                self.selected_attempt_ordinal != 0
                or self.preprocessing_pixel_count != 0
                or self.extra_operation_count != 0
            ):
                _invalid("Preprocessing baseline resources are inconsistent")
        elif self.preprocessing_pixel_count == 0 or self.extra_operation_count == 0:
            _invalid("Preprocessing retry resources are inconsistent")
        if (
            self.selection_reason
            is LocalOcrPreprocessingSelectionReason.BASELINE_PASSED
        ):
            valid = (
                self.original_decision is LocalOcrQualityDecision.PASS
                and self.final_decision is LocalOcrQualityDecision.PASS
                and self.attempt_count == 1
                and self.preprocessing_pixel_count == 0
                and self.extra_operation_count == 0
                and original
            )
        elif self.selection_reason is LocalOcrPreprocessingSelectionReason.RETRY_PASSED:
            valid = (
                self.original_decision is LocalOcrQualityDecision.FAIL
                and self.final_decision is LocalOcrQualityDecision.PASS
                and not original
                and self.extra_operation_count >= 1
            )
        else:
            valid = (
                self.original_decision is LocalOcrQualityDecision.FAIL
                and self.final_decision is LocalOcrQualityDecision.FAIL
                and self.attempt_count > 1
            )
        if not valid:
            _invalid("Preprocessing selection reason is inconsistent")
        return self


class LocalOcrPreprocessingProfileCount(SdkModel):
    """Stable selected-profile count without a mutable mapping."""

    profile: LocalOcrPreprocessingProfile
    count: int = Field(ge=1)


class LocalOcrPreprocessingSummary(SdkModel):
    """Small durable preprocessing projection for Batch and Resume."""

    algorithm_version: Literal["local-ocr-preprocessing-v1"] = (
        "local-ocr-preprocessing-v1"
    )
    selection_version: Literal["local-ocr-quality-selection-v1"] = (
        "local-ocr-quality-selection-v1"
    )
    policy_fingerprint: Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]
    attempted_input_count: int = Field(ge=0)
    not_needed_input_count: int = Field(ge=0)
    preprocessing_attempted_input_count: int = Field(ge=0)
    improved_input_count: int = Field(ge=0)
    pass_after_preprocessing_input_count: int = Field(ge=0)
    still_failed_input_count: int = Field(ge=0)
    extra_attempt_count: int = Field(ge=0)
    preprocessing_pixel_count: int = Field(ge=0)
    extra_operation_count: int = Field(ge=0)
    selected_profile_counts: tuple[LocalOcrPreprocessingProfileCount, ...] = Field(
        default=(), max_length=_MAX_SELECTED_PROFILE_COUNTS
    )
    source_page_count: int = Field(ge=0)
    source_frame_count: int = Field(ge=0)

    @model_validator(mode="before")
    @classmethod
    def bound_selected_profile_counts(
        cls, value: object, info: ValidationInfo
    ) -> object:
        """Reject oversized or caller-defined containers before item parsing."""
        del info
        if type(value) is dict:
            raw = cast("dict[str, object]", value)
            if "selected_profile_counts" in raw:
                _check_bounded_standard_sequence(
                    raw["selected_profile_counts"],
                    maximum=_MAX_SELECTED_PROFILE_COUNTS,
                    label="Preprocessing selected profile counts",
                )
            return _standardize_builtin_sequences(raw)
        return _standardize_builtin_sequences(value)

    @model_validator(mode="after")
    def validate_summary(self) -> Self:  # noqa: C901, PLR0912
        """Require canonical profile counts and complete outcome partitioning."""
        if self.policy_fingerprint == _DISABLED_PREPROCESSING_POLICY_FINGERPRINT:
            _invalid("Disabled preprocessing policy cannot produce a summary")
        profiles = tuple(item.profile for item in self.selected_profile_counts)
        if profiles != tuple(
            sorted(
                set(profiles),
                key=lambda item: list(LocalOcrPreprocessingProfile).index(item),
            )
        ):
            _invalid("Preprocessing profile counts are not canonical")
        if (
            sum(item.count for item in self.selected_profile_counts)
            != self.attempted_input_count
        ):
            _invalid("Preprocessing selected profile counts are inconsistent")
        if self.attempted_input_count != (
            self.not_needed_input_count + self.preprocessing_attempted_input_count
        ):
            _invalid("Preprocessing outcome counts are inconsistent")
        if self.preprocessing_attempted_input_count != (
            self.improved_input_count + self.still_failed_input_count
        ):
            _invalid("Preprocessing attempted input counts are inconsistent")
        if self.pass_after_preprocessing_input_count > self.improved_input_count:
            _invalid("Preprocessing pass count is inconsistent")
        if self.improved_input_count != self.pass_after_preprocessing_input_count:
            _invalid("Preprocessing improvement count is inconsistent")
        if self.extra_operation_count != self.extra_attempt_count:
            _invalid("Preprocessing successful retry counts are inconsistent")
        if not (
            self.preprocessing_attempted_input_count
            <= self.extra_attempt_count
            <= self.preprocessing_attempted_input_count * _MAX_EXTRA_ATTEMPTS_PER_INPUT
        ):
            _invalid("Preprocessing retry attempt counts are inconsistent")
        if self.preprocessing_attempted_input_count == 0:
            if (
                self.extra_attempt_count != 0
                or self.preprocessing_pixel_count != 0
                or self.extra_operation_count != 0
            ):
                _invalid("Preprocessing zero-retry evidence is inconsistent")
        elif (
            self.extra_attempt_count == 0
            or self.preprocessing_pixel_count == 0
            or self.extra_operation_count == 0
        ):
            _invalid("Preprocessing retry resource evidence is inconsistent")
        if bool(self.source_page_count) == bool(self.source_frame_count):
            _invalid("Preprocessing source family is inconsistent")
        if (
            self.source_page_count + self.source_frame_count
            != self.attempted_input_count
        ):
            _invalid("Preprocessing source count is inconsistent")
        return self


class LocalOcrPreprocessingReport(SdkModel):
    """Content-free complete per-document preprocessing evidence."""

    algorithm_version: Literal["local-ocr-preprocessing-v1"] = (
        "local-ocr-preprocessing-v1"
    )
    selection_version: Literal["local-ocr-quality-selection-v1"] = (
        "local-ocr-quality-selection-v1"
    )
    policy_fingerprint: Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]
    policy: LocalOcrPreprocessingPolicy
    quality_policy: LocalOcrIntrinsicQualityPolicy
    source_kind: Literal["image", "pdf"]
    input_indexes: tuple[int, ...] = Field(max_length=_MAX_SOURCE_INPUTS)
    input_summaries: tuple[LocalOcrPreprocessingInputSummary, ...] = Field(
        max_length=_MAX_SOURCE_INPUTS
    )
    original_quality_summary: LocalOcrQualitySummary
    final_quality_summary: LocalOcrQualitySummary
    total_preprocessing_pixels: int = Field(ge=0)
    total_extra_ocr_operations: int = Field(ge=0)
    attempts: tuple[LocalOcrPreprocessingAttemptSummary, ...] = Field(
        max_length=_MAX_REPORT_ATTEMPTS
    )

    @model_validator(mode="before")
    @classmethod
    def bound_raw_evidence(cls, value: object, info: ValidationInfo) -> object:
        """Bound exact raw containers before any nested evidence is parsed."""
        del info
        return _bound_preprocessing_report_raw_evidence(value)

    @model_validator(mode="after")
    def validate_evidence(self) -> Self:  # noqa: C901, PLR0912
        """Cross-check ordered inputs, attempts, policy, and selected evidence."""
        from document_sdk.ocr._preprocessing_selection import (
            _PreprocessingCandidate,
            _select_preprocessing_candidate,
        )

        if self.policy.enabled is not True:
            _invalid("Disabled preprocessing policy cannot produce a report")
        if self.policy_fingerprint != local_ocr_preprocessing_policy_fingerprint(
            self.policy
        ):
            msg = "Local OCR preprocessing policy fingerprint is inconsistent"
            raise ValueError(msg)
        if (
            not self.input_indexes
            or tuple(sorted(set(self.input_indexes))) != self.input_indexes
            or tuple(item.source_index for item in self.input_summaries)
            != self.input_indexes
            or any(
                item.source_kind != self.source_kind for item in self.input_summaries
            )
        ):
            msg = "Local OCR preprocessing input evidence is inconsistent"
            raise ValueError(msg)
        grouped_attempts = _group_preprocessing_attempts_linear(
            attempts=self.attempts,
            input_indexes=self.input_indexes,
            source_kind=self.source_kind,
        )
        if len(self.attempts) != sum(
            item.attempt_count for item in self.input_summaries
        ):
            msg = "Local OCR preprocessing attempt set is inconsistent"
            raise ValueError(msg)
        if any(
            item.status is not LocalOcrPreprocessingAttemptStatus.COMPLETED
            for item in self.attempts
        ):
            _invalid("Successful preprocessing report contains a failed attempt")
        retry_attempt_count = len(self.attempts) - len(self.input_summaries)
        if (
            retry_attempt_count > self.policy.limits.max_extra_attempts_per_document
            or self.total_extra_ocr_operations
            > self.policy.limits.max_extra_attempts_per_document
            or self.total_preprocessing_pixels
            > self.policy.limits.max_total_preprocessing_pixels
        ):
            _invalid("Preprocessing report exceeds its document limits")
        for summary in self.input_summaries:
            attempts = grouped_attempts[summary.source_index]
            if (
                tuple(item.attempt_ordinal for item in attempts)
                != tuple(range(len(attempts)))
                or len(attempts) != summary.attempt_count
                or len(attempts) - 1 > self.policy.limits.max_extra_attempts_per_input
                or sum(item.operation_count for item in attempts[1:])
                != summary.extra_operation_count
                or sum(item.input_pixel_count for item in attempts[1:])
                != summary.preprocessing_pixel_count
                or sum(item.selected for item in attempts) != 1
            ):
                msg = "Local OCR preprocessing attempt evidence is inconsistent"
                raise ValueError(msg)
            if any(
                item.input_pixel_count
                > self.policy.limits.max_preprocessing_pixels_per_input
                or item.input_pixel_count * 4 > self.policy.limits.max_working_pixels
                or item.output_pixel_count * 3
                > self.policy.limits.max_profile_output_bytes
                for item in attempts[1:]
            ):
                _invalid("Preprocessing attempt exceeds its policy limits")
            retry_profiles = tuple(item.profile for item in attempts[1:])
            if retry_profiles != self.policy.profiles[: len(retry_profiles)]:
                msg = "Local OCR preprocessing retry profile order is inconsistent"
                raise ValueError(msg)
            selected = next(item for item in attempts if item.selected)
            first_pass = next(
                (
                    item
                    for item in attempts
                    if cast(
                        "LocalOcrInputQualityAssessment", item.quality_assessment
                    ).decision
                    is LocalOcrQualityDecision.PASS
                ),
                None,
            )
            if first_pass is not None:
                if (
                    first_pass is not attempts[-1]
                    or not first_pass.selected
                    or (first_pass.attempt_ordinal == 0 and len(attempts) != 1)
                ):
                    msg = "Local OCR preprocessing first-pass stop is inconsistent"
                    raise ValueError(msg)
            else:
                ranked = _select_preprocessing_candidate(
                    tuple(
                        _PreprocessingCandidate(
                            profile=item.profile,
                            profile_order=item.attempt_ordinal,
                            assessment=cast(
                                "LocalOcrInputQualityAssessment",
                                item.quality_assessment,
                            ),
                            payload=item,
                        )
                        for item in attempts
                    )
                )
                if ranked.payload is not selected:
                    msg = "Local OCR preprocessing selected candidate is inconsistent"
                    raise ValueError(msg)
            if (
                selected.profile != summary.selected_profile
                or selected.attempt_ordinal != summary.selected_attempt_ordinal
                or cast(
                    "LocalOcrInputQualityAssessment", selected.quality_assessment
                ).decision
                != summary.final_decision
                or cast(
                    "LocalOcrInputQualityAssessment", attempts[0].quality_assessment
                ).decision
                != summary.original_decision
            ):
                msg = "Local OCR preprocessing selection evidence is inconsistent"
                raise ValueError(msg)
        if self.total_preprocessing_pixels != sum(
            item.preprocessing_pixel_count for item in self.input_summaries
        ) or self.total_extra_ocr_operations != sum(
            item.extra_operation_count for item in self.input_summaries
        ):
            msg = "Local OCR preprocessing totals are inconsistent"
            raise ValueError(msg)
        original = create_local_ocr_quality_report(
            intrinsic_policy=self.quality_policy,
            assessments=tuple(
                item.quality_assessment
                for item in self.attempts
                if item.attempt_ordinal == 0 and item.quality_assessment is not None
            ),
        ).summary
        final = create_local_ocr_quality_report(
            intrinsic_policy=self.quality_policy,
            assessments=tuple(
                item.quality_assessment
                for item in self.attempts
                if item.selected and item.quality_assessment is not None
            ),
        ).summary
        if (
            original != self.original_quality_summary
            or final != self.final_quality_summary
        ):
            _invalid("Preprocessing quality summaries are inconsistent")
        return self

    def summary(self) -> LocalOcrPreprocessingSummary:
        """Derive the unique durable summary from validated report evidence."""
        counts: list[LocalOcrPreprocessingProfileCount] = []
        for profile in LocalOcrPreprocessingProfile:
            count = sum(
                item.selected_profile is profile for item in self.input_summaries
            )
            if count:
                counts.append(
                    LocalOcrPreprocessingProfileCount(profile=profile, count=count)
                )
        return LocalOcrPreprocessingSummary(
            policy_fingerprint=self.policy_fingerprint,
            attempted_input_count=len(self.input_summaries),
            not_needed_input_count=sum(
                item.selection_reason
                is LocalOcrPreprocessingSelectionReason.BASELINE_PASSED
                for item in self.input_summaries
            ),
            preprocessing_attempted_input_count=sum(
                item.attempt_count > 1 for item in self.input_summaries
            ),
            improved_input_count=sum(
                item.final_decision is LocalOcrQualityDecision.PASS
                and item.original_decision is LocalOcrQualityDecision.FAIL
                for item in self.input_summaries
            ),
            pass_after_preprocessing_input_count=sum(
                item.selection_reason
                is LocalOcrPreprocessingSelectionReason.RETRY_PASSED
                for item in self.input_summaries
            ),
            still_failed_input_count=sum(
                item.final_decision is LocalOcrQualityDecision.FAIL
                for item in self.input_summaries
            ),
            extra_attempt_count=sum(
                item.attempt_count - 1 for item in self.input_summaries
            ),
            preprocessing_pixel_count=self.total_preprocessing_pixels,
            extra_operation_count=self.total_extra_ocr_operations,
            selected_profile_counts=tuple(counts),
            source_page_count=(
                len(self.input_indexes) if self.source_kind == "pdf" else 0
            ),
            source_frame_count=(
                len(self.input_indexes) if self.source_kind == "image" else 0
            ),
        )


def local_ocr_preprocessing_policy_fingerprint(
    policy: LocalOcrPreprocessingPolicy,
) -> str:
    """Return the canonical path-free policy fingerprint."""
    validated = _revalidate_model_instance_json(
        policy,
        LocalOcrPreprocessingPolicy,
        "Local OCR preprocessing policy is invalid",
    )
    payload = LocalOcrPreprocessingPolicy.__pydantic_serializer__.to_json(
        validated,
        round_trip=True,
        warnings="error",
        ensure_ascii=False,
    )
    return hashlib.sha256(payload).hexdigest()


_DISABLED_PREPROCESSING_POLICY_FINGERPRINT = local_ocr_preprocessing_policy_fingerprint(
    LocalOcrPreprocessingPolicy()
)


def _validate_preprocessing_quality_lineage(
    preprocessing_report: LocalOcrPreprocessingReport,
    quality_report: LocalOcrQualityReport,
) -> tuple[LocalOcrPreprocessingReport, LocalOcrQualityReport]:
    """Validate selected intrinsic evidence while allowing structured extensions."""
    validated_preprocessing = _revalidate_model_instance_json(
        preprocessing_report,
        LocalOcrPreprocessingReport,
        "Local OCR preprocessing report is invalid",
    )
    validated_quality = _revalidate_model_instance_json(
        quality_report,
        LocalOcrQualityReport,
        "Local OCR quality report is invalid",
    )
    if validated_preprocessing.quality_policy != validated_quality.policy.intrinsic:
        _invalid("Preprocessing intrinsic quality policy is inconsistent")
    selected_assessments = tuple(
        cast("LocalOcrInputQualityAssessment", item.quality_assessment)
        for item in validated_preprocessing.attempts
        if item.selected
    )
    if validated_quality.input_assessments != selected_assessments:
        _invalid("Preprocessing intrinsic quality assessments are inconsistent")
    intrinsic_only = create_local_ocr_quality_report(
        intrinsic_policy=validated_quality.policy.intrinsic,
        assessments=validated_quality.input_assessments,
    )
    if intrinsic_only.summary != validated_preprocessing.final_quality_summary:
        _invalid("Preprocessing intrinsic quality lineage is inconsistent")
    return validated_preprocessing, validated_quality

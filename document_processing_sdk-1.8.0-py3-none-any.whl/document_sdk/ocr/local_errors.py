"""Sanitized Local OCR exception hierarchy."""

from __future__ import annotations

from typing import TYPE_CHECKING

from document_sdk.core import DocumentProcessingError

if TYPE_CHECKING:
    from document_sdk.core import ProviderUsage

_ATTEMPT_USAGE_ATTRIBUTE = "_local_ocr_attempt_usage"


def _attach_attempt_usage(error: Exception, usage: ProviderUsage | None) -> None:
    """Attach one immutable content-free projection without changing messages."""
    if usage is not None:
        setattr(error, _ATTEMPT_USAGE_ATTRIBUTE, usage)


def _attempt_usage(error: BaseException) -> ProviderUsage | None:
    """Return a validated Local OCR attempt projection carried by an error."""
    from document_sdk.core import ProviderUsage

    usage = getattr(error, _ATTEMPT_USAGE_ATTRIBUTE, None)
    return usage if isinstance(usage, ProviderUsage) else None


class LocalOcrError(DocumentProcessingError):
    """Base for controlled Local OCR failures."""


class LocalOcrEngineInitializationError(LocalOcrError):
    """Raised when an explicit Engine cannot be safely initialized."""


class LocalOcrModelUnavailableError(LocalOcrError):
    """Raised when caller-managed local model data is unavailable."""


class LocalOcrInvalidResultError(LocalOcrError):
    """Raised when an Engine returns malformed or unsafe output."""


class LocalOcrLimitExceededError(LocalOcrError):
    """Raised before a configured Local OCR resource bound is exceeded."""

    def __init__(self, *, limit_name: str, observed: int, maximum: int) -> None:
        """Create a safe structured limit failure."""
        self.limit_name = limit_name
        self.observed = observed
        self.maximum = maximum
        message = (
            f"Local OCR {limit_name} limit exceeded: observed {observed}, "
            f"maximum {maximum}"
        )
        super().__init__(message)


class LocalOcrExecutionError(LocalOcrError):
    """Raised when local Engine inference fails."""


class LocalOcrEngineIdentityError(LocalOcrError):
    """Raised when runtime Engine identity is incompatible with retained evidence."""


class LocalOcrUnsupportedLanguageError(LocalOcrError):
    """Raised before work when a Local OCR language profile is unsupported."""


class LocalOcrModelSelectionError(LocalOcrError):
    """Raised before work when a Local OCR model selection is unsupported."""


class LocalOcrUnsupportedInputError(LocalOcrError):
    """Raised when content is not a supported PDF or image family."""


class LocalOcrQualityConfigurationError(LocalOcrError):
    """Raised before processing when Local OCR quality policy is incompatible."""


class LocalOcrQualityEvaluationError(LocalOcrError):
    """Raised when quality evidence cannot be evaluated safely."""

"""Lazy optional-dependency boundary for the RapidOCR CPU adapter."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from importlib import import_module
from importlib.metadata import PackageNotFoundError, packages_distributions, version
from pathlib import Path
from typing import Any, Never, cast

from document_sdk.core import DependencyNotInstalledError
from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.ocr._model_registry import RAPIDOCR_ZH_EN_MODEL
from document_sdk.ocr.rapidocr_errors import RapidOcrEngineInitializationError

SUPPORTED_RAPIDOCR_VERSION = RAPIDOCR_ZH_EN_MODEL.engine_version
SUPPORTED_ONNXRUNTIME_VERSION = "1.27.0"
SUPPORTED_NUMPY_VERSION = "2.5.1"
SUPPORTED_OPENCV_DISTRIBUTION = "opencv-python"
SUPPORTED_OPENCV_VERSION = "4.13.0.92"
_SUPPORTED_CV2_VERSION = "4.13.0"
SUPPORTED_DEPENDENCY_VERSIONS = (
    ("rapidocr", SUPPORTED_RAPIDOCR_VERSION),
    ("onnxruntime", SUPPORTED_ONNXRUNTIME_VERSION),
    ("numpy", SUPPORTED_NUMPY_VERSION),
    (SUPPORTED_OPENCV_DISTRIBUTION, SUPPORTED_OPENCV_VERSION),
    ("pyclipper", "1.4.0"),
    ("shapely", "2.1.2"),
    ("omegaconf", "2.3.1"),
    ("antlr4-python3-runtime", "4.9.3"),
    ("pyyaml", "6.0.3"),
    ("pillow", "12.3.0"),
    ("requests", "2.34.2"),
    ("colorlog", "6.12.0"),
    ("six", "1.17.0"),
    ("tqdm", "4.70.0"),
)

RAPIDOCR_DEPENDENCY_MESSAGE = """RapidOCR CPU support is not installed.
Install it with:
  pip install "document-processing-sdk[ocr-rapidocr]"
or:
  uv add "document-processing-sdk[ocr-rapidocr]"""


@dataclass(frozen=True, slots=True)
class _RapidOcrDependencies:
    rapidocr_type: type[Any]
    output_type: type[Any]
    numpy: Any
    onnxruntime_session_type: type[Any]
    onnxruntime_engine_type: Enum
    package_root: Path
    package_version: str
    runtime_version: str
    numpy_version: str
    opencv_distribution: str
    opencv_version: str
    dependency_versions: tuple[tuple[str, str], ...]


def _fail_dependency_validation() -> Never:
    message = "RapidOCR dependency validation failed"
    raise RapidOcrEngineInitializationError(message)


def _require_rapidocr_support() -> _RapidOcrDependencies:
    """Load the pinned adapter dependencies without initializing inference."""
    try:
        rapidocr_module = import_module("rapidocr")
        output_module = import_module("rapidocr.utils.output")
        numpy_module = import_module("numpy")
        onnxruntime_module = import_module("onnxruntime")
        cv2_module = import_module("cv2")
        observed_dependency_versions: list[tuple[str, str]] = []
        for distribution, _expected in SUPPORTED_DEPENDENCY_VERSIONS:
            observed_version = version(distribution)
            if type(observed_version) is not str:
                _fail_dependency_validation()
            observed_dependency_versions.append((distribution, observed_version))
        dependency_versions = tuple(observed_dependency_versions)
        resolved_versions = dict(dependency_versions)
        package_version = resolved_versions["rapidocr"]
        runtime_version = resolved_versions["onnxruntime"]
        numpy_version = resolved_versions["numpy"]
        opencv_version = resolved_versions[SUPPORTED_OPENCV_DISTRIBUTION]
        distribution_packages = packages_distributions()
        if type(distribution_packages) is not dict:
            _fail_dependency_validation()
        cv2_package_distributions = distribution_packages.get("cv2")
        if type(cv2_package_distributions) is not list or any(
            type(name) is not str for name in cv2_package_distributions
        ):
            _fail_dependency_validation()
        cv2_distributions = tuple(
            sorted(
                name.casefold().replace("_", "-") for name in cv2_package_distributions
            )
        )
        module_file = rapidocr_module.__file__
        rapidocr_type = getattr(rapidocr_module, "RapidOCR", None)
        output_type = getattr(output_module, "RapidOCROutput", None)
        numpy_array_type = getattr(numpy_module, "ndarray", None)
        onnxruntime_session_type = getattr(
            onnxruntime_module,
            "InferenceSession",
            None,
        )
        engine_type = getattr(
            getattr(rapidocr_module, "EngineType", None),
            "ONNXRUNTIME",
            None,
        )
        cv2_version = getattr(cv2_module, "__version__", None)
        numpy_module_version = getattr(numpy_module, "__version__", None)
        onnxruntime_module_version = getattr(
            onnxruntime_module,
            "__version__",
            None,
        )
        if (
            type(module_file) is not str
            or type(rapidocr_type) is not type
            or type(output_type) is not type
            or type(numpy_array_type) is not type
            or type(onnxruntime_session_type) is not type
            or not issubclass(type(engine_type), Enum)
            or type(cv2_version) is not str
            or type(numpy_module_version) is not str
            or type(onnxruntime_module_version) is not str
        ):
            _fail_dependency_validation()
        supported_engine_type = cast("Enum", engine_type)
        if (
            type(supported_engine_type.value) is not str
            or package_version != SUPPORTED_RAPIDOCR_VERSION
            or runtime_version != SUPPORTED_ONNXRUNTIME_VERSION
            or numpy_version != SUPPORTED_NUMPY_VERSION
            or opencv_version != SUPPORTED_OPENCV_VERSION
            or dependency_versions != SUPPORTED_DEPENDENCY_VERSIONS
            or cv2_distributions != (SUPPORTED_OPENCV_DISTRIBUTION,)
            or cv2_version != _SUPPORTED_CV2_VERSION
            or numpy_module_version != SUPPORTED_NUMPY_VERSION
            or onnxruntime_module_version != SUPPORTED_ONNXRUNTIME_VERSION
            or supported_engine_type.value != "onnxruntime"
        ):
            _fail_dependency_validation()
        package_root = Path(module_file).resolve().parent
        return _RapidOcrDependencies(
            rapidocr_type=rapidocr_type,
            output_type=output_type,
            numpy=numpy_module,
            onnxruntime_session_type=onnxruntime_session_type,
            onnxruntime_engine_type=supported_engine_type,
            package_root=package_root,
            package_version=package_version,
            runtime_version=runtime_version,
            numpy_version=numpy_version,
            opencv_distribution=SUPPORTED_OPENCV_DISTRIBUTION,
            opencv_version=opencv_version,
            dependency_versions=dependency_versions,
        )
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except (ImportError, ModuleNotFoundError, PackageNotFoundError) as exc:
        _raise_redacted_translation(
            exc,
            DependencyNotInstalledError(RAPIDOCR_DEPENDENCY_MESSAGE),
        )
    except Exception as exc:  # noqa: BLE001 - dependency boundary is redacted.
        _raise_redacted_translation(
            exc,
            RapidOcrEngineInitializationError("RapidOCR dependency validation failed"),
        )

"""Explicit OCR provider contract."""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from pathlib import Path

    from document_sdk.core import Document, ProcessingResult
    from document_sdk.ocr.models import OcrAnalysisOptions
    from document_sdk.providers import ProviderContext


@runtime_checkable
class OcrProvider(Protocol):
    """Normalize an explicitly selected OCR implementation."""

    @property
    def context(self) -> ProviderContext:
        """Return the provider instance's isolated runtime context."""
        ...

    def analyze(
        self,
        path: Path,
        *,
        options: OcrAnalysisOptions | None = None,
    ) -> ProcessingResult[Document]:
        """Analyze one local file and return normalized SDK models."""
        ...

"""Provider-neutral Local OCR model selection and capability evidence."""

from __future__ import annotations

import platform
import re
import sys
from enum import StrEnum
from typing import Annotated, Literal, Self

from pydantic import Field, StringConstraints, model_validator

from document_sdk.core._metadata import validate_safe_metadata
from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.core.models import SdkModel
from document_sdk.ocr._model_registry import RAPIDOCR_ZH_EN_MODEL
from document_sdk.ocr._rapidocr_dependencies import (
    SUPPORTED_DEPENDENCY_VERSIONS,
    _RapidOcrDependencies,
)
from document_sdk.ocr.local_errors import (
    LocalOcrModelSelectionError,
    LocalOcrUnsupportedLanguageError,
)
from document_sdk.ocr.local_models import LocalOcrEngineIdentity

type SafeCapabilityComponent = Annotated[
    str,
    StringConstraints(
        min_length=1,
        max_length=64,
        pattern=r"^[A-Za-z0-9][A-Za-z0-9._-]*$",
    ),
]

_POLICY_FIELDS = frozenset({"language_profile", "model_id"})
_PLATFORM_COMPONENT = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$")
_INVALID_POLICY = "Local OCR model policy is invalid"
_UNSUPPORTED_LANGUAGE = "Local OCR language profile is unsupported"
_UNSUPPORTED_MODEL = "Local OCR model selection is unsupported"
_INVALID_PLATFORM = "Local OCR runtime platform is invalid"
_UNSUPPORTED_ENGINE = "Local OCR capability Engine is unsupported"
_INVALID_ENGINE_IDENTITY = "Local OCR capability Engine identity is invalid"
_INVALID_CAPABILITY = "Local OCR runtime capability is invalid"


class LocalOcrLanguageProfile(StrEnum):
    """Canonical language profiles approved for Local OCR model selection."""

    ZH_EN = "zh_en"


class LocalOcrModelSelectionPolicy(SdkModel):
    """Explicit path-free selection request for one approved Local OCR model."""

    language_profile: LocalOcrLanguageProfile = LocalOcrLanguageProfile.ZH_EN
    model_id: SafeCapabilityComponent = RAPIDOCR_ZH_EN_MODEL.model_id


class LocalOcrRuntimeCapability(SdkModel):
    """Content-safe declared or runtime-verified Local OCR capability."""

    engine_name: SafeCapabilityComponent
    engine_version: SafeCapabilityComponent
    model_id: SafeCapabilityComponent
    language_profile: LocalOcrLanguageProfile
    languages: tuple[SafeCapabilityComponent, ...] = Field(min_length=1, max_length=8)
    device_class: Literal["cpu"]
    execution_provider: Literal["CPUExecutionProvider"]
    dependency_versions: tuple[
        tuple[SafeCapabilityComponent, SafeCapabilityComponent], ...
    ] = Field(min_length=1, max_length=32)
    python_major: int = Field(ge=3, le=99)
    python_minor: int = Field(ge=0, le=99)
    platform_system: SafeCapabilityComponent
    platform_machine: SafeCapabilityComponent
    runtime_verification: Literal["declared", "verified"]

    @model_validator(mode="after")
    def validate_current_capability(self) -> Self:
        """Bind evidence to the sole current Registry entry and pinned stack."""
        expected = RAPIDOCR_ZH_EN_MODEL
        if (
            self.engine_name != expected.engine_name
            or self.engine_version != expected.engine_version
            or self.model_id != expected.model_id
            or self.language_profile.value != expected.language_profile
            or self.languages != expected.languages
            or self.device_class != expected.device_class
            or self.execution_provider != expected.execution_provider
            or self.dependency_versions != SUPPORTED_DEPENDENCY_VERSIONS
        ):
            msg = "Local OCR runtime capability is inconsistent with the Registry"
            raise ValueError(msg)
        validate_safe_metadata(
            {
                "engine_name": self.engine_name,
                "engine_version": self.engine_version,
                "model_id": self.model_id,
                "language_profile": self.language_profile.value,
                "languages": list(self.languages),
                "device_class": self.device_class,
                "execution_provider": self.execution_provider,
                "dependency_versions": [
                    list(item) for item in self.dependency_versions
                ],
                "python_major": self.python_major,
                "python_minor": self.python_minor,
                "platform_system": self.platform_system,
                "platform_machine": self.platform_machine,
                "runtime_verification": self.runtime_verification,
            }
        )
        return self


def _validated_model_selection_policy(
    policy: LocalOcrModelSelectionPolicy | None,
) -> LocalOcrModelSelectionPolicy:
    """Rebuild one exact policy without invoking caller-controlled hooks."""
    if policy is None:
        return LocalOcrModelSelectionPolicy()
    try:
        language_profile, model_id = _read_model_selection_policy(policy)
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except (LocalOcrUnsupportedLanguageError, LocalOcrModelSelectionError):
        raise
    except Exception as exc:  # noqa: BLE001 - forged policy boundary is redacted.
        _raise_redacted_translation(
            exc,
            LocalOcrModelSelectionError(_INVALID_POLICY),
        )
    return LocalOcrModelSelectionPolicy(
        language_profile=language_profile,
        model_id=model_id,
    )


def _read_model_selection_policy(
    policy: LocalOcrModelSelectionPolicy,
) -> tuple[LocalOcrLanguageProfile, str]:
    if type(policy) is not LocalOcrModelSelectionPolicy:
        raise LocalOcrModelSelectionError(_INVALID_POLICY)
    fields = object.__getattribute__(policy, "__dict__")
    if type(fields) is not dict or frozenset(fields) != _POLICY_FIELDS:
        raise LocalOcrModelSelectionError(_INVALID_POLICY)
    language_profile = fields.get("language_profile")
    model_id = fields.get("model_id")
    if (
        type(language_profile) is not LocalOcrLanguageProfile
        or language_profile is not LocalOcrLanguageProfile.ZH_EN
    ):
        raise LocalOcrUnsupportedLanguageError(_UNSUPPORTED_LANGUAGE)
    if type(model_id) is not str or model_id != RAPIDOCR_ZH_EN_MODEL.model_id:
        raise LocalOcrModelSelectionError(_UNSUPPORTED_MODEL)
    return language_profile, model_id


def _safe_platform_component(value: object) -> str:
    if type(value) is not str or _PLATFORM_COMPONENT.fullmatch(value) is None:
        raise LocalOcrModelSelectionError(_INVALID_PLATFORM)
    return value


def _validate_engine_capability(
    engine: object,
    policy: LocalOcrModelSelectionPolicy,
) -> Literal["declared", "verified"]:
    """Validate one exact RapidOCR Engine without exposing runtime objects."""
    from document_sdk.ocr.rapidocr import RapidOcrEngine

    if type(engine) is not RapidOcrEngine:
        raise LocalOcrModelSelectionError(_UNSUPPORTED_ENGINE)
    try:
        verification = _read_engine_capability(engine, policy, RapidOcrEngine)
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except LocalOcrModelSelectionError:
        raise
    except Exception as exc:  # noqa: BLE001 - runtime boundary is redacted.
        _raise_redacted_translation(
            exc,
            LocalOcrModelSelectionError(_INVALID_CAPABILITY),
        )
    return verification


def _read_engine_capability(
    engine: object,
    policy: LocalOcrModelSelectionPolicy,
    engine_type: type[object],
) -> Literal["declared", "verified"]:
    engine_policy = object.__getattribute__(engine, "_model_policy")
    dependencies = object.__getattribute__(engine, "_dependencies")
    identity = object.__getattribute__(engine, "_identity")
    runtime = object.__getattribute__(engine, "_runtime")
    if (
        type(engine_policy) is not LocalOcrModelSelectionPolicy
        or engine_policy != policy
        or type(dependencies) is not _RapidOcrDependencies
        or dependencies.dependency_versions != SUPPORTED_DEPENDENCY_VERSIONS
        or type(identity) is not LocalOcrEngineIdentity
        or identity.engine_name != RAPIDOCR_ZH_EN_MODEL.engine_name
        or identity.engine_version != RAPIDOCR_ZH_EN_MODEL.engine_version
        or identity.languages != tuple(sorted(RAPIDOCR_ZH_EN_MODEL.languages))
        or identity.device_class != RAPIDOCR_ZH_EN_MODEL.device_class
    ):
        raise LocalOcrModelSelectionError(_INVALID_ENGINE_IDENTITY)
    if runtime is None:
        return "declared"
    engine_type._verify_cpu_sessions(  # type: ignore[attr-defined]  # noqa: SLF001
        engine, runtime
    )
    return "verified"


def inspect_local_ocr_runtime_capability(
    *,
    model_policy: LocalOcrModelSelectionPolicy | None = None,
    engine: object | None = None,
) -> LocalOcrRuntimeCapability:
    """Return actual-platform capability without model paths or runtime objects."""
    policy = _validated_model_selection_policy(model_policy)
    verification: Literal["declared", "verified"] = "declared"
    if engine is not None:
        verification = _validate_engine_capability(engine, policy)
    try:
        system = _safe_platform_component(platform.system())
        machine = _safe_platform_component(platform.machine())
        version_info = sys.version_info
        python_major = int(version_info.major)
        python_minor = int(version_info.minor)
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except LocalOcrModelSelectionError:
        raise
    except Exception as exc:  # noqa: BLE001 - platform boundary is redacted.
        _raise_redacted_translation(
            exc,
            LocalOcrModelSelectionError(_INVALID_PLATFORM),
        )
    approved = RAPIDOCR_ZH_EN_MODEL
    return LocalOcrRuntimeCapability(
        engine_name=approved.engine_name,
        engine_version=approved.engine_version,
        model_id=approved.model_id,
        language_profile=LocalOcrLanguageProfile.ZH_EN,
        languages=approved.languages,
        device_class="cpu",
        execution_provider="CPUExecutionProvider",
        dependency_versions=SUPPORTED_DEPENDENCY_VERSIONS,
        python_major=python_major,
        python_minor=python_minor,
        platform_system=system,
        platform_machine=machine,
        runtime_verification=verification,
    )

"""Lazy Azure Document Intelligence optional-dependency boundary."""

from importlib import import_module

from document_sdk.core import DependencyNotInstalledError
from document_sdk.core.errors import _raise_redacted_translation

_AZURE_DEPENDENCY_MESSAGE = """Azure Document Intelligence support is not installed.
Install it with:
  pip install "document-processing-sdk[azure-document-intelligence]"
or:
  uv add "document-processing-sdk[azure-document-intelligence]"
"""


def require_azure_document_intelligence_support() -> None:
    """Require the pinned Azure client and identity packages lazily."""
    try:
        import_module("azure.ai.documentintelligence")
        import_module("azure.identity")
    except ImportError as exc:
        _raise_redacted_translation(
            exc,
            DependencyNotInstalledError(_AZURE_DEPENDENCY_MESSAGE),
        )

"""Strict non-secret Azure Document Intelligence configuration."""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import Field, StringConstraints, field_validator

from document_sdk.core.models import CloudExecutionPolicy, SdkModel
from document_sdk.ocr._azure_identity import (
    AZURE_DOCUMENT_INTELLIGENCE_PROVIDER_NAME,
    AZURE_PROVIDER_IDENTITY_VERSION,
    azure_resource_identity,
    normalize_azure_resource_endpoint,
)

type NonEmptyString = Annotated[
    str,
    StringConstraints(strip_whitespace=True, min_length=1),
]


class AzureDocumentIntelligenceConfig(SdkModel):
    """One immutable customer-owned Azure Document Intelligence endpoint."""

    endpoint: str = Field(repr=False)
    model_id: NonEmptyString = "prebuilt-layout"
    api_version: Literal["2024-11-30"] = "2024-11-30"
    polling_timeout_seconds: int = Field(default=120, gt=0, le=3_600)
    max_input_bytes: int = Field(default=50_000_000, gt=0, le=2_000_000_000)
    max_advanced_elements: int = Field(default=20_000, gt=0, le=1_000_000)
    max_field_depth: int = Field(default=20, gt=0, le=100)
    max_field_count: int = Field(default=10_000, gt=0, le=1_000_000)
    max_element_references: int = Field(default=20_000, gt=0, le=1_000_000)
    max_content_characters: int = Field(default=5_000_000, gt=0, le=100_000_000)
    cloud_execution_policy: CloudExecutionPolicy = Field(
        default_factory=CloudExecutionPolicy
    )
    transport_retry_total: Literal[0] = 0
    provider_identity_version: Literal["azure-provider-identity-v2"] = (
        AZURE_PROVIDER_IDENTITY_VERSION
    )

    @property
    def provider_name(self) -> str:
        """Return the stable provider identifier used in safe metadata."""
        return AZURE_DOCUMENT_INTELLIGENCE_PROVIDER_NAME

    @property
    def resource_identity(self) -> str:
        """Return an irreversible identity for the normalized Azure resource."""
        return azure_resource_identity(self.endpoint)

    @field_validator("endpoint")
    @classmethod
    def validate_endpoint(cls, value: str) -> str:
        """Require a root HTTPS endpoint without user data or parameters."""
        return normalize_azure_resource_endpoint(value)

"""Canonical Azure Provider and resource identity primitives."""

from __future__ import annotations

import hashlib
from typing import Final
from urllib.parse import urlsplit

AZURE_DOCUMENT_INTELLIGENCE_PROVIDER_NAME: Final = "azure-document-intelligence"
AZURE_DOCUMENT_INTELLIGENCE_LEGACY_PROVIDER_NAMES = frozenset(
    {"azure_document_intelligence"}
)
AZURE_PROVIDER_IDENTITY_VERSION: Final = "azure-provider-identity-v2"
AZURE_RESOURCE_IDENTITY_VERSION: Final = "azure-resource-identity-v1"
_AZURE_RESOURCE_IDENTITY_DOMAIN = b"document-sdk:azure-resource:v1\0"


def canonical_azure_provider_name(value: str, *, allow_legacy: bool) -> str:
    """Return the one canonical Azure Provider name at a bounded boundary."""
    if value == AZURE_DOCUMENT_INTELLIGENCE_PROVIDER_NAME:
        return value
    if allow_legacy and value in AZURE_DOCUMENT_INTELLIGENCE_LEGACY_PROVIDER_NAMES:
        return AZURE_DOCUMENT_INTELLIGENCE_PROVIDER_NAME
    msg = "Azure Provider identity is invalid"
    raise ValueError(msg)


def normalize_azure_resource_endpoint(value: str) -> str:
    """Normalize one HTTPS resource root without retaining credentials or paths."""
    if type(value) is not str:
        msg = "Azure Document Intelligence endpoint must be a string"
        raise TypeError(msg)
    candidate = value.strip().rstrip("/")
    parsed = urlsplit(candidate)
    if parsed.scheme.casefold() != "https" or not parsed.hostname:
        msg = "Azure Document Intelligence endpoint must use HTTPS"
        raise ValueError(msg)
    if parsed.username or parsed.password:
        msg = "Azure Document Intelligence endpoint must not contain user data"
        raise ValueError(msg)
    if parsed.query or parsed.fragment:
        msg = "Azure Document Intelligence endpoint must not contain parameters"
        raise ValueError(msg)
    if parsed.path:
        msg = "Azure Document Intelligence endpoint must be a resource root"
        raise ValueError(msg)
    try:
        port = parsed.port
    except ValueError:
        msg = "Azure Document Intelligence endpoint port is invalid"
        raise ValueError(msg) from None
    host = parsed.hostname.casefold().rstrip(".")
    if not host:
        msg = "Azure Document Intelligence endpoint host is invalid"
        raise ValueError(msg)
    try:
        host = host.encode("idna").decode("ascii")
    except UnicodeError:
        msg = "Azure Document Intelligence endpoint host is invalid"
        raise ValueError(msg) from None
    authority = f"[{host}]" if ":" in host else host
    if port not in {None, 443}:
        authority = f"{authority}:{port}"
    return f"https://{authority}"


def azure_resource_identity(endpoint: str) -> str:
    """Derive an irreversible domain-separated identity for one Azure resource."""
    normalized = normalize_azure_resource_endpoint(endpoint)
    return hashlib.sha256(
        _AZURE_RESOURCE_IDENTITY_DOMAIN + normalized.encode("ascii")
    ).hexdigest()

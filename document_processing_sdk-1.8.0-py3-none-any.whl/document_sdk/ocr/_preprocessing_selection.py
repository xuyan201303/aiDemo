"""Deterministic intrinsic-quality candidate ranking."""

from __future__ import annotations

from dataclasses import dataclass

from document_sdk.core.local_ocr_quality import (
    LOCAL_OCR_QUALITY_CONFIDENCE_SCALE,
    LocalOcrInputQualityAssessment,
    LocalOcrQualityDecision,
    LocalOcrQualityIssueCode,
)
from document_sdk.ocr.preprocessing_errors import (
    LocalOcrPreprocessingSelectionError,
)
from document_sdk.ocr.preprocessing_models import LocalOcrPreprocessingProfile


@dataclass(frozen=True, slots=True)
class _PreprocessingCandidate:
    """Private candidate with content-free ranking evidence and opaque payload."""

    profile: LocalOcrPreprocessingProfile
    profile_order: int
    assessment: LocalOcrInputQualityAssessment
    payload: object


def _rank(candidate: _PreprocessingCandidate) -> tuple[int, ...]:
    assessment = candidate.assessment
    issues = assessment.issue_codes
    empty = int(LocalOcrQualityIssueCode.EMPTY_RESULT in issues)
    mean_micro = (
        -1
        if assessment.character_count == 0
        else _half_up_ratio(
            assessment.confidence_weighted_character_count,
            assessment.character_count,
            scale=1,
        )
    )
    low_ratio = (
        0
        if assessment.character_count == 0
        else _half_up_ratio(
            assessment.low_confidence_character_count,
            assessment.character_count,
        )
    )
    suspicious_ratio = (
        0
        if assessment.character_count == 0
        else _half_up_ratio(
            assessment.suspicious_character_count,
            assessment.character_count,
        )
    )
    coverage_deficit = _half_up_ratio(
        assessment.region_area_denominator - assessment.region_area_numerator,
        assessment.region_area_denominator,
    )
    return (
        int(assessment.decision is not LocalOcrQualityDecision.PASS),
        len(issues),
        empty,
        -mean_micro,
        low_ratio,
        suspicious_ratio,
        coverage_deficit,
        int(candidate.profile is not LocalOcrPreprocessingProfile.ORIGINAL),
        candidate.profile_order,
    )


def _half_up_ratio(
    numerator: int,
    denominator: int,
    *,
    scale: int = LOCAL_OCR_QUALITY_CONFIDENCE_SCALE,
) -> int:
    """Return a positive fixed-point ratio with exact HALF_UP rounding."""
    if denominator <= 0 or numerator < 0:
        msg = "Local OCR preprocessing quality ratio is invalid"
        raise LocalOcrPreprocessingSelectionError(msg)
    scaled = numerator * scale
    return (scaled + denominator // 2) // denominator


def _select_preprocessing_candidate(
    candidates: tuple[_PreprocessingCandidate, ...],
) -> _PreprocessingCandidate:
    """Select one candidate without OCR text, floats, or unstable ordering."""
    if not candidates:
        msg = "Local OCR preprocessing candidates are unavailable"
        raise LocalOcrPreprocessingSelectionError(msg)
    identities = {
        (item.assessment.source_kind, item.assessment.source_index)
        for item in candidates
    }
    if len(identities) != 1:
        msg = "Local OCR preprocessing candidate sources are inconsistent"
        raise LocalOcrPreprocessingSelectionError(msg)
    ordinals = [item.profile_order for item in candidates]
    profiles = [item.profile for item in candidates]
    if len(set(ordinals)) != len(ordinals) or len(set(profiles)) != len(profiles):
        msg = "Local OCR preprocessing candidates are duplicated"
        raise LocalOcrPreprocessingSelectionError(msg)
    return min(candidates, key=_rank)

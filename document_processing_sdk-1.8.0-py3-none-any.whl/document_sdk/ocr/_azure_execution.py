"""Safe Azure cloud-execution policy and attempt evidence helpers."""

from __future__ import annotations

import inspect
from typing import TYPE_CHECKING

from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.models import (
    CloudCancellationStatus,
    CloudExecutionAttemptEvidence,
    CloudExecutionAttemptStatus,
    ProviderUsage,
)

if TYPE_CHECKING:
    from document_sdk.ocr._azure_models import AzureDocumentIntelligenceConfig
    from document_sdk.ocr._azure_preflight import AzureInputPreflight
    from document_sdk.ocr.models import OcrAnalysisOptions
    from document_sdk.providers import ProviderMetadata

_ATTEMPT_ATTRIBUTE = "cloud_execution_attempt"
_USAGE_ATTRIBUTE = "cloud_provider_usage"


def _validated_completed_cloud_result(
    usage: ProviderUsage,
    evidence: CloudExecutionAttemptEvidence,
) -> tuple[ProviderUsage, CloudExecutionAttemptEvidence]:
    """Rebuild and bind one content-safe completed cloud result projection."""
    if (
        type(usage) is not ProviderUsage
        or type(evidence) is not CloudExecutionAttemptEvidence
    ):
        msg = "Completed cloud execution evidence has an invalid type"
        raise ValueError(msg)
    validated_usage = _revalidate_model_instance_json(
        usage,
        ProviderUsage,
        "Completed cloud Provider usage is invalid",
    )
    validated_evidence = _revalidate_model_instance_json(
        evidence,
        CloudExecutionAttemptEvidence,
        "Completed cloud execution attempt is invalid",
    )
    if (
        validated_evidence.status is not CloudExecutionAttemptStatus.COMPLETED
        or validated_usage.provider_name != validated_evidence.provider_name
        or validated_usage.profile_id != validated_evidence.profile_id
        or validated_usage.model_id != validated_evidence.model_id
        or validated_usage.api_version != validated_evidence.api_version
        or validated_usage.provider_resource_identity
        != validated_evidence.provider_resource_identity
        or validated_usage.submitted_pages != validated_evidence.submitted_pages
        or validated_usage.submitted_frames != validated_evidence.submitted_frames
        or validated_usage.cloud_logical_operation_count
        != validated_evidence.logical_operation_count
        or validated_usage.cloud_submitted_operation_count
        != validated_evidence.submitted_operation_count
        or validated_usage.cloud_paid_or_possibly_paid_operation_count
        != validated_evidence.paid_or_possibly_paid_operation_count
        or validated_usage.cloud_transport_retry_count
        != validated_evidence.transport_retry_count
    ):
        msg = "Completed cloud execution Usage and attempt are inconsistent"
        raise ValueError(msg)
    return validated_usage, validated_evidence


def azure_execution_attempt(  # noqa: PLR0913
    *,
    config: AzureDocumentIntelligenceConfig,
    metadata: ProviderMetadata,
    status: CloudExecutionAttemptStatus,
    preflight: AzureInputPreflight | None = None,
    options: OcrAnalysisOptions | None = None,
    cancellation_status: CloudCancellationStatus = (
        CloudCancellationStatus.NOT_ATTEMPTED
    ),
) -> CloudExecutionAttemptEvidence:
    """Build one content-free attempt projection from trusted Azure inputs."""
    submitted = status in {
        CloudExecutionAttemptStatus.SUBMITTED,
        CloudExecutionAttemptStatus.COMPLETED,
        CloudExecutionAttemptStatus.POSSIBLY_PAID,
    }
    paid_or_possibly_paid = status in {
        CloudExecutionAttemptStatus.COMPLETED,
        CloudExecutionAttemptStatus.POSSIBLY_PAID,
    }
    requested_entire_input = options is None or options.pages is None
    requested_indexes: tuple[int, ...] = (
        () if options is None or options.pages is None else options.pages
    )
    submitted_indexes: tuple[int, ...] = ()
    if submitted and preflight is not None:
        submitted_indexes = (
            tuple(range(1, preflight.page_count + 1))
            if requested_entire_input
            else requested_indexes
        )
    requested_pages = (
        requested_indexes if preflight is None or preflight.source_kind == "pdf" else ()
    )
    requested_frames = (
        requested_indexes
        if preflight is not None and preflight.source_kind == "image"
        else ()
    )
    return CloudExecutionAttemptEvidence(
        evidence_version="cloud-execution-attempt-v3",
        provider_name=metadata.provider_name,
        profile_id=metadata.profile_id,
        model_id=metadata.model_id,
        api_version=config.api_version,
        provider_resource_identity=config.resource_identity,
        policy_fingerprint=config.cloud_execution_policy.fingerprint(),
        status=status,
        submitted_operation_count=int(submitted),
        paid_or_possibly_paid_operation_count=int(paid_or_possibly_paid),
        requested_entire_input=requested_entire_input,
        requested_pages=requested_pages,
        requested_frames=requested_frames,
        submitted_pages=(
            submitted_indexes
            if submitted and preflight is not None and preflight.source_kind == "pdf"
            else ()
        ),
        submitted_frames=(
            submitted_indexes
            if submitted and preflight is not None and preflight.source_kind == "image"
            else ()
        ),
        input_bytes=0 if preflight is None else preflight.descriptor.size_bytes,
        cancellation_status=cancellation_status,
    )


def attach_cloud_execution_attempt(
    error: BaseException,
    evidence: CloudExecutionAttemptEvidence,
) -> None:
    """Attach SDK-owned content-free evidence to one typed failure."""
    object.__setattr__(error, _ATTEMPT_ATTRIBUTE, evidence)


def attach_completed_cloud_result(
    error: BaseException,
    usage: ProviderUsage,
    evidence: CloudExecutionAttemptEvidence,
) -> None:
    """Attach a validated content-safe completed cloud result to one failure."""
    validated_usage, validated_evidence = _validated_completed_cloud_result(
        usage,
        evidence,
    )
    object.__setattr__(error, _USAGE_ATTRIBUTE, validated_usage)
    object.__setattr__(error, _ATTEMPT_ATTRIBUTE, validated_evidence)


def read_cloud_execution_attempt(
    error: BaseException,
) -> CloudExecutionAttemptEvidence | None:
    """Read only an exact SDK evidence instance stored on an exception."""
    sentinel = object()
    try:
        static_value = inspect.getattr_static(error, _ATTEMPT_ATTRIBUTE, sentinel)
        storage = object.__getattribute__(error, "__dict__")
    except Exception:  # noqa: BLE001 - exception objects are untrusted boundaries.
        return None
    if (
        type(storage) is not dict
        or static_value is sentinel
        or storage.get(_ATTEMPT_ATTRIBUTE, sentinel) is not static_value
        or type(static_value) is not CloudExecutionAttemptEvidence
    ):
        return None
    try:
        return _revalidate_model_instance_json(
            static_value,
            CloudExecutionAttemptEvidence,
            "Cloud execution attempt evidence is invalid",
        )
    except Exception:  # noqa: BLE001 - invalid evidence is ignored safely.
        return None


def read_completed_cloud_result(
    error: BaseException,
) -> tuple[ProviderUsage, CloudExecutionAttemptEvidence] | None:
    """Recover only an exact SDK-owned completed Usage/attempt pair."""
    sentinel = object()
    try:
        static_usage = inspect.getattr_static(error, _USAGE_ATTRIBUTE, sentinel)
        static_attempt = inspect.getattr_static(error, _ATTEMPT_ATTRIBUTE, sentinel)
        storage = object.__getattribute__(error, "__dict__")
    except Exception:  # noqa: BLE001 - exception objects are untrusted boundaries.
        return None
    if (
        type(storage) is not dict
        or static_usage is sentinel
        or static_attempt is sentinel
        or storage.get(_USAGE_ATTRIBUTE, sentinel) is not static_usage
        or storage.get(_ATTEMPT_ATTRIBUTE, sentinel) is not static_attempt
        or type(static_usage) is not ProviderUsage
        or type(static_attempt) is not CloudExecutionAttemptEvidence
    ):
        return None
    try:
        return _validated_completed_cloud_result(static_usage, static_attempt)
    except Exception:  # noqa: BLE001 - invalid evidence is ignored safely.
        return None

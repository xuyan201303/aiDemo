"""Strict content-free models for explicit Azure page-level fallback."""

# ruff: noqa: C901, EM101, PLR0912, TRY003

from __future__ import annotations

import hashlib
import ipaddress
import json
import re
from enum import StrEnum
from typing import Annotated, Literal, Self, cast

from pydantic import Field, field_validator, model_validator

from document_sdk.core import (
    CloudExecutionAttemptEvidence,
    CloudExecutionAttemptStatus,
    Document,
    ImageSourceReference,
    LocalOcrQualityDecision,
    LocalOcrQualityIssueCode,
    LocalOcrQualitySummary,
    PdfSourceReference,
    ProviderUsage,
)
from document_sdk.core._metadata import _is_sensitive_metadata_key
from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.models import SdkModel
from document_sdk.ocr._azure_identity import (
    AZURE_DOCUMENT_INTELLIGENCE_PROVIDER_NAME,
    AZURE_PROVIDER_IDENTITY_VERSION,
    canonical_azure_provider_name,
)
from document_sdk.ocr.models import DocumentAnalysisFeature, OcrAnalysisOptions

AZURE_PAGE_FALLBACK_ALGORITHM_VERSION = "azure-page-fallback-v1"
AZURE_FALLBACK_PAYLOAD_POLICY_VERSION = "isolated-png-v1"

_Count = Annotated[int, Field(strict=True, ge=0, le=10_000)]
_Bytes = Annotated[int, Field(strict=True, ge=0, le=1_000_000_000)]
_SAFE_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")
_URI_SCHEME = re.compile(r"^[A-Za-z][A-Za-z0-9+.-]*:")
_DNS_LABEL = r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?"
_DNS_A_LABEL_TLD = r"xn--[A-Za-z0-9](?:[A-Za-z0-9-]{0,57}[A-Za-z0-9])?"
_HOST_NAME = re.compile(
    rf"^(?:{_DNS_LABEL}\.)+(?:[A-Za-z]{{2,63}}|{_DNS_A_LABEL_TLD})$",
    re.IGNORECASE,
)
_MODEL_NAMESPACE = "model:"
_LOOPBACK_HOST_NAMES = frozenset(
    {"localhost", "localhost.localdomain", "ip6-localhost"}
)
_UNSAFE_ID_PARTS = (
    "accesskey",
    "apikey",
    "bearer",
    "credential",
    "password",
    "secret",
    "token",
)
_CONTROL_CHARACTER_LIMIT = 32
_DELETE_CHARACTER = 127
_IPV4_PART_COUNT = 4
_IPV4_MAX_OCTET = 255
_INTRINSIC_QUALITY_ISSUES = frozenset(
    {
        LocalOcrQualityIssueCode.EMPTY_RESULT,
        LocalOcrQualityIssueCode.INSUFFICIENT_TEXT,
        LocalOcrQualityIssueCode.LOW_CONFIDENCE,
        LocalOcrQualityIssueCode.EXCESSIVE_LOW_CONFIDENCE_TEXT,
        LocalOcrQualityIssueCode.GARBLED_TEXT,
        LocalOcrQualityIssueCode.INSUFFICIENT_REGION_COVERAGE,
    }
)


def _intrinsic_quality_lineage(summary: LocalOcrQualitySummary) -> tuple[object, ...]:
    """Project only evidence that a structured recheck cannot recompute."""
    return (
        summary.algorithm_version,
        summary.policy_fingerprint,
        summary.evaluated_input_count,
        summary.passed_input_count,
        summary.failed_input_count,
        summary.evaluated_pages,
        summary.evaluated_frames,
        summary.failed_pages,
        summary.failed_frames,
        summary.character_count,
        summary.region_count,
        summary.confidence_weighted_character_count,
        summary.low_confidence_character_count,
        summary.suspicious_character_count,
        summary.region_area_numerator,
        summary.region_area_denominator,
        tuple(
            count
            for count in summary.issue_counts_by_code
            if count.code in _INTRINSIC_QUALITY_ISSUES
        ),
    )


def _is_ip_address(value: str) -> bool:
    """Return whether one already-bounded identifier is an IP address."""
    try:
        ipaddress.ip_address(value)
    except ValueError:
        return False
    return True


def _looks_like_numeric_ipv4(value: str) -> bool:
    """Detect bounded dotted-decimal IPv4 shapes, including leading zeroes."""
    parts = value.split(".")
    return len(parts) == _IPV4_PART_COUNT and all(
        part.isascii() and part.isdecimal() and 0 <= int(part) <= _IPV4_MAX_OCTET
        for part in parts
    )


def _looks_like_host_or_endpoint(value: str) -> bool:
    """Reject host-shaped identities without treating opaque versions as hosts."""

    def is_host(candidate: str) -> bool:
        candidate = candidate.rstrip(".")
        return bool(
            candidate.casefold() in _LOOPBACK_HOST_NAMES
            or _is_ip_address(candidate)
            or _looks_like_numeric_ipv4(candidate)
            or _HOST_NAME.fullmatch(candidate)
        )

    normalized = value.rstrip(".")
    if is_host(normalized):
        return True
    parts = normalized.split(":")
    for start_index, first_part in enumerate(parts):
        candidate = first_part
        if candidate and is_host(candidate):
            return True
        for part in parts[start_index + 1 :]:
            candidate = f"{candidate}:{part}"
            if candidate and is_host(candidate):
                return True
    return False


def _has_unsafe_colon_suffix(value: str) -> bool:
    """Reject unsafe host, URI, or nested-model shapes after any colon."""
    if ":" not in value:
        return False
    if _looks_like_host_or_endpoint(value):
        return True
    for index, character in enumerate(value):
        if character != ":":
            continue
        suffix = value[index + 1 :]
        if suffix and (
            _URI_SCHEME.match(suffix) or suffix.casefold().startswith(_MODEL_NAMESPACE)
        ):
            return True
    return False


def _has_unsafe_model_namespace(value: str) -> bool:
    """Validate one case-insensitive model namespace and its opaque suffix."""
    if not value.casefold().startswith(_MODEL_NAMESPACE):
        return False
    suffix = value[len(_MODEL_NAMESPACE) :]
    lowered = suffix.casefold()
    normalized = re.sub(r"[^a-z0-9]", "", lowered)
    return bool(
        not suffix
        or not _SAFE_ID.fullmatch(suffix)
        or normalized.startswith("sk")
        or any(part in normalized for part in _UNSAFE_ID_PARTS)
        or _is_sensitive_metadata_key(suffix)
        or _URI_SCHEME.match(suffix)
        or _has_unsafe_colon_suffix(suffix)
        or _looks_like_host_or_endpoint(suffix)
        or "=" in suffix
        or "/" in suffix
        or "\\" in suffix
        or "://" in suffix
    )


def _validate_structured_recheck_lineage(
    trigger: LocalOcrQualitySummary,
    final: LocalOcrQualitySummary,
) -> None:
    """Require a structured-only recheck to retain all intrinsic evidence."""
    if _intrinsic_quality_lineage(trigger) != _intrinsic_quality_lineage(final):
        raise ValueError("Structured fallback recheck intrinsic lineage changed")


def _validate_quality_family_lineage(
    summary: LocalOcrQualitySummary,
    *,
    input_pages: tuple[int, ...],
    input_frames: tuple[int, ...],
) -> None:
    """Bind quality indexes to the report's one exact input family and range."""
    page_evidence = (
        summary.evaluated_pages,
        summary.failed_pages,
        summary.recommended_retry_pages,
    )
    frame_evidence = (
        summary.evaluated_frames,
        summary.failed_frames,
        summary.recommended_retry_frames,
    )
    if summary.decision is LocalOcrQualityDecision.NOT_APPLICABLE and any(
        (*page_evidence, *frame_evidence)
    ):
        raise ValueError("Not-applicable fallback quality contains input evidence")
    if input_pages:
        if any(frame_evidence) or not (
            set(summary.evaluated_pages).issubset(input_pages)
            and set(summary.failed_pages).issubset(summary.evaluated_pages)
            and set(summary.recommended_retry_pages).issubset(summary.evaluated_pages)
        ):
            raise ValueError("Fallback page quality lineage is inconsistent")
        return
    if any(page_evidence) or not (
        set(summary.evaluated_frames).issubset(input_frames)
        and set(summary.failed_frames).issubset(summary.evaluated_frames)
        and set(summary.recommended_retry_frames).issubset(summary.evaluated_frames)
    ):
        raise ValueError("Fallback frame quality lineage is inconsistent")


def _validate_attempt_quality_family(
    summary: LocalOcrQualitySummary,
    *,
    source_kind: Literal["page", "frame"],
) -> None:
    """Bind partial Attempt evidence to one non-empty retry input family."""
    page_quality = (
        summary.evaluated_pages,
        summary.failed_pages,
        summary.recommended_retry_pages,
    )
    frame_quality = (
        summary.evaluated_frames,
        summary.failed_frames,
        summary.recommended_retry_frames,
    )
    if source_kind == "page":
        valid = not any(frame_quality) and bool(
            summary.evaluated_pages and summary.recommended_retry_pages
        )
    else:
        valid = not any(page_quality) and bool(
            summary.evaluated_frames and summary.recommended_retry_frames
        )
    if not valid:
        raise ValueError("Fallback attempt quality source family is invalid")


class AzurePageFallbackStatus(StrEnum):
    """Successful Azure fallback outcomes."""

    NOT_APPLICABLE = "not_applicable"
    COMPLETED = "completed"
    COMPLETED_UNRESOLVED_STRUCTURED = "completed_unresolved_structured"


class AzureFallbackProviderIdentity(SdkModel):
    """Safe immutable identity expected from the explicit Azure Provider."""

    provider_name: Literal["azure-document-intelligence"] = (
        AZURE_DOCUMENT_INTELLIGENCE_PROVIDER_NAME
    )
    profile_id: str = Field(min_length=1, max_length=128)
    model_id: str | None = Field(default=None, min_length=1, max_length=128)
    api_version: str = Field(min_length=1, max_length=128)
    provider_resource_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    identity_version: Literal["azure-provider-identity-v2"] = (
        AZURE_PROVIDER_IDENTITY_VERSION
    )

    @field_validator("provider_name", mode="before")
    @classmethod
    def _canonical_provider_name(cls, value: object) -> object:
        """Accept only the canonical name or the one bounded legacy alias."""
        if type(value) is not str:
            return value
        return canonical_azure_provider_name(value, allow_legacy=True)

    @field_validator("profile_id", "model_id", "api_version")
    @classmethod
    def _safe_identifier(cls, value: str | None) -> str | None:
        if value is None:
            return None
        lowered = value.casefold()
        normalized = re.sub(r"[^a-z0-9]", "", lowered)
        if (
            not _SAFE_ID.fullmatch(value)
            or normalized.startswith("sk")
            or any(part in normalized for part in _UNSAFE_ID_PARTS)
            or _is_sensitive_metadata_key(value)
            or (_URI_SCHEME.match(value) and not lowered.startswith(_MODEL_NAMESPACE))
            or _has_unsafe_colon_suffix(value)
            or _has_unsafe_model_namespace(value)
            or _looks_like_host_or_endpoint(value)
            or "=" in value
            or "/" in value
            or "\\" in value
            or "://" in value
            or any(
                ord(character) < _CONTROL_CHARACTER_LIMIT
                or ord(character) == _DELETE_CHARACTER
                for character in value
            )
        ):
            raise ValueError("Azure fallback Provider identity is unsafe")
        return value


class AzurePageFallbackPolicy(SdkModel):
    """Explicit bounded opt-in policy for isolated Azure fallback inputs."""

    expected_provider_identity: AzureFallbackProviderIdentity
    max_fallback_pages_per_document: _Count = 25
    max_fallback_frames_per_document: _Count = 25
    max_fallback_inputs_per_document: _Count = 25
    max_fallback_operations_per_document: _Count = 25
    max_payload_bytes_per_input: _Bytes = 20_000_000
    max_payload_bytes_per_document: _Bytes = 100_000_000
    pdf_render_dpi: Annotated[int, Field(strict=True, ge=72, le=300)] = 144
    azure_options: OcrAnalysisOptions = Field(default_factory=OcrAnalysisOptions)
    algorithm_version: Literal["azure-page-fallback-v1"] = "azure-page-fallback-v1"
    payload_policy_version: Literal["isolated-png-v1"] = "isolated-png-v1"

    @model_validator(mode="after")
    def _consistent_limits(self) -> Self:
        identity = _validate_azure_fallback_provider_identity(
            self.expected_provider_identity
        )
        options = _revalidate_model_instance_json(
            self.azure_options,
            OcrAnalysisOptions,
            "Azure fallback options are invalid",
        )
        object.__setattr__(self, "expected_provider_identity", identity)
        object.__setattr__(self, "azure_options", options)
        if self.max_fallback_inputs_per_document > (
            self.max_fallback_pages_per_document + self.max_fallback_frames_per_document
        ):
            raise ValueError("Fallback input limit exceeds page and frame limits")
        if self.max_fallback_operations_per_document < (
            self.max_fallback_inputs_per_document
        ):
            raise ValueError("Fallback operation limit is below the input limit")
        if self.max_payload_bytes_per_document < self.max_payload_bytes_per_input:
            raise ValueError("Fallback document payload limit is below input limit")
        if options.pages is not None:
            raise ValueError("Fallback Azure options cannot select payload pages")
        return self

    def fingerprint(self) -> str:
        """Return the canonical Resume identity without runtime outcomes."""
        normalized = _validate_azure_fallback_policy(self)
        return hashlib.sha256(
            json.dumps(
                normalized.model_dump(mode="json"),
                sort_keys=True,
                separators=(",", ":"),
            ).encode()
        ).hexdigest()


class AzurePageFallbackReport(SdkModel):
    """Content-free evidence for one completed explicit fallback attempt."""

    status: AzurePageFallbackStatus
    trigger_quality_summary: LocalOcrQualitySummary
    policy_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    payload_policy_version: Literal["isolated-png-v1"] = "isolated-png-v1"
    requested_features: tuple[DocumentAnalysisFeature, ...] = Field(
        default=(), max_length=len(DocumentAnalysisFeature)
    )
    query_field_count: _Count = 0
    input_pages: tuple[int, ...] = Field(default=(), max_length=10_000)
    input_frames: tuple[int, ...] = Field(default=(), max_length=10_000)
    submitted_pages: tuple[int, ...] = Field(default=(), max_length=10_000)
    submitted_frames: tuple[int, ...] = Field(default=(), max_length=10_000)
    replaced_pages: tuple[int, ...] = Field(default=(), max_length=10_000)
    replaced_frames: tuple[int, ...] = Field(default=(), max_length=10_000)
    reason_codes: tuple[LocalOcrQualityIssueCode, ...] = Field(
        default=(), max_length=len(LocalOcrQualityIssueCode)
    )
    provider_invocation_count: _Count = 0
    azure_operation_count: _Count = 0
    paid_page_count: _Count = 0
    paid_frame_count: _Count = 0
    payload_count: _Count = 0
    payload_byte_count: _Bytes = 0
    structured_recheck_performed: bool = False
    structured_recheck_resolved: bool | None = None
    structured_recheck_summary: LocalOcrQualitySummary | None = None
    algorithm_version: Literal["azure-page-fallback-v1"] = "azure-page-fallback-v1"
    provider_identity_summary: AzureFallbackProviderIdentity | None = None

    @model_validator(mode="after")
    def _consistent_report(self) -> Self:
        summary = _revalidate_model_instance_json(
            self.trigger_quality_summary,
            LocalOcrQualitySummary,
            "Azure fallback trigger summary is invalid",
        )
        object.__setattr__(self, "trigger_quality_summary", summary)
        if self.provider_identity_summary is not None:
            object.__setattr__(
                self,
                "provider_identity_summary",
                _validate_azure_fallback_provider_identity(
                    self.provider_identity_summary
                ),
            )
        if tuple(sorted(set(self.requested_features), key=lambda item: item.value)) != (
            self.requested_features
        ):
            raise ValueError("Fallback requested features are not canonical")
        for name in (
            "submitted_pages",
            "submitted_frames",
            "replaced_pages",
            "replaced_frames",
            "input_pages",
            "input_frames",
        ):
            values = getattr(self, name)
            if any(type(value) is not int or value < 1 for value in values):
                raise ValueError("Fallback indexes must be positive integers")
            if tuple(sorted(set(values))) != values:
                raise ValueError("Fallback indexes must be unique and sorted")
        if self.submitted_pages and self.submitted_frames:
            raise ValueError("Fallback report cannot mix pages and frames")
        if self.input_pages and self.input_frames:
            raise ValueError("Fallback report cannot mix input families")
        if (
            (not self.input_pages and not self.input_frames)
            or (
                self.submitted_pages
                and not set(self.submitted_pages).issubset(self.input_pages)
            )
            or (
                self.submitted_frames
                and not set(self.submitted_frames).issubset(self.input_frames)
            )
        ):
            raise ValueError("Fallback report input coverage is inconsistent")
        _validate_quality_family_lineage(
            summary,
            input_pages=self.input_pages,
            input_frames=self.input_frames,
        )
        if self.replaced_pages != self.submitted_pages:
            raise ValueError("Replaced pages must match submitted pages")
        if self.replaced_frames != self.submitted_frames:
            raise ValueError("Replaced frames must match submitted frames")
        inputs = len(self.submitted_pages) + len(self.submitted_frames)
        if (self.payload_count == 0 and self.payload_byte_count != 0) or (
            self.payload_count > 0 and self.payload_byte_count < self.payload_count
        ):
            raise ValueError("Fallback payload byte cardinality is inconsistent")
        expected_candidates = (
            summary.recommended_retry_pages
            if self.submitted_pages
            else summary.recommended_retry_frames
        )
        if self.status is AzurePageFallbackStatus.NOT_APPLICABLE:
            if (
                summary.decision is LocalOcrQualityDecision.FAIL
                or inputs
                or self.replaced_pages
                or self.replaced_frames
                or self.reason_codes
                or self.provider_invocation_count
                or self.azure_operation_count
                or self.paid_page_count
                or self.paid_frame_count
                or self.payload_count
                or self.payload_byte_count
                or self.provider_identity_summary is not None
                or self.structured_recheck_performed
                or self.structured_recheck_resolved is not None
                or self.structured_recheck_summary is not None
            ):
                raise ValueError("Not-applicable fallback contains attempt evidence")
            return self
        if (
            summary.decision is not LocalOcrQualityDecision.FAIL
            or not inputs
            or (self.submitted_pages or self.submitted_frames) != expected_candidates
            or self.reason_codes != summary.reason_codes
            or self.provider_invocation_count != inputs
            or self.azure_operation_count != inputs
            or self.payload_count != inputs
            or self.payload_byte_count < self.payload_count
            or self.provider_identity_summary is None
            or self.paid_page_count != len(self.submitted_pages)
            or self.paid_frame_count != len(self.submitted_frames)
        ):
            raise ValueError("Completed fallback cardinality is inconsistent")
        if not self.structured_recheck_performed:
            if (
                self.status is not AzurePageFallbackStatus.COMPLETED
                or self.structured_recheck_resolved is not None
                or self.structured_recheck_summary is not None
            ):
                raise ValueError("Fallback structured status is inconsistent")
        else:
            if self.structured_recheck_summary is None:
                raise ValueError("Structured fallback recheck evidence is incomplete")
            final_summary = _revalidate_model_instance_json(
                self.structured_recheck_summary,
                LocalOcrQualitySummary,
                "Azure fallback structured recheck summary is invalid",
            )
            object.__setattr__(self, "structured_recheck_summary", final_summary)
            _validate_structured_recheck_lineage(summary, final_summary)
            _validate_quality_family_lineage(
                final_summary,
                input_pages=self.input_pages,
                input_frames=self.input_frames,
            )
            unresolved = bool(
                {
                    LocalOcrQualityIssueCode.REQUIRED_FIELDS_MISSING,
                    LocalOcrQualityIssueCode.TABLE_INCOMPLETE,
                }.intersection(final_summary.reason_codes)
            )
            if self.structured_recheck_resolved is not (not unresolved):
                raise ValueError("Structured fallback resolution is inconsistent")
            expected_status = (
                AzurePageFallbackStatus.COMPLETED_UNRESOLVED_STRUCTURED
                if unresolved
                else AzurePageFallbackStatus.COMPLETED
            )
            if self.status is not expected_status:
                raise ValueError("Structured fallback status is inconsistent")
        return self


class AzurePageFallbackResult(SdkModel):
    """Merged document with separate content-free Azure usage evidence."""

    document: Document
    policy: AzurePageFallbackPolicy
    report: AzurePageFallbackReport
    azure_provider_usage: tuple[ProviderUsage, ...] = Field(
        default=(), max_length=10_000
    )
    cloud_execution_attempts: tuple[CloudExecutionAttemptEvidence, ...] = Field(
        default=(), max_length=10_000
    )

    @model_validator(mode="after")
    def _consistent_usage(self) -> Self:
        policy = _validate_azure_fallback_policy(self.policy)
        object.__setattr__(self, "policy", policy)
        document = _revalidate_model_instance_json(
            self.document,
            Document,
            "Azure fallback document is invalid",
        )
        usages = tuple(
            _revalidate_model_instance_json(
                usage,
                ProviderUsage,
                "Azure fallback Provider usage is invalid",
            )
            for usage in self.azure_provider_usage
        )
        cloud_attempts = tuple(
            _revalidate_model_instance_json(
                attempt,
                CloudExecutionAttemptEvidence,
                "Azure fallback cloud execution attempt is invalid",
            )
            for attempt in self.cloud_execution_attempts
        )
        object.__setattr__(self, "document", document)
        object.__setattr__(self, "azure_provider_usage", usages)
        object.__setattr__(self, "cloud_execution_attempts", cloud_attempts)
        report = _validate_azure_fallback_report(self.report)
        object.__setattr__(self, "report", report)
        identity = report.provider_identity_summary
        if (
            report.policy_fingerprint != policy.fingerprint()
            or report.payload_policy_version != policy.payload_policy_version
            or report.requested_features != policy.azure_options.features
            or report.query_field_count != len(policy.azure_options.query_fields)
            or (identity is not None and identity != policy.expected_provider_identity)
        ):
            raise ValueError("Fallback result policy evidence is inconsistent")
        page_count = len(report.submitted_pages)
        frame_count = len(report.submitted_frames)
        input_count = page_count + frame_count
        if (
            page_count > policy.max_fallback_pages_per_document
            or frame_count > policy.max_fallback_frames_per_document
            or input_count > policy.max_fallback_inputs_per_document
            or report.provider_invocation_count
            > policy.max_fallback_operations_per_document
            or report.azure_operation_count
            > policy.max_fallback_operations_per_document
            or report.payload_count > policy.max_fallback_operations_per_document
            or report.payload_byte_count > policy.max_payload_bytes_per_document
            or (
                report.payload_count > 0
                and report.payload_byte_count
                > report.payload_count * policy.max_payload_bytes_per_input
            )
        ):
            raise ValueError("Fallback result exceeds its policy limits")
        indexes = report.submitted_pages or report.submitted_frames
        if len(usages) != report.azure_operation_count:
            raise ValueError("Fallback result usage count is inconsistent")
        if len(cloud_attempts) != len(usages):
            raise ValueError("Fallback result cloud attempt count is inconsistent")
        for usage, index in zip(usages, indexes, strict=True):
            expected_pages = (index,) if report.submitted_pages else ()
            expected_frames = (index,) if report.submitted_frames else ()
            if (
                identity is None
                or usage.provider_name != identity.provider_name
                or usage.profile_id != identity.profile_id
                or usage.model_id != identity.model_id
                or usage.api_version != identity.api_version
                or usage.provider_resource_identity
                != identity.provider_resource_identity
                or usage.submitted_pages != expected_pages
                or usage.returned_pages != expected_pages
                or usage.submitted_frames != expected_frames
                or usage.returned_frames != expected_frames
                or usage.requested_features
                != tuple(feature.value for feature in report.requested_features)
                or usage.query_field_count != report.query_field_count
                or usage.local_operation_count
                or usage.azure_operation_count != 1
                or usage.paid_operation_count != 1
            ):
                raise ValueError("Fallback result contains invalid Azure usage")
        for attempt, index in zip(cloud_attempts, indexes, strict=True):
            expected_pages = (index,) if report.submitted_pages else ()
            expected_frames = (index,) if report.submitted_frames else ()
            if (
                identity is None
                or attempt.status is not CloudExecutionAttemptStatus.COMPLETED
                or attempt.provider_name != identity.provider_name
                or attempt.profile_id != identity.profile_id
                or attempt.model_id != identity.model_id
                or attempt.api_version != identity.api_version
                or attempt.provider_resource_identity
                != identity.provider_resource_identity
                or attempt.requested_entire_input
                or attempt.requested_pages != expected_pages
                or attempt.requested_frames != expected_frames
                or attempt.submitted_pages != expected_pages
                or attempt.submitted_frames != expected_frames
            ):
                raise ValueError("Fallback result contains invalid cloud attempt")
        if sum(attempt.input_bytes for attempt in cloud_attempts) != (
            report.payload_byte_count
        ):
            raise ValueError("Fallback result cloud payload bytes are inconsistent")
        expected_indexes = report.input_pages or report.input_frames
        document_indexes: list[int] = []
        for page in document.pages:
            source = page.source
            if report.input_pages:
                if not _is_actual_source_reference(source, PdfSourceReference):
                    raise ValueError("Fallback result source family is inconsistent")
                source_index = cast("PdfSourceReference", source).page_number
            else:
                if not _is_actual_source_reference(source, ImageSourceReference):
                    raise ValueError("Fallback result source family is inconsistent")
                source_index = cast("ImageSourceReference", source).frame_number
            if page.page_number != source_index:
                raise ValueError("Fallback result source index is inconsistent")
            document_indexes.append(source_index)
        if tuple(document_indexes) != expected_indexes:
            raise ValueError("Fallback result input coverage is inconsistent")
        return self


class AzureFallbackAttemptEvidence(SdkModel):
    """Safe partial evidence retained when fallback does not complete."""

    source_kind: Literal["page", "frame"]
    provider_invocation_count: _Count = 0
    trigger_quality_summary: LocalOcrQualitySummary
    provider_identity_summary: AzureFallbackProviderIdentity
    requested_features: tuple[DocumentAnalysisFeature, ...] = Field(
        default=(), max_length=len(DocumentAnalysisFeature)
    )
    query_field_count: _Count = 0
    completed_azure_usages: tuple[ProviderUsage, ...] = Field(
        default=(), max_length=10_000
    )
    current_attempt_usage: ProviderUsage | None = None
    completed_cloud_execution_attempts: tuple[CloudExecutionAttemptEvidence, ...] = (
        Field(default=(), max_length=10_000)
    )
    current_cloud_execution_attempt: CloudExecutionAttemptEvidence | None = None
    prepared_pages: tuple[int, ...] = Field(default=(), max_length=10_000)
    prepared_frames: tuple[int, ...] = Field(default=(), max_length=10_000)
    invoked_pages: tuple[int, ...] = Field(default=(), max_length=10_000)
    invoked_frames: tuple[int, ...] = Field(default=(), max_length=10_000)
    prepared_payload_byte_counts: tuple[_Bytes, ...] = Field(
        default=(), max_length=10_000
    )
    payload_count: _Count = 0
    payload_byte_count: _Bytes = 0

    @model_validator(mode="after")
    def _consistent_attempt(self) -> Self:  # noqa: PLR0915
        object.__setattr__(
            self,
            "trigger_quality_summary",
            _revalidate_model_instance_json(
                self.trigger_quality_summary,
                LocalOcrQualitySummary,
                "Azure fallback attempt trigger summary is invalid",
            ),
        )
        completed = tuple(
            _revalidate_model_instance_json(
                usage,
                ProviderUsage,
                "Azure fallback completed usage is invalid",
            )
            for usage in self.completed_azure_usages
        )
        current = (
            None
            if self.current_attempt_usage is None
            else _revalidate_model_instance_json(
                self.current_attempt_usage,
                ProviderUsage,
                "Azure fallback current usage is invalid",
            )
        )
        completed_cloud = tuple(
            _revalidate_model_instance_json(
                attempt,
                CloudExecutionAttemptEvidence,
                "Azure fallback completed cloud attempt is invalid",
            )
            for attempt in self.completed_cloud_execution_attempts
        )
        current_cloud = (
            None
            if self.current_cloud_execution_attempt is None
            else _revalidate_model_instance_json(
                self.current_cloud_execution_attempt,
                CloudExecutionAttemptEvidence,
                "Azure fallback current cloud attempt is invalid",
            )
        )
        object.__setattr__(self, "completed_azure_usages", completed)
        object.__setattr__(self, "current_attempt_usage", current)
        object.__setattr__(self, "completed_cloud_execution_attempts", completed_cloud)
        object.__setattr__(self, "current_cloud_execution_attempt", current_cloud)
        identity = _validate_azure_fallback_provider_identity(
            self.provider_identity_summary
        )
        object.__setattr__(self, "provider_identity_summary", identity)
        if tuple(sorted(set(self.requested_features), key=lambda item: item.value)) != (
            self.requested_features
        ):
            raise ValueError("Fallback attempt features are not canonical")
        if self.trigger_quality_summary.decision is not LocalOcrQualityDecision.FAIL:
            raise ValueError("Fallback attempt requires a failing quality decision")
        _validate_attempt_quality_family(
            self.trigger_quality_summary,
            source_kind=self.source_kind,
        )
        if (
            self.source_kind == "page" and (self.prepared_frames or self.invoked_frames)
        ) or (
            self.source_kind == "frame" and (self.prepared_pages or self.invoked_pages)
        ):
            raise ValueError("Fallback attempt cannot mix source families")
        prepared = (
            self.prepared_pages if self.source_kind == "page" else self.prepared_frames
        )
        invoked = (
            self.invoked_pages if self.source_kind == "page" else self.invoked_frames
        )
        candidates = (
            self.trigger_quality_summary.recommended_retry_pages
            if self.source_kind == "page"
            else self.trigger_quality_summary.recommended_retry_frames
        )
        for indexes in (prepared, invoked):
            if tuple(sorted(set(indexes))) != indexes or any(
                type(index) is not int or index < 1 for index in indexes
            ):
                raise ValueError("Fallback attempt indexes are invalid")
        if prepared != candidates[: len(prepared)]:
            raise ValueError("Prepared fallback indexes are not a candidate prefix")
        if invoked != prepared[: len(invoked)]:
            raise ValueError("Invoked fallback indexes are not a prepared prefix")
        if len(prepared) - len(invoked) not in (0, 1):
            raise ValueError("Fallback attempt prepared sequence has a gap")
        if self.provider_invocation_count != len(invoked):
            raise ValueError("Fallback attempt invocation evidence is inconsistent")
        if self.payload_count != len(prepared):
            raise ValueError("Fallback attempt payload evidence is inconsistent")
        if (
            len(self.prepared_payload_byte_counts) != len(prepared)
            or any(size < 1 for size in self.prepared_payload_byte_counts)
            or sum(self.prepared_payload_byte_counts) != self.payload_byte_count
        ):
            raise ValueError("Fallback attempt payload bytes are inconsistent")
        if not 0 <= len(prepared) - len(completed) <= 1:
            raise ValueError("Fallback attempt completion sequence is invalid")
        confirmed_usage_count = len(completed) + (current is not None)
        if not 0 <= len(invoked) - confirmed_usage_count <= 1:
            raise ValueError("Fallback attempt confirmed usage sequence is invalid")
        if current is not None and (not invoked or len(completed) != len(invoked) - 1):
            raise ValueError("Fallback current usage does not match its invocation")
        if current is None and len(completed) not in {
            len(invoked),
            len(invoked) - 1,
        }:
            raise ValueError("Fallback completed usage sequence is invalid")
        usages = completed + (() if current is None else (current,))
        usage_indexes = invoked[: len(usages)]
        for usage, index in zip(usages, usage_indexes, strict=True):
            expected_pages = (index,) if self.source_kind == "page" else ()
            expected_frames = (index,) if self.source_kind == "frame" else ()
            if (
                usage.provider_name != identity.provider_name
                or usage.profile_id != identity.profile_id
                or usage.model_id != identity.model_id
                or usage.api_version != identity.api_version
                or usage.provider_resource_identity
                != identity.provider_resource_identity
                or usage.submitted_pages != expected_pages
                or usage.returned_pages != expected_pages
                or usage.submitted_frames != expected_frames
                or usage.returned_frames != expected_frames
                or usage.requested_features
                != tuple(feature.value for feature in self.requested_features)
                or usage.query_field_count != self.query_field_count
                or usage.local_operation_count
                or usage.azure_operation_count != 1
                or usage.paid_operation_count != 1
            ):
                raise ValueError("Fallback attempt contains invalid confirmed usage")
        if any(usage.cloud_logical_operation_count for usage in completed) and len(
            completed_cloud
        ) != len(completed):
            raise ValueError("Fallback completed cloud attempts are inconsistent")
        cloud_attempts = completed_cloud + (
            () if current_cloud is None else (current_cloud,)
        )
        if current_cloud is not None and len(completed_cloud) != len(invoked) - 1:
            raise ValueError("Fallback current cloud attempt is out of sequence")
        for attempt, index, prepared_payload_bytes in zip(
            cloud_attempts,
            invoked[: len(cloud_attempts)],
            self.prepared_payload_byte_counts[: len(cloud_attempts)],
            strict=True,
        ):
            submitted = attempt.status in {
                CloudExecutionAttemptStatus.SUBMITTED,
                CloudExecutionAttemptStatus.COMPLETED,
                CloudExecutionAttemptStatus.POSSIBLY_PAID,
            }
            expected_pages = (
                (index,) if submitted and self.source_kind == "page" else ()
            )
            expected_frames = (
                (index,) if submitted and self.source_kind == "frame" else ()
            )
            if (
                attempt.provider_name != identity.provider_name
                or attempt.profile_id != identity.profile_id
                or attempt.model_id != identity.model_id
                or attempt.api_version != identity.api_version
                or attempt.provider_resource_identity
                != identity.provider_resource_identity
                or attempt.requested_entire_input
                or attempt.requested_pages
                != ((index,) if self.source_kind == "page" else ())
                or attempt.requested_frames
                != ((index,) if self.source_kind == "frame" else ())
                or attempt.submitted_pages != expected_pages
                or attempt.submitted_frames != expected_frames
                or (
                    attempt.submitted_operation_count
                    and attempt.input_bytes != prepared_payload_bytes
                )
            ):
                raise ValueError("Fallback attempt contains invalid cloud evidence")
        if any(
            attempt.status is not CloudExecutionAttemptStatus.COMPLETED
            for attempt in completed_cloud
        ):
            raise ValueError("Fallback completed cloud attempt is not completed")
        if (
            current is not None
            and current.cloud_logical_operation_count
            and current_cloud is None
        ):
            raise ValueError("Fallback current cloud attempt is missing")
        if (
            current is not None
            and current_cloud is not None
            and (
                current_cloud.status
                not in {
                    CloudExecutionAttemptStatus.COMPLETED,
                    CloudExecutionAttemptStatus.POSSIBLY_PAID,
                }
                or current.cloud_logical_operation_count
                != current_cloud.logical_operation_count
                or current.cloud_submitted_operation_count
                != current_cloud.submitted_operation_count
                or current.cloud_paid_or_possibly_paid_operation_count
                != current_cloud.paid_or_possibly_paid_operation_count
                or current.cloud_transport_retry_count
                != current_cloud.transport_retry_count
            )
        ):
            raise ValueError("Fallback confirmed usage has incomplete cloud evidence")
        if (
            current is None
            and current_cloud is not None
            and current_cloud.status is CloudExecutionAttemptStatus.COMPLETED
        ):
            raise ValueError("Fallback completed cloud evidence has no confirmed usage")
        return self


def _is_actual_source_reference(value: object, expected_type: type[object]) -> bool:
    """Check a normalized source's actual SDK type without reading __class__."""
    actual_type = type(value)
    try:
        return actual_type is expected_type or (
            actual_type.__module__.startswith("document_sdk.")
            and issubclass(actual_type, expected_type)
        )
    except (AttributeError, TypeError):
        return False


def _validate_azure_fallback_provider_identity(
    value: AzureFallbackProviderIdentity,
) -> AzureFallbackProviderIdentity:
    return _revalidate_model_instance_json(
        value,
        AzureFallbackProviderIdentity,
        "Azure fallback Provider identity is invalid",
    )


def _validate_azure_fallback_policy(
    value: AzurePageFallbackPolicy,
) -> AzurePageFallbackPolicy:
    return _revalidate_model_instance_json(
        value,
        AzurePageFallbackPolicy,
        "Azure fallback policy is invalid",
    )


def _validate_azure_fallback_report(
    value: AzurePageFallbackReport,
) -> AzurePageFallbackReport:
    return _revalidate_model_instance_json(
        value,
        AzurePageFallbackReport,
        "Azure fallback report is invalid",
    )


def _validate_azure_fallback_attempt(
    value: AzureFallbackAttemptEvidence,
) -> AzureFallbackAttemptEvidence:
    return _revalidate_model_instance_json(
        value,
        AzureFallbackAttemptEvidence,
        "Azure fallback attempt evidence is invalid",
    )


def _validate_azure_fallback_result(
    value: AzurePageFallbackResult,
) -> AzurePageFallbackResult:
    return _revalidate_model_instance_json(
        value,
        AzurePageFallbackResult,
        "Azure fallback result is invalid",
    )

"""Runtime-only Azure credential resolvers."""

from __future__ import annotations

import os
import re
from threading import Lock
from typing import Self

from document_sdk.core import CredentialResolutionError
from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.ocr._azure_dependencies import (
    require_azure_document_intelligence_support,
)

_ENV_VAR_PATTERN = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


class AzureEnvironmentKeyCredentialResolver:
    """Resolve one customer's Azure key lazily from a named environment variable."""

    __slots__ = ("__env_var_name",)

    def __init__(self, env_var_name: str) -> None:
        """Bind only a safe environment-variable name, never its value."""
        if not _ENV_VAR_PATTERN.fullmatch(env_var_name):
            msg = "Azure key environment-variable name is invalid"
            raise ValueError(msg)
        self.__env_var_name = env_var_name

    def __repr__(self) -> str:
        """Return a representation containing no resolved credential."""
        return (
            "AzureEnvironmentKeyCredentialResolver("
            f"env_var_name={self.__env_var_name!r})"
        )

    @property
    def env_var_name(self) -> str:
        """Return the non-secret environment-variable name."""
        return self.__env_var_name

    def resolve(self) -> object:
        """Return a fresh AzureKeyCredential without retaining the key."""
        value = os.environ.get(self.__env_var_name)
        if value is None or not (normalized_value := value.strip()):
            msg = (
                "Azure credential environment variable is missing or blank: "
                f"{self.__env_var_name}"
            )
            raise CredentialResolutionError(msg)
        require_azure_document_intelligence_support()
        try:
            from azure.core.credentials import AzureKeyCredential

            return AzureKeyCredential(normalized_value)
        except Exception as exc:  # noqa: BLE001 - credential boundary is redacted.
            msg = "Azure key credential construction failed"
            _raise_redacted_translation(exc, CredentialResolutionError(msg))


class AzureDefaultCredentialResolver:
    """Construct a customer-owned DefaultAzureCredential only during resolve."""

    __slots__ = ("__credential", "__lock")

    def __init__(self) -> None:
        """Create an empty synchronized owner without authenticating."""
        self.__credential: object | None = None
        self.__lock = Lock()

    def __repr__(self) -> str:
        """Return a representation containing no credential state."""
        return "AzureDefaultCredentialResolver()"

    def resolve(self) -> object:
        """Return the lazily constructed, resolver-owned Entra credential."""
        with self.__lock:
            if self.__credential is None:
                require_azure_document_intelligence_support()
                try:
                    from azure.identity import DefaultAzureCredential

                    self.__credential = DefaultAzureCredential()
                except Exception as exc:  # noqa: BLE001 - boundary is redacted.
                    msg = "Azure default credential construction failed"
                    _raise_redacted_translation(exc, CredentialResolutionError(msg))
            return self.__credential

    def close(self) -> None:
        """Close and release the currently owned credential at most once."""
        with self.__lock:
            credential = self.__credential
            self.__credential = None
            if credential is None:
                return
            close = getattr(credential, "close", None)
            if not callable(close):
                msg = "Azure default credential cannot be closed safely"
                raise CredentialResolutionError(msg)
            try:
                close()
            except Exception as exc:  # noqa: BLE001 - boundary is redacted.
                msg = "Azure default credential close failed"
                _raise_redacted_translation(exc, CredentialResolutionError(msg))

    def __enter__(self) -> Self:
        """Return this lazy credential owner without resolving it."""
        return self

    def __exit__(self, *args: object) -> None:
        """Close the owned credential when leaving a context."""
        del args
        self.close()

"""Runtime-only credential resolution contracts."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from document_sdk.core import CredentialResolutionError
from document_sdk.core.errors import _raise_redacted_translation


@runtime_checkable
class CredentialResolver(Protocol):
    """Resolve an opaque credential object at operation time."""

    def resolve(self) -> object:
        """Return an opaque runtime credential object."""
        ...


class MockCredentialResolver:
    """A redacting credential resolver for tests and examples."""

    __slots__ = ("__credential", "__error")

    def __init__(
        self,
        credential: object,
        *,
        error: Exception | None = None,
    ) -> None:
        """Create a resolver with an injected opaque object or safe failure."""
        self.__credential = credential
        self.__error = error

    def __repr__(self) -> str:
        """Return a representation that cannot disclose the credential."""
        return "MockCredentialResolver()"

    def resolve(self) -> object:
        """Return the injected credential or raise a redacted SDK error."""
        if self.__error is not None:
            msg = "Mock credential resolution failed"
            _raise_redacted_translation(
                self.__error,
                CredentialResolutionError(msg),
            )
        return self.__credential

"""Safe provider identity metadata."""

from __future__ import annotations

from collections.abc import Mapping  # noqa: TC003 - Pydantic resolves this at runtime.
from typing import Annotated, Self

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    JsonValue,
    StringConstraints,
    field_serializer,
    model_validator,
)

from document_sdk.core._metadata import (
    freeze_json_mapping,
    thaw_json_mapping,
    validate_safe_metadata,
)

type NonEmptyString = Annotated[
    str,
    StringConstraints(strip_whitespace=True, min_length=1),
]


class ProviderMetadata(BaseModel):
    """Serializable provider facts known to be non-secret."""

    model_config = ConfigDict(
        extra="forbid",
        frozen=True,
        hide_input_in_errors=True,
        strict=True,
    )

    provider_name: NonEmptyString
    profile_id: NonEmptyString
    model_id: NonEmptyString | None = None
    attributes: Mapping[str, JsonValue] = Field(default_factory=dict)

    @model_validator(mode="after")
    def freeze_safe_attributes(self) -> Self:
        """Validate and deeply freeze safe provider metadata."""
        validate_safe_metadata(self.attributes)
        object.__setattr__(
            self,
            "attributes",
            freeze_json_mapping(self.attributes),
        )
        return self

    @field_serializer("attributes")
    def serialize_attributes(
        self,
        value: Mapping[str, JsonValue],
    ) -> dict[str, JsonValue]:
        """Serialize immutable metadata as ordinary JSON objects and arrays."""
        return thaw_json_mapping(value)

"""Strict, non-secret provider configuration."""

from __future__ import annotations

from typing import Annotated, Self

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    HttpUrl,
    StringConstraints,
    model_validator,
)

type NonEmptyString = Annotated[
    str,
    StringConstraints(strip_whitespace=True, min_length=1),
]


class RetryConfig(BaseModel):
    """Non-secret retry behavior for a provider instance."""

    model_config = ConfigDict(
        extra="forbid",
        frozen=True,
        hide_input_in_errors=True,
        strict=True,
    )

    max_attempts: int = Field(default=3, ge=1, le=10)
    base_delay_seconds: float = Field(default=0.25, ge=0, le=60)
    max_delay_seconds: float = Field(default=5, ge=0, le=300)

    @model_validator(mode="after")
    def validate_delays(self) -> Self:
        """Ensure the maximum delay is not shorter than the base delay."""
        if self.max_delay_seconds < self.base_delay_seconds:
            msg = "max_delay_seconds must be at least base_delay_seconds"
            raise ValueError(msg)
        return self


class ProviderConfig(BaseModel):
    """Strict provider settings that can never contain credentials."""

    model_config = ConfigDict(
        extra="forbid",
        frozen=True,
        hide_input_in_errors=True,
        strict=True,
    )

    provider_name: NonEmptyString
    profile_id: NonEmptyString
    endpoint: HttpUrl | None = None
    region: NonEmptyString | None = None
    model_id: NonEmptyString | None = None
    deployment_name: NonEmptyString | None = None
    processor_id: NonEmptyString | None = None
    timeout_seconds: float = Field(default=30, gt=0, le=600)
    retry: RetryConfig = Field(default_factory=RetryConfig)

    @model_validator(mode="after")
    def reject_endpoint_credentials(self) -> Self:
        """Reject user information and query strings in provider endpoints."""
        if self.endpoint is None:
            return self
        if self.endpoint.username or self.endpoint.password:
            msg = "provider endpoint must not contain user information"
            raise ValueError(msg)
        if self.endpoint.query:
            msg = "provider endpoint must not contain a query string"
            raise ValueError(msg)
        if self.endpoint.fragment:
            msg = "provider endpoint must not contain a fragment"
            raise ValueError(msg)
        return self

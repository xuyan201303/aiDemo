"""Immutable per-provider runtime context."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal, Protocol, cast, final

from pydantic import BaseModel

from document_sdk.core import ProviderConfigurationError
from document_sdk.providers.metadata import ProviderMetadata

if TYPE_CHECKING:
    from document_sdk.providers.credentials import CredentialResolver


class _ProviderConfiguration(Protocol):
    """Structural boundary for immutable provider configuration models."""

    @property
    def provider_name(self) -> str:
        """Return the stable provider name."""
        ...

    @property
    def model_id(self) -> str | None:
        """Return the configured model identifier."""
        ...

    def model_dump(self, *, mode: Literal["json"]) -> dict[str, object]:
        """Return safe serializable configuration."""
        ...


def _safe_configuration_dict(config: _ProviderConfiguration) -> dict[str, object]:
    """Project exact Azure config without endpoint or untrusted model hooks."""
    from document_sdk.ocr._azure_models import (  # noqa: PLC0415 - avoids a providers/ocr import cycle.
        AzureDocumentIntelligenceConfig,
    )

    actual_type = type(config)
    try:
        is_azure_config = issubclass(actual_type, AzureDocumentIntelligenceConfig)
    except TypeError:
        is_azure_config = False
    if not is_azure_config:
        return config.model_dump(mode="json")
    if actual_type is not AzureDocumentIntelligenceConfig:
        msg = "Azure provider safe configuration type is invalid"
        raise ProviderConfigurationError(msg)
    try:
        raw = BaseModel.model_dump(
            cast("BaseModel", config),
            mode="python",
            round_trip=True,
            warnings="error",
        )
        validated = AzureDocumentIntelligenceConfig.model_validate(raw)
        projected = BaseModel.model_dump(
            validated,
            mode="json",
            warnings="error",
        )
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception:  # noqa: BLE001 - emit one sanitized projection failure.
        msg = "Azure provider safe configuration is invalid"
        raise ProviderConfigurationError(msg) from None
    projected.pop("endpoint", None)
    projected["provider_resource_identity"] = validated.resource_identity
    return projected


@final
class ProviderContext:
    """Bind one profile's safe configuration and runtime resolver."""

    __config: _ProviderConfiguration
    __credential_resolver: CredentialResolver
    __metadata: ProviderMetadata
    __profile_id: str

    __slots__ = (
        "__config",
        "__credential_resolver",
        "__metadata",
        "__profile_id",
    )

    def __init__(
        self,
        *,
        profile_id: str,
        config: _ProviderConfiguration,
        credential_resolver: CredentialResolver,
        metadata: ProviderMetadata | None = None,
    ) -> None:
        """Validate and bind one isolated provider runtime context."""
        if not profile_id.strip():
            msg = "provider context profile_id must not be empty"
            raise ProviderConfigurationError(msg)
        config_profile_id = getattr(config, "profile_id", None)
        if config_profile_id is not None and profile_id != config_profile_id:
            msg = "provider context profile_id does not match provider config"
            raise ProviderConfigurationError(msg)
        actual_metadata = metadata or ProviderMetadata(
            provider_name=config.provider_name,
            profile_id=profile_id,
            model_id=config.model_id,
        )
        if profile_id != actual_metadata.profile_id:
            msg = "provider context profile_id does not match provider metadata"
            raise ProviderConfigurationError(msg)
        if config.provider_name != actual_metadata.provider_name:
            msg = "provider context provider name does not match metadata"
            raise ProviderConfigurationError(msg)
        if config.model_id != actual_metadata.model_id:
            msg = "provider context model ID does not match metadata"
            raise ProviderConfigurationError(msg)

        object.__setattr__(self, "_ProviderContext__profile_id", profile_id)
        object.__setattr__(self, "_ProviderContext__config", config)
        object.__setattr__(
            self,
            "_ProviderContext__credential_resolver",
            credential_resolver,
        )
        object.__setattr__(self, "_ProviderContext__metadata", actual_metadata)

    def __setattr__(self, name: str, value: object) -> None:
        """Prevent mutation after initialization."""
        msg = "ProviderContext is immutable"
        raise AttributeError(msg)

    def __repr__(self) -> str:
        """Return a representation that deliberately omits the resolver."""
        return (
            "ProviderContext("
            f"profile_id={self.profile_id!r}, "
            f"config={self.config!r}, "
            f"metadata={self.metadata!r})"
        )

    @property
    def profile_id(self) -> str:
        """Return the isolated customer profile identifier."""
        return self.__profile_id

    @property
    def config(self) -> _ProviderConfiguration:
        """Return immutable, non-secret provider configuration."""
        return self.__config

    @property
    def credential_resolver(self) -> CredentialResolver:
        """Return the runtime resolver without serializing it."""
        return self.__credential_resolver

    @property
    def metadata(self) -> ProviderMetadata:
        """Return immutable safe provider metadata."""
        return self.__metadata

    def safe_dict(self) -> dict[str, object]:
        """Return JSON-compatible context data without the resolver."""
        return {
            "profile_id": self.profile_id,
            "config": _safe_configuration_dict(self.config),
            "metadata": self.metadata.model_dump(mode="json"),
        }

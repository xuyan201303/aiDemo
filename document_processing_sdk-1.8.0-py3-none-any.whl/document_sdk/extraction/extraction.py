"""Deterministic provider-independent structured field extraction."""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date, time
from decimal import Decimal, InvalidOperation
from typing import TYPE_CHECKING, Literal, Never, cast

from document_sdk.core import (
    CloudExecutionAttemptEvidence,
    Document,
    DocumentField,
    DocumentProcessingError,
    LocalOcrIntrinsicQualityPolicy,
    LocalOcrQualityReport,
    ProcessingError,
    ProcessingResult,
    ProcessingWarning,
    ProviderResponseError,
    ProviderUsage,
)
from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.core.local_ocr_quality import (
    _validate_local_ocr_provider_quality_result,
)
from document_sdk.extraction.errors import (
    ExtractionSchemaError,
    StructuredExtractionIncompleteError,
    StructuredExtractionProviderRequiredError,
)
from document_sdk.extraction.models import (
    _ISSUE_MESSAGE,
    DocumentTypeStatus,
    ExtractionConfidenceSource,
    ExtractionSchema,
    ExtractionStrategy,
    ExtractionValueType,
    FieldDefinition,
    StructuredExtractionIncompleteSummary,
    StructuredExtractionIssue,
    StructuredExtractionOptions,
    StructuredExtractionResult,
    StructuredFieldCandidate,
    StructuredFieldResult,
    _candidate_order_key,
    _candidate_public_key,
    _constraint_categories,
    _expected_document_field_type,
    _matching_name,
)
from document_sdk.ocr._provider_boundary import (
    _invoke_ocr_provider_safely,
    _LocalOcrInvocationState,
    _read_provider_identity_safely,
)
from document_sdk.ocr.models import (
    DocumentAnalysisFeature,
    OcrAnalysisOptions,
)
from document_sdk.pdf._validation import _validated_pdf_limits
from document_sdk.pipeline import HybridPdfAnalysisOptions
from document_sdk.pipeline.hybrid_pdf import (
    _analyze_pdf_hybrid_effective,
    _analyze_pdf_hybrid_prepared,
)

if TYPE_CHECKING:
    from pathlib import Path

    from document_sdk.core.models import DocumentSourceReference, PdfInspection
    from document_sdk.ocr.preprocessing_models import LocalOcrPreprocessingReport
    from document_sdk.ocr.provider import OcrProvider
    from document_sdk.pdf import PdfProcessingLimits
_MAX_QUERY_FIELDS = 20
_TRUE_LITERALS = frozenset({"true"})
_FALSE_LITERALS = frozenset({"false"})
_INTEGER_PATTERN = re.compile(r"^[+-]?[0-9]+$")
type _CandidateStatus = Literal[
    "normalized",
    "raw_only",
    "invalid",
    "missing_value",
]
type _FieldStatus = Literal[
    "found",
    "missing",
    "ambiguous",
    "invalid",
    "low_confidence",
    "raw_only",
]


@dataclass(frozen=True, slots=True)
class _CandidateRecord:
    candidate: StructuredFieldCandidate
    priority: int
    origin: str
    normalization: _CandidateStatus = "normalized"


@dataclass(frozen=True, slots=True)
class _ProviderIdentity:
    provider_name: str
    profile_id: str
    model_id: str | None


@dataclass(frozen=True, slots=True)
class _DocumentTypeEvidence:
    status: DocumentTypeStatus
    observed: tuple[str, ...]
    matched: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class _StructuredQualityCounts:
    required_fields: int
    missing_required_fields: int
    ambiguous_required_fields: int
    constrained_required_field_issues: int
    tables: int
    table_cells: int
    empty_table_cells: int


def _issue(
    category: str,
    *,
    field_name: str | None,
    severity: Literal["warning", "error"] = "error",
    count: int = 1,
) -> StructuredExtractionIssue:
    """Create one content-free issue using only a safe field name/category."""
    return StructuredExtractionIssue(
        code=f"structured_extraction.{category}",
        category=category,
        message=_ISSUE_MESSAGE,
        severity=severity,
        field_name=field_name,
        count=count,
    )


def _aggregate_issues(
    issues: tuple[StructuredExtractionIssue, ...],
) -> tuple[StructuredExtractionIssue, ...]:
    """Combine repeated safe issues while preserving first-seen order."""
    totals: dict[tuple[object, ...], int] = {}
    first: dict[tuple[object, ...], StructuredExtractionIssue] = {}
    for issue in issues:
        key = (
            issue.code,
            issue.category,
            issue.message,
            issue.severity,
            issue.field_name,
        )
        first.setdefault(key, issue)
        totals[key] = totals.get(key, 0) + issue.count
    return tuple(
        StructuredExtractionIssue(
            code=first[key].code,
            category=first[key].category,
            message=first[key].message,
            severity=first[key].severity,
            field_name=first[key].field_name,
            count=totals[key],
        )
        for key in first
    )


def _source_key(source: object) -> str:
    """Return a deterministic serialization for an SDK source."""
    serializer = getattr(source, "model_dump_json", None)
    if not callable(serializer):
        return ""
    value = serializer()
    return value if isinstance(value, str) else ""


def _combined_sources(
    *groups: tuple[DocumentSourceReference, ...],
) -> tuple[DocumentSourceReference, ...]:
    """Combine only existing source evidence in deterministic order."""
    unique = {_source_key(source): source for group in groups for source in group}
    return tuple(unique[key] for key in sorted(unique))


def _candidate(  # noqa: PLR0913
    *,
    source_kind: Literal["analyzed_field", "key_value_pair"],
    matched_name: str,
    match_kind: Literal["canonical", "alias"],
    field: DocumentField,
    confidence: float | None,
    sources: tuple[DocumentSourceReference, ...],
    document_type: str | None,
) -> StructuredFieldCandidate:
    """Build one validated public candidate from existing evidence."""
    return StructuredFieldCandidate(
        source_kind=source_kind,
        matched_name=matched_name,
        match_kind=match_kind,
        field=field,
        confidence=confidence,
        confidence_source=(
            ExtractionConfidenceSource.PROVIDER_REPORTED
            if confidence is not None
            else ExtractionConfidenceSource.UNAVAILABLE
        ),
        confidence_usable_for_thresholds=confidence is not None,
        sources=sources,
        document_type=document_type,
    )


def _match_kind(
    name: str,
    *,
    definition: FieldDefinition,
) -> Literal["canonical", "alias"] | None:
    """Match a canonical name or caller-supplied alias exactly."""
    key = _matching_name(name)
    if key == _matching_name(definition.name):
        return "canonical"
    if key in {_matching_name(alias) for alias in definition.aliases}:
        return "alias"
    return None


def _discover_candidates(
    document: Document,
    definition: FieldDefinition,
    *,
    accepted_document_types: frozenset[str],
) -> tuple[_CandidateRecord, ...]:
    """Discover exact analyzed-field and key-value candidates only."""
    records: list[_CandidateRecord] = []
    analyzed_documents = sorted(
        document.analyzed_documents,
        key=lambda item: (_matching_name(item.document_type), item.element_id),
    )
    for analyzed in analyzed_documents:
        if (
            accepted_document_types
            and _matching_name(analyzed.document_type) not in accepted_document_types
        ):
            continue
        for field_name, field in analyzed.fields.items():
            match_kind = _match_kind(field_name, definition=definition)
            if match_kind is None:
                continue
            records.append(
                _CandidateRecord(
                    candidate=_candidate(
                        source_kind="analyzed_field",
                        matched_name=field_name,
                        match_kind=match_kind,
                        field=field,
                        confidence=field.confidence,
                        sources=field.sources,
                        document_type=analyzed.document_type,
                    ),
                    priority=0 if match_kind == "canonical" else 1,
                    origin=f"analyzed_document:{analyzed.element_id}:{field_name}",
                )
            )
    for pair in sorted(document.key_value_pairs, key=lambda item: item.element_id):
        match_kind = _match_kind(pair.key.content, definition=definition)
        if match_kind is None:
            continue
        value = pair.value
        sources = _combined_sources(
            pair.sources,
            pair.key.sources,
            () if value is None else value.sources,
        )
        raw_field = DocumentField(
            field_type="string",
            normalization_status="raw_only",
            value=None,
            content=None if value is None else value.content,
            confidence=pair.confidence,
            spans=pair.spans if value is None else value.spans,
            sources=sources,
        )
        records.append(
            _CandidateRecord(
                candidate=_candidate(
                    source_kind="key_value_pair",
                    matched_name=pair.key.content,
                    match_kind=match_kind,
                    field=raw_field,
                    confidence=pair.confidence,
                    sources=sources,
                    document_type=None,
                ),
                priority=2 if match_kind == "canonical" else 3,
                origin=f"key_value_pair:{pair.element_id}",
                normalization="missing_value" if value is None else "raw_only",
            )
        )
    return tuple(records)


def _raw_value(  # noqa: C901, PLR0911, PLR0912
    raw: str,
    value_type: ExtractionValueType,
) -> str | int | Decimal | bool | date | time:
    """Conservatively coerce supported unambiguous scalar text."""
    normalized = raw.strip()
    if value_type is ExtractionValueType.STRING:
        return raw
    if value_type is ExtractionValueType.INTEGER:
        if not _INTEGER_PATTERN.fullmatch(normalized):
            raise ValueError
        return int(normalized)
    if value_type in {ExtractionValueType.DECIMAL, ExtractionValueType.NUMBER}:
        try:
            value = Decimal(normalized)
        except InvalidOperation:
            raise ValueError from None
        if not value.is_finite():
            raise ValueError
        return value
    if value_type is ExtractionValueType.DATE:
        return date.fromisoformat(normalized)
    if value_type is ExtractionValueType.TIME:
        return time.fromisoformat(normalized)
    if value_type is ExtractionValueType.BOOLEAN:
        folded = normalized.casefold()
        if folded in _TRUE_LITERALS:
            return True
        if folded in _FALSE_LITERALS:
            return False
        raise ValueError
    if value_type is ExtractionValueType.SELECTION_MARK:
        folded = normalized.casefold()
        if folded not in {"selected", "unselected"}:
            raise ValueError
        return folded
    raise TypeError


def _normalized_field(  # noqa: PLR0911
    source: DocumentField,
    *,
    definition: FieldDefinition,
    coerce_raw_values: bool,
) -> tuple[DocumentField, _CandidateStatus]:
    """Reuse a typed value or conservatively normalize its raw content."""
    expected_type = _expected_document_field_type(definition.value_type)
    if source.normalization_status == "normalized":
        if source.field_type == expected_type:
            return source, "normalized"
        converted_value: str | int | Decimal | None = None
        if (
            source.field_type == "integer"
            and expected_type == "number"
            and type(source.value) is int
        ):
            converted_value = Decimal(source.value)
        elif (
            source.field_type == "number"
            and expected_type == "integer"
            and isinstance(source.value, Decimal)
            and source.value.is_finite()
            and source.value == source.value.to_integral_value()
        ):
            converted_value = int(source.value)
        elif (
            source.field_type
            in {"phoneNumber", "countryRegion", "signature", "selectionMark"}
            and expected_type == "string"
            and isinstance(source.value, str)
        ):
            converted_value = source.value
        if converted_value is None:
            return source, "invalid"
        return (
            DocumentField(
                field_type=expected_type,
                normalization_status="normalized",
                value=converted_value,
                content=source.content,
                confidence=source.confidence,
                spans=source.spans,
                sources=source.sources,
            ),
            "normalized",
        )
    if not coerce_raw_values or source.content is None:
        return source, "raw_only"
    try:
        value = _raw_value(source.content, definition.value_type)
    except TypeError:
        return source, "raw_only"
    except (OverflowError, ValueError):
        return source, "invalid"
    return (
        DocumentField(
            field_type=expected_type,
            normalization_status="normalized",
            value=value,
            content=source.content,
            confidence=source.confidence,
            spans=source.spans,
            sources=source.sources,
        ),
        "normalized",
    )


def _replace_candidate_field(
    candidate: StructuredFieldCandidate,
    field: DocumentField,
) -> StructuredFieldCandidate:
    """Return one candidate with a validated normalized field."""
    return _candidate(
        source_kind=candidate.source_kind,
        matched_name=candidate.matched_name,
        match_kind=candidate.match_kind,
        field=field,
        confidence=candidate.confidence,
        sources=field.sources,
        document_type=candidate.document_type,
    )


def _prepare_records(
    records: tuple[_CandidateRecord, ...],
    *,
    definition: FieldDefinition,
    coerce_raw_values: bool,
) -> tuple[_CandidateRecord, ...]:
    """Normalize all candidates before deterministic equivalence checks."""
    prepared = []
    for record in records:
        status: _CandidateStatus
        if record.normalization == "missing_value":
            field = record.candidate.field
            status = record.normalization
        else:
            field, status = _normalized_field(
                record.candidate.field,
                definition=definition,
                coerce_raw_values=coerce_raw_values,
            )
        prepared.append(
            _CandidateRecord(
                candidate=_replace_candidate_field(record.candidate, field),
                priority=record.priority,
                origin=record.origin,
                normalization=status,
            )
        )
    return tuple(prepared)


def _record_sort_key(record: _CandidateRecord) -> tuple[object, ...]:
    """Return deterministic public ordering with an internal final tie-breaker."""
    return (*_candidate_order_key(record.candidate), record.origin)


def _deduplicate_records(
    records: tuple[_CandidateRecord, ...],
) -> tuple[_CandidateRecord, ...]:
    """Deduplicate and order using only the public candidate contract."""
    unique: dict[str, _CandidateRecord] = {}
    for record in sorted(records, key=_record_sort_key):
        unique.setdefault(_candidate_public_key(record.candidate), record)
    return tuple(unique.values())


def _resolve_field(
    document: Document,
    definition: FieldDefinition,
    *,
    accepted_document_types: frozenset[str],
    coerce_raw_values: bool,
) -> StructuredFieldResult:
    """Produce the final resolution state for exactly one schema field."""
    records = _prepare_records(
        _discover_candidates(
            document,
            definition,
            accepted_document_types=accepted_document_types,
        ),
        definition=definition,
        coerce_raw_values=coerce_raw_values,
    )
    records = _deduplicate_records(records)
    candidates = tuple(record.candidate for record in records)
    if not records:
        missing_issues = (
            (_issue("required_field_missing", field_name=definition.name),)
            if definition.required
            else ()
        )
        return StructuredFieldResult(
            name=definition.name,
            definition=definition,
            status="missing",
            candidates=(),
            issues=missing_issues,
        )
    top_priority = min(record.priority for record in records)
    top = tuple(record for record in records if record.priority == top_priority)
    if len(top) > 1 and not definition.allow_multiple:
        return StructuredFieldResult(
            name=definition.name,
            definition=definition,
            status="ambiguous",
            candidates=candidates,
            issues=(
                _issue("ambiguous_candidates", field_name=definition.name),
                *(
                    (_issue("missing_value", field_name=definition.name),)
                    if any(record.normalization == "missing_value" for record in top)
                    else ()
                ),
            ),
        )

    issues: list[StructuredExtractionIssue] = []
    status: _FieldStatus = "found"
    for record in top:
        if record.normalization == "missing_value":
            status = "invalid"
            issues.append(_issue("missing_value", field_name=definition.name))
        elif record.normalization == "invalid":
            status = "invalid"
            issues.append(_issue("value_type_invalid", field_name=definition.name))
        elif record.normalization == "raw_only" and status != "invalid":
            status = "raw_only"
            issues.append(
                _issue(
                    "raw_value_not_normalized",
                    field_name=definition.name,
                    severity="warning",
                )
            )
        if (
            definition.min_confidence is not None
            and (
                record.candidate.confidence is None
                or record.candidate.confidence < definition.min_confidence
            )
            and status not in {"invalid", "raw_only"}
        ):
            status = "low_confidence"
            issues.append(_issue("low_confidence", field_name=definition.name))
        if record.normalization == "normalized":
            categories = _constraint_categories(
                record.candidate.field.value,
                definition.constraints,
            )
            if categories:
                status = "invalid"
                issues.extend(
                    _issue(
                        f"constraint_{category}",
                        field_name=definition.name,
                    )
                    for category in categories
                )
    selected = tuple(record.candidate for record in top) if status == "found" else ()
    return StructuredFieldResult(
        name=definition.name,
        definition=definition,
        status=status,
        selected=selected,
        candidates=candidates,
        issues=_aggregate_issues(tuple(issues)),
    )


def _provider_error_issue(
    errors: tuple[ProcessingError, ...],
) -> tuple[StructuredExtractionIssue, ...]:
    """Represent Provider partial errors without copying codes or messages."""
    if not errors:
        return ()
    return (
        _issue(
            "provider_partial_errors",
            field_name=None,
            count=len(errors),
        ),
    )


def _structured_quality_counts(
    result: StructuredExtractionResult,
) -> _StructuredQualityCounts:
    """Count existing field/table evidence without retaining names or contents."""
    from document_sdk.ocr.local_errors import (  # noqa: PLC0415
        LocalOcrQualityEvaluationError,
    )

    required_counts = (0, 0, 0, 0)
    table_counts = (0, 0, 0)
    try:
        required_counts = _required_quality_counts(result)
        table_counts = _table_quality_counts(result)
    except Exception as exc:  # noqa: BLE001 - public evidence is redacted.
        msg = "Structured Local OCR quality evidence could not be evaluated safely"
        _raise_redacted_translation(exc, LocalOcrQualityEvaluationError(msg))
    return _StructuredQualityCounts(
        required_fields=required_counts[0],
        missing_required_fields=required_counts[1],
        ambiguous_required_fields=required_counts[2],
        constrained_required_field_issues=required_counts[3],
        tables=table_counts[0],
        table_cells=table_counts[1],
        empty_table_cells=table_counts[2],
    )


def _required_quality_counts(
    result: StructuredExtractionResult,
) -> tuple[int, int, int, int]:
    required = missing = ambiguous = constrained = 0
    for field in result.fields:
        if not field.definition.required:
            continue
        required += 1
        missing += field.status == "missing"
        ambiguous += field.status == "ambiguous"
        constrained += field.status in {"invalid", "low_confidence", "raw_only"}
    return required, missing, ambiguous, constrained


def _one_table_quality_counts(table: object) -> tuple[int, int]:
    from document_sdk.core import Table  # noqa: PLC0415

    if not issubclass(type(table), Table):
        msg = "Structured table evidence is invalid"
        raise TypeError(msg)
    validated_table = cast("Table", table)
    cells = 0
    empty_cells = 0
    for cell in validated_table.cells:
        text = cell.text
        if type(text) is not str:
            msg = "Structured table cell evidence is invalid"
            raise TypeError(msg)
        cells += 1
        empty_cells += not str.strip(text)
    return cells, empty_cells


def _table_quality_counts(
    result: StructuredExtractionResult,
) -> tuple[int, int, int]:
    tables = table_cells = empty_table_cells = 0
    for table in result.document.tables:
        cells, empty_cells = _one_table_quality_counts(table)
        tables += 1
        table_cells += cells
        empty_table_cells += empty_cells
    for page in result.document.pages:
        for table in page.tables:
            cells, empty_cells = _one_table_quality_counts(table)
            tables += 1
            table_cells += cells
            empty_table_cells += empty_cells
    return tables, table_cells, empty_table_cells


def _build_result(  # noqa: PLR0913
    document: Document,
    schema: ExtractionSchema,
    *,
    options: StructuredExtractionOptions,
    warnings: tuple[ProcessingWarning, ...] = (),
    provider_usage: ProviderUsage | None = None,
    cloud_execution_attempt: CloudExecutionAttemptEvidence | None = None,
    external_issues: tuple[StructuredExtractionIssue, ...] = (),
    intrinsic_quality_report: LocalOcrQualityReport | None = None,
    preprocessing_report: LocalOcrPreprocessingReport | None = None,
) -> StructuredExtractionResult:
    """Build and validate the complete final extraction result."""
    accepted = frozenset(
        _matching_name(value) for value in schema.accepted_document_types
    )
    observed = tuple(
        sorted(
            {
                _matching_name(analyzed.document_type)
                for analyzed in document.analyzed_documents
            }
        )
    )
    matched = tuple(value for value in observed if value in accepted)
    if not accepted:
        document_type_status = DocumentTypeStatus.NOT_RESTRICTED
    elif not observed:
        document_type_status = DocumentTypeStatus.UNAVAILABLE
    elif matched:
        document_type_status = DocumentTypeStatus.ACCEPTED
    else:
        document_type_status = DocumentTypeStatus.REJECTED
    document_type_evidence = _DocumentTypeEvidence(
        status=document_type_status,
        observed=observed,
        matched=matched,
    )
    fields = tuple(
        _resolve_field(
            document,
            definition,
            accepted_document_types=accepted,
            coerce_raw_values=options.coerce_raw_values,
        )
        for definition in schema.fields
    )
    missing = tuple(
        field.name
        for field in fields
        if field.definition.required and field.status == "missing"
    )
    unresolved = tuple(
        field.name
        for field in fields
        if field.definition.required and field.status != "found"
    )
    field_issues = tuple(issue for field in fields for issue in field.issues)
    document_type_issues = (
        (
            _issue(
                f"document_type_{document_type_status.value}",
                field_name=None,
            ),
        )
        if document_type_status
        in {DocumentTypeStatus.UNAVAILABLE, DocumentTypeStatus.REJECTED}
        else ()
    )
    issues = field_issues + document_type_issues + external_issues
    eligible = document_type_status in {
        DocumentTypeStatus.NOT_RESTRICTED,
        DocumentTypeStatus.ACCEPTED,
    }
    extraction_error = any(
        issue.severity == "error" and issue.field_name is None for issue in issues
    )
    result = StructuredExtractionResult.model_validate(
        {
            "schema": schema,
            "schema_id": schema.schema_id,
            "schema_version": schema.schema_version,
            "document": document,
            "fields": fields,
            "accepted_document_types": schema.accepted_document_types,
            "document_type_status": document_type_evidence.status,
            "observed_document_types": document_type_evidence.observed,
            "matched_document_types": document_type_evidence.matched,
            "complete": eligible and not unresolved and not extraction_error,
            "missing_required_fields": missing,
            "unresolved_required_fields": unresolved,
            "issues": issues,
            "warnings": warnings,
            "provider_usage": provider_usage,
            "cloud_execution_attempt": cloud_execution_attempt,
        }
    )
    quality_report = intrinsic_quality_report
    if options.local_ocr_quality_policy is not None:
        from document_sdk.core.local_ocr_quality import (  # noqa: PLC0415
            merge_local_ocr_structured_quality,
        )
        from document_sdk.ocr.local_errors import (  # noqa: PLC0415
            LocalOcrQualityEvaluationError,
        )

        counts = _structured_quality_counts(result)
        try:
            quality_report = merge_local_ocr_structured_quality(
                intrinsic_report=intrinsic_quality_report,
                policy=options.local_ocr_quality_policy,
                required_field_count=counts.required_fields,
                missing_required_field_count=counts.missing_required_fields,
                ambiguous_required_field_count=counts.ambiguous_required_fields,
                constrained_required_field_issue_count=(
                    counts.constrained_required_field_issues
                ),
                table_count=counts.tables,
                table_cell_count=counts.table_cells,
                empty_table_cell_count=counts.empty_table_cells,
            )
        except Exception as exc:  # noqa: BLE001 - quality boundary is redacted.
            msg = "Structured Local OCR quality evidence could not be merged safely"
            _raise_redacted_translation(exc, LocalOcrQualityEvaluationError(msg))
    if quality_report is not None:
        result = result.model_copy(update={"local_ocr_quality_report": quality_report})
    if preprocessing_report is not None:
        result = result.model_copy(
            update={"local_ocr_preprocessing_report": preprocessing_report}
        )
    result = _revalidate_structured_extraction_result(result)
    if options.fail_on_incomplete and not result.complete:
        summary = StructuredExtractionIncompleteSummary.from_result(result)
        raise StructuredExtractionIncompleteError(summary)
    return result


def _revalidate_structured_extraction_result(
    result: StructuredExtractionResult,
) -> StructuredExtractionResult:
    """Revalidate every public Structured result after private model updates."""
    try:
        return _revalidate_model_instance_json(
            result,
            StructuredExtractionResult,
            "Structured extraction result is invalid",
        )
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception as exc:  # noqa: BLE001 - public boundary is redacted.
        _raise_redacted_translation(
            exc,
            DocumentProcessingError("Structured extraction result is invalid"),
        )


def _validated_inputs(
    document: object,
    schema: object,
    options: object,
) -> tuple[Document, ExtractionSchema, StructuredExtractionOptions]:
    """Losslessly rebuild direct-extraction inputs before reading any fields."""
    document_message = "A validated Document is required"
    try:
        validated_document = _revalidate_model_instance_json(
            cast("Document", document),
            Document,
            document_message,
        )
    except Exception as exc:  # noqa: BLE001 - public boundary is redacted.
        _raise_redacted_translation(exc, DocumentProcessingError(document_message))
    schema_message = "A validated ExtractionSchema is required"
    try:
        validated_schema = _revalidate_model_instance_json(
            cast("ExtractionSchema", schema),
            ExtractionSchema,
            schema_message,
        )
    except Exception as exc:  # noqa: BLE001 - public boundary is redacted.
        _raise_redacted_translation(exc, ExtractionSchemaError(schema_message))
    options_message = "Structured extraction options are invalid"
    try:
        effective_options = (
            StructuredExtractionOptions()
            if options is None
            else _revalidate_model_instance_json(
                cast("StructuredExtractionOptions", options),
                StructuredExtractionOptions,
                options_message,
            )
        )
    except Exception as exc:  # noqa: BLE001 - public boundary is redacted.
        _raise_redacted_translation(exc, ExtractionSchemaError(options_message))
    if (
        effective_options.strategy is not ExtractionStrategy.HYBRID_EXISTING
        or effective_options.pages is not None
        or effective_options.locale is not None
        or effective_options.features
    ):
        msg = "Direct structured extraction does not accept analysis options"
        raise ExtractionSchemaError(msg)
    return validated_document, validated_schema, effective_options


def _validated_schema_options(
    schema: object,
    options: object,
) -> tuple[ExtractionSchema, StructuredExtractionOptions]:
    """Losslessly rebuild analysis inputs before local or Provider access."""
    schema_message = "A validated ExtractionSchema is required"
    try:
        validated_schema = _revalidate_model_instance_json(
            cast("ExtractionSchema", schema),
            ExtractionSchema,
            schema_message,
        )
    except Exception as exc:  # noqa: BLE001 - public boundary is redacted.
        _raise_redacted_translation(exc, ExtractionSchemaError(schema_message))
    options_message = "Structured extraction options are invalid"
    try:
        effective_options = (
            StructuredExtractionOptions()
            if options is None
            else _revalidate_model_instance_json(
                cast("StructuredExtractionOptions", options),
                StructuredExtractionOptions,
                options_message,
            )
        )
    except Exception as exc:  # noqa: BLE001 - public boundary is redacted.
        _raise_redacted_translation(exc, ExtractionSchemaError(options_message))
    return validated_schema, effective_options


def _validate_local_quality_provider(
    options: StructuredExtractionOptions,
    provider: OcrProvider | None,
) -> None:
    """Reject Local-only quality policy before inspection or Provider access."""
    if options.local_ocr_quality_policy is None or provider is None:
        return
    from document_sdk.ocr.local import (  # noqa: PLC0415
        _is_local_ocr_provider_instance,
    )
    from document_sdk.ocr.local_errors import (  # noqa: PLC0415
        LocalOcrQualityConfigurationError,
    )

    if not _is_local_ocr_provider_instance(provider):
        msg = "Local OCR quality policy requires a Local OCR Provider"
        raise LocalOcrQualityConfigurationError(msg)


def extract_structured_fields(
    document: Document,
    schema: ExtractionSchema,
    *,
    options: StructuredExtractionOptions | None = None,
) -> StructuredExtractionResult:
    """Resolve a schema against normalized analyzed fields and key-value pairs."""
    return _extract_structured_fields_with_quality(
        document,
        schema,
        options=options,
        intrinsic_quality_report=None,
    )


def _extract_structured_fields_with_quality(  # noqa: PLR0913
    document: Document,
    schema: ExtractionSchema,
    *,
    options: StructuredExtractionOptions | None,
    intrinsic_quality_report: LocalOcrQualityReport | None,
    provider_usage: ProviderUsage | None = None,
    cloud_execution_attempt: CloudExecutionAttemptEvidence | None = None,
    preprocessing_report: LocalOcrPreprocessingReport | None = None,
) -> StructuredExtractionResult:
    """Resolve fields while reusing one already prepared intrinsic report."""
    validated_document, validated_schema, effective_options = _validated_inputs(
        document,
        schema,
        options,
    )
    return _build_result(
        validated_document,
        validated_schema,
        options=effective_options,
        provider_usage=provider_usage,
        cloud_execution_attempt=cloud_execution_attempt,
        intrinsic_quality_report=intrinsic_quality_report,
        preprocessing_report=preprocessing_report,
    )


def _provider_identity(provider: OcrProvider) -> _ProviderIdentity:
    """Read only immutable non-secret Provider context identity."""
    provider_name, profile_id, model_id = _read_provider_identity_safely(
        provider,
        error=ProviderResponseError(
            "Structured extraction Provider Context metadata is invalid"
        ),
    )
    return _ProviderIdentity(provider_name, profile_id, model_id)


def _provider_result(  # noqa: PLR0913
    path: Path,
    *,
    provider: OcrProvider,
    request_options: OcrAnalysisOptions,
    expected_query_field_count: int,
    local_prepared_source: object | None = None,
    enable_local_ocr_quality: bool = False,
    local_invocation_state: _LocalOcrInvocationState | None = None,
) -> ProcessingResult[Document]:
    """Run and validate one explicit Provider operation."""
    identity = _provider_identity(provider)
    from document_sdk.ocr.local import _local_ocr_quality_policy  # noqa: PLC0415

    expected_quality_policy = _local_ocr_quality_policy(provider)
    if expected_quality_policy is None and enable_local_ocr_quality:
        expected_quality_policy = LocalOcrIntrinsicQualityPolicy()
    from document_sdk.ocr.local import (  # noqa: PLC0415
        _is_local_ocr_provider_instance,
    )

    if enable_local_ocr_quality and _is_local_ocr_provider_instance(provider):
        if local_prepared_source is None:
            result = _invoke_ocr_provider_safely(
                provider,
                "_analyze_bounded",
                path,
                options=request_options,
                usage_budget=None,
                enable_quality=True,
                error_message="Structured extraction Provider analysis failed",
                invocation_state=local_invocation_state,
            )
        else:
            result = _invoke_ocr_provider_safely(
                provider,
                "_analyze_prepared",
                path,
                local_prepared_source,
                options=request_options,
                usage_budget=None,
                enable_quality=True,
                error_message="Structured extraction Provider analysis failed",
                invocation_state=local_invocation_state,
            )
    elif local_prepared_source is None:
        result = _invoke_ocr_provider_safely(
            provider,
            "analyze",
            path,
            options=request_options,
            error_message="Structured extraction Provider analysis failed",
        )
    else:
        result = _invoke_ocr_provider_safely(
            provider,
            "_analyze_prepared",
            path,
            local_prepared_source,
            options=request_options,
            usage_budget=None,
            error_message="Structured extraction Provider analysis failed",
            invocation_state=local_invocation_state,
        )
    try:
        metadata = result.metadata
        usage = metadata.provider_usage
        identity_matches = (
            metadata.provider_name == identity.provider_name
            and metadata.profile_id == identity.profile_id
            and metadata.model_id == identity.model_id
        )
        usage_matches = (
            usage is not None
            and usage.provider_name == identity.provider_name
            and usage.profile_id == identity.profile_id
            and usage.model_id == identity.model_id
            and usage.query_field_count == expected_query_field_count
        )
    except Exception as exc:  # noqa: BLE001 - Provider boundary is redacted.
        msg = "Structured extraction Provider metadata is unavailable"
        _raise_redacted_translation(exc, ProviderResponseError(msg))
    if not identity_matches or not usage_matches:
        msg = "Structured extraction Provider identity or usage is inconsistent"
        raise ProviderResponseError(msg)
    quality_valid = True
    try:
        _validate_local_ocr_provider_quality_result(
            report=metadata.local_ocr_quality_report,
            usage=usage,
            expected_policy=expected_quality_policy,
            preprocessing_report=metadata.local_ocr_preprocessing_report,
        )
    except ValueError:
        quality_valid = False
    if not quality_valid:
        msg = "Structured extraction Provider Local quality evidence is inconsistent"
        raise ProviderResponseError(msg) from ValueError("redacted")
    if not isinstance(result.data, Document):
        msg = "Structured extraction Provider returned no valid Document"
        raise ProviderResponseError(msg)
    return result


def _provider_required() -> Never:
    """Raise one sanitized explicit-Provider requirement."""
    msg = "The selected strategy requires an explicit OCR Provider"
    raise StructuredExtractionProviderRequiredError(msg)


def analyze_pdf_structured(
    path: Path,
    schema: ExtractionSchema,
    *,
    ocr_provider: OcrProvider | None = None,
    options: StructuredExtractionOptions | None = None,
    limits: PdfProcessingLimits | None = None,
) -> StructuredExtractionResult:
    """Analyze one PDF through an explicit strategy and return final fields."""
    schema, effective_options = _validated_schema_options(schema, options)
    effective_limits = _validated_pdf_limits(limits)
    _validate_local_quality_provider(effective_options, ocr_provider)

    return _analyze_pdf_structured_effective(
        path,
        schema,
        ocr_provider=ocr_provider,
        options=effective_options,
        limits=effective_limits,
    )


def _analyze_pdf_structured_prepared(  # noqa: PLR0913
    path: Path,
    schema: ExtractionSchema,
    *,
    inspection: PdfInspection,
    ocr_provider: OcrProvider | None,
    options: StructuredExtractionOptions | None,
    limits: PdfProcessingLimits | None,
    local_prepared_source: object,
    local_invocation_state: _LocalOcrInvocationState | None = None,
) -> StructuredExtractionResult:
    """Reuse a Local-aware PDF inspection for Structured Extraction."""
    schema, effective_options = _validated_schema_options(schema, options)
    effective_limits = _validated_pdf_limits(limits)
    _validate_local_quality_provider(effective_options, ocr_provider)
    return _analyze_pdf_structured_effective(
        path,
        schema,
        ocr_provider=ocr_provider,
        options=effective_options,
        limits=effective_limits,
        inspection=inspection,
        local_prepared_source=local_prepared_source,
        local_invocation_state=local_invocation_state,
    )


def _analyze_pdf_structured_effective(  # noqa: PLR0913
    path: Path,
    schema: ExtractionSchema,
    *,
    ocr_provider: OcrProvider | None,
    options: StructuredExtractionOptions,
    limits: PdfProcessingLimits | None,
    inspection: PdfInspection | None = None,
    local_prepared_source: object | None = None,
    local_invocation_state: _LocalOcrInvocationState | None = None,
) -> StructuredExtractionResult:
    """Execute one validated strategy with optional prepared Local evidence."""
    effective_options = options
    _validate_local_quality_provider(effective_options, ocr_provider)
    enable_local_ocr_quality = effective_options.local_ocr_quality_policy is not None

    if effective_options.strategy is ExtractionStrategy.HYBRID_EXISTING:
        hybrid_options = HybridPdfAnalysisOptions(
            locale=effective_options.locale,
            features=effective_options.features,
        )
        if inspection is None:
            hybrid_result = _analyze_pdf_hybrid_effective(
                path,
                ocr_provider=ocr_provider,
                options=hybrid_options,
                limits=limits,
                enable_local_ocr_quality=enable_local_ocr_quality,
                local_invocation_state=local_invocation_state,
            )
        else:
            hybrid_result = _analyze_pdf_hybrid_prepared(
                path,
                inspection=inspection,
                ocr_provider=ocr_provider,
                options=hybrid_options,
                limits=limits,
                local_prepared_source=local_prepared_source,
                enable_local_ocr_quality=enable_local_ocr_quality,
                local_invocation_state=local_invocation_state,
            )
        if not isinstance(hybrid_result.data, Document):
            msg = "Hybrid structured extraction returned no valid Document"
            raise ProviderResponseError(msg)
        return _build_result(
            hybrid_result.data,
            schema,
            options=effective_options,
            warnings=hybrid_result.warnings,
            provider_usage=hybrid_result.metadata.provider_usage,
            cloud_execution_attempt=(hybrid_result.metadata.cloud_execution_attempt),
            external_issues=_provider_error_issue(hybrid_result.errors),
            intrinsic_quality_report=(hybrid_result.metadata.local_ocr_quality_report),
            preprocessing_report=(
                hybrid_result.metadata.local_ocr_preprocessing_report
            ),
        )

    if ocr_provider is None:
        _provider_required()

    query_fields: tuple[str, ...] = ()
    features = effective_options.features
    if effective_options.strategy is ExtractionStrategy.PROVIDER_QUERY_FIELDS:
        if len(schema.fields) > _MAX_QUERY_FIELDS:
            msg = "Azure Query Fields supports at most 20 schema fields"
            raise ExtractionSchemaError(msg)
        query_fields = tuple(field.name for field in schema.fields)
        features = tuple(
            sorted(
                {*features, DocumentAnalysisFeature.QUERY_FIELDS},
                key=lambda feature: feature.value,
            )
        )
    request_options = OcrAnalysisOptions(
        pages=effective_options.pages,
        locale=effective_options.locale,
        features=features,
        query_fields=query_fields,
    )
    if ocr_provider is None:  # pragma: no cover - narrowed above.
        _provider_required()
    provider_result = _provider_result(
        path,
        provider=ocr_provider,
        request_options=request_options,
        expected_query_field_count=len(query_fields),
        local_prepared_source=local_prepared_source,
        enable_local_ocr_quality=enable_local_ocr_quality,
        local_invocation_state=local_invocation_state,
    )
    if provider_result.data is None:  # pragma: no cover - validated above.
        msg = "Structured extraction Provider returned no valid Document"
        raise ProviderResponseError(msg)
    return _build_result(
        provider_result.data,
        schema,
        options=effective_options,
        warnings=provider_result.warnings,
        provider_usage=provider_result.metadata.provider_usage,
        cloud_execution_attempt=provider_result.metadata.cloud_execution_attempt,
        external_issues=_provider_error_issue(provider_result.errors),
        intrinsic_quality_report=provider_result.metadata.local_ocr_quality_report,
        preprocessing_report=(provider_result.metadata.local_ocr_preprocessing_report),
    )

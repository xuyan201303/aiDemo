"""Strict public models for provider-independent structured extraction."""

from __future__ import annotations

import json
import math
import re
import unicodedata
from collections import Counter
from collections.abc import Callable, Mapping
from datetime import date, time
from decimal import Decimal, DecimalException
from enum import StrEnum
from inspect import signature
from types import MappingProxyType
from typing import Any, Literal, Never, Self, cast

from pydantic import (
    ConfigDict,
    Field,
    GetJsonSchemaHandler,
    SerializerFunctionWrapHandler,
    ValidationInfo,
    field_serializer,
    field_validator,
    model_serializer,
    model_validator,
)
from pydantic.config import ExtraValues  # noqa: TC002
from pydantic.json_schema import JsonSchemaValue  # noqa: TC002
from pydantic_core import CoreSchema  # noqa: TC002

from document_sdk.core import (
    CloudExecutionAttemptEvidence,
    CloudExecutionAttemptStatus,
    Document,
    DocumentAddressValue,
    DocumentCurrencyValue,
    DocumentElementReference,
    DocumentField,
    ImageSourceReference,
    LocalOcrQualityReport,
    LocalOcrStructuredQualityPolicy,
    PdfSourceReference,
    ProcessingWarning,
    ProviderUsage,
    SourceReference,
)
from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.core.local_ocr_quality import (
    _local_ocr_quality_usage_matches,
    _validate_provider_usage,
    _validate_quality_report,
    _validate_structured_quality_policy,
)
from document_sdk.core.models import SdkModel
from document_sdk.ocr.models import DocumentAnalysisFeature
from document_sdk.ocr.preprocessing_models import (
    LocalOcrPreprocessingReport,
    _validate_preprocessing_quality_lineage,
)

_MAX_QUERY_FIELDS = 20
_MIN_AMBIGUOUS_CANDIDATES = 2
_ISSUE_MESSAGE = "Structured extraction could not fully resolve a schema rule."
_DECIMAL_JSON_PATTERN = r"^[+-]?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?$"
_MODEL_VALIDATE_PARAMETERS = frozenset(signature(SdkModel.model_validate).parameters)
_MODEL_VALIDATE_JSON_PARAMETERS = frozenset(
    signature(SdkModel.model_validate_json).parameters
)
type _ConstraintValue = (
    str
    | int
    | Decimal
    | bool
    | date
    | time
    | tuple[str, ...]
    | DocumentCurrencyValue
    | DocumentAddressValue
)
_SAFE_ISSUE_CATEGORIES = frozenset(
    {
        "ambiguous_candidates",
        "constraint_allowed_values",
        "constraint_maximum",
        "constraint_maximum_length",
        "constraint_minimum",
        "constraint_minimum_length",
        "constraint_pattern",
        "document_type_rejected",
        "document_type_unavailable",
        "low_confidence",
        "missing_value",
        "provider_partial_errors",
        "raw_value_not_normalized",
        "required_field_missing",
        "value_type_invalid",
    }
)


def _is_finite_json_node(  # noqa: PLR0911
    value: object,
    seen: set[int],
) -> bool:
    """Check one JSON node while rejecting recursive containers."""
    if value is None or type(value) in {bool, int, str}:
        return True
    if type(value) is float:
        return math.isfinite(value)
    if type(value) is list:
        identity = id(value)
        if identity in seen:
            return False
        seen.add(identity)
        try:
            return all(_is_finite_json_node(item, seen) for item in value)
        finally:
            seen.remove(identity)
    if type(value) is dict:
        identity = id(value)
        if identity in seen:
            return False
        seen.add(identity)
        try:
            return all(
                type(key) is str and _is_finite_json_node(item, seen)
                for key, item in value.items()
            )
        finally:
            seen.remove(identity)
    return False


def _is_finite_json_value(value: object) -> bool:
    """Return whether a value is made only from finite, acyclic JSON nodes."""
    try:
        return _is_finite_json_node(value, set())
    except RecursionError:
        return False


def _supported_validation_options(
    supported: frozenset[str],
    **options: Any,
) -> dict[str, Any]:
    """Forward only options implemented by the installed Pydantic release."""
    unsupported = tuple(
        sorted(
            name
            for name, value in options.items()
            if value is not None and name not in supported
        )
    )
    if unsupported:
        names = ", ".join(unsupported)
        msg = f"Installed Pydantic does not support validation option(s): {names}"
        raise TypeError(msg)
    return {
        name: value
        for name, value in options.items()
        if value is not None and name in supported
    }


class _JsonDictionaryRoundTripModel(SdkModel):
    """Restore a model's own pure JSON dictionary through JSON validation."""

    model_config = ConfigDict(revalidate_instances="subclass-instances")

    @classmethod
    def model_validate(  # noqa: PLR0913
        cls,
        obj: Any,
        *,
        strict: bool | None = None,
        extra: ExtraValues | None = None,
        from_attributes: bool | None = None,
        context: Any | None = None,
        by_alias: bool | None = None,
        by_name: bool | None = None,
    ) -> Self:
        """Give JSON dictionaries the same semantics as JSON strings."""
        if (
            from_attributes is not True
            and type(obj) is dict
            and _is_finite_json_value(obj)
        ):
            options = _supported_validation_options(
                _MODEL_VALIDATE_JSON_PARAMETERS,
                strict=strict,
                extra=extra,
                context=context,
                by_alias=by_alias,
                by_name=by_name,
            )
            return cls.model_validate_json(
                json.dumps(
                    obj,
                    allow_nan=False,
                    ensure_ascii=False,
                    separators=(",", ":"),
                ),
                **options,
            )
        options = _supported_validation_options(
            _MODEL_VALIDATE_PARAMETERS,
            strict=strict,
            extra=extra,
            from_attributes=from_attributes,
            context=context,
            by_alias=by_alias,
            by_name=by_name,
        )
        return super().model_validate(
            obj,
            **options,
        )


def _display_name(value: str) -> str:
    """Normalize caller terminology without changing its case."""
    return " ".join(unicodedata.normalize("NFKC", value).strip().split())


def _matching_name(value: str) -> str:
    """Return the deterministic schema/name matching form."""
    return _display_name(value).casefold()


def _source_key(source: object) -> str:
    """Return deterministic public source evidence without interpretation."""
    serializer = getattr(source, "model_dump_json", None)
    if not callable(serializer):
        return ""
    value = serializer()
    return value if isinstance(value, str) else ""


class ExtractionValueType(StrEnum):
    """Supported provider-independent structured value families."""

    STRING = "string"
    INTEGER = "integer"
    DECIMAL = "decimal"
    NUMBER = "number"
    BOOLEAN = "boolean"
    DATE = "date"
    TIME = "time"
    PHONE_NUMBER = "phone_number"
    COUNTRY_REGION = "country_region"
    SELECTION_MARK = "selection_mark"
    SELECTION_GROUP = "selection_group"
    SIGNATURE = "signature"
    CURRENCY = "currency"
    ADDRESS = "address"
    ARRAY = "array"
    OBJECT = "object"


class ExtractionStrategy(StrEnum):
    """Explicit document-analysis routes used before local extraction."""

    HYBRID_EXISTING = "hybrid_existing"
    PROVIDER_EXISTING = "provider_existing"
    PROVIDER_QUERY_FIELDS = "provider_query_fields"


class DocumentTypeStatus(StrEnum):
    """Final eligibility state for schema-restricted document types."""

    NOT_RESTRICTED = "not_restricted"
    ACCEPTED = "accepted"
    UNAVAILABLE = "unavailable"
    REJECTED = "rejected"


class ExtractionConfidenceSource(StrEnum):
    """Provenance of one candidate confidence observation."""

    UNAVAILABLE = "unavailable"
    PROVIDER_REPORTED = "provider_reported"
    DERIVED = "derived"


class ConstraintValueType(StrEnum):
    """Exact immutable value families supported by allowed-value constraints."""

    STRING = "string"
    INTEGER = "integer"
    DECIMAL = "decimal"
    BOOLEAN = "boolean"
    DATE = "date"
    TIME = "time"
    SELECTION_GROUP = "selection_group"
    CURRENCY = "currency"
    ADDRESS = "address"


def _raise_constraint_value_error() -> Never:
    """Raise one content-free validation error for a tag/value mismatch."""
    msg = "Constraint value does not match its declared value type"
    raise ValueError(msg)


def _restore_decimal_json(value: object) -> Decimal:
    """Restore one finite Decimal only from the SDK's JSON string shape."""
    if type(value) is not str or re.fullmatch(_DECIMAL_JSON_PATTERN, value) is None:
        _raise_constraint_value_error()
    try:
        restored = Decimal(value)
    except DecimalException:
        _raise_constraint_value_error()
    if not restored.is_finite():
        _raise_constraint_value_error()
    return restored


def _restore_currency_json(value: object) -> DocumentCurrencyValue:
    """Restore one frozen currency from its exact public JSON mapping."""
    if type(value) is not dict or set(value) - set(DocumentCurrencyValue.model_fields):
        _raise_constraint_value_error()
    amount = value.get("amount")
    if type(amount) is not str:
        _raise_constraint_value_error()
    restored = dict(value)
    restored["amount"] = _restore_decimal_json(amount)
    return DocumentCurrencyValue.model_validate(restored)


def _restore_address_json(value: object) -> DocumentAddressValue:
    """Restore one frozen address from its exact public JSON mapping."""
    if type(value) is not dict or set(value) - set(DocumentAddressValue.model_fields):
        _raise_constraint_value_error()
    return DocumentAddressValue.model_validate(value)


def _restore_string_json(value: object) -> str:
    """Restore one exact JSON string."""
    if type(value) is not str:
        _raise_constraint_value_error()
    return value


def _restore_integer_json(value: object) -> int:
    """Restore one exact non-boolean JSON integer."""
    if type(value) is not int:
        _raise_constraint_value_error()
    return value


def _restore_boolean_json(value: object) -> bool:
    """Restore one exact JSON boolean."""
    if type(value) is not bool:
        _raise_constraint_value_error()
    return value


def _restore_date_json(value: object) -> date:
    """Restore one exact ISO date string."""
    if type(value) is not str:
        _raise_constraint_value_error()
    try:
        return date.fromisoformat(value)
    except ValueError:
        _raise_constraint_value_error()


def _restore_time_json(value: object) -> time:
    """Restore one exact ISO time string."""
    if type(value) is not str:
        _raise_constraint_value_error()
    try:
        return time.fromisoformat(value)
    except ValueError:
        _raise_constraint_value_error()


def _restore_selection_group_json(value: object) -> tuple[str, ...]:
    """Restore one JSON string array as an immutable tuple."""
    if type(value) is not list or not all(type(item) is str for item in value):
        _raise_constraint_value_error()
    return tuple(cast("list[str]", value))


_CONSTRAINT_JSON_RESTORERS: dict[
    ConstraintValueType,
    Callable[[object], _ConstraintValue],
] = {
    ConstraintValueType.STRING: _restore_string_json,
    ConstraintValueType.INTEGER: _restore_integer_json,
    ConstraintValueType.DECIMAL: _restore_decimal_json,
    ConstraintValueType.BOOLEAN: _restore_boolean_json,
    ConstraintValueType.DATE: _restore_date_json,
    ConstraintValueType.TIME: _restore_time_json,
    ConstraintValueType.SELECTION_GROUP: _restore_selection_group_json,
    ConstraintValueType.CURRENCY: _restore_currency_json,
    ConstraintValueType.ADDRESS: _restore_address_json,
}


_CONSTRAINT_PYTHON_TYPES: dict[ConstraintValueType, type[object]] = {
    ConstraintValueType.STRING: str,
    ConstraintValueType.INTEGER: int,
    ConstraintValueType.DECIMAL: Decimal,
    ConstraintValueType.BOOLEAN: bool,
    ConstraintValueType.DATE: date,
    ConstraintValueType.TIME: time,
    ConstraintValueType.SELECTION_GROUP: tuple,
    ConstraintValueType.CURRENCY: DocumentCurrencyValue,
    ConstraintValueType.ADDRESS: DocumentAddressValue,
}


def _is_exact_constraint_value(
    value_type: ConstraintValueType,
    value: object,
) -> bool:
    """Return whether a Python value is the exact immutable tagged type."""
    if type(value) is not _CONSTRAINT_PYTHON_TYPES[value_type]:
        return False
    if value_type is ConstraintValueType.DECIMAL:
        return cast("Decimal", value).is_finite()
    if value_type is ConstraintValueType.SELECTION_GROUP:
        return all(type(item) is str for item in cast("tuple[object, ...]", value))
    return True


def _restore_constraint_json_value(
    value_type: ConstraintValueType,
    value: object,
) -> _ConstraintValue:
    """Restore one value using only its explicit public discriminator."""
    return _CONSTRAINT_JSON_RESTORERS[value_type](value)


def _constraint_schema_alternative(
    value_type: ConstraintValueType,
    value_schema: JsonSchemaValue,
) -> JsonSchemaValue:
    """Build one exact discriminator/value JSON Schema alternative."""
    return {
        "additionalProperties": False,
        "properties": {
            "value_type": {
                "const": value_type.value,
                "type": "string",
            },
            "value": value_schema,
        },
        "required": ["value_type", "value"],
        "type": "object",
    }


class FieldConstraintValue(_JsonDictionaryRoundTripModel):
    """One explicitly typed, deeply immutable allowed value."""

    value_type: ConstraintValueType
    value: (
        str
        | int
        | Decimal
        | bool
        | date
        | time
        | tuple[str, ...]
        | DocumentCurrencyValue
        | DocumentAddressValue
    )

    @field_validator("value", mode="before")
    @classmethod
    def restore_json_value(cls, value: object, info: ValidationInfo) -> object:
        """Restore JSON values only through their already validated tag."""
        value_type = info.data.get("value_type")
        if not isinstance(value_type, ConstraintValueType):
            return value
        if info.mode == "json":
            return _restore_constraint_json_value(value_type, value)
        if not _is_exact_constraint_value(value_type, value):
            _raise_constraint_value_error()
        return value

    @model_validator(mode="after")
    def validate_exact_type(self) -> Self:
        """Prevent Python equality from conflating distinct scalar families."""
        if not _is_exact_constraint_value(self.value_type, self.value):
            msg = "Constraint value does not match its declared value type"
            raise ValueError(msg)
        return self

    @classmethod
    def __get_pydantic_json_schema__(
        cls,
        core_schema: CoreSchema,
        handler: GetJsonSchemaHandler,
    ) -> JsonSchemaValue:
        """Describe value_type and value as nine exact paired alternatives."""
        schema = super().__get_pydantic_json_schema__(core_schema, handler)
        value_options = schema["properties"]["value"]["anyOf"]
        model_names = ("DocumentCurrencyValue", "DocumentAddressValue")
        model_references = {
            model_name: dict(option)
            for model_name in model_names
            for option in value_options
            if isinstance(option, dict)
            and isinstance(option.get("$ref"), str)
            and model_name in option["$ref"]
        }
        if set(model_references) != set(model_names):
            msg = "Constraint value JSON Schema model references are unavailable"
            raise RuntimeError(msg)
        for key in ("additionalProperties", "properties", "required", "type"):
            schema.pop(key, None)
        schema["oneOf"] = [
            _constraint_schema_alternative(
                ConstraintValueType.STRING,
                {"type": "string"},
            ),
            _constraint_schema_alternative(
                ConstraintValueType.INTEGER,
                {"type": "integer"},
            ),
            _constraint_schema_alternative(
                ConstraintValueType.DECIMAL,
                {
                    "pattern": _DECIMAL_JSON_PATTERN,
                    "type": "string",
                },
            ),
            _constraint_schema_alternative(
                ConstraintValueType.BOOLEAN,
                {"type": "boolean"},
            ),
            _constraint_schema_alternative(
                ConstraintValueType.DATE,
                {
                    "format": "date",
                    "type": "string",
                },
            ),
            _constraint_schema_alternative(
                ConstraintValueType.TIME,
                {
                    "format": "time",
                    "type": "string",
                },
            ),
            _constraint_schema_alternative(
                ConstraintValueType.SELECTION_GROUP,
                {
                    "items": {"type": "string"},
                    "type": "array",
                },
            ),
            _constraint_schema_alternative(
                ConstraintValueType.CURRENCY,
                model_references["DocumentCurrencyValue"],
            ),
            _constraint_schema_alternative(
                ConstraintValueType.ADDRESS,
                model_references["DocumentAddressValue"],
            ),
        ]
        return schema


def _constraint_value(value: object) -> FieldConstraintValue:
    """Wrap one supported Python value without lossy type inference."""
    if type(value) is FieldConstraintValue:
        return value
    exact_types = {
        bool: ConstraintValueType.BOOLEAN,
        int: ConstraintValueType.INTEGER,
        str: ConstraintValueType.STRING,
    }
    value_type = exact_types.get(type(value))
    if type(value) is Decimal:
        value_type = ConstraintValueType.DECIMAL
    elif type(value) is date:
        value_type = ConstraintValueType.DATE
    elif type(value) is time:
        value_type = ConstraintValueType.TIME
    elif type(value) is tuple and all(type(item) is str for item in value):
        value_type = ConstraintValueType.SELECTION_GROUP
    elif type(value) is DocumentCurrencyValue:
        value_type = ConstraintValueType.CURRENCY
    elif type(value) is DocumentAddressValue:
        value_type = ConstraintValueType.ADDRESS
    if value_type is None:
        msg = "Allowed values must use supported immutable extraction value types"
        raise ValueError(msg)
    immutable_value = cast("_ConstraintValue", value)
    return FieldConstraintValue(value_type=value_type, value=immutable_value)


class FieldConstraints(_JsonDictionaryRoundTripModel):
    """Generic trusted caller constraints for one extracted value."""

    allowed_values: tuple[FieldConstraintValue, ...] = ()
    minimum: Decimal | None = None
    maximum: Decimal | None = None
    minimum_length: int | None = Field(default=None, ge=0)
    maximum_length: int | None = Field(default=None, ge=0)
    pattern: str | None = None

    @classmethod
    def model_validate(  # noqa: PLR0913
        cls,
        obj: Any,
        *,
        strict: bool | None = None,
        extra: ExtraValues | None = None,
        from_attributes: bool | None = None,
        context: Any | None = None,
        by_alias: bool | None = None,
        by_name: bool | None = None,
    ) -> Self:
        """Restore serialized bounds without loosening normal constructors."""
        normalized = obj
        if from_attributes is not True and type(obj) is dict:
            restored = dict(obj)
            for field_name in ("minimum", "maximum"):
                value = restored.get(field_name)
                if type(value) is not str:
                    continue
                try:
                    restored[field_name] = _restore_decimal_json(value)
                except ValueError:
                    continue
            normalized = restored
        return super().model_validate(
            normalized,
            strict=strict,
            extra=extra,
            from_attributes=from_attributes,
            context=context,
            by_alias=by_alias,
            by_name=by_name,
        )

    @field_validator("minimum", "maximum", mode="before")
    @classmethod
    def restore_decimal_bound(cls, value: object, info: ValidationInfo) -> object:
        """Accept only native Decimals or the SDK's JSON string encoding."""
        if value is None or type(value) is Decimal:
            return value
        if info.mode == "json" and type(value) is str:
            return _restore_decimal_json(value)
        msg = "Field constraint decimal bounds require finite Decimal values"
        raise ValueError(msg)

    @field_validator("allowed_values", mode="before")
    @classmethod
    def freeze_allowed_values(cls, value: object, info: ValidationInfo) -> object:
        """Convert Python scalars and preserve typed JSON objects."""
        del info
        if not isinstance(value, tuple | list):
            return value
        return tuple(
            FieldConstraintValue.model_validate(item)
            if type(item) is dict
            else _constraint_value(item)
            for item in value
        )

    @model_validator(mode="after")
    def validate_constraint_configuration(self) -> Self:
        """Reject contradictory bounds and invalid trusted regex syntax."""
        if (
            self.minimum is not None
            and self.maximum is not None
            and self.minimum > self.maximum
        ):
            msg = "Field constraint minimum must not exceed maximum"
            raise ValueError(msg)
        if (
            self.minimum_length is not None
            and self.maximum_length is not None
            and self.minimum_length > self.maximum_length
        ):
            msg = "Field constraint minimum_length must not exceed maximum_length"
            raise ValueError(msg)
        if self.pattern is not None:
            if not self.pattern:
                msg = "Field constraint pattern must not be empty"
                raise ValueError(msg)
            try:
                re.compile(self.pattern)
            except re.error as exc:
                msg = "Field constraint pattern is invalid"
                _raise_redacted_translation(exc, ValueError(msg))
        unique = {value.model_dump_json(): value for value in self.allowed_values}
        object.__setattr__(
            self,
            "allowed_values",
            tuple(unique[key] for key in sorted(unique)),
        )
        return self


def _expected_document_field_type(value_type: ExtractionValueType) -> str:
    """Map a schema type to the final provider-independent field family."""
    return {
        ExtractionValueType.STRING: "string",
        ExtractionValueType.INTEGER: "integer",
        ExtractionValueType.DECIMAL: "number",
        ExtractionValueType.NUMBER: "number",
        ExtractionValueType.BOOLEAN: "boolean",
        ExtractionValueType.DATE: "date",
        ExtractionValueType.TIME: "time",
        ExtractionValueType.PHONE_NUMBER: "phoneNumber",
        ExtractionValueType.COUNTRY_REGION: "countryRegion",
        ExtractionValueType.SELECTION_MARK: "selectionMark",
        ExtractionValueType.SELECTION_GROUP: "selectionGroup",
        ExtractionValueType.SIGNATURE: "signature",
        ExtractionValueType.CURRENCY: "currency",
        ExtractionValueType.ADDRESS: "address",
        ExtractionValueType.ARRAY: "array",
        ExtractionValueType.OBJECT: "object",
    }[value_type]


def _numeric_value(value: object) -> Decimal | None:
    """Return one precision-preserving constraint value."""
    if type(value) is int:
        return Decimal(value)
    if isinstance(value, Decimal):
        return value
    return None


def _allowed_value_matches(
    value: object,
    allowed_value: FieldConstraintValue,
) -> bool:
    """Compare normalized values without Python cross-type equality."""
    expected = allowed_value.value
    value_type = allowed_value.value_type
    matches = False
    if value_type is ConstraintValueType.STRING:
        matches = isinstance(value, str) and value == expected
    elif value_type is ConstraintValueType.INTEGER:
        matches = type(value) is int and value == expected
    elif value_type is ConstraintValueType.DECIMAL:
        matches = isinstance(value, Decimal) and value == expected
    elif value_type is ConstraintValueType.BOOLEAN:
        matches = type(value) is bool and value == expected
    elif value_type is ConstraintValueType.DATE:
        matches = type(value) is date and value == expected
    elif value_type is ConstraintValueType.TIME:
        matches = isinstance(value, time) and value == expected
    elif value_type is ConstraintValueType.SELECTION_GROUP:
        matches = isinstance(value, tuple) and value == expected
    elif value_type in {
        ConstraintValueType.CURRENCY,
        ConstraintValueType.ADDRESS,
    }:
        matches = type(value) is type(expected) and value == expected
    return matches


def _constraint_categories(
    value: object,
    constraints: FieldConstraints,
) -> tuple[str, ...]:
    """Return only safe categories for violated generic constraints."""
    categories: list[str] = []
    if constraints.allowed_values and not any(
        _allowed_value_matches(value, allowed_value)
        for allowed_value in constraints.allowed_values
    ):
        categories.append("allowed_values")
    numeric = _numeric_value(value)
    if constraints.minimum is not None and (
        numeric is None or numeric < constraints.minimum
    ):
        categories.append("minimum")
    if constraints.maximum is not None and (
        numeric is None or numeric > constraints.maximum
    ):
        categories.append("maximum")
    length = len(value) if isinstance(value, str | tuple | Mapping) else None
    if constraints.minimum_length is not None and (
        length is None or length < constraints.minimum_length
    ):
        categories.append("minimum_length")
    if constraints.maximum_length is not None and (
        length is None or length > constraints.maximum_length
    ):
        categories.append("maximum_length")
    if constraints.pattern is not None and (
        not isinstance(value, str) or re.fullmatch(constraints.pattern, value) is None
    ):
        categories.append("pattern")
    return tuple(categories)


class FieldDefinition(_JsonDictionaryRoundTripModel):
    """One canonical business field and its generic extraction rules."""

    name: str = Field(min_length=1)
    value_type: ExtractionValueType
    required: bool = False
    aliases: tuple[str, ...] = ()
    allow_multiple: bool = False
    min_confidence: float | None = Field(default=None, ge=0, le=1)
    constraints: FieldConstraints = Field(default_factory=FieldConstraints)

    @field_validator("name")
    @classmethod
    def normalize_name(cls, value: str) -> str:
        """Store one non-empty deterministic canonical display name."""
        normalized = _display_name(value)
        if not normalized:
            msg = "Extraction field name must not be empty"
            raise ValueError(msg)
        return normalized

    @model_validator(mode="after")
    def normalize_aliases(self) -> Self:
        """Normalize aliases and validate type-compatible constraints."""
        normalized = tuple(_display_name(alias) for alias in self.aliases)
        if any(not alias for alias in normalized):
            msg = "Extraction field aliases must not be empty"
            raise ValueError(msg)
        keys = tuple(_matching_name(alias) for alias in normalized)
        if len(keys) != len(set(keys)) or _matching_name(self.name) in keys:
            msg = "Extraction field aliases must be unique and unambiguous"
            raise ValueError(msg)
        object.__setattr__(
            self,
            "aliases",
            tuple(alias for _, alias in sorted(zip(keys, normalized, strict=True))),
        )
        numeric_types = {
            ExtractionValueType.INTEGER,
            ExtractionValueType.DECIMAL,
            ExtractionValueType.NUMBER,
        }
        string_types = {
            ExtractionValueType.STRING,
            ExtractionValueType.PHONE_NUMBER,
            ExtractionValueType.COUNTRY_REGION,
            ExtractionValueType.SELECTION_MARK,
            ExtractionValueType.SIGNATURE,
        }
        length_types = {
            *string_types,
            ExtractionValueType.SELECTION_GROUP,
            ExtractionValueType.ARRAY,
            ExtractionValueType.OBJECT,
        }
        constraints = self.constraints
        if (
            constraints.minimum is not None or constraints.maximum is not None
        ) and self.value_type not in numeric_types:
            msg = "Numeric bounds require an integer, decimal, or number field"
            raise ValueError(msg)
        if constraints.pattern is not None and self.value_type not in string_types:
            msg = "Pattern constraints require a string-like field"
            raise ValueError(msg)
        if (
            constraints.minimum_length is not None
            or constraints.maximum_length is not None
        ) and self.value_type not in length_types:
            msg = "Length constraints are not supported for this field type"
            raise ValueError(msg)
        allowed_value_type = {
            ExtractionValueType.STRING: ConstraintValueType.STRING,
            ExtractionValueType.INTEGER: ConstraintValueType.INTEGER,
            ExtractionValueType.DECIMAL: ConstraintValueType.DECIMAL,
            ExtractionValueType.NUMBER: ConstraintValueType.DECIMAL,
            ExtractionValueType.BOOLEAN: ConstraintValueType.BOOLEAN,
            ExtractionValueType.DATE: ConstraintValueType.DATE,
            ExtractionValueType.TIME: ConstraintValueType.TIME,
            ExtractionValueType.PHONE_NUMBER: ConstraintValueType.STRING,
            ExtractionValueType.COUNTRY_REGION: ConstraintValueType.STRING,
            ExtractionValueType.SELECTION_MARK: ConstraintValueType.STRING,
            ExtractionValueType.SELECTION_GROUP: ConstraintValueType.SELECTION_GROUP,
            ExtractionValueType.SIGNATURE: ConstraintValueType.STRING,
            ExtractionValueType.CURRENCY: ConstraintValueType.CURRENCY,
            ExtractionValueType.ADDRESS: ConstraintValueType.ADDRESS,
            ExtractionValueType.ARRAY: None,
            ExtractionValueType.OBJECT: None,
        }[self.value_type]
        if constraints.allowed_values and (
            allowed_value_type is None
            or any(
                value.value_type is not allowed_value_type
                for value in constraints.allowed_values
            )
        ):
            msg = "Allowed values do not match the extraction field type"
            raise ValueError(msg)
        return self


class ExtractionSchema(_JsonDictionaryRoundTripModel):
    """A deterministic customer-supplied extraction schema."""

    schema_id: str = Field(min_length=1)
    schema_version: str = Field(min_length=1)
    fields: tuple[FieldDefinition, ...] = Field(min_length=1)
    accepted_document_types: tuple[str, ...] = ()

    @field_validator("schema_id", "schema_version")
    @classmethod
    def normalize_identifier(cls, value: str) -> str:
        """Trim required schema identifiers without interpreting them."""
        normalized = value.strip()
        if not normalized:
            msg = "Extraction schema identifiers must not be empty"
            raise ValueError(msg)
        return normalized

    @model_validator(mode="after")
    def validate_schema_names(self) -> Self:
        """Reject ambiguous terminology and store fields deterministically."""
        fields = tuple(
            sorted(self.fields, key=lambda field: _matching_name(field.name))
        )
        canonical_owners: dict[str, str] = {}
        for field in fields:
            key = _matching_name(field.name)
            if key in canonical_owners:
                msg = "Extraction schema field names must be unique"
                raise ValueError(msg)
            canonical_owners[key] = field.name
        alias_owners: dict[str, str] = {}
        for field in fields:
            for alias in field.aliases:
                key = _matching_name(alias)
                if key in canonical_owners or key in alias_owners:
                    msg = "Extraction schema aliases must be globally unambiguous"
                    raise ValueError(msg)
                alias_owners[key] = field.name
        accepted = tuple(
            sorted({_matching_name(value) for value in self.accepted_document_types})
        )
        if any(not value for value in accepted):
            msg = "Accepted document types must not be empty"
            raise ValueError(msg)
        object.__setattr__(self, "fields", fields)
        object.__setattr__(self, "accepted_document_types", accepted)
        return self


class StructuredExtractionOptions(SdkModel):
    """Explicit extraction, analysis, and conservative coercion options."""

    strategy: ExtractionStrategy = ExtractionStrategy.HYBRID_EXISTING
    pages: tuple[int, ...] | None = None
    locale: str | None = None
    features: tuple[DocumentAnalysisFeature, ...] = ()
    coerce_raw_values: bool = True
    fail_on_incomplete: bool = False
    local_ocr_quality_policy: LocalOcrStructuredQualityPolicy | None = None

    @field_validator("locale")
    @classmethod
    def normalize_locale(cls, value: str | None) -> str | None:
        """Normalize one optional non-empty Provider locale."""
        if value is None:
            return None
        normalized = value.strip()
        if not normalized:
            msg = "Structured extraction locale must not be empty"
            raise ValueError(msg)
        return normalized

    @model_validator(mode="after")
    def normalize_analysis_options(self) -> Self:
        """Normalize pages/features and reject implicit premium requests."""
        object.__setattr__(
            self,
            "local_ocr_quality_policy",
            _validate_structured_quality_policy(self.local_ocr_quality_policy),
        )
        object.__setattr__(
            self,
            "features",
            tuple(sorted(set(self.features), key=lambda feature: feature.value)),
        )
        if self.pages is not None:
            if not self.pages or any(
                type(page) is not int or page < 1 for page in self.pages
            ):
                msg = "Structured extraction pages must be positive integers"
                raise ValueError(msg)
            object.__setattr__(self, "pages", tuple(sorted(set(self.pages))))
        query_feature = DocumentAnalysisFeature.QUERY_FIELDS
        if (
            self.strategy is not ExtractionStrategy.PROVIDER_QUERY_FIELDS
            and query_feature in self.features
        ):
            msg = "Query Fields require the provider_query_fields strategy"
            raise ValueError(msg)
        if (
            self.strategy is ExtractionStrategy.HYBRID_EXISTING
            and self.pages is not None
        ):
            msg = "Hybrid structured extraction controls OCR page selection"
            raise ValueError(msg)
        return self


class StructuredFieldCandidate(SdkModel):
    """One provider-independent field candidate with complete evidence."""

    source_kind: Literal["analyzed_field", "key_value_pair"]
    matched_name: str
    match_kind: Literal["canonical", "alias"]
    field: DocumentField
    confidence: float | None = Field(default=None, ge=0, le=1)
    confidence_source: ExtractionConfidenceSource = (
        ExtractionConfidenceSource.UNAVAILABLE
    )
    confidence_usable_for_thresholds: bool = False
    sources: tuple[SourceReference, ...] = ()
    elements: tuple[DocumentElementReference, ...] = ()
    document_type: str | None = None

    @field_validator("matched_name")
    @classmethod
    def normalize_matched_name(cls, value: str) -> str:
        """Store one normalized, non-empty matched schema term."""
        normalized = _display_name(value)
        if not normalized:
            msg = "Structured field candidate matched name must not be empty"
            raise ValueError(msg)
        return normalized

    @field_validator("document_type")
    @classmethod
    def normalize_document_type(cls, value: str | None) -> str | None:
        """Normalize optional analyzed-document type evidence."""
        if value is None:
            return None
        normalized = _display_name(value)
        if not normalized:
            msg = "Structured field candidate document type must not be empty"
            raise ValueError(msg)
        return normalized

    @model_validator(mode="after")
    def validate_evidence_consistency(self) -> Self:
        """Reject fabricated or contradictory public candidate evidence."""
        if self.sources != self.field.sources:
            msg = "Structured field candidate sources must match field sources"
            raise ValueError(msg)
        if self.confidence != self.field.confidence:
            msg = "Structured field candidate confidence must match field confidence"
            raise ValueError(msg)
        if (self.confidence is None) != (
            self.confidence_source is ExtractionConfidenceSource.UNAVAILABLE
        ):
            msg = "Structured field candidate confidence provenance is inconsistent"
            raise ValueError(msg)
        if self.confidence is None and self.confidence_usable_for_thresholds:
            msg = "Unavailable confidence cannot satisfy thresholds"
            raise ValueError(msg)
        if self.source_kind == "analyzed_field" and self.document_type is None:
            msg = "Analyzed field candidates require a document type"
            raise ValueError(msg)
        if self.source_kind == "key_value_pair" and self.document_type is not None:
            msg = "Key-value candidates cannot contain a document type"
            raise ValueError(msg)
        if self.elements:
            msg = "Deterministic candidates cannot contain element evidence"
            raise ValueError(msg)
        return self


class StructuredExtractionIssue(SdkModel):
    """One content-free extraction or validation issue."""

    code: str = Field(min_length=1)
    category: str = Field(min_length=1)
    message: str = Field(min_length=1)
    severity: Literal["warning", "error"]
    field_name: str | None = None
    count: int = Field(default=1, ge=1)

    @model_validator(mode="after")
    def validate_safe_taxonomy(self) -> Self:
        """Keep public issue diagnostics within the content-free taxonomy."""
        if self.category not in _SAFE_ISSUE_CATEGORIES:
            msg = "Structured extraction issue category is not supported"
            raise ValueError(msg)
        if self.code != f"structured_extraction.{self.category}":
            msg = "Structured extraction issue code is inconsistent"
            raise ValueError(msg)
        if self.message != _ISSUE_MESSAGE:
            msg = "Structured extraction issue message is inconsistent"
            raise ValueError(msg)
        return self


def _candidate_match_kind(
    candidate: StructuredFieldCandidate,
    definition: FieldDefinition,
) -> Literal["canonical", "alias"] | None:
    """Return the actual deterministic schema match for one candidate."""
    matched = _matching_name(candidate.matched_name)
    if matched == _matching_name(definition.name):
        return "canonical"
    if matched in {_matching_name(alias) for alias in definition.aliases}:
        return "alias"
    return None


def _candidate_priority(candidate: StructuredFieldCandidate) -> int:
    """Return the documented public candidate priority."""
    return {
        ("analyzed_field", "canonical"): 0,
        ("analyzed_field", "alias"): 1,
        ("key_value_pair", "canonical"): 2,
        ("key_value_pair", "alias"): 3,
    }[(candidate.source_kind, candidate.match_kind)]


def _candidate_public_key(candidate: StructuredFieldCandidate) -> str:
    """Return canonical JSON identity for public candidate evidence."""
    return json.dumps(
        candidate.model_dump(mode="json"),
        sort_keys=True,
        separators=(",", ":"),
    )


def _candidate_order_key(
    candidate: StructuredFieldCandidate,
) -> tuple[object, ...]:
    """Return deterministic ordering based only on public evidence."""
    return (
        _candidate_priority(candidate),
        candidate.source_kind,
        _matching_name(candidate.matched_name),
        candidate.document_type or "",
        _candidate_public_key(candidate),
    )


def _issue_public_key(issue: StructuredExtractionIssue) -> str:
    """Return canonical public issue identity."""
    return json.dumps(
        issue.model_dump(mode="json"),
        sort_keys=True,
        separators=(",", ":"),
    )


def _has_issue(
    issues: tuple[StructuredExtractionIssue, ...],
    category: str,
    severity: Literal["warning", "error"],
) -> bool:
    """Return whether one exact safe issue kind is present."""
    return any(
        issue.category == category and issue.severity == severity for issue in issues
    )


class StructuredFieldResult(SdkModel):
    """Final deterministic resolution state for one schema field."""

    name: str = Field(min_length=1)
    definition: FieldDefinition
    status: Literal[
        "found",
        "missing",
        "ambiguous",
        "invalid",
        "low_confidence",
        "raw_only",
    ]
    selected: tuple[StructuredFieldCandidate, ...] = ()
    candidates: tuple[StructuredFieldCandidate, ...] = ()
    issues: tuple[StructuredExtractionIssue, ...] = ()

    @model_validator(mode="after")
    def validate_resolution_state(self) -> Self:  # noqa: C901, PLR0912, PLR0915
        """Require all public evidence to prove the declared resolution state."""
        if self.name != self.definition.name:
            msg = "Structured field result name must match its definition"
            raise ValueError(msg)
        candidate_keys = tuple(
            _candidate_public_key(candidate) for candidate in self.candidates
        )
        if len(candidate_keys) != len(set(candidate_keys)):
            msg = "Structured field candidates must be unique"
            raise ValueError(msg)
        if self.candidates != tuple(sorted(self.candidates, key=_candidate_order_key)):
            msg = "Structured field candidates must be deterministically ordered"
            raise ValueError(msg)
        for candidate in self.candidates:
            actual_match_kind = _candidate_match_kind(candidate, self.definition)
            if actual_match_kind is None:
                msg = "Structured field candidate does not match its definition"
                raise ValueError(msg)
            if candidate.match_kind != actual_match_kind:
                msg = "Structured field candidate match kind is inconsistent"
                raise ValueError(msg)
        if any(issue.field_name != self.name for issue in self.issues):
            msg = "Structured field issues must identify their result field"
            raise ValueError(msg)
        issue_keys = tuple(_issue_public_key(issue) for issue in self.issues)
        if len(issue_keys) != len(set(issue_keys)):
            msg = "Structured field issues must be unique"
            raise ValueError(msg)

        selected_keys = tuple(
            _candidate_public_key(candidate) for candidate in self.selected
        )
        if len(selected_keys) != len(set(selected_keys)):
            msg = "Selected structured field candidates must be unique"
            raise ValueError(msg)
        candidate_key_set = set(candidate_keys)
        if any(key not in candidate_key_set for key in selected_keys):
            msg = "Selected candidates must be present in field evidence"
            raise ValueError(msg)
        selected_key_set = set(selected_keys)
        expected_selected_order = tuple(
            candidate
            for candidate in self.candidates
            if _candidate_public_key(candidate) in selected_key_set
        )
        if self.selected != expected_selected_order:
            msg = "Selected candidates must preserve candidate ordering"
            raise ValueError(msg)
        if self.status != "found" and self.selected:
            msg = "Only a found structured field can select candidates"
            raise ValueError(msg)

        top_candidates: tuple[StructuredFieldCandidate, ...] = ()
        if self.candidates:
            top_priority = min(
                _candidate_priority(candidate) for candidate in self.candidates
            )
            top_candidates = tuple(
                candidate
                for candidate in self.candidates
                if _candidate_priority(candidate) == top_priority
            )

        if self.status == "found":
            if not self.selected:
                msg = "A found structured field requires selected candidates"
                raise ValueError(msg)
            if self.selected != top_candidates:
                msg = "Found structured fields must select top-priority candidates"
                raise ValueError(msg)
            if not self.definition.allow_multiple and len(self.selected) > 1:
                msg = "A single-value field cannot select multiple candidates"
                raise ValueError(msg)
            expected_type = _expected_document_field_type(self.definition.value_type)
            for candidate in self.selected:
                field = candidate.field
                if (
                    field.normalization_status != "normalized"
                    or field.field_type != expected_type
                    or field.value is None
                ):
                    msg = "Found structured fields require normalized expected values"
                    raise ValueError(msg)
                if self.definition.min_confidence is not None and (
                    candidate.confidence is None
                    or not candidate.confidence_usable_for_thresholds
                    or candidate.confidence < self.definition.min_confidence
                ):
                    msg = "Found structured fields must satisfy minimum confidence"
                    raise ValueError(msg)
                if _constraint_categories(
                    field.value,
                    self.definition.constraints,
                ):
                    msg = "Found structured fields must satisfy constraints"
                    raise ValueError(msg)
            if any(issue.severity == "error" for issue in self.issues):
                msg = "Found structured fields cannot contain error issues"
                raise ValueError(msg)
        elif self.status == "missing":
            if self.candidates:
                msg = "Missing structured fields cannot contain candidates"
                raise ValueError(msg)
            has_missing_issue = _has_issue(
                self.issues,
                "required_field_missing",
                "error",
            )
            if self.definition.required and not has_missing_issue:
                msg = "Required missing fields require a missing issue"
                raise ValueError(msg)
            if not self.definition.required and has_missing_issue:
                msg = "Optional missing fields cannot contain a required missing issue"
                raise ValueError(msg)
        elif self.status == "ambiguous":
            if len(top_candidates) < _MIN_AMBIGUOUS_CANDIDATES:
                msg = "Ambiguous structured fields require multiple top candidates"
                raise ValueError(msg)
            if not _has_issue(self.issues, "ambiguous_candidates", "error"):
                msg = "Ambiguous structured fields require an ambiguity issue"
                raise ValueError(msg)
        elif self.status == "invalid":
            relevant_error = any(
                issue.severity == "error"
                and (
                    issue.category in {"missing_value", "value_type_invalid"}
                    or issue.category.startswith("constraint_")
                )
                for issue in self.issues
            )
            if not self.candidates or not relevant_error:
                msg = "Invalid structured fields require candidate and error evidence"
                raise ValueError(msg)
        elif self.status == "low_confidence":
            threshold = self.definition.min_confidence
            if threshold is None:
                msg = "Low-confidence fields require a confidence threshold"
                raise ValueError(msg)
            if not top_candidates or not any(
                candidate.confidence is None
                or not candidate.confidence_usable_for_thresholds
                or candidate.confidence < threshold
                for candidate in top_candidates
            ):
                msg = "Low-confidence fields require below-threshold evidence"
                raise ValueError(msg)
            if not _has_issue(self.issues, "low_confidence", "error"):
                msg = "Low-confidence fields require a low-confidence issue"
                raise ValueError(msg)
        elif self.status == "raw_only":
            if not self.candidates or not any(
                candidate.field.normalization_status != "normalized"
                for candidate in self.candidates
            ):
                msg = "Raw-only fields require non-normalized candidate evidence"
                raise ValueError(msg)
            if not _has_issue(
                self.issues,
                "raw_value_not_normalized",
                "warning",
            ):
                msg = "Raw-only fields require a normalization warning"
                raise ValueError(msg)
        return self


def _structured_quality_counts(
    fields: tuple[StructuredFieldResult, ...],
    document: Document,
) -> tuple[int, int, int, int, int, int, int]:
    """Recount only bounded status and table-shape evidence from the result."""
    required = missing = ambiguous = constrained = 0
    for field in fields:
        if not field.definition.required:
            continue
        required += 1
        missing += field.status == "missing"
        ambiguous += field.status == "ambiguous"
        constrained += field.status in {"invalid", "low_confidence", "raw_only"}

    tables = table_cells = empty_table_cells = 0
    for table in document.tables:
        tables += 1
        table_cells += len(table.cells)
        for cell in table.cells:
            text = cell.text
            if type(text) is not str:
                msg = "Structured extraction table-cell evidence is invalid"
                raise ValueError(msg)
            empty_table_cells += not str.strip(text)
    for page in document.pages:
        for table in page.tables:
            tables += 1
            table_cells += len(table.cells)
            for cell in table.cells:
                text = cell.text
                if type(text) is not str:
                    msg = "Structured extraction table-cell evidence is invalid"
                    raise ValueError(msg)
                empty_table_cells += not str.strip(text)
    return (
        required,
        missing,
        ambiguous,
        constrained,
        tables,
        table_cells,
        empty_table_cells,
    )


def _validate_structured_quality_evidence(
    *,
    report: LocalOcrQualityReport,
    fields: tuple[StructuredFieldResult, ...],
    document: Document,
    provider_usage: ProviderUsage | None,
    preprocessing_report: LocalOcrPreprocessingReport | None,
) -> None:
    """Cross-check content-free quality evidence against its owning result."""
    assessments = report.input_assessments
    if assessments:
        first_source = document.pages[0].source if document.pages else None
        document_family: Literal["pdf", "image"] | None = None
        if isinstance(first_source, PdfSourceReference):
            document_family = "pdf"
        elif isinstance(first_source, ImageSourceReference):
            document_family = "image"
        valid_indexes = frozenset(page.page_number for page in document.pages)
        if any(
            assessment.source_kind != document_family
            or assessment.source_index not in valid_indexes
            for assessment in assessments
        ):
            msg = "Structured extraction Local OCR assessment coverage is inconsistent"
            raise ValueError(msg)

    if report.policy.structured is not None:
        expected_counts = _structured_quality_counts(fields, document)
        reported_counts = (
            report.required_field_count,
            report.missing_required_field_count,
            report.ambiguous_required_field_count,
            report.constrained_required_field_issue_count,
            report.table_count,
            report.table_cell_count,
            report.empty_table_cell_count,
        )
        if reported_counts != expected_counts:
            msg = "Structured extraction Local OCR quality counts are inconsistent"
            raise ValueError(msg)

    summary = report.summary
    preprocessing_summary = (
        None if preprocessing_report is None else preprocessing_report.summary()
    )
    if not _local_ocr_quality_usage_matches(
        summary=summary,
        usage=provider_usage,
        preprocessing_attempt_count=(
            0
            if preprocessing_summary is None
            else preprocessing_summary.extra_attempt_count
        ),
        preprocessing_operation_count=(
            0
            if preprocessing_summary is None
            else preprocessing_summary.extra_operation_count
        ),
        preprocessing_pixel_count=(
            0
            if preprocessing_summary is None
            else preprocessing_summary.preprocessing_pixel_count
        ),
    ):
        msg = "Structured extraction Local OCR usage evidence is inconsistent"
        raise ValueError(msg)


class StructuredExtractionResult(_JsonDictionaryRoundTripModel):
    """Complete document and final schema-resolution outcome."""

    model_config = ConfigDict(
        populate_by_name=True,
        serialize_by_alias=True,
        validate_by_alias=True,
        validate_by_name=True,
    )

    schema_contract: ExtractionSchema = Field(alias="schema")
    schema_id: str = Field(min_length=1)
    schema_version: str = Field(min_length=1)
    document: Document
    fields: tuple[StructuredFieldResult, ...]
    accepted_document_types: tuple[str, ...] = ()
    document_type_status: DocumentTypeStatus = DocumentTypeStatus.NOT_RESTRICTED
    observed_document_types: tuple[str, ...] = ()
    matched_document_types: tuple[str, ...] = ()
    complete: bool
    missing_required_fields: tuple[str, ...] = ()
    unresolved_required_fields: tuple[str, ...] = ()
    issues: tuple[StructuredExtractionIssue, ...] = ()
    warnings: tuple[ProcessingWarning, ...] = ()
    provider_usage: ProviderUsage | None = None
    cloud_execution_attempt: CloudExecutionAttemptEvidence | None = None
    local_ocr_quality_report: LocalOcrQualityReport | None = None
    local_ocr_preprocessing_report: LocalOcrPreprocessingReport | None = None

    @property
    def schema(self) -> ExtractionSchema:  # type: ignore[override]
        """Expose the embedded immutable schema under its public contract name."""
        return self.schema_contract

    @model_serializer(mode="wrap")
    def serialize_public_schema(
        self,
        handler: SerializerFunctionWrapHandler,
    ) -> dict[str, object]:
        """Keep the public schema key stable across supported Pydantic releases."""
        serialized = cast("dict[str, object]", handler(self))
        if "schema_contract" in serialized:
            serialized["schema"] = serialized.pop("schema_contract")
        return serialized

    @model_validator(mode="after")
    def validate_result_ordering(self) -> Self:  # noqa: C901, PLR0912, PLR0915
        """Require exact schema, issue, eligibility, and completion projections."""
        usage = _validate_provider_usage(self.provider_usage)
        object.__setattr__(self, "provider_usage", usage)
        cloud_attempt = self.cloud_execution_attempt
        if cloud_attempt is not None:
            cloud_attempt = _revalidate_model_instance_json(
                cloud_attempt,
                CloudExecutionAttemptEvidence,
                "Structured cloud execution attempt is invalid",
            )
            if (
                cloud_attempt.status is not CloudExecutionAttemptStatus.COMPLETED
                or usage is None
                or usage.provider_name != cloud_attempt.provider_name
                or usage.profile_id != cloud_attempt.profile_id
                or usage.model_id != cloud_attempt.model_id
                or usage.api_version != cloud_attempt.api_version
                or usage.provider_resource_identity
                != cloud_attempt.provider_resource_identity
            ):
                msg = "Structured cloud attempt and Provider usage are inconsistent"
                raise ValueError(msg)
            object.__setattr__(self, "cloud_execution_attempt", cloud_attempt)
        if (
            self.schema_id != self.schema.schema_id
            or self.schema_version != self.schema.schema_version
            or self.accepted_document_types != self.schema.accepted_document_types
        ):
            msg = "Structured extraction schema projections are inconsistent"
            raise ValueError(msg)
        supplied_fields = self.fields
        fields = tuple(
            sorted(supplied_fields, key=lambda field: _matching_name(field.name))
        )
        names = tuple(_matching_name(field.name) for field in fields)
        if len(names) != len(set(names)):
            msg = "Structured extraction result field names must be unique"
            raise ValueError(msg)
        expected_names = tuple(
            _matching_name(definition.name) for definition in self.schema.fields
        )
        if names != expected_names:
            msg = "Structured extraction result fields must exactly match the schema"
            raise ValueError(msg)
        definitions = {
            _matching_name(definition.name): definition
            for definition in self.schema.fields
        }
        if any(
            field.name != definitions[_matching_name(field.name)].name
            or field.definition != definitions[_matching_name(field.name)]
            for field in fields
        ):
            msg = "Structured extraction result definitions must match the schema"
            raise ValueError(msg)
        accepted = self.schema.accepted_document_types
        observed = tuple(
            sorted(
                {
                    _matching_name(document.document_type)
                    for document in self.document.analyzed_documents
                }
            )
        )
        matched = tuple(value for value in observed if value in set(accepted))
        if not accepted:
            expected_document_type_status = DocumentTypeStatus.NOT_RESTRICTED
        elif not observed:
            expected_document_type_status = DocumentTypeStatus.UNAVAILABLE
        elif matched:
            expected_document_type_status = DocumentTypeStatus.ACCEPTED
        else:
            expected_document_type_status = DocumentTypeStatus.REJECTED
        if (
            self.observed_document_types != observed
            or self.matched_document_types != matched
            or self.document_type_status is not expected_document_type_status
        ):
            msg = "Structured extraction document-type evidence is inconsistent"
            raise ValueError(msg)

        field_issues = tuple(issue for field in fields for issue in field.issues)
        if self.issues[: len(field_issues)] != field_issues:
            msg = "Structured extraction result must contain every field issue once"
            raise ValueError(msg)
        extraction_issues = self.issues[len(field_issues) :]
        if any(issue.field_name is not None for issue in extraction_issues):
            msg = "Additional extraction issues cannot identify a field"
            raise ValueError(msg)
        issue_keys = tuple(_issue_public_key(issue) for issue in self.issues)
        if len(issue_keys) != len(set(issue_keys)):
            msg = "Structured extraction result issues must be unique"
            raise ValueError(msg)
        document_type_issue_counts = Counter(
            issue.category for issue in extraction_issues
        )
        rejected_count = document_type_issue_counts["document_type_rejected"]
        unavailable_count = document_type_issue_counts["document_type_unavailable"]
        if expected_document_type_status is DocumentTypeStatus.REJECTED:
            if rejected_count != 1 or unavailable_count:
                msg = "Rejected document types require their extraction issue"
                raise ValueError(msg)
        elif expected_document_type_status is DocumentTypeStatus.UNAVAILABLE:
            if unavailable_count != 1 or rejected_count:
                msg = "Unavailable document types require their extraction issue"
                raise ValueError(msg)
        elif rejected_count or unavailable_count:
            msg = "Eligible document types cannot contain ineligibility issues"
            raise ValueError(msg)
        missing = tuple(
            field.name
            for field in fields
            if field.definition.required and field.status == "missing"
        )
        unresolved = tuple(
            field.name
            for field in fields
            if field.definition.required and field.status != "found"
        )
        if self.missing_required_fields != missing:
            msg = "Missing required fields must exactly identify missing results"
            raise ValueError(msg)
        if self.unresolved_required_fields != unresolved:
            msg = "Unresolved required fields must exactly identify unresolved results"
            raise ValueError(msg)
        eligible = expected_document_type_status in {
            DocumentTypeStatus.NOT_RESTRICTED,
            DocumentTypeStatus.ACCEPTED,
        }
        extraction_error = any(
            issue.severity == "error" and issue.field_name is None
            for issue in self.issues
        )
        expected_complete = eligible and not unresolved and not extraction_error
        if self.complete is not expected_complete:
            msg = "Structured extraction completion is inconsistent"
            raise ValueError(msg)
        quality = self.local_ocr_quality_report
        if quality is not None:
            quality = _validate_quality_report(quality)
            object.__setattr__(
                self,
                "local_ocr_quality_report",
                quality,
            )
        preprocessing: LocalOcrPreprocessingReport | None = None
        if self.local_ocr_preprocessing_report is not None:
            if quality is None:
                msg = "Structured preprocessing evidence is inconsistent"
                raise ValueError(msg)
            preprocessing, quality = _validate_preprocessing_quality_lineage(
                self.local_ocr_preprocessing_report,
                quality,
            )
            object.__setattr__(self, "local_ocr_preprocessing_report", preprocessing)
            object.__setattr__(self, "local_ocr_quality_report", quality)
        if quality is not None:
            _validate_structured_quality_evidence(
                report=quality,
                fields=fields,
                document=self.document,
                provider_usage=usage,
                preprocessing_report=preprocessing,
            )
        object.__setattr__(self, "fields", fields)
        object.__setattr__(self, "observed_document_types", observed)
        object.__setattr__(self, "matched_document_types", matched)
        object.__setattr__(self, "missing_required_fields", missing)
        object.__setattr__(self, "unresolved_required_fields", unresolved)
        return self


class StructuredExtractionIncompleteSummary(_JsonDictionaryRoundTripModel):
    """Sanitized fail-fast evidence without document or candidate data."""

    schema_id: str = Field(min_length=1)
    schema_version: str = Field(min_length=1)
    document_type_status: DocumentTypeStatus
    missing_required_fields: tuple[str, ...] = ()
    unresolved_required_fields: tuple[str, ...] = ()
    issue_category_counts: Mapping[str, int] = Field(default_factory=dict)

    @model_validator(mode="after")
    def freeze_category_counts(self) -> Self:
        """Freeze sorted safe category counts."""
        counts = dict(sorted(self.issue_category_counts.items()))
        if any(
            category not in _SAFE_ISSUE_CATEGORIES
            or type(count) is not int
            or count < 1
            for category, count in counts.items()
        ):
            msg = "Incomplete extraction issue counts are invalid"
            raise ValueError(msg)
        object.__setattr__(
            self,
            "issue_category_counts",
            MappingProxyType(counts),
        )
        return self

    @field_serializer("issue_category_counts")
    def serialize_category_counts(
        self,
        value: Mapping[str, int],
    ) -> dict[str, int]:
        """Serialize the immutable count mapping as safe JSON."""
        return dict(value)

    @classmethod
    def from_result(
        cls,
        result: StructuredExtractionResult,
    ) -> StructuredExtractionIncompleteSummary:
        """Create only the explicitly allowed fail-fast summary."""
        counts: Counter[str] = Counter()
        for issue in result.issues:
            counts[issue.category] += issue.count
        return cls(
            schema_id=result.schema_id,
            schema_version=result.schema_version,
            document_type_status=result.document_type_status,
            missing_required_fields=result.missing_required_fields,
            unresolved_required_fields=result.unresolved_required_fields,
            issue_category_counts=dict(counts),
        )


__all__ = [
    "ConstraintValueType",
    "DocumentTypeStatus",
    "ExtractionSchema",
    "ExtractionStrategy",
    "ExtractionValueType",
    "FieldConstraintValue",
    "FieldConstraints",
    "FieldDefinition",
    "StructuredExtractionIncompleteSummary",
    "StructuredExtractionIssue",
    "StructuredExtractionOptions",
    "StructuredExtractionResult",
    "StructuredFieldCandidate",
    "StructuredFieldResult",
]

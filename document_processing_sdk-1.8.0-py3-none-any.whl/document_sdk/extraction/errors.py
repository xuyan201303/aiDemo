"""Typed, sanitized structured-extraction errors."""

from __future__ import annotations

from typing import TYPE_CHECKING

from document_sdk.core import DocumentSdkError

if TYPE_CHECKING:
    from document_sdk.extraction.models import StructuredExtractionIncompleteSummary


class ExtractionSchemaError(DocumentSdkError):
    """Raised when an extraction request does not contain a valid schema."""


class StructuredExtractionIncompleteError(DocumentSdkError):
    """Raised after a validated result is incomplete when fail-fast is enabled."""

    def __init__(self, summary: StructuredExtractionIncompleteSummary) -> None:
        """Retain only sanitized aggregate evidence."""
        self.summary = summary
        super().__init__("Structured extraction did not resolve every required field")


class StructuredExtractionProviderRequiredError(DocumentSdkError):
    """Raised when the selected extraction strategy requires a Provider."""

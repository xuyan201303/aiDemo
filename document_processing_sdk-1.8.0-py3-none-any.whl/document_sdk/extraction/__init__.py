"""Public provider-independent structured extraction foundation."""

from document_sdk.extraction.errors import (
    ExtractionSchemaError,
    StructuredExtractionIncompleteError,
    StructuredExtractionProviderRequiredError,
)
from document_sdk.extraction.extraction import (
    analyze_pdf_structured,
    extract_structured_fields,
)
from document_sdk.extraction.models import (
    ConstraintValueType,
    DocumentTypeStatus,
    ExtractionConfidenceSource,
    ExtractionSchema,
    ExtractionStrategy,
    ExtractionValueType,
    FieldConstraints,
    FieldConstraintValue,
    FieldDefinition,
    StructuredExtractionIncompleteSummary,
    StructuredExtractionIssue,
    StructuredExtractionOptions,
    StructuredExtractionResult,
    StructuredFieldCandidate,
    StructuredFieldResult,
)

__all__ = [
    "ConstraintValueType",
    "DocumentTypeStatus",
    "ExtractionConfidenceSource",
    "ExtractionSchema",
    "ExtractionSchemaError",
    "ExtractionStrategy",
    "ExtractionValueType",
    "FieldConstraintValue",
    "FieldConstraints",
    "FieldDefinition",
    "StructuredExtractionIncompleteError",
    "StructuredExtractionIncompleteSummary",
    "StructuredExtractionIssue",
    "StructuredExtractionOptions",
    "StructuredExtractionProviderRequiredError",
    "StructuredExtractionResult",
    "StructuredFieldCandidate",
    "StructuredFieldResult",
    "analyze_pdf_structured",
    "extract_structured_fields",
]

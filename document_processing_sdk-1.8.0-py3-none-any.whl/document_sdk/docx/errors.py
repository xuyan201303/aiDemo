"""Typed sanitized failures for local DOCX processing."""

from document_sdk.core import DocumentProcessingError


class DocxProcessingError(DocumentProcessingError):
    """Base failure for local DOCX inspection and analysis."""


class DocxPackageInvalidError(DocxProcessingError):
    """Raised when an OPC/ZIP or XML contract is malformed."""


class DocxUnsupportedPackageError(DocxProcessingError):
    """Raised when an Office package is not a supported non-macro DOCX."""


class DocxResourceLimitError(DocxProcessingError):
    """Raised before configured DOCX resource limits would be exceeded."""

    def __init__(
        self,
        *,
        limit_name: str,
        observed: float,
        maximum: float,
    ) -> None:
        """Create a content-free structured limit failure."""
        self.limit_name = limit_name
        self.observed = observed
        self.maximum = maximum
        super().__init__(
            f"DOCX {limit_name} limit exceeded: observed {observed}, maximum {maximum}"
        )


class DocxSourceChangedError(DocxProcessingError):
    """Raised when authorized source bytes change during one operation."""

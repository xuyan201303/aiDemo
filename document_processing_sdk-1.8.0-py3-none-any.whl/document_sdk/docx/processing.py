"""Local bounded DOCX inspection, analysis, and normalized Document mapping."""

# ruff: noqa: B023, BLE001, C901, EM101, FURB162, PERF401, PLR0912, PLR0913, PLR0915, PLR2004, TRY003, TRY301, TRY300

from __future__ import annotations

import hashlib
import unicodedata
from collections import Counter
from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path, PurePosixPath
from typing import Any, Literal, cast

from document_sdk import __version__
from document_sdk.core import (
    Document,
    DocumentKeyValueElement,
    DocumentKeyValuePair,
    DocumentParagraph,
    DocumentProcessingError,
    DocumentSection,
    DocxSourceReference,
    FileAccessError,
    FileDescriptor,
    FileFingerprint,
    ProcessingWarning,
    Table,
    TableCell,
)
from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.document.errors import DocumentSourceChangedError
from document_sdk.document.models import DocumentEnvelope, DocumentFormat, DocumentType
from document_sdk.document.processing import (
    _adapter_path,
    _assert_source_unchanged,
    _DocumentIdentityLimitError,
    _raw_identity,
)
from document_sdk.docx._package import DocxPackage, Relationship
from document_sdk.docx.errors import (
    DocxPackageInvalidError,
    DocxProcessingError,
    DocxResourceLimitError,
    DocxSourceChangedError,
)
from document_sdk.docx.models import (
    DocxAnalysisOptions,
    DocxAnalysisResult,
    DocxBookmark,
    DocxComment,
    DocxContentControl,
    DocxCustomProperty,
    DocxDocumentProperties,
    DocxDocumentStructure,
    DocxEmbeddedResource,
    DocxEndnote,
    DocxFootnote,
    DocxHyperlink,
    DocxInspection,
    DocxListInfo,
    DocxPackageSummary,
    DocxParagraph,
    DocxProcessingLimits,
    DocxProcessingManifest,
    DocxRevisionView,
    DocxRun,
    DocxSection,
    DocxStory,
    DocxStoryType,
    DocxTable,
    DocxTableCell,
    DocxTableRow,
    DocxTextStyle,
    DocxTrackChangesSummary,
)

_DOCX_MEDIA_TYPE = (
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
)
_W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
_W14 = "http://schemas.microsoft.com/office/word/2010/wordml"
_W15 = "http://schemas.microsoft.com/office/word/2012/wordml"
_R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
_WP = "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
_M = "http://schemas.openxmlformats.org/officeDocument/2006/math"
_CP = "http://schemas.openxmlformats.org/package/2006/metadata/core-properties"
_DC = "http://purl.org/dc/elements/1.1/"
_DCTERMS = "http://purl.org/dc/terms/"
_EP = "http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"
_CUSTOM = "http://schemas.openxmlformats.org/officeDocument/2006/custom-properties"
_VT = "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"
_REL_PREFIX = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/"


def _q(namespace: str, name: str) -> str:
    return f"{{{namespace}}}{name}"


_RELATIONSHIP_TYPES = {
    role: f"{_REL_PREFIX}{role}"
    for role in (
        "comments",
        "control",
        "endnotes",
        "extended-properties",
        "footer",
        "footnotes",
        "header",
        "hyperlink",
        "image",
        "numbering",
        "oleObject",
        "package",
        "settings",
        "styles",
        "audio",
        "video",
        "custom-properties",
    )
}
_RELATIONSHIP_TYPES["core-properties"] = (
    "http://schemas.openxmlformats.org/package/2006/relationships/"
    "metadata/core-properties"
)
_RESOURCE_RELATIONSHIP_ROLES = frozenset(
    {"image", "package", "oleObject", "control", "audio", "video"}
)
_RELATIONSHIP_ROLES_BY_TYPE = {
    relationship_type: role for role, relationship_type in _RELATIONSHIP_TYPES.items()
}
_PART_CONTRACTS = {
    "document": (
        frozenset(
            {
                (
                    "application/vnd.openxmlformats-officedocument."
                    "wordprocessingml.document.main+xml"
                )
            }
        ),
        _q(_W, "document"),
    ),
    "header": (
        frozenset(
            {
                (
                    "application/vnd.openxmlformats-officedocument."
                    "wordprocessingml.header+xml"
                )
            }
        ),
        _q(_W, "hdr"),
    ),
    "footer": (
        frozenset(
            {
                (
                    "application/vnd.openxmlformats-officedocument."
                    "wordprocessingml.footer+xml"
                )
            }
        ),
        _q(_W, "ftr"),
    ),
    "comments": (
        frozenset(
            {
                (
                    "application/vnd.openxmlformats-officedocument."
                    "wordprocessingml.comments+xml"
                )
            }
        ),
        _q(_W, "comments"),
    ),
    "footnotes": (
        frozenset(
            {
                (
                    "application/vnd.openxmlformats-officedocument."
                    "wordprocessingml.footnotes+xml"
                )
            }
        ),
        _q(_W, "footnotes"),
    ),
    "endnotes": (
        frozenset(
            {
                (
                    "application/vnd.openxmlformats-officedocument."
                    "wordprocessingml.endnotes+xml"
                )
            }
        ),
        _q(_W, "endnotes"),
    ),
    "styles": (
        frozenset(
            {
                (
                    "application/vnd.openxmlformats-officedocument."
                    "wordprocessingml.styles+xml"
                )
            }
        ),
        _q(_W, "styles"),
    ),
    "numbering": (
        frozenset(
            {
                (
                    "application/vnd.openxmlformats-officedocument."
                    "wordprocessingml.numbering+xml"
                )
            }
        ),
        _q(_W, "numbering"),
    ),
    "settings": (
        frozenset(
            {
                (
                    "application/vnd.openxmlformats-officedocument."
                    "wordprocessingml.settings+xml"
                )
            }
        ),
        _q(_W, "settings"),
    ),
    "core-properties": (
        frozenset({"application/vnd.openxmlformats-package.core-properties+xml"}),
        _q(_CP, "coreProperties"),
    ),
    "extended-properties": (
        frozenset(
            {("application/vnd.openxmlformats-officedocument.extended-properties+xml")}
        ),
        _q(_EP, "Properties"),
    ),
    "custom-properties": (
        frozenset(
            {("application/vnd.openxmlformats-officedocument.custom-properties+xml")}
        ),
        _q(_CUSTOM, "Properties"),
    ),
}
_SUPPORTED_MAIN_PART_ROLES = frozenset(
    {
        "header",
        "footer",
        "comments",
        "footnotes",
        "endnotes",
        "styles",
        "numbering",
        "settings",
    }
)
_SUPPORTED_ROOT_PART_ROLES = frozenset(
    {"core-properties", "extended-properties", "custom-properties"}
)


def _word_name(element: Any) -> str | None:
    tag = str(element.tag)
    prefix = f"{{{_W}}}"
    return tag.removeprefix(prefix) if tag.startswith(prefix) else None


def _attr(element: Any, name: str, namespace: str = _W) -> str | None:
    return cast("str | None", element.attrib.get(_q(namespace, name)))


def _child(element: Any, name: str) -> Any | None:
    return element.find(_q(_W, name))


def _children(element: Any, name: str) -> tuple[Any, ...]:
    return tuple(element.findall(_q(_W, name)))


def _int(value: str | None) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except ValueError:
        return None


def _on_off(element: Any | None) -> bool | None:
    if element is None:
        return None
    value = _attr(element, "val")
    return value is None or value.casefold() not in {"0", "false", "off"}


def _datetime(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def _safe_basename(value: str) -> str | None:
    name = unicodedata.normalize("NFKC", PurePosixPath(value).name)
    if (
        not name
        or name in {".", ".."}
        or "/" in name
        or "\\" in name
        or any(ord(character) < 32 or ord(character) == 127 for character in name)
    ):
        return None
    return name


@dataclass
class _StyleDefinition:
    style_id: str
    name: str | None
    style_type: str | None
    based_on: str | None
    outline_level: int | None
    quick_format: bool


@dataclass
class _NumberingLevel:
    abstract_num_id: str
    level: int
    numbering_format: str | None
    level_text: str | None
    start_value: int | None
    restart: bool | None
    left_indent_twips: int | None
    hanging_indent_twips: int | None


@dataclass
class _Counters:
    limits: DocxProcessingLimits
    text_characters: int = 0
    paragraphs: int = 0
    runs: int = 0
    tables: int = 0
    table_rows: int = 0
    table_cells: int = 0
    sections: int = 0
    hyperlinks: int = 0
    bookmarks: int = 0
    content_controls: int = 0

    def add(self, field_name: str, amount: int = 1) -> None:
        value = getattr(self, field_name) + amount
        maximum = getattr(self.limits, f"max_{field_name}")
        if value > maximum:
            raise DocxResourceLimitError(
                limit_name=field_name,
                observed=value,
                maximum=maximum,
            )
        setattr(self, field_name, value)


@dataclass
class _ParseState:
    package: DocxPackage
    options: DocxAnalysisOptions
    descriptor: FileDescriptor
    counters: _Counters
    styles: dict[str, _StyleDefinition]
    numbering: dict[tuple[str, int], _NumberingLevel]
    num_to_abstract: dict[str, str]
    warnings: Counter[str] = field(default_factory=Counter)
    hyperlinks: list[DocxHyperlink] = field(default_factory=list)
    bookmarks: list[DocxBookmark] = field(default_factory=list)
    controls: list[DocxContentControl] = field(default_factory=list)
    note_references: dict[str, list[DocxSourceReference]] = field(default_factory=dict)
    endnote_references: dict[str, list[DocxSourceReference]] = field(
        default_factory=dict
    )
    comment_ranges: dict[str, dict[str, DocxSourceReference]] = field(
        default_factory=dict
    )
    open_bookmarks: dict[
        tuple[str, str],
        tuple[str, DocxSourceReference],
    ] = field(default_factory=dict)
    revision_sources: list[DocxSourceReference] = field(default_factory=list)
    resource_metadata: dict[
        tuple[str, str],
        tuple[str | None, str | None],
    ] = field(default_factory=dict)
    auxiliary_roots: list[Any] = field(default_factory=list)
    story_roots: list[tuple[Any, DocxStoryType, str]] = field(default_factory=list)
    element_sources: dict[int, DocxSourceReference] = field(default_factory=dict)

    def warning(self, category: str, count: int = 1) -> None:
        self.warnings[category] += count


def _source(
    state: _ParseState,
    *,
    story_type: DocxStoryType | Literal["custom_property"],
    story_id: str,
    block_index: int,
    paragraph_index: int | None = None,
    run_index: int | None = None,
    table_index: int | None = None,
    table_path: tuple[int, ...] = (),
    row_index: int | None = None,
    cell_index: int | None = None,
    character_start: int | None = None,
    character_end: int | None = None,
    resource_id: str | None = None,
    source_role: Literal["story", "section", "custom_property"] = "story",
    package_part: str | None = None,
) -> DocxSourceReference:
    return DocxSourceReference(
        file_id=state.descriptor.file_id,
        source_role=source_role,
        package_part=package_part,
        story_type=(
            story_type.value if isinstance(story_type, DocxStoryType) else story_type
        ),
        story_id=story_id,
        block_index=block_index,
        paragraph_index=paragraph_index,
        run_index=run_index,
        table_index=table_index,
        table_path=table_path,
        row_index=row_index,
        cell_index=cell_index,
        character_start=character_start,
        character_end=character_end,
        resource_id=resource_id,
    )


def _resource_id(owner: str, relationship_id: str) -> str:
    digest = hashlib.sha256(f"{owner}\0{relationship_id}".encode()).hexdigest()[:20]
    return f"resource-{digest}"


def _relationship_role(relationship: Relationship) -> str | None:
    return _RELATIONSHIP_ROLES_BY_TYPE.get(relationship.relationship_type)


def _relationship_by_role(
    relationships: tuple[Relationship, ...],
    role: str,
) -> Relationship | None:
    relationship_type = _RELATIONSHIP_TYPES[role]
    matches = tuple(
        relationship
        for relationship in relationships
        if relationship.relationship_type == relationship_type
    )
    if len(matches) > 1:
        raise DocxPackageInvalidError(
            "The DOCX package contains conflicting part relationships"
        )
    return matches[0] if matches else None


def _relationships_by_role(
    relationships: tuple[Relationship, ...],
    role: str,
) -> tuple[Relationship, ...]:
    relationship_type = _RELATIONSHIP_TYPES[role]
    return tuple(
        relationship
        for relationship in relationships
        if relationship.relationship_type == relationship_type
    )


def _validated_part_root(
    package: DocxPackage,
    *,
    part: str,
    role: str,
) -> Any:
    expected_content_types, expected_root = _PART_CONTRACTS[role]
    content_type = package.content_type(part)
    if content_type is None or content_type.casefold() not in {
        value.casefold() for value in expected_content_types
    }:
        raise DocxPackageInvalidError(
            "A DOCX relationship targets a part with an invalid content type"
        )
    root = package.cached_xml(part)
    if root is None:
        root = package.read_xml(part)
    if root.tag != expected_root:
        raise DocxPackageInvalidError(
            "A DOCX relationship targets a part with an invalid root element"
        )
    return root


def _validated_relationship_root(
    package: DocxPackage,
    relationship: Relationship,
    *,
    role: str,
) -> Any:
    if (
        relationship.external
        or relationship.relationship_type != _RELATIONSHIP_TYPES[role]
    ):
        raise DocxPackageInvalidError(
            "A DOCX relationship has an invalid role or target mode"
        )
    return _validated_part_root(package, part=relationship.target, role=role)


def _validate_supported_part_contracts(
    package: DocxPackage,
    *,
    root_relationships: tuple[Relationship, ...],
    main_relationships: tuple[Relationship, ...],
) -> None:
    for relationship in root_relationships:
        role = _relationship_role(relationship)
        if role in _SUPPORTED_ROOT_PART_ROLES:
            _validated_relationship_root(package, relationship, role=role)
    for relationship in main_relationships:
        role = _relationship_role(relationship)
        if role in _SUPPORTED_MAIN_PART_ROLES:
            _validated_relationship_root(package, relationship, role=role)


def _parse_styles(
    package: DocxPackage,
    relationships: tuple[Relationship, ...],
    warnings: Counter[str],
) -> dict[str, _StyleDefinition]:
    relationship = _relationship_by_role(relationships, "styles")
    if relationship is None or relationship.external:
        return {}
    root = _validated_relationship_root(package, relationship, role="styles")
    styles: dict[str, _StyleDefinition] = {}
    for style in _children(root, "style"):
        style_id = _attr(style, "styleId")
        if not style_id or style_id in styles:
            warnings["malformed_styles"] += 1
            continue
        name_node = _child(style, "name")
        based_node = _child(style, "basedOn")
        ppr = _child(style, "pPr")
        outline = None if ppr is None else _child(ppr, "outlineLvl")
        styles[style_id] = _StyleDefinition(
            style_id=style_id,
            name=None if name_node is None else _attr(name_node, "val"),
            style_type=_attr(style, "type"),
            based_on=None if based_node is None else _attr(based_node, "val"),
            outline_level=None if outline is None else _int(_attr(outline, "val")),
            quick_format=_on_off(_child(style, "qFormat")) is True,
        )
    for style_id in styles:
        seen: set[str] = set()
        current = style_id
        while current in styles and styles[current].based_on:
            if current in seen:
                warnings["style_inheritance_cycle"] += 1
                break
            seen.add(current)
            target = styles[current].based_on
            if target not in styles:
                warnings["broken_style_reference"] += 1
                break
            current = target
    return styles


def _resolve_style(
    style_id: str | None,
    styles: dict[str, _StyleDefinition],
) -> tuple[str | None, int | None, bool]:
    if style_id is None or style_id not in styles:
        return None, None, False
    seen: set[str] = set()
    current = style_id
    name: str | None = None
    outline: int | None = None
    quick = False
    while current in styles and current not in seen:
        seen.add(current)
        style = styles[current]
        name = name or style.name
        outline = outline if outline is not None else style.outline_level
        quick = quick or style.quick_format
        current = style.based_on or ""
    return name, outline, quick


def _parse_numbering(
    package: DocxPackage,
    relationships: tuple[Relationship, ...],
    warnings: Counter[str],
) -> tuple[dict[tuple[str, int], _NumberingLevel], dict[str, str]]:
    relationship = _relationship_by_role(relationships, "numbering")
    if relationship is None or relationship.external:
        return {}, {}
    root = _validated_relationship_root(package, relationship, role="numbering")
    levels: dict[tuple[str, int], _NumberingLevel] = {}
    for abstract in _children(root, "abstractNum"):
        abstract_id = _attr(abstract, "abstractNumId")
        if abstract_id is None:
            warnings["malformed_numbering"] += 1
            continue
        for level in _children(abstract, "lvl"):
            index = _int(_attr(level, "ilvl"))
            if index is None or index < 0:
                warnings["malformed_numbering"] += 1
                continue
            num_fmt = _child(level, "numFmt")
            level_text = _child(level, "lvlText")
            start = _child(level, "start")
            restart = _child(level, "lvlRestart")
            ppr = _child(level, "pPr")
            indent = None if ppr is None else _child(ppr, "ind")
            levels[(abstract_id, index)] = _NumberingLevel(
                abstract_num_id=abstract_id,
                level=index,
                numbering_format=None if num_fmt is None else _attr(num_fmt, "val"),
                level_text=(None if level_text is None else _attr(level_text, "val")),
                start_value=None if start is None else _int(_attr(start, "val")),
                restart=(
                    None if restart is None else (_int(_attr(restart, "val")) or 0) > 0
                ),
                left_indent_twips=(
                    None if indent is None else _int(_attr(indent, "left"))
                ),
                hanging_indent_twips=(
                    None if indent is None else _int(_attr(indent, "hanging"))
                ),
            )
    mapping: dict[str, str] = {}
    for num in _children(root, "num"):
        num_id = _attr(num, "numId")
        abstract = _child(num, "abstractNumId")
        abstract_id = None if abstract is None else _attr(abstract, "val")
        if not num_id or not abstract_id or num_id in mapping:
            warnings["malformed_numbering"] += 1
            continue
        mapping[num_id] = abstract_id
    return levels, mapping


def _run_style(run: Any) -> DocxTextStyle:
    properties = _child(run, "rPr")
    if properties is None:
        return DocxTextStyle()
    vertical = _child(properties, "vertAlign")
    vertical_value = None if vertical is None else _attr(vertical, "val")
    fonts = _child(properties, "rFonts")
    size = _child(properties, "sz")
    color = _child(properties, "color")
    highlight = _child(properties, "highlight")
    language = _child(properties, "lang")
    return DocxTextStyle(
        bold=_on_off(_child(properties, "b")),
        italic=_on_off(_child(properties, "i")),
        underline=(
            None
            if _child(properties, "u") is None
            else _attr(cast("Any", _child(properties, "u")), "val") != "none"
        ),
        strike=_on_off(_child(properties, "strike")),
        double_strike=_on_off(_child(properties, "dstrike")),
        subscript=vertical_value == "subscript" or None,
        superscript=vertical_value == "superscript" or None,
        small_caps=_on_off(_child(properties, "smallCaps")),
        all_caps=_on_off(_child(properties, "caps")),
        hidden=_on_off(_child(properties, "vanish")),
        font_family=(
            None if fonts is None else _attr(fonts, "ascii") or _attr(fonts, "hAnsi")
        ),
        font_size_points=(
            None
            if size is None or _int(_attr(size, "val")) is None
            else cast("int", _int(_attr(size, "val"))) / 2
        ),
        foreground_color=None if color is None else _attr(color, "val"),
        highlight=None if highlight is None else _attr(highlight, "val"),
        language=None if language is None else _attr(language, "val"),
    )


def _run_text(run: Any) -> str:
    fragments: list[str] = []
    for node in run.iter():
        if node.tag in {_q(_W, "t"), _q(_W, "delText")}:
            fragments.append(node.text or "")
        elif node.tag == _q(_W, "tab"):
            fragments.append("\t")
        elif node.tag in {_q(_W, "br"), _q(_W, "cr")}:
            fragments.append("\n")
        elif node.tag == _q(_W, "noBreakHyphen"):
            fragments.append("\u2011")
        elif node.tag == _q(_W, "softHyphen"):
            fragments.append("\u00ad")
    return "".join(fragments)


def _revision_included(kind: str, view: DocxRevisionView) -> bool:
    if kind in {"ins", "moveTo"}:
        return view is DocxRevisionView.CURRENT
    if kind in {"del", "moveFrom"}:
        return view is DocxRevisionView.ORIGINAL
    return True


def _projected_text(element: Any, view: DocxRevisionView) -> str:
    """Collect Word text through the same CURRENT/ORIGINAL revision contract."""
    fragments: list[str] = []

    def visit(node: Any) -> None:
        name = _word_name(node)
        if name in {"ins", "del", "moveFrom", "moveTo"} and not _revision_included(
            name, view
        ):
            return
        if node.tag in {_q(_W, "t"), _q(_W, "delText")}:
            fragments.append(node.text or "")
            return
        if node.tag == _q(_W, "tab"):
            fragments.append("\t")
            return
        if node.tag in {_q(_W, "br"), _q(_W, "cr")}:
            fragments.append("\n")
            return
        if node.tag == _q(_W, "noBreakHyphen"):
            fragments.append("\u2011")
            return
        if node.tag == _q(_W, "softHyphen"):
            fragments.append("\u00ad")
            return
        for child in node:
            visit(child)

    visit(element)
    return "".join(fragments)


def _paragraph(
    element: Any,
    *,
    state: _ParseState,
    story_type: DocxStoryType,
    story_id: str,
    block_index: int,
    paragraph_index: int,
    relationships: dict[str, Relationship],
    owner_part: str,
    identity_prefix: str | None = None,
    table_path: tuple[int, ...] = (),
    row_index: int | None = None,
    cell_index: int | None = None,
) -> DocxParagraph:
    state.counters.add("paragraphs")
    paragraph_source = _source(
        state,
        story_type=story_type,
        story_id=story_id,
        block_index=block_index,
        paragraph_index=paragraph_index,
        table_index=table_path[-1] if table_path else None,
        table_path=table_path,
        row_index=row_index,
        cell_index=cell_index,
    )
    properties = _child(element, "pPr")
    section_properties = None if properties is None else _child(properties, "sectPr")
    if section_properties is not None:
        state.element_sources[id(section_properties)] = paragraph_source.model_copy(
            update={"source_role": "section", "package_part": owner_part}
        )
    if properties is not None:
        for descendant in properties.iter():
            if descendant.tag == _q(_W, "pPrChange"):
                state.element_sources[id(descendant)] = paragraph_source
    style_node = None if properties is None else _child(properties, "pStyle")
    style_id = None if style_node is None else _attr(style_node, "val")
    style_name, inherited_outline, quick_format = _resolve_style(style_id, state.styles)
    outline_node = None if properties is None else _child(properties, "outlineLvl")
    outline = (
        inherited_outline if outline_node is None else _int(_attr(outline_node, "val"))
    )
    alignment_node = None if properties is None else _child(properties, "jc")
    alignment = None if alignment_node is None else _attr(alignment_node, "val")
    list_info: DocxListInfo | None = None
    num_properties = None if properties is None else _child(properties, "numPr")
    if num_properties is not None:
        num_id_node = _child(num_properties, "numId")
        level_node = _child(num_properties, "ilvl")
        num_id = None if num_id_node is None else _attr(num_id_node, "val")
        level = None if level_node is None else _int(_attr(level_node, "val"))
        if num_id is not None and level is not None:
            abstract_id = state.num_to_abstract.get(num_id)
            definition = (
                None
                if abstract_id is None
                else state.numbering.get((abstract_id, level))
            )
            if abstract_id is None or definition is None:
                state.warning("broken_numbering_reference")
            list_info = DocxListInfo(
                num_id=num_id,
                abstract_num_id=abstract_id,
                level=level,
                numbering_format=(
                    None if definition is None else definition.numbering_format
                ),
                level_text=None if definition is None else definition.level_text,
                start_value=None if definition is None else definition.start_value,
                restart=None if definition is None else definition.restart,
                left_indent_twips=(
                    None if definition is None else definition.left_indent_twips
                ),
                hanging_indent_twips=(
                    None if definition is None else definition.hanging_indent_twips
                ),
            )
    runs: list[DocxRun] = []
    hyperlinks: list[DocxHyperlink] = []
    bookmarks: list[DocxBookmark] = []
    character_offset = 0

    def visit(  # noqa: PLR0911
        node: Any,
        *,
        revision_kind: str | None = None,
        hyperlink_context: (
            tuple[str, Relationship | None, str | None, str | None, bool | None] | None
        ) = None,
    ) -> None:
        nonlocal character_offset
        name = _word_name(node)
        if name in {"ins", "del", "moveFrom", "moveTo"}:
            revision_kind = name
            state.element_sources[id(node)] = paragraph_source
            if not _revision_included(name, state.options.revision_view):
                return
        if name == "hyperlink":
            relationship_id = node.attrib.get(_q(_R, "id"))
            anchor = _attr(node, "anchor")
            relationship = (
                None if relationship_id is None else relationships.get(relationship_id)
            )
            if relationship_id is not None and (
                relationship is None
                or relationship.relationship_type != _RELATIONSHIP_TYPES["hyperlink"]
            ):
                raise DocxPackageInvalidError(
                    "A DOCX hyperlink relationship is missing or invalid"
                )
            if (
                relationship is not None
                and not relationship.external
                and state.package.member_metadata(relationship.target) is None
            ):
                raise DocxPackageInvalidError(
                    "A DOCX internal hyperlink target is missing"
                )
            if relationship is None and not anchor:
                raise DocxPackageInvalidError(
                    "A DOCX hyperlink lacks a resolvable target"
                )
            history_value = _attr(node, "history")
            hyperlink_id = f"{story_id}-h{state.counters.hyperlinks}"
            state.counters.add("hyperlinks")
            hyperlinks.append(
                DocxHyperlink(
                    hyperlink_id=hyperlink_id,
                    display_text="",
                    target=None if relationship is None else relationship.target,
                    anchor=anchor,
                    tooltip=_attr(node, "tooltip"),
                    history=(
                        None
                        if history_value is None
                        else history_value.casefold() not in {"0", "false", "off"}
                    ),
                    external=(False if relationship is None else relationship.external),
                    source=paragraph_source,
                )
            )
            hyperlink_context = (
                hyperlink_id,
                relationship,
                anchor,
                _attr(node, "tooltip"),
                (
                    None
                    if history_value is None
                    else history_value not in {"0", "false", "off"}
                ),
            )
        if name == "bookmarkStart":
            raw_bookmark_id = _attr(node, "id")
            if raw_bookmark_id:
                key = story_id, raw_bookmark_id
                if key in state.open_bookmarks:
                    state.warning("malformed_bookmark_range")
                    return
                state.counters.add("bookmarks")
                bookmark_id = (
                    f"{story_id}-b{state.counters.bookmarks - 1}-{raw_bookmark_id}"
                )
                bookmark = DocxBookmark(
                    bookmark_id=bookmark_id,
                    name=_attr(node, "name"),
                    start_source=paragraph_source,
                )
                state.open_bookmarks[key] = bookmark_id, paragraph_source
                state.bookmarks.append(bookmark)
                bookmarks.append(bookmark)
            return
        if name == "bookmarkEnd":
            raw_bookmark_id = _attr(node, "id")
            key = story_id, raw_bookmark_id or ""
            if raw_bookmark_id and key in state.open_bookmarks:
                bookmark_id, _ = state.open_bookmarks.pop(key)
                for index, bookmark in enumerate(state.bookmarks):
                    if bookmark.bookmark_id == bookmark_id:
                        completed = bookmark.model_copy(
                            update={"end_source": paragraph_source}
                        )
                        state.bookmarks[index] = completed
                        bookmarks.append(completed)
                        break
            else:
                state.warning("malformed_bookmark_range")
            return
        if name == "sdt":
            state.controls.append(
                _content_control(
                    node,
                    state=state,
                    source=paragraph_source,
                    blocks=(),
                )
            )
            content = _child(node, "sdtContent")
            if content is not None:
                for child in content:
                    visit(
                        child,
                        revision_kind=revision_kind,
                        hyperlink_context=hyperlink_context,
                    )
            return
        if name == "commentRangeStart":
            comment_id = _attr(node, "id")
            if comment_id:
                state.comment_ranges.setdefault(comment_id, {})["start"] = (
                    paragraph_source
                )
            return
        if name == "commentRangeEnd":
            comment_id = _attr(node, "id")
            if comment_id:
                state.comment_ranges.setdefault(comment_id, {})["end"] = (
                    paragraph_source
                )
            return
        if name == "r":
            state.counters.add("runs")
            text = _run_text(node)
            state.counters.add("text_characters", len(text))
            run_index = len(runs)
            run_source = _source(
                state,
                story_type=story_type,
                story_id=story_id,
                block_index=block_index,
                paragraph_index=paragraph_index,
                run_index=run_index,
                table_index=table_path[-1] if table_path else None,
                table_path=table_path,
                row_index=row_index,
                cell_index=cell_index,
                character_start=character_offset,
                character_end=character_offset + len(text),
            )
            for descendant in node.iter():
                if descendant.tag == _q(_W, "rPrChange"):
                    state.element_sources[id(descendant)] = run_source
            footnote_ids = (
                tuple(
                    filter(
                        None,
                        (
                            _attr(reference, "id")
                            for reference in node.iter(_q(_W, "footnoteReference"))
                        ),
                    )
                )
                if state.options.include_footnotes
                else ()
            )
            endnote_ids = (
                tuple(
                    filter(
                        None,
                        (
                            _attr(reference, "id")
                            for reference in node.iter(_q(_W, "endnoteReference"))
                        ),
                    )
                )
                if state.options.include_endnotes
                else ()
            )
            comment_ids = (
                tuple(
                    filter(
                        None,
                        (
                            _attr(reference, "id")
                            for reference in node.iter(_q(_W, "commentReference"))
                        ),
                    )
                )
                if state.options.include_comments
                else ()
            )
            for note_id in footnote_ids:
                state.note_references.setdefault(note_id, []).append(run_source)
            for note_id in endnote_ids:
                state.endnote_references.setdefault(note_id, []).append(run_source)
            for comment_id in comment_ids:
                state.comment_ranges.setdefault(comment_id, {})["reference"] = (
                    run_source
                )
            raw_resource_references = tuple(
                sorted(
                    {
                        (attribute, relationship_id)
                        for descendant in node.iter()
                        for attribute, relationship_id in (
                            ("embed", descendant.attrib.get(_q(_R, "embed"))),
                            ("link", descendant.attrib.get(_q(_R, "link"))),
                        )
                        if relationship_id
                    }
                )
            )
            for attribute, relationship_id in raw_resource_references:
                relationship = relationships.get(relationship_id)
                if (
                    relationship is None
                    or _relationship_role(relationship)
                    not in _RESOURCE_RELATIONSHIP_ROLES
                    or (attribute == "embed" and relationship.external)
                ):
                    raise DocxPackageInvalidError(
                        "A DOCX run resource relationship is missing or invalid"
                    )
            raw_resource_ids = tuple(
                sorted(
                    {
                        relationship_id
                        for _attribute, relationship_id in raw_resource_references
                    }
                )
            )
            drawing_properties = next(
                (
                    descendant
                    for descendant in node.iter()
                    if descendant.tag == _q(_WP, "docPr")
                ),
                None,
            )
            if drawing_properties is not None:
                alt_text = drawing_properties.attrib.get("descr")
                title = drawing_properties.attrib.get("title")
                for relationship_id in raw_resource_ids:
                    state.resource_metadata.setdefault(
                        (owner_part, relationship_id),
                        (alt_text, title),
                    )
            resource_ids = tuple(
                _resource_id(owner_part, relationship_id)
                for relationship_id in raw_resource_ids
            )
            run_hyperlink_id = (
                None if hyperlink_context is None else hyperlink_context[0]
            )
            paragraph_id = (
                f"{story_id}-p{paragraph_index}"
                if identity_prefix is None
                else f"{story_id}-{identity_prefix}-p{paragraph_index}"
            )
            runs.append(
                DocxRun(
                    run_id=f"{paragraph_id}-r{run_index}",
                    text=text,
                    style=_run_style(node),
                    hyperlink_id=run_hyperlink_id,
                    footnote_id=footnote_ids[0] if footnote_ids else None,
                    endnote_id=endnote_ids[0] if endnote_ids else None,
                    comment_ids=comment_ids,
                    resource_ids=resource_ids,
                    revision_kind=revision_kind,
                    source=run_source,
                )
            )
            if hyperlink_context is not None and text:
                (
                    hyperlink_id,
                    _relationship,
                    _anchor,
                    _tooltip,
                    _history,
                ) = hyperlink_context
                existing = next(
                    (item for item in hyperlinks if item.hyperlink_id == hyperlink_id),
                    None,
                )
                if existing is not None:
                    index = hyperlinks.index(existing)
                    hyperlinks[index] = existing.model_copy(
                        update={
                            "display_text": existing.display_text + text,
                            "source": run_source,
                        }
                    )
            character_offset += len(text)
            return
        for child in node:
            visit(
                child,
                revision_kind=revision_kind,
                hyperlink_context=hyperlink_context,
            )

    visit(element)
    text = "".join(run.text for run in runs)
    state.hyperlinks.extend(hyperlinks)
    language = next(
        (run.style.language for run in runs if run.style.language is not None),
        None,
    )
    return DocxParagraph(
        paragraph_id=(
            f"{story_id}-p{paragraph_index}"
            if identity_prefix is None
            else f"{story_id}-{identity_prefix}-p{paragraph_index}"
        ),
        text=text,
        runs=tuple(runs),
        style_id=style_id,
        style_name=style_name,
        outline_level=outline,
        is_heading=outline is not None or (quick_format and outline is not None),
        alignment=alignment,
        language=language,
        list_info=list_info,
        hyperlinks=tuple(hyperlinks),
        bookmarks=tuple(bookmarks),
        source=paragraph_source,
    )


def _block_text(block: DocxParagraph | DocxTable) -> str:
    if isinstance(block, DocxParagraph):
        return block.text
    return "\n".join(cell.text for row in block.rows for cell in row.cells if cell.text)


def _table(
    element: Any,
    *,
    state: _ParseState,
    story_type: DocxStoryType,
    story_id: str,
    block_index: int,
    relationships: dict[str, Relationship],
    nested_depth: int,
    parent_table_path: tuple[int, ...],
    owner_part: str,
) -> DocxTable:
    if nested_depth > state.counters.limits.max_nested_table_depth:
        raise DocxResourceLimitError(
            limit_name="nested_table_depth",
            observed=nested_depth,
            maximum=state.counters.limits.max_nested_table_depth,
        )
    table_index = state.counters.tables
    state.counters.add("tables")
    table_path = (*parent_table_path, table_index)
    table_source = _source(
        state,
        story_type=story_type,
        story_id=story_id,
        block_index=block_index,
        table_index=table_index,
        table_path=table_path,
    )
    properties = _child(element, "tblPr")
    if properties is not None:
        for descendant in properties.iter():
            if descendant.tag == _q(_W, "tblPrChange"):
                state.element_sources[id(descendant)] = table_source
    caption_node = None if properties is None else _child(properties, "tblCaption")
    description_node = (
        None if properties is None else _child(properties, "tblDescription")
    )
    grid = _child(element, "tblGrid")
    declared_grid_columns = None if grid is None else len(_children(grid, "gridCol"))
    mutable_rows: list[list[dict[str, Any]]] = []
    active_vertical: dict[int, dict[str, Any]] = {}
    logical_columns = 0

    row_nodes: list[Any] = []

    def collect_rows(container: Any) -> None:
        for child in container:
            name = _word_name(child)
            if name == "tr":
                row_properties = _child(child, "trPr")
                revision_markers = tuple(
                    marker
                    for marker in (() if row_properties is None else row_properties)
                    if _word_name(marker) in {"ins", "del", "moveFrom", "moveTo"}
                )
                for marker in revision_markers:
                    state.element_sources[id(marker)] = table_source
                revision = (
                    None if not revision_markers else _word_name(revision_markers[0])
                )
                if revision is None or _revision_included(
                    revision, state.options.revision_view
                ):
                    row_nodes.append(child)
            elif name == "sdt":
                row_index = len(row_nodes)
                state.controls.append(
                    _content_control(
                        child,
                        state=state,
                        source=_source(
                            state,
                            story_type=story_type,
                            story_id=story_id,
                            block_index=block_index,
                            table_index=table_index,
                            table_path=table_path,
                            row_index=row_index,
                        ),
                        blocks=(),
                    )
                )
                content = _child(child, "sdtContent")
                if content is not None:
                    collect_rows(content)
            elif name in {"ins", "del", "moveFrom", "moveTo"}:
                state.element_sources[id(child)] = table_source
                if _revision_included(name, state.options.revision_view):
                    collect_rows(child)

    collect_rows(element)
    for row in row_nodes:
        row_index = len(mutable_rows)
        state.counters.add("table_rows")
        row_source = _source(
            state,
            story_type=story_type,
            story_id=story_id,
            block_index=block_index,
            table_index=table_index,
            table_path=table_path,
            row_index=row_index,
        )
        row_properties = _child(row, "trPr")
        if row_properties is not None:
            for descendant in row_properties.iter():
                if _word_name(descendant) in {
                    "trPrChange",
                    "ins",
                    "del",
                    "moveFrom",
                    "moveTo",
                }:
                    state.element_sources[id(descendant)] = row_source
        row_header = _on_off(
            None if row_properties is None else _child(row_properties, "tblHeader")
        )
        grid_before_node = (
            None if row_properties is None else _child(row_properties, "gridBefore")
        )
        grid_after_node = (
            None if row_properties is None else _child(row_properties, "gridAfter")
        )
        grid_before = (
            0
            if grid_before_node is None
            else (_int(_attr(grid_before_node, "val")) or 0)
        )
        grid_after = (
            0 if grid_after_node is None else (_int(_attr(grid_after_node, "val")) or 0)
        )
        if grid_before < 0 or grid_after < 0:
            raise DocxPackageInvalidError("A DOCX table contains invalid grid offsets")
        column_index = grid_before
        row_cells: list[dict[str, Any]] = []
        physical_cells: list[tuple[Any, DocxSourceReference]] = []

        def collect_cells(container: Any) -> None:
            for child in container:
                name = _word_name(child)
                if name == "tc":
                    physical_cell_index = len(physical_cells)
                    physical_cells.append(
                        (
                            child,
                            _source(
                                state,
                                story_type=story_type,
                                story_id=story_id,
                                block_index=block_index,
                                table_index=table_index,
                                table_path=table_path,
                                row_index=row_index,
                                cell_index=physical_cell_index,
                            ),
                        )
                    )
                elif name == "sdt":
                    physical_cell_index = len(physical_cells)
                    control_source = _source(
                        state,
                        story_type=story_type,
                        story_id=story_id,
                        block_index=block_index,
                        table_index=table_index,
                        table_path=table_path,
                        row_index=row_index,
                        cell_index=physical_cell_index,
                    )
                    state.controls.append(
                        _content_control(
                            child,
                            state=state,
                            source=control_source,
                            blocks=(),
                        )
                    )
                    content = _child(child, "sdtContent")
                    if content is not None:
                        collect_cells(content)
                elif name in {"ins", "del", "moveFrom", "moveTo"}:
                    state.element_sources[id(child)] = _source(
                        state,
                        story_type=story_type,
                        story_id=story_id,
                        block_index=block_index,
                        table_index=table_index,
                        table_path=table_path,
                        row_index=row_index,
                    )
                    if _revision_included(name, state.options.revision_view):
                        collect_cells(child)

        collect_cells(row)
        parsed_cells: list[dict[str, Any]] = []
        horizontal_anchor: dict[str, Any] | None = None
        for physical_cell_index, (cell, cell_source) in enumerate(physical_cells):
            state.counters.add("table_cells")
            cell_properties = _child(cell, "tcPr")
            if cell_properties is not None:
                for descendant in cell_properties.iter():
                    if _word_name(descendant) in {
                        "tcPrChange",
                        "cellIns",
                        "cellDel",
                        "cellMerge",
                    }:
                        state.element_sources[id(descendant)] = cell_source
            span_node = (
                None if cell_properties is None else _child(cell_properties, "gridSpan")
            )
            column_span = (
                1 if span_node is None else (_int(_attr(span_node, "val")) or 0)
            )
            if column_span < 1:
                raise DocxPackageInvalidError(
                    "A DOCX table contains an invalid grid span"
                )
            merge_node = (
                None if cell_properties is None else _child(cell_properties, "vMerge")
            )
            merge_value = None if merge_node is None else _attr(merge_node, "val")
            if merge_value not in {None, "restart", "continue"}:
                raise DocxPackageInvalidError(
                    "A DOCX table contains an invalid vertical merge value"
                )
            horizontal = (
                None if cell_properties is None else _child(cell_properties, "hMerge")
            )
            horizontal_value = None if horizontal is None else _attr(horizontal, "val")
            if horizontal_value not in {None, "restart", "continue"}:
                raise DocxPackageInvalidError(
                    "A DOCX table contains an invalid horizontal merge value"
                )
            blocks: list[DocxParagraph | DocxTable] = []
            paragraph_counter = 0

            def add_cell_blocks(container: Any) -> None:
                nonlocal paragraph_counter
                for child in container:
                    name = _word_name(child)
                    before = len(blocks)
                    if name == "p":
                        blocks.append(
                            _paragraph(
                                child,
                                state=state,
                                story_type=story_type,
                                story_id=story_id,
                                block_index=block_index,
                                paragraph_index=paragraph_counter,
                                relationships=relationships,
                                owner_part=owner_part,
                                identity_prefix=(
                                    "t"
                                    + "-".join(str(index) for index in table_path)
                                    + f"-r{row_index}-c{physical_cell_index}"
                                ),
                                table_path=table_path,
                                row_index=row_index,
                                cell_index=physical_cell_index,
                            )
                        )
                        paragraph_counter += 1
                    elif name == "tbl":
                        blocks.append(
                            _table(
                                child,
                                state=state,
                                story_type=story_type,
                                story_id=story_id,
                                block_index=block_index,
                                relationships=relationships,
                                nested_depth=nested_depth + 1,
                                parent_table_path=table_path,
                                owner_part=owner_part,
                            )
                        )
                    elif name == "sdt":
                        content = _child(child, "sdtContent")
                        if content is not None:
                            add_cell_blocks(content)
                        state.controls.append(
                            _content_control(
                                child,
                                state=state,
                                source=cell_source,
                                blocks=tuple(blocks[before:]),
                            )
                        )
                    elif name in {"ins", "del", "moveFrom", "moveTo"}:
                        state.element_sources[id(child)] = cell_source
                        if _revision_included(name, state.options.revision_view):
                            add_cell_blocks(child)

            add_cell_blocks(cell)
            text = "\n".join(_block_text(block) for block in blocks)
            cell_data: dict[str, Any] = {
                "row_index": row_index,
                "column_index": 0,
                "row_span": 1,
                "column_span": column_span,
                "blocks": tuple(blocks),
                "text": text,
                "row_header": bool(row_header),
                "source": cell_source,
                "vertical": (
                    None
                    if merge_node is None
                    else ("restart" if merge_value == "restart" else "continue")
                ),
            }
            if horizontal is not None and horizontal_value != "restart":
                if horizontal_anchor is None:
                    raise DocxPackageInvalidError(
                        "A DOCX table contains a malformed horizontal merge chain"
                    )
                if horizontal_anchor["vertical"] != cell_data["vertical"]:
                    raise DocxPackageInvalidError(
                        "A DOCX table merge has inconsistent spans"
                    )
                horizontal_anchor["column_span"] += column_span
                if blocks:
                    horizontal_anchor["blocks"] = (
                        *horizontal_anchor["blocks"],
                        *blocks,
                    )
                    horizontal_anchor["text"] = "\n".join(
                        value for value in (horizontal_anchor["text"], text) if value
                    )
                    state.warning("horizontal_merge_continuation_content")
            else:
                parsed_cells.append(cell_data)
                horizontal_anchor = (
                    cell_data
                    if horizontal is not None and horizontal_value == "restart"
                    else None
                )

        next_vertical: dict[int, dict[str, Any]] = {}
        for cell_data in parsed_cells:
            column_span = cast("int", cell_data["column_span"])
            cell_data["column_index"] = column_index
            vertical = cell_data.pop("vertical")
            columns = range(column_index, column_index + column_span)
            if vertical == "continue":
                anchors = {
                    id(active_vertical[column])
                    for column in columns
                    if column in active_vertical
                }
                if len(anchors) != 1 or any(
                    column not in active_vertical for column in columns
                ):
                    raise DocxPackageInvalidError(
                        "A DOCX table contains a malformed vertical merge chain"
                    )
                anchor = active_vertical[column_index]
                if (
                    anchor["column_index"] != column_index
                    or anchor["column_span"] != column_span
                ):
                    raise DocxPackageInvalidError(
                        "A DOCX table vertical merge has inconsistent spans"
                    )
                anchor["row_span"] += 1
                if cell_data["blocks"]:
                    anchor["blocks"] = (
                        *anchor["blocks"],
                        *cell_data["blocks"],
                    )
                    anchor["text"] = "\n".join(
                        value for value in (anchor["text"], cell_data["text"]) if value
                    )
                    state.warning("vertical_merge_continuation_content")
                for column in columns:
                    next_vertical[column] = anchor
            else:
                row_cells.append(cell_data)
                if vertical == "restart":
                    for column in columns:
                        next_vertical[column] = cell_data
            column_index += column_span
        column_index += grid_after
        if declared_grid_columns is not None and column_index != declared_grid_columns:
            state.warning("incomplete_table_grid")
        logical_columns = max(
            logical_columns,
            column_index,
            declared_grid_columns or 0,
        )
        active_vertical = next_vertical
        mutable_rows.append(row_cells)
    rows = tuple(
        DocxTableRow(
            row_index=row_index,
            cells=tuple(DocxTableCell(**cell) for cell in cells),
            is_header=any(cell["row_header"] for cell in cells),
            source=_source(
                state,
                story_type=story_type,
                story_id=story_id,
                block_index=block_index,
                table_index=table_index,
                table_path=table_path,
                row_index=row_index,
            ),
        )
        for row_index, cells in enumerate(mutable_rows)
    )
    return DocxTable(
        table_id=(f"{story_id}-t" + "-".join(str(index) for index in table_path)),
        table_index=table_index,
        rows=rows,
        logical_column_count=logical_columns,
        caption=None if caption_node is None else _attr(caption_node, "val"),
        description=(
            None if description_node is None else _attr(description_node, "val")
        ),
        nested_depth=nested_depth,
        source=table_source,
    )


def _content_control(
    element: Any,
    *,
    state: _ParseState,
    source: DocxSourceReference,
    blocks: tuple[DocxParagraph | DocxTable, ...],
) -> DocxContentControl:
    state.counters.add("content_controls")
    properties = _child(element, "sdtPr")
    if properties is None:
        state.warning("unsupported_content_controls")
        properties = element
    id_node = _child(properties, "id")
    tag_node = _child(properties, "tag")
    alias_node = _child(properties, "alias")
    lock_node = _child(properties, "lock")
    control_type = "rich_text"
    value: str | bool | Any | None = None
    list_values: list[str] = []
    selected_value: str | None = None
    checkbox = properties.find(_q(_W14, "checkbox"))
    if checkbox is None:
        checkbox = properties.find(_q(_W14, "checkBox"))
    if checkbox is None:
        checkbox = properties.find(_q(_W, "checkBox"))
    date_node = _child(properties, "date")
    dropdown = _child(properties, "dropDownList")
    combo = _child(properties, "comboBox")
    if checkbox is not None:
        control_type = "checkbox"
        checked = checkbox.find(_q(_W14, "checked"))
        if checked is None:
            checked = checkbox.find(_q(_W, "checked"))
        checked_value = (
            None
            if checked is None
            else checked.attrib.get(_q(_W14, "val"))
            or checked.attrib.get(_q(_W, "val"))
        )
        value = (
            None
            if checked is None
            else checked_value is None
            or checked_value.casefold() not in {"0", "false", "off"}
        )
    elif date_node is not None:
        control_type = "date"
        full_date = _attr(date_node, "fullDate")
        parsed = _datetime(full_date)
        value = None if parsed is None else parsed.date()
        if full_date and parsed is None:
            state.warning("ambiguous_content_control_value")
    elif dropdown is not None or combo is not None:
        list_node = dropdown if dropdown is not None else combo
        control_type = "drop_down" if dropdown is not None else "combo_box"
        for item in _children(list_node, "listItem"):
            item_value = _attr(item, "value") or _attr(item, "displayText")
            if item_value is not None:
                list_values.append(item_value)
    elif _child(properties, "picture") is not None:
        control_type = "picture"
    elif _child(properties, "text") is not None:
        control_type = "plain_text"
    elif properties.find(_q(_W15, "repeatingSection")) is not None:
        control_type = "repeating_section"
    content = _child(element, "sdtContent")
    text_value = (
        "\n".join(_block_text(block) for block in blocks)
        if blocks
        else _projected_text(
            content if content is not None else element,
            state.options.revision_view,
        )
    )
    if value is None and control_type in {
        "plain_text",
        "rich_text",
        "drop_down",
        "combo_box",
    }:
        value = text_value
        selected_value = text_value or None
    raw_id = None if id_node is None else _attr(id_node, "val")
    ordinal = state.counters.content_controls - 1
    control_id = (
        f"{source.story_id}-sdt{ordinal}"
        if raw_id is None
        else f"{source.story_id}-sdt{ordinal}-{raw_id}"
    )
    return DocxContentControl(
        control_id=control_id,
        sdt_id=raw_id,
        tag=None if tag_node is None else _attr(tag_node, "val"),
        alias=None if alias_node is None else _attr(alias_node, "val"),
        control_type=control_type,
        lock_state=None if lock_node is None else _attr(lock_node, "val"),
        placeholder=_on_off(_child(properties, "showingPlcHdr")) is True,
        list_values=tuple(list_values),
        selected_value=selected_value,
        value=value,
        blocks=blocks,
        source=source,
    )


def _story_blocks(
    container: Any,
    *,
    state: _ParseState,
    story_type: DocxStoryType,
    story_id: str,
    relationships: dict[str, Relationship],
    owner_part: str,
) -> tuple[DocxParagraph | DocxTable, ...]:
    blocks: list[DocxParagraph | DocxTable] = []
    paragraph_index = 0

    def add_block(node: Any) -> None:
        nonlocal paragraph_index
        name = _word_name(node)
        block_index = len(blocks)
        if name == "p":
            blocks.append(
                _paragraph(
                    node,
                    state=state,
                    story_type=story_type,
                    story_id=story_id,
                    block_index=block_index,
                    paragraph_index=paragraph_index,
                    relationships=relationships,
                    owner_part=owner_part,
                )
            )
            paragraph_index += 1
        elif name == "tbl":
            blocks.append(
                _table(
                    node,
                    state=state,
                    story_type=story_type,
                    story_id=story_id,
                    block_index=block_index,
                    relationships=relationships,
                    nested_depth=0,
                    parent_table_path=(),
                    owner_part=owner_part,
                )
            )
        elif name == "sdt":
            content = _child(node, "sdtContent")
            before = len(blocks)
            if content is not None:
                for child in content:
                    add_block(child)
            control_blocks = tuple(blocks[before:])
            state.controls.append(
                _content_control(
                    node,
                    state=state,
                    source=_source(
                        state,
                        story_type=story_type,
                        story_id=story_id,
                        block_index=before,
                    ),
                    blocks=control_blocks,
                )
            )
        elif name in {"ins", "del", "moveFrom", "moveTo"}:
            state.element_sources[id(node)] = _source(
                state,
                story_type=story_type,
                story_id=story_id,
                block_index=block_index,
            )
            if _revision_included(name, state.options.revision_view):
                for child in node:
                    add_block(child)
        elif name == "altChunk":
            state.warning("alt_chunk")
        elif name not in {"sectPr", "bookmarkStart", "bookmarkEnd"}:
            state.warning("unsupported_block_markup")

    for child in container:
        add_block(child)
    return tuple(blocks)


def _refresh_bookmark_evidence(
    blocks: tuple[DocxParagraph | DocxTable, ...],
    state: _ParseState,
) -> tuple[DocxParagraph | DocxTable, ...]:
    by_id = {bookmark.bookmark_id: bookmark for bookmark in state.bookmarks}

    def refresh(block: DocxParagraph | DocxTable) -> DocxParagraph | DocxTable:
        if isinstance(block, DocxParagraph):
            unique_ids = tuple(
                dict.fromkeys(item.bookmark_id for item in block.bookmarks)
            )
            return block.model_copy(
                update={
                    "bookmarks": tuple(
                        by_id[bookmark_id]
                        for bookmark_id in unique_ids
                        if bookmark_id in by_id
                    )
                }
            )
        rows = []
        for row in block.rows:
            cells = []
            for cell in row.cells:
                cells.append(
                    cell.model_copy(
                        update={"blocks": tuple(refresh(item) for item in cell.blocks)}
                    )
                )
            rows.append(row.model_copy(update={"cells": tuple(cells)}))
        return block.model_copy(update={"rows": tuple(rows)})

    return tuple(refresh(block) for block in blocks)


def _story(
    package: DocxPackage,
    *,
    state: _ParseState,
    part: str,
    story_type: DocxStoryType,
    story_id: str,
    container: Any | None = None,
) -> DocxStory:
    root = package.read_xml(part) if container is None else container
    if container is None:
        state.auxiliary_roots.append(root)
    state.story_roots.append((root, story_type, story_id))
    relationships = package.relationship_map(part)
    blocks = _story_blocks(
        root,
        state=state,
        story_type=story_type,
        story_id=story_id,
        relationships=relationships,
        owner_part=part,
    )
    unclosed = tuple(key for key in state.open_bookmarks if key[0] == story_id)
    if unclosed:
        state.warning("malformed_bookmark_range", len(unclosed))
        for key in unclosed:
            state.open_bookmarks.pop(key, None)
    blocks = _refresh_bookmark_evidence(blocks, state)
    sources = tuple(block.source for block in blocks)
    return DocxStory(
        story_id=story_id,
        story_type=story_type,
        part_role=story_type.value,
        blocks=blocks,
        sources=sources,
    )


def _projected_sections(
    body: Any,
    *,
    state: _ParseState,
    main_part: str,
) -> tuple[tuple[Any, DocxSourceReference], ...]:
    """Collect only active section properties for the selected revision view."""
    projected: list[tuple[Any, DocxSourceReference]] = []
    property_snapshots = {
        "pPrChange",
        "rPrChange",
        "sectPrChange",
        "tblPrChange",
        "trPrChange",
        "tcPrChange",
    }

    def visit(node: Any, raw_block_index: int) -> None:
        name = _word_name(node)
        if name in {"ins", "del", "moveFrom", "moveTo"} and not _revision_included(
            name, state.options.revision_view
        ):
            return
        if name in property_snapshots:
            return
        if name == "sectPr":
            source = state.element_sources.get(id(node)) or _source(
                state,
                story_type=DocxStoryType.MAIN,
                story_id="main",
                block_index=raw_block_index,
                source_role="section",
                package_part=main_part,
            )
            state.element_sources[id(node)] = source
            for change in node.iter(_q(_W, "sectPrChange")):
                state.element_sources[id(change)] = source
            projected.append((node, source))
            return
        for child in node:
            visit(child, raw_block_index)

    for raw_block_index, child in enumerate(body):
        visit(child, raw_block_index)
    return tuple(projected)


def _section(
    properties: Any,
    *,
    state: _ParseState,
    section_index: int,
    source: DocxSourceReference,
    even_and_odd_headers: bool,
    main_relationships: dict[str, Relationship],
    story_ids_by_target: dict[str, str],
) -> DocxSection:
    state.counters.add("sections")
    section_type = _child(properties, "type")
    page_size = _child(properties, "pgSz")
    margins = _child(properties, "pgMar")
    columns = _child(properties, "cols")
    references: dict[tuple[str, str], str] = {}
    for node_name, label in (
        ("headerReference", "header"),
        ("footerReference", "footer"),
    ):
        for reference in _children(properties, node_name):
            reference_type = _attr(reference, "type") or "default"
            relationship_id = reference.attrib.get(_q(_R, "id"))
            relationship = (
                None
                if relationship_id is None
                else main_relationships.get(relationship_id)
            )
            if (
                relationship is None
                or relationship.external
                or relationship.target not in story_ids_by_target
            ):
                state.warning("broken_header_footer_reference")
                continue
            references[(label, reference_type)] = story_ids_by_target[
                relationship.target
            ]
    orientation = None if page_size is None else _attr(page_size, "orient")
    width = None if page_size is None else _int(_attr(page_size, "w"))
    height = None if page_size is None else _int(_attr(page_size, "h"))
    if orientation is None and width is not None and height is not None:
        orientation = "landscape" if width > height else "portrait"
    return DocxSection(
        section_id=f"section-{section_index}",
        section_index=section_index,
        break_type=None if section_type is None else _attr(section_type, "val"),
        page_width_twips=width,
        page_height_twips=height,
        orientation=orientation,
        margin_top_twips=None if margins is None else _int(_attr(margins, "top")),
        margin_right_twips=(None if margins is None else _int(_attr(margins, "right"))),
        margin_bottom_twips=(
            None if margins is None else _int(_attr(margins, "bottom"))
        ),
        margin_left_twips=None if margins is None else _int(_attr(margins, "left")),
        column_count=None if columns is None else (_int(_attr(columns, "num")) or 1),
        title_page=_on_off(_child(properties, "titlePg")) is True,
        even_and_odd_headers=even_and_odd_headers,
        default_header_story_id=references.get(("header", "default")),
        first_header_story_id=references.get(("header", "first")),
        even_header_story_id=references.get(("header", "even")),
        default_footer_story_id=references.get(("footer", "default")),
        first_footer_story_id=references.get(("footer", "first")),
        even_footer_story_id=references.get(("footer", "even")),
        source=source,
    )


def _properties(
    package: DocxPackage,
    root_relationships: tuple[Relationship, ...],
    state: _ParseState,
) -> DocxDocumentProperties:
    warnings = state.warnings
    values: dict[str, Any] = {}
    core_relationship = _relationship_by_role(root_relationships, "core-properties")
    if core_relationship is not None and not core_relationship.external:
        core = _validated_relationship_root(
            package,
            core_relationship,
            role="core-properties",
        )
        mapping = {
            _q(_DC, "title"): "title",
            _q(_DC, "subject"): "subject",
            _q(_DC, "creator"): "creator",
            _q(_CP, "keywords"): "keywords",
            _q(_DC, "description"): "description",
            _q(_CP, "lastModifiedBy"): "last_modified_by",
        }
        for child in core:
            target = mapping.get(child.tag)
            if target is not None:
                values[target] = child.text
            elif child.tag == _q(_DCTERMS, "created"):
                values["created_at"] = _datetime(child.text)
            elif child.tag == _q(_DCTERMS, "modified"):
                values["modified_at"] = _datetime(child.text)
    extended_relationship = _relationship_by_role(
        root_relationships, "extended-properties"
    )
    if extended_relationship is not None and not extended_relationship.external:
        extended = _validated_relationship_root(
            package,
            extended_relationship,
            role="extended-properties",
        )
        for child in extended:
            if child.tag == _q(_EP, "Application"):
                values["application"] = child.text
            elif child.tag == _q(_EP, "Company"):
                values["company"] = child.text
            elif child.tag == _q(_EP, "Pages"):
                page_count = _int(child.text)
                if page_count is None or page_count < 0:
                    warnings["invalid_declared_page_count"] += 1
                else:
                    values["declared_page_count"] = page_count
    custom_properties: list[DocxCustomProperty] = []
    custom_relationship = _relationship_by_role(root_relationships, "custom-properties")
    if custom_relationship is not None and not custom_relationship.external:
        custom = _validated_relationship_root(
            package,
            custom_relationship,
            role="custom-properties",
        )
        names: set[str] = set()
        for property_index, property_node in enumerate(custom):
            if property_node.tag != _q(_CUSTOM, "property"):
                warnings["unsupported_custom_property_type"] += 1
                continue
            name = property_node.attrib.get("name", "")
            if not name or name in names:
                warnings["malformed_custom_properties"] += 1
                continue
            names.add(name)
            children = tuple(property_node)
            if len(children) != 1:
                warnings["unsupported_custom_property_type"] += 1
                custom_properties.append(
                    DocxCustomProperty(
                        name=name,
                        value_type="unsupported",
                        supported=False,
                        source=_source(
                            state,
                            story_type="custom_property",
                            story_id="custom-properties",
                            block_index=property_index,
                            source_role="custom_property",
                            package_part=custom_relationship.target,
                        ),
                    )
                )
                continue
            value_node = children[0]
            value_type = (
                str(value_node.tag).removeprefix(f"{{{_VT}}}")
                if str(value_node.tag).startswith(f"{{{_VT}}}")
                else "unsupported"
            )
            raw = value_node.text or ""
            value: str | int | Decimal | bool | datetime | None
            supported = True
            try:
                if value_type in {"lpwstr", "lpstr", "bstr"}:
                    value = raw
                elif value_type in {"i1", "i2", "i4", "i8", "int", "uint"}:
                    value = int(raw)
                elif value_type in {"r4", "r8", "decimal"}:
                    value = Decimal(raw)
                elif value_type == "bool":
                    if raw.casefold() not in {"true", "false", "1", "0"}:
                        raise ValueError
                    value = raw.casefold() in {"true", "1"}
                elif value_type in {"filetime", "date"}:
                    parsed = _datetime(raw)
                    if parsed is None:
                        raise ValueError
                    value = parsed
                else:
                    value = None
                    supported = False
            except (InvalidOperation, ValueError):
                value = None
                supported = False
            if not supported:
                warnings["unsupported_custom_property_type"] += 1
            custom_properties.append(
                DocxCustomProperty(
                    name=name,
                    value_type=value_type,
                    value=value,
                    raw_value=None if supported else raw,
                    supported=supported,
                    source=_source(
                        state,
                        story_type="custom_property",
                        story_id="custom-properties",
                        block_index=property_index,
                        source_role="custom_property",
                        package_part=custom_relationship.target,
                    ),
                )
            )
    values["custom_properties"] = tuple(custom_properties)
    return DocxDocumentProperties(**values)


def _revision_summary(
    roots: tuple[tuple[Any, DocxStoryType, str], ...],
    state: _ParseState,
) -> DocxTrackChangesSummary:
    counts: Counter[str] = Counter()
    authors: set[str] = set()
    dates: set[datetime] = set()
    sources: list[DocxSourceReference] = []
    mapping = {
        _q(_W, "ins"): "insertions",
        _q(_W, "del"): "deletions",
        _q(_W, "moveFrom"): "move_from",
        _q(_W, "moveTo"): "move_to",
        _q(_W, "pPrChange"): "paragraph_property_changes",
        _q(_W, "rPrChange"): "run_property_changes",
        _q(_W, "sectPrChange"): "section_property_changes",
        _q(_W, "tblPrChange"): "table_property_changes",
        _q(_W, "trPrChange"): "table_property_changes",
        _q(_W, "tcPrChange"): "table_property_changes",
        _q(_W, "cellIns"): "table_property_changes",
        _q(_W, "cellDel"): "table_property_changes",
        _q(_W, "cellMerge"): "table_property_changes",
    }
    for root, story_type, story_id in roots:
        for element in root.iter():
            category = mapping.get(element.tag)
            if category is None:
                continue
            counts[category] += 1
            author = _attr(element, "author")
            when = _datetime(_attr(element, "date"))
            if author:
                authors.add(author)
            if when:
                dates.add(when)
            sources.append(
                state.element_sources.get(id(element))
                or _source(
                    state,
                    story_type=story_type,
                    story_id=story_id,
                    block_index=0,
                )
            )
            if category.endswith("_property_changes") or element.tag in {
                _q(_W, "cellIns"),
                _q(_W, "cellDel"),
                _q(_W, "cellMerge"),
            }:
                state.warning("unprojected_structural_revision")
    summary = DocxTrackChangesSummary(
        insertions=counts["insertions"],
        deletions=counts["deletions"],
        move_from=counts["move_from"],
        move_to=counts["move_to"],
        paragraph_property_changes=counts["paragraph_property_changes"],
        run_property_changes=counts["run_property_changes"],
        section_property_changes=counts["section_property_changes"],
        table_property_changes=counts["table_property_changes"],
        authors=tuple(sorted(authors)),
        dates=tuple(sorted(dates)),
        sources=tuple(
            {source.model_dump_json(): source for source in sources}.values()
        ),
    )
    if summary.present:
        state.warning("track_changes")
    return summary


def _resource_type(relationship: Relationship) -> str:
    role = _relationship_role(relationship)
    if role == "image":
        return "external_linked_resource" if relationship.external else "image"
    if role in {"package", "oleObject"}:
        return "embedded_package" if role == "package" else "ole_object"
    if role == "control":
        return "activex"
    if role in {"audio", "video"}:
        return "audio_video"
    return "unknown_binary"


@dataclass(frozen=True)
class _ResourcePartEvidence:
    """One unique internal package part reused by relationship evidence."""

    relationship_role: str
    resource_type: str
    content_type: str | None
    byte_size: int | None
    sha256: str | None
    present: bool


@dataclass(frozen=True)
class _ResourceInventory:
    """Relationship-level evidence plus unique package-part counts."""

    resources: tuple[DocxEmbeddedResource, ...]
    media_part_count: int
    embedded_part_count: int


def _resources(
    package: DocxPackage,
    owners: tuple[str, ...],
    warnings: Counter[str],
    metadata: dict[tuple[str, str], tuple[str | None, str | None]],
) -> _ResourceInventory:
    resources: list[DocxEmbeddedResource] = []
    seen: set[tuple[str, str]] = set()
    part_cache: dict[str, _ResourcePartEvidence] = {}
    embedded_total = 0
    media_count = embedded_count = 0
    for owner in owners:
        for relationship in package.relationships(owner):
            role = _relationship_role(relationship)
            if role not in _RESOURCE_RELATIONSHIP_ROLES:
                continue
            key = owner, relationship.relationship_id
            if key in seen:
                continue
            seen.add(key)
            resource_type = _resource_type(relationship)
            content_type = None
            byte_size = None
            digest = None
            basename = _safe_basename(relationship.target)
            if relationship.external:
                warnings["external_linked_resource"] += 1
            else:
                part = part_cache.get(relationship.target)
                if part is not None:
                    if part.relationship_role != role:
                        raise DocxPackageInvalidError(
                            "A DOCX resource part has incompatible relationship roles"
                        )
                else:
                    member = package.member_metadata(relationship.target)
                    content_type = package.content_type(relationship.target)
                    if member is None:
                        part = _ResourcePartEvidence(
                            relationship_role=role,
                            resource_type=resource_type,
                            content_type=content_type,
                            byte_size=None,
                            sha256=None,
                            present=False,
                        )
                    else:
                        byte_size = member.file_size
                        if resource_type == "image":
                            media_count += 1
                            if media_count > package.limits.max_media_parts:
                                raise DocxResourceLimitError(
                                    limit_name="media_parts",
                                    observed=media_count,
                                    maximum=package.limits.max_media_parts,
                                )
                        else:
                            embedded_count += 1
                            if embedded_count > package.limits.max_embedded_parts:
                                raise DocxResourceLimitError(
                                    limit_name="embedded_parts",
                                    observed=embedded_count,
                                    maximum=package.limits.max_embedded_parts,
                                )
                            next_total = embedded_total + member.file_size
                            if next_total > package.limits.max_embedded_total_bytes:
                                raise DocxResourceLimitError(
                                    limit_name="embedded_total_bytes",
                                    observed=next_total,
                                    maximum=package.limits.max_embedded_total_bytes,
                                )
                            embedded_total = next_total
                        observed_size, digest = package.hash_part(relationship.target)
                        if observed_size != member.file_size:
                            raise DocxPackageInvalidError(
                                "A DOCX resource member size is inconsistent"
                            )
                        part = _ResourcePartEvidence(
                            relationship_role=role,
                            resource_type=resource_type,
                            content_type=content_type,
                            byte_size=byte_size,
                            sha256=digest,
                            present=True,
                        )
                    part_cache[relationship.target] = part
                content_type = part.content_type
                byte_size = part.byte_size
                digest = part.sha256
                if not part.present:
                    warnings["missing_embedded_resource"] += 1
            if resource_type in {"ole_object", "activex"}:
                warnings[resource_type] += 1
            resources.append(
                DocxEmbeddedResource(
                    resource_id=_resource_id(owner, relationship.relationship_id),
                    relationship_role=role,
                    resource_type=resource_type,
                    content_type=content_type,
                    safe_basename=basename,
                    byte_size=byte_size,
                    sha256=digest,
                    internal=not relationship.external,
                    alt_text=metadata.get(
                        (owner, relationship.relationship_id),
                        (None, None),
                    )[0],
                    description=metadata.get(
                        (owner, relationship.relationship_id),
                        (None, None),
                    )[0],
                    title=metadata.get(
                        (owner, relationship.relationship_id),
                        (None, None),
                    )[1],
                )
            )
    return _ResourceInventory(
        resources=tuple(resources),
        media_part_count=media_count,
        embedded_part_count=embedded_count,
    )


def _comments(
    package: DocxPackage,
    relationship: Relationship | None,
    state: _ParseState,
) -> tuple[tuple[DocxComment, ...], tuple[DocxStory, ...], tuple[Any, ...]]:
    if (
        relationship is None
        or relationship.external
        or not state.options.include_comments
    ):
        return (), (), ()
    root = _validated_relationship_root(
        package,
        relationship,
        role="comments",
    )
    comments: list[DocxComment] = []
    stories: list[DocxStory] = []
    ids: set[str] = set()
    for comment_node in _children(root, "comment"):
        comment_id = _attr(comment_node, "id")
        if comment_id is None or comment_id in ids:
            state.warning("duplicate_or_missing_comment_id")
            continue
        ids.add(comment_id)
        if len(comments) >= state.counters.limits.max_comments:
            raise DocxResourceLimitError(
                limit_name="comments",
                observed=len(comments) + 1,
                maximum=state.counters.limits.max_comments,
            )
        story_id = f"comment-{comment_id}"
        story = _story(
            package,
            state=state,
            part=relationship.target,
            story_type=DocxStoryType.COMMENT,
            story_id=story_id,
            container=comment_node,
        )
        stories.append(story)
        anchors = state.comment_ranges.get(comment_id, {})
        comments.append(
            DocxComment(
                comment_id=comment_id,
                author=_attr(comment_node, "author"),
                initials=_attr(comment_node, "initials"),
                created_at=_datetime(_attr(comment_node, "date")),
                blocks=story.blocks,
                range_start=anchors.get("start"),
                range_end=anchors.get("end"),
                reference=anchors.get("reference"),
                source=_source(
                    state,
                    story_type=DocxStoryType.COMMENT,
                    story_id=story_id,
                    block_index=0,
                ),
            )
        )
        if set(anchors) not in (set(), {"start", "end", "reference"}):
            state.warning("incomplete_comment_anchor")
    if any(comment_id not in ids for comment_id in state.comment_ranges):
        raise DocxPackageInvalidError(
            "The DOCX contains a comment reference without a definition"
        )
    for comment_id in ids:
        if comment_id not in state.comment_ranges:
            state.warning("unreferenced_comment")
    return tuple(comments), tuple(stories), (root,)


def _notes(
    package: DocxPackage,
    relationship: Relationship | None,
    *,
    state: _ParseState,
    story_type: DocxStoryType,
) -> tuple[
    tuple[DocxFootnote, ...] | tuple[DocxEndnote, ...],
    tuple[DocxStory, ...],
    tuple[Any, ...],
    int,
]:
    enabled = (
        state.options.include_footnotes
        if story_type is DocxStoryType.FOOTNOTE
        else state.options.include_endnotes
    )
    if relationship is None or relationship.external or not enabled:
        return (), (), (), 0
    role = "footnotes" if story_type is DocxStoryType.FOOTNOTE else "endnotes"
    root = _validated_relationship_root(package, relationship, role=role)
    element_name = "footnote" if story_type is DocxStoryType.FOOTNOTE else "endnote"
    references = (
        state.note_references
        if story_type is DocxStoryType.FOOTNOTE
        else state.endnote_references
    )
    maximum = (
        state.counters.limits.max_footnotes
        if story_type is DocxStoryType.FOOTNOTE
        else state.counters.limits.max_endnotes
    )
    notes: list[DocxFootnote | DocxEndnote] = []
    stories: list[DocxStory] = []
    ids: set[str] = set()
    separator_count = 0
    for note_node in _children(root, element_name):
        note_id = _attr(note_node, "id")
        note_type = _attr(note_node, "type")
        if note_id is None or note_id in ids:
            state.warning(f"duplicate_or_missing_{element_name}_id")
            continue
        ids.add(note_id)
        if note_type in {"separator", "continuationSeparator"} or (
            _int(note_id) is not None and cast("int", _int(note_id)) < 0
        ):
            separator_count += 1
            continue
        if len(notes) >= maximum:
            raise DocxResourceLimitError(
                limit_name=f"{element_name}s",
                observed=len(notes) + 1,
                maximum=maximum,
            )
        story_id = f"{element_name}-{note_id}"
        story = _story(
            package,
            state=state,
            part=relationship.target,
            story_type=story_type,
            story_id=story_id,
            container=note_node,
        )
        stories.append(story)
        source = _source(
            state,
            story_type=story_type,
            story_id=story_id,
            block_index=0,
        )
        if story_type is DocxStoryType.FOOTNOTE:
            notes.append(
                DocxFootnote(
                    note_id=note_id,
                    blocks=story.blocks,
                    reference_sources=tuple(references.get(note_id, ())),
                    source=source,
                )
            )
        else:
            notes.append(
                DocxEndnote(
                    note_id=note_id,
                    blocks=story.blocks,
                    reference_sources=tuple(references.get(note_id, ())),
                    source=source,
                )
            )
    user_ids = {note.note_id for note in notes}
    if any(note_id not in user_ids for note_id in references):
        raise DocxPackageInvalidError(
            "The DOCX contains a note reference without a definition"
        )
    for note_id in user_ids:
        if note_id not in references:
            state.warning(f"unreferenced_{element_name}")
    if story_type is DocxStoryType.FOOTNOTE:
        return (
            cast("tuple[DocxFootnote, ...]", tuple(notes)),
            tuple(stories),
            (root,),
            separator_count,
        )
    return (
        cast("tuple[DocxEndnote, ...]", tuple(notes)),
        tuple(stories),
        (root,),
        separator_count,
    )


def _unsupported_inventory(
    package: DocxPackage,
    roots: tuple[Any, ...],
    warnings: Counter[str],
    owners: tuple[str, ...],
) -> None:
    relationships = tuple(
        relationship
        for owner in owners
        for relationship in package.relationships(owner)
    )
    relationship_categories = {
        "attachedTemplate": "external_template",
        "customXml": "custom_xml_data_binding",
        "control": "activex",
        "oleObject": "ole_object",
        "aFChunk": "alt_chunk",
        "font": "embedded_font",
        "digital-signature": "digital_signature_not_validated",
    }
    for relationship in relationships:
        role = _relationship_role(relationship)
        if role is None:
            continue
        category = relationship_categories.get(role)
        if category is not None:
            warnings[category] += 1
        if relationship.external and role != "hyperlink":
            warnings["external_relationship"] += 1
    element_categories = {
        _q(_W, "altChunk"): "alt_chunk",
        _q(_M, "oMath"): "omml_equation",
        _q(_M, "oMathPara"): "omml_equation",
        _q(_W, "txbxContent"): "text_box_partial",
        _q(_W, "instrText"): "field_not_evaluated",
        _q(_W, "fldSimple"): "field_not_evaluated",
        _q(_W, "dataBinding"): "custom_xml_data_binding",
        _q(_W, "object"): "ole_object",
    }
    for root in roots:
        for element in root.iter():
            category = element_categories.get(element.tag)
            if category is not None:
                warnings[category] += 1


def _warning_models(warnings: Counter[str]) -> tuple[ProcessingWarning, ...]:
    return tuple(
        ProcessingWarning(
            code=f"docx.{category}",
            category=category,
            message=(
                "The DOCX contains fidelity or reference evidence requiring review."
            ),
            count=count,
        )
        for category, count in sorted(warnings.items())
        if count > 0
    )


def _core_table(table: DocxTable) -> Table:
    cells = tuple(
        TableCell(
            row=cell.row_index + 1,
            column=cell.column_index + 1,
            row_span=cell.row_span,
            column_span=cell.column_span,
            text=cell.text,
            source=cell.source,
            sources=(cell.source,),
        )
        for row in table.rows
        for cell in row.cells
    )
    return Table(
        cells=cells,
        source=table.source,
        row_count=max((row.row_index for row in table.rows), default=-1) + 1 or None,
        column_count=table.logical_column_count or None,
        element_id=table.table_id,
        sources=(table.source,),
    )


def _normalized_document(
    descriptor: FileDescriptor,
    structure: DocxDocumentStructure,
    properties: DocxDocumentProperties,
    options: DocxAnalysisOptions,
    state: _ParseState,
) -> Document:
    paragraphs: list[DocumentParagraph] = []
    tables: list[Table] = []
    key_values: list[DocumentKeyValuePair] = []
    sections: list[DocumentSection] = []

    def add_block(block: DocxParagraph | DocxTable) -> None:
        if isinstance(block, DocxParagraph):
            paragraphs.append(
                DocumentParagraph(
                    element_id=f"docx-{block.paragraph_id}",
                    content=block.text,
                    role=(
                        None
                        if not block.is_heading
                        else f"heading_{(block.outline_level or 0) + 1}"
                    ),
                    sources=(block.source,),
                )
            )
            return
        tables.append(_core_table(block))
        for row in block.rows:
            for cell in row.cells:
                for nested in cell.blocks:
                    add_block(nested)

    for story in structure.stories:
        for block in story.blocks:
            add_block(block)
    for control in structure.content_controls:
        key = control.tag or control.alias
        if key and control.value is not None:
            key_values.append(
                DocumentKeyValuePair(
                    element_id=f"docx-control-{len(key_values)}",
                    key=DocumentKeyValueElement(
                        content=key,
                        sources=(control.source,),
                    ),
                    value=DocumentKeyValueElement(
                        content=(
                            control.value.isoformat()
                            if isinstance(control.value, date)
                            else str(control.value)
                        ),
                        sources=(control.source,),
                    ),
                    sources=(control.source,),
                )
            )
    if options.include_custom_properties_as_key_values:
        for custom in properties.custom_properties:
            if custom.supported and custom.value is not None:
                key_values.append(
                    DocumentKeyValuePair(
                        element_id=f"docx-property-{len(key_values)}",
                        key=DocumentKeyValueElement(
                            content=custom.name,
                            sources=(custom.source,),
                        ),
                        value=DocumentKeyValueElement(
                            content=(
                                custom.value.isoformat()
                                if isinstance(custom.value, datetime)
                                else str(custom.value)
                            ),
                            sources=(custom.source,),
                        ),
                        sources=(custom.source,),
                    )
                )
    if options.extract_two_column_key_value_tables:
        for story in structure.stories:
            for block in story.blocks:
                if not isinstance(block, DocxTable) or block.nested_depth:
                    continue
                for row in block.rows:
                    cells = row.cells
                    if (
                        len(cells) != 2
                        or any(
                            cell.row_span != 1 or cell.column_span != 1
                            for cell in cells
                        )
                        or not cells[0].text.strip()
                    ):
                        state.warning("skipped_two_column_key_value_row")
                        continue
                    key_values.append(
                        DocumentKeyValuePair(
                            element_id=f"docx-table-kv-{len(key_values)}",
                            key=DocumentKeyValueElement(
                                content=cells[0].text,
                                sources=(cells[0].source,),
                            ),
                            value=DocumentKeyValueElement(
                                content=cells[1].text,
                                sources=(cells[1].source,),
                            ),
                            sources=(cells[0].source, cells[1].source),
                        )
                    )
    for section in structure.sections:
        sections.append(
            DocumentSection(
                element_id=f"docx-{section.section_id}",
                sources=(section.source,),
            )
        )
    return Document(
        file=descriptor,
        tables=tuple(tables),
        paragraphs=tuple(paragraphs),
        key_value_pairs=tuple(key_values),
        sections=tuple(sections),
    )


def _descriptor(path: Path, sha256: str, byte_size: int) -> FileDescriptor:
    source_name = unicodedata.normalize("NFKC", path.name)
    if (
        not source_name
        or source_name in {".", ".."}
        or "/" in source_name
        or "\\" in source_name
        or any(
            ord(character) < 32 or ord(character) == 127 for character in source_name
        )
    ):
        raise DocxPackageInvalidError("The DOCX source name is unsafe")
    return FileDescriptor(
        file_id=sha256,
        filename=source_name,
        extension=".docx",
        mime_type=_DOCX_MEDIA_TYPE,
        size_bytes=byte_size,
        fingerprint=FileFingerprint(value=sha256),
    )


def _envelope(
    descriptor: FileDescriptor,
    *,
    extension_mismatch: bool,
) -> DocumentEnvelope:
    return DocumentEnvelope(
        document_type=DocumentType.WORD,
        document_format=DocumentFormat.DOCX,
        media_type=_DOCX_MEDIA_TYPE,
        source_name=descriptor.filename,
        sha256=descriptor.fingerprint.value,
        byte_size=descriptor.size_bytes,
        sdk_version=__version__,
        extension_mismatch=extension_mismatch,
    )


def _package_summary(
    package: DocxPackage,
    resources: _ResourceInventory,
    warnings: Counter[str],
    *,
    separator_footnotes: int = 0,
    separator_endnotes: int = 0,
) -> DocxPackageSummary:
    return DocxPackageSummary(
        member_count=package.member_count,
        total_uncompressed_bytes=package.total_uncompressed_bytes,
        xml_part_count=package.xml_part_count,
        relationship_count=package.relationship_count,
        media_part_count=resources.media_part_count,
        embedded_part_count=resources.embedded_part_count,
        separator_footnote_count=separator_footnotes,
        separator_endnote_count=separator_endnotes,
        unsupported_feature_counts=tuple(sorted(warnings.items())),
    )


def _analyze_snapshot(
    snapshot: Path,
    *,
    descriptor: FileDescriptor,
    options: DocxAnalysisOptions,
    limits: DocxProcessingLimits,
    extension_mismatch: bool,
) -> DocxAnalysisResult:
    with DocxPackage(snapshot, limits) as package:
        classification = package.classification
        if classification is None:
            raise DocxPackageInvalidError(
                "The DOCX package classification is incomplete"
            )
        main_part = classification.main_part
        main_root = _validated_part_root(
            package,
            part=main_part,
            role="document",
        )
        bodies = tuple(child for child in main_root if child.tag == _q(_W, "body"))
        if len(bodies) != 1:
            raise DocxPackageInvalidError(
                "The DOCX main story must contain exactly one body"
            )
        body = bodies[0]
        root_relationships = package.relationships("")
        main_relationships_tuple = package.relationships(main_part)
        _validate_supported_part_contracts(
            package,
            root_relationships=root_relationships,
            main_relationships=main_relationships_tuple,
        )
        main_relationships = package.relationship_map(main_part)
        warnings: Counter[str] = Counter()
        styles = _parse_styles(package, main_relationships_tuple, warnings)
        numbering, num_to_abstract = _parse_numbering(
            package,
            main_relationships_tuple,
            warnings,
        )
        state = _ParseState(
            package=package,
            options=options,
            descriptor=descriptor,
            counters=_Counters(limits),
            styles=styles,
            numbering=numbering,
            num_to_abstract=num_to_abstract,
            warnings=warnings,
        )
        auxiliary_stories: list[DocxStory] = []
        story_ids_by_target: dict[str, str] = {}
        story_parts: list[str] = [main_part]
        header_relationships = _relationships_by_role(
            main_relationships_tuple, "header"
        )
        footer_relationships = _relationships_by_role(
            main_relationships_tuple, "footer"
        )
        if len(header_relationships) > limits.max_headers:
            raise DocxResourceLimitError(
                limit_name="headers",
                observed=len(header_relationships),
                maximum=limits.max_headers,
            )
        if len(footer_relationships) > limits.max_footers:
            raise DocxResourceLimitError(
                limit_name="footers",
                observed=len(footer_relationships),
                maximum=limits.max_footers,
            )
        if options.include_headers:
            for index, relationship in enumerate(header_relationships):
                if relationship.external:
                    warnings["external_header"] += 1
                    continue
                if relationship.target in story_ids_by_target:
                    continue
                story_id = f"header-{index}"
                story_ids_by_target[relationship.target] = story_id
                story_parts.append(relationship.target)
                auxiliary_stories.append(
                    _story(
                        package,
                        state=state,
                        part=relationship.target,
                        story_type=DocxStoryType.HEADER,
                        story_id=story_id,
                    )
                )
        if options.include_footers:
            for index, relationship in enumerate(footer_relationships):
                if relationship.external:
                    warnings["external_footer"] += 1
                    continue
                if relationship.target in story_ids_by_target:
                    continue
                story_id = f"footer-{index}"
                story_ids_by_target[relationship.target] = story_id
                story_parts.append(relationship.target)
                auxiliary_stories.append(
                    _story(
                        package,
                        state=state,
                        part=relationship.target,
                        story_type=DocxStoryType.FOOTER,
                        story_id=story_id,
                    )
                )
        main_story = _story(
            package,
            state=state,
            part=main_part,
            story_type=DocxStoryType.MAIN,
            story_id="main",
            container=body,
        )
        projected_sections = _projected_sections(
            body,
            state=state,
            main_part=main_part,
        )
        settings_relationship = _relationship_by_role(
            main_relationships_tuple, "settings"
        )
        even_and_odd_headers = False
        if settings_relationship is not None and not settings_relationship.external:
            settings = _validated_relationship_root(
                package,
                settings_relationship,
                role="settings",
            )
            even_and_odd_headers = (
                _on_off(_child(settings, "evenAndOddHeaders")) is True
            )
        sections = tuple(
            _section(
                section_node,
                state=state,
                section_index=index,
                source=section_source,
                even_and_odd_headers=even_and_odd_headers,
                main_relationships=main_relationships,
                story_ids_by_target=story_ids_by_target,
            )
            for index, (section_node, section_source) in enumerate(projected_sections)
        )
        comments_relationship = _relationship_by_role(
            main_relationships_tuple, "comments"
        )
        comments, comment_stories, comment_roots = _comments(
            package,
            comments_relationship,
            state,
        )
        footnote_relationship = _relationship_by_role(
            main_relationships_tuple, "footnotes"
        )
        footnotes, footnote_stories, footnote_roots, separator_footnotes = _notes(
            package,
            footnote_relationship,
            state=state,
            story_type=DocxStoryType.FOOTNOTE,
        )
        endnote_relationship = _relationship_by_role(
            main_relationships_tuple, "endnotes"
        )
        endnotes, endnote_stories, endnote_roots, separator_endnotes = _notes(
            package,
            endnote_relationship,
            state=state,
            story_type=DocxStoryType.ENDNOTE,
        )
        for optional_relationship in (
            comments_relationship,
            footnote_relationship,
            endnote_relationship,
        ):
            if optional_relationship is not None and not optional_relationship.external:
                story_parts.append(optional_relationship.target)
        track_changes = _revision_summary(tuple(state.story_roots), state)
        all_roots = (
            main_root,
            *state.auxiliary_roots,
            *comment_roots,
            *footnote_roots,
            *endnote_roots,
        )
        selected_story_parts = tuple(dict.fromkeys(story_parts))
        _unsupported_inventory(
            package,
            all_roots,
            warnings,
            selected_story_parts,
        )
        resource_inventory = _resources(
            package,
            selected_story_parts,
            warnings,
            state.resource_metadata,
        )
        bookmark_names = {
            bookmark.name for bookmark in state.bookmarks if bookmark.name is not None
        }
        for hyperlink in state.hyperlinks:
            if hyperlink.anchor and hyperlink.anchor not in bookmark_names:
                warnings["unresolved_internal_hyperlink_anchor"] += 1
        properties = _properties(package, root_relationships, state)
        stories = (
            main_story,
            *auxiliary_stories,
            *comment_stories,
            *footnote_stories,
            *endnote_stories,
        )
        structure = DocxDocumentStructure(
            stories=stories,
            sections=sections,
            comments=comments,
            footnotes=cast("tuple[DocxFootnote, ...]", footnotes),
            endnotes=cast("tuple[DocxEndnote, ...]", endnotes),
            content_controls=tuple(state.controls),
            hyperlinks=tuple(state.hyperlinks),
            bookmarks=tuple(state.bookmarks),
            embedded_resources=resource_inventory.resources,
            track_changes=track_changes,
        )
        document = _normalized_document(
            descriptor,
            structure,
            properties,
            options,
            state,
        )
        warning_models = _warning_models(warnings)
        if extension_mismatch:
            warning_models = (
                ProcessingWarning(
                    code="docx.extension_mismatch",
                    category="extension_mismatch",
                    message=(
                        "The filename extension does not match the detected "
                        "DOCX content."
                    ),
                ),
                *warning_models,
            )
        inspection = DocxInspection(
            file=descriptor,
            package=_package_summary(
                package,
                resource_inventory,
                warnings,
                separator_footnotes=separator_footnotes,
                separator_endnotes=separator_endnotes,
            ),
            properties=properties,
            block_count=structure.block_count,
            declared_page_count=properties.declared_page_count,
            extension_mismatch=extension_mismatch,
            warnings=warning_models,
        )
        return DocxAnalysisResult(
            inspection=inspection,
            structure=structure,
            document=document,
            warnings=warning_models,
            processing_manifest=DocxProcessingManifest(
                source_sha256=descriptor.fingerprint.value,
                sdk_version=__version__,
                revision_view=options.revision_view,
                operation_counts=(("docx_analysis", 1), ("inspection", 1)),
            ),
        )


def _requests(
    *,
    options: DocxAnalysisOptions | None,
    limits: DocxProcessingLimits | None,
) -> tuple[DocxAnalysisOptions, DocxProcessingLimits]:
    try:
        effective_options = (
            DocxAnalysisOptions()
            if options is None
            else _revalidate_model_instance_json(
                options,
                DocxAnalysisOptions,
                "The DOCX analysis options are invalid",
            )
        )
        effective_limits = (
            DocxProcessingLimits()
            if limits is None
            else _revalidate_model_instance_json(
                limits,
                DocxProcessingLimits,
                "The DOCX processing limits are invalid",
            )
        )
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            DocxProcessingError("The DOCX processing request is invalid"),
        )
    return effective_options, effective_limits


def _identity(
    path: Path,
    limits: DocxProcessingLimits,
) -> tuple[str, int]:
    try:
        return _raw_identity(path, max_bytes=limits.max_input_bytes)
    except _DocumentIdentityLimitError as exc:
        raise DocxResourceLimitError(
            limit_name="input_bytes",
            observed=exc.byte_size,
            maximum=limits.max_input_bytes,
        ) from None
    except DocxProcessingError:
        raise
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            DocxPackageInvalidError("The DOCX source could not be inspected safely"),
        )


def inspect_docx(
    path: Path,
    *,
    limits: DocxProcessingLimits | None = None,
) -> DocxInspection:
    """Inspect one non-macro DOCX through a verified immutable snapshot."""
    _, effective_limits = _requests(options=None, limits=limits)
    sha256, byte_size = _identity(path, effective_limits)
    descriptor = _descriptor(path, sha256, byte_size)
    mismatch = path.suffix.casefold() != ".docx"
    envelope = _envelope(descriptor, extension_mismatch=mismatch)
    try:
        with _adapter_path(
            path,
            DocumentFormat.DOCX,
            sha256,
            byte_size,
            always_snapshot=True,
        ) as snapshot:
            result = _analyze_snapshot(
                snapshot,
                descriptor=descriptor,
                options=DocxAnalysisOptions(),
                limits=effective_limits,
                extension_mismatch=mismatch,
            ).inspection
        _assert_source_unchanged(path, envelope)
        return result
    except DocxProcessingError:
        raise
    except DocumentSourceChangedError as exc:
        _raise_redacted_translation(
            exc,
            DocxSourceChangedError("The DOCX source changed during inspection"),
        )
    except (DocumentProcessingError, FileAccessError) as exc:
        _raise_redacted_translation(
            exc,
            DocxProcessingError("The DOCX inspection could not be completed safely"),
        )
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            DocxProcessingError("The DOCX inspection failed internal validation"),
        )


def analyze_docx(
    path: Path,
    *,
    options: DocxAnalysisOptions | None = None,
    limits: DocxProcessingLimits | None = None,
) -> DocxAnalysisResult:
    """Analyze one non-macro DOCX locally without rendering or Provider access."""
    effective_options, effective_limits = _requests(options=options, limits=limits)
    sha256, byte_size = _identity(path, effective_limits)
    descriptor = _descriptor(path, sha256, byte_size)
    mismatch = path.suffix.casefold() != ".docx"
    envelope = _envelope(descriptor, extension_mismatch=mismatch)
    try:
        with _adapter_path(
            path,
            DocumentFormat.DOCX,
            sha256,
            byte_size,
            always_snapshot=True,
        ) as snapshot:
            result = _analyze_snapshot(
                snapshot,
                descriptor=descriptor,
                options=effective_options,
                limits=effective_limits,
                extension_mismatch=mismatch,
            )
        _assert_source_unchanged(path, envelope)
        return result
    except DocxProcessingError:
        raise
    except DocumentSourceChangedError as exc:
        _raise_redacted_translation(
            exc,
            DocxSourceChangedError("The DOCX source changed during analysis"),
        )
    except (DocumentProcessingError, FileAccessError) as exc:
        _raise_redacted_translation(
            exc,
            DocxProcessingError("The DOCX analysis could not be completed safely"),
        )
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            DocxProcessingError("The DOCX analysis failed internal validation"),
        )

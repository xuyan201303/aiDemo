"""Strict provider-independent public models for local DOCX processing."""

# ruff: noqa: EM101, TC001, TC003, TRY003

from __future__ import annotations

import math
from datetime import date, datetime
from decimal import Decimal
from enum import StrEnum
from typing import Annotated, Literal, Self

from pydantic import ConfigDict, Field, field_validator, model_validator

from document_sdk.core import (
    Document,
    DocxSourceReference,
    FileDescriptor,
    ProcessingError,
    ProcessingWarning,
)
from document_sdk.core._validation import SanitizedPublicModel
from document_sdk.docx.errors import DocxProcessingError

_StrictModel = ConfigDict(
    extra="forbid",
    frozen=True,
    strict=False,
    validate_default=True,
    hide_input_in_errors=True,
)
PositiveLimit = Annotated[int, Field(strict=True, ge=1, le=10_000_000_000)]
NonEmptyString = Annotated[str, Field(min_length=1)]
Sha256 = Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]


class _PublicModel(SanitizedPublicModel):
    """DOCX public model with content-free validation failures."""

    _validation_error_type = DocxProcessingError
    _validation_error_message = "DOCX result validation failed"


class DocxRevisionView(StrEnum):
    """Visible revision projection without accepting or rejecting revisions."""

    CURRENT = "current"
    ORIGINAL = "original"


class DocxStoryType(StrEnum):
    """WordprocessingML story categories represented without pagination."""

    MAIN = "main"
    HEADER = "header"
    FOOTER = "footer"
    COMMENT = "comment"
    FOOTNOTE = "footnote"
    ENDNOTE = "endnote"


class DocxProcessingLimits(_PublicModel):
    """Finite ZIP, XML, structure, text, and resource limits."""

    model_config = _StrictModel

    max_input_bytes: PositiveLimit = 512_000_000
    max_package_members: PositiveLimit = 10_000
    max_total_uncompressed_bytes: PositiveLimit = 1_000_000_000
    max_member_uncompressed_bytes: PositiveLimit = 256_000_000
    max_compression_ratio: float = Field(default=200.0, gt=0, le=10_000)
    max_xml_parts: PositiveLimit = 2_000
    max_total_xml_bytes: PositiveLimit = 256_000_000
    max_xml_part_bytes: PositiveLimit = 32_000_000
    max_xml_elements: PositiveLimit = 2_000_000
    max_xml_depth: PositiveLimit = 256
    max_relationships: PositiveLimit = 100_000
    max_text_characters: PositiveLimit = 100_000_000
    max_paragraphs: PositiveLimit = 2_000_000
    max_runs: PositiveLimit = 10_000_000
    max_tables: PositiveLimit = 100_000
    max_table_rows: PositiveLimit = 2_000_000
    max_table_cells: PositiveLimit = 10_000_000
    max_nested_table_depth: PositiveLimit = 32
    max_sections: PositiveLimit = 100_000
    max_headers: PositiveLimit = 10_000
    max_footers: PositiveLimit = 10_000
    max_comments: PositiveLimit = 1_000_000
    max_footnotes: PositiveLimit = 1_000_000
    max_endnotes: PositiveLimit = 1_000_000
    max_hyperlinks: PositiveLimit = 2_000_000
    max_bookmarks: PositiveLimit = 2_000_000
    max_content_controls: PositiveLimit = 2_000_000
    max_media_parts: PositiveLimit = 100_000
    max_embedded_parts: PositiveLimit = 100_000
    max_embedded_total_bytes: PositiveLimit = 512_000_000

    @field_validator("max_compression_ratio")
    @classmethod
    def finite_ratio(cls, value: float) -> float:
        """Reject NaN and infinity."""
        if not math.isfinite(value):
            raise ValueError("max_compression_ratio must be finite")
        return value


class DocxAnalysisOptions(_PublicModel):
    """Explicit local DOCX projection and candidate-extraction policy."""

    model_config = _StrictModel

    revision_view: DocxRevisionView = DocxRevisionView.CURRENT
    include_headers: bool = True
    include_footers: bool = True
    include_comments: bool = True
    include_footnotes: bool = True
    include_endnotes: bool = True
    include_custom_properties_as_key_values: bool = True
    extract_two_column_key_value_tables: bool = False


class DocxTextStyle(_PublicModel):
    """Common resolved run formatting without renderer claims."""

    model_config = _StrictModel

    bold: bool | None = None
    italic: bool | None = None
    underline: bool | None = None
    strike: bool | None = None
    double_strike: bool | None = None
    subscript: bool | None = None
    superscript: bool | None = None
    small_caps: bool | None = None
    all_caps: bool | None = None
    hidden: bool | None = None
    font_family: str | None = None
    font_size_points: float | None = Field(default=None, gt=0)
    foreground_color: str | None = None
    highlight: str | None = None
    language: str | None = None


class DocxRun(_PublicModel):
    """One ordered paragraph run and structural source."""

    model_config = _StrictModel

    run_id: NonEmptyString
    text: str
    style: DocxTextStyle = Field(default_factory=DocxTextStyle)
    hyperlink_id: str | None = None
    footnote_id: str | None = None
    endnote_id: str | None = None
    comment_ids: tuple[str, ...] = ()
    resource_ids: tuple[str, ...] = ()
    revision_kind: str | None = None
    source: DocxSourceReference


class DocxListInfo(_PublicModel):
    """Structural Word numbering evidence without fabricated rendered prefixes."""

    model_config = _StrictModel

    num_id: NonEmptyString
    abstract_num_id: str | None = None
    level: int = Field(ge=0)
    numbering_format: str | None = None
    level_text: str | None = None
    start_value: int | None = None
    restart: bool | None = None
    left_indent_twips: int | None = None
    hanging_indent_twips: int | None = None


class DocxHyperlink(_PublicModel):
    """Internal or external hyperlink evidence that is never followed."""

    model_config = _StrictModel

    hyperlink_id: NonEmptyString
    display_text: str
    target: str | None = None
    anchor: str | None = None
    tooltip: str | None = None
    history: bool | None = None
    external: bool = False
    source: DocxSourceReference


class DocxBookmark(_PublicModel):
    """A Word bookmark range marker."""

    model_config = _StrictModel

    bookmark_id: NonEmptyString
    name: str | None = None
    start_source: DocxSourceReference
    end_source: DocxSourceReference | None = None


class DocxParagraph(_PublicModel):
    """One ordered paragraph with resolved structural formatting evidence."""

    model_config = _StrictModel

    kind: Literal["paragraph"] = "paragraph"
    paragraph_id: NonEmptyString
    text: str
    runs: tuple[DocxRun, ...] = ()
    style_id: str | None = None
    style_name: str | None = None
    outline_level: int | None = Field(default=None, ge=0, le=9)
    is_heading: bool = False
    alignment: str | None = None
    language: str | None = None
    list_info: DocxListInfo | None = None
    hyperlinks: tuple[DocxHyperlink, ...] = ()
    bookmarks: tuple[DocxBookmark, ...] = ()
    source: DocxSourceReference


class DocxTableCell(_PublicModel):
    """One non-overlapping logical table cell."""

    model_config = _StrictModel

    row_index: int = Field(ge=0)
    column_index: int = Field(ge=0)
    row_span: int = Field(default=1, ge=1)
    column_span: int = Field(default=1, ge=1)
    blocks: tuple[DocxParagraph | DocxTable, ...] = ()
    text: str = ""
    row_header: bool = False
    source: DocxSourceReference


class DocxTableRow(_PublicModel):
    """One physical table row mapped to logical columns."""

    model_config = _StrictModel

    row_index: int = Field(ge=0)
    cells: tuple[DocxTableCell, ...] = ()
    is_header: bool = False
    source: DocxSourceReference


class DocxTable(_PublicModel):
    """One ordered logical table, including nested tables."""

    model_config = _StrictModel

    kind: Literal["table"] = "table"
    table_id: NonEmptyString
    table_index: int = Field(ge=0)
    rows: tuple[DocxTableRow, ...] = ()
    logical_column_count: int = Field(default=0, ge=0)
    caption: str | None = None
    description: str | None = None
    nested_depth: int = Field(default=0, ge=0)
    source: DocxSourceReference

    @model_validator(mode="after")
    def non_overlapping_grid(self) -> Self:
        """Reject overlapping logical cell rectangles."""
        occupied: set[tuple[int, int]] = set()
        for row in self.rows:
            for cell in row.cells:
                for row_index in range(cell.row_index, cell.row_index + cell.row_span):
                    for column_index in range(
                        cell.column_index,
                        cell.column_index + cell.column_span,
                    ):
                        coordinate = row_index, column_index
                        if coordinate in occupied:
                            raise ValueError("DOCX logical table cells overlap")
                        occupied.add(coordinate)
        return self


DocxBlock = Annotated[
    DocxParagraph | DocxTable,
    Field(discriminator="kind"),
]


class DocxStory(_PublicModel):
    """One ordered WordprocessingML story."""

    model_config = _StrictModel

    story_id: NonEmptyString
    story_type: DocxStoryType
    part_role: NonEmptyString
    blocks: tuple[DocxBlock, ...] = ()
    sources: tuple[DocxSourceReference, ...] = ()


class DocxSection(_PublicModel):
    """Section properties and deterministic header/footer story references."""

    model_config = _StrictModel

    section_id: NonEmptyString
    section_index: int = Field(ge=0)
    break_type: str | None = None
    page_width_twips: int | None = Field(default=None, gt=0)
    page_height_twips: int | None = Field(default=None, gt=0)
    orientation: str | None = None
    margin_top_twips: int | None = Field(default=None, ge=0)
    margin_right_twips: int | None = Field(default=None, ge=0)
    margin_bottom_twips: int | None = Field(default=None, ge=0)
    margin_left_twips: int | None = Field(default=None, ge=0)
    column_count: int | None = Field(default=None, ge=1)
    title_page: bool = False
    even_and_odd_headers: bool = False
    default_header_story_id: str | None = None
    first_header_story_id: str | None = None
    even_header_story_id: str | None = None
    default_footer_story_id: str | None = None
    first_footer_story_id: str | None = None
    even_footer_story_id: str | None = None
    source: DocxSourceReference


class DocxComment(_PublicModel):
    """One comment definition and available anchor evidence."""

    model_config = _StrictModel

    comment_id: NonEmptyString
    author: str | None = None
    initials: str | None = None
    created_at: datetime | None = None
    blocks: tuple[DocxBlock, ...] = ()
    range_start: DocxSourceReference | None = None
    range_end: DocxSourceReference | None = None
    reference: DocxSourceReference | None = None
    source: DocxSourceReference


class DocxFootnote(_PublicModel):
    """One user footnote story."""

    model_config = _StrictModel

    note_id: NonEmptyString
    blocks: tuple[DocxBlock, ...] = ()
    reference_sources: tuple[DocxSourceReference, ...] = ()
    source: DocxSourceReference


class DocxEndnote(_PublicModel):
    """One user endnote story."""

    model_config = _StrictModel

    note_id: NonEmptyString
    blocks: tuple[DocxBlock, ...] = ()
    reference_sources: tuple[DocxSourceReference, ...] = ()
    source: DocxSourceReference


class DocxContentControl(_PublicModel):
    """One read-only Structured Document Tag and deterministic typed value."""

    model_config = _StrictModel

    control_id: NonEmptyString
    sdt_id: str | None = None
    tag: str | None = None
    alias: str | None = None
    control_type: NonEmptyString
    lock_state: str | None = None
    placeholder: bool = False
    list_values: tuple[str, ...] = ()
    selected_value: str | None = None
    value: str | bool | date | None = None
    blocks: tuple[DocxBlock, ...] = ()
    source: DocxSourceReference


class DocxEmbeddedResource(_PublicModel):
    """Opaque internal or external resource inventory without bytes."""

    model_config = _StrictModel

    resource_id: NonEmptyString
    relationship_role: NonEmptyString
    resource_type: NonEmptyString
    content_type: str | None = None
    safe_basename: str | None = None
    byte_size: int | None = Field(default=None, ge=0)
    sha256: Sha256 | None = None
    internal: bool
    alt_text: str | None = None
    title: str | None = None
    description: str | None = None


class DocxTrackChangesSummary(_PublicModel):
    """Complete safe revision counts and optional author/date evidence."""

    model_config = _StrictModel

    insertions: int = Field(default=0, ge=0)
    deletions: int = Field(default=0, ge=0)
    move_from: int = Field(default=0, ge=0)
    move_to: int = Field(default=0, ge=0)
    paragraph_property_changes: int = Field(default=0, ge=0)
    run_property_changes: int = Field(default=0, ge=0)
    section_property_changes: int = Field(default=0, ge=0)
    table_property_changes: int = Field(default=0, ge=0)
    authors: tuple[str, ...] = ()
    dates: tuple[datetime, ...] = ()
    sources: tuple[DocxSourceReference, ...] = ()

    @property
    def present(self) -> bool:
        """Return whether any tracked revision evidence is present."""
        return any(
            (
                self.insertions,
                self.deletions,
                self.move_from,
                self.move_to,
                self.paragraph_property_changes,
                self.run_property_changes,
                self.section_property_changes,
                self.table_property_changes,
            )
        )


class DocxCustomProperty(_PublicModel):
    """One explicit typed custom document property."""

    model_config = _StrictModel

    name: NonEmptyString
    value_type: NonEmptyString
    value: str | int | Decimal | bool | datetime | None = None
    raw_value: str | None = None
    supported: bool = True
    source: DocxSourceReference


class DocxDocumentProperties(_PublicModel):
    """Safe core, extended, and custom document properties."""

    model_config = _StrictModel

    title: str | None = None
    subject: str | None = None
    creator: str | None = None
    keywords: str | None = None
    description: str | None = None
    last_modified_by: str | None = None
    created_at: datetime | None = None
    modified_at: datetime | None = None
    application: str | None = None
    company: str | None = None
    declared_page_count: int | None = Field(default=None, ge=0)
    declared_page_count_is_authoritative: Literal[False] = False
    custom_properties: tuple[DocxCustomProperty, ...] = ()


class DocxPackageSummary(_PublicModel):
    """Bounded package facts and unsupported-feature counts."""

    model_config = _StrictModel

    member_count: int = Field(ge=1)
    total_uncompressed_bytes: int = Field(ge=0)
    xml_part_count: int = Field(ge=1)
    relationship_count: int = Field(ge=0)
    media_part_count: int = Field(ge=0)
    embedded_part_count: int = Field(ge=0)
    separator_footnote_count: int = Field(default=0, ge=0)
    separator_endnote_count: int = Field(default=0, ge=0)
    unsupported_feature_counts: tuple[tuple[str, int], ...] = ()


class DocxDocumentStructure(_PublicModel):
    """Complete ordered DOCX stories and cross-story evidence."""

    model_config = _StrictModel

    stories: tuple[DocxStory, ...]
    sections: tuple[DocxSection, ...] = ()
    comments: tuple[DocxComment, ...] = ()
    footnotes: tuple[DocxFootnote, ...] = ()
    endnotes: tuple[DocxEndnote, ...] = ()
    content_controls: tuple[DocxContentControl, ...] = ()
    hyperlinks: tuple[DocxHyperlink, ...] = ()
    bookmarks: tuple[DocxBookmark, ...] = ()
    embedded_resources: tuple[DocxEmbeddedResource, ...] = ()
    track_changes: DocxTrackChangesSummary = Field(
        default_factory=DocxTrackChangesSummary
    )

    @model_validator(mode="after")
    def validate_references(self) -> Self:  # noqa: C901, PLR0912, PLR0915
        """Require globally unique structural IDs and valid references."""
        story_ids = tuple(story.story_id for story in self.stories)
        if len(story_ids) != len(set(story_ids)):
            raise ValueError("DOCX story IDs must be unique")
        available = set(story_ids)
        for section in self.sections:
            references = (
                section.default_header_story_id,
                section.first_header_story_id,
                section.even_header_story_id,
                section.default_footer_story_id,
                section.first_footer_story_id,
                section.even_footer_story_id,
            )
            if any(reference not in available for reference in references if reference):
                raise ValueError("DOCX section references a missing story")
        element_ids: set[str] = set()

        def add_id(value: str) -> None:
            if value in element_ids:
                raise ValueError("DOCX structural element IDs must be globally unique")
            element_ids.add(value)

        hyperlink_ids = {item.hyperlink_id for item in self.hyperlinks}
        bookmark_ids = {item.bookmark_id for item in self.bookmarks}
        if len(hyperlink_ids) != len(self.hyperlinks):
            raise ValueError("DOCX hyperlink IDs must be unique")
        if len(bookmark_ids) != len(self.bookmarks):
            raise ValueError("DOCX bookmark IDs must be unique")
        comment_ids = {item.comment_id for item in self.comments}
        footnote_ids = {item.note_id for item in self.footnotes}
        endnote_ids = {item.note_id for item in self.endnotes}
        resource_ids = {item.resource_id for item in self.embedded_resources}
        if len(comment_ids) != len(self.comments):
            raise ValueError("DOCX comment IDs must be unique")
        if len(footnote_ids) != len(self.footnotes):
            raise ValueError("DOCX footnote IDs must be unique")
        if len(endnote_ids) != len(self.endnotes):
            raise ValueError("DOCX endnote IDs must be unique")

        def visit(block: DocxBlock) -> None:  # noqa: C901
            if isinstance(block, DocxParagraph):
                add_id(block.paragraph_id)
                if any(
                    item.hyperlink_id not in hyperlink_ids for item in block.hyperlinks
                ):
                    raise ValueError("DOCX paragraph references a missing hyperlink")
                if any(
                    item.bookmark_id not in bookmark_ids for item in block.bookmarks
                ):
                    raise ValueError("DOCX paragraph references a missing bookmark")
                for run in block.runs:
                    add_id(run.run_id)
                    if (
                        run.hyperlink_id is not None
                        and run.hyperlink_id not in hyperlink_ids
                    ):
                        raise ValueError("DOCX run references a missing hyperlink")
                    if any(value not in comment_ids for value in run.comment_ids):
                        raise ValueError("DOCX run references a missing comment")
                    if (
                        run.footnote_id is not None
                        and run.footnote_id not in footnote_ids
                    ):
                        raise ValueError("DOCX run references a missing footnote")
                    if run.endnote_id is not None and run.endnote_id not in endnote_ids:
                        raise ValueError("DOCX run references a missing endnote")
                    if any(value not in resource_ids for value in run.resource_ids):
                        raise ValueError("DOCX run references a missing resource")
                return
            add_id(block.table_id)
            for row in block.rows:
                for cell in row.cells:
                    for nested in cell.blocks:
                        visit(nested)

        for story in self.stories:
            add_id(story.story_id)
            for block in story.blocks:
                visit(block)
        for section in self.sections:
            add_id(section.section_id)
        for control in self.content_controls:
            add_id(control.control_id)
        for hyperlink in self.hyperlinks:
            add_id(hyperlink.hyperlink_id)
        for bookmark in self.bookmarks:
            add_id(bookmark.bookmark_id)
        for resource in self.embedded_resources:
            add_id(resource.resource_id)
        return self

    @property
    def block_count(self) -> int:
        """Count parsed paragraph and table blocks across selected stories."""

        def count(block: DocxBlock) -> int:
            if isinstance(block, DocxParagraph):
                return 1
            return 1 + sum(
                count(nested)
                for row in block.rows
                for cell in row.cells
                for nested in cell.blocks
            )

        return sum(count(block) for story in self.stories for block in story.blocks)


class DocxInspection(_PublicModel):
    """Safe bounded inspection of one verified non-macro DOCX."""

    model_config = _StrictModel

    file: FileDescriptor
    package: DocxPackageSummary
    properties: DocxDocumentProperties
    block_count: int = Field(default=0, ge=0)
    declared_page_count: int | None = Field(default=None, ge=0)
    declared_page_count_is_authoritative: Literal[False] = False
    extension_mismatch: bool = False
    warnings: tuple[ProcessingWarning, ...] = ()


class DocxProcessingManifest(_PublicModel):
    """Content-free exact local DOCX operation evidence."""

    model_config = _StrictModel

    source_sha256: Sha256
    sdk_version: NonEmptyString
    revision_view: DocxRevisionView
    operation_counts: tuple[tuple[str, int], ...]

    @model_validator(mode="after")
    def exact_counts(self) -> Self:
        """Require sorted unique unit operation counts."""
        names = tuple(name for name, _ in self.operation_counts)
        if names != tuple(sorted(set(names))) or any(
            count != 1 for _, count in self.operation_counts
        ):
            raise ValueError("DOCX operation counts are inconsistent")
        return self


class DocxAnalysisResult(_PublicModel):
    """Complete provider-independent DOCX analysis."""

    model_config = _StrictModel

    inspection: DocxInspection
    structure: DocxDocumentStructure
    document: Document
    warnings: tuple[ProcessingWarning, ...] = ()
    issues: tuple[ProcessingError, ...] = ()
    processing_manifest: DocxProcessingManifest

    @model_validator(mode="after")
    def consistent_identity(self) -> Self:
        """Cross-check descriptor, warnings, and manifest identity."""
        descriptor = self.inspection.file
        if (
            self.document.file != descriptor
            or self.processing_manifest.source_sha256 != descriptor.fingerprint.value
            or self.warnings != self.inspection.warnings
        ):
            raise ValueError("DOCX analysis identity evidence is inconsistent")
        if self.document.pages:
            raise ValueError("DOCX analysis must not fabricate document pages")
        return self


DocxTableCell.model_rebuild()
DocxTable.model_rebuild()

"""Provider-independent local DOCX inspection and analysis."""

from pathlib import Path

from document_sdk.core import DocxSourceReference
from document_sdk.docx.errors import (
    DocxPackageInvalidError,
    DocxProcessingError,
    DocxResourceLimitError,
    DocxSourceChangedError,
    DocxUnsupportedPackageError,
)
from document_sdk.docx.models import (
    DocxAnalysisOptions,
    DocxAnalysisResult,
    DocxBlock,
    DocxBookmark,
    DocxComment,
    DocxContentControl,
    DocxDocumentProperties,
    DocxDocumentStructure,
    DocxEmbeddedResource,
    DocxEndnote,
    DocxFootnote,
    DocxHyperlink,
    DocxInspection,
    DocxListInfo,
    DocxPackageSummary,
    DocxParagraph,
    DocxProcessingLimits,
    DocxRevisionView,
    DocxRun,
    DocxSection,
    DocxStory,
    DocxStoryType,
    DocxTable,
    DocxTableCell,
    DocxTableRow,
    DocxTextStyle,
    DocxTrackChangesSummary,
)


def inspect_docx(
    path: Path,
    *,
    limits: DocxProcessingLimits | None = None,
) -> DocxInspection:
    """Inspect one verified local DOCX."""
    from document_sdk.docx.processing import inspect_docx as _inspect_docx

    return _inspect_docx(path, limits=limits)


def analyze_docx(
    path: Path,
    *,
    options: DocxAnalysisOptions | None = None,
    limits: DocxProcessingLimits | None = None,
) -> DocxAnalysisResult:
    """Analyze one verified local DOCX."""
    from document_sdk.docx.processing import analyze_docx as _analyze_docx

    return _analyze_docx(path, options=options, limits=limits)


__all__ = [
    "DocxAnalysisOptions",
    "DocxAnalysisResult",
    "DocxBlock",
    "DocxBookmark",
    "DocxComment",
    "DocxContentControl",
    "DocxDocumentProperties",
    "DocxDocumentStructure",
    "DocxEmbeddedResource",
    "DocxEndnote",
    "DocxFootnote",
    "DocxHyperlink",
    "DocxInspection",
    "DocxListInfo",
    "DocxPackageInvalidError",
    "DocxPackageSummary",
    "DocxParagraph",
    "DocxProcessingError",
    "DocxProcessingLimits",
    "DocxResourceLimitError",
    "DocxRevisionView",
    "DocxRun",
    "DocxSection",
    "DocxSourceChangedError",
    "DocxSourceReference",
    "DocxStory",
    "DocxStoryType",
    "DocxTable",
    "DocxTableCell",
    "DocxTableRow",
    "DocxTextStyle",
    "DocxTrackChangesSummary",
    "DocxUnsupportedPackageError",
    "analyze_docx",
    "inspect_docx",
]

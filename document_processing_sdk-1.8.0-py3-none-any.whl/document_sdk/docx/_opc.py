"""Shared bounded OPC/OOXML classification for Direct and Unified routes."""

# ruff: noqa: EM101, TC001, TRY003

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path, PurePosixPath
from typing import Any, Protocol

from document_sdk.docx.errors import (
    DocxPackageInvalidError,
    DocxUnsupportedPackageError,
)
from document_sdk.docx.models import DocxProcessingLimits

_OFFICE_DOCUMENT_RELATIONSHIP = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"
)
_DOCX_MAIN_CONTENT_TYPE = (
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"
)
_XLSX_MAIN_CONTENT_TYPE = (
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"
)
_XLSM_MAIN_CONTENT_TYPE = "application/vnd.ms-excel.sheet.macroEnabled.main+xml"
_WORD_MACRO_MAIN_CONTENT_TYPES = frozenset(
    {
        "application/vnd.ms-word.document.macroEnabled.main+xml",
        "application/vnd.ms-word.template.macroEnabledTemplate.main+xml",
    }
)
_OFFICE_MAIN_CONTENT_TYPES = frozenset(
    {
        _DOCX_MAIN_CONTENT_TYPE,
        (
            "application/vnd.openxmlformats-officedocument."
            "wordprocessingml.template.main+xml"
        ),
        *_WORD_MACRO_MAIN_CONTENT_TYPES,
        _XLSX_MAIN_CONTENT_TYPE,
        _XLSM_MAIN_CONTENT_TYPE,
        (
            "application/vnd.openxmlformats-officedocument."
            "spreadsheetml.template.main+xml"
        ),
        "application/vnd.ms-excel.template.macroEnabled.main+xml",
        (
            "application/vnd.openxmlformats-officedocument."
            "presentationml.presentation.main+xml"
        ),
        "application/vnd.ms-powerpoint.presentation.macroEnabled.main+xml",
        (
            "application/vnd.openxmlformats-officedocument."
            "presentationml.template.main+xml"
        ),
        "application/vnd.ms-powerpoint.template.macroEnabled.main+xml",
        (
            "application/vnd.openxmlformats-officedocument."
            "presentationml.slideshow.main+xml"
        ),
        "application/vnd.ms-powerpoint.slideshow.macroEnabled.main+xml",
    }
)
_VBA_CONTENT_TYPES = frozenset(
    {
        "application/vnd.ms-office.vbaProject",
        "application/vnd.ms-word.vbaData+xml",
        "application/vnd.ms-office.vbaProjectSignature",
        "application/vnd.ms-office.vbaProjectSignatureAgile",
        "application/vnd.ms-office.vbaProjectSignatureV3",
    }
)
_VBA_RELATIONSHIPS = frozenset(
    {
        "http://schemas.microsoft.com/office/2006/relationships/vbaProject",
        "http://schemas.microsoft.com/office/2006/relationships/vbaData",
        "http://schemas.microsoft.com/office/2006/relationships/vbaProjectSignature",
        (
            "http://schemas.microsoft.com/office/2014/relationships/"
            "vbaProjectSignatureAgile"
        ),
        (
            "http://schemas.microsoft.com/office/2020/07/relationships/"
            "vbaProjectSignatureV3"
        ),
    }
)
_VBA_MEMBER_BASENAMES = frozenset(
    {
        "vbaproject.bin",
        "vbadata.xml",
        "vbaprojectsignature.bin",
        "vbaprojectsignatureagile.bin",
        "vbaprojectsignaturev3.bin",
    }
)


class OfficePackageKind(StrEnum):
    """Private Office family classification without a public API dependency."""

    DOCX = "docx"
    XLSX = "xlsx"
    XLSM = "xlsm"
    UNSUPPORTED = "unsupported"


@dataclass(frozen=True)
class PackageClassification:
    """Validated main-document contract shared by every classification route."""

    main_part: str
    main_content_type: str
    kind: OfficePackageKind


class _OpenOpcPackage(Protocol):
    def member_names(self) -> tuple[str, ...]: ...

    def relationship_owners(self) -> tuple[str, ...]: ...

    def relationships(self, owner: str) -> tuple[Any, ...]: ...

    def content_type(self, part: str) -> str | None: ...

    def content_type_declarations(self) -> tuple[str, ...]: ...


def classify_open_package(package: _OpenOpcPackage) -> PackageClassification:
    """Classify one already preflighted package using every declaration."""
    names = frozenset(package.member_names())
    root_relationships = package.relationships("")
    office_relationships = tuple(
        relationship
        for relationship in root_relationships
        if relationship.relationship_type == _OFFICE_DOCUMENT_RELATIONSHIP
    )
    if len(office_relationships) != 1 or office_relationships[0].external:
        raise DocxUnsupportedPackageError(
            "The package lacks one valid internal Office document relationship"
        )

    main_part = office_relationships[0].target
    if main_part not in names:
        raise DocxPackageInvalidError("The Office main document part is missing")
    main_content_type = package.content_type(main_part)
    if not main_content_type:
        raise DocxUnsupportedPackageError(
            "The package main document content type is unsupported"
        )

    declarations = package.content_type_declarations()
    normalized_declarations = tuple(value.casefold() for value in declarations)
    normalized_main_content_type = main_content_type.casefold()
    word_macro_types = {value.casefold() for value in _WORD_MACRO_MAIN_CONTENT_TYPES}
    office_main_types = {value.casefold() for value in _OFFICE_MAIN_CONTENT_TYPES}
    if any(value in word_macro_types for value in normalized_declarations):
        raise DocxUnsupportedPackageError("Macro-enabled Word packages are unsupported")
    conflicting_main_types = {
        value
        for value in normalized_declarations
        if value in office_main_types and value != normalized_main_content_type
    }
    if conflicting_main_types:
        raise DocxUnsupportedPackageError(
            "The package contains conflicting Office main document types"
        )

    relationship_types = {
        relationship.relationship_type
        for owner in package.relationship_owners()
        for relationship in package.relationships(owner)
    }
    kind = {
        _DOCX_MAIN_CONTENT_TYPE.casefold(): OfficePackageKind.DOCX,
        _XLSX_MAIN_CONTENT_TYPE.casefold(): OfficePackageKind.XLSX,
        _XLSM_MAIN_CONTENT_TYPE.casefold(): OfficePackageKind.XLSM,
    }.get(normalized_main_content_type, OfficePackageKind.UNSUPPORTED)
    vba_content_types = {value.casefold() for value in _VBA_CONTENT_TYPES}
    has_vba_evidence = (
        any(value in vba_content_types for value in normalized_declarations)
        or any(
            PurePosixPath(name).name.casefold() in _VBA_MEMBER_BASENAMES
            for name in names
        )
        or any(value in _VBA_RELATIONSHIPS for value in relationship_types)
    )
    if has_vba_evidence and kind in {
        OfficePackageKind.DOCX,
        OfficePackageKind.XLSX,
    }:
        raise DocxUnsupportedPackageError(
            "The Office package type conflicts with macro evidence"
        )
    return PackageClassification(
        main_part=main_part,
        main_content_type=main_content_type,
        kind=kind,
    )


def classify_ooxml_path(
    path: Path,
    *,
    limits: DocxProcessingLimits,
) -> PackageClassification:
    """Open and classify through the same bounded package used by Direct DOCX."""
    from document_sdk.docx._package import DocxPackage

    with DocxPackage(path, limits, require_docx=False) as package:
        classification = package.classification
        if classification is None:
            raise DocxPackageInvalidError(
                "The Office package classification is incomplete"
            )
        return classification

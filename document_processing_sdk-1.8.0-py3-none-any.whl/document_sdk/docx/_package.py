"""Bounded OPC package access and deterministic relationship registration."""

# ruff: noqa: BLE001, EM101, PIE810, PLR2004, PYI034, PYI041, TC001, TC003, TRY003, TRY300

from __future__ import annotations

import hashlib
import io
import posixpath
import re
import stat
import unicodedata
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Final, cast
from xml.etree.ElementTree import Element

from defusedxml import ElementTree
from defusedxml.common import DefusedXmlException

from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.docx._opc import (
    OfficePackageKind,
    PackageClassification,
    classify_open_package,
)
from document_sdk.docx.errors import (
    DocxPackageInvalidError,
    DocxResourceLimitError,
    DocxUnsupportedPackageError,
)
from document_sdk.docx.models import DocxProcessingLimits

_CONTENT_TYPES: Final = "[Content_Types].xml"
_ROOT_RELATIONSHIPS: Final = "_rels/.rels"
_REL_NS: Final = "http://schemas.openxmlformats.org/package/2006/relationships"
_CONTENT_TYPE_NS: Final = "http://schemas.openxmlformats.org/package/2006/content-types"
_STRICT_RELATIONSHIP_PREFIX: Final = "http://purl.oclc.org/ooxml/"
_DRIVE_NAME = re.compile(r"^[A-Za-z]:")
_URI_SCHEME = re.compile(r"^[A-Za-z][A-Za-z0-9+.-]*:")
_SUPPORTED_COMPRESSION = frozenset({zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED})


@dataclass(frozen=True)
class Relationship:
    """One validated OPC relationship."""

    relationship_id: str
    relationship_type: str
    target: str
    external: bool


@dataclass(frozen=True)
class MemberMetadata:
    """Safe immutable metadata for one validated member."""

    name: str
    file_size: int
    compressed_size: int
    compression_type: int


def _relationship_part(owner: str) -> str:
    parent, basename = posixpath.split(owner)
    relationship = f"_rels/{basename}.rels"
    return relationship if not parent else f"{parent}/{relationship}"


def _safe_internal_target(owner: str, target: str) -> str:
    normalized_target = unicodedata.normalize("NFKC", target)
    if (
        not target
        or normalized_target != target
        or "\\" in target
        or target.startswith("//")
        or _DRIVE_NAME.match(target)
        or _URI_SCHEME.match(target)
        or any(ord(character) < 32 or ord(character) == 127 for character in target)
    ):
        raise DocxPackageInvalidError(
            "The DOCX package contains an unsafe relationship target"
        )
    owner_parent = "" if target.startswith("/") else posixpath.dirname(owner)
    relative_target = target.removeprefix("/")
    normalized = posixpath.normpath(posixpath.join(owner_parent, relative_target))
    if (
        normalized in {"", ".", ".."}
        or normalized.startswith("../")
        or normalized.startswith("/")
    ):
        raise DocxPackageInvalidError(
            "The DOCX package relationship escapes the package root"
        )
    return normalized


def _relationship_owner(part: str) -> str | None:
    if part == _ROOT_RELATIONSHIPS:
        return ""
    parent, basename = posixpath.split(part)
    if not parent.endswith("/_rels") or not basename.endswith(".rels"):
        return None
    owner_parent = parent.removesuffix("/_rels")
    owner_name = basename.removesuffix(".rels")
    return f"{owner_parent}/{owner_name}" if owner_parent else owner_name


class DocxPackage:
    """One bounded verified ZIP package; never extracts members to disk."""

    def __init__(
        self,
        path: Path,
        limits: DocxProcessingLimits,
        *,
        require_docx: bool = True,
    ) -> None:
        self._path = path
        self.limits = limits
        self._require_docx = require_docx
        self._archive: zipfile.ZipFile | None = None
        self._infos: dict[str, zipfile.ZipInfo] = {}
        self._content_types: dict[str, str] = {}
        self._defaults: dict[str, str] = {}
        self._relationships: dict[str, tuple[Relationship, ...]] = {}
        self._xml_cache: dict[str, Element] = {}
        self._xml_parts_read: set[str] = set()
        self._total_xml_bytes = 0
        self._xml_elements = 0
        self._relationship_count = 0
        self.classification: PackageClassification | None = None
        self.total_uncompressed_bytes = 0

    def __enter__(self) -> DocxPackage:
        try:
            archive = zipfile.ZipFile(self._path)
            self._archive = archive
            self._preflight(archive.infolist())
            self._parse_content_types()
            classification = classify_open_package(self)
            if self._require_docx and classification.kind is not OfficePackageKind.DOCX:
                raise DocxUnsupportedPackageError(  # noqa: TRY301
                    "The Office package is not a DOCX document"
                )
            self.classification = classification
            return self
        except (
            DocxPackageInvalidError,
            DocxResourceLimitError,
            DocxUnsupportedPackageError,
        ):
            self.close()
            raise
        except Exception as exc:
            self.close()
            _raise_redacted_translation(
                exc,
                DocxPackageInvalidError("The DOCX package could not be opened safely"),
            )

    def __exit__(self, *_args: object) -> None:
        self.close()

    def close(self) -> None:
        """Close the package without exposing backend cleanup failures."""
        archive = self._archive
        self._archive = None
        if archive is not None:
            try:
                archive.close()
            except Exception as exc:
                _raise_redacted_translation(
                    exc,
                    DocxPackageInvalidError(
                        "The DOCX package could not be closed safely"
                    ),
                )

    @property
    def member_count(self) -> int:
        return len(self._infos)

    @property
    def xml_part_count(self) -> int:
        return len(self._xml_parts_read)

    @property
    def relationship_count(self) -> int:
        return self._relationship_count

    def member_names(self) -> tuple[str, ...]:
        """Return validated internal names for bounded deterministic inventory."""
        return tuple(sorted(self._infos))

    def relationship_owners(self) -> tuple[str, ...]:
        """Return every real OPC relationship owner in deterministic order."""
        return tuple(
            sorted(
                {
                    owner
                    for part in self._infos
                    if (owner := _relationship_owner(part)) is not None
                }
            )
        )

    def member_metadata(self, name: str) -> MemberMetadata | None:
        """Return safe immutable member metadata without exposing ZipInfo."""
        info = self._infos.get(name)
        if info is None:
            return None
        return MemberMetadata(
            name=name,
            file_size=info.file_size,
            compressed_size=info.compress_size,
            compression_type=info.compress_type,
        )

    def cached_xml(self, name: str) -> Element | None:
        """Return an already validated XML root without triggering another read."""
        return self._xml_cache.get(name)

    def _limit(
        self,
        name: str,
        observed: int | float,
        maximum: int | float,
    ) -> None:
        if observed > maximum:
            raise DocxResourceLimitError(
                limit_name=name,
                observed=observed,
                maximum=maximum,
            )

    def _preflight(self, infos: list[zipfile.ZipInfo]) -> None:
        self._limit(
            "package_members",
            len(infos),
            self.limits.max_package_members,
        )
        normalized_names: set[str] = set()
        total = 0
        for info in infos:
            name = info.filename
            normalized = unicodedata.normalize("NFKC", name)
            segments = name.split("/")
            if (
                not name
                or normalized != name
                or name.startswith("/")
                or _DRIVE_NAME.match(name)
                or "\\" in name
                or any(segment in {"", ".", ".."} for segment in segments)
                or any(
                    ord(character) < 32 or ord(character) == 127 for character in name
                )
            ):
                raise DocxPackageInvalidError(
                    "The DOCX package contains an unsafe member name"
                )
            if name in self._infos or normalized in normalized_names:
                raise DocxPackageInvalidError(
                    "The DOCX package contains duplicate member names"
                )
            normalized_names.add(normalized)
            if info.flag_bits & 0x1:
                raise DocxUnsupportedPackageError(
                    "Encrypted DOCX package members are unsupported"
                )
            if info.compress_type not in _SUPPORTED_COMPRESSION:
                raise DocxUnsupportedPackageError(
                    "The DOCX package uses unsupported compression"
                )
            mode = info.external_attr >> 16
            if mode and stat.S_IFMT(mode) not in {0, stat.S_IFREG}:
                raise DocxPackageInvalidError(
                    "The DOCX package contains a non-regular member"
                )
            self._limit(
                "member_uncompressed_bytes",
                info.file_size,
                self.limits.max_member_uncompressed_bytes,
            )
            total += info.file_size
            self._limit(
                "total_uncompressed_bytes",
                total,
                self.limits.max_total_uncompressed_bytes,
            )
            ratio = (
                float(info.file_size)
                if info.compress_size == 0
                else info.file_size / info.compress_size
            )
            if info.file_size:
                self._limit(
                    "compression_ratio",
                    ratio,
                    self.limits.max_compression_ratio,
                )
            self._infos[name] = info
        self.total_uncompressed_bytes = total
        if _CONTENT_TYPES not in self._infos or _ROOT_RELATIONSHIPS not in self._infos:
            raise DocxUnsupportedPackageError(
                "The package lacks required OPC declarations"
            )

    def read_part(self, name: str) -> bytes:
        """Read one preflighted bounded member and translate CRC/backend failures."""
        archive = self._archive
        info = self._infos.get(name)
        if archive is None or info is None:
            raise DocxPackageInvalidError("A required DOCX package part is missing")
        try:
            data = archive.read(info)
        except Exception as exc:
            _raise_redacted_translation(
                exc,
                DocxPackageInvalidError(
                    "A DOCX package member failed integrity validation"
                ),
            )
        if len(data) != info.file_size:
            raise DocxPackageInvalidError("A DOCX package member size is inconsistent")
        return data

    def hash_part(self, name: str) -> tuple[int, str]:
        """Hash one member incrementally without materializing another bytes copy."""
        archive = self._archive
        info = self._infos.get(name)
        if archive is None or info is None:
            raise DocxPackageInvalidError("A required DOCX package part is missing")
        digest = hashlib.sha256()
        observed = 0
        try:
            with archive.open(info, "r") as stream:
                while chunk := stream.read(1024 * 1024):
                    observed += len(chunk)
                    digest.update(chunk)
        except DocxPackageInvalidError:
            raise
        except Exception as exc:
            _raise_redacted_translation(
                exc,
                DocxPackageInvalidError(
                    "A DOCX package member failed integrity validation"
                ),
            )
        if observed != info.file_size:
            raise DocxPackageInvalidError("A DOCX package member size is inconsistent")
        return observed, digest.hexdigest()

    def read_xml(self, name: str) -> Element:
        """Parse one allowlisted bounded XML part with global budgets."""
        cached = self._xml_cache.get(name)
        if cached is not None:
            return cached
        info = self._infos.get(name)
        if info is None:
            raise DocxPackageInvalidError("A required DOCX XML part is missing")
        self._limit(
            "xml_part_bytes",
            info.file_size,
            self.limits.max_xml_part_bytes,
        )
        if name not in self._xml_parts_read:
            self._limit(
                "xml_parts",
                len(self._xml_parts_read) + 1,
                self.limits.max_xml_parts,
            )
            self._limit(
                "total_xml_bytes",
                self._total_xml_bytes + info.file_size,
                self.limits.max_total_xml_bytes,
            )
            self._xml_parts_read.add(name)
            self._total_xml_bytes += info.file_size
        data = self.read_part(name)
        try:
            parser = ElementTree.iterparse(
                io.BytesIO(data),
                events=("start", "end"),
                forbid_dtd=True,
                forbid_entities=True,
                forbid_external=True,
            )
            local_elements = 0
            depth = 0
            for event, _element in parser:
                if event == "start":
                    depth += 1
                    local_elements += 1
                    self._limit(
                        "xml_elements",
                        self._xml_elements + local_elements,
                        self.limits.max_xml_elements,
                    )
                    self._limit("xml_depth", depth, self.limits.max_xml_depth)
                else:
                    depth -= 1
            root = cast("Any", parser).root
        except DocxResourceLimitError:
            raise
        except (DefusedXmlException, ElementTree.ParseError) as exc:
            _raise_redacted_translation(
                exc,
                DocxPackageInvalidError("A DOCX XML part is malformed or unsafe"),
            )
        except Exception as exc:
            _raise_redacted_translation(
                exc,
                DocxPackageInvalidError("A DOCX XML part could not be parsed safely"),
            )
        self._xml_elements += local_elements
        result = cast("Element", root)
        self._xml_cache[name] = result
        return result

    def _parse_content_types(self) -> None:
        root = self.read_xml(_CONTENT_TYPES)
        if root.tag != f"{{{_CONTENT_TYPE_NS}}}Types":
            raise DocxPackageInvalidError(
                "The DOCX content-type root declaration is invalid"
            )
        overrides: dict[str, str] = {}
        defaults: dict[str, str] = {}
        for child in root:
            if child.tag == f"{{{_CONTENT_TYPE_NS}}}Override":
                part = child.attrib.get("PartName", "")
                content_type = child.attrib.get("ContentType", "")
                if (
                    not part.startswith("/")
                    or not content_type
                    or content_type.strip() != content_type
                ):
                    raise DocxPackageInvalidError(
                        "The DOCX content-type declaration is malformed"
                    )
                safe_part = _safe_internal_target("", part[1:])
                if safe_part != part[1:]:
                    raise DocxPackageInvalidError(
                        "The DOCX content-type part name is unsafe"
                    )
                if safe_part in overrides:
                    raise DocxPackageInvalidError(
                        "The DOCX content-type declaration is duplicated"
                    )
                overrides[safe_part] = content_type
            elif child.tag == f"{{{_CONTENT_TYPE_NS}}}Default":
                raw_extension = child.attrib.get("Extension", "")
                normalized_extension = unicodedata.normalize("NFKC", raw_extension)
                extension = normalized_extension.casefold()
                content_type = child.attrib.get("ContentType", "")
                if (
                    not extension
                    or normalized_extension != raw_extension
                    or "." in extension
                    or "/" in extension
                    or "\\" in extension
                    or any(
                        ord(character) < 32 or ord(character) == 127
                        for character in extension
                    )
                    or any(character.isspace() for character in extension)
                    or not content_type
                    or content_type.strip() != content_type
                    or extension in defaults
                ):
                    raise DocxPackageInvalidError(
                        "The DOCX default content-type declaration is malformed"
                    )
                defaults[extension] = content_type
            else:
                raise DocxPackageInvalidError(
                    "The DOCX content-type declaration uses an invalid namespace"
                )
        self._content_types = overrides
        self._defaults = defaults

    def content_type_declarations(self) -> tuple[str, ...]:
        """Return every validated Override and Default content type."""
        return (
            *tuple(self._content_types.values()),
            *tuple(self._defaults.values()),
        )

    def content_type(self, part: str) -> str | None:
        """Resolve an explicit or extension-default content type."""
        explicit = self._content_types.get(part)
        if explicit is not None:
            return explicit
        suffix = PurePosixPath(part).suffix.removeprefix(".").casefold()
        return self._defaults.get(suffix)

    def relationships(self, owner: str) -> tuple[Relationship, ...]:
        """Register one relationship part exactly once."""
        if owner in self._relationships:
            return self._relationships[owner]
        relationship_part = (
            _ROOT_RELATIONSHIPS if not owner else _relationship_part(owner)
        )
        if relationship_part not in self._infos:
            self._relationships[owner] = ()
            return ()
        root = self.read_xml(relationship_part)
        if root.tag != f"{{{_REL_NS}}}Relationships":
            raise DocxPackageInvalidError(
                "The DOCX relationship root declaration is invalid"
            )
        relationships: list[Relationship] = []
        ids: set[str] = set()
        for child in root:
            if child.tag != f"{{{_REL_NS}}}Relationship":
                raise DocxPackageInvalidError(
                    "The DOCX relationship declaration uses an invalid namespace"
                )
            relationship_id = child.attrib.get("Id", "")
            relationship_type = child.attrib.get("Type", "")
            raw_target = child.attrib.get("Target", "")
            target_mode = child.attrib.get("TargetMode")
            if target_mode not in {None, "Internal", "External"}:
                raise DocxPackageInvalidError(
                    "A DOCX relationship target mode is invalid"
                )
            external = target_mode == "External"
            if (
                not relationship_id
                or relationship_id.strip() != relationship_id
                or relationship_id in ids
                or not relationship_type
                or relationship_type.strip() != relationship_type
                or not raw_target
            ):
                raise DocxPackageInvalidError(
                    "A DOCX relationship declaration is malformed or duplicated"
                )
            next_count = self._relationship_count + len(relationships) + 1
            if next_count > self.limits.max_relationships:
                raise DocxResourceLimitError(
                    limit_name="relationships",
                    observed=next_count,
                    maximum=self.limits.max_relationships,
                )
            if relationship_type.startswith(_STRICT_RELATIONSHIP_PREFIX):
                raise DocxUnsupportedPackageError(
                    "Strict OOXML relationships are unsupported"
                )
            target = (
                raw_target if external else _safe_internal_target(owner, raw_target)
            )
            ids.add(relationship_id)
            relationships.append(
                Relationship(
                    relationship_id=relationship_id,
                    relationship_type=relationship_type,
                    target=target,
                    external=external,
                )
            )
        self._relationship_count += len(relationships)
        result = tuple(
            sorted(relationships, key=lambda relationship: relationship.relationship_id)
        )
        self._relationships[owner] = result
        return result

    def relationship_map(self, owner: str) -> dict[str, Relationship]:
        """Return deterministic relationship IDs for one owning part."""
        return {
            relationship.relationship_id: relationship
            for relationship in self.relationships(owner)
        }

"""Safe local file inspection."""

from pathlib import Path
from types import MappingProxyType

from document_sdk.core import FileAccessError, FileDescriptor, UnsupportedFileError
from document_sdk.core.errors import _raise_redacted_translation, safe_file_label
from document_sdk.files.fingerprint import calculate_sha256

SUPPORTED_MIME_TYPES = MappingProxyType(
    {
        ".bmp": "image/bmp",
        ".docx": (
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        ),
        ".jpeg": "image/jpeg",
        ".jpg": "image/jpeg",
        ".pdf": "application/pdf",
        ".png": "image/png",
        ".tif": "image/tiff",
        ".tiff": "image/tiff",
        ".webp": "image/webp",
        ".xlsm": "application/vnd.ms-excel.sheet.macroEnabled.12",
        ".xlsx": ("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
    }
)


def inspect_file(path: Path) -> FileDescriptor:
    """Inspect a supported local file without exposing its absolute path.

    Args:
        path: Path to a supported PDF, image, DOCX, XLSX, or XLSM regular file.

    Returns:
        A safe descriptor whose file identity is its SHA-256 digest.

    Raises:
        FileAccessError: If the path is missing, not a file, or cannot be read.
        UnsupportedFileError: If the file extension is unsupported.
    """
    if not path.exists():
        msg = f"File does not exist: {safe_file_label(path)}"
        raise FileAccessError(msg)
    if not path.is_file():
        msg = f"Path is not a regular file: {safe_file_label(path)}"
        raise FileAccessError(msg)

    extension = path.suffix.lower()
    try:
        mime_type = SUPPORTED_MIME_TYPES[extension]
    except KeyError:
        label = extension or "<none>"
        msg = f"Unsupported file type: {label}"
        raise UnsupportedFileError(msg) from None

    try:
        size_bytes = path.stat().st_size
    except OSError as exc:
        msg = f"Unable to inspect file: {safe_file_label(path)}"
        _raise_redacted_translation(exc, FileAccessError(msg))

    fingerprint = calculate_sha256(path)
    return FileDescriptor(
        file_id=fingerprint.value,
        filename=safe_file_label(path),
        extension=extension,
        mime_type=mime_type,
        size_bytes=size_bytes,
        fingerprint=fingerprint,
    )

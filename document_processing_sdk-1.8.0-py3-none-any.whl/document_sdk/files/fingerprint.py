"""Streaming file fingerprint operations."""

from hashlib import sha256
from pathlib import Path

from document_sdk.core import FileAccessError, FileFingerprint
from document_sdk.core.errors import _raise_redacted_translation, safe_file_label

DEFAULT_CHUNK_SIZE = 1024 * 1024


def calculate_sha256(
    path: Path,
    *,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
) -> FileFingerprint:
    """Calculate SHA-256 without loading the whole file into memory.

    Args:
        path: Local regular file to hash.
        chunk_size: Maximum number of bytes read per iteration.

    Returns:
        The lowercase SHA-256 fingerprint.

    Raises:
        ValueError: If ``chunk_size`` is not positive.
        FileAccessError: If the path is not an accessible regular file.
    """
    if chunk_size <= 0:
        msg = "chunk_size must be positive"
        raise ValueError(msg)
    if not path.exists():
        msg = f"File does not exist: {safe_file_label(path)}"
        raise FileAccessError(msg)
    if not path.is_file():
        msg = f"Path is not a regular file: {safe_file_label(path)}"
        raise FileAccessError(msg)

    digest = sha256()
    try:
        with path.open("rb") as stream:
            while chunk := stream.read(chunk_size):
                digest.update(chunk)
    except OSError as exc:
        msg = f"Unable to read file: {safe_file_label(path)}"
        _raise_redacted_translation(exc, FileAccessError(msg))
    return FileFingerprint(value=digest.hexdigest())

"""Private same-handle content-identity verification."""

from __future__ import annotations

from hashlib import sha256
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import BinaryIO


_FINGERPRINT_CHUNK_SIZE = 1024 * 1024


def verify_open_binary(
    stream: BinaryIO,
    *,
    expected_fingerprint: str,
    expected_size: int | None = None,
    mismatch_message: str = "File changed after inspection",
) -> None:
    """Verify identity on one stream and restore its original position."""
    position = stream.tell()
    digest = sha256()
    actual_size = 0
    try:
        stream.seek(0)
        while chunk := stream.read(_FINGERPRINT_CHUNK_SIZE):
            digest.update(chunk)
            actual_size += len(chunk)
    finally:
        stream.seek(position)
    if digest.hexdigest() != expected_fingerprint or (
        expected_size is not None and actual_size != expected_size
    ):
        raise ValueError(mismatch_message)

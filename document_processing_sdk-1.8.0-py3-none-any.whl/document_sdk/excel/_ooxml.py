"""Sparse OOXML workbook structure inspection."""

from __future__ import annotations

import posixpath
from dataclasses import dataclass
from typing import TYPE_CHECKING
from xml.etree.ElementTree import iterparse
from zipfile import ZipFile

from document_sdk.core._excel_coordinates import (
    MAX_EXCEL_COLUMN,
    MAX_EXCEL_ROW,
    excel_column_letter,
    excel_range_bounds,
    format_excel_range,
    normalize_excel_coordinate,
    normalize_excel_range,
)
from document_sdk.excel._package_security import _has_forbidden_xml_declaration
from document_sdk.excel._source_identity import open_verified_binary
from document_sdk.excel._visible_text import _visible_text
from document_sdk.excel._worksheet_xml import (
    _validate_cell_type,
    _worksheet_child,
    _worksheet_events,
)

if TYPE_CHECKING:
    from pathlib import Path
    from xml.etree.ElementTree import Element

    from document_sdk.core._excel_coordinates import ExcelRangeBounds


@dataclass(frozen=True, slots=True)
class WorksheetStructure:
    """Internal normalized worksheet structure."""

    name: str
    used_range: str | None
    max_row: int
    max_column: int
    merged_ranges: tuple[str, ...]
    hidden_rows: tuple[int, ...]
    hidden_columns: tuple[str, ...]
    formula_cell_count: int
    requires_full_read: bool


@dataclass(frozen=True, slots=True)
class WorkbookStructure:
    """Complete workbook order plus cell-bearing worksheet structures."""

    sheet_names: tuple[str, ...]
    worksheets: tuple[WorksheetStructure, ...]


@dataclass(frozen=True, slots=True)
class _SheetReference:
    """Workbook sheet name and relationship identifier."""

    name: str
    relationship_id: str


@dataclass(frozen=True, slots=True)
class _Relationship:
    """Internal OOXML package relationship."""

    target: str
    relationship_type: str
    external: bool


def _local_name(tag: str) -> str:
    """Return an XML local name without depending on namespace versions."""
    return tag.rsplit("}", 1)[-1]


def _attribute(element: Element, local_name: str) -> str | None:
    """Return one attribute by local name across OOXML namespaces."""
    for name, value in element.attrib.items():
        if _local_name(name) == local_name:
            return value
    return None


def _is_true(value: str | None) -> bool:
    """Interpret OOXML boolean lexical values."""
    return value in {"1", "true", "on"}


def _ensure_no_dtd(archive: ZipFile, member: str) -> None:
    """Reject DTD/entity declarations before standard-library XML parsing."""
    with archive.open(member) as stream:
        if _has_forbidden_xml_declaration(stream):
            msg = "OOXML package contains a forbidden XML declaration"
            raise ValueError(msg)


def _workbook_sheets(archive: ZipFile) -> tuple[_SheetReference, ...]:
    """Read ordered workbook sheet references."""
    sheets: list[_SheetReference] = []
    names: set[str] = set()
    relationship_ids: set[str] = set()
    _ensure_no_dtd(archive, "xl/workbook.xml")
    with archive.open("xl/workbook.xml") as stream:
        for _event, element in iterparse(  # noqa: S314 - DTDs rejected above.
            stream,
            events=("end",),
        ):
            if _local_name(element.tag) != "sheet":
                continue
            name = element.attrib.get("name")
            relationship_id = _attribute(element, "id")
            if not name or not relationship_id:
                msg = "workbook contains an invalid sheet reference"
                raise ValueError(msg)
            normalized_name = name.casefold()
            if normalized_name in names or relationship_id in relationship_ids:
                msg = "workbook contains duplicate sheet references"
                raise ValueError(msg)
            names.add(normalized_name)
            relationship_ids.add(relationship_id)
            sheets.append(
                _SheetReference(
                    name=name,
                    relationship_id=relationship_id,
                )
            )
            element.clear()
    return tuple(sheets)


def _workbook_relationships(archive: ZipFile) -> dict[str, _Relationship]:
    """Read workbook package relationships by identifier."""
    relationships: dict[str, _Relationship] = {}
    _ensure_no_dtd(archive, "xl/_rels/workbook.xml.rels")
    with archive.open("xl/_rels/workbook.xml.rels") as stream:
        for _event, element in iterparse(  # noqa: S314 - DTDs rejected above.
            stream,
            events=("end",),
        ):
            if _local_name(element.tag) != "Relationship":
                continue
            relationship_id = element.attrib.get("Id")
            target = element.attrib.get("Target")
            relationship_type = element.attrib.get("Type")
            if not relationship_id or not target or not relationship_type:
                msg = "workbook contains an invalid relationship"
                raise ValueError(msg)
            if relationship_id in relationships:
                msg = "workbook contains duplicate relationship identifiers"
                raise ValueError(msg)
            target_mode = element.attrib.get("TargetMode")
            if target_mode not in {None, "Internal", "External"}:
                msg = "workbook relationship has an invalid target mode"
                raise ValueError(msg)
            relationships[relationship_id] = _Relationship(
                target=target,
                relationship_type=relationship_type,
                external=target_mode == "External",
            )
            element.clear()
    return relationships


def _sheet_member(relationship: _Relationship, *, expected_type: str) -> str:
    """Resolve and validate one internal workbook sheet archive member."""
    if (
        relationship.external
        or relationship.relationship_type.rsplit("/", 1)[-1].casefold()
        != expected_type.casefold()
    ):
        msg = "workbook contains an unsupported sheet relationship"
        raise ValueError(msg)
    if relationship.target.startswith("/"):
        member = posixpath.normpath(relationship.target.lstrip("/"))
    else:
        member = posixpath.normpath(posixpath.join("xl", relationship.target))
    if member == "xl" or not member.startswith("xl/") or member.startswith("../"):
        msg = "workbook sheet relationship escapes the package"
        raise ValueError(msg)
    return member


def _worksheet_member(relationship: _Relationship) -> str:
    """Resolve and validate an internal worksheet archive member."""
    return _sheet_member(relationship, expected_type="worksheet")


def _cell_has_value(cell: Element, *, has_formula: bool) -> bool:
    """Match openpyxl's non-None cell-value semantics from worksheet XML."""
    if has_formula:
        return True
    value = _worksheet_child(cell, "v")
    if value is not None:
        return value.text is not None
    inline = _worksheet_child(cell, "is")
    if inline is not None:
        return _visible_text(
            inline,
            container="is",
            label="inline String",
        ).choice_present
    return False


def _row_index(element: Element, previous_row: int) -> int:
    """Return an explicit or positionally inferred one-based row index."""
    row_text = element.attrib.get("r")
    row = previous_row + 1 if row_text is None else int(row_text)
    if row < 1 or row > MAX_EXCEL_ROW:
        msg = "worksheet row is outside Excel bounds"
        raise ValueError(msg)
    if row <= previous_row:
        msg = "worksheet rows are not in deterministic order"
        raise ValueError(msg)
    return row


def _hidden_row(element: Element, row: int) -> int | None:
    """Return an inferred or explicit hidden row index."""
    return row if _is_true(element.attrib.get("hidden")) else None


def _cell_coordinate(
    element: Element,
    *,
    current_row: int | None,
    previous_column: int,
) -> tuple[str, int]:
    """Return an explicit or positionally inferred cell coordinate."""
    if current_row is None:
        msg = "worksheet cell is outside a row"
        raise ValueError(msg)
    coordinate = element.attrib.get("r")
    if coordinate is None:
        column = previous_column + 1
        if column > MAX_EXCEL_COLUMN:
            msg = "worksheet cell is outside Excel bounds"
            raise ValueError(msg)
        return f"{excel_column_letter(column)}{current_row}", column

    normalized = normalize_excel_coordinate(coordinate)
    bounds = excel_range_bounds(normalized)
    if bounds.min_row != current_row:
        msg = "worksheet cell coordinate does not match its row"
        raise ValueError(msg)
    if bounds.min_column <= previous_column:
        msg = "worksheet cells are not in deterministic row order"
        raise ValueError(msg)
    return normalized, bounds.min_column


def _hidden_column(element: Element) -> str | None:
    """Return the public openpyxl-compatible key for a hidden column range."""
    if not _is_true(element.attrib.get("hidden")):
        return None
    minimum = int(element.attrib["min"])
    maximum = int(element.attrib["max"])
    if minimum < 1 or maximum < minimum or maximum > MAX_EXCEL_COLUMN:
        msg = "hidden worksheet column is outside Excel bounds"
        raise ValueError(msg)
    return excel_column_letter(minimum)


def _hyperlink_facts(
    archive: ZipFile,
    member: str,
) -> tuple[set[str], tuple[int, int, int, int] | None, bool]:
    """Pre-scan bounded hyperlink references without retaining cell locations."""
    pending_single_cells: set[str] = set()
    min_row: int | None = None
    min_column: int | None = None
    max_row = 0
    max_column = 0
    requires_full_read = False

    with archive.open(member) as stream:
        for event, element, name in _worksheet_events(stream):
            if event != "end":
                continue
            if name != "hyperlink":
                element.clear()
                continue
            reference = element.attrib.get("ref")
            has_target = (
                _attribute(element, "id") is not None
                or element.attrib.get("location") is not None
            )
            if reference is None:
                msg = "worksheet hyperlink is missing its reference"
                raise ValueError(msg)
            if has_target:
                normalized_reference = normalize_excel_range(reference)
                hyperlink_bounds = excel_range_bounds(normalized_reference)
                min_row = (
                    hyperlink_bounds.min_row
                    if min_row is None
                    else min(min_row, hyperlink_bounds.min_row)
                )
                min_column = (
                    hyperlink_bounds.min_column
                    if min_column is None
                    else min(min_column, hyperlink_bounds.min_column)
                )
                max_row = max(max_row, hyperlink_bounds.max_row)
                max_column = max(max_column, hyperlink_bounds.max_column)
                if ":" in normalized_reference:
                    requires_full_read = True
                else:
                    pending_single_cells.add(normalized_reference)
            element.clear()

    bounds = (
        None
        if min_row is None or min_column is None
        else (min_row, min_column, max_row, max_column)
    )
    return pending_single_cells, bounds, requires_full_read


def _inspect_worksheet(  # noqa: C901, PLR0912, PLR0915
    archive: ZipFile,
    *,
    name: str,
    member: str,
    validate_cell_types: bool = False,
    selected_bounds: ExcelRangeBounds | None = None,
) -> WorksheetStructure:
    """Stream one worksheet XML member without constructing blank cells."""
    min_row: int | None = None
    min_column: int | None = None
    max_row = 0
    max_column = 0
    formula_cell_count = 0
    merged_ranges: list[str] = []
    hidden_rows: list[int] = []
    hidden_columns: list[str] = []
    previous_row = 0
    current_row: int | None = None
    previous_cell_column = 0

    _ensure_no_dtd(archive, member)
    (
        pending_hyperlink_cells,
        hyperlink_bounds,
        requires_full_read,
    ) = _hyperlink_facts(archive, member)
    if hyperlink_bounds is not None:
        min_row, min_column, max_row, max_column = hyperlink_bounds

    with archive.open(member) as stream:
        for event, element, element_name in _worksheet_events(stream):
            if event == "start":
                if element_name == "row":
                    if current_row is not None:
                        msg = "worksheet contains nested rows"
                        raise ValueError(msg)
                    current_row = _row_index(element, previous_row)
                    previous_cell_column = 0
                continue

            if element_name == "c":
                normalized_coordinate, previous_cell_column = _cell_coordinate(
                    element,
                    current_row=current_row,
                    previous_column=previous_cell_column,
                )
                bounds = excel_range_bounds(normalized_coordinate)
                if validate_cell_types and (
                    selected_bounds is None
                    or (
                        selected_bounds.min_row
                        <= bounds.min_row
                        <= selected_bounds.max_row
                        and selected_bounds.min_column
                        <= bounds.min_column
                        <= selected_bounds.max_column
                    )
                ):
                    _validate_cell_type(element)
                has_formula = _worksheet_child(element, "f") is not None
                if has_formula:
                    formula_cell_count += 1
                if _cell_has_value(element, has_formula=has_formula):
                    pending_hyperlink_cells.discard(normalized_coordinate)
                    min_row = (
                        bounds.min_row
                        if min_row is None
                        else min(min_row, bounds.min_row)
                    )
                    min_column = (
                        bounds.min_column
                        if min_column is None
                        else min(min_column, bounds.min_column)
                    )
                    max_row = max(max_row, bounds.max_row)
                    max_column = max(max_column, bounds.max_column)
                element.clear()
            elif element_name == "row":
                if current_row is None:
                    msg = "worksheet row state is invalid"
                    raise ValueError(msg)
                hidden_row = _hidden_row(element, current_row)
                if hidden_row is not None:
                    hidden_rows.append(hidden_row)
                previous_row = current_row
                current_row = None
                previous_cell_column = 0
                element.clear()
            elif element_name == "col":
                hidden_column = _hidden_column(element)
                if hidden_column is not None:
                    hidden_columns.append(hidden_column)
                element.clear()
            elif element_name == "mergeCell":
                reference = element.attrib.get("ref")
                if reference is None:
                    msg = "merged worksheet range is missing its reference"
                    raise ValueError(msg)
                merged_ranges.append(normalize_excel_range(reference))
                element.clear()
            elif element_name == "hyperlink":
                element.clear()

    requires_full_read = requires_full_read or bool(pending_hyperlink_cells)
    used_range = (
        None
        if min_row is None or min_column is None
        else format_excel_range(
            min_column,
            min_row,
            max_column,
            max_row,
        )
    )
    return WorksheetStructure(
        name=name,
        used_range=used_range,
        max_row=max_row,
        max_column=max_column,
        merged_ranges=tuple(merged_ranges),
        hidden_rows=tuple(hidden_rows),
        hidden_columns=tuple(hidden_columns),
        formula_cell_count=formula_cell_count,
        requires_full_read=requires_full_read,
    )


def inspect_ooxml_workbook(
    path: Path,
    *,
    expected_fingerprint: str | None = None,
) -> WorkbookStructure:
    """Return complete sheet order and ordered sparse worksheet structures."""
    with (
        open_verified_binary(path, expected_fingerprint) as source,
        ZipFile(source, "r") as archive,
    ):
        sheets = _workbook_sheets(archive)
        relationships = _workbook_relationships(archive)
        structures: list[WorksheetStructure] = []
        for sheet in sheets:
            relationship = relationships.get(sheet.relationship_id)
            if relationship is None:
                msg = "workbook sheet relationship does not exist"
                raise ValueError(msg)
            relationship_type = relationship.relationship_type.rsplit("/", 1)[
                -1
            ].casefold()
            if relationship_type == "chartsheet":
                member = _sheet_member(relationship, expected_type="chartsheet")
                if member not in archive.namelist():
                    msg = "workbook Chartsheet relationship target does not exist"
                    raise ValueError(msg)
                continue
            if relationship_type in {"macrosheet", "xlmacrosheet"}:
                member = _sheet_member(
                    relationship,
                    expected_type=relationship_type,
                )
                if member not in archive.namelist():
                    msg = "workbook Macro Sheet relationship target does not exist"
                    raise ValueError(msg)
                continue
            structures.append(
                _inspect_worksheet(
                    archive,
                    name=sheet.name,
                    member=_worksheet_member(relationship),
                )
            )
    return WorkbookStructure(
        sheet_names=tuple(sheet.name for sheet in sheets),
        worksheets=tuple(structures),
    )


def inspect_ooxml_worksheet(
    path: Path,
    sheet_name: str,
    *,
    expected_fingerprint: str | None = None,
    validate_cell_types: bool = False,
    selected_bounds: ExcelRangeBounds | None = None,
) -> WorksheetStructure | None:
    """Return one selected worksheet structure without scanning other sheets."""
    with (
        open_verified_binary(path, expected_fingerprint) as source,
        ZipFile(source, "r") as archive,
    ):
        sheet = next(
            (
                reference
                for reference in _workbook_sheets(archive)
                if reference.name == sheet_name
            ),
            None,
        )
        if sheet is None:
            return None
        relationship = _workbook_relationships(archive).get(sheet.relationship_id)
        if relationship is None:
            msg = "workbook sheet relationship does not exist"
            raise ValueError(msg)
        return _inspect_worksheet(
            archive,
            name=sheet.name,
            member=_worksheet_member(relationship),
            validate_cell_types=validate_cell_types,
            selected_bounds=selected_bounds,
        )

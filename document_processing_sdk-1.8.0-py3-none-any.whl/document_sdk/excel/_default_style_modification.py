"""Bounded package-level workbook default-style modification."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal, cast

from document_sdk.excel._column_modification import (
    _ColumnStyleTable,
    _copy_package,
)
from document_sdk.excel._package import _SafePackage
from document_sdk.excel.errors import ExcelModificationError

if TYPE_CHECKING:
    from pathlib import Path

    from document_sdk.excel.models import WorkbookDefaultStylePatch


type _DefaultStyleComponent = Literal[
    "font", "fill", "border", "alignment", "number_format", "named_style"
]


@dataclass(frozen=True, slots=True)
class _PendingDefaultStyleChange:
    """One verified workbook default-style change before file identities exist."""

    old_fingerprint: str
    new_fingerprint: str
    changed_components: tuple[_DefaultStyleComponent, ...]


def _settings(patch: WorkbookDefaultStylePatch) -> dict[str, object]:
    return {
        field: value
        for field in (
            "font",
            "fill",
            "border",
            "alignment",
            "number_format",
            "named_style",
        )
        if (value := getattr(patch, field)) is not None
    }


def create_default_style_patch_output(
    source_path: Path,
    output_path: Path,
    patch: WorkbookDefaultStylePatch,
    *,
    source_fingerprint: str,
) -> _PendingDefaultStyleChange | None:
    """Write and independently verify one package-level default-style patch."""
    replacements: dict[str, bytes] = {}
    with _SafePackage(source_path) as package:
        package.verify_fingerprint(source_fingerprint)
        if not package.has("xl/styles.xml"):
            msg = "Workbook styles part does not exist"
            raise ExcelModificationError(msg)
        with package.open_xml_stream("xl/styles.xml") as stream:
            table = _ColumnStyleTable.parse(stream.read())
        settings = _settings(patch)
        old_fingerprint, new_fingerprint = table.apply_default(settings)
        if old_fingerprint != new_fingerprint:
            replacements["xl/styles.xml"] = table.payload()
    _copy_package(
        source_path,
        output_path,
        replacements,
        source_fingerprint=source_fingerprint,
    )
    verify_default_style_patch_output(output_path, patch)
    if old_fingerprint == new_fingerprint:
        return None
    return _PendingDefaultStyleChange(
        old_fingerprint=old_fingerprint,
        new_fingerprint=new_fingerprint,
        changed_components=cast(
            "tuple[_DefaultStyleComponent, ...]",
            tuple(_settings(patch)),
        ),
    )


def verify_default_style_patch_output(
    output_path: Path,
    patch: WorkbookDefaultStylePatch,
) -> None:
    """Verify default-style semantics from an independently reopened package."""
    with _SafePackage(output_path) as package:
        if not package.has("xl/styles.xml"):
            msg = "Patched workbook styles part does not exist"
            raise ExcelModificationError(msg)
        with package.open_xml_stream("xl/styles.xml") as stream:
            table = _ColumnStyleTable.parse(stream.read())
        actual_fingerprint = table.fingerprint(0)
        expected_style_id = table.resolve(0, _settings(patch))
        if (
            table.fingerprint(expected_style_id) != actual_fingerprint
            or not table.default_is_consistent()
        ):
            msg = "Patched workbook default-style verification failed"
            raise ExcelModificationError(msg)

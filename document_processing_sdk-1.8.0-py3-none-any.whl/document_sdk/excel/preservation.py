"""Conservative workbook preservation assessment."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from document_sdk.excel.features import _scan_workbook_features
from document_sdk.excel.models import (
    PreservationItem,
    WorkbookPreservationReport,
    WorksheetFeatureInventory,
)

if TYPE_CHECKING:
    from pathlib import Path

    from document_sdk.excel._package import PackageFeatureScan

type PreservationOperation = Literal["patch", "template_fill", "rewrite"]


def _present(
    worksheets: tuple[WorksheetFeatureInventory, ...],
    attribute: str,
) -> bool:
    return any(bool(getattr(worksheet, attribute)) for worksheet in worksheets)


def _absent_item(feature: str) -> PreservationItem:
    return PreservationItem(
        feature=feature,
        present=False,
        status="SAFE",
        disposition="guaranteed_preserved",
        details="The feature is not present in the workbook.",
    )


def _item(
    feature: str,
    *,
    present: bool,
    status: Literal["SAFE", "SAFE_WITH_WARNINGS", "UNSUPPORTED"],
    disposition: Literal[
        "guaranteed_preserved",
        "expected_preserved",
        "present_untouched",
        "possible_loss",
        "unsupported",
    ],
    details: str,
) -> PreservationItem:
    if not present:
        return _absent_item(feature)
    return PreservationItem(
        feature=feature,
        present=True,
        status=status,
        disposition=disposition,
        details=details,
    )


def _ordinary_item(
    feature: str,
    *,
    present: bool,
    operation: PreservationOperation,
) -> PreservationItem:
    if operation == "rewrite":
        return _item(
            feature,
            present=present,
            status="UNSUPPORTED",
            disposition="possible_loss",
            details="A rewrite does not guarantee preservation of this feature.",
        )
    return _item(
        feature,
        present=present,
        status="SAFE_WITH_WARNINGS",
        disposition="expected_preserved",
        details=(
            "Patch operations are expected to preserve this feature, "
            "but package-level equivalence is not guaranteed."
        ),
    )


def _complex_item(
    feature: str,
    *,
    present: bool,
    details: str,
) -> PreservationItem:
    return _item(
        feature,
        present=present,
        status="UNSUPPORTED",
        disposition="unsupported",
        details=details,
    )


def _vba_item(
    scan: PackageFeatureScan,
    *,
    operation: PreservationOperation,
) -> PreservationItem:
    inventory = scan.inventory
    present = inventory.vba_project_present
    if operation == "rewrite" or inventory.workbook_type != "xlsm":
        return _complex_item(
            "vba_package",
            present=present,
            details="The selected operation cannot guarantee VBA package preservation.",
        )
    return _item(
        "vba_package",
        present=present,
        status="SAFE_WITH_WARNINGS",
        disposition="present_untouched",
        details=(
            "The VBA package can be retained without reading or executing macro "
            "content, "
            "but binary equivalence is not guaranteed."
        ),
    )


def _build_items(
    scan: PackageFeatureScan,
    *,
    operation: PreservationOperation,
) -> tuple[PreservationItem, ...]:
    inventory = scan.inventory
    worksheets = inventory.worksheets
    formulas = _present(worksheets, "formulas")
    styles = any(worksheet.styled_cell_count > 0 for worksheet in worksheets)
    unsupported_types = {sheet.sheet_type for sheet in inventory.unsupported_sheets}

    items = [
        _item(
            "cell_values",
            present=scan.risk_facts.cell_values_present,
            status="SAFE",
            disposition="guaranteed_preserved",
            details=(
                "Addressed cell values are preserved by the selected operation."
                if operation != "rewrite"
                else "Cell values are represented by the rewrite operation."
            ),
        ),
        _ordinary_item("formulas", present=formulas, operation=operation),
        _complex_item(
            "formula_caches",
            present=scan.risk_facts.formula_cache_present,
            details=(
                "Stored formula caches may be stale and are not preserved by "
                "patch operations; formulas are never recalculated."
            ),
        ),
        _item(
            "dynamic_array_metadata",
            present=scan.risk_facts.dynamic_array_metadata_present,
            status=("UNSUPPORTED" if operation == "rewrite" else "SAFE_WITH_WARNINGS"),
            disposition=(
                "possible_loss" if operation == "rewrite" else "present_untouched"
            ),
            details=(
                "Dynamic-array metadata, workbook reachability, and untouched "
                "cell metadata references are restored after patch operations."
                if operation != "rewrite"
                else "A rewrite does not preserve dynamic-array metadata."
            ),
        ),
        _ordinary_item("cell_styles", present=styles, operation=operation),
        _ordinary_item(
            "merged_cells",
            present=_present(worksheets, "merged_ranges"),
            operation=operation,
        ),
        _ordinary_item(
            "row_heights",
            present=_present(worksheets, "row_heights"),
            operation=operation,
        ),
        _ordinary_item(
            "column_widths",
            present=_present(worksheets, "column_widths"),
            operation=operation,
        ),
        _ordinary_item(
            "freeze_panes",
            present=any(worksheet.freeze_panes for worksheet in worksheets),
            operation=operation,
        ),
        _ordinary_item(
            "hyperlinks",
            present=_present(worksheets, "hyperlinks"),
            operation=operation,
        ),
        _ordinary_item(
            "comments",
            present=_present(worksheets, "comments"),
            operation=operation,
        ),
        _ordinary_item(
            "data_validations",
            present=_present(worksheets, "data_validations"),
            operation=operation,
        ),
        _ordinary_item(
            "conditional_formatting",
            present=_present(worksheets, "conditional_formats"),
            operation=operation,
        ),
        _ordinary_item(
            "named_ranges",
            present=bool(inventory.defined_names),
            operation=operation,
        ),
        _ordinary_item(
            "excel_tables",
            present=_present(worksheets, "tables"),
            operation=operation,
        ),
        _item(
            "images",
            present=any(worksheet.image_count > 0 for worksheet in worksheets),
            status=("UNSUPPORTED" if operation == "rewrite" else "SAFE"),
            disposition=(
                "possible_loss" if operation == "rewrite" else "guaranteed_preserved"
            ),
            details=(
                "Image-bearing DrawingML, media bytes, anchors, relationships, and "
                "content types are restored and verified after patch operations."
                if operation != "rewrite"
                else "A rewrite does not preserve workbook images."
            ),
        ),
        _ordinary_item(
            "charts",
            present=any(worksheet.chart_count > 0 for worksheet in worksheets),
            operation=operation,
        ),
        _item(
            "shapes_drawings",
            present=scan.risk_facts.shape_or_unknown_drawing_present,
            status=("UNSUPPORTED" if operation == "rewrite" else "SAFE_WITH_WARNINGS"),
            disposition=(
                "possible_loss" if operation == "rewrite" else "present_untouched"
            ),
            details=(
                "Drawing, chart, media, and VML package parts are retained without "
                "interpreting their contents after patch operations."
                if operation != "rewrite"
                else "A rewrite does not preserve shape and drawing package parts."
            ),
        ),
        _item(
            "worksheet_extensions",
            present=scan.risk_facts.worksheet_extension_present,
            status=("UNSUPPORTED" if operation == "rewrite" else "SAFE_WITH_WARNINGS"),
            disposition=(
                "possible_loss" if operation == "rewrite" else "present_untouched"
            ),
            details=(
                "Worksheet extension content is restored byte-for-byte at the "
                "worksheet XML boundary after patch operations."
                if operation != "rewrite"
                else "A rewrite does not preserve worksheet extension content."
            ),
        ),
        _vba_item(scan, operation=operation),
        _item(
            "external_links",
            present=inventory.external_link_count > 0
            or any(name.external_reference for name in inventory.defined_names),
            status=("UNSUPPORTED" if operation == "rewrite" else "SAFE_WITH_WARNINGS"),
            disposition=(
                "possible_loss" if operation == "rewrite" else "present_untouched"
            ),
            details=(
                "External-link parts and relationships are retained without "
                "following or resolving their external targets unless explicit "
                "unreferenced-link cleanup is requested."
                if operation != "rewrite"
                else "A rewrite does not preserve external workbook links."
            ),
        ),
        _item(
            "chartsheets",
            present=bool(inventory.chartsheets),
            status=("UNSUPPORTED" if operation == "rewrite" else "SAFE"),
            disposition=(
                "possible_loss" if operation == "rewrite" else "guaranteed_preserved"
            ),
            details=(
                "Chartsheet records and their bounded relationship closure are "
                "restored and verified after patch operations."
                if operation != "rewrite"
                else "A rewrite does not preserve Chartsheet package structure."
            ),
        ),
        _complex_item(
            "dialog_sheets",
            present="dialog_sheet" in unsupported_types,
            details="Dialog-sheet preservation is outside the supported boundary.",
        ),
        _item(
            "macro_sheets",
            present=bool(inventory.macro_sheets),
            status=("UNSUPPORTED" if operation == "rewrite" else "SAFE"),
            disposition=(
                "possible_loss" if operation == "rewrite" else "guaranteed_preserved"
            ),
            details=(
                "Excel 4.0 Macro Sheet parts are never executed; their records, "
                "defined names, and bounded relationship closure are restored and "
                "verified after patch operations."
                if operation != "rewrite"
                else "A rewrite does not preserve Excel 4.0 Macro Sheet structure."
            ),
        ),
        _complex_item(
            "unknown_sheet_types",
            present="unknown" in unsupported_types,
            details="Unknown sheet-type preservation cannot be guaranteed.",
        ),
        _complex_item(
            "active_x",
            present=inventory.active_x_count > 0,
            details="ActiveX preservation and editing are unsupported.",
        ),
        _ordinary_item(
            "workbook_protection",
            present=inventory.workbook_protection_present,
            operation=operation,
        ),
        _item(
            "unknown_package_parts",
            present=bool(inventory.unknown_package_parts),
            status=("UNSUPPORTED" if operation == "rewrite" else "SAFE_WITH_WARNINGS"),
            disposition=(
                "possible_loss" if operation == "rewrite" else "present_untouched"
            ),
            details=(
                "Unrecognized and high-risk package parts are restored with their "
                "source package reachability after patch operations."
                if operation != "rewrite"
                else "A rewrite does not preserve unrecognized package parts."
            ),
        ),
    ]
    return tuple(items)


def assess_workbook_preservation(
    path: Path,
    *,
    operation: PreservationOperation,
) -> WorkbookPreservationReport:
    """Assess feature-preservation risk for one planned workbook operation."""
    if operation not in {"patch", "template_fill", "rewrite"}:
        msg = "operation must be 'patch', 'template_fill', or 'rewrite'"
        raise ValueError(msg)

    scan = _scan_workbook_features(path)
    items = _build_items(scan, operation=operation)
    if any(item.present and item.status == "UNSUPPORTED" for item in items):
        overall_status: Literal["SAFE", "SAFE_WITH_WARNINGS", "UNSUPPORTED"] = (
            "UNSUPPORTED"
        )
    elif any(item.present and item.status == "SAFE_WITH_WARNINGS" for item in items):
        overall_status = "SAFE_WITH_WARNINGS"
    else:
        overall_status = "SAFE"

    warnings = tuple(
        f"{item.feature}: {item.details}"
        for item in items
        if item.present and item.status != "SAFE"
    )
    return WorkbookPreservationReport(
        file=scan.inventory.file,
        operation=operation,
        overall_status=overall_status,
        items=items,
        warnings=warnings,
    )

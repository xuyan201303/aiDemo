"""Bounded formula-aware external workbook reference handling."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Callable

_EXTERNAL_RANGE_PREFIX = re.compile(r"^\[(?P<index>[1-9][0-9]*)\](?P<target>.*)$")
_EXTERNAL_WORKBOOK_QUALIFIER = re.compile(
    r"^(?P<prefix>[^\[\]]*)\[(?P<workbook>[^\[\]]+)\](?P<sheet>.+)$"
)
_DRIVE_PATH = re.compile(r"^[A-Za-z]:[\\/]")
_URI_PATH = re.compile(r"^[A-Za-z][A-Za-z0-9+.-]*:(?://|/)")
_QUOTED_PATH_AND_SHEET = re.compile(r"^'(?P<path>[^']+)'![^!]+$")


def _formula_tokens(formula: str) -> tuple[bool, list[Any]]:
    from openpyxl.formula import Tokenizer

    has_equals = formula.startswith("=")
    source = formula if has_equals else f"={formula}"
    try:
        return has_equals, Tokenizer(source).items
    except Exception:  # noqa: BLE001 - third-party parser may raise undocumented exceptions
        msg = "Workbook formula cannot be safely analyzed"
        raise ValueError(msg) from None


def _is_bounded_external_path(value: str) -> bool:
    lowered = value.casefold()
    return bool(
        _DRIVE_PATH.match(value) is not None
        or value.startswith(("\\\\", "//", "../", "..\\", "./", ".\\", "/"))
        or _URI_PATH.match(lowered) is not None
        or "/" in value
        or "\\" in value
    )


def is_bounded_external_path(value: str) -> bool:
    """Return whether a non-empty value has a bounded external path form."""
    return bool(value) and _is_bounded_external_path(value)


def _external_range_identity(value: str) -> tuple[bool, int | None]:
    if "!" not in value:
        return False, None
    qualifier = value.rsplit("!", 1)[0]
    if qualifier.startswith("'") and qualifier.endswith("'"):
        qualifier = qualifier[1:-1].replace("''", "'")
    numeric = _EXTERNAL_RANGE_PREFIX.fullmatch(qualifier)
    if numeric is not None:
        return True, int(numeric.group("index"))
    quoted_path = _QUOTED_PATH_AND_SHEET.fullmatch(qualifier)
    if quoted_path is not None:
        return _is_bounded_external_path(quoted_path.group("path")), None
    match = _EXTERNAL_WORKBOOK_QUALIFIER.fullmatch(qualifier)
    if match is None:
        return _is_bounded_external_path(qualifier), None
    prefix = match.group("prefix")
    is_bounded_path = not prefix or _is_bounded_external_path(prefix)
    return is_bounded_path, None


def external_workbook_indexes(formula: str) -> frozenset[int]:
    """Return true numeric external-workbook indexes from formula range tokens."""
    _has_equals, tokens = _formula_tokens(formula)
    indexes: set[int] = set()
    for token in tokens:
        if token.type != "OPERAND" or token.subtype != "RANGE":
            continue
        detected, index = _external_range_identity(token.value)
        if detected and index is not None:
            indexes.add(index)
    return frozenset(indexes)


def is_external_workbook_range(value: str) -> bool:
    """Return whether one formula RANGE token targets an external workbook."""
    return _external_range_identity(value)[0]


def external_workbook_references(formula: str) -> tuple[int | None, ...]:
    """Return numeric indexes or ``None`` for path-based external references."""
    _has_equals, tokens = _formula_tokens(formula)
    references: list[int | None] = []
    for token in tokens:
        if token.type != "OPERAND" or token.subtype != "RANGE":
            continue
        detected, index = _external_range_identity(token.value)
        if detected:
            references.append(index)
    return tuple(references)


def formula_has_external_reference(formula: str) -> bool:
    """Detect external workbook references without matching strings or tables."""
    _has_equals, tokens = _formula_tokens(formula)
    return any(
        token.type == "OPERAND"
        and token.subtype == "RANGE"
        and _external_range_identity(token.value)[0]
        for token in tokens
    )


def rewrite_external_workbook_indexes(
    formula: str,
    replace_index: Callable[[int], int | None],
) -> str:
    """Rewrite only external-workbook index prefixes in formula range tokens."""
    has_equals, tokens = _formula_tokens(formula)
    rewritten = ["="]
    for token in tokens:
        value = token.value
        if token.type == "OPERAND" and token.subtype == "RANGE":
            detected, index = _external_range_identity(value)
            if detected and index is not None:
                match = _EXTERNAL_RANGE_PREFIX.match(value.lstrip("'"))
                if match is None:  # pragma: no cover - bounded parser invariant.
                    continue
                replacement = replace_index(index)
                if replacement is not None:
                    start, end = match.span("index")
                    offset = 1 if value.startswith("'") else 0
                    start += offset
                    end += offset
                    value = f"{value[:start]}{replacement}{value[end:]}"
        rewritten.append(value)
    result = "".join(rewritten)
    return result if has_equals else result[1:]

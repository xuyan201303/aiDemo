"""Bounded package-level worksheet hyperlink and legacy-comment replacement."""

from __future__ import annotations

import hashlib
import json
import posixpath
from dataclasses import dataclass
from typing import TYPE_CHECKING
from xml.dom import Node, minidom

from document_sdk.core._excel_coordinates import excel_range_bounds
from document_sdk.excel._column_modification import (
    _copy_package,
    _direct_elements,
    _document_root,
)
from document_sdk.excel._package import _SafePackage
from document_sdk.excel._package_security import _resolve_target, _serialize_xml
from document_sdk.excel._package_workbook import _workbook_records
from document_sdk.excel._package_worksheet import (
    _SPREADSHEETML_WORKSHEET_NAMESPACES,
)
from document_sdk.excel._xml_namespaces import namespace_prefix
from document_sdk.excel.errors import ExcelModificationError

if TYPE_CHECKING:
    from collections.abc import Sequence
    from pathlib import Path
    from xml.dom.minidom import Document, Element

    from document_sdk.excel.models import (
        HyperlinkRecordPatch,
        LegacyCommentRecordPatch,
        WorksheetHyperlinkPatch,
        WorksheetLegacyCommentsPatch,
    )


_CONTENT_TYPES_MEMBER = "[Content_Types].xml"
_CONTENT_TYPES_NAMESPACE = (
    "http://schemas.openxmlformats.org/package/2006/content-types"
)
_RELATIONSHIPS_NAMESPACE = (
    "http://schemas.openxmlformats.org/package/2006/relationships"
)
_TRANSITIONAL_OFFICE_RELATIONSHIPS = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
)
_STRICT_OFFICE_RELATIONSHIPS = "http://purl.oclc.org/ooxml/officeDocument/relationships"
_XML_NAMESPACE = "http://www.w3.org/XML/1998/namespace"
_COMMENTS_CONTENT_TYPE = (
    "application/vnd.openxmlformats-officedocument.spreadsheetml.comments+xml"
)
_VML_CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.vmlDrawing"
_VML_NAMESPACE = "urn:schemas-microsoft-com:vml"
_OFFICE_NAMESPACE = "urn:schemas-microsoft-com:office:office"
_EXCEL_NAMESPACE = "urn:schemas-microsoft-com:office:excel"
_WORKSHEET_TRAILING_ELEMENTS = frozenset(
    {
        "printOptions",
        "pageMargins",
        "pageSetup",
        "headerFooter",
        "rowBreaks",
        "colBreaks",
        "customProperties",
        "cellWatches",
        "ignoredErrors",
        "smartTags",
        "drawing",
        "legacyDrawing",
        "legacyDrawingHF",
        "picture",
        "oleObjects",
        "controls",
        "webPublishItems",
        "tableParts",
        "extLst",
    }
)


@dataclass(frozen=True, slots=True)
class _PendingHyperlinkChange:
    sheet_name: str
    old_count: int
    new_count: int
    old_fingerprint: str
    new_fingerprint: str


@dataclass(frozen=True, slots=True)
class _PendingLegacyCommentChange:
    sheet_name: str
    old_count: int
    new_count: int
    old_fingerprint: str
    new_fingerprint: str


def _document(payload: bytes, namespace: str, label: str) -> tuple[Document, Element]:
    document = minidom.parseString(  # noqa: S318 - bounded, DTD-screened OOXML.
        payload
    )
    root = _document_root(document)
    if root.namespaceURI != namespace:
        msg = f"Workbook {label} namespace is unsupported"
        raise ValueError(msg)
    return document, root


def _worksheet_document(payload: bytes) -> tuple[Document, Element, str]:
    document = minidom.parseString(  # noqa: S318 - bounded, DTD-screened OOXML.
        payload
    )
    root = _document_root(document)
    namespace = root.namespaceURI
    if namespace not in _SPREADSHEETML_WORKSHEET_NAMESPACES:
        msg = "Workbook worksheet namespace is unsupported"
        raise ValueError(msg)
    return document, root, namespace


def _payload(package: _SafePackage, member: str) -> bytes:
    with package.open_xml_stream(member) as stream:
        return stream.read()


def _relationships_member(source_member: str) -> str:
    directory, filename = posixpath.split(source_member)
    return posixpath.join(directory, "_rels", f"{filename}.rels")


def _new_relationships_document() -> tuple[Document, Element]:
    document = minidom.Document()
    root = document.createElementNS(_RELATIONSHIPS_NAMESPACE, "Relationships")
    root.setAttribute("xmlns", _RELATIONSHIPS_NAMESPACE)
    document.appendChild(root)
    return document, root


def _relationship_elements(root: Element) -> tuple[Element, ...]:
    return tuple(
        element
        for element in _direct_elements(root)
        if element.namespaceURI == _RELATIONSHIPS_NAMESPACE
        and element.localName == "Relationship"
    )


def _relationship_kind(element: Element) -> str:
    return element.getAttribute("Type").rsplit("/", 1)[-1].casefold()


def _office_relationship_namespace(worksheet_namespace: str) -> str:
    return (
        _STRICT_OFFICE_RELATIONSHIPS
        if worksheet_namespace.startswith("http://purl.oclc.org/ooxml/")
        else _TRANSITIONAL_OFFICE_RELATIONSHIPS
    )


def _next_relationship_id(used: set[str]) -> str:
    value = 1
    while f"rId{value}" in used:
        value += 1
    result = f"rId{value}"
    used.add(result)
    return result


def _relationship(
    document: Document,
    relationship_id: str,
    relationship_type: str,
    target: str,
    *,
    external: bool = False,
) -> Element:
    element = document.createElementNS(_RELATIONSHIPS_NAMESPACE, "Relationship")
    element.setAttribute("Id", relationship_id)
    element.setAttribute("Type", relationship_type)
    element.setAttribute("Target", target)
    if external:
        element.setAttribute("TargetMode", "External")
    return element


def _insert_worksheet_element(root: Element, element: Element) -> None:
    before = next(
        (
            child
            for child in _direct_elements(root)
            if child.namespaceURI == root.namespaceURI
            and child.localName in _WORKSHEET_TRAILING_ELEMENTS
        ),
        None,
    )
    if before is None:
        root.appendChild(element)
    else:
        root.insertBefore(element, before)


def _fingerprint(value: object) -> str:
    payload = json.dumps(
        value,
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _hyperlink_state(
    worksheet_root: Element,
    relationship_root: Element,
) -> tuple[dict[str, object], ...]:
    relationships = {
        element.getAttribute("Id"): element
        for element in _relationship_elements(relationship_root)
    }
    records: list[dict[str, object]] = []
    for container in _direct_elements(worksheet_root):
        if (
            container.namespaceURI != worksheet_root.namespaceURI
            or container.localName != "hyperlinks"
        ):
            continue
        for element in _direct_elements(container):
            if (
                element.namespaceURI != worksheet_root.namespaceURI
                or element.localName != "hyperlink"
            ):
                continue
            relationship_id = next(
                (
                    str(getattr(attribute, "value", ""))
                    for index in range(element.attributes.length)
                    if (attribute := element.attributes.item(index)) is not None
                    and attribute.localName == "id"
                ),
                None,
            )
            relationship = relationships.get(relationship_id or "")
            records.append(
                {
                    "cell_range": element.getAttribute("ref"),
                    "target": (
                        relationship.getAttribute("Target")
                        if relationship is not None
                        else None
                    ),
                    "location": element.getAttribute("location") or None,
                    "display": element.getAttribute("display") or None,
                    "tooltip": element.getAttribute("tooltip") or None,
                }
            )
    return tuple(records)


def _requested_hyperlink_state(
    links: Sequence[HyperlinkRecordPatch],
) -> tuple[dict[str, object], ...]:
    return tuple(
        {
            "cell_range": link.cell_range,
            "target": link.target,
            "location": link.location,
            "display": link.display,
            "tooltip": link.tooltip,
        }
        for link in links
    )


def _replace_hyperlinks(  # noqa: C901, PLR0913, PLR0917
    worksheet_document: Document,
    worksheet_root: Element,
    worksheet_namespace: str,
    relationship_document: Document,
    relationship_root: Element,
    links: Sequence[HyperlinkRecordPatch],
) -> None:
    for container in tuple(_direct_elements(worksheet_root)):
        if (
            container.namespaceURI == worksheet_namespace
            and container.localName == "hyperlinks"
        ):
            worksheet_root.removeChild(container)
    for element in tuple(_relationship_elements(relationship_root)):
        if _relationship_kind(element) == "hyperlink":
            relationship_root.removeChild(element)
    if not links:
        return
    used = {
        element.getAttribute("Id")
        for element in _relationship_elements(relationship_root)
    }
    office_namespace = _office_relationship_namespace(worksheet_namespace)
    relationship_prefix = namespace_prefix(
        worksheet_root,
        office_namespace,
        "r",
    )
    by_target: dict[str, str] = {}
    for link in links:
        if link.target is None or link.target in by_target:
            continue
        relationship_id = _next_relationship_id(used)
        by_target[link.target] = relationship_id
        relationship_root.appendChild(
            _relationship(
                relationship_document,
                relationship_id,
                f"{office_namespace}/hyperlink",
                link.target,
                external=True,
            )
        )
    container = worksheet_document.createElementNS(
        worksheet_namespace,
        "hyperlinks",
    )
    for link in links:
        element = worksheet_document.createElementNS(
            worksheet_namespace,
            "hyperlink",
        )
        element.setAttribute("ref", link.cell_range)
        for name, value in (
            ("location", link.location),
            ("display", link.display),
            ("tooltip", link.tooltip),
        ):
            if value is not None:
                element.setAttribute(name, value)
        if link.target is not None:
            element.setAttributeNS(
                office_namespace,
                f"{relationship_prefix}:id",
                by_target[link.target],
            )
        container.appendChild(element)
    _insert_worksheet_element(worksheet_root, container)


def _element_text(element: Element) -> str:
    return "".join(
        str(getattr(child, "data", ""))
        for child in element.childNodes
        if child.nodeType in {Node.TEXT_NODE, Node.CDATA_SECTION_NODE}
    )


def _comment_state(payload: bytes) -> tuple[dict[str, str], ...]:
    _document_value, root = _document(
        payload,
        root_namespace := root_namespace_from_payload(payload),
        "comments",
    )
    if root_namespace not in _SPREADSHEETML_WORKSHEET_NAMESPACES:
        msg = "Workbook comments namespace is unsupported"
        raise ValueError(msg)
    authors = tuple(
        _element_text(element)
        for element in root.getElementsByTagNameNS(root_namespace, "author")
    )
    records: list[dict[str, str]] = []
    for comment in root.getElementsByTagNameNS(root_namespace, "comment"):
        try:
            author = authors[int(comment.getAttribute("authorId"))]
        except (IndexError, ValueError):
            msg = "Workbook comment author identity is invalid"
            raise ValueError(msg) from None
        records.append(
            {
                "coordinate": comment.getAttribute("ref"),
                "author": author,
                "text": "".join(
                    _element_text(element)
                    for element in comment.getElementsByTagNameNS(root_namespace, "t")
                ),
            }
        )
    return tuple(records)


def root_namespace_from_payload(payload: bytes) -> str:
    document = minidom.parseString(  # noqa: S318 - bounded, DTD-screened OOXML.
        payload
    )
    namespace = _document_root(document).namespaceURI
    if namespace is None:
        msg = "Workbook comments namespace is missing"
        raise ValueError(msg)
    return namespace


def _requested_comment_state(
    comments: Sequence[LegacyCommentRecordPatch],
) -> tuple[dict[str, str], ...]:
    return tuple(
        {
            "coordinate": comment.coordinate,
            "author": comment.author,
            "text": comment.text,
        }
        for comment in comments
    )


def _comments_payload(
    namespace: str,
    comments: Sequence[LegacyCommentRecordPatch],
) -> bytes:
    document = minidom.Document()
    root = document.createElementNS(namespace, "comments")
    root.setAttribute("xmlns", namespace)
    document.appendChild(root)
    authors_element = document.createElementNS(namespace, "authors")
    root.appendChild(authors_element)
    authors: list[str] = []
    for comment in comments:
        if comment.author not in authors:
            authors.append(comment.author)
            author = document.createElementNS(namespace, "author")
            author.appendChild(document.createTextNode(comment.author))
            authors_element.appendChild(author)
    comment_list = document.createElementNS(namespace, "commentList")
    root.appendChild(comment_list)
    for comment in comments:
        element = document.createElementNS(namespace, "comment")
        element.setAttribute("ref", comment.coordinate)
        element.setAttribute("authorId", str(authors.index(comment.author)))
        text = document.createElementNS(namespace, "text")
        value = document.createElementNS(namespace, "t")
        value.setAttributeNS(_XML_NAMESPACE, "xml:space", "preserve")
        value.appendChild(document.createTextNode(comment.text))
        text.appendChild(value)
        element.appendChild(text)
        comment_list.appendChild(element)
    return _serialize_xml(document)


def _comment_vml_payload(comments: Sequence[LegacyCommentRecordPatch]) -> bytes:
    document = minidom.Document()
    root = document.createElementNS(_VML_NAMESPACE, "xml")
    root.setAttribute("xmlns:v", _VML_NAMESPACE)
    root.setAttribute("xmlns:o", _OFFICE_NAMESPACE)
    root.setAttribute("xmlns:x", _EXCEL_NAMESPACE)
    document.appendChild(root)
    layout = document.createElementNS(_OFFICE_NAMESPACE, "o:shapelayout")
    layout.setAttributeNS(_VML_NAMESPACE, "v:ext", "edit")
    idmap = document.createElementNS(_OFFICE_NAMESPACE, "o:idmap")
    idmap.setAttributeNS(_VML_NAMESPACE, "v:ext", "edit")
    idmap.setAttribute("data", "1")
    layout.appendChild(idmap)
    root.appendChild(layout)
    shape_type = document.createElementNS(_VML_NAMESPACE, "v:shapetype")
    shape_type.setAttribute("id", "_x0000_t202")
    shape_type.setAttribute("coordsize", "21600,21600")
    shape_type.setAttributeNS(_OFFICE_NAMESPACE, "o:spt", "202")
    shape_type.setAttribute("path", "m,l,21600r21600,l21600,xe")
    root.appendChild(shape_type)
    for index, comment in enumerate(comments, start=1):
        bounds = excel_range_bounds(comment.coordinate)
        shape = document.createElementNS(_VML_NAMESPACE, "v:shape")
        shape.setAttribute("id", f"_x0000_s{1024 + index}")
        shape.setAttribute("type", "#_x0000_t202")
        shape.setAttribute("style", "position:absolute;visibility:hidden")
        shape.setAttribute("fillcolor", "#ffffe1")
        shape.setAttributeNS(_OFFICE_NAMESPACE, "o:insetmode", "auto")
        client = document.createElementNS(_EXCEL_NAMESPACE, "x:ClientData")
        client.setAttribute("ObjectType", "Note")
        row = document.createElementNS(_EXCEL_NAMESPACE, "x:Row")
        row.appendChild(document.createTextNode(str(bounds.min_row - 1)))
        column = document.createElementNS(_EXCEL_NAMESPACE, "x:Column")
        column.appendChild(document.createTextNode(str(bounds.min_column - 1)))
        client.appendChild(row)
        client.appendChild(column)
        shape.appendChild(client)
        root.appendChild(shape)
    return document.toxml(encoding="utf-8")


def _reject_noncomment_vml(payload: bytes) -> None:
    document = minidom.parseString(  # noqa: S318 - bounded, DTD-screened OOXML.
        payload
    )
    root = _document_root(document)
    for element in root.getElementsByTagNameNS(_EXCEL_NAMESPACE, "ClientData"):
        if element.getAttribute("ObjectType") != "Note":
            msg = "Workbook VML contains non-comment drawing state"
            raise ExcelModificationError(msg)


def _relative_target(source_member: str, target_member: str) -> str:
    return posixpath.relpath(target_member, posixpath.dirname(source_member))


def _numbered_member(
    names: set[str],
    prefix: str,
    suffix: str,
) -> str:
    number = 1
    while f"{prefix}{number}{suffix}" in names:
        number += 1
    result = f"{prefix}{number}{suffix}"
    names.add(result)
    return result


def _content_types_payload(
    payload: bytes,
    *,
    comment_additions: set[str],
    comment_removals: set[str],
    needs_vml: bool,
) -> bytes:
    document, root = _document(
        payload,
        _CONTENT_TYPES_NAMESPACE,
        "content types",
    )
    for element in tuple(_direct_elements(root)):
        if (
            element.namespaceURI == _CONTENT_TYPES_NAMESPACE
            and element.localName == "Override"
            and element.getAttribute("PartName").lstrip("/") in comment_removals
        ):
            root.removeChild(element)
    existing = {
        element.getAttribute("PartName").lstrip("/")
        for element in _direct_elements(root)
        if element.namespaceURI == _CONTENT_TYPES_NAMESPACE
        and element.localName == "Override"
    }
    for member in sorted(comment_additions - existing):
        element = document.createElementNS(_CONTENT_TYPES_NAMESPACE, "Override")
        element.setAttribute("PartName", f"/{member}")
        element.setAttribute("ContentType", _COMMENTS_CONTENT_TYPE)
        root.appendChild(element)
    if needs_vml and not any(
        element.namespaceURI == _CONTENT_TYPES_NAMESPACE
        and element.localName == "Default"
        and element.getAttribute("Extension").casefold() == "vml"
        for element in _direct_elements(root)
    ):
        element = document.createElementNS(_CONTENT_TYPES_NAMESPACE, "Default")
        element.setAttribute("Extension", "vml")
        element.setAttribute("ContentType", _VML_CONTENT_TYPE)
        root.appendChild(element)
    return _serialize_xml(document)


def _replace_legacy_drawing(
    worksheet_document: Document,
    worksheet_root: Element,
    worksheet_namespace: str,
    office_namespace: str,
    relationship_id: str | None,
) -> None:
    for element in tuple(_direct_elements(worksheet_root)):
        if (
            element.namespaceURI == worksheet_namespace
            and element.localName == "legacyDrawing"
        ):
            worksheet_root.removeChild(element)
    if relationship_id is None:
        return
    prefix = namespace_prefix(worksheet_root, office_namespace, "r")
    element = worksheet_document.createElementNS(
        worksheet_namespace,
        "legacyDrawing",
    )
    element.setAttributeNS(office_namespace, f"{prefix}:id", relationship_id)
    _insert_worksheet_element(worksheet_root, element)


def create_worksheet_annotation_patch_output(  # noqa: C901, PLR0912, PLR0915
    source_path: Path,
    output_path: Path,
    hyperlink_patches: Sequence[WorksheetHyperlinkPatch],
    comment_patches: Sequence[WorksheetLegacyCommentsPatch],
    *,
    source_fingerprint: str,
) -> tuple[
    tuple[_PendingHyperlinkChange, ...],
    tuple[_PendingLegacyCommentChange, ...],
]:
    """Write and verify bounded hyperlink and legacy-comment worksheet graphs."""
    replacements: dict[str, bytes] = {}
    additions: dict[str, bytes] = {}
    removals: set[str] = set()
    hyperlink_pending: list[_PendingHyperlinkChange] = []
    comment_pending: list[_PendingLegacyCommentChange] = []
    comment_additions: set[str] = set()
    comment_removals: set[str] = set()
    with _SafePackage(source_path) as package:
        package.verify_fingerprint(source_fingerprint)
        package.reject_forbidden_xml_declarations()
        _workbook, records = _workbook_records(package)
        by_name = {record.name.casefold(): record for record in records}
        package_names = set(package.names)
        hyperlink_by_sheet = {
            patch.sheet_name.casefold(): patch for patch in hyperlink_patches
        }
        comment_by_sheet = {
            patch.sheet_name.casefold(): patch for patch in comment_patches
        }
        for sheet_key in sorted(set(hyperlink_by_sheet) | set(comment_by_sheet)):
            record = by_name.get(sheet_key)
            if (
                record is None
                or record.sheet_type != "worksheet"
                or record.part_name is None
            ):
                msg = "Workbook worksheet annotation target does not exist"
                raise ExcelModificationError(msg)
            worksheet_member = record.part_name
            worksheet_document, worksheet_root, worksheet_namespace = (
                _worksheet_document(_payload(package, worksheet_member))
            )
            relationships_member = _relationships_member(worksheet_member)
            if package.has(relationships_member):
                relationship_document, relationship_root = _document(
                    _payload(package, relationships_member),
                    _RELATIONSHIPS_NAMESPACE,
                    "worksheet relationships",
                )
            else:
                relationship_document, relationship_root = _new_relationships_document()
            hyperlink_patch = hyperlink_by_sheet.get(sheet_key)
            if hyperlink_patch is not None:
                old_state = _hyperlink_state(worksheet_root, relationship_root)
                new_state = _requested_hyperlink_state(hyperlink_patch.links)
                _replace_hyperlinks(
                    worksheet_document,
                    worksheet_root,
                    worksheet_namespace,
                    relationship_document,
                    relationship_root,
                    hyperlink_patch.links,
                )
                if old_state != new_state:
                    hyperlink_pending.append(
                        _PendingHyperlinkChange(
                            sheet_name=record.name,
                            old_count=len(old_state),
                            new_count=len(new_state),
                            old_fingerprint=_fingerprint(old_state),
                            new_fingerprint=_fingerprint(new_state),
                        )
                    )
            comment_patch = comment_by_sheet.get(sheet_key)
            if comment_patch is not None:
                office_namespace = _office_relationship_namespace(worksheet_namespace)
                relationships = _relationship_elements(relationship_root)
                comment_relationships = tuple(
                    element
                    for element in relationships
                    if _relationship_kind(element) == "comments"
                )
                vml_relationships = tuple(
                    element
                    for element in relationships
                    if _relationship_kind(element) == "vmldrawing"
                )
                if len(comment_relationships) > 1 or len(vml_relationships) > 1:
                    msg = "Workbook legacy comment relationship graph is ambiguous"
                    raise ValueError(msg)
                old_comment_member = (
                    _resolve_target(
                        worksheet_member,
                        comment_relationships[0].getAttribute("Target"),
                    )
                    if comment_relationships
                    else None
                )
                old_vml_member = (
                    _resolve_target(
                        worksheet_member,
                        vml_relationships[0].getAttribute("Target"),
                    )
                    if vml_relationships
                    else None
                )
                old_comment_state = (
                    _comment_state(_payload(package, old_comment_member))
                    if old_comment_member is not None
                    and package.has(old_comment_member)
                    else ()
                )
                new_comment_state = _requested_comment_state(comment_patch.comments)
                if old_vml_member is not None and package.has(old_vml_member):
                    _reject_noncomment_vml(_payload(package, old_vml_member))
                for element in (*comment_relationships, *vml_relationships):
                    relationship_root.removeChild(element)
                if comment_patch.comments:
                    comment_member = old_comment_member or _numbered_member(
                        package_names,
                        "xl/comments",
                        ".xml",
                    )
                    vml_member = old_vml_member or _numbered_member(
                        package_names,
                        "xl/drawings/commentsDrawing",
                        ".vml",
                    )
                    used = {
                        element.getAttribute("Id")
                        for element in _relationship_elements(relationship_root)
                    }
                    comment_id = _next_relationship_id(used)
                    vml_id = _next_relationship_id(used)
                    relationship_root.appendChild(
                        _relationship(
                            relationship_document,
                            comment_id,
                            f"{office_namespace}/comments",
                            _relative_target(worksheet_member, comment_member),
                        )
                    )
                    relationship_root.appendChild(
                        _relationship(
                            relationship_document,
                            vml_id,
                            f"{office_namespace}/vmlDrawing",
                            _relative_target(worksheet_member, vml_member),
                        )
                    )
                    _replace_legacy_drawing(
                        worksheet_document,
                        worksheet_root,
                        worksheet_namespace,
                        office_namespace,
                        vml_id,
                    )
                    comments_payload = _comments_payload(
                        worksheet_namespace,
                        comment_patch.comments,
                    )
                    vml_payload = _comment_vml_payload(comment_patch.comments)
                    target = replacements if package.has(comment_member) else additions
                    target[comment_member] = comments_payload
                    target = replacements if package.has(vml_member) else additions
                    target[vml_member] = vml_payload
                    comment_additions.add(comment_member)
                else:
                    _replace_legacy_drawing(
                        worksheet_document,
                        worksheet_root,
                        worksheet_namespace,
                        office_namespace,
                        None,
                    )
                    for member in (old_comment_member, old_vml_member):
                        if member is not None and package.has(member):
                            removals.add(member)
                    if old_comment_member is not None:
                        comment_removals.add(old_comment_member)
                if old_comment_state != new_comment_state:
                    comment_pending.append(
                        _PendingLegacyCommentChange(
                            sheet_name=record.name,
                            old_count=len(old_comment_state),
                            new_count=len(new_comment_state),
                            old_fingerprint=_fingerprint(old_comment_state),
                            new_fingerprint=_fingerprint(new_comment_state),
                        )
                    )
            replacements[worksheet_member] = _serialize_xml(worksheet_document)
            relationship_payload = _serialize_xml(relationship_document)
            if _relationship_elements(relationship_root):
                target = (
                    replacements if package.has(relationships_member) else additions
                )
                target[relationships_member] = relationship_payload
            elif package.has(relationships_member):
                removals.add(relationships_member)
        if comment_patches:
            replacements[_CONTENT_TYPES_MEMBER] = _content_types_payload(
                _payload(package, _CONTENT_TYPES_MEMBER),
                comment_additions=comment_additions,
                comment_removals=comment_removals,
                needs_vml=any(patch.comments for patch in comment_patches),
            )
    _copy_package(
        source_path,
        output_path,
        replacements,
        additions=additions,
        removals=frozenset(removals),
        source_fingerprint=source_fingerprint,
    )
    return tuple(hyperlink_pending), tuple(comment_pending)

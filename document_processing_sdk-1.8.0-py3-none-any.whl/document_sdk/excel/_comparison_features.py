# ruff: noqa: PLR0913
"""Private worksheet and workbook feature comparison helpers."""

from __future__ import annotations

from typing import TYPE_CHECKING

from document_sdk.excel._comparison_common import (
    _column_selected,
    _DiffCollector,
    _range_selected,
    _source,
)
from document_sdk.excel.models import FeatureDiff

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable, Sequence

    from document_sdk.core import ExcelSourceReference, FileDescriptor
    from document_sdk.core._excel_coordinates import ExcelRangeBounds
    from document_sdk.excel._comparison_package import _WorksheetComparisonState
    from document_sdk.excel._package_types import _SheetRecord
    from document_sdk.excel.models import (
        DefinedNameFeature,
        FeatureState,
        WorksheetFeatureInventory,
    )


def _feature_diff(
    *,
    difference_type: str,
    feature: str,
    old_state: FeatureState = None,
    new_state: FeatureState = None,
    old_source: ExcelSourceReference | None = None,
    new_source: ExcelSourceReference | None = None,
) -> FeatureDiff:
    """Construct one normalized feature difference."""
    return FeatureDiff(
        difference_type=difference_type,
        feature=feature,
        old_state=old_state,
        new_state=new_state,
        old_source=old_source,
        new_source=new_source,
    )


def _add_scalar_feature(
    collector: _DiffCollector,
    *,
    sheet_name: str,
    difference_type: str,
    feature: str,
    old_state: FeatureState,
    new_state: FeatureState,
    old_source: ExcelSourceReference | None,
    new_source: ExcelSourceReference | None,
) -> None:
    """Add one changed scalar worksheet feature."""
    if old_state == new_state:
        return
    collector.add_sheet_feature(
        sheet_name,
        _feature_diff(
            difference_type=difference_type,
            feature=feature,
            old_state=old_state,
            new_state=new_state,
            old_source=old_source,
            new_source=new_source,
        ),
    )


def _add_set_features(
    collector: _DiffCollector,
    *,
    sheet_name: str,
    difference_type: str,
    old_values: Iterable[str | int],
    new_values: Iterable[str | int],
    old_descriptor: FileDescriptor,
    new_descriptor: FileDescriptor,
    coordinate_for: Callable[[str | int], str],
) -> None:
    """Add deterministic presence changes for ranges, rows, or columns."""
    old_set = set(old_values)
    new_set = set(new_values)
    for item in sorted(old_set | new_set, key=str):
        if (item in old_set) == (item in new_set):
            continue
        coordinate = coordinate_for(item)
        collector.add_sheet_feature(
            sheet_name,
            _feature_diff(
                difference_type=difference_type,
                feature=str(item),
                old_state=item in old_set,
                new_state=item in new_set,
                old_source=(
                    _source(old_descriptor, sheet_name, coordinate)
                    if item in old_set
                    else None
                ),
                new_source=(
                    _source(new_descriptor, sheet_name, coordinate)
                    if item in new_set
                    else None
                ),
            ),
        )


def _row_height_map(
    worksheet: WorksheetFeatureInventory,
) -> dict[int, float]:
    return {item.row: item.height for item in worksheet.row_heights}


def _column_width_map(
    worksheet: WorksheetFeatureInventory,
) -> dict[str, float]:
    return {item.column: item.width for item in worksheet.column_widths}


def _add_dimension_features(
    collector: _DiffCollector,
    *,
    sheet_name: str,
    old_worksheet: WorksheetFeatureInventory,
    new_worksheet: WorksheetFeatureInventory,
    old_descriptor: FileDescriptor,
    new_descriptor: FileDescriptor,
    ranges: tuple[ExcelRangeBounds, ...],
) -> None:
    """Compare row heights, column widths, and hidden dimensions."""
    old_rows = _row_height_map(old_worksheet)
    new_rows = _row_height_map(new_worksheet)
    for row in sorted(old_rows.keys() | new_rows.keys()):
        if ranges and not any(item.min_row <= row <= item.max_row for item in ranges):
            continue
        coordinate = f"A{row}"
        _add_scalar_feature(
            collector,
            sheet_name=sheet_name,
            difference_type="row_height",
            feature=str(row),
            old_state=old_rows.get(row),
            new_state=new_rows.get(row),
            old_source=_source(old_descriptor, sheet_name, coordinate),
            new_source=_source(new_descriptor, sheet_name, coordinate),
        )

    old_columns = _column_width_map(old_worksheet)
    new_columns = _column_width_map(new_worksheet)
    for column in sorted(old_columns.keys() | new_columns.keys()):
        coordinate = f"{column}1"
        if not _column_selected(column, ranges):
            continue
        _add_scalar_feature(
            collector,
            sheet_name=sheet_name,
            difference_type="column_width",
            feature=column,
            old_state=old_columns.get(column),
            new_state=new_columns.get(column),
            old_source=_source(old_descriptor, sheet_name, coordinate),
            new_source=_source(new_descriptor, sheet_name, coordinate),
        )

    _add_set_features(
        collector,
        sheet_name=sheet_name,
        difference_type="hidden_row",
        old_values=(
            row
            for row in old_worksheet.hidden_rows
            if not ranges or any(item.min_row <= row <= item.max_row for item in ranges)
        ),
        new_values=(
            row
            for row in new_worksheet.hidden_rows
            if not ranges or any(item.min_row <= row <= item.max_row for item in ranges)
        ),
        old_descriptor=old_descriptor,
        new_descriptor=new_descriptor,
        coordinate_for=lambda item: f"A{item}",
    )
    _add_set_features(
        collector,
        sheet_name=sheet_name,
        difference_type="hidden_column",
        old_values=(
            column
            for column in old_worksheet.hidden_columns
            if _column_selected(column, ranges)
        ),
        new_values=(
            column
            for column in new_worksheet.hidden_columns
            if _column_selected(column, ranges)
        ),
        old_descriptor=old_descriptor,
        new_descriptor=new_descriptor,
        coordinate_for=lambda item: f"{item}1",
    )


def _add_sheet_features(
    collector: _DiffCollector,
    *,
    sheet_name: str,
    old_sheet: _WorksheetComparisonState,
    new_sheet: _WorksheetComparisonState,
    old_descriptor: FileDescriptor,
    new_descriptor: FileDescriptor,
    ranges: tuple[ExcelRangeBounds, ...],
) -> None:
    """Compare supported structural features for one worksheet."""
    old_inventory = old_sheet.inventory
    new_inventory = new_sheet.inventory
    _add_scalar_feature(
        collector,
        sheet_name=sheet_name,
        difference_type="sheet_visibility",
        feature="visibility",
        old_state=old_inventory.visibility,
        new_state=new_inventory.visibility,
        old_source=_source(old_descriptor, sheet_name, "A1"),
        new_source=_source(new_descriptor, sheet_name, "A1"),
    )
    _add_scalar_feature(
        collector,
        sheet_name=sheet_name,
        difference_type="freeze_panes",
        feature="freeze_panes",
        old_state=old_inventory.freeze_panes,
        new_state=new_inventory.freeze_panes,
        old_source=_source(
            old_descriptor,
            sheet_name,
            old_inventory.freeze_panes or "A1",
        ),
        new_source=_source(
            new_descriptor,
            sheet_name,
            new_inventory.freeze_panes or "A1",
        ),
    )

    old_merges = tuple(
        item for item in old_inventory.merged_ranges if _range_selected(item, ranges)
    )
    new_merges = tuple(
        item for item in new_inventory.merged_ranges if _range_selected(item, ranges)
    )
    _add_set_features(
        collector,
        sheet_name=sheet_name,
        difference_type="merged_range",
        old_values=old_merges,
        new_values=new_merges,
        old_descriptor=old_descriptor,
        new_descriptor=new_descriptor,
        coordinate_for=str,
    )
    _add_dimension_features(
        collector,
        sheet_name=sheet_name,
        old_worksheet=old_inventory,
        new_worksheet=new_inventory,
        old_descriptor=old_descriptor,
        new_descriptor=new_descriptor,
        ranges=ranges,
    )

    old_validations = old_sheet.validations
    new_validations = new_sheet.validations
    for reference in sorted(old_validations.keys() | new_validations.keys()):
        _add_scalar_feature(
            collector,
            sheet_name=sheet_name,
            difference_type="data_validation",
            feature=reference,
            old_state=old_validations.get(reference),
            new_state=new_validations.get(reference),
            old_source=(
                _source(old_descriptor, sheet_name, reference)
                if reference in old_validations
                else None
            ),
            new_source=(
                _source(new_descriptor, sheet_name, reference)
                if reference in new_validations
                else None
            ),
        )

    old_tables = old_sheet.tables
    new_tables = new_sheet.tables
    for name in sorted(old_tables.keys() | new_tables.keys()):
        old_state = old_tables.get(name)
        new_state = new_tables.get(name)
        old_range = old_state[1] if old_state is not None else None
        new_range = new_state[1] if new_state is not None else None
        if ranges and not any(
            reference is not None and _range_selected(reference, ranges)
            for reference in (old_range, new_range)
        ):
            continue
        _add_scalar_feature(
            collector,
            sheet_name=sheet_name,
            difference_type="table",
            feature=name,
            old_state=old_state,
            new_state=new_state,
            old_source=(
                None
                if old_range is None
                else _source(old_descriptor, sheet_name, old_range)
            ),
            new_source=(
                None
                if new_range is None
                else _source(new_descriptor, sheet_name, new_range)
            ),
        )


def _defined_name_state(feature: DefinedNameFeature) -> tuple[str, ...]:
    """Return safe, comparable state for one defined name."""
    destinations = tuple(
        f"{item.sheet_name}!{item.cell_range}" for item in feature.destinations
    )
    return (
        feature.kind,
        "external" if feature.external_reference else "internal",
        *destinations,
    )


def _defined_name_map(
    features: Sequence[DefinedNameFeature],
) -> dict[tuple[str, str], DefinedNameFeature]:
    """Index workbook names by scope and exact name."""
    return {(item.scope or "", item.name): item for item in features}


def _add_workbook_features(
    collector: _DiffCollector,
    *,
    old_names: tuple[str, ...],
    new_names: tuple[str, ...],
    old_defined_names: Sequence[DefinedNameFeature],
    new_defined_names: Sequence[DefinedNameFeature],
    old_name_signatures: dict[tuple[str, str], str],
    new_name_signatures: dict[tuple[str, str], str],
) -> None:
    """Compare sheet order and safe defined-name states."""
    if set(old_names) == set(new_names) and old_names != new_names:
        collector.add_workbook_feature(
            _feature_diff(
                difference_type="sheet_order",
                feature="sheet_order",
                old_state=old_names,
                new_state=new_names,
            )
        )

    old_map = _defined_name_map(old_defined_names)
    new_map = _defined_name_map(new_defined_names)
    keys = (
        old_map.keys()
        | new_map.keys()
        | old_name_signatures.keys()
        | new_name_signatures.keys()
    )
    for key in sorted(keys):
        old_feature = old_map.get(key)
        new_feature = new_map.get(key)
        old_signature = old_name_signatures.get(key)
        new_signature = new_name_signatures.get(key)
        old_state = (
            None
            if old_feature is None or old_signature is None
            else (*_defined_name_state(old_feature), old_signature)
        )
        new_state = (
            None
            if new_feature is None or new_signature is None
            else (*_defined_name_state(new_feature), new_signature)
        )
        if old_state == new_state:
            continue
        scope, name = key
        collector.add_workbook_feature(
            _feature_diff(
                difference_type="defined_name",
                feature=f"{scope}:{name}" if scope else name,
                old_state=old_state,
                new_state=new_state,
                old_source=(
                    None
                    if old_feature is None or not old_feature.destinations
                    else old_feature.destinations[0]
                ),
                new_source=(
                    None
                    if new_feature is None or not new_feature.destinations
                    else new_feature.destinations[0]
                ),
            )
        )


def _add_unsupported_sheet_features(
    collector: _DiffCollector,
    *,
    sheet_order: tuple[str, ...],
    old_sheets: Sequence[_SheetRecord],
    new_sheets: Sequence[_SheetRecord],
) -> None:
    """Compare type and visibility for sheets outside the common worksheet path."""
    old_by_name = {sheet.name: sheet for sheet in old_sheets}
    new_by_name = {sheet.name: sheet for sheet in new_sheets}
    for name in sheet_order:
        old_sheet = old_by_name.get(name)
        new_sheet = new_by_name.get(name)
        if old_sheet is None or new_sheet is None:
            continue
        if old_sheet.sheet_type != new_sheet.sheet_type:
            collector.add_workbook_feature(
                _feature_diff(
                    difference_type="sheet_type",
                    feature=name,
                    old_state=old_sheet.sheet_type,
                    new_state=new_sheet.sheet_type,
                )
            )
        if (
            old_sheet.sheet_type != "worksheet" or new_sheet.sheet_type != "worksheet"
        ) and old_sheet.visibility != new_sheet.visibility:
            collector.add_workbook_feature(
                _feature_diff(
                    difference_type="sheet_visibility",
                    feature=name,
                    old_state=old_sheet.visibility,
                    new_state=new_sheet.visibility,
                )
            )

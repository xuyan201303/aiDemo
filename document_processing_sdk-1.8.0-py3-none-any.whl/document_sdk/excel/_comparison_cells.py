# ruff: noqa: PLR0913
"""Private cell-level workbook comparison helpers."""

from __future__ import annotations

from datetime import date, datetime, time
from decimal import Decimal
from typing import TYPE_CHECKING

from document_sdk.core import DocumentProcessingError
from document_sdk.excel._comparison_common import _DiffCollector, _source
from document_sdk.excel.models import CellDiff

if TYPE_CHECKING:
    from document_sdk.core import ExcelTemporalSource, FileDescriptor
    from document_sdk.excel._comparison_package import _WorksheetComparisonState
    from document_sdk.excel._streaming_ooxml import _RawCell
    from document_sdk.excel.models import WorkbookComparisonOptions


type _DiffValue = str | int | float | Decimal | bool | date | datetime | time | None


def _normal_value(
    value: _DiffValue,
    normalization: str,
) -> _DiffValue:
    """Apply the explicitly selected generic string normalization."""
    if not isinstance(value, str):
        return value
    if normalization == "trim":
        return value.strip()
    if normalization == "casefold":
        return value.casefold()
    return value


def _raw_value(record: _RawCell | None) -> _DiffValue:
    """Return an ordinary value, excluding formula caches."""
    return None if record is None or record.formula is not None else record.value


def _formula(record: _RawCell | None) -> str | None:
    """Return formula text when represented."""
    return None if record is None else record.formula


def _cached_value(record: _RawCell | None) -> _DiffValue:
    """Return a formula cache only when OOXML reports one."""
    if record is None or not record.has_cached_value:
        return None
    return record.cached_value


def _temporal_source(
    record: _RawCell | None, origin: str
) -> ExcelTemporalSource | None:
    """Return source facts for the selected ordinary value or formula cache."""
    source = None if record is None else record.temporal_source
    return source if source is not None and source.origin == origin else None


def _data_type(record: _RawCell | None) -> str:
    """Return a stable absent or represented data type."""
    return "<absent>" if record is None else record.data_type


def _style_fingerprint(
    fingerprints: tuple[str, ...],
    record: _RawCell | None,
) -> str:
    """Resolve a represented or absent cell to one package style fingerprint."""
    style_id = 0 if record is None else record.style_id
    if style_id < 0 or style_id >= len(fingerprints):
        msg = "Worksheet references a missing cell style"
        raise DocumentProcessingError(msg)
    return fingerprints[style_id]


def _add_cell_differences(
    collector: _DiffCollector,
    *,
    sheet_name: str,
    coordinate: str,
    old_record: _RawCell | None,
    new_record: _RawCell | None,
    old_sheet: _WorksheetComparisonState,
    new_sheet: _WorksheetComparisonState,
    old_style_fingerprints: tuple[str, ...],
    new_style_fingerprints: tuple[str, ...],
    old_descriptor: FileDescriptor,
    new_descriptor: FileDescriptor,
    options: WorkbookComparisonOptions,
) -> None:
    """Compare all supported cell states in a deterministic order."""
    old_source = (
        None if old_record is None else _source(old_descriptor, sheet_name, coordinate)
    )
    new_source = (
        None if new_record is None else _source(new_descriptor, sheet_name, coordinate)
    )
    old_value = _raw_value(old_record)
    new_value = _raw_value(new_record)
    if _normal_value(old_value, options.value_normalization) != _normal_value(
        new_value, options.value_normalization
    ) or _temporal_source(old_record, "value") != _temporal_source(new_record, "value"):
        collector.add_cell(
            sheet_name,
            CellDiff(
                difference_type="value",
                sheet_name=sheet_name,
                coordinate=coordinate,
                old_value=old_value,
                new_value=new_value,
                old_source=old_source,
                new_source=new_source,
            ),
        )

    old_formula = _formula(old_record)
    new_formula = _formula(new_record)
    formula_metadata_changed = (
        old_formula is not None or new_formula is not None
    ) and (
        (
            None
            if old_record is None
            else (old_record.formula_kind, old_record.external_reference)
        )
        != (
            None
            if new_record is None
            else (new_record.formula_kind, new_record.external_reference)
        )
    )
    if old_formula != new_formula or formula_metadata_changed:
        collector.add_cell(
            sheet_name,
            CellDiff(
                difference_type="formula",
                sheet_name=sheet_name,
                coordinate=coordinate,
                old_value=old_formula,
                new_value=new_formula,
                old_source=old_source,
                new_source=new_source,
            ),
        )

    if not options.ignore_formula_cache:
        old_cache = _cached_value(old_record)
        new_cache = _cached_value(new_record)
        old_has_cache = bool(old_record and old_record.has_cached_value)
        new_has_cache = bool(new_record and new_record.has_cached_value)
        if (
            _normal_value(old_cache, options.value_normalization)
            != _normal_value(new_cache, options.value_normalization)
            or old_has_cache != new_has_cache
            or _temporal_source(old_record, "formula_cache")
            != _temporal_source(new_record, "formula_cache")
        ):
            collector.add_cell(
                sheet_name,
                CellDiff(
                    difference_type="cached_value",
                    sheet_name=sheet_name,
                    coordinate=coordinate,
                    old_value=old_cache,
                    new_value=new_cache,
                    old_source=old_source,
                    new_source=new_source,
                ),
            )

    old_type = _data_type(old_record)
    new_type = _data_type(new_record)
    if old_type != new_type:
        collector.add_cell(
            sheet_name,
            CellDiff(
                difference_type="data_type",
                sheet_name=sheet_name,
                coordinate=coordinate,
                old_value=old_type,
                new_value=new_type,
                old_source=old_source,
                new_source=new_source,
            ),
        )

    if not options.ignore_style:
        old_style = _style_fingerprint(old_style_fingerprints, old_record)
        new_style = _style_fingerprint(new_style_fingerprints, new_record)
        if old_style != new_style:
            collector.add_cell(
                sheet_name,
                CellDiff(
                    difference_type="style",
                    sheet_name=sheet_name,
                    coordinate=coordinate,
                    old_value=old_style,
                    new_value=new_style,
                    old_source=old_source,
                    new_source=new_source,
                ),
            )

    old_link = old_sheet.hyperlinks.get(coordinate)
    new_link = new_sheet.hyperlinks.get(coordinate)
    if old_link != new_link:
        old_link_source = (
            old_source
            if old_source is not None or old_link is None
            else _source(old_descriptor, sheet_name, coordinate)
        )
        new_link_source = (
            new_source
            if new_source is not None or new_link is None
            else _source(new_descriptor, sheet_name, coordinate)
        )
        collector.add_cell(
            sheet_name,
            CellDiff(
                difference_type="hyperlink",
                sheet_name=sheet_name,
                coordinate=coordinate,
                old_value=old_link,
                new_value=new_link,
                old_source=old_link_source,
                new_source=new_link_source,
            ),
        )

    old_comment = old_sheet.comments.get(coordinate)
    new_comment = new_sheet.comments.get(coordinate)
    if old_comment != new_comment:
        old_comment_source = (
            old_source
            if old_source is not None or old_comment is None
            else _source(old_descriptor, sheet_name, coordinate)
        )
        new_comment_source = (
            new_source
            if new_source is not None or new_comment is None
            else _source(new_descriptor, sheet_name, coordinate)
        )
        collector.add_cell(
            sheet_name,
            CellDiff(
                difference_type="comment",
                sheet_name=sheet_name,
                coordinate=coordinate,
                old_value=old_comment,
                new_value=new_comment,
                old_source=old_comment_source,
                new_source=new_comment_source,
            ),
        )

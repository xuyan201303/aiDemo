"""Strict public models for advanced local Excel operations."""

from __future__ import annotations

import re
import unicodedata
from base64 import b64decode
from binascii import Error as Base64Error
from datetime import date, datetime, time
from decimal import Decimal
from hashlib import sha256
from math import isclose, isfinite
from typing import Annotated, Literal, Self
from urllib.parse import urlsplit

from pydantic import (
    AfterValidator,
    Field,
    StringConstraints,
    field_validator,
    model_validator,
)

from document_sdk.core import (  # noqa: TC001 - Pydantic resolves these at runtime.
    ExcelCell,
    ExcelSourceReference,
    FileDescriptor,
)
from document_sdk.core._excel_coordinates import (
    MAX_EXCEL_COLUMN,
    MAX_EXCEL_ROW,
    excel_column_letter,
    excel_range_bounds,
    normalize_excel_coordinate,
    normalize_excel_range,
)
from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.core.models import SdkModel, WorksheetName
from document_sdk.excel._formula_references import (
    formula_has_external_reference,
    is_bounded_external_path,
)

type NonEmptyString = Annotated[
    str,
    StringConstraints(strip_whitespace=True, min_length=1),
]


def _validate_number_format_code(value: str) -> str:
    if not value:
        msg = "Excel number format codes cannot be empty"
        raise ValueError(msg)
    if any(ord(character) < _MIN_PRINTABLE_CODEPOINT for character in value):
        msg = "Excel number format codes cannot contain control characters"
        raise ValueError(msg)
    return value


type ExcelNumberFormatCode = Annotated[
    str,
    StringConstraints(min_length=1),
    AfterValidator(_validate_number_format_code),
]
type ExcelRowNumber = Annotated[int, Field(ge=1, le=MAX_EXCEL_ROW)]
type WorkbookType = Literal["xlsx", "xlsm"]
type SheetVisibility = Literal["visible", "hidden", "veryHidden"]
type FormulaKind = Literal["ordinary", "shared", "array", "dynamic_array"]
type FormulaView = Literal["both", "formula", "cached"]
type ExcelPatchScalar = (
    str | int | float | Decimal | bool | date | datetime | time | None
)
_EXCEL_ERROR_VALUES = frozenset(
    {"#NULL!", "#DIV/0!", "#VALUE!", "#REF!", "#NAME?", "#NUM!", "#N/A"}
)
type FeatureState = (
    str
    | int
    | float
    | bool
    | Decimal
    | date
    | datetime
    | time
    | tuple[str, ...]
    | tuple[int, ...]
    | tuple[float, ...]
    | None
)
MAX_EXCEL_COLUMN_WIDTH = 255.0
MAX_EXCEL_ROW_HEIGHT = 409.5
_RGB_WITHOUT_ALPHA_LENGTH = 6
_MAX_TEXT_ROTATION = 180
_STACKED_TEXT_ROTATION = 255
_MAX_DEFINED_NAME_LENGTH = 255
_MIN_PRINTABLE_CODEPOINT = 32
_MAX_DEFINED_NAME_FORMULA_LENGTH = 8_192
_MAX_WORKSHEET_IMAGE_BYTES = 20_000_000
_MAX_CONDITIONAL_FORMATTING_FORMULA_LENGTH = 8_192
_MAX_DATA_VALIDATION_FORMULA_LENGTH = 8_192
_MAX_DATA_VALIDATION_MESSAGE_LENGTH = 255
_MAX_DATA_VALIDATION_TITLE_LENGTH = 32
_DATA_VALIDATION_REVISION_UID_PATTERN = (
    r"^\{[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-"
    r"[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\}$"
)
_MAX_AUTO_FILTER_VALUE_LENGTH = 32_767


def _normalize_column_name(value: str) -> str:
    """Normalize one bounded Excel column name without a row component."""
    if re.fullmatch(r"[A-Za-z]{1,3}", value) is None:
        msg = "Excel column names must contain letters only"
        raise ValueError(msg)
    bounds = excel_range_bounds(f"{value}1")
    return excel_column_letter(bounds.min_column)


class RowHeightFeature(SdkModel):
    """One explicitly configured worksheet row height."""

    row: ExcelRowNumber
    height: float = Field(gt=0)


class ColumnWidthFeature(SdkModel):
    """One explicitly configured worksheet column width."""

    column: NonEmptyString
    width: float = Field(gt=0)

    @field_validator("column")
    @classmethod
    def validate_column(cls, value: str) -> str:
        """Normalize and bound the worksheet column."""
        return _normalize_column_name(value)


class LocatedWorkbookFeature(SdkModel):
    """A workbook feature with a meaningful worksheet or cell location."""

    feature_type: NonEmptyString
    source: ExcelSourceReference
    details: str | None = None


class ExcelTableFeature(SdkModel):
    """Safe inventory data for one standard Excel table."""

    name: NonEmptyString
    display_name: NonEmptyString
    cell_range: NonEmptyString
    source: ExcelSourceReference

    @field_validator("cell_range")
    @classmethod
    def validate_cell_range(cls, value: str) -> str:
        """Normalize the table range."""
        return normalize_excel_range(value)

    @model_validator(mode="after")
    def validate_source(self) -> Self:
        """Keep table bounds aligned with their source reference."""
        if self.source.cell_range != self.cell_range:
            msg = "Excel table source must match cell_range"
            raise ValueError(msg)
        return self


class DefinedNameFeature(SdkModel):
    """One workbook-defined name without external target details."""

    name: NonEmptyString
    scope: WorksheetName | None = None
    kind: Literal["range", "constant", "formula", "external", "reserved"]
    definition: str | None = None
    destinations: tuple[ExcelSourceReference, ...] = ()
    external_reference: bool = False
    fillable: bool = False

    @field_validator("destinations", mode="before")
    @classmethod
    def accept_json_destinations(cls, value: object) -> object:
        """Accept the JSON destination array emitted by model_dump."""
        return tuple(value) if isinstance(value, list) else value

    @model_validator(mode="after")
    def validate_external_definition(self) -> Self:
        """Prevent an external target from entering serializable output."""
        if (self.kind == "external") != self.external_reference:
            msg = "external defined-name kind and flag must agree"
            raise ValueError(msg)
        if self.external_reference and self.definition is not None:
            msg = "external defined names cannot expose their definition"
            raise ValueError(msg)
        if self.external_reference and self.destinations:
            msg = "external defined names cannot expose destinations"
            raise ValueError(msg)
        if self.fillable and (
            self.external_reference
            or self.kind != "range"
            or len(self.destinations) != 1
        ):
            msg = "fillable names require one internal range destination"
            raise ValueError(msg)
        return self


class UnsupportedSheetFeature(SdkModel):
    """A non-worksheet sheet reported without backend objects."""

    name: WorksheetName
    sheet_type: Literal["chartsheet", "dialog_sheet", "macro_sheet", "unknown"]
    visibility: SheetVisibility


class ChartsheetFeatureInventory(SdkModel):
    """Serializable structural inventory for one non-cell-bearing Chartsheet."""

    name: WorksheetName
    workbook_order: int = Field(ge=1)
    visibility: SheetVisibility
    part_present: bool
    drawing_relationship_count: int = Field(ge=0)
    drawing_part_count: int = Field(ge=0)
    chart_part_count: int = Field(ge=0)
    printer_settings_present: bool
    page_margins_present: bool
    page_setup_present: bool
    header_footer_present: bool
    sheet_protection_present: bool
    external_relationship_count: int = Field(ge=0)


class MacroSheetFeatureInventory(SdkModel):
    """Safe structural inventory for one non-executed Excel 4.0 Macro Sheet."""

    name: WorksheetName
    workbook_order: int = Field(ge=1)
    visibility: SheetVisibility
    part_present: bool
    dimension_reference: str | None = None
    row_count: int = Field(ge=0)
    cell_count: int = Field(ge=0)
    formula_count: int = Field(ge=0)
    value_count: int = Field(ge=0)
    part_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    formula_digest_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    shared_string_reference_count: int = Field(ge=0)
    shared_string_digest_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    non_formula_cell_digest_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    relationship_count: int = Field(ge=0)
    printer_settings_present: bool
    external_relationship_count: int = Field(ge=0)
    defined_name_reference_count: int = Field(ge=0)
    defined_name_digest_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")

    @field_validator("dimension_reference")
    @classmethod
    def validate_dimension_reference(cls, value: str | None) -> str | None:
        """Normalize an optional bounded Macro Sheet dimension."""
        return None if value is None else normalize_excel_range(value)

    @model_validator(mode="after")
    def validate_counts(self) -> Self:
        """Keep public Macro Sheet counts and relationship facts consistent."""
        if self.formula_count > self.cell_count:
            msg = "Macro Sheet formula_count cannot exceed cell_count"
            raise ValueError(msg)
        if self.value_count > self.cell_count:
            msg = "Macro Sheet value_count cannot exceed cell_count"
            raise ValueError(msg)
        if self.shared_string_reference_count > self.cell_count:
            msg = "Macro Sheet shared-string references cannot exceed cell_count"
            raise ValueError(msg)
        if self.external_relationship_count > self.relationship_count:
            msg = "Macro Sheet external relationships cannot exceed relationships"
            raise ValueError(msg)
        if self.printer_settings_present and self.relationship_count == 0:
            msg = "Macro Sheet printer settings require a relationship"
            raise ValueError(msg)
        return self


class WorksheetFeatureInventory(SdkModel):
    """Serializable feature inventory for one worksheet."""

    name: WorksheetName
    visibility: SheetVisibility
    freeze_panes: str | None = None
    merged_ranges: tuple[str, ...] = ()
    row_heights: tuple[RowHeightFeature, ...] = ()
    column_widths: tuple[ColumnWidthFeature, ...] = ()
    print_area: tuple[str, ...] = ()
    print_title_rows: str | None = None
    print_title_columns: str | None = None
    page_orientation: Literal["portrait", "landscape"] | None = None
    hyperlinks: tuple[LocatedWorkbookFeature, ...] = ()
    comments: tuple[LocatedWorkbookFeature, ...] = ()
    data_validations: tuple[LocatedWorkbookFeature, ...] = ()
    conditional_formats: tuple[LocatedWorkbookFeature, ...] = ()
    tables: tuple[ExcelTableFeature, ...] = ()
    formulas: tuple[LocatedWorkbookFeature, ...] = ()
    hidden_rows: tuple[int, ...] = ()
    hidden_columns: tuple[str, ...] = ()
    drawing_count: int = Field(ge=0)
    image_count: int = Field(ge=0)
    chart_count: int = Field(ge=0)
    styled_cell_count: int = Field(ge=0)
    hyperlink_count: int = Field(ge=0)
    comment_count: int = Field(ge=0)
    data_validation_count: int = Field(ge=0)
    conditional_formatting_count: int = Field(ge=0)
    table_count: int = Field(ge=0)
    formula_count: int = Field(ge=0)

    @field_validator(
        "merged_ranges",
        "row_heights",
        "column_widths",
        "print_area",
        "hyperlinks",
        "comments",
        "data_validations",
        "conditional_formats",
        "tables",
        "formulas",
        "hidden_rows",
        "hidden_columns",
        mode="before",
    )
    @classmethod
    def accept_json_arrays(cls, value: object) -> object:
        """Accept JSON arrays emitted by model_dump in dictionary round-trips."""
        return tuple(value) if isinstance(value, list) else value

    @field_validator("freeze_panes")
    @classmethod
    def validate_freeze_panes(cls, value: str | None) -> str | None:
        """Normalize the optional freeze-pane coordinate."""
        return None if value is None else normalize_excel_coordinate(value)

    @field_validator("merged_ranges", "print_area")
    @classmethod
    def validate_ranges(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        """Normalize worksheet feature ranges."""
        return tuple(normalize_excel_range(item) for item in value)

    @field_validator("print_title_rows")
    @classmethod
    def validate_print_title_rows(cls, value: str | None) -> str | None:
        """Normalize and bound an optional whole-row print-title range."""
        if value is None:
            return None
        match = re.fullmatch(r"\$?(\d+):\$?(\d+)", value)
        if match is None:
            msg = "print_title_rows must be a whole-row range"
            raise ValueError(msg)
        start, end = (int(item) for item in match.groups())
        if start < 1 or end > MAX_EXCEL_ROW or start > end:
            msg = "print_title_rows is outside Excel bounds"
            raise ValueError(msg)
        return f"{start}:{end}"

    @field_validator("print_title_columns")
    @classmethod
    def validate_print_title_columns(cls, value: str | None) -> str | None:
        """Normalize and bound an optional whole-column print-title range."""
        if value is None:
            return None
        match = re.fullmatch(r"\$?([A-Za-z]+):\$?([A-Za-z]+)", value)
        if match is None:
            msg = "print_title_columns must be a whole-column range"
            raise ValueError(msg)
        start, end = (_normalize_column_name(item) for item in match.groups())
        if (
            excel_range_bounds(f"{start}1").min_column
            > excel_range_bounds(f"{end}1").min_column
        ):
            msg = "print_title_columns start must not follow its end"
            raise ValueError(msg)
        return f"{start}:{end}"

    @field_validator("hidden_rows")
    @classmethod
    def validate_hidden_rows(cls, value: tuple[int, ...]) -> tuple[int, ...]:
        """Require sorted unique hidden rows inside Excel bounds."""
        if any(row < 1 or row > MAX_EXCEL_ROW for row in value):
            msg = "hidden row is outside Excel bounds"
            raise ValueError(msg)
        normalized = tuple(sorted(set(value)))
        if normalized != value:
            msg = "hidden rows must be sorted and unique"
            raise ValueError(msg)
        return value

    @field_validator("hidden_columns")
    @classmethod
    def validate_hidden_columns(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        """Normalize and require unique hidden columns."""
        normalized = tuple(_normalize_column_name(item) for item in value)
        column_numbers = tuple(
            excel_range_bounds(f"{item}1").min_column for item in normalized
        )
        if len(column_numbers) != len(set(column_numbers)) or column_numbers != tuple(
            sorted(column_numbers)
        ):
            msg = "hidden columns must be sorted and unique"
            raise ValueError(msg)
        return normalized

    @model_validator(mode="after")
    def validate_counts(self) -> Self:
        """Ensure reported counts agree with normalized feature records."""
        pairs = (
            (self.hyperlink_count, len(self.hyperlinks)),
            (self.comment_count, len(self.comments)),
            (self.data_validation_count, len(self.data_validations)),
            (self.conditional_formatting_count, len(self.conditional_formats)),
            (self.table_count, len(self.tables)),
            (self.formula_count, len(self.formulas)),
        )
        if any(reported != actual for reported, actual in pairs):
            msg = "worksheet feature counts must match feature records"
            raise ValueError(msg)
        row_numbers = tuple(item.row for item in self.row_heights)
        column_numbers = tuple(
            excel_range_bounds(f"{item.column}1").min_column
            for item in self.column_widths
        )
        if row_numbers != tuple(sorted(set(row_numbers))):
            msg = "worksheet row heights must be ordered and unique"
            raise ValueError(msg)
        if column_numbers != tuple(sorted(set(column_numbers))):
            msg = "worksheet column widths must be ordered and unique"
            raise ValueError(msg)
        if len(self.merged_ranges) != len(set(self.merged_ranges)):
            msg = "worksheet merged ranges must be unique"
            raise ValueError(msg)
        feature_groups = (
            ("hyperlink", self.hyperlinks),
            ("comment", self.comments),
            ("data_validation", self.data_validations),
            ("conditional_formatting", self.conditional_formats),
            ("formula", self.formulas),
        )
        for expected_type, features in feature_groups:
            if any(
                feature.feature_type != expected_type
                or feature.source.sheet_name != self.name
                for feature in features
            ):
                msg = "worksheet feature sources and types must match inventory"
                raise ValueError(msg)
        if any(table.source.sheet_name != self.name for table in self.tables):
            msg = "worksheet table sources must match inventory"
            raise ValueError(msg)
        return self


class ExcelPackageLimits(SdkModel):
    """Explicit finite OOXML expansion limits for trusted large workbooks."""

    package_members: int = Field(default=10_000, gt=0)
    total_uncompressed_bytes: int = Field(default=512 * 1024 * 1024, gt=0)
    xml_member_bytes: int = Field(default=64 * 1024 * 1024, gt=0)
    compression_ratio: int = Field(default=1_000, gt=0)
    worksheet_feature_records: int = Field(default=100_000, gt=0)
    shared_string_entries: int = Field(default=1_000_000, gt=0)
    semantic_detail_records: int = Field(default=1_000_000, gt=0)
    semantic_detail_text_characters: int = Field(default=64 * 1024 * 1024, gt=0)
    semantic_detail_xml_depth: int = Field(default=256, gt=0)


class WorkbookFeatureInventory(SdkModel):
    """Workbook and worksheet feature facts used for preservation decisions."""

    file: FileDescriptor
    workbook_type: WorkbookType
    sheet_names: tuple[WorksheetName, ...]
    worksheet_count: int = Field(ge=0)
    worksheets: tuple[WorksheetFeatureInventory, ...] = ()
    chartsheet_count: int = Field(default=0, ge=0)
    chartsheets: tuple[ChartsheetFeatureInventory, ...] = ()
    macro_sheet_count: int = Field(default=0, ge=0)
    macro_sheets: tuple[MacroSheetFeatureInventory, ...] = ()
    unsupported_sheets: tuple[UnsupportedSheetFeature, ...] = ()
    defined_names: tuple[DefinedNameFeature, ...] = ()
    external_link_count: int = Field(ge=0)
    calculation_mode: Literal["auto", "autoNoTable", "manual"] | None = None
    vba_project_present: bool
    workbook_protection_present: bool
    active_x_count: int = Field(ge=0)
    unknown_package_parts: tuple[str, ...] = ()

    @field_validator(
        "sheet_names",
        "worksheets",
        "chartsheets",
        "macro_sheets",
        "unsupported_sheets",
        "defined_names",
        "unknown_package_parts",
        mode="before",
    )
    @classmethod
    def accept_json_arrays(cls, value: object) -> object:
        """Accept JSON arrays emitted by model_dump in dictionary round-trips."""
        return tuple(value) if isinstance(value, list) else value

    @model_validator(mode="after")
    def validate_sheets(self) -> Self:  # noqa: C901, PLR0912, PLR0915
        """Ensure ordered sheets and all nested sources remain traceable."""
        if self.worksheet_count != len(self.worksheets):
            msg = "worksheet_count must match worksheet inventories"
            raise ValueError(msg)
        if self.chartsheet_count != len(self.chartsheets):
            msg = "chartsheet_count must match chartsheet inventories"
            raise ValueError(msg)
        if self.macro_sheet_count != len(self.macro_sheets):
            msg = "macro_sheet_count must match Macro Sheet inventories"
            raise ValueError(msg)
        if self.file.extension.casefold() != f".{self.workbook_type}":
            msg = "workbook type must match the file extension"
            raise ValueError(msg)
        normalized_sheet_names = [name.casefold() for name in self.sheet_names]
        if len(normalized_sheet_names) != len(set(normalized_sheet_names)):
            msg = "workbook sheet names must be unique"
            raise ValueError(msg)
        represented = (
            tuple(item.name for item in self.worksheets)
            + tuple(item.name for item in self.chartsheets)
            + tuple(item.name for item in self.macro_sheets)
            + tuple(item.name for item in self.unsupported_sheets)
        )
        normalized_represented = [name.casefold() for name in represented]
        if len(normalized_represented) != len(set(normalized_represented)) or set(
            normalized_represented
        ) != set(normalized_sheet_names):
            msg = "sheet_names must match supported and unsupported sheets"
            raise ValueError(msg)

        positions = {
            name.casefold(): index for index, name in enumerate(self.sheet_names)
        }
        if any(
            self.sheet_names[positions[name.casefold()]] != name for name in represented
        ):
            msg = "sheet inventory names must exactly match sheet_names"
            raise ValueError(msg)
        for group in (
            self.worksheets,
            self.chartsheets,
            self.macro_sheets,
            self.unsupported_sheets,
        ):
            group_positions = tuple(positions[item.name.casefold()] for item in group)
            if group_positions != tuple(sorted(group_positions)):
                msg = "sheet inventory groups must preserve workbook order"
                raise ValueError(msg)
        if any(
            chartsheet.workbook_order != positions[chartsheet.name.casefold()] + 1
            for chartsheet in self.chartsheets
        ):
            msg = "chartsheet workbook_order must match sheet_names"
            raise ValueError(msg)
        if any(
            macro_sheet.workbook_order != positions[macro_sheet.name.casefold()] + 1
            for macro_sheet in self.macro_sheets
        ):
            msg = "Macro Sheet workbook_order must match sheet_names"
            raise ValueError(msg)

        for worksheet in self.worksheets:
            sources = [
                feature.source
                for features in (
                    worksheet.hyperlinks,
                    worksheet.comments,
                    worksheet.data_validations,
                    worksheet.conditional_formats,
                    worksheet.formulas,
                )
                for feature in features
            ] + [table.source for table in worksheet.tables]
            if any(
                source.file_id != self.file.file_id
                or source.sheet_name != worksheet.name
                for source in sources
            ):
                msg = "worksheet feature sources must match workbook identity"
                raise ValueError(msg)

        known_sheets = set(self.sheet_names)
        name_keys: list[tuple[str, str]] = []
        for defined_name in self.defined_names:
            if (
                defined_name.scope is not None
                and defined_name.scope not in known_sheets
            ):
                msg = "defined-name scope must identify a workbook sheet"
                raise ValueError(msg)
            name_keys.append(
                (
                    "" if defined_name.scope is None else defined_name.scope.casefold(),
                    defined_name.name.casefold(),
                )
            )
            if any(
                destination.file_id != self.file.file_id
                or destination.sheet_name not in known_sheets
                for destination in defined_name.destinations
            ):
                msg = "defined-name destinations must match workbook identity"
                raise ValueError(msg)
        if len(name_keys) != len(set(name_keys)):
            msg = "defined names must be unique within each scope"
            raise ValueError(msg)
        return self


class PreservationItem(SdkModel):
    """One deterministic preservation classification."""

    feature: NonEmptyString
    present: bool
    status: Literal["SAFE", "SAFE_WITH_WARNINGS", "UNSUPPORTED"]
    disposition: Literal[
        "guaranteed_preserved",
        "expected_preserved",
        "present_untouched",
        "possible_loss",
        "unsupported",
    ]
    details: NonEmptyString

    @model_validator(mode="after")
    def validate_classification(self) -> Self:
        """Keep status and disposition semantics internally consistent."""
        allowed_dispositions = {
            "SAFE": {"guaranteed_preserved"},
            "SAFE_WITH_WARNINGS": {"expected_preserved", "present_untouched"},
            "UNSUPPORTED": {"possible_loss", "unsupported"},
        }
        if self.disposition not in allowed_dispositions[self.status]:
            msg = "preservation status and disposition are inconsistent"
            raise ValueError(msg)
        if not self.present and (
            self.status != "SAFE" or self.disposition != "guaranteed_preserved"
        ):
            msg = "absent preservation items must be classified as safe"
            raise ValueError(msg)
        return self


class WorkbookPreservationReport(SdkModel):
    """Preservation assessment for a selected workbook operation."""

    file: FileDescriptor
    operation: Literal["patch", "template_fill", "rewrite"]
    overall_status: Literal["SAFE", "SAFE_WITH_WARNINGS", "UNSUPPORTED"]
    items: tuple[PreservationItem, ...] = Field(min_length=1)
    warnings: tuple[NonEmptyString, ...] = ()

    @field_validator("items", "warnings", mode="before")
    @classmethod
    def restore_json_sequences(cls, value: object) -> object:
        """Restore tuple fields from their JSON-compatible list form."""
        return tuple(value) if isinstance(value, list) else value

    @model_validator(mode="after")
    def validate_overall_status(self) -> Self:
        """Ensure the aggregate status matches the present feature items."""
        features = [item.feature.casefold() for item in self.items]
        if len(features) != len(set(features)):
            msg = "preservation features must be unique"
            raise ValueError(msg)
        present_statuses = {item.status for item in self.items if item.present}
        expected = (
            "UNSUPPORTED"
            if "UNSUPPORTED" in present_statuses
            else (
                "SAFE_WITH_WARNINGS"
                if "SAFE_WITH_WARNINGS" in present_statuses
                else "SAFE"
            )
        )
        if self.overall_status != expected:
            msg = "overall preservation status must match present feature items"
            raise ValueError(msg)
        return self


class CellPatchValue(SdkModel):
    """Explicit value, formula, or clear operation for a cell."""

    kind: Literal["value", "error", "formula", "array_formula", "clear"]
    value: ExcelPatchScalar = None
    number_format: ExcelNumberFormatCode | None = None
    formula_range: str | None = None
    clear_existing_cells: tuple[NonEmptyString, ...] = ()

    @field_validator("clear_existing_cells", mode="before")
    @classmethod
    def restore_clear_existing_cells(cls, value: object) -> object:
        """Restore explicit array-range clear targets from JSON arrays."""
        return tuple(value) if isinstance(value, list) else value

    @field_validator("clear_existing_cells")
    @classmethod
    def validate_clear_existing_cells(
        cls,
        value: tuple[str, ...],
    ) -> tuple[str, ...]:
        """Normalize and deduplicate explicit occupied array-range cells."""
        normalized = tuple(normalize_excel_coordinate(item) for item in value)
        if len(normalized) != len(set(normalized)):
            msg = "array formula clear targets must be unique"
            raise ValueError(msg)
        return normalized

    @field_validator("formula_range")
    @classmethod
    def validate_formula_range(cls, value: str | None) -> str | None:
        """Normalize an optional bounded array-formula range."""
        return None if value is None else normalize_excel_range(value)

    @model_validator(mode="after")
    def validate_kind(self) -> Self:
        """Keep formulas and explicit clearing unambiguous."""
        if self.kind == "clear" and (
            self.value is not None
            or self.number_format is not None
            or self.formula_range is not None
            or self.clear_existing_cells
        ):
            msg = "clear values cannot include content or a number format"
            raise ValueError(msg)
        if self.kind == "value" and self.value is None:
            msg = "value patches require a non-null value; use clear instead"
            raise ValueError(msg)
        if self.kind == "error" and (
            not isinstance(self.value, str) or self.value not in _EXCEL_ERROR_VALUES
        ):
            msg = "error patches require a supported Excel error value"
            raise ValueError(msg)
        if self.kind in {"formula", "array_formula"} and (
            not isinstance(self.value, str) or not self.value.startswith("=")
        ):
            msg = "formula patches require a string starting with '='"
            raise ValueError(msg)
        if self.kind == "array_formula" and self.formula_range is None:
            msg = "array formula patches require formula_range"
            raise ValueError(msg)
        if self.kind != "array_formula" and self.formula_range is not None:
            msg = "formula_range is valid only for array formula patches"
            raise ValueError(msg)
        if self.kind != "array_formula" and self.clear_existing_cells:
            msg = "clear_existing_cells is valid only for array formula patches"
            raise ValueError(msg)
        return self


class CellPatch(SdkModel):
    """One addressed worksheet patch."""

    sheet_name: WorksheetName
    coordinate: NonEmptyString
    content: CellPatchValue

    @field_validator("coordinate")
    @classmethod
    def validate_coordinate(cls, value: str) -> str:
        """Normalize one patch coordinate."""
        return normalize_excel_coordinate(value)

    @model_validator(mode="after")
    def validate_array_anchor(self) -> Self:
        """Require an array formula patch to address its range's top-left cell."""
        if self.content.formula_range is None:
            return self
        bounds = excel_range_bounds(self.content.formula_range)
        expected = f"{excel_column_letter(bounds.min_column)}{bounds.min_row}"
        if self.coordinate != expected:
            msg = "array formula patch coordinate must be formula_range top-left"
            raise ValueError(msg)
        for coordinate in self.content.clear_existing_cells:
            target = excel_range_bounds(coordinate)
            if (
                coordinate == self.coordinate
                or target.min_column < bounds.min_column
                or target.max_column > bounds.max_column
                or target.min_row < bounds.min_row
                or target.max_row > bounds.max_row
            ):
                msg = "array formula clear targets must be non-anchor range members"
                raise ValueError(msg)
        return self


class CellStyleColor(SdkModel):
    """One explicit OOXML-compatible cell-style color."""

    rgb: str | None = None
    indexed: int | None = Field(default=None, ge=0, le=65)
    theme: int | None = Field(default=None, ge=0)
    auto: bool | None = None
    tint: float = Field(default=0.0, ge=-1.0, le=1.0)

    @field_validator("rgb")
    @classmethod
    def validate_rgb(cls, value: str | None) -> str | None:
        """Normalize six- or eight-digit ARGB color text."""
        if value is None:
            return None
        normalized = value.upper()
        if re.fullmatch(r"[0-9A-F]{6}(?:[0-9A-F]{2})?", normalized) is None:
            msg = "cell style rgb colors must contain six or eight hex digits"
            raise ValueError(msg)
        return (
            f"FF{normalized}"
            if len(normalized) == _RGB_WITHOUT_ALPHA_LENGTH
            else normalized
        )

    @model_validator(mode="after")
    def validate_identity(self) -> Self:
        """Require exactly one color identity representation."""
        supplied = sum(
            value is not None
            for value in (self.rgb, self.indexed, self.theme, self.auto)
        )
        if supplied != 1:
            msg = "cell style colors require exactly one identity"
            raise ValueError(msg)
        return self


class CellFontPatch(SdkModel):
    """A complete font component for one cell format."""

    name: str | None = None
    size: float | None = Field(default=None, gt=0, le=409.0)
    bold: bool | None = None
    italic: bool | None = None
    underline: (
        Literal["single", "double", "singleAccounting", "doubleAccounting"] | None
    ) = None
    strike: bool | None = None
    color: CellStyleColor | None = None
    vert_align: Literal["baseline", "superscript", "subscript"] | None = None
    charset: int | None = Field(default=None, ge=0, le=255)
    family: float | None = Field(default=None, ge=0, le=14)
    scheme: Literal["major", "minor"] | None = None
    outline: bool | None = None
    shadow: bool | None = None
    condense: bool | None = None
    extend: bool | None = None


class CellPatternFillPatch(SdkModel):
    """A complete pattern-fill component for one cell format."""

    pattern_type: (
        Literal[
            "none",
            "solid",
            "darkDown",
            "darkGray",
            "darkGrid",
            "darkHorizontal",
            "darkTrellis",
            "darkUp",
            "darkVertical",
            "gray0625",
            "gray125",
            "lightDown",
            "lightGray",
            "lightGrid",
            "lightHorizontal",
            "lightTrellis",
            "lightUp",
            "lightVertical",
            "mediumGray",
        ]
        | None
    ) = None
    foreground_color: CellStyleColor | None = None
    background_color: CellStyleColor | None = None


class CellGradientStopPatch(SdkModel):
    """One ordered color stop in a complete gradient fill."""

    position: float = Field(ge=0.0, le=1.0)
    color: CellStyleColor


class CellGradientFillPatch(SdkModel):
    """A complete linear or path gradient-fill component."""

    fill_type: Literal["linear", "path"] = "linear"
    degree: float = 0.0
    left: float = Field(default=0.0, ge=0.0, le=1.0)
    right: float = Field(default=0.0, ge=0.0, le=1.0)
    top: float = Field(default=0.0, ge=0.0, le=1.0)
    bottom: float = Field(default=0.0, ge=0.0, le=1.0)
    stops: tuple[CellGradientStopPatch, ...] = Field(min_length=2, max_length=64)

    @field_validator("stops", mode="before")
    @classmethod
    def restore_stops(cls, value: object) -> object:
        """Restore the immutable stop sequence from JSON arrays."""
        return tuple(value) if isinstance(value, list) else value

    @model_validator(mode="after")
    def validate_gradient(self) -> Self:
        """Require finite, ordered stops and type-appropriate geometry."""
        if not isfinite(self.degree):
            msg = "cell gradient fill degree must be finite"
            raise ValueError(msg)
        positions = tuple(stop.position for stop in self.stops)
        if positions != tuple(sorted(positions)) or len(positions) != len(
            set(positions)
        ):
            msg = "cell gradient fill stops must be strictly ordered"
            raise ValueError(msg)
        if self.fill_type == "linear" and any(
            value != 0.0 for value in (self.left, self.right, self.top, self.bottom)
        ):
            msg = "linear gradient fills cannot include path extents"
            raise ValueError(msg)
        if self.fill_type == "path" and self.degree != 0.0:
            msg = "path gradient fills cannot include a degree"
            raise ValueError(msg)
        return self


class CellBorderSidePatch(SdkModel):
    """One complete side of a cell border."""

    style: (
        Literal[
            "dashDot",
            "dashDotDot",
            "dashed",
            "dotted",
            "double",
            "hair",
            "medium",
            "mediumDashDot",
            "mediumDashDotDot",
            "mediumDashed",
            "slantDashDot",
            "thick",
            "thin",
        ]
        | None
    ) = None
    color: CellStyleColor | None = None


class CellBorderPatch(SdkModel):
    """A complete border component for one cell format."""

    left: CellBorderSidePatch | None = None
    right: CellBorderSidePatch | None = None
    top: CellBorderSidePatch | None = None
    bottom: CellBorderSidePatch | None = None
    diagonal: CellBorderSidePatch | None = None
    vertical: CellBorderSidePatch | None = None
    horizontal: CellBorderSidePatch | None = None
    start: CellBorderSidePatch | None = None
    end: CellBorderSidePatch | None = None
    diagonal_up: bool | None = None
    diagonal_down: bool | None = None
    outline: bool | None = None


class CellAlignmentPatch(SdkModel):
    """A complete alignment component for one cell format."""

    horizontal: (
        Literal[
            "general",
            "left",
            "center",
            "right",
            "fill",
            "justify",
            "centerContinuous",
            "distributed",
        ]
        | None
    ) = None
    vertical: Literal["top", "center", "bottom", "justify", "distributed"] | None = None
    text_rotation: int | None = None
    wrap_text: bool | None = None
    shrink_to_fit: bool | None = None
    indent: int | None = Field(default=None, ge=0, le=250)
    relative_indent: int | None = Field(default=None, ge=-15, le=15)
    justify_last_line: bool | None = None
    reading_order: int | None = Field(default=None, ge=0, le=2)

    @field_validator("text_rotation")
    @classmethod
    def validate_rotation(cls, value: int | None) -> int | None:
        """Accept Excel's ordinary rotations plus stacked-text marker 255."""
        if (
            value is not None
            and value != _STACKED_TEXT_ROTATION
            and not 0 <= value <= _MAX_TEXT_ROTATION
        ):
            msg = "cell alignment text rotation is outside Excel bounds"
            raise ValueError(msg)
        return value


class CellFormatPatch(SdkModel):
    """One addressed cell-format patch with explicit complete components."""

    sheet_name: WorksheetName
    coordinate: NonEmptyString
    font: CellFontPatch | None = None
    fill: CellPatternFillPatch | None = None
    border: CellBorderPatch | None = None
    alignment: CellAlignmentPatch | None = None
    number_format: ExcelNumberFormatCode | None = None
    named_style: NonEmptyString | None = None
    quote_prefix: bool | None = None
    pivot_button: bool | None = None

    @field_validator("coordinate")
    @classmethod
    def validate_coordinate(cls, value: str) -> str:
        """Normalize one format target coordinate."""
        return normalize_excel_coordinate(value)

    @model_validator(mode="after")
    def validate_components(self) -> Self:
        """Reject format requests without an explicit component."""
        if all(
            component is None
            for component in (
                self.font,
                self.fill,
                self.border,
                self.alignment,
                self.number_format,
                self.named_style,
                self.quote_prefix,
                self.pivot_button,
            )
        ):
            msg = "cell format patches require at least one component"
            raise ValueError(msg)
        return self


class ExistingCellFormatRangePatch(SdkModel):
    """Apply complete format components only to existing cells in bounded ranges."""

    sheet_name: WorksheetName
    cell_ranges: tuple[NonEmptyString, ...] = Field(min_length=1, max_length=100_000)
    font: CellFontPatch | None = None
    fill: CellPatternFillPatch | None = None
    border: CellBorderPatch | None = None
    alignment: CellAlignmentPatch | None = None
    number_format: ExcelNumberFormatCode | None = None
    named_style: NonEmptyString | None = None
    quote_prefix: bool | None = None
    pivot_button: bool | None = None

    @field_validator("cell_ranges", mode="before")
    @classmethod
    def restore_ranges(cls, value: object) -> object:
        """Restore target ranges from JSON arrays."""
        return tuple(value) if isinstance(value, list) else value

    @field_validator("cell_ranges")
    @classmethod
    def validate_ranges(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        """Normalize and require non-overlapping bounded target ranges."""
        normalized = tuple(normalize_excel_range(item) for item in value)
        if len(normalized) != len(set(normalized)):
            msg = "existing-cell format ranges must be unique"
            raise ValueError(msg)
        bounds = [excel_range_bounds(item) for item in normalized]
        for index, current in enumerate(bounds):
            if any(
                current.min_column <= other.max_column
                and current.max_column >= other.min_column
                and current.min_row <= other.max_row
                and current.max_row >= other.min_row
                for other in bounds[:index]
            ):
                msg = "existing-cell format ranges must not overlap"
                raise ValueError(msg)
        return normalized

    @model_validator(mode="after")
    def validate_components(self) -> Self:
        """Reject range format requests without an explicit component."""
        if all(
            component is None
            for component in (
                self.font,
                self.fill,
                self.border,
                self.alignment,
                self.number_format,
                self.named_style,
                self.quote_prefix,
                self.pivot_button,
            )
        ):
            msg = "existing-cell format range patches require a component"
            raise ValueError(msg)
        return self


class WorkbookDefaultStylePatch(SdkModel):
    """Complete format components for the workbook default cell style."""

    font: CellFontPatch | None = None
    fill: CellPatternFillPatch | None = None
    border: CellBorderPatch | None = None
    alignment: CellAlignmentPatch | None = None
    number_format: ExcelNumberFormatCode | None = None
    named_style: NonEmptyString | None = None

    @model_validator(mode="after")
    def validate_components(self) -> Self:
        """Reject default-style requests without an explicit component."""
        if all(
            component is None
            for component in (
                self.font,
                self.fill,
                self.border,
                self.alignment,
                self.number_format,
                self.named_style,
            )
        ):
            msg = "workbook default style patches require at least one component"
            raise ValueError(msg)
        return self


class WorksheetCreatePatch(SdkModel):
    """One explicitly positioned worksheet creation request."""

    name: WorksheetName
    index: int = Field(ge=0, le=9_999)
    visibility: SheetVisibility = "visible"


class WorksheetDeletePatch(SdkModel):
    """Delete one existing worksheet and its owned package graph."""

    name: WorksheetName


class WorksheetStructuralInsertionPatch(SdkModel):
    """Insert bounded rows or columns before one worksheet position."""

    sheet_name: WorksheetName
    axis: Literal["row", "column"]
    before: int = Field(ge=1, le=MAX_EXCEL_ROW)
    count: int = Field(ge=1, le=1_000)

    @model_validator(mode="after")
    def validate_axis_bound(self) -> Self:
        """Apply Excel's narrower column bound to column insertions."""
        maximum = MAX_EXCEL_COLUMN if self.axis == "column" else MAX_EXCEL_ROW
        if self.before > maximum or self.before + self.count - 1 > maximum:
            msg = "worksheet structural insertion is outside Excel bounds"
            raise ValueError(msg)
        return self


class WorksheetDrawingRemovalPatch(SdkModel):
    """Remove all drawing objects owned by one worksheet."""

    sheet_name: WorksheetName


class DrawingMarkerPatch(SdkModel):
    """One zero-based DrawingML worksheet anchor marker."""

    column: int = Field(ge=0, lt=MAX_EXCEL_COLUMN)
    column_offset: int = Field(default=0, ge=0, le=2_147_483_647)
    row: int = Field(ge=0, lt=MAX_EXCEL_ROW)
    row_offset: int = Field(default=0, ge=0, le=2_147_483_647)


class WorksheetImagePatch(SdkModel):
    """Add one bounded image at an explicit two-cell worksheet anchor."""

    sheet_name: WorksheetName
    content_type: Literal["image/png", "image/jpeg", "image/gif"]
    data_base64: str = Field(min_length=4, max_length=28_000_000)
    sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    from_marker: DrawingMarkerPatch
    to_marker: DrawingMarkerPatch
    name: NonEmptyString = "Picture"

    @model_validator(mode="after")
    def validate_image(self) -> Self:
        """Verify bounded decoded content, identity, format, and anchor order."""
        try:
            payload = b64decode(self.data_base64, validate=True)
        except (Base64Error, ValueError):
            msg = "worksheet image payload is invalid"
            raise ValueError(msg) from None
        if not payload or len(payload) > _MAX_WORKSHEET_IMAGE_BYTES:
            msg = "worksheet image payload is outside configured bounds"
            raise ValueError(msg)
        signatures = {
            "image/png": b"\x89PNG\r\n\x1a\n",
            "image/jpeg": b"\xff\xd8\xff",
            "image/gif": b"GIF",
        }
        if not payload.startswith(signatures[self.content_type]):
            msg = "worksheet image payload does not match its content type"
            raise ValueError(msg)
        if sha256(payload).hexdigest() != self.sha256:
            msg = "worksheet image payload fingerprint does not match"
            raise ValueError(msg)
        if (self.to_marker.row, self.to_marker.column) < (
            self.from_marker.row,
            self.from_marker.column,
        ):
            msg = "worksheet image anchor markers must be ordered"
            raise ValueError(msg)
        return self


class ExternalLinkRemovalPatch(SdkModel):
    """Remove one one-based external-link identity and compact later indexes."""

    link_index: int = Field(ge=1, le=10_000)


class WorkbookSheetOrderPatch(SdkModel):
    """A complete ordering of every existing workbook sheet."""

    sheet_names: tuple[WorksheetName, ...] = Field(min_length=1, max_length=10_000)

    @field_validator("sheet_names", mode="before")
    @classmethod
    def restore_sheet_names(cls, value: object) -> object:
        """Restore the ordered tuple from a JSON array."""
        return tuple(value) if isinstance(value, list) else value

    @model_validator(mode="after")
    def validate_names(self) -> Self:
        """Reject case-insensitive duplicate sheet identities."""
        identities = [name.casefold() for name in self.sheet_names]
        if len(identities) != len(set(identities)):
            msg = "workbook sheet order names must be unique"
            raise ValueError(msg)
        return self


class FreezePanePatch(SdkModel):
    """Set or clear the frozen-pane anchor for one worksheet."""

    sheet_name: WorksheetName
    coordinate: NonEmptyString | None = None

    @field_validator("coordinate")
    @classmethod
    def validate_coordinate(cls, value: str | None) -> str | None:
        """Normalize a non-default pane anchor; ``None`` explicitly clears it."""
        if value is None:
            return None
        normalized = normalize_excel_coordinate(value)
        if normalized == "A1":
            msg = "freeze pane coordinates must be below or right of A1"
            raise ValueError(msg)
        return normalized


class AutoFilterValueListPatch(SdkModel):
    """One value-list filter for a zero-based column inside a filter range."""

    column_id: int = Field(ge=0, lt=MAX_EXCEL_COLUMN)
    values: tuple[NonEmptyString, ...] = Field(default=(), max_length=10_000)
    include_blank: bool = False
    hidden_button: bool = False
    show_button: bool = True

    @field_validator("values", mode="before")
    @classmethod
    def restore_values(cls, value: object) -> object:
        """Restore value tuples from JSON arrays."""
        return tuple(value) if isinstance(value, list) else value

    @model_validator(mode="after")
    def validate_values(self) -> Self:
        """Require at least one selected value or the blank option."""
        if not self.values and not self.include_blank:
            msg = "auto filter value lists cannot be empty"
            raise ValueError(msg)
        if len(self.values) != len(set(self.values)):
            msg = "auto filter values must be unique"
            raise ValueError(msg)
        return self


class AutoFilterCustomCriterionPatch(SdkModel):
    """One explicit custom-filter comparison value."""

    operator: Literal[
        "equal",
        "notEqual",
        "lessThan",
        "lessThanOrEqual",
        "greaterThan",
        "greaterThanOrEqual",
    ] = "equal"
    value: str = Field(min_length=1, max_length=_MAX_AUTO_FILTER_VALUE_LENGTH)


class AutoFilterCustomPatch(SdkModel):
    """One one- or two-condition custom filter column."""

    column_id: int = Field(ge=0, lt=MAX_EXCEL_COLUMN)
    criteria: tuple[AutoFilterCustomCriterionPatch, ...] = Field(
        min_length=1,
        max_length=2,
    )
    and_operator: bool = False
    hidden_button: bool = False
    show_button: bool = True

    @field_validator("criteria", mode="before")
    @classmethod
    def restore_criteria(cls, value: object) -> object:
        """Restore criterion tuples from JSON arrays."""
        return tuple(value) if isinstance(value, list) else value


class AutoFilterColorPatch(SdkModel):
    """One differential-format color filter column."""

    column_id: int = Field(ge=0, lt=MAX_EXCEL_COLUMN)
    differential_format_id: int = Field(ge=0, le=100_000)
    cell_color: bool | None = None
    hidden_button: bool = False
    show_button: bool = True


class AutoFilterSortConditionPatch(SdkModel):
    """One ordinary value-sort condition inside an automatic-filter range."""

    cell_range: NonEmptyString
    descending: bool = False

    @field_validator("cell_range")
    @classmethod
    def validate_range(cls, value: str) -> str:
        """Normalize the sorted cell range."""
        return normalize_excel_range(value)


class AutoFilterPatch(SdkModel):
    """Set, replace, or clear one worksheet's standard automatic filter."""

    sheet_name: WorksheetName
    cell_range: NonEmptyString | None = None
    value_filters: tuple[AutoFilterValueListPatch, ...] = Field(
        default=(),
        max_length=MAX_EXCEL_COLUMN,
    )
    custom_filters: tuple[AutoFilterCustomPatch, ...] = Field(
        default=(),
        max_length=MAX_EXCEL_COLUMN,
    )
    color_filters: tuple[AutoFilterColorPatch, ...] = Field(
        default=(),
        max_length=MAX_EXCEL_COLUMN,
    )
    sort_range: str | None = None
    sort_conditions: tuple[AutoFilterSortConditionPatch, ...] = Field(
        default=(),
        max_length=MAX_EXCEL_COLUMN,
    )
    revision_uid: str | None = Field(
        default=None,
        pattern=_DATA_VALIDATION_REVISION_UID_PATTERN,
    )
    extension_list: Literal["absent", "empty"] = "absent"

    @field_validator(
        "value_filters",
        "custom_filters",
        "color_filters",
        "sort_conditions",
        mode="before",
    )
    @classmethod
    def restore_sequences(cls, value: object) -> object:
        """Restore filter and sort tuples from JSON arrays."""
        return tuple(value) if isinstance(value, list) else value

    @field_validator("cell_range", "sort_range")
    @classmethod
    def validate_range(cls, value: str | None) -> str | None:
        """Normalize the optional filter range."""
        return None if value is None else normalize_excel_range(value)

    @model_validator(mode="after")
    def validate_filter(self) -> Self:
        """Bind criteria and sort conditions to one bounded filter range."""
        if self.cell_range is None:
            if (
                self.value_filters
                or self.custom_filters
                or self.color_filters
                or self.sort_range
                or self.sort_conditions
                or self.revision_uid is not None
                or self.extension_list != "absent"
            ):
                msg = "cleared auto filters cannot include criteria or sort state"
                raise ValueError(msg)
            return self
        bounds = excel_range_bounds(self.cell_range)
        width = bounds.max_column - bounds.min_column + 1
        column_ids = [
            item.column_id
            for group in (self.value_filters, self.custom_filters, self.color_filters)
            for item in group
        ]
        if any(column_id >= width for column_id in column_ids):
            msg = "auto filter column is outside the filter range"
            raise ValueError(msg)
        if len(column_ids) != len(set(column_ids)):
            msg = "auto filter columns must be unique"
            raise ValueError(msg)
        if bool(self.sort_range) != bool(self.sort_conditions):
            msg = "auto filter sort range and conditions must be supplied together"
            raise ValueError(msg)
        return self


class MergedRangePatch(SdkModel):
    """Merge or unmerge one bounded worksheet range."""

    sheet_name: WorksheetName
    cell_range: NonEmptyString
    operation: Literal["merge", "unmerge"]

    @field_validator("cell_range")
    @classmethod
    def validate_range(cls, value: str) -> str:
        """Normalize a non-singleton rectangular merge range."""
        normalized = normalize_excel_range(value)
        bounds = excel_range_bounds(normalized)
        if bounds.min_row == bounds.max_row and bounds.min_column == bounds.max_column:
            msg = "merged range patches require at least two cells"
            raise ValueError(msg)
        return normalized


class TableColumnPatch(SdkModel):
    """One ordered table-column identity in a structural table patch."""

    column_id: int = Field(ge=1, le=MAX_EXCEL_COLUMN)
    name: NonEmptyString
    totals_row_function: (
        Literal[
            "average",
            "count",
            "countNums",
            "custom",
            "max",
            "min",
            "none",
            "stdDev",
            "sum",
            "var",
        ]
        | None
    ) = None


class TableRangePatch(SdkModel):
    """Resize one existing table and optionally replace its column identities."""

    sheet_name: WorksheetName
    table_name: NonEmptyString
    cell_range: NonEmptyString
    columns: tuple[TableColumnPatch, ...] | None = Field(
        default=None,
        max_length=MAX_EXCEL_COLUMN,
    )

    @field_validator("columns", mode="before")
    @classmethod
    def restore_columns(cls, value: object) -> object:
        """Restore an optional ordered column tuple from JSON arrays."""
        return tuple(value) if isinstance(value, list) else value

    @field_validator("cell_range")
    @classmethod
    def validate_range(cls, value: str) -> str:
        """Normalize one bounded table range."""
        return normalize_excel_range(value)

    @model_validator(mode="after")
    def validate_columns(self) -> Self:
        """Bind unique column records to the requested table width."""
        if self.columns is None:
            return self
        width = (
            excel_range_bounds(self.cell_range).max_column
            - excel_range_bounds(self.cell_range).min_column
            + 1
        )
        if len(self.columns) != width:
            msg = "table column patches must match the requested table width"
            raise ValueError(msg)
        ids = [column.column_id for column in self.columns]
        names = [column.name.casefold() for column in self.columns]
        if len(ids) != len(set(ids)) or len(names) != len(set(names)):
            msg = "table column identities and names must be unique"
            raise ValueError(msg)
        return self


class HyperlinkRecordPatch(SdkModel):
    """One complete internal or safely-schemed external worksheet hyperlink."""

    cell_range: NonEmptyString
    target: str | None = Field(default=None, max_length=8_192)
    location: str | None = Field(default=None, max_length=8_192)
    display: str | None = Field(default=None, max_length=32_767)
    tooltip: str | None = Field(default=None, max_length=32_767)

    @field_validator("cell_range")
    @classmethod
    def validate_range(cls, value: str) -> str:
        """Normalize the hyperlink's bounded worksheet range."""
        return normalize_excel_range(value)

    @model_validator(mode="after")
    def validate_destination(self) -> Self:
        """Require exactly one safe internal or external destination."""
        if (self.target is None) == (self.location is None):
            msg = "hyperlinks require exactly one target or internal location"
            raise ValueError(msg)
        if self.target is not None:
            if self.target != self.target.strip() or not self.target:
                msg = "external hyperlink target is invalid"
                raise ValueError(msg)
            parsed = urlsplit(self.target)
            scheme = parsed.scheme.casefold()
            drive_path = re.match(r"^[A-Za-z]:[\\/]", self.target) is not None
            path_target = drive_path or (
                not scheme
                and not self.target.startswith("#")
                and (
                    is_bounded_external_path(self.target)
                    or all(character not in {":", "!"} for character in self.target)
                )
            )
            if scheme not in {"http", "https", "mailto", "file"} and not path_target:
                msg = "external hyperlink scheme is unsupported"
                raise ValueError(msg)
            if scheme in {"http", "https"} and not parsed.netloc:
                msg = "external hyperlink target is invalid"
                raise ValueError(msg)
            if scheme == "file" and not (parsed.netloc or parsed.path):
                msg = "external hyperlink target is invalid"
                raise ValueError(msg)
            if any(
                ord(character) < _MIN_PRINTABLE_CODEPOINT for character in self.target
            ):
                msg = "external hyperlink target is invalid"
                raise ValueError(msg)
        elif self.location is not None and any(
            ord(character) < _MIN_PRINTABLE_CODEPOINT for character in self.location
        ):
            msg = "internal hyperlink location is invalid"
            raise ValueError(msg)
        return self


class WorksheetHyperlinkPatch(SdkModel):
    """Explicit full replacement of one worksheet's hyperlink set."""

    sheet_name: WorksheetName
    links: tuple[HyperlinkRecordPatch, ...] = Field(default=(), max_length=100_000)

    @field_validator("links", mode="before")
    @classmethod
    def restore_links(cls, value: object) -> object:
        """Restore ordered hyperlink records from JSON arrays."""
        return tuple(value) if isinstance(value, list) else value


class LegacyCommentRecordPatch(SdkModel):
    """One complete legacy worksheet comment record."""

    coordinate: NonEmptyString
    author: NonEmptyString
    text: str = Field(max_length=32_767)

    @field_validator("coordinate")
    @classmethod
    def validate_coordinate(cls, value: str) -> str:
        """Normalize one legacy-comment cell coordinate."""
        return normalize_excel_coordinate(value)


class WorksheetLegacyCommentsPatch(SdkModel):
    """Explicit full replacement of one worksheet's legacy comments."""

    sheet_name: WorksheetName
    comments: tuple[LegacyCommentRecordPatch, ...] = Field(
        default=(),
        max_length=100_000,
    )

    @field_validator("comments", mode="before")
    @classmethod
    def restore_comments(cls, value: object) -> object:
        """Restore ordered legacy-comment records from JSON arrays."""
        return tuple(value) if isinstance(value, list) else value

    @model_validator(mode="after")
    def validate_targets(self) -> Self:
        """Require at most one legacy comment per worksheet cell."""
        coordinates = [comment.coordinate for comment in self.comments]
        if len(coordinates) != len(set(coordinates)):
            msg = "legacy comment targets must be unique"
            raise ValueError(msg)
        return self


class DefinedNamePatch(SdkModel):
    """Create, update, or delete one local-workbook defined name."""

    name: NonEmptyString
    operation: Literal["create", "update", "delete"]
    formula: str | None = None
    scope_sheet_name: WorksheetName | None = None
    hidden: bool = False
    allow_external_reference: bool = False

    @field_validator("name")
    @classmethod
    def validate_name(cls, value: str) -> str:
        """Reject names that cannot be represented safely in workbook XML."""
        if len(value) > _MAX_DEFINED_NAME_LENGTH or any(
            ord(character) < _MIN_PRINTABLE_CODEPOINT for character in value
        ):
            msg = "defined name is outside Excel bounds"
            raise ValueError(msg)
        return value

    @model_validator(mode="after")
    def validate_operation(self) -> Self:
        """Bind formulas to create/update and reject external path definitions."""
        if self.operation == "delete":
            if self.formula is not None or self.hidden or self.allow_external_reference:
                msg = "defined name delete patches cannot include target state"
                raise ValueError(msg)
            return self
        if (
            self.formula is None
            or not self.formula
            or len(self.formula) > _MAX_DEFINED_NAME_FORMULA_LENGTH
        ):
            msg = "defined name create/update patches require a bounded formula"
            raise ValueError(msg)
        has_external_reference = formula_has_external_reference(self.formula)
        if has_external_reference and not self.allow_external_reference:
            msg = "external defined name formulas are unsupported"
            raise ValueError(msg)
        if self.allow_external_reference and (
            self.operation != "update" or not has_external_reference
        ):
            msg = "external defined name formulas require an explicit update"
            raise ValueError(msg)
        if any(ord(character) == 0 for character in self.formula):
            msg = "defined name formulas cannot contain null characters"
            raise ValueError(msg)
        return self


class DifferentialFormatPatch(SdkModel):
    """A complete supported differential style for conditional formatting."""

    font: CellFontPatch | None = None
    fill: CellPatternFillPatch | CellGradientFillPatch | None = None
    border: CellBorderPatch | None = None
    alignment: CellAlignmentPatch | None = None
    number_format: ExcelNumberFormatCode | None = None


class ConditionalFormattingRulePatch(SdkModel):
    """One standard conditional-formatting rule in priority order."""

    rule_type: Literal[
        "expression",
        "cellIs",
        "containsText",
        "notContainsText",
        "beginsWith",
        "endsWith",
        "containsBlanks",
        "notContainsBlanks",
        "duplicateValues",
        "top10",
    ]
    operator: (
        Literal[
            "lessThan",
            "lessThanOrEqual",
            "equal",
            "notEqual",
            "greaterThanOrEqual",
            "greaterThan",
            "between",
            "notBetween",
            "containsText",
            "notContains",
            "beginsWith",
            "endsWith",
        ]
        | None
    ) = None
    formulas: tuple[str, ...] = Field(default=(), max_length=2)
    text: str | None = None
    stop_if_true: bool = False
    rank: int | None = Field(default=None, ge=1)
    bottom: bool | None = None
    differential_format: DifferentialFormatPatch | None = None

    @field_validator("formulas", mode="before")
    @classmethod
    def restore_formulas(cls, value: object) -> object:
        """Restore formula tuples from JSON arrays."""
        return tuple(value) if isinstance(value, list) else value

    @model_validator(mode="after")
    def validate_rule(self) -> Self:
        """Enforce the bounded operands required by each supported rule family."""
        if any(
            not formula or len(formula) > _MAX_CONDITIONAL_FORMATTING_FORMULA_LENGTH
            for formula in self.formulas
        ):
            msg = "conditional formatting formulas must be non-empty and bounded"
            raise ValueError(msg)
        if self.rule_type == "expression" and len(self.formulas) != 1:
            msg = "expression conditional formatting requires one formula"
            raise ValueError(msg)
        if self.rule_type == "cellIs" and (
            self.operator is None
            or len(self.formulas)
            != (2 if self.operator in {"between", "notBetween"} else 1)
        ):
            msg = "cellIs conditional formatting requires matching operands"
            raise ValueError(msg)
        text_rules = {
            "containsText",
            "notContainsText",
            "beginsWith",
            "endsWith",
        }
        if self.rule_type in text_rules and (not self.text or len(self.formulas) != 1):
            msg = "text conditional formatting requires text"
            raise ValueError(msg)
        if (
            self.rule_type in {"containsBlanks", "notContainsBlanks"}
            and len(self.formulas) != 1
        ):
            msg = "blank conditional formatting requires one formula"
            raise ValueError(msg)
        if self.rule_type == "duplicateValues" and self.formulas:
            msg = "duplicate-value conditional formatting cannot include formulas"
            raise ValueError(msg)
        if self.rule_type == "top10" and self.rank is None:
            msg = "top10 conditional formatting requires rank"
            raise ValueError(msg)
        return self


class ConditionalFormattingBlockPatch(SdkModel):
    """One target range set and its ordered conditional-formatting rules."""

    cell_ranges: tuple[NonEmptyString, ...] = Field(min_length=1, max_length=1_000)
    rules: tuple[ConditionalFormattingRulePatch, ...] = Field(
        min_length=1,
        max_length=10_000,
    )

    @field_validator("cell_ranges", "rules", mode="before")
    @classmethod
    def restore_sequences(cls, value: object) -> object:
        """Restore tuple fields from JSON arrays."""
        return tuple(value) if isinstance(value, list) else value

    @field_validator("cell_ranges")
    @classmethod
    def validate_ranges(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        """Normalize and deduplicate every target range."""
        normalized = tuple(normalize_excel_range(item) for item in value)
        if len(normalized) != len(set(normalized)):
            msg = "conditional formatting ranges must be unique"
            raise ValueError(msg)
        return normalized


class WorksheetConditionalFormattingPatch(SdkModel):
    """Explicit full replacement of one worksheet's conditional formatting."""

    sheet_name: WorksheetName
    blocks: tuple[ConditionalFormattingBlockPatch, ...] = Field(
        default=(),
        max_length=10_000,
    )

    @field_validator("blocks", mode="before")
    @classmethod
    def restore_blocks(cls, value: object) -> object:
        """Restore block tuples from JSON arrays."""
        return tuple(value) if isinstance(value, list) else value


class DataValidationRulePatch(SdkModel):
    """One complete standard worksheet data-validation rule."""

    representation: Literal["standard", "x14"] = "standard"
    cell_ranges: tuple[NonEmptyString, ...] = Field(min_length=1, max_length=1_000)
    validation_type: (
        Literal[
            "list",
            "whole",
            "decimal",
            "date",
            "time",
            "textLength",
            "custom",
        ]
        | None
    ) = None
    operator: (
        Literal[
            "between",
            "notBetween",
            "equal",
            "notEqual",
            "lessThan",
            "lessThanOrEqual",
            "greaterThan",
            "greaterThanOrEqual",
        ]
        | None
    ) = None
    formula1: str | None = None
    formula2: str | None = None
    allow_blank: bool = False
    show_error_message: bool = False
    show_input_message: bool = False
    show_drop_down: bool = False
    error_style: Literal["stop", "warning", "information"] | None = None
    error: str | None = Field(
        default=None, max_length=_MAX_DATA_VALIDATION_MESSAGE_LENGTH
    )
    error_title: str | None = Field(
        default=None,
        max_length=_MAX_DATA_VALIDATION_TITLE_LENGTH,
    )
    prompt: str | None = Field(
        default=None, max_length=_MAX_DATA_VALIDATION_MESSAGE_LENGTH
    )
    prompt_title: str | None = Field(
        default=None,
        max_length=_MAX_DATA_VALIDATION_TITLE_LENGTH,
    )
    revision_uid: str | None = Field(
        default=None,
        pattern=_DATA_VALIDATION_REVISION_UID_PATTERN,
    )
    clear_revision_uid: bool = False

    @field_validator("cell_ranges", mode="before")
    @classmethod
    def restore_ranges(cls, value: object) -> object:
        """Restore range tuples from JSON arrays."""
        return tuple(value) if isinstance(value, list) else value

    @field_validator("cell_ranges")
    @classmethod
    def validate_ranges(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        """Normalize and deduplicate every validation target range."""
        normalized = tuple(normalize_excel_range(item) for item in value)
        if len(normalized) != len(set(normalized)):
            msg = "data validation ranges must be unique"
            raise ValueError(msg)
        return normalized

    @model_validator(mode="after")
    def validate_rule(self) -> Self:
        """Enforce bounded formulas and type-specific operands."""
        if self.revision_uid is not None and self.clear_revision_uid:
            msg = (
                "data validation revision UID and clear operation "
                "are mutually exclusive"
            )
            raise ValueError(msg)
        if any(
            formula is not None
            and (not formula or len(formula) > _MAX_DATA_VALIDATION_FORMULA_LENGTH)
            for formula in (self.formula1, self.formula2)
        ):
            msg = "data validation formulas must be non-empty and bounded"
            raise ValueError(msg)
        if self.formula2 is not None and self.formula1 is None:
            msg = "data validation formula2 requires formula1"
            raise ValueError(msg)
        if self.validation_type in {"list", "custom"} and self.formula1 is None:
            msg = "list and custom data validation require formula1"
            raise ValueError(msg)
        if self.validation_type is None and (
            self.operator is not None
            or self.formula1 is not None
            or self.formula2 is not None
        ):
            msg = "untyped data validation cannot include operands"
            raise ValueError(msg)
        if self.operator in {"between", "notBetween"} and self.formula2 is None:
            msg = "between data validation requires formula2"
            raise ValueError(msg)
        return self


class WorksheetDataValidationPatch(SdkModel):
    """Explicit full replacement of one worksheet's standard validations."""

    sheet_name: WorksheetName
    rules: tuple[DataValidationRulePatch, ...] = Field(default=(), max_length=100_000)

    @field_validator("rules", mode="before")
    @classmethod
    def restore_rules(cls, value: object) -> object:
        """Restore the ordered rule tuple from a JSON array."""
        return tuple(value) if isinstance(value, list) else value


class ColumnDimensionPatch(SdkModel):
    """One bounded worksheet column-dimension patch."""

    sheet_name: WorksheetName
    start_column: str
    end_column: str | None = None
    width: float | None = Field(default=None, gt=0, le=MAX_EXCEL_COLUMN_WIDTH)
    clear_width: bool = False
    hidden: bool | None = None
    best_fit: bool | None = None
    font: CellFontPatch | None = None
    fill: CellPatternFillPatch | None = None
    border: CellBorderPatch | None = None
    alignment: CellAlignmentPatch | None = None
    number_format: ExcelNumberFormatCode | None = None
    named_style: NonEmptyString | None = None
    quote_prefix: bool | None = None
    pivot_button: bool | None = None

    @field_validator("start_column", "end_column")
    @classmethod
    def validate_column(cls, value: str | None) -> str | None:
        """Normalize and bound each supplied worksheet column."""
        return None if value is None else _normalize_column_name(value)

    @model_validator(mode="after")
    def validate_patch(self) -> Self:
        """Require one operation and an ordered finite column range."""
        if self.width is not None and self.clear_width:
            msg = "column dimension width and clear_width are mutually exclusive"
            raise ValueError(msg)
        if (
            self.width is None
            and not self.clear_width
            and self.hidden is None
            and self.best_fit is None
            and self.font is None
            and self.fill is None
            and self.border is None
            and self.alignment is None
            and self.number_format is None
            and self.named_style is None
            and self.quote_prefix is None
            and self.pivot_button is None
        ):
            msg = "column dimension patches require layout or format changes"
            raise ValueError(msg)
        end_column = self.end_column or self.start_column
        start = excel_range_bounds(f"{self.start_column}1").min_column
        end = excel_range_bounds(f"{end_column}1").min_column
        if end < start:
            msg = "column dimension patch ranges must be ordered"
            raise ValueError(msg)
        return self


class WorkbookNamedStylePatch(SdkModel):
    """One deterministic named-style definition imported before use."""

    name: NonEmptyString
    builtin_id: int | None = Field(default=None, ge=0, le=255)
    font: CellFontPatch
    fill: CellPatternFillPatch
    border: CellBorderPatch
    alignment: CellAlignmentPatch
    number_format: ExcelNumberFormatCode


class RowDimensionPatch(SdkModel):
    """One bounded worksheet row-dimension patch."""

    sheet_name: WorksheetName
    start_row: ExcelRowNumber
    end_row: ExcelRowNumber | None = None
    height: float | None = Field(default=None, gt=0, le=MAX_EXCEL_ROW_HEIGHT)
    clear_height: bool = False
    hidden: bool | None = None

    @model_validator(mode="after")
    def validate_patch(self) -> Self:
        """Require one operation and an ordered finite row range."""
        if self.height is not None and self.clear_height:
            msg = "row dimension height and clear_height are mutually exclusive"
            raise ValueError(msg)
        if self.height is None and not self.clear_height and self.hidden is None:
            msg = "row dimension patches require height or hidden"
            raise ValueError(msg)
        if self.end_row is not None and self.end_row < self.start_row:
            msg = "row dimension patch ranges must be ordered"
            raise ValueError(msg)
        return self


def _column_patch_bounds(patch: ColumnDimensionPatch) -> tuple[int, int]:
    start = excel_range_bounds(f"{patch.start_column}1").min_column
    end = excel_range_bounds(f"{patch.end_column or patch.start_column}1").min_column
    return start, end


def _validate_column_patch_overlaps(  # noqa: C901
    patches: tuple[ColumnDimensionPatch, ...],
) -> None:
    intervals: dict[tuple[str, str], list[tuple[int, int, object]]] = {}
    for patch in patches:
        start, end = _column_patch_bounds(patch)
        if patch.width is not None:
            intervals.setdefault((patch.sheet_name.casefold(), "width"), []).append(
                (start, end, patch.width)
            )
        if patch.clear_width:
            intervals.setdefault((patch.sheet_name.casefold(), "width"), []).append(
                (start, end, "clear")
            )
        if patch.hidden is not None:
            intervals.setdefault((patch.sheet_name.casefold(), "hidden"), []).append(
                (start, end, patch.hidden)
            )
        if patch.best_fit is not None:
            intervals.setdefault((patch.sheet_name.casefold(), "best_fit"), []).append(
                (start, end, patch.best_fit)
            )
        for field in (
            "font",
            "fill",
            "border",
            "alignment",
            "number_format",
            "named_style",
            "quote_prefix",
            "pivot_button",
        ):
            value = getattr(patch, field)
            if value is not None:
                intervals.setdefault((patch.sheet_name.casefold(), field), []).append(
                    (start, end, value)
                )
    for values in intervals.values():
        merged_end = 0
        merged_value: object = None
        for start, end, value in sorted(values, key=lambda item: (item[0], item[1])):
            if start <= merged_end and value != merged_value:
                msg = "overlapping column dimension patches must not conflict"
                raise ValueError(msg)
            if start > merged_end:
                merged_end = end
                merged_value = value
            else:
                merged_end = max(merged_end, end)


def _validate_row_patch_overlaps(
    patches: tuple[RowDimensionPatch, ...],
) -> None:
    intervals: dict[tuple[str, str], list[tuple[int, int, object]]] = {}
    for patch in patches:
        end = patch.end_row or patch.start_row
        if patch.height is not None or patch.clear_height:
            intervals.setdefault((patch.sheet_name.casefold(), "height"), []).append(
                (
                    patch.start_row,
                    end,
                    patch.height if patch.height is not None else "clear",
                )
            )
        if patch.hidden is not None:
            intervals.setdefault((patch.sheet_name.casefold(), "hidden"), []).append(
                (patch.start_row, end, patch.hidden)
            )
    for values in intervals.values():
        merged_end = 0
        merged_value: object = None
        for start, end, value in sorted(values, key=lambda item: (item[0], item[1])):
            if start <= merged_end and value != merged_value:
                msg = "overlapping row dimension patches must not conflict"
                raise ValueError(msg)
            if start > merged_end:
                merged_end = end
                merged_value = value
            else:
                merged_end = max(merged_end, end)


class NamedRangePatch(SdkModel):
    """A rectangular value matrix for one workbook-defined name."""

    name: NonEmptyString
    values: tuple[tuple[CellPatchValue, ...], ...] = Field(min_length=1)

    @field_validator("values", mode="before")
    @classmethod
    def restore_json_matrix(cls, value: object) -> object:
        """Restore the tuple matrix from its JSON-compatible list form."""
        if not isinstance(value, list):
            return value
        return tuple(tuple(row) if isinstance(row, list) else row for row in value)

    @model_validator(mode="after")
    def validate_matrix(self) -> Self:
        """Require a non-empty rectangular matrix."""
        widths = {len(row) for row in self.values}
        if not widths or 0 in widths or len(widths) != 1:
            msg = "named-range values must form a non-empty rectangle"
            raise ValueError(msg)
        return self


class WorkbookPatchRequest(SdkModel):
    """Typed changes for safe workbook or template patching."""

    cells: tuple[CellPatch, ...] = ()
    formats: tuple[CellFormatPatch, ...] = Field(default=(), max_length=100_000)
    existing_cell_format_ranges: tuple[ExistingCellFormatRangePatch, ...] = Field(
        default=(),
        max_length=1_000,
    )
    default_style: WorkbookDefaultStylePatch | None = None
    named_styles: tuple[WorkbookNamedStylePatch, ...] = Field(
        default=(),
        max_length=1_000,
    )
    create_sheets: tuple[WorksheetCreatePatch, ...] = Field(
        default=(),
        max_length=1_000,
    )
    delete_sheets: tuple[WorksheetDeletePatch, ...] = Field(
        default=(),
        max_length=1_000,
    )
    structural_insertions: tuple[WorksheetStructuralInsertionPatch, ...] = Field(
        default=(),
        max_length=1_000,
    )
    drawing_removals: tuple[WorksheetDrawingRemovalPatch, ...] = Field(
        default=(),
        max_length=1_000,
    )
    image_additions: tuple[WorksheetImagePatch, ...] = Field(
        default=(),
        max_length=1_000,
    )
    external_link_removals: tuple[ExternalLinkRemovalPatch, ...] = Field(
        default=(),
        max_length=10_000,
    )
    sheet_order: WorkbookSheetOrderPatch | None = None
    freeze_panes: tuple[FreezePanePatch, ...] = Field(default=(), max_length=1_000)
    auto_filters: tuple[AutoFilterPatch, ...] = Field(default=(), max_length=1_000)
    merged_ranges: tuple[MergedRangePatch, ...] = Field(
        default=(),
        max_length=100_000,
    )
    table_ranges: tuple[TableRangePatch, ...] = Field(default=(), max_length=10_000)
    defined_names: tuple[DefinedNamePatch, ...] = Field(
        default=(),
        max_length=100_000,
    )
    conditional_formatting: tuple[WorksheetConditionalFormattingPatch, ...] = Field(
        default=(),
        max_length=1_000,
    )
    data_validations: tuple[WorksheetDataValidationPatch, ...] = Field(
        default=(),
        max_length=1_000,
    )
    hyperlinks: tuple[WorksheetHyperlinkPatch, ...] = Field(
        default=(),
        max_length=1_000,
    )
    legacy_comments: tuple[WorksheetLegacyCommentsPatch, ...] = Field(
        default=(),
        max_length=1_000,
    )
    named_ranges: tuple[NamedRangePatch, ...] = ()
    column_dimensions: tuple[ColumnDimensionPatch, ...] = Field(
        default=(),
        max_length=100_000,
    )
    row_dimensions: tuple[RowDimensionPatch, ...] = Field(
        default=(),
        max_length=100_000,
    )
    remove_unreferenced_external_links: bool = False
    output_file_id: NonEmptyString | None = None

    @field_validator(
        "cells",
        "formats",
        "existing_cell_format_ranges",
        "named_styles",
        "create_sheets",
        "delete_sheets",
        "structural_insertions",
        "drawing_removals",
        "image_additions",
        "external_link_removals",
        "freeze_panes",
        "auto_filters",
        "merged_ranges",
        "table_ranges",
        "defined_names",
        "conditional_formatting",
        "data_validations",
        "hyperlinks",
        "legacy_comments",
        "named_ranges",
        "column_dimensions",
        "row_dimensions",
        mode="before",
    )
    @classmethod
    def restore_json_sequences(cls, value: object) -> object:
        """Restore tuple fields from their JSON-compatible list form."""
        return tuple(value) if isinstance(value, list) else value

    @model_validator(mode="after")
    def validate_changes(self) -> Self:  # noqa: C901, PLR0912, PLR0915
        """Reject empty requests and duplicate direct cell targets."""
        if (
            not self.cells
            and not self.formats
            and not self.existing_cell_format_ranges
            and self.default_style is None
            and not self.named_styles
            and not self.create_sheets
            and not self.delete_sheets
            and not self.structural_insertions
            and not self.drawing_removals
            and not self.image_additions
            and not self.external_link_removals
            and self.sheet_order is None
            and not self.freeze_panes
            and not self.auto_filters
            and not self.merged_ranges
            and not self.table_ranges
            and not self.defined_names
            and not self.conditional_formatting
            and not self.data_validations
            and not self.hyperlinks
            and not self.legacy_comments
            and not self.named_ranges
            and not self.column_dimensions
            and not self.row_dimensions
            and not self.remove_unreferenced_external_links
        ):
            msg = "workbook patch request must contain at least one change"
            raise ValueError(msg)
        deleted_names = [patch.name.casefold() for patch in self.delete_sheets]
        if len(deleted_names) != len(set(deleted_names)):
            msg = "worksheet deletion targets must be unique"
            raise ValueError(msg)
        drawing_names = [patch.sheet_name.casefold() for patch in self.drawing_removals]
        if len(drawing_names) != len(set(drawing_names)):
            msg = "worksheet drawing removal targets must be unique"
            raise ValueError(msg)
        insertion_targets = [
            (patch.sheet_name.casefold(), patch.axis, patch.before)
            for patch in self.structural_insertions
        ]
        if len(insertion_targets) != len(set(insertion_targets)):
            msg = "worksheet structural insertion targets must be unique"
            raise ValueError(msg)
        link_indexes = [patch.link_index for patch in self.external_link_removals]
        if len(link_indexes) != len(set(link_indexes)):
            msg = "external link removal indexes must be unique"
            raise ValueError(msg)
        targets = [
            (patch.sheet_name.casefold(), patch.coordinate) for patch in self.cells
        ]
        if len(targets) != len(set(targets)):
            msg = "workbook patch coordinates must be unique"
            raise ValueError(msg)
        format_targets = [
            (patch.sheet_name.casefold(), patch.coordinate) for patch in self.formats
        ]
        if len(format_targets) != len(set(format_targets)):
            msg = "workbook format patch coordinates must be unique"
            raise ValueError(msg)
        named_style_names = [patch.name.casefold() for patch in self.named_styles]
        if len(named_style_names) != len(set(named_style_names)):
            msg = "workbook named style import names must be unique"
            raise ValueError(msg)
        builtin_ids = [
            patch.builtin_id
            for patch in self.named_styles
            if patch.builtin_id is not None
        ]
        if len(builtin_ids) != len(set(builtin_ids)):
            msg = "workbook named style import built-in identities must be unique"
            raise ValueError(msg)
        referenced_styles = {
            patch.named_style.casefold()
            for patch in self.formats
            if patch.named_style is not None
        }
        referenced_styles.update(
            patch.named_style.casefold()
            for patch in self.existing_cell_format_ranges
            if patch.named_style is not None
        )
        referenced_styles.update(
            patch.named_style.casefold()
            for patch in self.column_dimensions
            if patch.named_style is not None
        )
        if (
            self.default_style is not None
            and self.default_style.named_style is not None
        ):
            referenced_styles.add(self.default_style.named_style.casefold())
        if not set(named_style_names) <= referenced_styles:
            msg = "workbook named style imports must be referenced by a style patch"
            raise ValueError(msg)
        sheet_names = [patch.name.casefold() for patch in self.create_sheets]
        if len(sheet_names) != len(set(sheet_names)):
            msg = "created worksheet names must be unique"
            raise ValueError(msg)
        pane_sheets = [patch.sheet_name.casefold() for patch in self.freeze_panes]
        if len(pane_sheets) != len(set(pane_sheets)):
            msg = "workbook freeze pane patch worksheets must be unique"
            raise ValueError(msg)
        filter_sheets = [patch.sheet_name.casefold() for patch in self.auto_filters]
        if len(filter_sheets) != len(set(filter_sheets)):
            msg = "workbook auto filter patch worksheets must be unique"
            raise ValueError(msg)
        merge_operations: dict[tuple[str, str], set[str]] = {}
        for patch in self.merged_ranges:
            target = (patch.sheet_name.casefold(), patch.cell_range)
            operations = merge_operations.setdefault(target, set())
            if patch.operation in operations:
                msg = "workbook merged range patch operations must be unique"
                raise ValueError(msg)
            operations.add(patch.operation)
        table_targets = [
            (patch.sheet_name.casefold(), patch.table_name.casefold())
            for patch in self.table_ranges
        ]
        if len(table_targets) != len(set(table_targets)):
            msg = "workbook table range patch targets must be unique"
            raise ValueError(msg)
        defined_name_targets = [
            (
                patch.name.casefold(),
                None
                if patch.scope_sheet_name is None
                else patch.scope_sheet_name.casefold(),
            )
            for patch in self.defined_names
        ]
        if len(defined_name_targets) != len(set(defined_name_targets)):
            msg = "workbook defined name patch targets must be unique"
            raise ValueError(msg)
        conditional_sheets = [
            patch.sheet_name.casefold() for patch in self.conditional_formatting
        ]
        if len(conditional_sheets) != len(set(conditional_sheets)):
            msg = "conditional formatting patch worksheets must be unique"
            raise ValueError(msg)
        validation_sheets = [
            patch.sheet_name.casefold() for patch in self.data_validations
        ]
        if len(validation_sheets) != len(set(validation_sheets)):
            msg = "data validation patch worksheets must be unique"
            raise ValueError(msg)
        hyperlink_sheets = [patch.sheet_name.casefold() for patch in self.hyperlinks]
        if len(hyperlink_sheets) != len(set(hyperlink_sheets)):
            msg = "hyperlink patch worksheets must be unique"
            raise ValueError(msg)
        comment_sheets = [patch.sheet_name.casefold() for patch in self.legacy_comments]
        if len(comment_sheets) != len(set(comment_sheets)):
            msg = "legacy comment patch worksheets must be unique"
            raise ValueError(msg)
        names = [patch.name.casefold() for patch in self.named_ranges]
        if len(names) != len(set(names)):
            msg = "named-range patch names must be unique"
            raise ValueError(msg)
        _validate_column_patch_overlaps(self.column_dimensions)
        _validate_row_patch_overlaps(self.row_dimensions)
        deleted = set(deleted_names)
        targeted_sheets = {
            patch.sheet_name.casefold()
            for patches in (
                self.cells,
                self.formats,
                self.existing_cell_format_ranges,
                self.structural_insertions,
                self.drawing_removals,
                self.image_additions,
                self.freeze_panes,
                self.auto_filters,
                self.merged_ranges,
                self.table_ranges,
                self.conditional_formatting,
                self.data_validations,
                self.hyperlinks,
                self.legacy_comments,
                self.column_dimensions,
                self.row_dimensions,
            )
            for patch in patches
        }
        targeted_sheets.update(
            patch.scope_sheet_name.casefold()
            for patch in self.defined_names
            if patch.scope_sheet_name is not None
        )
        if deleted & targeted_sheets:
            msg = "worksheet deletion cannot be combined with patches on that sheet"
            raise ValueError(msg)
        removed_drawings = {
            patch.sheet_name.casefold() for patch in self.drawing_removals
        }
        added_images = {patch.sheet_name.casefold() for patch in self.image_additions}
        if removed_drawings & added_images:
            msg = "drawing removal and image addition on one worksheet conflict"
            raise ValueError(msg)
        return self


class CellModification(SdkModel):
    """One verified workbook cell modification."""

    sheet_name: WorksheetName
    coordinate: NonEmptyString
    old_value: ExcelPatchScalar = None
    new_value: ExcelPatchScalar = None
    old_formula: str | None = None
    new_formula: str | None = None
    number_format: str | None = None
    source: ExcelSourceReference
    output_source: ExcelSourceReference

    @field_validator("coordinate")
    @classmethod
    def validate_coordinate(cls, value: str) -> str:
        """Normalize the changed coordinate."""
        return normalize_excel_coordinate(value)

    @model_validator(mode="after")
    def validate_sources(self) -> Self:
        """Ensure source references point to the modified cell and sheet."""
        for formula in (self.old_formula, self.new_formula):
            if formula is not None and not formula.startswith("="):
                msg = "cell modification formulas must start with '='"
                raise ValueError(msg)
        if self.old_formula is not None and self.old_value is not None:
            msg = "old formula and ordinary value are mutually exclusive"
            raise ValueError(msg)
        if self.new_formula is not None and self.new_value is not None:
            msg = "new formula and ordinary value are mutually exclusive"
            raise ValueError(msg)
        for source in (self.source, self.output_source):
            if (
                source.sheet_name != self.sheet_name
                or source.cell_range != self.coordinate
            ):
                msg = "cell modification sources must match the changed cell"
                raise ValueError(msg)
        return self


class CellFormatModification(SdkModel):
    """One verified workbook cell-format modification."""

    sheet_name: WorksheetName
    coordinate: NonEmptyString
    changed_components: tuple[
        Literal[
            "font",
            "fill",
            "border",
            "alignment",
            "number_format",
            "named_style",
            "quote_prefix",
            "pivot_button",
        ],
        ...,
    ] = Field(min_length=1)
    source: ExcelSourceReference
    output_source: ExcelSourceReference

    @field_validator("coordinate")
    @classmethod
    def validate_coordinate(cls, value: str) -> str:
        """Normalize the changed coordinate."""
        return normalize_excel_coordinate(value)

    @field_validator("changed_components", mode="before")
    @classmethod
    def restore_components(cls, value: object) -> object:
        """Restore JSON arrays and keep component evidence canonical."""
        return tuple(value) if isinstance(value, list) else value

    @model_validator(mode="after")
    def validate_sources(self) -> Self:
        """Bind both references to the exact formatted cell."""
        if len(self.changed_components) != len(set(self.changed_components)):
            msg = "cell format modification components must be unique"
            raise ValueError(msg)
        for source in (self.source, self.output_source):
            if (
                source.sheet_name != self.sheet_name
                or source.cell_range != self.coordinate
            ):
                msg = "cell format modification sources must match the changed cell"
                raise ValueError(msg)
        return self


class ExistingCellFormatRangeModification(SdkModel):
    """Compact evidence for one verified existing-cell range-format operation."""

    sheet_name: WorksheetName
    cell_ranges: tuple[NonEmptyString, ...] = Field(min_length=1, max_length=100_000)
    target_cell_count: int = Field(gt=0)
    changed_components: tuple[
        Literal[
            "font",
            "fill",
            "border",
            "alignment",
            "number_format",
            "named_style",
            "quote_prefix",
            "pivot_button",
        ],
        ...,
    ] = Field(min_length=1)
    source_file_id: NonEmptyString
    output_file_id: NonEmptyString

    @field_validator("cell_ranges", "changed_components", mode="before")
    @classmethod
    def restore_sequences(cls, value: object) -> object:
        """Restore immutable evidence sequences from JSON arrays."""
        return tuple(value) if isinstance(value, list) else value


class HyperlinkModification(SdkModel):
    """One verified worksheet hyperlink-set replacement."""

    sheet_name: WorksheetName
    old_count: int = Field(ge=0)
    new_count: int = Field(ge=0)
    old_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    new_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    source: ExcelSourceReference
    output_source: ExcelSourceReference

    @model_validator(mode="after")
    def validate_change(self) -> Self:
        """Bind a real hyperlink replacement to the complete worksheet."""
        if self.old_fingerprint == self.new_fingerprint:
            msg = "hyperlink modification evidence requires a real change"
            raise ValueError(msg)
        for source in (self.source, self.output_source):
            if (
                source.sheet_name != self.sheet_name
                or source.cell_range != "A1:XFD1048576"
            ):
                msg = "hyperlink modification sources must match the worksheet"
                raise ValueError(msg)
        return self


class LegacyCommentsModification(SdkModel):
    """One verified worksheet legacy-comment-set replacement."""

    sheet_name: WorksheetName
    old_count: int = Field(ge=0)
    new_count: int = Field(ge=0)
    old_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    new_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    source: ExcelSourceReference
    output_source: ExcelSourceReference

    @model_validator(mode="after")
    def validate_change(self) -> Self:
        """Bind a real legacy-comment replacement to the complete worksheet."""
        if self.old_fingerprint == self.new_fingerprint:
            msg = "legacy comment modification evidence requires a real change"
            raise ValueError(msg)
        for source in (self.source, self.output_source):
            if (
                source.sheet_name != self.sheet_name
                or source.cell_range != "A1:XFD1048576"
            ):
                msg = "legacy comment modification sources must match the worksheet"
                raise ValueError(msg)
        return self


class WorksheetCreationModification(SdkModel):
    """One verified newly created worksheet in the output workbook."""

    sheet_name: WorksheetName
    index: int = Field(ge=0, le=9_999)
    visibility: SheetVisibility
    output_source: ExcelSourceReference

    @model_validator(mode="after")
    def validate_source(self) -> Self:
        """Bind output evidence to the complete created worksheet."""
        if (
            self.output_source.sheet_name != self.sheet_name
            or self.output_source.cell_range != "A1:XFD1048576"
        ):
            msg = "worksheet creation output source must match the created worksheet"
            raise ValueError(msg)
        return self


class WorkbookSheetOrderModification(SdkModel):
    """One verified package-level workbook sheet reordering."""

    old_sheet_names: tuple[WorksheetName, ...] = Field(min_length=1)
    new_sheet_names: tuple[WorksheetName, ...] = Field(min_length=1)
    source_file_id: NonEmptyString
    output_file_id: NonEmptyString

    @field_validator("old_sheet_names", "new_sheet_names", mode="before")
    @classmethod
    def restore_sheet_names(cls, value: object) -> object:
        """Restore ordered tuples from JSON arrays."""
        return tuple(value) if isinstance(value, list) else value

    @model_validator(mode="after")
    def validate_change(self) -> Self:
        """Require one real permutation of exactly the same sheets."""
        old_identities = tuple(name.casefold() for name in self.old_sheet_names)
        new_identities = tuple(name.casefold() for name in self.new_sheet_names)
        if (
            len(old_identities) != len(set(old_identities))
            or len(new_identities) != len(set(new_identities))
            or set(old_identities) != set(new_identities)
            or old_identities == new_identities
        ):
            msg = "workbook sheet order evidence must describe a real permutation"
            raise ValueError(msg)
        return self


class FreezePaneModification(SdkModel):
    """One verified worksheet frozen-pane change."""

    sheet_name: WorksheetName
    old_coordinate: str | None = None
    new_coordinate: str | None = None
    source: ExcelSourceReference
    output_source: ExcelSourceReference

    @field_validator("old_coordinate", "new_coordinate")
    @classmethod
    def validate_coordinate(cls, value: str | None) -> str | None:
        """Normalize optional pane anchors in change evidence."""
        return None if value is None else normalize_excel_coordinate(value)

    @model_validator(mode="after")
    def validate_sources(self) -> Self:
        """Bind pane evidence to the complete worksheet."""
        if self.old_coordinate == self.new_coordinate:
            msg = "freeze pane modifications must describe a real change"
            raise ValueError(msg)
        for source in (self.source, self.output_source):
            if (
                source.sheet_name != self.sheet_name
                or source.cell_range != "A1:XFD1048576"
            ):
                msg = "freeze pane sources must match the modified worksheet"
                raise ValueError(msg)
        return self


class AutoFilterModification(SdkModel):
    """One verified worksheet automatic-filter state replacement."""

    sheet_name: WorksheetName
    old_cell_range: str | None = None
    new_cell_range: str | None = None
    old_state_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    new_state_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    source: ExcelSourceReference
    output_source: ExcelSourceReference

    @field_validator("old_cell_range", "new_cell_range")
    @classmethod
    def validate_range(cls, value: str | None) -> str | None:
        """Normalize optional filter ranges in public evidence."""
        return None if value is None else normalize_excel_range(value)

    @model_validator(mode="after")
    def validate_sources(self) -> Self:
        """Bind a real filter change to the complete worksheet."""
        if self.old_state_fingerprint == self.new_state_fingerprint:
            msg = "auto filter modifications must describe a real change"
            raise ValueError(msg)
        for source in (self.source, self.output_source):
            if (
                source.sheet_name != self.sheet_name
                or source.cell_range != "A1:XFD1048576"
            ):
                msg = "auto filter sources must match the modified worksheet"
                raise ValueError(msg)
        return self


class MergedRangeModification(SdkModel):
    """One verified worksheet merge or unmerge operation."""

    sheet_name: WorksheetName
    cell_range: NonEmptyString
    operation: Literal["merge", "unmerge"]
    source: ExcelSourceReference
    output_source: ExcelSourceReference

    @field_validator("cell_range")
    @classmethod
    def validate_range(cls, value: str) -> str:
        """Normalize the changed merged range."""
        return normalize_excel_range(value)

    @model_validator(mode="after")
    def validate_sources(self) -> Self:
        """Bind both references to the exact changed range."""
        for source in (self.source, self.output_source):
            if (
                source.sheet_name != self.sheet_name
                or source.cell_range != self.cell_range
            ):
                msg = "merged range sources must match the changed range"
                raise ValueError(msg)
        return self


class TableRangeModification(SdkModel):
    """One verified existing-table range change."""

    sheet_name: WorksheetName
    table_name: NonEmptyString
    old_range: NonEmptyString
    new_range: NonEmptyString
    source: ExcelSourceReference
    output_source: ExcelSourceReference

    @field_validator("old_range", "new_range")
    @classmethod
    def validate_range(cls, value: str) -> str:
        """Normalize table-range evidence."""
        return normalize_excel_range(value)

    @model_validator(mode="after")
    def validate_change(self) -> Self:
        """Bind a real table change to its old and new locations."""
        if self.old_range == self.new_range:
            msg = "table range modifications must describe a real change"
            raise ValueError(msg)
        if (
            self.source.sheet_name != self.sheet_name
            or self.source.cell_range != self.old_range
            or self.output_source.sheet_name != self.sheet_name
            or self.output_source.cell_range != self.new_range
        ):
            msg = "table range sources must match the changed table"
            raise ValueError(msg)
        return self


class DefinedNameModification(SdkModel):
    """One verified local-workbook defined-name change."""

    name: NonEmptyString
    operation: Literal["create", "update", "delete"]
    scope_sheet_name: WorksheetName | None = None
    old_formula: str | None = None
    new_formula: str | None = None
    old_hidden: bool | None = None
    new_hidden: bool | None = None
    source_file_id: NonEmptyString
    output_file_id: NonEmptyString

    @model_validator(mode="after")
    def validate_change(self) -> Self:
        """Require operation-consistent old/new definition evidence."""
        if self.operation == "create" and (
            self.old_formula is not None
            or self.new_formula is None
            or self.old_hidden is not None
            or self.new_hidden is None
        ):
            msg = "defined name create evidence requires only a new formula"
            raise ValueError(msg)
        if self.operation == "update" and (
            self.old_formula is None
            or self.new_formula is None
            or self.old_hidden is None
            or self.new_hidden is None
            or (
                self.old_formula == self.new_formula
                and self.old_hidden == self.new_hidden
            )
        ):
            msg = "defined name update evidence requires distinct formulas"
            raise ValueError(msg)
        if self.operation == "delete" and (
            self.old_formula is None
            or self.new_formula is not None
            or self.old_hidden is None
            or self.new_hidden is not None
        ):
            msg = "defined name delete evidence requires only an old formula"
            raise ValueError(msg)
        return self


class ConditionalFormattingModification(SdkModel):
    """One verified worksheet conditional-formatting replacement."""

    sheet_name: WorksheetName
    old_rule_count: int = Field(ge=0)
    new_rule_count: int = Field(ge=0)
    old_rule_set_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    new_rule_set_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    source: ExcelSourceReference
    output_source: ExcelSourceReference

    @model_validator(mode="after")
    def validate_sources(self) -> Self:
        """Bind a real replacement to the complete worksheet."""
        if self.old_rule_set_fingerprint == self.new_rule_set_fingerprint:
            msg = "conditional formatting evidence requires a rule-set change"
            raise ValueError(msg)
        for source in (self.source, self.output_source):
            if (
                source.sheet_name != self.sheet_name
                or source.cell_range != "A1:XFD1048576"
            ):
                msg = "conditional formatting sources must match the worksheet"
                raise ValueError(msg)
        return self


class DataValidationModification(SdkModel):
    """One verified worksheet data-validation rule-set replacement."""

    sheet_name: WorksheetName
    old_rule_count: int = Field(ge=0)
    new_rule_count: int = Field(ge=0)
    old_rule_set_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    new_rule_set_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    source: ExcelSourceReference
    output_source: ExcelSourceReference

    @model_validator(mode="after")
    def validate_sources(self) -> Self:
        """Bind a real replacement to the complete worksheet."""
        if self.old_rule_set_fingerprint == self.new_rule_set_fingerprint:
            msg = "data validation evidence requires a rule-set change"
            raise ValueError(msg)
        for source in (self.source, self.output_source):
            if (
                source.sheet_name != self.sheet_name
                or source.cell_range != "A1:XFD1048576"
            ):
                msg = "data validation sources must match the worksheet"
                raise ValueError(msg)
        return self


class ColumnDimensionModification(SdkModel):
    """One verified worksheet column-dimension modification."""

    sheet_name: WorksheetName
    start_column: str
    end_column: str
    old_width: float | None = Field(default=None, gt=0)
    new_width: float | None = Field(default=None, gt=0)
    old_hidden: bool
    new_hidden: bool
    old_best_fit: bool = False
    new_best_fit: bool = False
    old_style_fingerprint: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )
    new_style_fingerprint: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )
    style_changed_components: tuple[
        Literal[
            "font",
            "fill",
            "border",
            "alignment",
            "number_format",
            "named_style",
            "quote_prefix",
            "pivot_button",
        ],
        ...,
    ] = Field(default=(), max_length=8)
    source: ExcelSourceReference
    output_source: ExcelSourceReference

    @field_validator("style_changed_components", mode="before")
    @classmethod
    def restore_style_changed_components(cls, value: object) -> object:
        """Restore JSON arrays to the strict tuple representation."""
        return tuple(value) if isinstance(value, list) else value

    @field_validator("start_column", "end_column")
    @classmethod
    def validate_column(cls, value: str) -> str:
        """Normalize and bound each evidence column."""
        return _normalize_column_name(value)

    @model_validator(mode="after")
    def validate_sources(self) -> Self:
        """Bind both references to the exact modified whole-column range."""
        if (self.old_style_fingerprint is None) != (self.new_style_fingerprint is None):
            msg = "column style evidence requires both fingerprints"
            raise ValueError(msg)
        if self.style_changed_components and (
            self.old_style_fingerprint is None
            or self.old_style_fingerprint == self.new_style_fingerprint
        ):
            msg = "column style evidence requires a verified style change"
            raise ValueError(msg)
        if not self.style_changed_components and self.old_style_fingerprint is not None:
            msg = "column style fingerprints require changed components"
            raise ValueError(msg)
        start = excel_range_bounds(f"{self.start_column}1").min_column
        end = excel_range_bounds(f"{self.end_column}1").min_column
        if end < start:
            msg = "column modification ranges must be ordered"
            raise ValueError(msg)
        expected_range = f"{self.start_column}1:{self.end_column}{MAX_EXCEL_ROW}"
        for source in (self.source, self.output_source):
            if (
                source.sheet_name != self.sheet_name
                or source.cell_range != expected_range
            ):
                msg = "column modification sources must match the changed range"
                raise ValueError(msg)
        return self


class RowDimensionModification(SdkModel):
    """One verified worksheet row-dimension modification."""

    sheet_name: WorksheetName
    start_row: ExcelRowNumber
    end_row: ExcelRowNumber
    old_height: float | None = Field(default=None, gt=0)
    new_height: float | None = Field(default=None, gt=0)
    old_hidden: bool
    new_hidden: bool
    source: ExcelSourceReference
    output_source: ExcelSourceReference

    @model_validator(mode="after")
    def validate_sources(self) -> Self:
        """Bind both references to the exact modified whole-row range."""
        if self.end_row < self.start_row:
            msg = "row modification ranges must be ordered"
            raise ValueError(msg)
        expected_range = f"A{self.start_row}:XFD{self.end_row}"
        for source in (self.source, self.output_source):
            if (
                source.sheet_name != self.sheet_name
                or source.cell_range != expected_range
            ):
                msg = "row modification sources must match the changed range"
                raise ValueError(msg)
        return self


class WorkbookDefaultStyleModification(SdkModel):
    """One verified workbook default cell-style modification."""

    old_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    new_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    changed_components: tuple[
        Literal["font", "fill", "border", "alignment", "number_format", "named_style"],
        ...,
    ] = Field(min_length=1, max_length=6)
    source_file_id: NonEmptyString
    output_file_id: NonEmptyString

    @field_validator("changed_components", mode="before")
    @classmethod
    def restore_components(cls, value: object) -> object:
        """Restore the canonical tuple from JSON arrays."""
        return tuple(value) if isinstance(value, list) else value

    @model_validator(mode="after")
    def validate_change(self) -> Self:
        """Require one real, uniquely described default-style change."""
        if self.old_fingerprint == self.new_fingerprint:
            msg = "workbook default style evidence requires a real change"
            raise ValueError(msg)
        if len(self.changed_components) != len(set(self.changed_components)):
            msg = "workbook default style components must be unique"
            raise ValueError(msg)
        return self


class WorkbookStructuralModification(SdkModel):
    """One verified package-level workbook structural operation."""

    operation: Literal[
        "insert_rows",
        "insert_columns",
        "delete_worksheet",
        "remove_drawings",
        "add_image",
        "remove_external_link",
    ]
    target: NonEmptyString
    count: int = Field(default=1, ge=1, le=100_000)
    source_file_id: NonEmptyString
    output_file_id: NonEmptyString


class WorkbookModificationResult(SdkModel):
    """Verified atomic workbook modification or content-identical no-op evidence."""

    source_file: FileDescriptor
    output_file: FileDescriptor
    changes: tuple[CellModification, ...] = ()
    format_changes: tuple[CellFormatModification, ...] = ()
    existing_cell_format_range_changes: tuple[
        ExistingCellFormatRangeModification, ...
    ] = ()
    default_style_change: WorkbookDefaultStyleModification | None = None
    sheet_creations: tuple[WorksheetCreationModification, ...] = ()
    sheet_order_change: WorkbookSheetOrderModification | None = None
    freeze_pane_changes: tuple[FreezePaneModification, ...] = ()
    auto_filter_changes: tuple[AutoFilterModification, ...] = ()
    merged_range_changes: tuple[MergedRangeModification, ...] = ()
    table_range_changes: tuple[TableRangeModification, ...] = ()
    defined_name_changes: tuple[DefinedNameModification, ...] = ()
    conditional_formatting_changes: tuple[ConditionalFormattingModification, ...] = ()
    data_validation_changes: tuple[DataValidationModification, ...] = ()
    hyperlink_changes: tuple[HyperlinkModification, ...] = ()
    legacy_comment_changes: tuple[LegacyCommentsModification, ...] = ()
    column_changes: tuple[ColumnDimensionModification, ...] = ()
    row_changes: tuple[RowDimensionModification, ...] = ()
    structural_changes: tuple[WorkbookStructuralModification, ...] = ()
    external_links_removed: int = Field(default=0, ge=0)
    preservation: WorkbookPreservationReport
    warnings: tuple[NonEmptyString, ...] = ()
    source_unchanged: bool
    vba_preserved: bool | None = None

    @field_validator(
        "changes",
        "format_changes",
        "existing_cell_format_range_changes",
        "sheet_creations",
        "freeze_pane_changes",
        "auto_filter_changes",
        "merged_range_changes",
        "table_range_changes",
        "defined_name_changes",
        "conditional_formatting_changes",
        "data_validation_changes",
        "hyperlink_changes",
        "legacy_comment_changes",
        "column_changes",
        "row_changes",
        "structural_changes",
        "warnings",
        mode="before",
    )
    @classmethod
    def restore_json_sequences(cls, value: object) -> object:
        """Restore tuple fields from their JSON-compatible list form."""
        return tuple(value) if isinstance(value, list) else value

    @model_validator(mode="after")
    def validate_traceability(self) -> Self:  # noqa: C901, PLR0912, PLR0915
        """Bind preservation and every change to the two result files."""
        if (
            not self.changes
            and not self.format_changes
            and not self.existing_cell_format_range_changes
            and self.default_style_change is None
            and not self.sheet_creations
            and self.sheet_order_change is None
            and not self.freeze_pane_changes
            and not self.auto_filter_changes
            and not self.merged_range_changes
            and not self.table_range_changes
            and not self.defined_name_changes
            and not self.conditional_formatting_changes
            and not self.data_validation_changes
            and not self.hyperlink_changes
            and not self.legacy_comment_changes
            and not self.column_changes
            and not self.row_changes
            and not self.structural_changes
            and self.external_links_removed == 0
            and (
                self.source_file.fingerprint != self.output_file.fingerprint
                or self.source_file.size_bytes != self.output_file.size_bytes
            )
        ):
            msg = "no-op workbook modification output must match source content"
            raise ValueError(msg)
        if self.preservation.file != self.source_file:
            msg = "preservation report must describe source_file"
            raise ValueError(msg)
        if self.preservation.operation != "patch":
            msg = "workbook modification preservation operation must be patch"
            raise ValueError(msg)
        if (
            self.source_file.extension.casefold()
            != self.output_file.extension.casefold()
        ):
            msg = "workbook modification files must use the same extension"
            raise ValueError(msg)
        if not self.source_unchanged:
            msg = "successful workbook modification requires an unchanged source"
            raise ValueError(msg)
        targets = [
            (change.sheet_name.casefold(), change.coordinate) for change in self.changes
        ]
        if len(targets) != len(set(targets)):
            msg = "workbook modification changes must be unique"
            raise ValueError(msg)
        if any(
            change.source.file_id != self.source_file.file_id
            or change.output_source.file_id != self.output_file.file_id
            for change in self.changes
        ):
            msg = "workbook modification sources must match result files"
            raise ValueError(msg)
        if self.default_style_change is not None and (
            self.default_style_change.source_file_id != self.source_file.file_id
            or self.default_style_change.output_file_id != self.output_file.file_id
        ):
            msg = "workbook default style modification must match result files"
            raise ValueError(msg)
        validation_sheets = [
            change.sheet_name.casefold() for change in self.data_validation_changes
        ]
        if len(validation_sheets) != len(set(validation_sheets)):
            msg = "workbook data validation modifications must be unique"
            raise ValueError(msg)
        if any(
            change.source.file_id != self.source_file.file_id
            or change.output_source.file_id != self.output_file.file_id
            for change in self.data_validation_changes
        ):
            msg = "data validation sources must match result files"
            raise ValueError(msg)
        for changes, label in (
            (self.hyperlink_changes, "hyperlink"),
            (self.legacy_comment_changes, "legacy comment"),
        ):
            sheets = [change.sheet_name.casefold() for change in changes]
            if len(sheets) != len(set(sheets)):
                msg = f"workbook {label} modifications must be unique"
                raise ValueError(msg)
            if any(
                change.source.file_id != self.source_file.file_id
                or change.output_source.file_id != self.output_file.file_id
                for change in changes
            ):
                msg = f"{label} sources must match result files"
                raise ValueError(msg)
        conditional_sheets = [
            change.sheet_name.casefold()
            for change in self.conditional_formatting_changes
        ]
        if len(conditional_sheets) != len(set(conditional_sheets)):
            msg = "workbook conditional formatting modifications must be unique"
            raise ValueError(msg)
        if any(
            change.source.file_id != self.source_file.file_id
            or change.output_source.file_id != self.output_file.file_id
            for change in self.conditional_formatting_changes
        ):
            msg = "conditional formatting sources must match result files"
            raise ValueError(msg)
        defined_name_targets = [
            (
                change.name.casefold(),
                None
                if change.scope_sheet_name is None
                else change.scope_sheet_name.casefold(),
            )
            for change in self.defined_name_changes
        ]
        if len(defined_name_targets) != len(set(defined_name_targets)):
            msg = "workbook defined name modifications must be unique"
            raise ValueError(msg)
        if any(
            change.source_file_id != self.source_file.file_id
            or change.output_file_id != self.output_file.file_id
            for change in self.defined_name_changes
        ):
            msg = "defined name modifications must match result files"
            raise ValueError(msg)
        pane_sheets = [
            change.sheet_name.casefold() for change in self.freeze_pane_changes
        ]
        if len(pane_sheets) != len(set(pane_sheets)):
            msg = "workbook freeze pane modifications must be unique"
            raise ValueError(msg)
        if any(
            change.source.file_id != self.source_file.file_id
            or change.output_source.file_id != self.output_file.file_id
            for change in self.freeze_pane_changes
        ):
            msg = "freeze pane modification sources must match result files"
            raise ValueError(msg)
        filter_sheets = [
            change.sheet_name.casefold() for change in self.auto_filter_changes
        ]
        if len(filter_sheets) != len(set(filter_sheets)):
            msg = "workbook auto filter modifications must be unique"
            raise ValueError(msg)
        if any(
            change.source.file_id != self.source_file.file_id
            or change.output_source.file_id != self.output_file.file_id
            for change in self.auto_filter_changes
        ):
            msg = "auto filter modification sources must match result files"
            raise ValueError(msg)
        merge_targets = [
            (change.sheet_name.casefold(), change.cell_range, change.operation)
            for change in self.merged_range_changes
        ]
        if len(merge_targets) != len(set(merge_targets)):
            msg = "workbook merged range modification operations must be unique"
            raise ValueError(msg)
        if any(
            change.source.file_id != self.source_file.file_id
            or change.output_source.file_id != self.output_file.file_id
            for change in self.merged_range_changes
        ):
            msg = "merged range modification sources must match result files"
            raise ValueError(msg)
        table_targets = [
            (change.sheet_name.casefold(), change.table_name.casefold())
            for change in self.table_range_changes
        ]
        if len(table_targets) != len(set(table_targets)):
            msg = "workbook table range modifications must be unique"
            raise ValueError(msg)
        if any(
            change.source.file_id != self.source_file.file_id
            or change.output_source.file_id != self.output_file.file_id
            for change in self.table_range_changes
        ):
            msg = "table range modification sources must match result files"
            raise ValueError(msg)
        format_targets = [
            (change.sheet_name.casefold(), change.coordinate)
            for change in self.format_changes
        ]
        if len(format_targets) != len(set(format_targets)):
            msg = "workbook format modifications must be unique"
            raise ValueError(msg)
        if any(
            change.source.file_id != self.source_file.file_id
            or change.output_source.file_id != self.output_file.file_id
            for change in self.format_changes
        ):
            msg = "workbook format modification sources must match result files"
            raise ValueError(msg)
        if any(
            change.source_file_id != self.source_file.file_id
            or change.output_file_id != self.output_file.file_id
            for change in self.existing_cell_format_range_changes
        ):
            msg = "range format modifications must match result files"
            raise ValueError(msg)
        created_names = [
            change.sheet_name.casefold() for change in self.sheet_creations
        ]
        if len(created_names) != len(set(created_names)):
            msg = "workbook worksheet creations must be unique"
            raise ValueError(msg)
        if any(
            change.output_source.file_id != self.output_file.file_id
            for change in self.sheet_creations
        ):
            msg = "worksheet creation output sources must match output_file"
            raise ValueError(msg)
        if self.sheet_order_change is not None and (
            self.sheet_order_change.source_file_id != self.source_file.file_id
            or self.sheet_order_change.output_file_id != self.output_file.file_id
        ):
            msg = "workbook sheet order modification must match result files"
            raise ValueError(msg)
        column_targets = [
            (
                change.sheet_name.casefold(),
                change.start_column,
                change.end_column,
            )
            for change in self.column_changes
        ]
        if len(column_targets) != len(set(column_targets)):
            msg = "workbook column modifications must be unique"
            raise ValueError(msg)
        if any(
            change.source.file_id != self.source_file.file_id
            or change.output_source.file_id != self.output_file.file_id
            for change in self.column_changes
        ):
            msg = "workbook column modification sources must match result files"
            raise ValueError(msg)
        row_targets = [
            (change.sheet_name.casefold(), change.start_row, change.end_row)
            for change in self.row_changes
        ]
        if len(row_targets) != len(set(row_targets)):
            msg = "workbook row modifications must be unique"
            raise ValueError(msg)
        if any(
            change.source.file_id != self.source_file.file_id
            or change.output_source.file_id != self.output_file.file_id
            for change in self.row_changes
        ):
            msg = "workbook row modification sources must match result files"
            raise ValueError(msg)
        if any(
            change.source_file_id != self.source_file.file_id
            or change.output_file_id != self.output_file.file_id
            for change in self.structural_changes
        ):
            msg = "workbook structural modifications must match result files"
            raise ValueError(msg)
        if self.vba_preserved is not None and self.source_file.extension.casefold() != (
            ".xlsm"
        ):
            msg = "VBA preservation state requires an XLSM source"
            raise ValueError(msg)
        return self


class WorksheetRow(SdkModel):
    """One deterministic streamed worksheet row."""

    row_number: ExcelRowNumber
    cells: tuple[ExcelCell, ...] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_row(self) -> Self:
        """Ensure cells are ordered and share one row, file, and sheet."""
        if any(
            excel_range_bounds(cell.coordinate).min_row != self.row_number
            for cell in self.cells
        ):
            msg = "streamed cells must match row_number"
            raise ValueError(msg)
        positions = tuple(
            excel_range_bounds(cell.coordinate).min_column for cell in self.cells
        )
        if positions != tuple(sorted(set(positions))):
            msg = "streamed row cells must be ordered and unique"
            raise ValueError(msg)
        first_source = self.cells[0].source
        if any(
            cell.source.file_id != first_source.file_id
            or cell.source.sheet_name != first_source.sheet_name
            for cell in self.cells
        ):
            msg = "streamed row cells must share one file and sheet"
            raise ValueError(msg)
        return self


class SheetRangeSelection(SdkModel):
    """Optional workbook comparison range for one sheet."""

    sheet_name: NonEmptyString
    cell_range: NonEmptyString

    @field_validator("cell_range")
    @classmethod
    def validate_cell_range(cls, value: str) -> str:
        """Normalize a selected comparison range."""
        return normalize_excel_range(value)


class WorkbookComparisonOptions(SdkModel):
    """Bounds and ignore controls for workbook comparison."""

    selected_sheets: tuple[NonEmptyString, ...] = ()
    selected_ranges: tuple[SheetRangeSelection, ...] = ()
    ignore_empty_cells: bool = True
    ignore_style: bool = False
    ignore_formula_cache: bool = False
    value_normalization: Literal["none", "trim", "casefold"] = "none"
    max_differences: int = Field(default=10_000, gt=0)
    max_cells: int = Field(default=1_000_000, gt=0)

    @model_validator(mode="after")
    def validate_selections(self) -> Self:
        """Reject duplicate sheet and range selections."""
        sheets = [name.casefold() for name in self.selected_sheets]
        if len(sheets) != len(set(sheets)):
            msg = "selected comparison sheets must be unique"
            raise ValueError(msg)
        ranges = [
            (selection.sheet_name.casefold(), selection.cell_range)
            for selection in self.selected_ranges
        ]
        if len(ranges) != len(set(ranges)):
            msg = "selected comparison ranges must be unique"
            raise ValueError(msg)
        if self.selected_sheets:
            selected = set(sheets)
            if any(
                selection.sheet_name.casefold() not in selected
                for selection in self.selected_ranges
            ):
                msg = "selected ranges must belong to selected comparison sheets"
                raise ValueError(msg)
        return self


class CellDiff(SdkModel):
    """One cell-level workbook difference."""

    difference_type: Literal[
        "value",
        "formula",
        "cached_value",
        "data_type",
        "style",
        "hyperlink",
        "comment",
    ]
    sheet_name: NonEmptyString
    coordinate: NonEmptyString
    old_value: ExcelPatchScalar = None
    new_value: ExcelPatchScalar = None
    old_source: ExcelSourceReference | None = None
    new_source: ExcelSourceReference | None = None

    @field_validator("coordinate")
    @classmethod
    def validate_coordinate(cls, value: str) -> str:
        """Normalize the changed coordinate."""
        return normalize_excel_coordinate(value)

    @model_validator(mode="after")
    def validate_sources(self) -> Self:
        """Ensure any source references point to the compared cell."""
        for source in (self.old_source, self.new_source):
            if source is not None and (
                source.sheet_name != self.sheet_name
                or source.cell_range != self.coordinate
            ):
                msg = "cell difference sources must match the compared cell"
                raise ValueError(msg)
        return self


class FeatureDiff(SdkModel):
    """One structural workbook or worksheet difference."""

    difference_type: NonEmptyString
    feature: NonEmptyString
    old_state: FeatureState = None
    new_state: FeatureState = None
    old_source: ExcelSourceReference | None = None
    new_source: ExcelSourceReference | None = None


class SheetDiff(SdkModel):
    """All bounded differences for one worksheet."""

    sheet_name: NonEmptyString
    cell_diffs: tuple[CellDiff, ...] = ()
    feature_diffs: tuple[FeatureDiff, ...] = ()

    @model_validator(mode="after")
    def validate_nested_sheets(self) -> Self:
        """Keep every nested location on the sheet represented by this diff."""
        if any(item.sheet_name != self.sheet_name for item in self.cell_diffs):
            msg = "cell differences must match their containing sheet"
            raise ValueError(msg)
        for feature in self.feature_diffs:
            if any(
                source is not None and source.sheet_name != self.sheet_name
                for source in (feature.old_source, feature.new_source)
            ):
                msg = "worksheet feature sources must match their containing sheet"
                raise ValueError(msg)
        return self


class WorkbookDiff(SdkModel):
    """Bounded, serializable workbook comparison."""

    old_file: FileDescriptor
    new_file: FileDescriptor
    sheets_added: tuple[NonEmptyString, ...] = ()
    sheets_removed: tuple[NonEmptyString, ...] = ()
    sheet_diffs: tuple[SheetDiff, ...] = ()
    feature_diffs: tuple[FeatureDiff, ...] = ()
    difference_count: int = Field(ge=0)
    truncated: bool

    @model_validator(mode="after")
    def validate_difference_count(self) -> Self:
        """Validate bounded counts and old/new source identity across layers."""
        added_names = [name.casefold() for name in self.sheets_added]
        removed_names = [name.casefold() for name in self.sheets_removed]
        added = set(added_names)
        removed = set(removed_names)
        sheet_names = [sheet.sheet_name for sheet in self.sheet_diffs]
        normalized_sheet_names = [name.casefold() for name in sheet_names]
        if (
            len(added) != len(added_names)
            or len(removed) != len(removed_names)
            or added & removed
            or len(normalized_sheet_names) != len(set(normalized_sheet_names))
            or (added | removed) & set(normalized_sheet_names)
        ):
            msg = "workbook sheet difference groups must be unique and disjoint"
            raise ValueError(msg)

        features = list(self.feature_diffs)
        cells: list[CellDiff] = []
        for sheet in self.sheet_diffs:
            cells.extend(sheet.cell_diffs)
            features.extend(sheet.feature_diffs)
        old_sources = [
            source
            for source in (
                *(item.old_source for item in cells),
                *(item.old_source for item in features),
            )
            if source is not None
        ]
        new_sources = [
            source
            for source in (
                *(item.new_source for item in cells),
                *(item.new_source for item in features),
            )
            if source is not None
        ]
        if any(source.file_id != self.old_file.file_id for source in old_sources):
            msg = "old comparison sources must match old_file"
            raise ValueError(msg)
        if any(source.file_id != self.new_file.file_id for source in new_sources):
            msg = "new comparison sources must match new_file"
            raise ValueError(msg)

        returned_count = (
            len(self.sheets_added)
            + len(self.sheets_removed)
            + len(self.feature_diffs)
            + sum(
                len(sheet.cell_diffs) + len(sheet.feature_diffs)
                for sheet in self.sheet_diffs
            )
        )
        if self.difference_count != returned_count:
            msg = "difference_count must match returned workbook differences"
            raise ValueError(msg)
        return self


class TableDetectionOptions(SdkModel):
    """Deterministic thresholds for table-region candidates."""

    min_rows: int = Field(default=2, gt=0, le=MAX_EXCEL_ROW)
    min_columns: int = Field(default=2, gt=0, le=MAX_EXCEL_COLUMN)
    max_blank_rows: int = Field(default=0, ge=0, lt=MAX_EXCEL_ROW)
    max_blank_columns: int = Field(default=1, ge=0, lt=MAX_EXCEL_COLUMN)
    header_scan_rows: int = Field(default=3, gt=0, le=MAX_EXCEL_ROW)
    minimum_density: float = Field(default=0.2, gt=0, le=1)
    max_cells: int = Field(default=100_000, gt=0)


class TableRegionCandidate(SdkModel):
    """Evidence-backed deterministic table-region candidate."""

    cell_range: NonEmptyString
    header_row_candidates: tuple[ExcelRowNumber, ...]
    data_start_row: ExcelRowNumber | None
    data_end_row: ExcelRowNumber | None
    non_empty_cell_count: int = Field(gt=0)
    non_empty_density: float = Field(gt=0, le=1)
    merged_header_ranges: tuple[str, ...] = ()
    score: float = Field(ge=0, le=1)
    warnings: tuple[NonEmptyString, ...] = ()
    source: ExcelSourceReference

    @field_validator("cell_range")
    @classmethod
    def validate_cell_range(cls, value: str) -> str:
        """Normalize the candidate range."""
        return normalize_excel_range(value)

    @field_validator("merged_header_ranges")
    @classmethod
    def validate_merged_header_ranges(
        cls,
        value: tuple[str, ...],
    ) -> tuple[str, ...]:
        """Normalize merged-header evidence ranges."""
        return tuple(normalize_excel_range(item) for item in value)

    @model_validator(mode="after")
    def validate_source(self) -> Self:
        """Ensure candidate bounds, evidence, and source agree."""
        if self.source.cell_range != self.cell_range:
            msg = "table candidate source range must match cell_range"
            raise ValueError(msg)
        bounds = excel_range_bounds(self.cell_range)
        if tuple(sorted(set(self.header_row_candidates))) != (
            self.header_row_candidates
        ):
            msg = "table candidate header rows must be sorted and unique"
            raise ValueError(msg)
        if any(
            row < bounds.min_row or row > bounds.max_row
            for row in self.header_row_candidates
        ):
            msg = "table candidate header rows must be inside cell_range"
            raise ValueError(msg)
        if (self.data_start_row is None) != (self.data_end_row is None):
            msg = "table candidate data row bounds must both be present or absent"
            raise ValueError(msg)
        if (
            self.data_start_row is not None
            and self.data_end_row is not None
            and (
                self.data_start_row < bounds.min_row
                or self.data_end_row > bounds.max_row
                or self.data_start_row > self.data_end_row
            )
        ):
            msg = "table candidate data row bounds must be ordered inside range"
            raise ValueError(msg)
        if self.non_empty_cell_count > bounds.cell_count:
            msg = "table candidate non-empty count exceeds its range area"
            raise ValueError(msg)
        for merged_range in self.merged_header_ranges:
            merged = excel_range_bounds(merged_range)
            if (
                merged.max_row < bounds.min_row
                or merged.min_row > bounds.max_row
                or merged.max_column < bounds.min_column
                or merged.min_column > bounds.max_column
            ):
                msg = "merged-header evidence must intersect the candidate"
                raise ValueError(msg)
        expected_density = self.non_empty_cell_count / bounds.cell_count
        if not isclose(
            self.non_empty_density,
            expected_density,
            rel_tol=1e-9,
            abs_tol=1e-12,
        ):
            msg = "table candidate density must match its range and cell count"
            raise ValueError(msg)
        return self


class NormalizationOptions(SdkModel):
    """Explicit generic value normalization controls."""

    trim_whitespace: bool = True
    unicode_form: Literal["none", "NFC", "NFKC"] = "NFC"
    normalize_width: bool = False
    case: Literal["preserve", "lower", "upper", "casefold"] = "preserve"
    blank_values: tuple[str, ...] = ("",)
    thousands_separator: str = ","
    decimal_separator: str = "."
    true_values: tuple[str, ...] = ("true", "yes", "1")
    false_values: tuple[str, ...] = ("false", "no", "0")

    @model_validator(mode="after")
    def validate_options(self) -> Self:
        """Reject ambiguous numeric and boolean normalization controls."""
        if not self.decimal_separator:
            msg = "decimal_separator must not be empty"
            raise ValueError(msg)
        if (
            self.thousands_separator
            and self.thousands_separator == self.decimal_separator
        ):
            msg = "thousands_separator and decimal_separator must differ"
            raise ValueError(msg)

        def normalized_marker(value: str) -> str:
            normalized = value.strip() if self.trim_whitespace else value
            if self.unicode_form != "none":
                normalized = unicodedata.normalize(self.unicode_form, normalized)
            if self.normalize_width:
                normalized = unicodedata.normalize("NFKC", normalized)
            return normalized.casefold()

        true_values = {normalized_marker(value) for value in self.true_values}
        false_values = {normalized_marker(value) for value in self.false_values}
        if true_values & false_values:
            msg = "true_values and false_values must not overlap"
            raise ValueError(msg)
        blank_values = {normalized_marker(value) for value in self.blank_values}
        if blank_values & (true_values | false_values):
            msg = "blank_values must not overlap boolean markers"
            raise ValueError(msg)
        return self


class NormalizedValueResult(SdkModel):
    """Original and normalized representations of one scalar."""

    original_value: ExcelPatchScalar = None
    normalized_value: ExcelPatchScalar = None
    target_type: Literal[
        "auto",
        "string",
        "integer",
        "decimal",
        "percentage",
        "date",
        "datetime",
        "boolean",
    ]
    warnings: tuple[NonEmptyString, ...] = ()


class ColumnSchema(SdkModel):
    """Generic validation rules for one table column."""

    name: NonEmptyString
    data_type: Literal[
        "string",
        "integer",
        "decimal",
        "percentage",
        "date",
        "datetime",
        "boolean",
    ] = "string"
    required: bool = True
    nullable: bool = True
    unique: bool = False
    minimum: Decimal | date | datetime | None = None
    maximum: Decimal | date | datetime | None = None
    minimum_length: int | None = Field(default=None, ge=0)
    maximum_length: int | None = Field(default=None, ge=0)
    pattern: str | None = None
    allowed_values: tuple[ExcelPatchScalar, ...] = ()

    @field_validator("pattern")
    @classmethod
    def validate_pattern(cls, value: str | None) -> str | None:
        """Reject malformed regular expressions without echoing the pattern."""
        if value is not None:
            try:
                re.compile(value)
            except re.error as exc:
                msg = "pattern must be a valid regular expression"
                _raise_redacted_translation(exc, ValueError(msg))
        return value

    @model_validator(mode="after")
    def validate_bounds(self) -> Self:
        """Reject incompatible or reversed bounds."""
        if (
            self.minimum_length is not None
            and self.maximum_length is not None
            and self.minimum_length > self.maximum_length
        ):
            msg = "minimum_length must not exceed maximum_length"
            raise ValueError(msg)
        bounds = (self.minimum, self.maximum)
        if self.data_type in {"integer", "decimal", "percentage"}:
            compatible = all(
                bound is None or isinstance(bound, Decimal) for bound in bounds
            )
        elif self.data_type == "date":
            compatible = all(
                bound is None
                or (isinstance(bound, date) and not isinstance(bound, datetime))
                for bound in bounds
            )
        elif self.data_type == "datetime":
            compatible = all(
                bound is None or isinstance(bound, datetime) for bound in bounds
            )
        else:
            compatible = all(bound is None for bound in bounds)
        if not compatible:
            msg = "minimum and maximum must match the column data type"
            raise ValueError(msg)
        try:
            reversed_bounds = (
                (
                    isinstance(self.minimum, Decimal)
                    and isinstance(self.maximum, Decimal)
                    and self.minimum > self.maximum
                )
                or (
                    isinstance(self.minimum, datetime)
                    and isinstance(self.maximum, datetime)
                    and self.minimum > self.maximum
                )
                or (
                    isinstance(self.minimum, date)
                    and not isinstance(self.minimum, datetime)
                    and isinstance(self.maximum, date)
                    and not isinstance(self.maximum, datetime)
                    and self.minimum > self.maximum
                )
            )
        except TypeError as exc:
            msg = "minimum and maximum must use compatible timezone awareness"
            _raise_redacted_translation(exc, ValueError(msg))
        if reversed_bounds:
            msg = "minimum must not exceed maximum"
            raise ValueError(msg)
        return self


class TableSchema(SdkModel):
    """Generic table schema without customer business rules."""

    columns: tuple[ColumnSchema, ...] = Field(min_length=1)
    header_row: ExcelRowNumber
    allow_extra_columns: bool = True
    require_unique_rows: bool = False

    @model_validator(mode="after")
    def validate_columns(self) -> Self:
        """Reject duplicate schema columns."""
        names = [column.name.casefold() for column in self.columns]
        if len(names) != len(set(names)):
            msg = "table schema column names must be unique"
            raise ValueError(msg)
        return self


class NormalizedCell(SdkModel):
    """One normalized table cell with source traceability."""

    column_name: NonEmptyString
    original_value: ExcelPatchScalar = None
    normalized_value: ExcelPatchScalar = None
    source: ExcelSourceReference


class NormalizedRow(SdkModel):
    """One normalized table row."""

    row_number: ExcelRowNumber
    cells: tuple[NormalizedCell, ...]

    @model_validator(mode="after")
    def validate_cells(self) -> Self:
        """Ensure normalized cells are unique and belong to this row."""
        names = [cell.column_name.casefold() for cell in self.cells]
        coordinates = [cell.source.cell_range for cell in self.cells]
        if len(names) != len(set(names)) or len(coordinates) != len(set(coordinates)):
            msg = "normalized row cells must have unique columns and coordinates"
            raise ValueError(msg)
        if any(
            ":" in cell.source.cell_range
            or excel_range_bounds(cell.source.cell_range).min_row != self.row_number
            for cell in self.cells
        ):
            msg = "normalized row cell sources must be cells on row_number"
            raise ValueError(msg)
        return self


class ValidationIssue(SdkModel):
    """One generic validation issue at a traceable source cell."""

    code: NonEmptyString
    message: NonEmptyString
    severity: Literal["error", "warning"] = "error"
    column_name: str | None = None
    source: ExcelSourceReference
    original_value: ExcelPatchScalar = None
    normalized_value: ExcelPatchScalar = None


class TableValidationResult(SdkModel):
    """Normalized rows and deterministic generic schema issues."""

    valid: bool
    table_schema: TableSchema
    rows: tuple[NormalizedRow, ...]
    issues: tuple[ValidationIssue, ...]
    source_file: FileDescriptor
    sheet_name: NonEmptyString

    @model_validator(mode="after")
    def validate_status(self) -> Self:
        """Ensure status and all nested source identities remain traceable."""
        expected = not any(issue.severity == "error" for issue in self.issues)
        if self.valid != expected:
            msg = "valid must reflect whether validation errors are present"
            raise ValueError(msg)
        if any(row.row_number <= self.table_schema.header_row for row in self.rows):
            msg = "normalized table rows must follow the schema header row"
            raise ValueError(msg)
        row_numbers = tuple(row.row_number for row in self.rows)
        if row_numbers != tuple(sorted(set(row_numbers))):
            msg = "normalized table rows must be ordered and unique"
            raise ValueError(msg)
        schema_names = {column.name.casefold() for column in self.table_schema.columns}
        if any(
            cell.column_name.casefold() not in schema_names
            for row in self.rows
            for cell in row.cells
        ):
            msg = "normalized cells must belong to the table schema"
            raise ValueError(msg)
        if any(
            issue.column_name is not None
            and issue.column_name.casefold() not in schema_names
            for issue in self.issues
        ):
            msg = "validation issue columns must belong to the table schema"
            raise ValueError(msg)
        if any(":" in issue.source.cell_range for issue in self.issues):
            msg = "validation issues must identify one source cell"
            raise ValueError(msg)
        nested_sources = [cell.source for row in self.rows for cell in row.cells] + [
            issue.source for issue in self.issues
        ]
        if any(
            source.file_id != self.source_file.file_id
            or source.sheet_name != self.sheet_name
            for source in nested_sources
        ):
            msg = "table validation sources must match the result file and sheet"
            raise ValueError(msg)
        return self

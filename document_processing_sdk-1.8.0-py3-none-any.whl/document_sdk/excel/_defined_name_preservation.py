"""Preserve workbook-defined names across third-party cell rewrites."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import TYPE_CHECKING
from xml.dom import minidom

from document_sdk.excel._column_modification import (
    _copy_package,
    _direct_elements,
    _document_root,
    _spreadsheet_element,
)
from document_sdk.excel._package import _SafePackage
from document_sdk.excel._package_worksheet import (
    _SPREADSHEETML_WORKSHEET_NAMESPACES,
)
from document_sdk.excel.errors import ExcelModificationError
from document_sdk.files import calculate_sha256

if TYPE_CHECKING:
    from collections.abc import Sequence
    from xml.dom.minidom import Document, Element

    from document_sdk.excel.models import DefinedNamePatch


_WORKBOOK_MEMBER = "xl/workbook.xml"
_DEFINED_NAMES_SUCCESSORS = frozenset(
    {
        "calcPr",
        "oleSize",
        "customWorkbookViews",
        "pivotCaches",
        "smartTagPr",
        "smartTagTypes",
        "webPublishing",
        "fileRecoveryPr",
        "webPublishObjects",
        "extLst",
    }
)


@dataclass(frozen=True, slots=True)
class _PendingDefinedNameChange:
    """One defined-name change before public file identities are known."""

    name: str
    operation: str
    scope_sheet_name: str | None
    old_formula: str | None
    new_formula: str | None
    old_hidden: bool | None
    new_hidden: bool | None


def _workbook_document(payload: bytes) -> tuple[Document, Element, str]:
    document = minidom.parseString(  # noqa: S318 - bounded, DTD-screened OOXML.
        payload
    )
    root = _document_root(document)
    namespace = root.namespaceURI
    if namespace not in _SPREADSHEETML_WORKSHEET_NAMESPACES:
        msg = "Workbook XML namespace is unsupported"
        raise ValueError(msg)
    return document, root, namespace


def _defined_names(root: Element, namespace: str) -> Element | None:
    matches = tuple(
        element
        for element in _direct_elements(root)
        if _spreadsheet_element(element, "definedNames", namespace)
    )
    if len(matches) > 1:
        msg = "Workbook contains duplicate defined-name containers"
        raise ValueError(msg)
    return matches[0] if matches else None


def _insert_defined_names(
    document: Document,
    root: Element,
    namespace: str,
    source_names: Element,
) -> Element:
    imported = document.importNode(source_names, deep=True)
    reference = next(
        (
            child
            for child in _direct_elements(root)
            if child.namespaceURI == namespace
            and child.localName in _DEFINED_NAMES_SUCCESSORS
        ),
        None,
    )
    root.insertBefore(imported, reference)
    return imported


def _remap_local_sheet_ids(
    container: Element,
    namespace: str,
    *,
    source_sheet_names: tuple[str, ...],
    output_sheet_names: tuple[str, ...],
) -> None:
    output_indexes = {name: index for index, name in enumerate(output_sheet_names)}
    if len(output_indexes) != len(output_sheet_names):
        msg = "Patched workbook contains duplicate worksheet names"
        raise ExcelModificationError(msg)
    for definition in _definition_elements(container, namespace):
        if not definition.hasAttribute("localSheetId"):
            continue
        try:
            source_index = int(definition.getAttribute("localSheetId"))
            source_sheet_name = source_sheet_names[source_index]
            output_index = output_indexes[source_sheet_name]
        except (IndexError, KeyError, ValueError):
            msg = "Workbook defined name scope worksheet does not exist"
            raise ExcelModificationError(msg) from None
        definition.setAttribute("localSheetId", str(output_index))


def _sheet_names(root: Element, namespace: str) -> tuple[str, ...]:
    sheets = next(
        (
            child
            for child in _direct_elements(root)
            if _spreadsheet_element(child, "sheets", namespace)
        ),
        None,
    )
    if sheets is None:
        return ()
    return tuple(
        child.getAttribute("name")
        for child in _direct_elements(sheets)
        if _spreadsheet_element(child, "sheet", namespace)
    )


def _definition_text(element: Element) -> str:
    return "".join(
        child.data for child in element.childNodes if isinstance(child, minidom.Text)
    )


def _definition_hidden(element: Element) -> bool:
    return element.getAttribute("hidden") in {"1", "true"}


def _definition_key(element: Element) -> tuple[str, str | None]:
    scope = element.getAttribute("localSheetId")
    return (
        element.getAttribute("name").casefold(),
        scope if element.hasAttribute("localSheetId") else None,
    )


def _definition_elements(container: Element, namespace: str) -> tuple[Element, ...]:
    return tuple(
        child
        for child in _direct_elements(container)
        if _spreadsheet_element(child, "definedName", namespace)
    )


def workbook_defined_name_identity_counts(
    path: Path,
) -> dict[tuple[str, str | None], int]:
    """Return bounded case-insensitive name/scope identities from workbook XML."""
    with (
        _SafePackage(path) as package,
        package.open_xml_stream(_WORKBOOK_MEMBER) as stream,
    ):
        payload = stream.read()
    _document, root, namespace = _workbook_document(payload)
    sheet_names = _sheet_names(root, namespace)
    container = _defined_names(root, namespace)
    definitions = (
        () if container is None else _definition_elements(container, namespace)
    )
    counts: dict[tuple[str, str | None], int] = {}
    for definition in definitions:
        local_id = (
            definition.getAttribute("localSheetId")
            if definition.hasAttribute("localSheetId")
            else None
        )
        try:
            scope = None if local_id is None else sheet_names[int(local_id)]
        except (IndexError, ValueError):
            msg = "Workbook defined name scope worksheet does not exist"
            raise ExcelModificationError(msg) from None
        identity = (
            definition.getAttribute("name").casefold(),
            None if scope is None else scope.casefold(),
        )
        counts[identity] = counts.get(identity, 0) + 1
    return counts


def _create_defined_names_container(
    document: Document,
    root: Element,
    namespace: str,
) -> Element:
    container = document.createElementNS(namespace, "definedNames")
    reference = next(
        (
            child
            for child in _direct_elements(root)
            if child.namespaceURI == namespace
            and child.localName in _DEFINED_NAMES_SUCCESSORS
        ),
        None,
    )
    root.insertBefore(container, reference)
    return container


def _replace_definition_text(
    document: Document,
    element: Element,
    formula: str,
) -> None:
    while element.firstChild is not None:
        element.removeChild(element.firstChild)
    element.appendChild(document.createTextNode(formula))


def _apply_defined_name_payload(  # noqa: C901, PLR0912, PLR0915
    payload: bytes,
    patches: Sequence[DefinedNamePatch],
) -> tuple[bytes, tuple[_PendingDefinedNameChange, ...]]:
    document, root, namespace = _workbook_document(payload)
    sheet_names = _sheet_names(root, namespace)
    sheet_indexes = {name: index for index, name in enumerate(sheet_names)}
    container = _defined_names(root, namespace)
    pending: list[_PendingDefinedNameChange] = []
    for patch in patches:
        scope_index: str | None = None
        if patch.scope_sheet_name is not None:
            if patch.scope_sheet_name not in sheet_indexes:
                msg = "Workbook defined name scope worksheet does not exist"
                raise ExcelModificationError(msg)
            scope_index = str(sheet_indexes[patch.scope_sheet_name])
        definitions = (
            () if container is None else _definition_elements(container, namespace)
        )
        matches = [
            item
            for item in definitions
            if _definition_key(item) == (patch.name.casefold(), scope_index)
        ]
        if len(matches) > 1:
            msg = "Workbook contains duplicate defined name identities"
            raise ExcelModificationError(msg)
        existing = matches[0] if matches else None
        if patch.operation == "create":
            if existing is not None:
                msg = "Workbook defined name create target already exists"
                raise ExcelModificationError(msg)
            if container is None:
                container = _create_defined_names_container(document, root, namespace)
            created = document.createElementNS(namespace, "definedName")
            created.setAttribute("name", patch.name)
            if scope_index is not None:
                created.setAttribute("localSheetId", scope_index)
            if patch.hidden:
                created.setAttribute("hidden", "1")
            _replace_definition_text(document, created, patch.formula or "")
            container.appendChild(created)
            pending.append(
                _PendingDefinedNameChange(
                    name=patch.name,
                    operation="create",
                    scope_sheet_name=patch.scope_sheet_name,
                    old_formula=None,
                    new_formula=patch.formula,
                    old_hidden=None,
                    new_hidden=patch.hidden,
                )
            )
            continue
        if existing is None:
            msg = "Workbook defined name patch target does not exist"
            raise ExcelModificationError(msg)
        old_formula = _definition_text(existing)
        old_hidden = _definition_hidden(existing)
        if patch.operation == "delete":
            if container is None:  # pragma: no cover - existing invariant.
                msg = "Workbook defined name container is missing"
                raise ExcelModificationError(msg)
            container.removeChild(existing)
            if not _definition_elements(container, namespace):
                root.removeChild(container)
                container = None
            pending.append(
                _PendingDefinedNameChange(
                    name=patch.name,
                    operation="delete",
                    scope_sheet_name=patch.scope_sheet_name,
                    old_formula=old_formula,
                    new_formula=None,
                    old_hidden=old_hidden,
                    new_hidden=None,
                )
            )
            continue
        if old_formula == patch.formula and old_hidden == patch.hidden:
            continue
        _replace_definition_text(document, existing, patch.formula or "")
        if patch.hidden:
            existing.setAttribute("hidden", "1")
        elif existing.hasAttribute("hidden"):
            existing.removeAttribute("hidden")
        pending.append(
            _PendingDefinedNameChange(
                name=patch.name,
                operation="update",
                scope_sheet_name=patch.scope_sheet_name,
                old_formula=old_formula,
                new_formula=patch.formula,
                old_hidden=old_hidden,
                new_hidden=patch.hidden,
            )
        )
    return document.toxml(encoding="utf-8"), tuple(pending)


def _restore_defined_names_payload(source: bytes, output: bytes) -> bytes:
    _source_document, source_root, source_namespace = _workbook_document(source)
    output_document, output_root, output_namespace = _workbook_document(output)
    if source_namespace != output_namespace:
        msg = "Patched workbook XML namespace changed"
        raise ExcelModificationError(msg)

    source_names = _defined_names(source_root, source_namespace)
    output_names = _defined_names(output_root, output_namespace)
    if output_names is not None:
        output_root.removeChild(output_names)
    if source_names is not None:
        imported = _insert_defined_names(
            output_document,
            output_root,
            output_namespace,
            source_names,
        )
        _remap_local_sheet_ids(
            imported,
            output_namespace,
            source_sheet_names=_sheet_names(source_root, source_namespace),
            output_sheet_names=_sheet_names(output_root, output_namespace),
        )
    return output_document.toxml(encoding="utf-8")


def preserve_workbook_defined_names(
    source_path: Path,
    output_path: Path,
    *,
    source_fingerprint: str,
) -> None:
    """Restore source defined-name XML after a cell-only backend rewrite."""
    with _SafePackage(source_path) as source_package:
        source_package.verify_fingerprint(source_fingerprint)
        with source_package.open_xml_stream(_WORKBOOK_MEMBER) as stream:
            source_payload = stream.read()
    with (
        _SafePackage(output_path) as output_package,
        output_package.open_xml_stream(_WORKBOOK_MEMBER) as stream,
    ):
        output_payload = stream.read()

    replacement = _restore_defined_names_payload(source_payload, output_payload)
    with NamedTemporaryFile(
        dir=output_path.parent,
        prefix=f".{output_path.name}.defined-names.",
        suffix=output_path.suffix,
        delete=False,
    ) as temporary_file:
        replacement_path = Path(temporary_file.name)
    try:
        _copy_package(
            output_path,
            replacement_path,
            {_WORKBOOK_MEMBER: replacement},
            source_fingerprint=calculate_sha256(output_path).value,
        )
        os.replace(replacement_path, output_path)  # noqa: PTH105 - atomic API.
    finally:
        replacement_path.unlink(missing_ok=True)

    with (
        _SafePackage(output_path) as output_package,
        output_package.open_xml_stream(_WORKBOOK_MEMBER) as stream,
    ):
        verified_payload = stream.read()
    _verified_document, verified_root, verified_namespace = _workbook_document(
        verified_payload
    )
    _expected_document, expected_root, expected_namespace = _workbook_document(
        replacement
    )
    verified_names = _defined_names(verified_root, verified_namespace)
    expected_names = _defined_names(expected_root, expected_namespace)
    verified_xml = None if verified_names is None else verified_names.toxml()
    expected_xml = None if expected_names is None else expected_names.toxml()
    if verified_xml != expected_xml:
        msg = "Patched workbook defined-name preservation verification failed"
        raise ExcelModificationError(msg)


def apply_workbook_defined_name_patches(
    path: Path,
    patches: Sequence[DefinedNamePatch],
) -> tuple[_PendingDefinedNameChange, ...]:
    """Apply and verify bounded defined-name edits to one output package."""
    if not patches:
        return ()
    with (
        _SafePackage(path) as package,
        package.open_xml_stream(_WORKBOOK_MEMBER) as stream,
    ):
        payload = stream.read()
    replacement, pending = _apply_defined_name_payload(payload, patches)
    if not pending:
        return ()

    with NamedTemporaryFile(
        dir=path.parent,
        prefix=f".{path.name}.defined-name-patches.",
        suffix=path.suffix,
        delete=False,
    ) as temporary_file:
        replacement_path = Path(temporary_file.name)
    try:
        _copy_package(
            path,
            replacement_path,
            {_WORKBOOK_MEMBER: replacement},
            source_fingerprint=calculate_sha256(path).value,
        )
        os.replace(replacement_path, path)  # noqa: PTH105 - atomic API.
    finally:
        replacement_path.unlink(missing_ok=True)

    with (
        _SafePackage(path) as package,
        package.open_xml_stream(_WORKBOOK_MEMBER) as stream,
    ):
        verified_payload = stream.read()
    _verified, verified_pending = _apply_defined_name_payload(verified_payload, ())
    if verified_pending:
        msg = "Patched workbook defined-name verification failed"
        raise ExcelModificationError(msg)
    verified_document, verified_root, verified_namespace = _workbook_document(
        verified_payload
    )
    del verified_document
    sheet_names = _sheet_names(verified_root, verified_namespace)
    sheet_indexes = {name: index for index, name in enumerate(sheet_names)}
    container = _defined_names(verified_root, verified_namespace)
    definitions = (
        () if container is None else _definition_elements(container, verified_namespace)
    )
    states = {
        _definition_key(item): (_definition_text(item), _definition_hidden(item))
        for item in definitions
    }
    for change in pending:
        scope_index = (
            None
            if change.scope_sheet_name is None
            else str(sheet_indexes[change.scope_sheet_name])
        )
        state = states.get((change.name.casefold(), scope_index))
        expected = (
            None
            if change.operation == "delete"
            else (change.new_formula, change.new_hidden)
        )
        if state != expected:
            msg = "Patched workbook defined-name verification failed"
            raise ExcelModificationError(msg)
    return pending

# ruff: noqa: BLE001, C901, PLR0911, PLR0912, PLR0913, PLR0915
"""Private sparse OOXML cell streaming primitives."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, time
from hashlib import sha256
from pathlib import PurePosixPath
from typing import TYPE_CHECKING
from xml.etree.ElementTree import iterparse
from zipfile import ZipFile

from document_sdk.core import (
    DocumentProcessingError,
    DocumentSdkError,
    ExcelTemporalSource,
)
from document_sdk.core._excel_coordinates import (
    MAX_EXCEL_ROW,
    ExcelRangeBounds,
    excel_column_letter,
    excel_range_bounds,
    normalize_excel_coordinate,
)
from document_sdk.core.errors import _raise_redacted_translation, safe_file_label
from document_sdk.excel._ooxml import _ensure_no_dtd, _local_name
from document_sdk.excel._package_security import _resolve_target
from document_sdk.excel._visible_text import _visible_text
from document_sdk.excel._worksheet_xml import (
    _validate_cell_type,
    _worksheet_child,
    _worksheet_events,
)
from document_sdk.excel.errors import ExcelPackageLimitError
from document_sdk.excel.formula import (
    _dynamic_metadata_indexes,
    _formula_kind,
    _has_external_reference,
)
from document_sdk.excel.models import ExcelPackageLimits

if TYPE_CHECKING:
    from collections.abc import Iterator
    from pathlib import Path
    from typing import BinaryIO
    from xml.etree.ElementTree import Element

    from document_sdk.excel.models import FormulaKind


_MAX_PACKAGE_MEMBERS = 10_000
_MAX_TOTAL_UNCOMPRESSED_BYTES = 512 * 1024 * 1024
_MAX_XML_MEMBER_BYTES = 64 * 1024 * 1024
_MAX_COMPRESSION_RATIO = 1_000
_MAX_CELL_STYLES = 100_000
_MAX_CUSTOM_NUMBER_FORMATS = 100_000
_FINGERPRINT_CHUNK_SIZE = 1024 * 1024
_ROW_PARENT_STACK_DEPTH = 2

type _ExcelValue = str | int | float | bool | date | datetime | time | None


@dataclass(frozen=True, slots=True)
class _Relationship:
    """One safe internal OOXML relationship."""

    target: str
    relationship_type: str
    external: bool


@dataclass(frozen=True, slots=True)
class _PackageInfo:
    """Members needed to stream one worksheet."""

    worksheet_member: str
    shared_strings_member: str | None
    styles_member: str | None
    date_1904: bool


@dataclass(frozen=True, slots=True)
class _RawCell:
    """One represented OOXML cell before formula-view projection."""

    coordinate: str
    value: _ExcelValue
    formula: str | None
    cached_value: _ExcelValue
    has_cached_value: bool
    data_type: str
    cached_data_type: str
    style_id: int
    number_format: str | None
    formula_kind: FormulaKind | None
    external_reference: bool
    has_content: bool
    temporal_source: ExcelTemporalSource | None = None


@dataclass(frozen=True, slots=True)
class _CellStyle:
    """Number-format facts for one indexed OOXML cell style."""

    number_format: str | None
    date_like: bool


def _attribute(element: Element, local_name: str) -> str | None:
    """Return an attribute independent of its namespace prefix."""
    for name, value in element.attrib.items():
        if _local_name(name) == local_name:
            return value
    return None


def _resolve_member(target: str) -> str:
    """Resolve workbook relationships within the package, including its root."""
    return _resolve_target("xl/workbook.xml", target)


def _preflight_archive(
    archive: ZipFile,
    limits: ExcelPackageLimits | None = None,
) -> None:
    """Reject unsafe OOXML expansion before opening package members."""
    infos = archive.infolist()
    member_limit = _MAX_PACKAGE_MEMBERS if limits is None else limits.package_members
    total_limit = (
        _MAX_TOTAL_UNCOMPRESSED_BYTES
        if limits is None
        else limits.total_uncompressed_bytes
    )
    ratio_limit = _MAX_COMPRESSION_RATIO if limits is None else limits.compression_ratio
    if len(infos) > member_limit:
        raise ExcelPackageLimitError(
            limit_name="member_count",
            observed=len(infos),
            maximum=member_limit,
        )

    names: set[str] = set()
    total_size = 0
    for info in infos:
        name = info.filename
        path = PurePosixPath(name)
        if (
            "\x00" in name
            or "\\" in name
            or path.is_absolute()
            or any(part in {"", ".", ".."} for part in path.parts)
        ):
            msg = "workbook package contains an unsafe member name"
            raise ValueError(msg)
        if name in names:
            msg = "workbook package contains duplicate member names"
            raise ValueError(msg)
        names.add(name)
        if info.flag_bits & 0x1:
            msg = "encrypted workbook package members are unsupported"
            raise ValueError(msg)
        total_size += info.file_size
        if total_size > total_limit:
            raise ExcelPackageLimitError(
                limit_name="total_uncompressed_bytes",
                observed=total_size,
                maximum=total_limit,
            )
        ratio = info.file_size // max(info.compress_size, 1)
        if ratio > ratio_limit:
            raise ExcelPackageLimitError(
                limit_name="compression_ratio",
                observed=ratio,
                maximum=ratio_limit,
            )


def _ensure_bounded_xml_member(
    archive: ZipFile,
    member: str,
    limits: ExcelPackageLimits | None = None,
) -> None:
    """Enforce an XML member size limit before decompression."""
    info = archive.getinfo(member)
    maximum = _MAX_XML_MEMBER_BYTES if limits is None else limits.xml_member_bytes
    if info.file_size > maximum:
        raise ExcelPackageLimitError(
            limit_name="xml_member_bytes",
            observed=info.file_size,
            maximum=maximum,
        )


def _package_info(
    archive: ZipFile,
    sheet_name: str,
    limits: ExcelPackageLimits | None = None,
    *,
    source_only: bool = False,
) -> _PackageInfo:
    """Resolve one worksheet and its supporting package members."""
    workbook_member = "xl/workbook.xml"
    _ensure_bounded_xml_member(archive, workbook_member, limits)
    _ensure_no_dtd(archive, workbook_member)

    relationship_id: str | None = None
    date_1904 = False
    sheet_names: set[str] = set()
    sheet_relationship_ids: set[str] = set()
    with archive.open(workbook_member) as stream:
        for _event, element in iterparse(  # noqa: S314 - DTD rejected above.
            stream,
            events=("end",),
        ):
            name = _local_name(element.tag)
            if name == "workbookPr":
                date_1904 = element.attrib.get("date1904") in {"1", "true", "on"}
            elif name == "sheet":
                candidate_name = element.attrib.get("name")
                candidate_relationship = _attribute(element, "id")
                if not candidate_name or not candidate_relationship:
                    msg = "workbook contains an invalid sheet reference"
                    raise ValueError(msg)
                normalized_name = candidate_name.casefold()
                if (
                    normalized_name in sheet_names
                    or candidate_relationship in sheet_relationship_ids
                ):
                    msg = "workbook contains duplicate sheet references"
                    raise ValueError(msg)
                sheet_names.add(normalized_name)
                sheet_relationship_ids.add(candidate_relationship)
                if candidate_name == sheet_name:
                    relationship_id = candidate_relationship
            element.clear()

    if relationship_id is None:
        msg = f"Worksheet does not exist: {sheet_name}"
        raise DocumentProcessingError(msg)

    relationships = _workbook_relationships(archive, limits)
    worksheet_relationship = relationships.get(relationship_id)
    if (
        worksheet_relationship is None
        or worksheet_relationship.external
        or not worksheet_relationship.relationship_type.endswith("/worksheet")
    ):
        msg = "workbook contains an unsupported sheet relationship"
        raise DocumentProcessingError(msg)

    shared_strings_member, styles_member = (
        (None, None) if source_only else _support_members(relationships)
    )
    worksheet_member = _resolve_member(worksheet_relationship.target)
    # Keep the existing worksheet-directory policy; S04 concerns support parts.
    if not worksheet_member.startswith("xl/"):
        msg = "workbook worksheet target is outside the supported directory"
        raise ValueError(msg)
    if worksheet_member not in archive.namelist():
        msg = "workbook worksheet part does not exist"
        raise DocumentProcessingError(msg)
    return _PackageInfo(
        worksheet_member=worksheet_member,
        shared_strings_member=shared_strings_member,
        styles_member=styles_member,
        date_1904=date_1904,
    )


def _workbook_relationships(
    archive: ZipFile,
    limits: ExcelPackageLimits | None = None,
) -> dict[str, _Relationship]:
    """Read bounded relationship declarations without opening support content."""
    relationships_member = "xl/_rels/workbook.xml.rels"
    _ensure_bounded_xml_member(archive, relationships_member, limits)
    _ensure_no_dtd(archive, relationships_member)
    relationships: dict[str, _Relationship] = {}
    with archive.open(relationships_member) as stream:
        for _event, element in iterparse(  # noqa: S314 - DTD rejected above.
            stream,
            events=("end",),
        ):
            if _local_name(element.tag) != "Relationship":
                continue
            identifier = element.attrib.get("Id")
            target = element.attrib.get("Target")
            relationship_type = element.attrib.get("Type")
            if not identifier or not target or not relationship_type:
                msg = "workbook contains an invalid relationship"
                raise ValueError(msg)
            if identifier in relationships:
                msg = "workbook contains duplicate relationship identifiers"
                raise ValueError(msg)
            target_mode = element.attrib.get("TargetMode")
            if target_mode not in {None, "Internal", "External"}:
                msg = "workbook relationship has an invalid target mode"
                raise ValueError(msg)
            relationships[identifier] = _Relationship(
                target=target,
                relationship_type=relationship_type,
                external=target_mode == "External",
            )
            element.clear()

    return relationships


def _support_members(
    relationships: dict[str, _Relationship],
) -> tuple[str | None, str | None]:
    """Resolve the single internal shared-string and style declarations."""
    support_members: dict[str, str] = {}
    for relationship in relationships.values():
        kind = relationship.relationship_type.rsplit("/", 1)[-1]
        if kind not in {"sharedStrings", "styles"}:
            continue
        if relationship.external or kind in support_members:
            msg = "workbook contains an invalid supporting-part relationship"
            raise ValueError(msg)
        support_members[kind] = _resolve_member(relationship.target)
    return support_members.get("sharedStrings"), support_members.get("styles")


def _shared_strings(
    archive: ZipFile,
    member: str | None,
    limits: ExcelPackageLimits | None = None,
) -> tuple[str, ...]:
    """Read shared strings in their indexed OOXML order."""
    if member is None:
        return ()
    _ensure_bounded_xml_member(archive, member, limits)
    _ensure_no_dtd(archive, member)
    maximum = (
        ExcelPackageLimits().shared_string_entries
        if limits is None
        else limits.shared_string_entries
    )
    values: list[str] = []
    with archive.open(member) as stream:
        for _event, element in iterparse(  # noqa: S314 - DTD rejected above.
            stream,
            events=("end",),
        ):
            if _local_name(element.tag) != "si":
                continue
            visible = _visible_text(
                element,
                container="si",
                label="Shared String",
            )
            values.append(visible.value)
            if len(values) > maximum:
                raise ExcelPackageLimitError(
                    limit_name="shared_string_entries",
                    observed=len(values),
                    maximum=maximum,
                )
            element.clear()
    return tuple(values)


def _cell_styles(
    archive: ZipFile,
    member: str | None,
    limits: ExcelPackageLimits | None = None,
) -> tuple[_CellStyle, ...]:
    """Return number-format facts for indexed cell styles."""
    if member is None:
        return ()

    from openpyxl.styles.numbers import BUILTIN_FORMATS, is_date_format

    _ensure_bounded_xml_member(archive, member, limits)
    _ensure_no_dtd(archive, member)
    custom_formats: dict[int, str] = {}
    styles: list[_CellStyle] = []
    in_cell_xfs = False
    with archive.open(member) as stream:
        for event, element in iterparse(  # noqa: S314 - DTD rejected above.
            stream,
            events=("start", "end"),
        ):
            name = _local_name(element.tag)
            if event == "start" and name == "cellXfs":
                in_cell_xfs = True
                continue
            if event == "end" and name == "numFmt":
                num_format_id_text = element.attrib.get("numFmtId")
                format_code = element.attrib.get("formatCode")
                if num_format_id_text is not None and format_code is not None:
                    custom_formats[int(num_format_id_text)] = format_code
                    if len(custom_formats) > _MAX_CUSTOM_NUMBER_FORMATS:
                        raise ExcelPackageLimitError(
                            limit_name="custom_number_formats",
                            observed=len(custom_formats),
                            maximum=_MAX_CUSTOM_NUMBER_FORMATS,
                        )
                element.clear()
            elif event == "end" and name == "xf" and in_cell_xfs:
                num_format_id = int(element.attrib.get("numFmtId", "0"))
                format_code = custom_formats.get(
                    num_format_id,
                    BUILTIN_FORMATS.get(num_format_id),
                )
                styles.append(
                    _CellStyle(
                        number_format=format_code,
                        date_like=bool(format_code and is_date_format(format_code)),
                    )
                )
                if len(styles) > _MAX_CELL_STYLES:
                    raise ExcelPackageLimitError(
                        limit_name="cell_styles",
                        observed=len(styles),
                        maximum=_MAX_CELL_STYLES,
                    )
                element.clear()
            elif event == "end" and name == "cellXfs":
                in_cell_xfs = False
                element.clear()
    return tuple(styles)


def _numeric_value(
    value: str,
    *,
    style_id: int,
    styles: tuple[_CellStyle, ...],
    date_1904: bool,
) -> _ExcelValue:
    """Normalize one OOXML numeric lexical value."""
    if "." not in value and "e" not in value.lower():
        number: int | float = int(value)
    else:
        number = float(value)
    if style_id >= len(styles) or not styles[style_id].date_like:
        return number

    from openpyxl.utils.datetime import (
        CALENDAR_MAC_1904,
        CALENDAR_WINDOWS_1900,
        from_excel,
    )

    epoch = CALENDAR_MAC_1904 if date_1904 else CALENDAR_WINDOWS_1900
    converted = from_excel(number, epoch)
    if isinstance(converted, (datetime, date, time)):
        return converted
    return number


def _parse_value(
    *,
    data_type: str | None,
    value_text: str,
    inline_text: str | None,
    shared_strings: tuple[str, ...],
    style_id: int,
    styles: tuple[_CellStyle, ...],
    date_1904: bool,
) -> tuple[_ExcelValue, str]:
    """Normalize one represented ordinary or cached OOXML value."""
    if data_type == "inlineStr":
        return inline_text or "", "s"
    if data_type == "s":
        index = int(value_text)
        if index < 0:
            msg = "worksheet references a missing shared string"
            raise ValueError(msg)
        try:
            return shared_strings[index], "s"
        except IndexError:
            msg = "worksheet references a missing shared string"
            raise ValueError(msg) from None
    if data_type == "b":
        if value_text not in {"0", "1"}:
            msg = "worksheet contains an invalid boolean cell"
            raise ValueError(msg)
        return value_text == "1", "b"
    if data_type in {"str", "e"}:
        return value_text, "s" if data_type == "str" else "e"
    if data_type == "d":
        if "T" in value_text:
            return datetime.fromisoformat(value_text), "d"
        if ":" in value_text:
            return time.fromisoformat(value_text), "d"
        return date.fromisoformat(value_text), "d"
    return (
        _numeric_value(
            value_text,
            style_id=style_id,
            styles=styles,
            date_1904=date_1904,
        ),
        "d" if style_id < len(styles) and styles[style_id].date_like else "n",
    )


def _cell_coordinate(
    element: Element,
    *,
    current_row: int | None,
    previous_column: int,
) -> tuple[str, int]:
    """Normalize an explicit or inferred worksheet cell coordinate."""
    if current_row is None:
        msg = "worksheet cell is outside a row"
        raise ValueError(msg)
    coordinate = element.attrib.get("r")
    if coordinate is None:
        column = previous_column + 1
        coordinate = f"{excel_column_letter(column)}{current_row}"
        return coordinate, column
    normalized = normalize_excel_coordinate(coordinate)
    bounds = excel_range_bounds(normalized)
    if bounds.min_row != current_row:
        msg = "worksheet cell coordinate does not match its row"
        raise ValueError(msg)
    return normalized, bounds.min_column


def _formula_text(
    element: Element,
    coordinate: str,
    shared_formulas: dict[str, tuple[str, str]],
) -> str:
    """Return an ordinary or translated shared formula with a leading equals."""
    text = element.text or ""
    formula = text if text.startswith("=") else f"={text}"
    if element.attrib.get("t") != "shared":
        return formula

    shared_index = element.attrib.get("si")
    if shared_index is None:
        msg = "shared formula is missing its index"
        raise ValueError(msg)
    if text:
        shared_formulas[shared_index] = (coordinate, formula)
        return formula
    try:
        origin, base_formula = shared_formulas[shared_index]
    except KeyError:
        msg = "shared formula base does not precede its dependents"
        raise ValueError(msg) from None

    from openpyxl.formula.translate import Translator

    translated = Translator(base_formula, origin=origin).translate_formula(coordinate)
    if not isinstance(translated, str):
        msg = "shared formula translation returned invalid text"
        raise TypeError(msg)
    return translated


def _cell_is_selected(
    bounds: ExcelRangeBounds,
    selected_ranges: tuple[ExcelRangeBounds, ...],
) -> bool:
    """Return whether one cell falls inside the optional range union."""
    return not selected_ranges or any(
        selected.min_row <= bounds.min_row <= selected.max_row
        and selected.min_column <= bounds.min_column <= selected.max_column
        for selected in selected_ranges
    )


def _next_selected_coordinate(
    coordinates: Iterator[str] | None,
) -> tuple[int, int] | None:
    """Advance one trusted, sorted coordinate iterator without retaining it."""
    coordinate = None if coordinates is None else next(coordinates, None)
    if coordinate is None:
        return None
    bounds = excel_range_bounds(coordinate)
    return bounds.min_row, bounds.min_column


def _temporal_source_text(
    value_text: str,
    *,
    data_type: str | None,
    date_1904: bool,
    formula_cache: bool,
) -> ExcelTemporalSource:
    """Preserve decoded source text after a decoder has established temporal typing."""
    return ExcelTemporalSource(
        kind="iso8601" if data_type == "d" else "excel_serial",
        raw_value=value_text,
        date_system=(None if data_type == "d" else "1904" if date_1904 else "1900"),
        origin="formula_cache" if formula_cache else "value",
    )


def _temporal_source_record(
    element: Element,
    coordinate: str,
    *,
    date_1904: bool,
) -> _RawCell:
    """Capture a reader-typed cell; only coordinate and source are meaningful."""
    from openpyxl.xml.constants import SHEET_MAIN_NS

    data_type = element.attrib.get("t")
    value_element = element.find(f"{{{SHEET_MAIN_NS}}}v")
    value_text = None if value_element is None else value_element.text
    source = None
    if value_text is not None and data_type in {None, "n", "d"}:
        source = _temporal_source_text(
            value_text,
            data_type=data_type,
            date_1904=date_1904,
            formula_cache=element.find(f"{{{SHEET_MAIN_NS}}}f") is not None,
        )
    return _RawCell(
        coordinate=coordinate,
        value=None,
        formula=None,
        cached_value=None,
        has_cached_value=False,
        data_type=data_type or "n",
        cached_data_type="n",
        style_id=0,
        number_format=None,
        formula_kind=None,
        external_reference=False,
        has_content=source is not None,
        temporal_source=source,
    )


def _raw_cells(
    archive: ZipFile,
    *,
    package: _PackageInfo,
    shared_strings: tuple[str, ...],
    styles: tuple[_CellStyle, ...],
    selected_ranges: tuple[ExcelRangeBounds, ...],
    limits: ExcelPackageLimits | None = None,
    selected_coordinates: Iterator[str] | None = None,
    source_only: bool = False,
) -> Iterator[_RawCell]:
    """Yield represented worksheet cells without expanding missing cells."""
    member = package.worksheet_member
    _ensure_bounded_xml_member(archive, member, limits)
    _ensure_no_dtd(archive, member)
    previous_row = 0
    current_row: int | None = None
    previous_column = 0
    previous_key = (0, 0)
    shared_formulas: dict[str, tuple[str, str]] = {}
    if not source_only and "xl/metadata.xml" in archive.namelist():
        _ensure_bounded_xml_member(archive, "xl/metadata.xml", limits)
    dynamic_metadata_indexes = (
        frozenset[int]() if source_only else _dynamic_metadata_indexes(archive)
    )
    element_stack: list[Element] = []
    selected_key = _next_selected_coordinate(selected_coordinates)
    if selected_coordinates is not None and selected_key is None:
        return

    with archive.open(member) as stream:
        for event, element, name in _worksheet_events(stream):
            if event == "start":
                element_stack.append(element)
                if name == "row":
                    row_text = element.attrib.get("r")
                    current_row = (
                        previous_row + 1 if row_text is None else int(row_text)
                    )
                    if current_row < 1 or current_row > MAX_EXCEL_ROW:
                        msg = "worksheet row is outside Excel bounds"
                        raise ValueError(msg)
                    previous_column = 0
                continue

            if name == "c":
                coordinate, previous_column = _cell_coordinate(
                    element,
                    current_row=current_row,
                    previous_column=previous_column,
                )
                bounds = excel_range_bounds(coordinate)
                key = (bounds.min_row, bounds.min_column)
                if key <= previous_key:
                    msg = "worksheet cells are not in deterministic row order"
                    raise ValueError(msg)
                previous_key = key
                if selected_coordinates is not None:
                    while selected_key is not None and selected_key < key:
                        selected_key = _next_selected_coordinate(selected_coordinates)
                    if selected_key is None:
                        return

                is_selected = _cell_is_selected(bounds, selected_ranges) and (
                    selected_coordinates is None or key == selected_key
                )
                if is_selected:
                    _validate_cell_type(element)
                if source_only:
                    if is_selected:
                        yield _temporal_source_record(
                            element,
                            coordinate,
                            date_1904=package.date_1904,
                        )
                        if selected_coordinates is not None:
                            selected_key = _next_selected_coordinate(
                                selected_coordinates
                            )
                            if selected_key is None:
                                return
                    element.clear()
                    if not element_stack or element_stack[-1] is not element:
                        msg = "worksheet XML element stack is invalid"
                        raise ValueError(msg)
                    element_stack.pop()
                    continue

                formula_element = _worksheet_child(element, "f")
                formula = (
                    None
                    if formula_element is None
                    else _formula_text(
                        formula_element,
                        coordinate,
                        shared_formulas,
                    )
                )
                if not is_selected:
                    element.clear()
                    if not element_stack or element_stack[-1] is not element:
                        msg = "worksheet XML element stack is invalid"
                        raise ValueError(msg)
                    element_stack.pop()
                    continue

                style_id = int(element.attrib.get("s", "0"))
                if style_id < 0:
                    msg = "worksheet cell style index must not be negative"
                    raise ValueError(msg)
                data_type = element.attrib.get("t")
                value_element = _worksheet_child(element, "v")
                inline_container = _worksheet_child(element, "is")
                inline_visible = (
                    None
                    if inline_container is None
                    else _visible_text(
                        inline_container,
                        container="is",
                        label="inline String",
                    )
                )
                inline_text = (
                    inline_visible.value
                    if inline_visible is not None and inline_visible.choice_present
                    else None
                )
                value_text = None if value_element is None else value_element.text

                value: _ExcelValue = None
                cached_value: _ExcelValue = None
                has_cached_value = False
                formula_kind: FormulaKind | None = None
                external_reference = False
                ordinary_data_type = "n"
                cached_data_type = "n"
                if formula_element is not None:
                    formula_kind = _formula_kind(
                        element,
                        formula_element,
                        dynamic_metadata_indexes=dynamic_metadata_indexes,
                    )
                    external_reference = _has_external_reference(formula)
                    if value_text is not None:
                        cached_value, cached_data_type = _parse_value(
                            data_type=data_type,
                            value_text=value_text,
                            inline_text=inline_text,
                            shared_strings=shared_strings,
                            style_id=style_id,
                            styles=styles,
                            date_1904=package.date_1904,
                        )
                        has_cached_value = True
                elif inline_text is not None:
                    value, ordinary_data_type = _parse_value(
                        data_type="inlineStr",
                        value_text="",
                        inline_text=inline_text,
                        shared_strings=shared_strings,
                        style_id=style_id,
                        styles=styles,
                        date_1904=package.date_1904,
                    )
                elif value_text is not None:
                    value, ordinary_data_type = _parse_value(
                        data_type=data_type,
                        value_text=value_text,
                        inline_text=None,
                        shared_strings=shared_strings,
                        style_id=style_id,
                        styles=styles,
                        date_1904=package.date_1904,
                    )

                temporal_value = cached_value if formula_element is not None else value
                temporal_source = None
                if value_text is not None and isinstance(
                    temporal_value, (date, datetime, time)
                ):
                    temporal_source = _temporal_source_text(
                        value_text,
                        data_type=data_type,
                        date_1904=package.date_1904,
                        formula_cache=formula_element is not None,
                    )

                yield _RawCell(
                    coordinate=coordinate,
                    value=value,
                    formula=formula,
                    cached_value=cached_value,
                    has_cached_value=has_cached_value,
                    data_type=(
                        "formula" if formula is not None else ordinary_data_type
                    ),
                    cached_data_type=cached_data_type,
                    style_id=style_id,
                    number_format=(
                        styles[style_id].number_format
                        if style_id < len(styles)
                        else None
                    ),
                    formula_kind=formula_kind,
                    external_reference=external_reference,
                    temporal_source=temporal_source,
                    has_content=(
                        formula is not None
                        or inline_text is not None
                        or value_text is not None
                    ),
                )
                element.clear()
                if selected_coordinates is not None:
                    selected_key = _next_selected_coordinate(selected_coordinates)
                    if selected_key is None:
                        return
            elif name == "row":
                if current_row is None:
                    msg = "worksheet row state is invalid"
                    raise ValueError(msg)
                previous_row = current_row
                current_row = None
                previous_column = 0
                element.clear()
                if len(element_stack) < _ROW_PARENT_STACK_DEPTH:
                    msg = "worksheet row has no parent element"
                    raise ValueError(msg)
                element_stack[-2].remove(element)
            if not element_stack or element_stack[-1] is not element:
                msg = "worksheet XML element stack is invalid"
                raise ValueError(msg)
            element_stack.pop()


def _fingerprint_open_stream(stream: BinaryIO) -> str:
    """Hash one already-open file and restore it for package parsing."""
    digest = sha256()
    while chunk := stream.read(_FINGERPRINT_CHUNK_SIZE):
        digest.update(chunk)
    stream.seek(0)
    return digest.hexdigest()


def _verify_stream_fingerprint(
    stream: BinaryIO,
    *,
    expected_fingerprint: str,
    path: Path,
) -> None:
    """Reject a path replacement before parsing content under an old identity."""
    if _fingerprint_open_stream(stream) != expected_fingerprint:
        msg = f"Workbook changed after inspection: {safe_file_label(path)}"
        raise DocumentProcessingError(msg)


def _represented_cells(
    path: Path,
    sheet_name: str,
    *,
    expected_fingerprint: str | None = None,
    selected_ranges: tuple[ExcelRangeBounds, ...] = (),
    package_limits: ExcelPackageLimits | None = None,
    selected_coordinates: Iterator[str] | None = None,
    source_only: bool = False,
) -> Iterator[_RawCell]:
    """Stream cells for an internal caller that already validated the input.

    A reader may supply a lazy sorted coordinate iterator and source-only mode
    after its backend establishes temporal typing. That mode reads source facts
    without repeating value/formula decoding or changing backend acceptance.
    """

    def generate() -> Iterator[_RawCell]:
        try:
            with path.open("rb") as source:
                if expected_fingerprint is not None:
                    _verify_stream_fingerprint(
                        source,
                        expected_fingerprint=expected_fingerprint,
                        path=path,
                    )
                with ZipFile(source, "r") as archive:
                    _preflight_archive(archive, package_limits)
                    package = _package_info(
                        archive,
                        sheet_name,
                        package_limits,
                        source_only=source_only,
                    )
                    yield from _raw_cells(
                        archive,
                        package=package,
                        shared_strings=(
                            ()
                            if source_only
                            else _shared_strings(
                                archive,
                                package.shared_strings_member,
                                package_limits,
                            )
                        ),
                        styles=(
                            ()
                            if source_only
                            else _cell_styles(
                                archive,
                                package.styles_member,
                                package_limits,
                            )
                        ),
                        selected_ranges=selected_ranges,
                        limits=package_limits,
                        selected_coordinates=selected_coordinates,
                        source_only=source_only,
                    )
        except DocumentSdkError:
            raise
        except Exception as exc:
            msg = f"Unable to stream workbook: {safe_file_label(path)}"
            _raise_redacted_translation(exc, DocumentProcessingError(msg))

    return generate()

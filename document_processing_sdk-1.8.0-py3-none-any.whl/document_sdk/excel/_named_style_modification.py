"""Deterministic workbook named-style import and verification."""

from __future__ import annotations

from typing import TYPE_CHECKING, cast

from document_sdk.excel._cell_format_modification import (
    _alignment,
    _border,
    _fill,
    _font,
)
from document_sdk.excel.errors import ExcelModificationError

if TYPE_CHECKING:
    from collections.abc import Sequence

    from openpyxl.styles import NamedStyle
    from openpyxl.workbook.workbook import Workbook

    from document_sdk.excel.models import WorkbookNamedStylePatch


def _identity(style: NamedStyle) -> tuple[str, object]:
    builtin_id = style.builtinId
    if builtin_id is not None:
        return "builtin", int(builtin_id)
    return "name", str(style.name).casefold()


def _patch_identity(patch: WorkbookNamedStylePatch) -> tuple[str, object]:
    if patch.builtin_id is not None:
        return "builtin", patch.builtin_id
    return "name", patch.name.casefold()


def _styles(workbook: Workbook) -> Sequence[NamedStyle]:
    return cast(
        "Sequence[NamedStyle]",
        workbook._named_styles,  # type: ignore[attr-defined]  # noqa: SLF001
    )


def _matches(style: NamedStyle, patch: WorkbookNamedStylePatch) -> bool:
    return (
        style.name == patch.name
        and style.builtinId == patch.builtin_id
        and style.font == _font(patch.font)
        and style.fill == _fill(patch.fill)
        and style.border == _border(patch.border)
        and style.alignment == _alignment(patch.alignment)
        and style.number_format == patch.number_format
    )


def _find(workbook: Workbook, patch: WorkbookNamedStylePatch) -> NamedStyle | None:
    identity = _patch_identity(patch)
    matches = [style for style in _styles(workbook) if _identity(style) == identity]
    if len(matches) > 1:
        msg = "Workbook contains duplicate named style identities"
        raise ExcelModificationError(msg)
    name_collisions = [
        style
        for style in _styles(workbook)
        if style.name.casefold() == patch.name.casefold()
        and _identity(style) != identity
    ]
    if name_collisions:
        msg = "Workbook named style import name conflicts with an existing style"
        raise ExcelModificationError(msg)
    return matches[0] if matches else None


def apply_named_style_imports(
    workbook: Workbook,
    patches: Sequence[WorkbookNamedStylePatch],
) -> tuple[str, ...]:
    """Import missing named styles and reject conflicting existing definitions."""
    from openpyxl.styles import NamedStyle

    imported: list[str] = []
    for patch in patches:
        existing = _find(workbook, patch)
        if existing is not None:
            if not _matches(existing, patch):
                msg = "Workbook named style import conflicts with existing semantics"
                raise ExcelModificationError(msg)
            continue
        workbook.add_named_style(
            NamedStyle(
                name=patch.name,
                builtinId=patch.builtin_id,
                font=_font(patch.font),
                fill=_fill(patch.fill),
                border=_border(patch.border),
                alignment=_alignment(patch.alignment),
                number_format=patch.number_format,
            )
        )
        imported.append(patch.name)
    return tuple(imported)


def verify_named_style_imports(
    workbook: Workbook,
    patches: Sequence[WorkbookNamedStylePatch],
) -> None:
    """Verify imported style identities and complete represented components."""
    for patch in patches:
        existing = _find(workbook, patch)
        if existing is None or not _matches(existing, patch):
            msg = "Patched workbook named style verification failed"
            raise ExcelModificationError(msg)

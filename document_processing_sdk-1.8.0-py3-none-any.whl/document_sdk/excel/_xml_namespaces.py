"""Deterministic namespace-prefix allocation for OOXML writers."""

from __future__ import annotations

from typing import TYPE_CHECKING, cast

if TYPE_CHECKING:
    from xml.dom.minidom import Attr, Element

_XMLNS_NAMESPACE = "http://www.w3.org/2000/xmlns/"


def namespace_prefix(root: Element, namespace: str, preferred: str) -> str:
    """Reuse the correct binding or allocate a collision-free stable prefix."""
    used: dict[str, str] = {}
    for index in range(root.attributes.length):
        attribute = cast("Attr | None", root.attributes.item(index))
        if attribute is None or attribute.namespaceURI != _XMLNS_NAMESPACE:
            continue
        prefix = attribute.localName
        used[prefix] = attribute.value
        if attribute.value == namespace and prefix != "xmlns":
            return prefix
    candidate = preferred
    suffix = 1
    while candidate in used:
        suffix += 1
        candidate = f"{preferred}{suffix}"
    root.setAttributeNS(
        _XMLNS_NAMESPACE,
        f"xmlns:{candidate}",
        namespace,
    )
    return candidate

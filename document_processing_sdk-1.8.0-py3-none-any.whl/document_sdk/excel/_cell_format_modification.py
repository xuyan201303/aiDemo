"""Typed openpyxl conversion and verification for cell-format patches."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal, cast

from document_sdk.excel.errors import ExcelModificationError

if TYPE_CHECKING:
    from collections.abc import Sequence
    from pathlib import Path
    from xml.dom.minidom import Element

    from openpyxl.cell.cell import Cell
    from openpyxl.styles import (
        Alignment,
        Border,
        Color,
        Font,
        GradientFill,
        PatternFill,
        Side,
    )
    from openpyxl.workbook.workbook import Workbook
    from openpyxl.worksheet.worksheet import Worksheet

    from document_sdk.excel._package import _SafePackage
    from document_sdk.excel._package_types import _SheetRecord
    from document_sdk.excel.models import (
        CellAlignmentPatch,
        CellBorderPatch,
        CellBorderSidePatch,
        CellFontPatch,
        CellFormatPatch,
        CellGradientFillPatch,
        CellPatternFillPatch,
        CellStyleColor,
        ExistingCellFormatRangePatch,
    )

type _FormatComponent = Literal[
    "font",
    "fill",
    "border",
    "alignment",
    "number_format",
    "named_style",
    "quote_prefix",
    "pivot_button",
]
type _FormatTarget = tuple[str, str]
_MAX_EXISTING_FORMAT_RANGE_ROWS = 1_000_000


@dataclass(frozen=True, slots=True)
class _PendingFormatChange:
    """One verified format target before public file identities are known."""

    sheet_name: str
    coordinate: str
    changed_components: tuple[_FormatComponent, ...]


@dataclass(frozen=True, slots=True)
class _PendingExistingCellFormatRangeChange:
    """One compact existing-cell format operation and its concrete targets."""

    sheet_name: str
    cell_ranges: tuple[str, ...]
    target_coordinates: tuple[str, ...]
    changed_components: tuple[_FormatComponent, ...]


def _worksheet(workbook: Workbook, sheet_name: str) -> Worksheet:
    matches = [
        worksheet
        for worksheet in workbook.worksheets
        if worksheet.title.casefold() == sheet_name.casefold()
    ]
    if len(matches) != 1:
        msg = "Workbook format patch worksheet does not exist"
        raise ExcelModificationError(msg)
    return matches[0]


def _color(value: CellStyleColor | None) -> Color | None:
    if value is None:
        return None
    from openpyxl.styles import Color

    arguments: dict[str, Any] = {
        name: item
        for name, item in {
            "rgb": value.rgb,
            "indexed": value.indexed,
            "auto": value.auto,
            "theme": value.theme,
        }.items()
        if item is not None
    }
    if value.tint != 0.0:
        arguments["tint"] = value.tint
    return Color(**arguments)


def _font(value: CellFontPatch) -> Font:
    from openpyxl.styles import Font

    arguments: dict[str, Any] = {
        name: item
        for name, item in {
            "name": value.name,
            "sz": value.size,
            "b": value.bold,
            "i": value.italic,
            "u": value.underline,
            "strike": value.strike,
            "color": _color(value.color),
            "vertAlign": value.vert_align,
            "charset": value.charset,
            "family": value.family,
            "scheme": value.scheme,
            "outline": value.outline,
            "shadow": value.shadow,
            "condense": value.condense,
            "extend": value.extend,
        }.items()
        if item is not None
    }
    return Font(**arguments)


def _fill(
    value: CellPatternFillPatch | CellGradientFillPatch,
) -> PatternFill | GradientFill:
    from openpyxl.styles import GradientFill, PatternFill
    from openpyxl.styles.fills import Stop

    from document_sdk.excel.models import CellGradientFillPatch

    if isinstance(value, CellGradientFillPatch):
        return GradientFill(
            type=value.fill_type,
            degree=value.degree,
            left=value.left,
            right=value.right,
            top=value.top,
            bottom=value.bottom,
            stop=tuple(
                Stop(color=_color(stop.color), position=stop.position)
                for stop in value.stops
            ),
        )

    arguments: dict[str, Any] = {"patternType": value.pattern_type}
    if value.foreground_color is not None:
        arguments["fgColor"] = _color(value.foreground_color)
    if value.background_color is not None:
        arguments["bgColor"] = _color(value.background_color)
    return PatternFill(**arguments)


def _side(value: CellBorderSidePatch | None) -> Side | None:
    if value is None:
        return None
    from openpyxl.styles import Side

    return Side(style=value.style, color=_color(value.color))


def _border(value: CellBorderPatch) -> Border:
    from openpyxl.styles import Border

    arguments: dict[str, Any] = {
        name: item
        for name, item in {
            "left": _side(value.left),
            "right": _side(value.right),
            "top": _side(value.top),
            "bottom": _side(value.bottom),
            "diagonal": _side(value.diagonal),
            "vertical": _side(value.vertical),
            "horizontal": _side(value.horizontal),
            "start": _side(value.start),
            "end": _side(value.end),
            "diagonalUp": value.diagonal_up,
            "diagonalDown": value.diagonal_down,
            "outline": value.outline,
        }.items()
        if item is not None
    }
    return Border(**arguments)


def _alignment(value: CellAlignmentPatch) -> Alignment:
    from openpyxl.styles import Alignment

    arguments: dict[str, Any] = {
        name: item
        for name, item in {
            "horizontal": value.horizontal,
            "vertical": value.vertical,
            "textRotation": value.text_rotation,
            "wrapText": value.wrap_text,
            "shrinkToFit": value.shrink_to_fit,
            "indent": value.indent,
            "relativeIndent": value.relative_indent,
            "justifyLastLine": value.justify_last_line,
            "readingOrder": value.reading_order,
        }.items()
        if item is not None
    }
    return Alignment(**arguments)


def _requested_components(
    patch: CellFormatPatch | ExistingCellFormatRangePatch,
) -> tuple[tuple[_FormatComponent, object], ...]:
    requested: list[tuple[_FormatComponent, object]] = []
    if patch.named_style is not None:
        requested.append(("named_style", patch.named_style))
    if patch.font is not None:
        requested.append(("font", _font(patch.font)))
    if patch.fill is not None:
        requested.append(("fill", _fill(patch.fill)))
    if patch.border is not None:
        requested.append(("border", _border(patch.border)))
    if patch.alignment is not None:
        requested.append(("alignment", _alignment(patch.alignment)))
    if patch.number_format is not None:
        requested.append(("number_format", patch.number_format))
    if patch.quote_prefix is not None:
        requested.append(("quote_prefix", patch.quote_prefix))
    if patch.pivot_button is not None:
        requested.append(("pivot_button", patch.pivot_button))
    return tuple(requested)


def _existing_range_cells(
    worksheet: Worksheet,
    patch: ExistingCellFormatRangePatch,
) -> tuple[Cell, ...]:
    """Resolve only physically existing cells without materializing blank grids."""
    from document_sdk.core._excel_coordinates import excel_range_bounds

    row_intervals: dict[int, list[tuple[int, int]]] = {}
    row_assignments = 0
    for cell_range in patch.cell_ranges:
        bounds = excel_range_bounds(cell_range)
        row_assignments += bounds.max_row - bounds.min_row + 1
        if row_assignments > _MAX_EXISTING_FORMAT_RANGE_ROWS:
            msg = "existing-cell format range row assignments exceed limits"
            raise ExcelModificationError(msg)
        for row in range(bounds.min_row, bounds.max_row + 1):
            row_intervals.setdefault(row, []).append(
                (bounds.min_column, bounds.max_column)
            )
    cells = tuple(
        cell
        for (row, column), cell in sorted(worksheet._cells.items())  # noqa: SLF001
        if any(
            minimum <= column <= maximum
            for minimum, maximum in row_intervals.get(row, ())
        )
    )
    if not cells:
        msg = "existing-cell format range contains no existing cells"
        raise ExcelModificationError(msg)
    return cast("tuple[Cell, ...]", cells)


def _cell_component(cell: Cell, component: _FormatComponent) -> object:
    if component == "named_style":
        return cell.style
    if component == "quote_prefix":
        return cell.quotePrefix
    if component == "pivot_button":
        return cell.pivotButton
    return getattr(cell, component)


def _worksheet_record(
    records: Sequence[_SheetRecord],
    sheet_key: str,
) -> _SheetRecord:
    matches = [record for record in records if record.name.casefold() == sheet_key]
    if len(matches) != 1:
        msg = "Workbook format patch worksheet does not exist"
        raise ExcelModificationError(msg)
    record = matches[0]
    if record.sheet_type != "worksheet" or record.part_name is None:
        msg = "Workbook format patch worksheet does not exist"
        raise ExcelModificationError(msg)
    return record


def _persisted_cells(
    package: _SafePackage,
    record: _SheetRecord,
    coordinates: set[str],
) -> dict[str, Element]:
    from document_sdk.excel._cell_style_preservation import (
        _cell_elements,
        _worksheet_document,
    )

    if record.part_name is None:  # pragma: no cover - caller invariant.
        msg = "Workbook format patch worksheet does not exist"
        raise ExcelModificationError(msg)
    with package.open_xml_stream(record.part_name) as worksheet_stream:
        _document, root, namespace = _worksheet_document(worksheet_stream.read())
    cells: dict[str, Element] = {}
    for element in _cell_elements(root, namespace):
        coordinate = element.getAttribute("r")
        if coordinate not in coordinates:
            continue
        if coordinate in cells:
            msg = "Workbook worksheet contains invalid cell references"
            raise ValueError(msg)
        cells[coordinate] = element
    if set(cells) != coordinates:
        msg = "Workbook format patch cell does not exist"
        raise ExcelModificationError(msg)
    return cells


def verify_persisted_format_borders(
    output_path: Path,
    patches: Sequence[CellFormatPatch],
) -> frozenset[_FormatTarget]:
    """Verify requested borders against persisted worksheet style records."""
    requested: dict[str, list[CellFormatPatch]] = {}
    for patch in patches:
        if patch.border is not None:
            requested.setdefault(patch.sheet_name.casefold(), []).append(patch)
    if not requested:
        return frozenset()

    from document_sdk.excel._cell_style_preservation import _element_style_id
    from document_sdk.excel._column_modification import _ColumnStyleTable
    from document_sdk.excel._package import _SafePackage
    from document_sdk.excel._package_workbook import _workbook_records

    verified: set[_FormatTarget] = set()
    with _SafePackage(output_path) as package:
        if not package.has("xl/styles.xml"):
            msg = "Patched workbook styles part does not exist"
            raise ExcelModificationError(msg)
        with package.open_xml_stream("xl/styles.xml") as styles_stream:
            style_table = _ColumnStyleTable.parse(styles_stream.read())
        _workbook, records = _workbook_records(package)
        for sheet_key, sheet_patches in requested.items():
            record = _worksheet_record(records, sheet_key)
            coordinates = {patch.coordinate for patch in sheet_patches}
            cells = _persisted_cells(package, record, coordinates)
            for patch in sheet_patches:
                element = cells[patch.coordinate]
                style_id = _element_style_id(element)
                current = style_table.fingerprint(style_id)
                desired_style_id = style_table.resolve(
                    style_id,
                    {"border": patch.border},
                )
                if style_table.fingerprint(desired_style_id) != current:
                    msg = "Patched workbook cell-format verification failed"
                    raise ExcelModificationError(msg)
                verified.add((sheet_key, patch.coordinate))
    return frozenset(verified)


def _merged_anchor_border_matches(
    worksheet: Worksheet,
    cell: Cell,
    actual: object,
    expected: object,
) -> bool:
    """Recognize only the edge border synthesized for a reopened merge anchor."""
    from openpyxl.styles import Border

    if not isinstance(expected, Border):  # pragma: no cover - caller invariant.
        return False
    for merged_range in worksheet.merged_cells.ranges:
        if (
            cell.row != merged_range.min_row
            or cell.column != merged_range.min_col
            or (
                merged_range.min_row == merged_range.max_row
                and merged_range.min_col == merged_range.max_col
            )
        ):
            continue
        end_cell = worksheet.cell(
            row=merged_range.max_row,
            column=merged_range.max_col,
        )
        synthesized = expected + Border(
            right=end_cell.border.right,
            bottom=end_cell.border.bottom,
        )
        return bool(actual == synthesized)
    return False


def apply_format_patches(
    workbook: Workbook,
    patches: Sequence[CellFormatPatch],
) -> tuple[_PendingFormatChange, ...]:
    """Apply complete format components and return only real changes."""
    pending: list[_PendingFormatChange] = []
    for patch in patches:
        worksheet = _worksheet(workbook, patch.sheet_name)
        cell = worksheet[patch.coordinate]
        changed: list[_FormatComponent] = []
        for component, expected in _requested_components(patch):
            if _cell_component(cell, component) == expected:
                continue
            if component == "named_style":
                try:
                    cell.style = str(expected)
                except ValueError:
                    msg = "Workbook format patch named style does not exist"
                    raise ExcelModificationError(msg) from None
            elif component == "quote_prefix":
                cell.quotePrefix = bool(expected)
            elif component == "pivot_button":
                cell.pivotButton = bool(expected)
            else:
                setattr(cell, component, expected)
            changed.append(component)
        if changed:
            pending.append(
                _PendingFormatChange(
                    sheet_name=worksheet.title,
                    coordinate=patch.coordinate,
                    changed_components=tuple(changed),
                )
            )
    return tuple(pending)


def apply_existing_cell_format_range_patches(
    workbook: Workbook,
    patches: Sequence[ExistingCellFormatRangePatch],
) -> tuple[_PendingExistingCellFormatRangeChange, ...]:
    """Apply compact range formats only to already-materialized cells."""
    pending: list[_PendingExistingCellFormatRangeChange] = []
    for patch in patches:
        worksheet = _worksheet(workbook, patch.sheet_name)
        cells = _existing_range_cells(worksheet, patch)
        changed: set[_FormatComponent] = set()
        for cell in cells:
            for component, expected in _requested_components(patch):
                if _cell_component(cell, component) == expected:
                    continue
                if component == "named_style":
                    try:
                        cell.style = str(expected)
                    except ValueError:
                        msg = "Workbook format patch named style does not exist"
                        raise ExcelModificationError(msg) from None
                elif component == "quote_prefix":
                    cell.quotePrefix = bool(expected)
                elif component == "pivot_button":
                    cell.pivotButton = bool(expected)
                else:
                    setattr(cell, component, expected)
                changed.add(component)
        if changed:
            pending.append(
                _PendingExistingCellFormatRangeChange(
                    sheet_name=worksheet.title,
                    cell_ranges=patch.cell_ranges,
                    target_coordinates=tuple(cell.coordinate for cell in cells),
                    changed_components=tuple(sorted(changed)),
                )
            )
    return tuple(pending)


def verify_format_patches(
    workbook: Workbook,
    patches: Sequence[CellFormatPatch],
    *,
    persisted_border_targets: frozenset[_FormatTarget] = frozenset(),
) -> None:
    """Verify every requested format component from a reopened workbook."""
    for patch in patches:
        worksheet = _worksheet(workbook, patch.sheet_name)
        cell = worksheet[patch.coordinate]
        for component, expected in _requested_components(patch):
            actual = _cell_component(cell, component)
            if actual == expected:
                continue
            target = (patch.sheet_name.casefold(), patch.coordinate)
            if (
                component == "border"
                and target in persisted_border_targets
                and _merged_anchor_border_matches(
                    worksheet,
                    cell,
                    actual,
                    expected,
                )
            ):
                continue
            msg = "Patched workbook cell-format verification failed"
            raise ExcelModificationError(msg)


def verify_existing_cell_format_range_patches(
    workbook: Workbook,
    patches: Sequence[ExistingCellFormatRangePatch],
) -> None:
    """Verify every requested component on reopened existing range cells."""
    for patch in patches:
        worksheet = _worksheet(workbook, patch.sheet_name)
        for cell in _existing_range_cells(worksheet, patch):
            if any(
                _cell_component(cell, component) != expected
                for component, expected in _requested_components(patch)
            ):
                msg = "Patched workbook existing-cell range-format verification failed"
                raise ExcelModificationError(msg)

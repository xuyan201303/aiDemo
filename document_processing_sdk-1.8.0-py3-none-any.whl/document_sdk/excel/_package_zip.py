"""Deterministic ZIP metadata for newly created OOXML package members."""

from __future__ import annotations

from copy import copy
from typing import TYPE_CHECKING
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

if TYPE_CHECKING:
    from pathlib import Path

_FIXED_ZIP_TIMESTAMP = (1980, 1, 1, 0, 0, 0)
_REGULAR_FILE_MODE = 0o100600


def deterministic_zip_info(name: str) -> ZipInfo:
    """Build stable metadata for one new regular package member."""
    info = ZipInfo(filename=name, date_time=_FIXED_ZIP_TIMESTAMP)
    info.compress_type = ZIP_DEFLATED
    info.create_system = 3
    info.create_version = 20
    info.extract_version = 20
    info.external_attr = _REGULAR_FILE_MODE << 16
    info.internal_attr = 0
    info.flag_bits = 0
    info.extra = b""
    info.comment = b""
    return info


def write_new_member(archive: ZipFile, name: str, payload: bytes) -> None:
    """Write one new package member without wall-clock ZIP metadata."""
    archive.writestr(
        deterministic_zip_info(name),
        payload,
        compress_type=ZIP_DEFLATED,
    )


def copy_with_deterministic_timestamps(source_path: Path, output_path: Path) -> None:
    """Copy an OOXML package without retaining wall-clock ZIP timestamps."""
    with (
        ZipFile(source_path, "r") as source,
        ZipFile(
            output_path,
            "w",
            compression=ZIP_DEFLATED,
            allowZip64=True,
            strict_timestamps=False,
        ) as output,
    ):
        output.comment = source.comment
        for source_info in source.infolist():
            output_info = copy(source_info)
            output_info.date_time = _FIXED_ZIP_TIMESTAMP
            output.writestr(output_info, source.read(source_info))

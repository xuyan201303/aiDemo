"""ZIP, XML, and relationship safety boundaries for OOXML packages."""

from __future__ import annotations

import codecs
import posixpath
from contextlib import contextmanager
from dataclasses import dataclass
from hashlib import sha256
from pathlib import PurePosixPath
from typing import TYPE_CHECKING, Self
from xml.etree import ElementTree as ET
from zipfile import ZipFile, ZipInfo

from document_sdk.excel._package_types import _Relationship
from document_sdk.excel.errors import ExcelPackageLimitError

if TYPE_CHECKING:
    from collections.abc import Iterator
    from pathlib import Path
    from typing import IO
    from xml.dom.minidom import Document
    from xml.etree.ElementTree import Element


_FINGERPRINT_CHUNK_SIZE = 1024 * 1024
_RELATIONSHIPS_NAMESPACE = (
    "http://schemas.openxmlformats.org/package/2006/relationships"
)


def _serialize_xml(document: Document) -> bytes:  # noqa: C901, PLR0912
    """Serialize XML without losing referenced whitespace in attributes."""
    payload = document.toxml(encoding="utf-8")
    output = bytearray()
    index = 0
    in_markup = False
    quote: int | None = None
    while index < len(payload):
        if not in_markup and payload.startswith(b"<!--", index):
            end = payload.find(b"-->", index + 4)
            if end < 0:  # pragma: no cover - minidom serialization invariant.
                return payload
            output.extend(payload[index : end + 3])
            index = end + 3
            continue
        if not in_markup and payload.startswith(b"<![CDATA[", index):
            end = payload.find(b"]]>", index + 9)
            if end < 0:  # pragma: no cover - minidom serialization invariant.
                return payload
            output.extend(payload[index : end + 3])
            index = end + 3
            continue
        value = payload[index]
        if not in_markup:
            in_markup = value == ord("<")
            output.append(value)
        elif quote is None:
            output.append(value)
            if value in {ord('"'), ord("'")}:
                quote = value
            elif value == ord(">"):
                in_markup = False
        elif value == quote:
            output.append(value)
            quote = None
        elif value == ord("\t"):
            output.extend(b"&#9;")
        elif value == ord("\n"):
            output.extend(b"&#10;")
        elif value == ord("\r"):
            output.extend(b"&#13;")
        else:
            output.append(value)
        index += 1
    return bytes(output)


def _wide_xml_encoding(prefix: bytes) -> str | None:
    """Detect UTF-16/32 XML encodings that interleave ASCII with NUL bytes."""
    if prefix.startswith((b"\x00\x00\xfe\xff", b"\x00\x00\x00<")):
        return "utf-32-be"
    if prefix.startswith((b"\xff\xfe\x00\x00", b"<\x00\x00\x00")):
        return "utf-32-le"
    if prefix.startswith((b"\xfe\xff", b"\x00<")):
        return "utf-16-be"
    if prefix.startswith((b"\xff\xfe", b"<\x00")):
        return "utf-16-le"
    return None


class _XmlDeclarationScanner:
    """Find real DTD/entity markup while ignoring comment and CDATA payloads."""

    __slots__ = ("_buffer", "_state")

    def __init__(self) -> None:
        self._buffer = ""
        self._state = "content"

    def feed(self, value: str, *, final: bool = False) -> bool:
        """Consume decoded XML characters and report a forbidden declaration."""
        self._buffer += value
        while self._buffer:
            if self._state == "comment":
                end = self._buffer.find("-->")
                if end < 0:
                    self._buffer = "" if final else self._buffer[-2:]
                    return False
                self._buffer = self._buffer[end + 3 :]
                self._state = "content"
                continue
            if self._state == "cdata":
                end = self._buffer.find("]]>")
                if end < 0:
                    self._buffer = "" if final else self._buffer[-2:]
                    return False
                self._buffer = self._buffer[end + 3 :]
                self._state = "content"
                continue

            lowered = self._buffer.casefold()
            candidates = tuple(
                (position, kind, marker)
                for kind, marker, position in (
                    ("comment", "<!--", self._buffer.find("<!--")),
                    ("cdata", "<![CDATA[", self._buffer.find("<![CDATA[")),
                    ("forbidden", "<!doctype", lowered.find("<!doctype")),
                    ("forbidden", "<!entity", lowered.find("<!entity")),
                )
                if position >= 0
            )
            if not candidates:
                self._buffer = "" if final else self._buffer[-10:]
                return False
            position, kind, marker = min(candidates, key=lambda item: item[0])
            if kind == "forbidden":
                return True
            self._buffer = self._buffer[position + len(marker) :]
            self._state = kind
        return False


def _has_forbidden_xml_declaration(stream: IO[bytes]) -> bool:
    """Scan one XML stream for forbidden declarations across chunk boundaries."""
    first_chunk = stream.read(64 * 1024)
    encoding = _wide_xml_encoding(first_chunk)
    scanner = _XmlDeclarationScanner()
    if encoding is None:
        chunk = first_chunk
        while chunk:
            if scanner.feed(chunk.decode("latin-1")):
                return True
            chunk = stream.read(64 * 1024)
        return scanner.feed("", final=True)

    decoder = codecs.getincrementaldecoder(encoding)(errors="ignore")
    chunk = first_chunk
    while chunk:
        if scanner.feed(decoder.decode(chunk)):
            return True
        chunk = stream.read(64 * 1024)
    return scanner.feed(decoder.decode(b"", final=True), final=True)


@dataclass(frozen=True, slots=True)
class _PackageLimits:
    """Expansion limits supplied by the compatibility entry module."""

    package_members: int
    total_uncompressed_bytes: int
    xml_member_bytes: int
    compression_ratio: int


class _SafePackage:
    """A ZIP package that validates expansion limits before reading members."""

    def __init__(self, path: Path, *, limits: _PackageLimits) -> None:
        self._limits = limits
        self._archive = ZipFile(path)
        try:
            self._members = self._preflight(self._archive.infolist())
        except Exception:
            self._archive.close()
            raise

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *_exc: object) -> None:
        self._archive.close()

    @property
    def names(self) -> tuple[str, ...]:
        """Return validated member names in archive order."""
        return tuple(self._members)

    def has(self, name: str) -> bool:
        """Return whether a validated member exists."""
        return name in self._members

    def verify_fingerprint(self, expected: str) -> None:
        """Verify the already-open package handle against a content identity."""
        stream = self._archive.fp
        if stream is None:
            msg = "Workbook package is closed"
            raise ValueError(msg)
        position = stream.tell()
        digest = sha256()
        try:
            stream.seek(0)
            while chunk := stream.read(_FINGERPRINT_CHUNK_SIZE):
                digest.update(chunk)
        finally:
            stream.seek(position)
        if digest.hexdigest() != expected:
            msg = "Workbook changed after inspection"
            raise ValueError(msg)

    @contextmanager
    def open_member(self, name: str) -> Iterator[IO[bytes]]:
        """Open one preflighted member from this package's archive handle."""
        info = self._members.get(name)
        if info is None:
            msg = "Required workbook package part is missing"
            raise ValueError(msg)
        with self._archive.open(info) as stream:
            yield stream

    @contextmanager
    def open_xml_stream(
        self,
        name: str,
        *,
        declared_xml: bool = False,
    ) -> Iterator[IO[bytes]]:
        """Open one preflighted XML member from this package's archive handle."""
        info = self._members.get(name)
        if info is None:
            msg = "Required workbook package part is missing"
            raise ValueError(msg)
        if not declared_xml and not _is_xml_member(name):
            msg = "Requested workbook package part is not XML"
            raise ValueError(msg)
        if info.file_size > self._limits.xml_member_bytes:
            raise ExcelPackageLimitError(
                limit_name="xml_member_bytes",
                observed=info.file_size,
                maximum=self._limits.xml_member_bytes,
            )
        with self.open_member(name) as stream:
            if _has_forbidden_xml_declaration(stream):
                msg = "Workbook XML contains a forbidden document type declaration"
                raise ValueError(msg)
            stream.seek(0)
            yield stream

    def read_xml(self, name: str, *, declared_xml: bool = False) -> Element:
        """Read and parse one bounded XML member with DTDs disabled."""
        stream_context = (
            self.open_xml_stream(name, declared_xml=True)
            if declared_xml
            else self.open_xml_stream(name)
        )
        with stream_context as stream:
            payload = stream.read()
        return ET.fromstring(  # noqa: S314 - DTD/entity declarations rejected.
            payload
        )

    def reject_forbidden_xml_declarations(self) -> None:
        """Scan every bounded XML member before a third-party parser can open it."""
        for name, info in self._members.items():
            if not _is_xml_member(name):
                continue
            with self._archive.open(info) as stream:
                if _has_forbidden_xml_declaration(stream):
                    msg = "Workbook XML contains a forbidden document type declaration"
                    raise ValueError(msg)

    def _preflight(self, infos: list[ZipInfo]) -> dict[str, ZipInfo]:
        if len(infos) > self._limits.package_members:
            raise ExcelPackageLimitError(
                limit_name="member_count",
                observed=len(infos),
                maximum=self._limits.package_members,
            )

        members: dict[str, ZipInfo] = {}
        seen_names: set[str] = set()
        total_size = 0
        for info in infos:
            name = info.filename
            raw_name = info.orig_filename
            _validate_member_name(raw_name)
            if raw_name != name:
                msg = "Workbook package contains a noncanonical member name"
                raise ValueError(msg)
            if name in seen_names:
                msg = "Workbook package contains duplicate member names"
                raise ValueError(msg)
            seen_names.add(name)
            if info.flag_bits & 0x1:
                msg = "Encrypted workbook package members are unsupported"
                raise ValueError(msg)
            if _is_xml_member(name) and info.file_size > self._limits.xml_member_bytes:
                raise ExcelPackageLimitError(
                    limit_name="xml_member_bytes",
                    observed=info.file_size,
                    maximum=self._limits.xml_member_bytes,
                )
            total_size += info.file_size
            if total_size > self._limits.total_uncompressed_bytes:
                raise ExcelPackageLimitError(
                    limit_name="total_uncompressed_bytes",
                    observed=total_size,
                    maximum=self._limits.total_uncompressed_bytes,
                )
            denominator = max(info.compress_size, 1)
            if info.file_size > self._limits.compression_ratio * denominator:
                ratio = (info.file_size + denominator - 1) // denominator
                raise ExcelPackageLimitError(
                    limit_name="compression_ratio",
                    observed=ratio,
                    maximum=self._limits.compression_ratio,
                )
            if not info.is_dir():
                members[name] = info
        return members


def _is_xml_member(name: str) -> bool:
    """Return whether a package member is XML or an OOXML relationship part."""
    return name.casefold().endswith((".xml", ".rels", ".vml"))


def _validate_member_name(name: str) -> None:
    if not name or "\x00" in name or "\\" in name or name.startswith("/"):
        msg = "Workbook package contains an unsafe member name"
        raise ValueError(msg)
    is_directory = name.endswith("/")
    candidate = name[:-1] if is_directory else name
    path = PurePosixPath(candidate)
    if (
        not candidate
        or candidate in {".", ".."}
        or path.is_absolute()
        or path.as_posix() != candidate
        or any(part in {"", ".", ".."} for part in path.parts)
    ):
        msg = "Workbook package contains an unsafe member name"
        raise ValueError(msg)


def _local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _attribute_by_local_name(element: Element, local_name: str) -> str | None:
    return next(
        (
            value
            for name, value in element.attrib.items()
            if _local_name(name) == local_name
        ),
        None,
    )


def _first_descendant(element: Element, local_name: str) -> Element | None:
    return next(
        (item for item in element.iter() if _local_name(item.tag) == local_name),
        None,
    )


def _relationship_part(part_name: str) -> str:
    directory, filename = posixpath.split(part_name)
    return posixpath.join(directory, "_rels", f"{filename}.rels")


def _resolve_target(source_part: str, target: str) -> str:
    if target.startswith("/"):
        normalized = posixpath.normpath(target.lstrip("/"))
    else:
        normalized = posixpath.normpath(
            posixpath.join(posixpath.dirname(source_part), target)
        )
    if normalized == ".." or normalized.startswith("../"):
        msg = "Workbook relationship target escapes the package"
        raise ValueError(msg)
    _validate_member_name(normalized)
    return normalized


def _relationships(package: _SafePackage, source_part: str) -> dict[str, _Relationship]:
    relationship_part = _relationship_part(source_part)
    if not package.has(relationship_part):
        return {}
    root = package.read_xml(relationship_part)
    if root.tag != f"{{{_RELATIONSHIPS_NAMESPACE}}}Relationships":
        msg = "Workbook relationship root or namespace is invalid"
        raise ValueError(msg)
    relationships: dict[str, _Relationship] = {}
    seen_ids: set[str] = set()
    for element in root:
        if element.tag != f"{{{_RELATIONSHIPS_NAMESPACE}}}Relationship":
            msg = "Workbook relationship declaration is invalid"
            raise ValueError(msg)
        relationship_id = element.attrib.get("Id")
        target = element.attrib.get("Target")
        relationship_type = element.attrib.get("Type", "")
        if not relationship_id or not target or not relationship_type:
            msg = "Workbook package contains an invalid relationship"
            raise ValueError(msg)
        if relationship_id in seen_ids:
            msg = "Workbook package contains duplicate relationship identifiers"
            raise ValueError(msg)
        seen_ids.add(relationship_id)
        target_mode = element.attrib.get("TargetMode")
        if target_mode not in {None, "Internal", "External"}:
            msg = "Workbook package relationship has an invalid target mode"
            raise ValueError(msg)
        external = target_mode == "External"
        relationships[relationship_id] = _Relationship(
            target=None if external else _resolve_target(source_part, target),
            relationship_type=relationship_type,
            external=external,
        )
    return relationships

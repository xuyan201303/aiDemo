"""Bounded package-level worksheet row-dimension modification."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import TYPE_CHECKING
from xml.dom import minidom

from document_sdk.core._excel_coordinates import MAX_EXCEL_ROW
from document_sdk.excel._column_modification import (
    _copy_package,
    _direct_elements,
    _document_root,
    _new_element,
    _spreadsheet_element,
)
from document_sdk.excel._package import _SafePackage
from document_sdk.excel._package_security import _serialize_xml
from document_sdk.excel._package_workbook import _workbook_records
from document_sdk.excel._package_worksheet import (
    _SPREADSHEETML_WORKSHEET_NAMESPACES,
)
from document_sdk.excel.errors import ExcelModificationError, ExcelPackageLimitError

if TYPE_CHECKING:
    from collections.abc import Sequence
    from pathlib import Path
    from xml.dom.minidom import Document, Element

    from document_sdk.excel.models import RowDimensionPatch


_TRUE_VALUES = frozenset({"1", "true", "on"})
_MAX_ROW_STATE_ASSIGNMENTS = 100_000


@dataclass(frozen=True, slots=True)
class _PendingRowChange:
    """One normalized whole-row change before public identities are known."""

    sheet_name: str
    start_row: int
    end_row: int
    old_height: float | None
    new_height: float | None
    old_hidden: bool
    new_hidden: bool


@dataclass(frozen=True, slots=True)
class _RowTarget:
    """One worksheet package member and its normalized desired row settings."""

    sheet_name: str
    member: str
    settings: dict[int, dict[str, float | bool]]


def _row_settings(
    patches: Sequence[RowDimensionPatch],
) -> dict[str, dict[int, dict[str, float | bool]]]:
    settings: dict[str, dict[int, dict[str, float | bool]]] = {}
    assignments = 0
    for patch in patches:
        sheet_settings = settings.setdefault(patch.sheet_name, {})
        maximum = patch.end_row or patch.start_row
        assignments += maximum - patch.start_row + 1
        if assignments > _MAX_ROW_STATE_ASSIGNMENTS:
            raise ExcelPackageLimitError(
                limit_name="row_patch_targets",
                observed=assignments,
                maximum=_MAX_ROW_STATE_ASSIGNMENTS,
            )
        for row in range(patch.start_row, maximum + 1):
            target = sheet_settings.setdefault(row, {})
            if patch.height is not None:
                target["height"] = patch.height
            elif patch.clear_height:
                target["clear_height"] = True
            if patch.hidden is not None:
                target["hidden"] = patch.hidden
    return settings


def _resolve_targets(
    source_path: Path,
    patches: Sequence[RowDimensionPatch],
    *,
    source_fingerprint: str | None,
) -> tuple[_RowTarget, ...]:
    requested = _row_settings(patches)
    with _SafePackage(source_path) as package:
        if source_fingerprint is not None:
            package.verify_fingerprint(source_fingerprint)
        _workbook, records = _workbook_records(package)
        by_name = {record.name: record for record in records}
        targets: list[_RowTarget] = []
        for sheet_name, settings in requested.items():
            record = by_name.get(sheet_name)
            if (
                record is None
                or record.sheet_type != "worksheet"
                or record.part_name is None
                or not package.has(record.part_name)
            ):
                msg = "Workbook row patch worksheet does not exist"
                raise ExcelModificationError(msg)
            targets.append(
                _RowTarget(
                    sheet_name=sheet_name,
                    member=record.part_name,
                    settings=settings,
                )
            )
    return tuple(targets)


def _worksheet_sheet_data(root: Element, namespace: str) -> Element:
    matches = tuple(
        element
        for element in _direct_elements(root)
        if _spreadsheet_element(element, "sheetData", namespace)
    )
    if len(matches) != 1:
        msg = "Workbook worksheet must contain one row-data container"
        raise ValueError(msg)
    return matches[0]


def _row_index(element: Element, previous_row: int) -> int:
    raw = element.getAttribute("r")
    try:
        row = previous_row + 1 if raw == "" else int(raw)
    except ValueError:
        msg = "Workbook row metadata is outside Excel bounds"
        raise ValueError(msg) from None
    if row < 1 or row > MAX_EXCEL_ROW or row <= previous_row:
        msg = "Workbook row metadata is outside Excel bounds"
        raise ValueError(msg)
    return row


def _existing_rows(sheet_data: Element, namespace: str) -> dict[int, Element]:
    rows: dict[int, Element] = {}
    previous_row = 0
    assignments = 0
    for element in _direct_elements(sheet_data):
        if not _spreadsheet_element(element, "row", namespace):
            continue
        row = _row_index(element, previous_row)
        previous_row = row
        assignments += 1
        if assignments > _MAX_ROW_STATE_ASSIGNMENTS:
            raise ExcelPackageLimitError(
                limit_name="row_metadata_targets",
                observed=assignments,
                maximum=_MAX_ROW_STATE_ASSIGNMENTS,
            )
        rows[row] = element
    return rows


def _state_height(element: Element | None) -> float | None:
    if element is None or not element.hasAttribute("ht"):
        return None
    try:
        height = float(element.getAttribute("ht"))
    except ValueError:
        msg = "Workbook row height is invalid"
        raise ValueError(msg) from None
    if not math.isfinite(height) or height <= 0:
        msg = "Workbook row height is invalid"
        raise ValueError(msg)
    return height


def _state_hidden(element: Element | None) -> bool:
    return element is not None and element.getAttribute("hidden") in _TRUE_VALUES


def _height_text(value: float) -> str:
    return format(value, ".15g")


def _insert_row(
    document: Document,
    sheet_data: Element,
    namespace: str,
    rows: dict[int, Element],
    row: int,
) -> Element:
    element = _new_element(document, namespace, "row")
    element.setAttribute("r", str(row))
    following = next((rows[index] for index in sorted(rows) if index > row), None)
    sheet_data.insertBefore(element, following)
    rows[row] = element
    return element


def _group_changes(
    atomic: list[_PendingRowChange],
) -> tuple[_PendingRowChange, ...]:
    grouped: list[_PendingRowChange] = []
    for change in atomic:
        if (
            grouped
            and grouped[-1].sheet_name == change.sheet_name
            and grouped[-1].end_row + 1 == change.start_row
            and grouped[-1].old_height == change.old_height
            and grouped[-1].new_height == change.new_height
            and grouped[-1].old_hidden == change.old_hidden
            and grouped[-1].new_hidden == change.new_hidden
        ):
            previous = grouped[-1]
            grouped[-1] = _PendingRowChange(
                sheet_name=previous.sheet_name,
                start_row=previous.start_row,
                end_row=change.end_row,
                old_height=previous.old_height,
                new_height=previous.new_height,
                old_hidden=previous.old_hidden,
                new_hidden=previous.new_hidden,
            )
        else:
            grouped.append(change)
    return tuple(grouped)


def _apply_settings(  # noqa: PLR0913
    document: Document,
    sheet_data: Element,
    namespace: str,
    rows: dict[int, Element],
    settings: dict[int, dict[str, float | bool]],
    *,
    sheet_name: str,
) -> tuple[_PendingRowChange, ...]:
    atomic: list[_PendingRowChange] = []
    for row in sorted(settings):
        before = rows.get(row)
        old_height = _state_height(before)
        old_hidden = _state_hidden(before)
        requested = settings[row]
        height = requested.get("height")
        clear_height = requested.get("clear_height") is True
        hidden = requested.get("hidden")
        height_changed = (isinstance(height, float) and old_height != height) or (
            clear_height and old_height is not None
        )
        hidden_changed = isinstance(hidden, bool) and old_hidden != hidden
        if not height_changed and not hidden_changed:
            continue

        element = before or _insert_row(document, sheet_data, namespace, rows, row)
        if height_changed and isinstance(height, float):
            element.setAttribute("ht", _height_text(height))
            element.setAttribute("customHeight", "1")
        elif height_changed and clear_height:
            element.removeAttribute("ht")
            element.removeAttribute("customHeight")
        if hidden_changed and hidden is True:
            element.setAttribute("hidden", "1")
        elif hidden_changed and hidden is False:
            element.removeAttribute("hidden")
        if (
            before is not None
            and set(element.attributes.keys()) <= {"r"}
            and not element.childNodes
        ):
            sheet_data.removeChild(element)
            rows.pop(row)
        atomic.append(
            _PendingRowChange(
                sheet_name=sheet_name,
                start_row=row,
                end_row=row,
                old_height=old_height,
                new_height=_state_height(element),
                old_hidden=old_hidden,
                new_hidden=_state_hidden(element),
            )
        )
    return _group_changes(atomic)


def _patch_worksheet(
    payload: bytes,
    *,
    sheet_name: str,
    settings: dict[int, dict[str, float | bool]],
) -> tuple[bytes, tuple[_PendingRowChange, ...]]:
    document = minidom.parseString(  # noqa: S318 - bounded, DTD-screened OOXML.
        payload
    )
    root = _document_root(document)
    namespace = root.namespaceURI
    if namespace not in _SPREADSHEETML_WORKSHEET_NAMESPACES:
        msg = "Workbook worksheet namespace is unsupported"
        raise ValueError(msg)
    sheet_data = _worksheet_sheet_data(root, namespace)
    rows = _existing_rows(sheet_data, namespace)
    changes = _apply_settings(
        document,
        sheet_data,
        namespace,
        rows,
        settings,
        sheet_name=sheet_name,
    )
    if not changes:
        return payload, ()
    return _serialize_xml(document), changes


def create_row_patch_output(
    source_path: Path,
    output_path: Path,
    patches: Sequence[RowDimensionPatch],
    *,
    source_fingerprint: str,
) -> tuple[_PendingRowChange, ...]:
    """Write and verify one package-level row-dimension patch output."""
    targets = _resolve_targets(
        source_path,
        patches,
        source_fingerprint=source_fingerprint,
    )
    replacements: dict[str, bytes] = {}
    pending: list[_PendingRowChange] = []
    with _SafePackage(source_path) as package:
        package.verify_fingerprint(source_fingerprint)
        for target in targets:
            with package.open_xml_stream(target.member) as stream:
                payload = stream.read()
            replacement, changes = _patch_worksheet(
                payload,
                sheet_name=target.sheet_name,
                settings=target.settings,
            )
            if changes:
                replacements[target.member] = replacement
            pending.extend(changes)
    _copy_package(
        source_path,
        output_path,
        replacements,
        source_fingerprint=source_fingerprint,
    )
    verify_row_patch_output(output_path, patches)
    return tuple(pending)


def verify_row_patch_output(
    output_path: Path,
    patches: Sequence[RowDimensionPatch],
) -> None:
    """Verify requested row settings from the independently reopened package."""
    targets = _resolve_targets(output_path, patches, source_fingerprint=None)
    with _SafePackage(output_path) as package:
        for target in targets:
            with package.open_xml_stream(target.member) as stream:
                document = minidom.parse(  # noqa: S318 - bounded OOXML.
                    stream
                )
            root = _document_root(document)
            namespace = root.namespaceURI
            if namespace not in _SPREADSHEETML_WORKSHEET_NAMESPACES:
                msg = "Patched workbook worksheet namespace is unsupported"
                raise ExcelModificationError(msg)
            sheet_data = _worksheet_sheet_data(root, namespace)
            rows = _existing_rows(sheet_data, namespace)
            for row, expected in target.settings.items():
                element = rows.get(row)
                expected_height = expected.get("height")
                if isinstance(expected_height, float) and not math.isclose(
                    _state_height(element) or 0.0,
                    expected_height,
                    rel_tol=0.0,
                    abs_tol=1e-12,
                ):
                    msg = "Patched workbook row-height verification failed"
                    raise ExcelModificationError(msg)
                if (
                    expected.get("clear_height") is True
                    and _state_height(element) is not None
                ):
                    msg = "Patched workbook row-height clearing verification failed"
                    raise ExcelModificationError(msg)
                expected_hidden = expected.get("hidden")
                if (
                    isinstance(expected_hidden, bool)
                    and _state_hidden(element) != expected_hidden
                ):
                    msg = "Patched workbook row-visibility verification failed"
                    raise ExcelModificationError(msg)

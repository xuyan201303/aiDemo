"""Same-handle workbook content-identity verification."""

from __future__ import annotations

from contextlib import contextmanager
from typing import TYPE_CHECKING

from document_sdk.files._source_identity import (
    verify_open_binary as _verify_file_identity,
)

if TYPE_CHECKING:
    from collections.abc import Iterator
    from pathlib import Path
    from typing import BinaryIO


def verify_open_binary(stream: BinaryIO, expected_fingerprint: str) -> None:
    """Hash and rewind the same binary handle that a parser will consume."""
    _verify_file_identity(
        stream,
        expected_fingerprint=expected_fingerprint,
        mismatch_message="Workbook changed after inspection",
    )


@contextmanager
def open_verified_binary(
    path: Path,
    expected_fingerprint: str | None,
) -> Iterator[BinaryIO]:
    """Open a workbook and verify the exact handle before yielding it."""
    with path.open("rb") as stream:
        if expected_fingerprint is not None:
            verify_open_binary(stream, expected_fingerprint)
        yield stream

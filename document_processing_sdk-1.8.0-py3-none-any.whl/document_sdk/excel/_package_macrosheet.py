"""Bounded, non-executing Excel 4.0 Macro Sheet inspection."""

from __future__ import annotations

import re
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from hashlib import sha256
from typing import TYPE_CHECKING, Any, cast
from xml.etree.ElementTree import iterparse

from document_sdk.core._excel_coordinates import (
    MAX_EXCEL_ROW,
    excel_range_bounds,
    normalize_excel_coordinate,
    normalize_excel_range,
)
from document_sdk.excel._package_chartsheet import (
    _content_types,
    _namespace,
    _part_content_type,
    _relationship_closure,
)
from document_sdk.excel._package_security import (
    _local_name,
    _relationships,
    _SafePackage,
)
from document_sdk.excel._package_worksheet import (
    _SPREADSHEETML_WORKSHEET_NAMESPACES,
)
from document_sdk.excel._visible_text import _VisibleTextAccumulator
from document_sdk.excel.errors import ExcelPackageLimitError
from document_sdk.excel.models import ExcelPackageLimits, MacroSheetFeatureInventory

if TYPE_CHECKING:
    from typing import IO
    from xml.etree.ElementTree import Element

    from document_sdk.excel._package_types import _Relationship, _SheetRecord


_MACRO_SHEET_CONTENT_TYPE = "application/vnd.ms-excel.macrosheet+xml"
_MACRO_SHEET_NAMESPACE = "http://schemas.microsoft.com/office/excel/2006/main"
_OFFICE_RELATIONSHIP_NAMESPACES = frozenset(
    {
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
        "http://purl.oclc.org/ooxml/officeDocument/relationships",
    }
)
_PRINTER_SETTINGS_CONTENT_TYPE = (
    "application/vnd.openxmlformats-officedocument.spreadsheetml.printerSettings"
)
_SHARED_STRINGS_CONTENT_TYPE = (
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"
)
_MAX_MACRO_SHEET_RECORDS = 100_000
_ROW_DEPTH = 2
_CELL_DEPTH = 3
_CELL_CHILD_DEPTH = 4
_INLINE_STRING_DEPTH = 4
_INLINE_TEXT_DEPTH = 5
_INLINE_RUN_TEXT_DEPTH = 6
_SHARED_STRING_ITEM_STACK_LENGTH = 2
_SHARED_STRING_TEXT_STACK_LENGTH = 3
_SHARED_STRING_RUN_TEXT_STACK_LENGTH = 4
_SHARED_STRING_TEXT_DEPTH = 2
_SHARED_STRING_RUN_TEXT_DEPTH = 3
_MAX_EXCEL_COLUMN_LETTERS = 3
_CELL_COORDINATE_PATTERN = re.compile(r"^([A-Za-z]+)([0-9]+)$")


def _bounded_row_number(value: str) -> int:
    if re.fullmatch(r"[0-9]+", value) is None:
        msg = "Macro Sheet row index is invalid"
        raise ValueError(msg)
    significant = value.lstrip("0") or "0"
    maximum = str(MAX_EXCEL_ROW)
    if len(significant) > len(maximum) or (
        len(significant) == len(maximum) and significant > maximum
    ):
        msg = "Macro Sheet row index is invalid"
        raise ValueError(msg)
    row = int(significant)
    if row < 1:
        msg = "Macro Sheet row index is invalid"
        raise ValueError(msg)
    return row


def _macro_row_index(value: str | None, previous_row: int) -> int:
    row = previous_row + 1 if value is None else _bounded_row_number(value)
    if row > MAX_EXCEL_ROW or row <= previous_row:
        msg = "Macro Sheet rows are not in deterministic order"
        raise ValueError(msg)
    return row


def _macro_cell_position(value: str) -> tuple[str, int, int]:
    match = _CELL_COORDINATE_PATTERN.fullmatch(value)
    if match is None:
        msg = "Macro Sheet cell coordinate is invalid"
        raise ValueError(msg)
    column, raw_row = match.groups()
    if len(column) > _MAX_EXCEL_COLUMN_LETTERS:
        msg = "Macro Sheet cell coordinate is invalid"
        raise ValueError(msg)
    _bounded_row_number(raw_row)
    coordinate = normalize_excel_coordinate(value)
    bounds = excel_range_bounds(coordinate)
    return coordinate, bounds.min_row, bounds.min_column


@dataclass(frozen=True, slots=True)
class _MacroSheetFacts:
    """Public inventory plus private package-closure preservation evidence."""

    inventory: MacroSheetFeatureInventory
    relationship_edges: tuple[tuple[str, str, str, str | None, bool], ...]
    closure_members: tuple[str, ...]
    formula_cache_present: bool
    shared_strings_part: str | None
    shared_strings_part_sha256: str | None
    shared_strings_relationship_type: str | None


@dataclass(frozen=True, slots=True)
class _MacroCellEvidence:
    """Content-safe evidence retained until Shared String resolution."""

    coordinate: str
    cell_type: str
    shared_string_index: int | None
    value_evidence: str


@dataclass(frozen=True, slots=True)
class _SharedStringTable:
    """Bounded Shared String dependency represented without plaintext."""

    part: str
    part_sha256: str
    entry_digests: tuple[str, ...]
    relationship_type: str


@dataclass(slots=True)
class _SharedStringTableCache:
    """Lazily parse one package's Shared Strings table at most once."""

    package: _SafePackage
    entry_limit: int | None
    _loaded: bool = False
    _value: _SharedStringTable | None = None

    def __call__(self) -> _SharedStringTable:
        if not self._loaded:
            self._value = _shared_string_table(
                self.package,
                content_types=_content_types(self.package),
                entry_limit=self.entry_limit,
            )
            self._loaded = True
        if self._value is None:  # pragma: no cover - successful load sets a value.
            msg = "Macro Sheet Shared Strings state is invalid"
            raise RuntimeError(msg)
        return self._value


@dataclass(frozen=True, slots=True)
class _MacroSheetStreamFacts:
    """Scalar-only facts projected from one streamed Macro Sheet XML part."""

    dimension_reference: str | None
    row_count: int
    cell_count: int
    formula_count: int
    value_count: int
    part_sha256: str
    formula_digest_sha256: str
    formula_cache_present: bool
    shared_string_references: tuple[tuple[str, int], ...]
    non_formula_cells: tuple[_MacroCellEvidence, ...]
    relationship_references: frozenset[str]
    printer_relationship_ids: tuple[str, ...]


@dataclass(slots=True)
class _RecordBudget:
    """One cumulative scalar-record budget for Macro Sheet projection."""

    maximum: int
    observed: int = 0

    def reserve(self) -> None:
        self.observed += 1
        if self.observed > self.maximum:
            raise ExcelPackageLimitError(
                limit_name="worksheet_feature_records",
                observed=self.observed,
                maximum=self.maximum,
            )


class _HashingReader:
    """Hash the exact decompressed XML bytes consumed by iterparse."""

    def __init__(self, stream: IO[bytes]) -> None:
        self._stream = stream
        self._digest = sha256()

    def read(self, size: int = -1) -> bytes:
        chunk = self._stream.read(size)
        self._digest.update(chunk)
        return chunk

    def hexdigest(self) -> str:
        return self._digest.hexdigest()


def _update_digest(digest: Any, *parts: str) -> None:
    """Frame UTF-8 fields so adjacent records cannot collide."""
    for part in parts:
        payload = part.encode("utf-8")
        digest.update(len(payload).to_bytes(8, "big"))
        digest.update(payload)


def _text_digest(value: str) -> str:
    return sha256(value.encode("utf-8")).hexdigest()


def _canonical_decimal(value: str) -> str:
    try:
        number = Decimal(value.strip())
    except InvalidOperation:
        msg = "Macro Sheet numeric cell value is invalid"
        raise ValueError(msg) from None
    if not number.is_finite():
        msg = "Macro Sheet numeric cell value is invalid"
        raise ValueError(msg)
    sign, raw_digits, raw_exponent = number.as_tuple()
    exponent = cast("int", raw_exponent)
    digits = list(raw_digits)
    while digits and digits[-1] == 0:
        digits.pop()
        exponent += 1
    if not digits:
        return "0"
    return f"{sign}:{''.join(str(digit) for digit in digits)}:{exponent}"


def _non_shared_value_evidence(
    cell_type: str,
    value: str | None,
    inline_string_digest: str,
) -> str:
    if cell_type == "inlineStr":
        return f"inline:{inline_string_digest}"
    if value is None:
        return "none"
    if cell_type == "b":
        if value not in {"0", "1"}:
            msg = "Macro Sheet boolean cell value is invalid"
            raise ValueError(msg)
        return f"boolean:{value}"
    if cell_type in {"n", ""}:
        return f"number:{_canonical_decimal(value)}"
    return f"text:{_text_digest(value)}"


def _shared_string_index(value: str | None) -> int:
    candidate = "" if value is None else value.strip()
    if re.fullmatch(r"\+?\d+", candidate) is None:
        msg = "Macro Sheet Shared String index is invalid"
        raise ValueError(msg)
    return int(candidate)


def _relationship_ids(element: Element) -> tuple[str, ...]:
    return tuple(
        value
        for name, value in element.attrib.items()
        if _namespace(name) in _OFFICE_RELATIONSHIP_NAMESPACES
        and _local_name(name) in {"id", "embed", "link"}
        and value
    )


def _stream_macro_sheet(  # noqa: C901, PLR0912, PLR0915
    package: _SafePackage,
    part: str,
    *,
    feature_record_limit: int | None,
) -> _MacroSheetStreamFacts:
    maximum = (
        _MAX_MACRO_SHEET_RECORDS
        if feature_record_limit is None
        else feature_record_limit
    )
    budget = _RecordBudget(maximum)
    dimension_reference: str | None = None
    row_count = 0
    cell_count = 0
    formula_count = 0
    value_count = 0
    formula_digest = sha256()
    references: set[str] = set()
    printer_relationship_ids: list[str] = []
    shared_string_references: list[tuple[str, int]] = []
    non_formula_cells: list[_MacroCellEvidence] = []
    current_coordinate: str | None = None
    current_cell_type = "n"
    current_value: str | None = None
    current_value_seen = False
    current_formula_seen = False
    current_cell_has_formula = False
    current_cell_has_value = False
    formula_cache_present = False
    current_inline_text: _VisibleTextAccumulator | None = None
    previous_row = 0
    current_row: int | None = None
    previous_column = 0
    stack: list[Element] = []

    with package.open_xml_stream(part) as stream:
        hashing_stream = _HashingReader(stream)
        for event, element in iterparse(  # noqa: S314 - stream rejects DTD/entities.
            hashing_stream,
            events=("start", "end"),
        ):
            if event == "start":
                if not stack and (
                    _local_name(element.tag) != "macrosheet"
                    or _namespace(element.tag) != _MACRO_SHEET_NAMESPACE
                ):
                    msg = "Macro Sheet XML root is invalid"
                    raise ValueError(msg)
                stack.append(element)
                references.update(_relationship_ids(element))
                depth = len(stack) - 1
                local = _local_name(element.tag)
                namespace = _namespace(element.tag)
                if depth == 1 and namespace in _SPREADSHEETML_WORKSHEET_NAMESPACES:
                    if local == "dimension":
                        if dimension_reference is not None:
                            msg = "Macro Sheet contains duplicate dimensions"
                            raise ValueError(msg)
                        raw_dimension = element.attrib.get("ref")
                        if not raw_dimension:
                            msg = "Macro Sheet dimension is invalid"
                            raise ValueError(msg)
                        dimension_reference = normalize_excel_range(raw_dimension)
                    elif local == "pageSetup":
                        identifiers = _relationship_ids(element)
                        if len(identifiers) > 1:
                            msg = "Macro Sheet printer relationship is invalid"
                            raise ValueError(msg)
                        printer_relationship_ids.extend(identifiers)
                elif (
                    depth == _ROW_DEPTH
                    and namespace in _SPREADSHEETML_WORKSHEET_NAMESPACES
                    and local == "row"
                    and _local_name(stack[1].tag) == "sheetData"
                    and _namespace(stack[1].tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
                ):
                    current_row = _macro_row_index(
                        element.attrib.get("r"),
                        previous_row,
                    )
                    previous_column = 0
                    row_count += 1
                    budget.reserve()
                elif (
                    depth == _CELL_DEPTH
                    and namespace in _SPREADSHEETML_WORKSHEET_NAMESPACES
                    and local == "c"
                    and _local_name(stack[1].tag) == "sheetData"
                    and _namespace(stack[1].tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
                    and _local_name(stack[2].tag) == "row"
                    and _namespace(stack[2].tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
                ):
                    coordinate = element.attrib.get("r")
                    if not coordinate or current_row is None:
                        msg = "Macro Sheet cell coordinate is invalid"
                        raise ValueError(msg)
                    normalized, coordinate_row, coordinate_column = (
                        _macro_cell_position(coordinate)
                    )
                    if (
                        coordinate_row != current_row
                        or coordinate_column <= previous_column
                    ):
                        msg = "Macro Sheet cells are not in deterministic row order"
                        raise ValueError(msg)
                    current_coordinate = normalized
                    previous_column = coordinate_column
                    current_cell_type = element.attrib.get("t", "n")
                    current_value = None
                    current_value_seen = False
                    current_formula_seen = False
                    cell_count += 1
                    budget.reserve()
                    current_cell_has_formula = False
                    current_cell_has_value = False
                    current_inline_text = None
                elif (
                    current_coordinate is not None
                    and current_cell_type == "inlineStr"
                    and depth == _INLINE_STRING_DEPTH
                    and local == "is"
                    and namespace in _SPREADSHEETML_WORKSHEET_NAMESPACES
                    and _local_name(stack[3].tag) == "c"
                    and _namespace(stack[3].tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
                ):
                    if current_inline_text is not None:
                        msg = "Macro Sheet inline String XML is invalid"
                        raise ValueError(msg)
                    current_inline_text = _VisibleTextAccumulator(
                        label="inline String",
                        retain_text=False,
                    )
                elif (
                    current_inline_text is not None
                    and depth == _INLINE_TEXT_DEPTH
                    and _local_name(stack[4].tag) == "is"
                    and _namespace(stack[4].tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
                    and namespace in _SPREADSHEETML_WORKSHEET_NAMESPACES
                ):
                    if local == "t":
                        current_inline_text.start_plain()
                    elif local == "r":
                        current_inline_text.start_run()
                elif (
                    current_inline_text is not None
                    and depth == _INLINE_RUN_TEXT_DEPTH
                    and local == "t"
                    and namespace in _SPREADSHEETML_WORKSHEET_NAMESPACES
                    and _local_name(stack[5].tag) == "r"
                    and _namespace(stack[5].tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
                    and _local_name(stack[4].tag) == "is"
                    and _namespace(stack[4].tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
                ):
                    current_inline_text.start_run_text()
                continue

            depth = len(stack) - 1
            local = _local_name(element.tag)
            namespace = _namespace(element.tag)
            if (
                depth == _CELL_CHILD_DEPTH
                and namespace in _SPREADSHEETML_WORKSHEET_NAMESPACES
                and _local_name(stack[3].tag) == "c"
                and _namespace(stack[3].tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
                and _local_name(stack[2].tag) == "row"
                and _namespace(stack[2].tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
                and _local_name(stack[1].tag) == "sheetData"
                and _namespace(stack[1].tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
            ):
                if local == "f":
                    if current_coordinate is None or current_formula_seen:
                        msg = "Macro Sheet formula record is invalid"
                        raise ValueError(msg)
                    formula = element.text or ""
                    formula_digest.update(current_coordinate.encode("utf-8"))
                    formula_digest.update(b"\0")
                    formula_digest.update(formula.encode("utf-8"))
                    formula_digest.update(b"\0")
                    formula_count += 1
                    budget.reserve()
                    current_formula_seen = True
                    current_cell_has_formula = True
                elif local == "v":
                    if current_coordinate is None or current_value_seen:
                        msg = "Macro Sheet cell value record is invalid"
                        raise ValueError(msg)
                    value_count += 1
                    budget.reserve()
                    current_value_seen = True
                    current_value = element.text or ""
                    current_cell_has_value = element.text is not None
            elif (
                current_inline_text is not None
                and depth == _INLINE_TEXT_DEPTH
                and local == "t"
                and namespace in _SPREADSHEETML_WORKSHEET_NAMESPACES
                and _local_name(stack[4].tag) == "is"
                and _namespace(stack[4].tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
            ) or (
                current_inline_text is not None
                and depth == _INLINE_RUN_TEXT_DEPTH
                and local == "t"
                and namespace in _SPREADSHEETML_WORKSHEET_NAMESPACES
                and _local_name(stack[5].tag) == "r"
                and _namespace(stack[5].tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
                and _local_name(stack[4].tag) == "is"
                and _namespace(stack[4].tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
            ):
                current_inline_text.update(element.text)
            elif (
                current_inline_text is not None
                and depth == _INLINE_TEXT_DEPTH
                and local == "r"
                and namespace in _SPREADSHEETML_WORKSHEET_NAMESPACES
                and _local_name(stack[4].tag) == "is"
                and _namespace(stack[4].tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
            ):
                current_inline_text.finish_run()

            if (
                depth == _CELL_DEPTH
                and local == "c"
                and namespace in _SPREADSHEETML_WORKSHEET_NAMESPACES
                and _local_name(stack[2].tag) == "row"
                and _namespace(stack[2].tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
                and _local_name(stack[1].tag) == "sheetData"
                and _namespace(stack[1].tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
            ):
                if current_coordinate is None:
                    msg = "Macro Sheet cell state is invalid"
                    raise ValueError(msg)
                if current_cell_type == "inlineStr" and current_inline_text is None:
                    msg = "Macro Sheet inline String XML is invalid"
                    raise ValueError(msg)
                shared_index: int | None = None
                if current_cell_type == "s":
                    if not current_value_seen:
                        msg = "Macro Sheet Shared String index is missing"
                        raise ValueError(msg)
                    shared_index = _shared_string_index(current_value)
                    shared_string_references.append((current_coordinate, shared_index))
                if not current_formula_seen:
                    non_formula_cells.append(
                        _MacroCellEvidence(
                            coordinate=current_coordinate,
                            cell_type=current_cell_type,
                            shared_string_index=shared_index,
                            value_evidence=(
                                ""
                                if shared_index is not None
                                else _non_shared_value_evidence(
                                    current_cell_type,
                                    current_value if current_value_seen else None,
                                    (
                                        current_inline_text.hexdigest()
                                        if current_inline_text is not None
                                        else sha256().hexdigest()
                                    ),
                                )
                            ),
                        )
                    )
                formula_cache_present = formula_cache_present or (
                    current_cell_has_formula and current_cell_has_value
                )
                current_coordinate = None

            if (
                depth == _ROW_DEPTH
                and local == "row"
                and namespace in _SPREADSHEETML_WORKSHEET_NAMESPACES
                and _local_name(stack[1].tag) == "sheetData"
                and _namespace(stack[1].tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
            ):
                if current_row is None:
                    msg = "Macro Sheet row state is invalid"
                    raise ValueError(msg)
                previous_row = current_row
                current_row = None
                previous_column = 0

            if depth > 0:
                parent = stack[-2]
                element.clear()
                parent.remove(element)
            stack.pop()

    if stack:
        msg = "Macro Sheet XML stream is incomplete"
        raise ValueError(msg)
    return _MacroSheetStreamFacts(
        dimension_reference=dimension_reference,
        row_count=row_count,
        cell_count=cell_count,
        formula_count=formula_count,
        value_count=value_count,
        part_sha256=hashing_stream.hexdigest(),
        formula_digest_sha256=formula_digest.hexdigest(),
        formula_cache_present=formula_cache_present,
        shared_string_references=tuple(shared_string_references),
        non_formula_cells=tuple(non_formula_cells),
        relationship_references=frozenset(references),
        printer_relationship_ids=tuple(printer_relationship_ids),
    )


def _sheet_reference_matches(names: list[str], expected: str) -> bool:
    return any(
        "[" not in name and "]" not in name and name.casefold() == expected
        for name in names
    )


def _quoted_sheet_reference(
    definition: str,
    index: int,
) -> tuple[list[str], int] | None:
    candidate: list[str] = []
    cursor = index + 1
    while cursor < len(definition):
        quoted_value = definition[cursor]
        if quoted_value != "'":
            candidate.append(quoted_value)
            cursor += 1
            continue
        if cursor + 1 < len(definition) and definition[cursor + 1] == "'":
            candidate.append("'")
            cursor += 2
            continue
        if definition[cursor + 1 : cursor + 2] == "!":
            return "".join(candidate).split(":"), cursor + 2
        return None
    return None


def _unquoted_sheet_reference(definition: str, index: int) -> list[str]:
    delimiters = frozenset("=+-*/^&(),<>;{} \t\r\n")
    cursor = index - 1
    while cursor >= 0 and definition[cursor] not in delimiters:
        cursor -= 1
    return definition[cursor + 1 : index].split(":")


def _definition_references_sheet(definition: str, sheet_name: str) -> bool:
    expected = sheet_name.casefold()
    index = 0
    in_string = False
    while index < len(definition):
        value = definition[index]
        if value == '"':
            if (
                in_string
                and index + 1 < len(definition)
                and definition[index + 1] == '"'
            ):
                index += 2
                continue
            in_string = not in_string
            index += 1
            continue
        if in_string:
            index += 1
            continue
        if value == "'":
            reference = _quoted_sheet_reference(definition, index)
            if reference is not None:
                names, index = reference
                if _sheet_reference_matches(names, expected):
                    return True
                continue
        elif value == "!":
            names = _unquoted_sheet_reference(definition, index)
            if _sheet_reference_matches(names, expected):
                return True
        index += 1
    return False


def _valid_local_sheet_id(value: str | None) -> int | None:
    if value is None or re.fullmatch(r"\d+", value) is None:
        return None
    return int(value)


def _defined_name_record_digest(element: Element) -> str:
    digest = sha256()
    _update_digest(
        digest,
        "name",
        element.attrib.get("name", "").casefold(),
    )
    attributes = sorted(
        (
            _namespace(name),
            _local_name(name),
            value,
        )
        for name, value in element.attrib.items()
    )
    for namespace, name, value in attributes:
        _update_digest(digest, "attribute", namespace, name, value)
    _update_digest(digest, "definition", "".join(element.itertext()))
    return digest.hexdigest()


def _relevant_defined_name_record_digests(
    workbook: Element,
    *,
    sheets: tuple[tuple[str, int], ...],
) -> tuple[str, ...]:
    workbook_namespace = _namespace(workbook.tag)
    records: list[str] = []
    for element in workbook.iter():
        if (
            _local_name(element.tag) != "definedName"
            or _namespace(element.tag) != workbook_namespace
        ):
            continue
        definition = "".join(element.itertext())
        local_sheet_id = _valid_local_sheet_id(element.attrib.get("localSheetId"))
        if not any(
            _definition_references_sheet(definition, sheet_name)
            or local_sheet_id == sheet_index
            for sheet_name, sheet_index in sheets
        ):
            continue
        records.append(_defined_name_record_digest(element))
    return tuple(records)


def _defined_name_evidence(
    workbook: Element,
    sheet_name: str,
    *,
    workbook_order: int,
) -> tuple[int, str]:
    records = _relevant_defined_name_record_digests(
        workbook,
        sheets=((sheet_name, workbook_order - 1),),
    )
    digest = sha256()
    for record in records:
        _update_digest(digest, "defined-name", record)
    return len(records), digest.hexdigest()


def _workbook_shared_strings_relationship(
    package: _SafePackage,
) -> tuple[_Relationship, str]:
    relationships = _relationships(package, "xl/workbook.xml")
    candidates = tuple(
        relationship
        for relationship in relationships.values()
        if relationship.relationship_type.rsplit("/", 1)[-1].casefold()
        == "sharedstrings"
    )
    if len(candidates) != 1:
        msg = "Macro Sheet Shared Strings relationship is invalid"
        raise ValueError(msg)
    relationship = candidates[0]
    target = relationship.target
    if (
        relationship.external
        or not isinstance(target, str)
        or not target.casefold().startswith("xl/")
        or not package.has(target)
    ):
        msg = "Macro Sheet Shared Strings target is invalid"
        raise ValueError(msg)
    return relationship, target


def _shared_string_table(  # noqa: C901, PLR0912
    package: _SafePackage,
    *,
    content_types: tuple[dict[str, str], dict[str, str]],
    entry_limit: int | None = None,
) -> _SharedStringTable:
    relationship, part = _workbook_shared_strings_relationship(package)
    if _part_content_type(part, content_types) != _SHARED_STRINGS_CONTENT_TYPE:
        msg = "Macro Sheet Shared Strings content type is invalid"
        raise ValueError(msg)

    entries: list[str] = []
    stack: list[Element] = []
    current_text: _VisibleTextAccumulator | None = None
    maximum = (
        ExcelPackageLimits().shared_string_entries
        if entry_limit is None
        else entry_limit
    )
    with package.open_xml_stream(part) as stream:
        hashing_stream = _HashingReader(stream)
        for event, element in iterparse(  # noqa: S314 - DTD/entities rejected.
            hashing_stream,
            events=("start", "end"),
        ):
            if event == "start":
                if not stack and (
                    _local_name(element.tag) != "sst"
                    or _namespace(element.tag)
                    not in _SPREADSHEETML_WORKSHEET_NAMESPACES
                ):
                    msg = "Macro Sheet Shared Strings XML is invalid"
                    raise ValueError(msg)
                stack.append(element)
                if (
                    len(stack) == _SHARED_STRING_ITEM_STACK_LENGTH
                    and _local_name(element.tag) == "si"
                    and _namespace(element.tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
                ):
                    current_text = _VisibleTextAccumulator(
                        label="Shared String",
                        retain_text=False,
                    )
                elif (
                    current_text is not None
                    and len(stack) == _SHARED_STRING_TEXT_STACK_LENGTH
                ):
                    if (
                        _local_name(stack[1].tag) == "si"
                        and _namespace(stack[1].tag)
                        in _SPREADSHEETML_WORKSHEET_NAMESPACES
                        and _namespace(element.tag)
                        in _SPREADSHEETML_WORKSHEET_NAMESPACES
                    ):
                        if _local_name(element.tag) == "t":
                            current_text.start_plain()
                        elif _local_name(element.tag) == "r":
                            current_text.start_run()
                elif (
                    current_text is not None
                    and len(stack) == _SHARED_STRING_RUN_TEXT_STACK_LENGTH
                    and _local_name(stack[1].tag) == "si"
                    and _namespace(stack[1].tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
                    and _local_name(stack[2].tag) == "r"
                    and _namespace(stack[2].tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
                    and _local_name(element.tag) == "t"
                    and _namespace(element.tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
                ):
                    current_text.start_run_text()
                continue

            depth = len(stack) - 1
            if (
                current_text is not None
                and depth == _SHARED_STRING_TEXT_DEPTH
                and _local_name(element.tag) == "t"
                and _namespace(element.tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
                and _local_name(stack[1].tag) == "si"
                and _namespace(stack[1].tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
            ) or (
                current_text is not None
                and depth == _SHARED_STRING_RUN_TEXT_DEPTH
                and _local_name(element.tag) == "t"
                and _namespace(element.tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
                and _local_name(stack[2].tag) == "r"
                and _namespace(stack[2].tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
                and _local_name(stack[1].tag) == "si"
                and _namespace(stack[1].tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
            ):
                current_text.update(element.text)
            elif (
                current_text is not None
                and depth == _SHARED_STRING_TEXT_DEPTH
                and _local_name(element.tag) == "r"
                and _namespace(element.tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
                and _local_name(stack[1].tag) == "si"
                and _namespace(stack[1].tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
            ):
                current_text.finish_run()
            if (
                depth == 1
                and _local_name(element.tag) == "si"
                and _namespace(element.tag) in _SPREADSHEETML_WORKSHEET_NAMESPACES
            ):
                if current_text is None:
                    msg = "Macro Sheet Shared String state is invalid"
                    raise ValueError(msg)
                entries.append(current_text.hexdigest())
                current_text = None
                if len(entries) > maximum:
                    raise ExcelPackageLimitError(
                        limit_name="shared_string_entries",
                        observed=len(entries),
                        maximum=maximum,
                    )
            if depth > 0:
                parent = stack[-2]
                element.clear()
                parent.remove(element)
            stack.pop()
    if stack:
        msg = "Macro Sheet Shared Strings XML is incomplete"
        raise ValueError(msg)
    return _SharedStringTable(
        part=part,
        part_sha256=hashing_stream.hexdigest(),
        entry_digests=tuple(entries),
        relationship_type=relationship.relationship_type,
    )


def _content_digests(
    stream_facts: _MacroSheetStreamFacts,
    shared_strings: _SharedStringTable | None,
) -> tuple[str, str]:
    shared_digest = sha256()
    resolved_shared: dict[tuple[str, int], str] = {}
    for coordinate, index in stream_facts.shared_string_references:
        if shared_strings is None or index >= len(shared_strings.entry_digests):
            msg = "Macro Sheet Shared String index is out of range"
            raise ValueError(msg)
        value_digest = shared_strings.entry_digests[index]
        resolved_shared[(coordinate, index)] = value_digest
        _update_digest(
            shared_digest,
            "shared-string",
            coordinate,
            str(index),
            value_digest,
        )

    non_formula_digest = sha256()
    for cell in stream_facts.non_formula_cells:
        value_evidence = cell.value_evidence
        if cell.shared_string_index is not None:
            value_evidence = (
                "shared:" + resolved_shared[(cell.coordinate, cell.shared_string_index)]
            )
        _update_digest(
            non_formula_digest,
            "cell",
            cell.coordinate,
            cell.cell_type,
            value_evidence,
        )
    return shared_digest.hexdigest(), non_formula_digest.hexdigest()


def _validate_printer_settings(
    package: _SafePackage,
    part: str,
    relationship_ids: tuple[str, ...],
) -> None:
    relationships = _relationships(package, part)
    content_types = _content_types(package)
    for relationship_id in relationship_ids:
        relationship = relationships.get(relationship_id)
        target = None if relationship is None else relationship.target
        if (
            relationship is None
            or relationship.external
            or relationship.relationship_type.rsplit("/", 1)[-1].casefold()
            != "printersettings"
            or not isinstance(target, str)
            or not target.casefold().startswith("xl/printersettings/")
            or not package.has(target)
            or _part_content_type(target, content_types)
            != _PRINTER_SETTINGS_CONTENT_TYPE
        ):
            msg = "Macro Sheet printer settings target is invalid"
            raise ValueError(msg)


def _macro_sheet_facts(  # noqa: PLR0913
    package: _SafePackage,
    *,
    workbook: Element,
    sheet: _SheetRecord,
    workbook_order: int,
    feature_record_limit: int | None = None,
    shared_string_entry_limit: int | None = None,
    shared_string_loader: _SharedStringTableCache | None = None,
) -> _MacroSheetFacts:
    """Validate one Macro Sheet without evaluating or exposing its formulas."""
    part = sheet.part_name
    if (
        sheet.sheet_type != "macro_sheet"
        or part is None
        or not part.casefold().startswith("xl/macrosheets/")
        or not package.has(part)
    ):
        msg = "Macro Sheet package part is invalid"
        raise ValueError(msg)
    content_types = _content_types(package)
    if _part_content_type(part, content_types) != _MACRO_SHEET_CONTENT_TYPE:
        msg = "Macro Sheet package part content type is invalid"
        raise ValueError(msg)

    stream_facts = _stream_macro_sheet(
        package,
        part,
        feature_record_limit=feature_record_limit,
    )
    shared_strings = None
    if stream_facts.shared_string_references:
        shared_strings = (
            shared_string_loader()
            if shared_string_loader is not None
            else _shared_string_table(
                package,
                content_types=content_types,
                entry_limit=shared_string_entry_limit,
            )
        )
    shared_string_digest, non_formula_cell_digest = _content_digests(
        stream_facts,
        shared_strings,
    )
    defined_name_count, defined_name_digest = _defined_name_evidence(
        workbook,
        sheet.name,
        workbook_order=workbook_order,
    )
    relationships = _relationships(package, part)
    if any(
        relationship_id not in relationships
        for relationship_id in stream_facts.relationship_references
    ):
        msg = "Macro Sheet relationship reference does not exist"
        raise ValueError(msg)
    _validate_printer_settings(
        package,
        part,
        stream_facts.printer_relationship_ids,
    )
    edges, closure_members, external_count = _relationship_closure(package, part)
    inventory = MacroSheetFeatureInventory(
        name=sheet.name,
        workbook_order=workbook_order,
        visibility=sheet.visibility,
        part_present=True,
        dimension_reference=stream_facts.dimension_reference,
        row_count=stream_facts.row_count,
        cell_count=stream_facts.cell_count,
        formula_count=stream_facts.formula_count,
        value_count=stream_facts.value_count,
        part_sha256=stream_facts.part_sha256,
        formula_digest_sha256=stream_facts.formula_digest_sha256,
        shared_string_reference_count=len(stream_facts.shared_string_references),
        shared_string_digest_sha256=shared_string_digest,
        non_formula_cell_digest_sha256=non_formula_cell_digest,
        relationship_count=len(relationships),
        printer_settings_present=bool(stream_facts.printer_relationship_ids),
        external_relationship_count=external_count,
        defined_name_reference_count=defined_name_count,
        defined_name_digest_sha256=defined_name_digest,
    )
    return _MacroSheetFacts(
        inventory=inventory,
        relationship_edges=edges,
        closure_members=closure_members,
        formula_cache_present=stream_facts.formula_cache_present,
        shared_strings_part=None if shared_strings is None else shared_strings.part,
        shared_strings_part_sha256=(
            None if shared_strings is None else shared_strings.part_sha256
        ),
        shared_strings_relationship_type=(
            None if shared_strings is None else shared_strings.relationship_type
        ),
    )

"""Ownership and cleanup for one Excel patch staging transaction."""

from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Iterator


_STAGING_OWNER: ContextVar[set[Path] | None] = ContextVar(
    "excel_patch_staging_owner",
    default=None,
)


def create_staging_path(
    output_path: Path,
    suffix: str,
    *,
    purpose: str | None = None,
) -> Path:
    """Create and register one closed same-directory temporary path."""
    marker = f".{purpose}." if purpose is not None else "."
    with NamedTemporaryFile(
        dir=output_path.parent,
        prefix=f".{output_path.name}{marker}",
        suffix=suffix,
        delete=False,
    ) as temporary_file:
        path = Path(temporary_file.name)
    owner = _STAGING_OWNER.get()
    if owner is not None:
        owner.add(path)
    return path


@contextmanager
def owned_staging_paths() -> Iterator[None]:
    """Own and clean every intermediate created by one patch request."""
    paths: set[Path] = set()
    token = _STAGING_OWNER.set(paths)
    try:
        yield
    finally:
        for path in paths:
            path.unlink(missing_ok=True)
        _STAGING_OWNER.reset(token)

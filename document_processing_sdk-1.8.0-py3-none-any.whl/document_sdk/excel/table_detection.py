"""Deterministic table-region detection without semantic inference."""

from __future__ import annotations

from collections import defaultdict
from typing import TYPE_CHECKING

from document_sdk.core import DocumentProcessingError, ExcelSourceReference
from document_sdk.core._excel_coordinates import (
    excel_range_bounds,
    format_excel_range,
)
from document_sdk.excel._dependencies import require_excel_support
from document_sdk.excel._helpers import revalidate_excel_model, translate_excel_errors
from document_sdk.excel._ooxml import inspect_ooxml_worksheet
from document_sdk.excel.models import TableDetectionOptions, TableRegionCandidate
from document_sdk.excel.streaming import (
    DEFAULT_STREAM_BATCH_SIZE,
    _inspect_streaming_input,
    _iter_non_empty_cells,
)

if TYPE_CHECKING:
    from pathlib import Path

    from document_sdk.core import ExcelCell

MINIMUM_HEADER_TEXT_RATIO = 0.75


def _split_numbers(
    values: set[int], *, allowed_blanks: int
) -> tuple[tuple[int, ...], ...]:
    """Split ordered coordinates when their gap exceeds the configured bound."""
    groups: list[list[int]] = []
    for value in sorted(values):
        if not groups or value - groups[-1][-1] > allowed_blanks + 1:
            groups.append([value])
        else:
            groups[-1].append(value)
    return tuple(tuple(group) for group in groups)


def _cell_display_value(cell: ExcelCell) -> object:
    """Return formula text or ordinary value without calculating anything."""
    return cell.formula if cell.formula is not None else cell.value


def _header_rows(
    cells_by_row: dict[int, list[tuple[int, ExcelCell]]],
    *,
    minimum_row: int,
    maximum_row: int,
    maximum_scan_rows: int,
    minimum_columns: int,
) -> tuple[int, ...]:
    """Return leading rows with deterministic text-header evidence."""
    candidates: list[int] = []
    scan_end = min(maximum_row, minimum_row + maximum_scan_rows - 1)
    for row_number in range(minimum_row, scan_end + 1):
        row_cells = cells_by_row.get(row_number, [])
        if len(row_cells) < minimum_columns:
            continue
        text_cells = sum(
            isinstance(_cell_display_value(cell), str) for _column, cell in row_cells
        )
        if text_cells / len(row_cells) >= MINIMUM_HEADER_TEXT_RATIO:
            candidates.append(row_number)
        if candidates and row_number > candidates[-1] + 1:
            break
    return tuple(candidates)


def _overlaps(first: str, second: str) -> bool:
    """Return whether two normalized rectangular ranges overlap."""
    left = excel_range_bounds(first)
    right = excel_range_bounds(second)
    return not (
        left.max_row < right.min_row
        or right.max_row < left.min_row
        or left.max_column < right.min_column
        or right.max_column < left.min_column
    )


def _footer_row(
    cells_by_row: dict[int, list[tuple[int, ExcelCell]]],
    maximum_row: int,
) -> bool:
    """Detect a generic total/footer label in the final occupied row."""
    final_cells = cells_by_row.get(maximum_row, [])
    if not final_cells:
        return False
    value = _cell_display_value(min(final_cells, key=lambda item: item[0])[1])
    return isinstance(value, str) and value.strip().casefold().startswith(
        ("total", "subtotal", "grand total", "合計", "小計")
    )


def _selected_merged_ranges(
    path: Path,
    sheet_name: str,
    *,
    expected_fingerprint: str,
) -> tuple[str, ...]:
    """Inspect structural facts for only the caller-selected worksheet."""
    with translate_excel_errors(path, "detect tables in"):
        structure = inspect_ooxml_worksheet(
            path,
            sheet_name,
            expected_fingerprint=expected_fingerprint,
        )
    if structure is None:
        msg = f"Worksheet does not exist: {sheet_name}"
        raise DocumentProcessingError(msg)
    return structure.merged_ranges


def _candidate(
    cells: tuple[ExcelCell, ...],
    *,
    options: TableDetectionOptions,
    merged_ranges: tuple[str, ...],
    sheet_name: str,
    file_id: str,
) -> TableRegionCandidate | None:
    """Build one candidate from a connected row/column component."""
    positioned = tuple(
        (
            excel_range_bounds(cell.coordinate).min_row,
            excel_range_bounds(cell.coordinate).min_column,
            cell,
        )
        for cell in cells
    )
    rows = [row for row, _column, _cell in positioned]
    columns = [column for _row, column, _cell in positioned]
    minimum_row = min(rows)
    maximum_row = max(rows)
    minimum_column = min(columns)
    maximum_column = max(columns)
    cells_by_row: dict[int, list[tuple[int, ExcelCell]]] = defaultdict(list)
    for row, column, cell in positioned:
        cells_by_row[row].append((column, cell))
    original_range = format_excel_range(
        minimum_column,
        minimum_row,
        maximum_column,
        maximum_row,
    )
    merged_header_rows = {
        bounds.min_row
        for merged_range in merged_ranges
        if _overlaps(merged_range, original_range)
        and (bounds := excel_range_bounds(merged_range)).max_column
        - bounds.min_column
        + 1
        >= options.min_columns
        and bounds.min_row < minimum_row + options.header_scan_rows
    }
    header_rows = tuple(
        sorted(
            set(
                _header_rows(
                    cells_by_row,
                    minimum_row=minimum_row,
                    maximum_row=maximum_row,
                    maximum_scan_rows=options.header_scan_rows,
                    minimum_columns=options.min_columns,
                )
            )
            | merged_header_rows
        )
    )
    warnings: list[str] = []
    if header_rows and header_rows[0] > minimum_row:
        warnings.append("Sparse title rows precede the first header candidate.")
        minimum_row = header_rows[0]
        cells = tuple(
            cell
            for cell in cells
            if excel_range_bounds(cell.coordinate).min_row >= minimum_row
        )
        positioned = tuple(item for item in positioned if item[0] >= minimum_row)
        rows = [row for row, _column, _cell in positioned]
        columns = [column for _row, column, _cell in positioned]
        minimum_row = min(rows)
        maximum_row = max(rows)
        minimum_column = min(columns)
        maximum_column = max(columns)
        cells_by_row = defaultdict(list)
        for row, column, cell in positioned:
            cells_by_row[row].append((column, cell))
    row_count = maximum_row - minimum_row + 1
    column_count = maximum_column - minimum_column + 1
    if row_count < options.min_rows or column_count < options.min_columns:
        return None
    candidate_range = format_excel_range(
        minimum_column,
        minimum_row,
        maximum_column,
        maximum_row,
    )
    density = len(cells) / (row_count * column_count)
    if density < options.minimum_density:
        return None
    merged_headers = tuple(
        merged_range
        for merged_range in merged_ranges
        if _overlaps(merged_range, candidate_range)
        and excel_range_bounds(merged_range).min_row
        <= (header_rows[-1] if header_rows else minimum_row)
    )
    footer_present = _footer_row(cells_by_row, maximum_row)
    if footer_present:
        warnings.append("A deterministic total or footer row was detected.")
    if any(
        len(cells_by_row.get(row_number, ())) < column_count
        for row_number in range(minimum_row, maximum_row + 1)
    ):
        warnings.append("The candidate contains sparse internal cells.")
    header_score = 1.0 if header_rows else 0.0
    size_score = min(1.0, row_count / max(options.min_rows * 3, 1))
    merged_score = 1.0 if merged_headers else 0.0
    score = round(
        min(
            1.0,
            (density * 0.45)
            + (header_score * 0.3)
            + (size_score * 0.15)
            + (merged_score * 0.1),
        ),
        6,
    )
    data_start = header_rows[-1] + 1 if header_rows else minimum_row
    data_end = maximum_row - 1 if footer_present else maximum_row
    return TableRegionCandidate(
        cell_range=candidate_range,
        header_row_candidates=header_rows,
        data_start_row=data_start if data_start <= data_end else None,
        data_end_row=data_end if data_start <= data_end else None,
        non_empty_cell_count=len(cells),
        non_empty_density=density,
        merged_header_ranges=merged_headers,
        score=score,
        warnings=tuple(warnings),
        source=ExcelSourceReference(
            file_id=file_id,
            sheet_name=sheet_name,
            cell_range=candidate_range,
        ),
    )


def detect_table_regions(
    path: Path,
    sheet_name: str,
    *,
    cell_range: str | None = None,
    options: TableDetectionOptions | None = None,
) -> tuple[TableRegionCandidate, ...]:
    """Return deterministic table candidates and their structural evidence."""
    effective_options = (
        TableDetectionOptions()
        if options is None
        else revalidate_excel_model(
            options,
            TableDetectionOptions,
            "Table detection options are invalid",
        )
    )
    require_excel_support()
    bounds = None if cell_range is None else excel_range_bounds(cell_range)
    descriptor = _inspect_streaming_input(path)
    streamed = tuple(
        _iter_non_empty_cells(
            path,
            descriptor,
            sheet_name,
            bounds=bounds,
            max_cells=effective_options.max_cells,
            batch_size=DEFAULT_STREAM_BATCH_SIZE,
            formula_view="both",
        )
    )
    if not streamed:
        return ()
    merged_ranges = _selected_merged_ranges(
        path,
        sheet_name,
        expected_fingerprint=descriptor.fingerprint.value,
    )
    cells_by_row: dict[int, list[tuple[int, ExcelCell]]] = defaultdict(list)
    for cell in streamed:
        bounds = excel_range_bounds(cell.coordinate)
        cells_by_row[bounds.min_row].append((bounds.min_column, cell))
    row_groups = _split_numbers(
        set(cells_by_row),
        allowed_blanks=effective_options.max_blank_rows,
    )
    candidates: list[TableRegionCandidate] = []
    for row_group in row_groups:
        row_cells = tuple(
            (row, column, cell)
            for row in row_group
            for column, cell in cells_by_row[row]
        )
        column_groups = _split_numbers(
            {column for _row, column, _cell in row_cells},
            allowed_blanks=effective_options.max_blank_columns,
        )
        column_group_indexes = {
            column: index
            for index, column_group in enumerate(column_groups)
            for column in column_group
        }
        components: list[list[tuple[int, int, ExcelCell]]] = [
            [] for _column_group in column_groups
        ]
        for row, column, cell in row_cells:
            components[column_group_indexes[column]].append((row, column, cell))
        for component_items in components:
            component = tuple(cell for _row, _column, cell in sorted(component_items))
            candidate = _candidate(
                component,
                options=effective_options,
                merged_ranges=merged_ranges,
                sheet_name=sheet_name,
                file_id=streamed[0].source.file_id,
            )
            if candidate is not None:
                candidates.append(candidate)
    return tuple(
        sorted(
            candidates,
            key=lambda item: (
                excel_range_bounds(item.cell_range).min_row,
                excel_range_bounds(item.cell_range).min_column,
            ),
        )
    )

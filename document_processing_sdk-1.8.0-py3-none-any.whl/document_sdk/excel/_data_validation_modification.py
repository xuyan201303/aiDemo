"""Typed standard data-validation replacement and reopened verification."""

from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any
from xml.dom import Node, minidom

from document_sdk.excel._column_modification import _copy_package, _document_root
from document_sdk.excel._package import _SafePackage
from document_sdk.excel._package_security import _serialize_xml
from document_sdk.excel._package_workbook import _workbook_records
from document_sdk.excel._package_worksheet import (
    _SPREADSHEETML_WORKSHEET_NAMESPACES,
)
from document_sdk.excel._staging import create_staging_path
from document_sdk.excel._xml_namespaces import namespace_prefix
from document_sdk.excel.errors import ExcelModificationError
from document_sdk.files import calculate_sha256

if TYPE_CHECKING:
    from collections.abc import Sequence
    from pathlib import Path
    from xml.dom.minidom import Document, Element

    from openpyxl.workbook.workbook import Workbook
    from openpyxl.worksheet.datavalidation import DataValidation
    from openpyxl.worksheet.worksheet import Worksheet

    from document_sdk.excel.models import (
        DataValidationRulePatch,
        WorksheetDataValidationPatch,
    )


@dataclass(frozen=True, slots=True)
class _PendingDataValidationChange:
    """One requested validation replacement before public file identities exist."""

    sheet_name: str
    old_rule_count: int
    new_rule_count: int
    old_rule_set_fingerprint: str
    new_rule_set_fingerprint: str
    expected_openpyxl_rule_count: int
    expected_openpyxl_fingerprint: str
    expected_revision_uid_identities: tuple[tuple[str, str | None], ...]

    @property
    def changed(self) -> bool:
        """Return whether the replacement changes validation semantics."""
        return self.old_rule_set_fingerprint != self.new_rule_set_fingerprint


def _worksheet(workbook: Workbook, sheet_name: str) -> Worksheet:
    matches = [
        worksheet
        for worksheet in workbook.worksheets
        if worksheet.title.casefold() == sheet_name.casefold()
    ]
    if len(matches) != 1:
        msg = "Workbook data-validation worksheet does not exist"
        raise ExcelModificationError(msg)
    return matches[0]


def _validate_container(worksheet: Worksheet) -> None:
    container = worksheet.data_validations
    if any(
        value is not None
        for value in (
            container.disablePrompts,
            container.xWindow,
            container.yWindow,
        )
    ):
        msg = "Workbook data-validation container settings are unsupported"
        raise ExcelModificationError(msg)


def _rule_state(rule: DataValidation) -> dict[str, object]:
    return {
        "representation": "standard",
        "cell_ranges": tuple(sorted(str(rule.sqref).split())),
        "validation_type": rule.type,
        "operator": rule.operator,
        "formula1": rule.formula1,
        "formula2": rule.formula2,
        "allow_blank": bool(rule.allowBlank),
        "show_error_message": bool(rule.showErrorMessage),
        "show_input_message": bool(rule.showInputMessage),
        "show_drop_down": bool(rule.showDropDown),
        "error_style": rule.errorStyle,
        "error": rule.error,
        "error_title": rule.errorTitle,
        "prompt": rule.prompt,
        "prompt_title": rule.promptTitle,
    }


def _rule_set_state(worksheet: Worksheet) -> tuple[dict[str, object], ...]:
    _validate_container(worksheet)
    return tuple(
        _rule_state(rule) for rule in worksheet.data_validations.dataValidation
    )


def _fingerprint(state: tuple[dict[str, object], ...]) -> str:
    payload = json.dumps(
        state,
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


_REVISION_NAMESPACE = "http://schemas.microsoft.com/office/spreadsheetml/2014/revision"
_X14_NAMESPACE = "http://schemas.microsoft.com/office/spreadsheetml/2009/9/main"
_XM_NAMESPACE = "http://schemas.microsoft.com/office/excel/2006/main"
_X14_DATA_VALIDATION_EXTENSION_URI = "{CCE6A557-97BC-4b89-ADB6-D9C93CAAB3DF}"


def _combined_fingerprint(
    rule_set_fingerprint: str,
    revision_uid_identities: tuple[tuple[str, str | None], ...],
) -> str:
    payload = json.dumps(
        {
            "revision_uid_identities": revision_uid_identities,
            "rule_set_fingerprint": rule_set_fingerprint,
        },
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _direct_elements(parent: Element) -> tuple[Element, ...]:
    return tuple(
        child for child in parent.childNodes if child.nodeType == Node.ELEMENT_NODE
    )


def _validation_elements(root: Element, namespace: str) -> tuple[Element, ...]:
    containers = tuple(
        child
        for child in _direct_elements(root)
        if child.namespaceURI == namespace and child.localName == "dataValidations"
    )
    if len(containers) > 1:
        msg = "Workbook worksheet contains duplicate data-validation containers"
        raise ValueError(msg)
    if not containers:
        return ()
    return tuple(
        child
        for child in _direct_elements(containers[0])
        if child.namespaceURI == namespace and child.localName == "dataValidation"
    )


def _worksheet_document(payload: bytes) -> tuple[Document, Element, str]:
    document = minidom.parseString(  # noqa: S318 - bounded, DTD-screened OOXML.
        payload
    )
    root = _document_root(document)
    namespace = root.namespaceURI
    if namespace not in _SPREADSHEETML_WORKSHEET_NAMESPACES:
        msg = "Workbook worksheet namespace is unsupported"
        raise ValueError(msg)
    return document, root, namespace


def _revision_uids(payload: bytes) -> tuple[str | None, ...]:
    _document, root, namespace = _worksheet_document(payload)
    standard = tuple(
        element.getAttributeNS(_REVISION_NAMESPACE, "uid")
        if element.hasAttributeNS(_REVISION_NAMESPACE, "uid")
        else None
        for element in _validation_elements(root, namespace)
    )
    extended = tuple(
        element.getAttributeNS(_REVISION_NAMESPACE, "uid")
        if element.hasAttributeNS(_REVISION_NAMESPACE, "uid")
        else None
        for element in root.getElementsByTagNameNS(_X14_NAMESPACE, "dataValidation")
    )
    return (*standard, *extended)


def _element_text(element: Element | None) -> str | None:
    if element is None:
        return None
    return "".join(
        str(getattr(child, "data", ""))
        for child in element.childNodes
        if child.nodeType in {Node.TEXT_NODE, Node.CDATA_SECTION_NODE}
    )


def _extended_rule_states(payload: bytes) -> tuple[dict[str, object], ...]:
    _document, root, _namespace = _worksheet_document(payload)
    states: list[dict[str, object]] = []
    for element in root.getElementsByTagNameNS(_X14_NAMESPACE, "dataValidation"):
        formulas: dict[str, str | None] = {}
        for name in ("formula1", "formula2"):
            containers = element.getElementsByTagNameNS(_X14_NAMESPACE, name)
            values = (
                containers[0].getElementsByTagNameNS(_XM_NAMESPACE, "f")
                if containers
                else ()
            )
            formulas[name] = _element_text(values[0]) if values else None
        ranges = element.getElementsByTagNameNS(_XM_NAMESPACE, "sqref")
        states.append(
            {
                "representation": "x14",
                "cell_ranges": tuple(sorted((_element_text(ranges[0]) or "").split()))
                if ranges
                else (),
                "validation_type": element.getAttribute("type") or None,
                "operator": element.getAttribute("operator") or None,
                "formula1": formulas["formula1"],
                "formula2": formulas["formula2"],
                "allow_blank": element.getAttribute("allowBlank") in {"1", "true"},
                "show_error_message": element.getAttribute("showErrorMessage")
                in {"1", "true"},
                "show_input_message": element.getAttribute("showInputMessage")
                in {"1", "true"},
                "show_drop_down": element.getAttribute("showDropDown") in {"1", "true"},
                "error_style": element.getAttribute("errorStyle") or None,
                "error": element.getAttribute("error") or None,
                "error_title": element.getAttribute("errorTitle") or None,
                "prompt": element.getAttribute("prompt") or None,
                "prompt_title": element.getAttribute("promptTitle") or None,
            }
        )
    return tuple(states)


def _patch_rule_state(rule: DataValidationRulePatch) -> dict[str, object]:
    return {
        "representation": rule.representation,
        "cell_ranges": tuple(sorted(rule.cell_ranges)),
        "validation_type": rule.validation_type,
        "operator": rule.operator,
        "formula1": rule.formula1,
        "formula2": rule.formula2,
        "allow_blank": rule.allow_blank,
        "show_error_message": rule.show_error_message,
        "show_input_message": rule.show_input_message,
        "show_drop_down": rule.show_drop_down,
        "error_style": rule.error_style,
        "error": rule.error,
        "error_title": rule.error_title,
        "prompt": rule.prompt,
        "prompt_title": rule.prompt_title,
    }


def _patch_state(
    rules: Sequence[DataValidationRulePatch],
) -> tuple[dict[str, object], ...]:
    return tuple(_patch_rule_state(rule) for rule in rules)


def _logical_rule_identity(state: dict[str, object]) -> str:
    return json.dumps(
        {
            "representation": state["representation"],
            "cell_ranges": state["cell_ranges"],
            "validation_type": state["validation_type"],
        },
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    )


def _standard_rule_states(payload: bytes) -> tuple[dict[str, object], ...]:
    _document, root, namespace = _worksheet_document(payload)
    states: list[dict[str, object]] = []
    for element in _validation_elements(root, namespace):
        formulas = {}
        for name in ("formula1", "formula2"):
            matches = tuple(
                child
                for child in _direct_elements(element)
                if child.namespaceURI == namespace and child.localName == name
            )
            formulas[name] = _element_text(matches[0]) if matches else None
        states.append(
            {
                "representation": "standard",
                "cell_ranges": tuple(sorted(element.getAttribute("sqref").split())),
                "validation_type": element.getAttribute("type") or None,
                "operator": element.getAttribute("operator") or None,
                "formula1": formulas["formula1"],
                "formula2": formulas["formula2"],
                "allow_blank": element.getAttribute("allowBlank") in {"1", "true"},
                "show_error_message": element.getAttribute("showErrorMessage")
                in {"1", "true"},
                "show_input_message": element.getAttribute("showInputMessage")
                in {"1", "true"},
                "show_drop_down": element.getAttribute("showDropDown") in {"1", "true"},
                "error_style": element.getAttribute("errorStyle") or None,
                "error": element.getAttribute("error") or None,
                "error_title": element.getAttribute("errorTitle") or None,
                "prompt": element.getAttribute("prompt") or None,
                "prompt_title": element.getAttribute("promptTitle") or None,
            }
        )
    return tuple(states)


def _source_uid_identities(
    payload: bytes,
) -> tuple[dict[str, str | None], frozenset[str]]:
    states = (*_standard_rule_states(payload), *_extended_rule_states(payload))
    uids = _revision_uids(payload)
    identities: dict[str, str | None] = {}
    ambiguous: set[str] = set()
    for state, uid in zip(states, uids, strict=True):
        identity = _logical_rule_identity(state)
        if identity in identities:
            ambiguous.add(identity)
        else:
            identities[identity] = uid
    return identities, frozenset(ambiguous)


def _requested_revision_uids(
    patches: Sequence[DataValidationRulePatch],
    preserved: dict[str, str | None],
    ambiguous: frozenset[str],
) -> tuple[str | None, ...]:
    requested: list[str | None] = []
    for patch in patches:
        if patch.revision_uid is not None:
            requested.append(patch.revision_uid)
            continue
        if patch.clear_revision_uid:
            requested.append(None)
            continue
        identity = _logical_rule_identity(_patch_rule_state(patch))
        if identity in ambiguous:
            msg = "Workbook data-validation UID identity is ambiguous"
            raise ExcelModificationError(msg)
        requested.append(preserved.get(identity))
    return tuple(requested)


def _revision_uid_identity_state(
    states: Sequence[dict[str, object]],
    revision_uids: Sequence[str | None],
) -> tuple[tuple[str, str | None], ...]:
    return tuple(
        sorted(
            (
                (_logical_rule_identity(state), uid)
                for state, uid in zip(states, revision_uids, strict=True)
            ),
            key=lambda item: (item[0], item[1] or ""),
        )
    )


def _persisted_revision_uid_identity_state(
    payload: bytes,
) -> tuple[tuple[str, str | None], ...]:
    states = (*_standard_rule_states(payload), *_extended_rule_states(payload))
    return _revision_uid_identity_state(states, _revision_uids(payload))


def _worksheet_extension_list(
    document: Document,
    root: Element,
    namespace: str,
) -> Element:
    matches = tuple(
        child
        for child in _direct_elements(root)
        if child.namespaceURI == namespace and child.localName == "extLst"
    )
    if len(matches) > 1:
        msg = "Workbook worksheet contains duplicate extension lists"
        raise ValueError(msg)
    if matches:
        return matches[0]
    element = document.createElementNS(namespace, "extLst")
    root.appendChild(element)
    return element


def _restore_source_extensions(source_payload: bytes, output_payload: bytes) -> bytes:
    """Restore unrelated worksheet extensions before replacing known DV state."""
    source_document, source_root, source_namespace = _worksheet_document(source_payload)
    output_document, output_root, output_namespace = _worksheet_document(output_payload)
    source_lists = tuple(
        child
        for child in _direct_elements(source_root)
        if child.namespaceURI == source_namespace and child.localName == "extLst"
    )
    output_lists = tuple(
        child
        for child in _direct_elements(output_root)
        if child.namespaceURI == output_namespace and child.localName == "extLst"
    )
    if len(source_lists) > 1 or len(output_lists) > 1:
        msg = "Workbook worksheet contains duplicate extension lists"
        raise ValueError(msg)
    for element in output_lists:
        output_root.removeChild(element)
    if source_lists:
        output_root.appendChild(output_document.importNode(source_lists[0], deep=True))
    del source_document
    return _serialize_xml(output_document)


def _set_rule_attributes(element: Element, patch: DataValidationRulePatch) -> None:
    for name, value in (
        ("type", patch.validation_type),
        ("operator", patch.operator),
        ("errorStyle", patch.error_style),
        ("error", patch.error),
        ("errorTitle", patch.error_title),
        ("prompt", patch.prompt),
        ("promptTitle", patch.prompt_title),
    ):
        if value is not None:
            element.setAttribute(name, str(value))
    for name, enabled in (
        ("allowBlank", patch.allow_blank),
        ("showErrorMessage", patch.show_error_message),
        ("showInputMessage", patch.show_input_message),
        ("showDropDown", patch.show_drop_down),
    ):
        if enabled:
            element.setAttribute(name, "1")


def _extended_validation_container(  # noqa: C901
    document: Document,
    root: Element,
    namespace: str,
    patches: Sequence[DataValidationRulePatch],
    revision_uids: tuple[str | None, ...],
) -> None:
    extended = tuple(
        (patch, revision_uids[index])
        for index, patch in enumerate(patches)
        if patch.representation == "x14"
    )
    extension_list = _worksheet_extension_list(document, root, namespace)
    extensions = tuple(
        child
        for child in _direct_elements(extension_list)
        if child.namespaceURI == namespace
        and child.localName == "ext"
        and child.getAttribute("uri").casefold()
        == _X14_DATA_VALIDATION_EXTENSION_URI.casefold()
    )
    if len(extensions) > 1:
        msg = "Workbook worksheet contains duplicate data-validation extensions"
        raise ValueError(msg)
    extension = (
        extensions[0] if extensions else document.createElementNS(namespace, "ext")
    )
    if not extensions:
        extension.setAttribute("uri", _X14_DATA_VALIDATION_EXTENSION_URI)
        extension_list.appendChild(extension)
    containers = tuple(
        child
        for child in _direct_elements(extension)
        if child.namespaceURI == _X14_NAMESPACE and child.localName == "dataValidations"
    )
    if len(containers) > 1:
        msg = "Workbook worksheet contains duplicate extended validation containers"
        raise ValueError(msg)
    for container in containers:
        extension.removeChild(container)
    if not extended:
        if not tuple(_direct_elements(extension)):
            extension_list.removeChild(extension)
        if not tuple(_direct_elements(extension_list)):
            root.removeChild(extension_list)
        return
    x14_prefix = namespace_prefix(root, _X14_NAMESPACE, "x14")
    xm_prefix = namespace_prefix(root, _XM_NAMESPACE, "xm")
    revision_prefix = (
        namespace_prefix(root, _REVISION_NAMESPACE, "xr")
        if any(uid is not None for _patch, uid in extended)
        else None
    )
    container = document.createElementNS(
        _X14_NAMESPACE,
        f"{x14_prefix}:dataValidations",
    )
    container.setAttribute("count", str(len(extended)))
    for patch, uid in extended:
        element = document.createElementNS(
            _X14_NAMESPACE,
            f"{x14_prefix}:dataValidation",
        )
        _set_rule_attributes(element, patch)
        if uid is not None and revision_prefix is not None:
            element.setAttributeNS(
                _REVISION_NAMESPACE,
                f"{revision_prefix}:uid",
                uid,
            )
        for name, formula in (
            ("formula1", patch.formula1),
            ("formula2", patch.formula2),
        ):
            if formula is None:
                continue
            formula_element = document.createElementNS(
                _X14_NAMESPACE,
                f"{x14_prefix}:{name}",
            )
            value = document.createElementNS(_XM_NAMESPACE, f"{xm_prefix}:f")
            value.appendChild(document.createTextNode(formula))
            formula_element.appendChild(value)
            element.appendChild(formula_element)
        ranges = document.createElementNS(_XM_NAMESPACE, f"{xm_prefix}:sqref")
        ranges.appendChild(document.createTextNode(" ".join(patch.cell_ranges)))
        element.appendChild(ranges)
        container.appendChild(element)
    extension.appendChild(container)


def _apply_revision_uids(
    payload: bytes,
    source_payload: bytes | None,
    patches: Sequence[DataValidationRulePatch],
    preserved: dict[str, str | None],
    ambiguous: frozenset[str],
) -> tuple[bytes, tuple[str | None, ...], tuple[tuple[str, str | None], ...]]:
    if source_payload is not None:
        payload = _restore_source_extensions(source_payload, payload)
    document, root, namespace = _worksheet_document(payload)
    elements = _validation_elements(root, namespace)
    standard_patches = tuple(
        patch for patch in patches if patch.representation == "standard"
    )
    if len(elements) != len(standard_patches):
        msg = "Patched workbook data-validation UID target count changed"
        raise ExcelModificationError(msg)
    requested = _requested_revision_uids(patches, preserved, ambiguous)
    prefix = (
        namespace_prefix(root, _REVISION_NAMESPACE, "xr") if any(requested) else None
    )
    changed = False
    standard_uids = tuple(
        requested[index]
        for index, patch in enumerate(patches)
        if patch.representation == "standard"
    )
    for element, value in zip(elements, standard_uids, strict=True):
        existing = (
            element.getAttributeNS(_REVISION_NAMESPACE, "uid")
            if element.hasAttributeNS(_REVISION_NAMESPACE, "uid")
            else None
        )
        if value is None:
            if existing is not None:
                element.removeAttributeNS(_REVISION_NAMESPACE, "uid")
                changed = True
        elif existing != value:
            element.setAttributeNS(_REVISION_NAMESPACE, f"{prefix}:uid", value)
            changed = True
    _extended_validation_container(document, root, namespace, patches, requested)
    changed = True
    identity_state = _revision_uid_identity_state(
        tuple(_patch_rule_state(patch) for patch in patches),
        requested,
    )
    return (_serialize_xml(document) if changed else payload), requested, identity_state


def apply_persisted_data_validation_revision_uids(
    source_path: Path,
    output_path: Path,
    patches: Sequence[WorksheetDataValidationPatch],
    evidence: Sequence[_PendingDataValidationChange],
    *,
    source_fingerprint: str,
) -> tuple[_PendingDataValidationChange, ...]:
    """Apply known revision UIDs to targeted persisted worksheet rules."""
    if not patches:
        return tuple(evidence)
    replacements: dict[str, bytes] = {}
    updated: list[_PendingDataValidationChange] = []
    evidence_by_sheet = {item.sheet_name.casefold(): item for item in evidence}
    with (
        _SafePackage(source_path) as source_package,
        _SafePackage(output_path) as output_package,
    ):
        source_package.verify_fingerprint(source_fingerprint)
        _source_workbook, source_records = _workbook_records(source_package)
        _output_workbook, output_records = _workbook_records(output_package)
        source_by_name = {record.name.casefold(): record for record in source_records}
        output_by_name = {record.name.casefold(): record for record in output_records}
        for patch in patches:
            name_key = patch.sheet_name.casefold()
            pending = evidence_by_sheet[name_key]
            source_record = source_by_name.get(name_key)
            output_record = output_by_name.get(name_key)
            if output_record is None or output_record.part_name is None:
                msg = "Workbook data-validation worksheet does not exist"
                raise ExcelModificationError(msg)
            source_uid_identities: dict[str, str | None] = {}
            ambiguous_identities: frozenset[str] = frozenset()
            source_payload: bytes | None = None
            if source_record is not None and source_record.part_name is not None:
                with source_package.open_xml_stream(source_record.part_name) as stream:
                    source_payload = stream.read()
                source_uid_identities, ambiguous_identities = _source_uid_identities(
                    source_payload
                )
            with output_package.open_xml_stream(output_record.part_name) as stream:
                output_payload = stream.read()
            replacement, _requested_uids, requested_uid_identities = (
                _apply_revision_uids(
                    output_payload,
                    source_payload,
                    patch.rules,
                    source_uid_identities,
                    ambiguous_identities,
                )
            )
            if replacement != output_payload:
                replacements[output_record.part_name] = replacement
            updated.append(
                _PendingDataValidationChange(
                    sheet_name=pending.sheet_name,
                    old_rule_count=pending.old_rule_count,
                    new_rule_count=pending.new_rule_count,
                    old_rule_set_fingerprint=_combined_fingerprint(
                        pending.old_rule_set_fingerprint,
                        _persisted_revision_uid_identity_state(source_payload)
                        if source_payload is not None
                        else (),
                    ),
                    new_rule_set_fingerprint=_combined_fingerprint(
                        pending.new_rule_set_fingerprint,
                        requested_uid_identities,
                    ),
                    expected_openpyxl_fingerprint=(
                        pending.expected_openpyxl_fingerprint
                    ),
                    expected_openpyxl_rule_count=(pending.expected_openpyxl_rule_count),
                    expected_revision_uid_identities=requested_uid_identities,
                )
            )
    if replacements:
        replacement_path = create_staging_path(
            output_path,
            output_path.suffix,
            purpose="data-validation-uids",
        )
        try:
            _copy_package(
                output_path,
                replacement_path,
                replacements,
                source_fingerprint=calculate_sha256(output_path).value,
            )
            os.replace(replacement_path, output_path)  # noqa: PTH105 - atomic API.
        finally:
            replacement_path.unlink(missing_ok=True)
    return tuple(updated)


def verify_persisted_data_validation_revision_uids(
    output_path: Path,
    patches: Sequence[WorksheetDataValidationPatch],
    evidence: Sequence[_PendingDataValidationChange],
) -> None:
    """Verify requested revision UID state directly from persisted OOXML."""
    evidence_by_sheet = {item.sheet_name.casefold(): item for item in evidence}
    with _SafePackage(output_path) as package:
        _workbook, records = _workbook_records(package)
        by_name = {record.name.casefold(): record for record in records}
        for patch in patches:
            record = by_name.get(patch.sheet_name.casefold())
            if record is None or record.part_name is None:
                msg = "Workbook data-validation worksheet does not exist"
                raise ExcelModificationError(msg)
            with package.open_xml_stream(record.part_name) as stream:
                payload = stream.read()
            actual = _persisted_revision_uid_identity_state(payload)
            expected = evidence_by_sheet[patch.sheet_name.casefold()]
            if actual != expected.expected_revision_uid_identities:
                msg = "Patched workbook data-validation UID verification failed"
                raise ExcelModificationError(msg)
            expected_extended = tuple(
                _patch_rule_state(rule)
                for rule in patch.rules
                if rule.representation == "x14"
            )
            if _extended_rule_states(payload) != expected_extended:
                msg = "Patched workbook extended data-validation verification failed"
                raise ExcelModificationError(msg)


def _rule(value: DataValidationRulePatch) -> DataValidation:
    from openpyxl.worksheet.datavalidation import DataValidation

    arguments: dict[str, Any] = {
        "type": value.validation_type,
        "formula1": value.formula1,
        "formula2": value.formula2,
        "showErrorMessage": value.show_error_message,
        "showInputMessage": value.show_input_message,
        "showDropDown": value.show_drop_down,
        "allowBlank": value.allow_blank,
        "errorStyle": value.error_style,
        "error": value.error,
        "errorTitle": value.error_title,
        "prompt": value.prompt,
        "promptTitle": value.prompt_title,
        "operator": value.operator,
    }
    rule = DataValidation(**arguments)
    for cell_range in value.cell_ranges:
        rule.add(cell_range)
    return rule


def _replace_rule_set(
    worksheet: Worksheet,
    patch: WorksheetDataValidationPatch,
) -> None:
    from openpyxl.worksheet.datavalidation import DataValidationList

    worksheet.data_validations = DataValidationList(
        dataValidation=tuple(
            _rule(rule) for rule in patch.rules if rule.representation == "standard"
        )
    )


def apply_data_validation_patches(
    workbook: Workbook,
    patches: Sequence[WorksheetDataValidationPatch],
) -> tuple[_PendingDataValidationChange, ...]:
    """Replace requested standard validation sets and retain verification evidence."""
    evidence: list[_PendingDataValidationChange] = []
    for patch in patches:
        worksheet = _worksheet(workbook, patch.sheet_name)
        old_state = _rule_set_state(worksheet)
        _replace_rule_set(worksheet, patch)
        new_state = _rule_set_state(worksheet)
        requested_state = _patch_state(patch.rules)
        evidence.append(
            _PendingDataValidationChange(
                sheet_name=worksheet.title,
                old_rule_count=len(old_state),
                new_rule_count=len(patch.rules),
                old_rule_set_fingerprint=_fingerprint(old_state),
                new_rule_set_fingerprint=_fingerprint(requested_state),
                expected_openpyxl_rule_count=len(new_state),
                expected_openpyxl_fingerprint=_fingerprint(new_state),
                expected_revision_uid_identities=(),
            )
        )
    return tuple(evidence)


def verify_data_validation_patches(
    workbook: Workbook,
    evidence: Sequence[_PendingDataValidationChange],
) -> None:
    """Verify each requested validation set from the reopened workbook."""
    for expected in evidence:
        worksheet = _worksheet(workbook, expected.sheet_name)
        state = _rule_set_state(worksheet)
        if (
            len(state) != expected.expected_openpyxl_rule_count
            or _fingerprint(state) != expected.expected_openpyxl_fingerprint
        ):
            msg = "Patched workbook data-validation verification failed"
            raise ExcelModificationError(msg)

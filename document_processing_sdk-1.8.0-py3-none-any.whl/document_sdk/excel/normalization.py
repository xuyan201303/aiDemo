"""Generic, explicit Excel scalar normalization."""

from __future__ import annotations

import unicodedata
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from typing import Literal

from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.excel._helpers import revalidate_excel_model
from document_sdk.excel.models import (
    ExcelPatchScalar,
    NormalizationOptions,
    NormalizedValueResult,
)

type NormalizationTarget = Literal[
    "auto",
    "string",
    "integer",
    "decimal",
    "percentage",
    "date",
    "datetime",
    "boolean",
]
_NORMALIZATION_TARGETS = frozenset(
    {
        "auto",
        "string",
        "integer",
        "decimal",
        "percentage",
        "date",
        "datetime",
        "boolean",
    }
)


def _transform_text(
    value: str,
    options: NormalizationOptions,
    *,
    apply_case: bool = True,
) -> str:
    """Apply caller-selected text transforms without blank conversion."""
    normalized = value.strip() if options.trim_whitespace else value
    if options.unicode_form != "none":
        normalized = unicodedata.normalize(options.unicode_form, normalized)
    if options.normalize_width:
        normalized = unicodedata.normalize("NFKC", normalized)
    if apply_case and options.case == "lower":
        normalized = normalized.lower()
    elif apply_case and options.case == "upper":
        normalized = normalized.upper()
    elif apply_case and options.case == "casefold":
        normalized = normalized.casefold()
    return normalized


def _normalized_text(value: str, options: NormalizationOptions) -> str | None:
    """Apply only caller-selected text normalization."""
    normalized = _transform_text(value, options)
    blank_values = {_transform_text(item, options) for item in options.blank_values}
    return None if normalized in blank_values else normalized


def _numeric_text(value: str, options: NormalizationOptions) -> str:
    """Remove explicitly configured numeric separators."""
    normalized = _transform_text(value, options, apply_case=False)
    if options.thousands_separator:
        normalized = normalized.replace(options.thousands_separator, "")
    if options.decimal_separator != ".":
        normalized = normalized.replace(options.decimal_separator, ".")
    return normalized


def _decimal_value(
    value: ExcelPatchScalar,
    options: NormalizationOptions,
) -> Decimal:
    """Convert a supported scalar to Decimal without binary float artifacts."""
    if isinstance(value, bool) or value is None:
        msg = "value cannot be parsed as a decimal"
        raise ValueError(msg)
    if isinstance(value, Decimal):
        parsed = value
    elif isinstance(value, int):
        parsed = Decimal(value)
    elif isinstance(value, float):
        parsed = Decimal(str(value))
    elif isinstance(value, str):
        try:
            parsed = Decimal(_numeric_text(value, options))
        except InvalidOperation as exc:
            msg = "value cannot be parsed as a decimal"
            _raise_redacted_translation(exc, ValueError(msg))
    else:
        msg = "value cannot be parsed as a decimal"
        raise ValueError(msg)  # noqa: TRY004 - normalization is value-oriented.
    if not parsed.is_finite():
        msg = "value cannot be parsed as a finite decimal"
        raise ValueError(msg)
    return parsed


def _normalize_non_null(  # noqa: C901, PLR0911, PLR0912
    value: ExcelPatchScalar,
    *,
    options: NormalizationOptions,
    target_type: NormalizationTarget,
) -> ExcelPatchScalar:
    """Normalize one non-null value for a selected generic target."""
    if target_type == "auto":
        return _normalized_text(value, options) if isinstance(value, str) else value
    if target_type == "string":
        text = value if isinstance(value, str) else str(value)
        return _normalized_text(text, options)
    if target_type == "integer":
        decimal_value = _decimal_value(value, options)
        if decimal_value != decimal_value.to_integral_value():
            msg = "value cannot be parsed as an integer"
            raise ValueError(msg)
        return int(decimal_value)
    if target_type == "decimal":
        return _decimal_value(value, options)
    if target_type == "percentage":
        if isinstance(value, str):
            text = _transform_text(value, options, apply_case=False)
            has_percent_sign = text.endswith("%")
            if has_percent_sign:
                text = text[:-1].strip()
            parsed = _decimal_value(text, options)
            return parsed / 100 if has_percent_sign else parsed
        return _decimal_value(value, options)
    if target_type == "boolean":
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            normalized = _transform_text(
                value,
                options,
                apply_case=False,
            ).casefold()
            if normalized in {
                _transform_text(item, options, apply_case=False).casefold()
                for item in options.true_values
            }:
                return True
            if normalized in {
                _transform_text(item, options, apply_case=False).casefold()
                for item in options.false_values
            }:
                return False
        msg = "value cannot be parsed as a boolean"
        raise ValueError(msg)
    if target_type == "date":
        if isinstance(value, datetime):
            return value.date()
        if isinstance(value, date):
            return value
        if isinstance(value, str):
            try:
                return date.fromisoformat(
                    _transform_text(value, options, apply_case=False)
                )
            except ValueError as exc:
                msg = "value cannot be parsed as a date"
                _raise_redacted_translation(exc, ValueError(msg))
        msg = "value cannot be parsed as a date"
        raise ValueError(msg)
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(
                _transform_text(value, options, apply_case=False)
            )
        except ValueError as exc:
            msg = "value cannot be parsed as a datetime"
            _raise_redacted_translation(exc, ValueError(msg))
    msg = "value cannot be parsed as a datetime"
    raise ValueError(msg)


def normalize_value(
    value: ExcelPatchScalar,
    *,
    options: NormalizationOptions | None = None,
    target_type: NormalizationTarget = "auto",
) -> NormalizedValueResult:
    """Normalize one supported scalar without changing a workbook."""
    effective_options = (
        NormalizationOptions()
        if options is None
        else revalidate_excel_model(
            options,
            NormalizationOptions,
            "Excel normalization options are invalid",
        )
    )
    if target_type not in _NORMALIZATION_TARGETS:
        msg = "target_type is not a supported normalization target"
        raise ValueError(msg)
    normalized: ExcelPatchScalar
    if value is None or (
        isinstance(value, str)
        and _normalized_text(
            value,
            effective_options,
        )
        is None
    ):
        normalized = None
    else:
        normalized = _normalize_non_null(
            value,
            options=effective_options,
            target_type=target_type,
        )
    return NormalizedValueResult(
        original_value=value,
        normalized_value=normalized,
        target_type=target_type,
    )

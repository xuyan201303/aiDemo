"""Bounded package-level worksheet column-dimension modification."""

from __future__ import annotations

import math
from copy import copy
from dataclasses import dataclass
from hashlib import sha256
from shutil import copyfileobj
from typing import TYPE_CHECKING, Any, Literal, cast
from xml.dom import Node, minidom
from zipfile import ZIP_DEFLATED, ZipFile

from document_sdk.core._excel_coordinates import (
    MAX_EXCEL_COLUMN,
    excel_column_letter,
    excel_range_bounds,
)
from document_sdk.excel._package import _SafePackage
from document_sdk.excel._package_security import _serialize_xml
from document_sdk.excel._package_workbook import _workbook_records
from document_sdk.excel._package_worksheet import (
    _SPREADSHEETML_WORKSHEET_NAMESPACES,
)
from document_sdk.excel._package_zip import write_new_member
from document_sdk.excel.errors import ExcelModificationError, ExcelPackageLimitError

if TYPE_CHECKING:
    from collections.abc import Iterable, Sequence
    from pathlib import Path
    from xml.dom.minidom import Attr, Document, Element
    from xml.etree.ElementTree import Element as EtElement

    from document_sdk.excel.models import (
        CellAlignmentPatch,
        CellBorderPatch,
        CellFontPatch,
        CellPatternFillPatch,
        ColumnDimensionPatch,
    )


_COLUMN_ATTRIBUTES = frozenset({"min", "max"})
_TRUE_VALUES = frozenset({"1", "true", "on"})
_MAX_COLUMN_STATE_ASSIGNMENTS = 100_000
type _ColumnStyleComponent = Literal[
    "font",
    "fill",
    "border",
    "alignment",
    "number_format",
    "named_style",
    "quote_prefix",
    "pivot_button",
]


@dataclass(frozen=True, slots=True)
class _PendingColumnChange:
    """One normalized whole-column change before public identities are known."""

    sheet_name: str
    start_column: int
    end_column: int
    old_width: float | None
    new_width: float | None
    old_hidden: bool
    new_hidden: bool
    old_best_fit: bool
    new_best_fit: bool
    old_style_fingerprint: str | None = None
    new_style_fingerprint: str | None = None
    style_changed_components: tuple[_ColumnStyleComponent, ...] = ()


@dataclass(frozen=True, slots=True)
class _ColumnTarget:
    """One worksheet package member and its normalized desired settings."""

    sheet_name: str
    member: str
    settings: dict[int, dict[str, object]]


def _direct_elements(parent: Element) -> Iterable[Element]:
    for child in parent.childNodes:
        if child.nodeType == Node.ELEMENT_NODE:
            yield child


def _document_root(document: Document) -> Element:
    root = document.documentElement
    if root is None:
        msg = "Workbook worksheet XML has no document element"
        raise ValueError(msg)
    return root


def _spreadsheet_element(element: Element, local_name: str, namespace: str) -> bool:
    return element.namespaceURI == namespace and element.localName == local_name


def _column_number(value: str) -> int:
    return excel_range_bounds(f"{value}1").min_column


def _column_settings(
    patches: Sequence[ColumnDimensionPatch],
) -> dict[str, dict[int, dict[str, object]]]:
    settings: dict[str, dict[int, dict[str, object]]] = {}
    assignments = 0
    for patch in patches:
        sheet_settings = settings.setdefault(patch.sheet_name, {})
        minimum = _column_number(patch.start_column)
        maximum = _column_number(patch.end_column or patch.start_column)
        assignments += maximum - minimum + 1
        if assignments > _MAX_COLUMN_STATE_ASSIGNMENTS:
            raise ExcelPackageLimitError(
                limit_name="column_patch_targets",
                observed=assignments,
                maximum=_MAX_COLUMN_STATE_ASSIGNMENTS,
            )
        for column in range(minimum, maximum + 1):
            target = sheet_settings.setdefault(column, {})
            if patch.width is not None:
                target["width"] = patch.width
            if patch.clear_width:
                target["clear_width"] = True
            if patch.hidden is not None:
                target["hidden"] = patch.hidden
            if patch.best_fit is not None:
                target["best_fit"] = patch.best_fit
            for field in (
                "font",
                "fill",
                "border",
                "alignment",
                "number_format",
                "named_style",
                "quote_prefix",
                "pivot_button",
            ):
                value = getattr(patch, field)
                if value is not None:
                    target[field] = value
    return settings


def _resolve_targets(
    source_path: Path,
    patches: Sequence[ColumnDimensionPatch],
    *,
    source_fingerprint: str | None,
) -> tuple[_ColumnTarget, ...]:
    requested = _column_settings(patches)
    with _SafePackage(source_path) as package:
        if source_fingerprint is not None:
            package.verify_fingerprint(source_fingerprint)
        _workbook, records = _workbook_records(package)
        by_name = {record.name: record for record in records}
        targets: list[_ColumnTarget] = []
        for sheet_name, settings in requested.items():
            record = by_name.get(sheet_name)
            if (
                record is None
                or record.sheet_type != "worksheet"
                or record.part_name is None
                or not package.has(record.part_name)
            ):
                msg = "Workbook column patch worksheet does not exist"
                raise ExcelModificationError(msg)
            targets.append(
                _ColumnTarget(
                    sheet_name=sheet_name,
                    member=record.part_name,
                    settings=settings,
                )
            )
    return tuple(targets)


def _column_attributes(element: Element) -> dict[str, str]:
    attributes: dict[str, str] = {}
    for index in range(element.attributes.length):
        attribute = cast("Attr | None", element.attributes.item(index))
        if attribute is not None and attribute.name not in _COLUMN_ATTRIBUTES:
            attributes[attribute.name] = attribute.value
    return attributes


def _column_range(element: Element) -> tuple[int, int]:
    try:
        minimum = int(element.getAttribute("min"))
        maximum = int(element.getAttribute("max"))
    except ValueError:
        msg = "Workbook column metadata is outside Excel bounds"
        raise ValueError(msg) from None
    if minimum < 1 or maximum < minimum or maximum > MAX_EXCEL_COLUMN:
        msg = "Workbook column metadata is outside Excel bounds"
        raise ValueError(msg)
    return minimum, maximum


def _existing_states(
    columns: Element | None,
    namespace: str,
) -> list[dict[str, str] | None]:
    states: list[dict[str, str] | None] = [None] * (MAX_EXCEL_COLUMN + 1)
    if columns is None:
        return states
    assignments = 0
    for element in _direct_elements(columns):
        if not _spreadsheet_element(element, "col", namespace):
            continue
        if any(child.nodeType == Node.ELEMENT_NODE for child in element.childNodes):
            msg = "Workbook column metadata contains unsupported child content"
            raise ValueError(msg)
        minimum, maximum = _column_range(element)
        assignments += maximum - minimum + 1
        if assignments > _MAX_COLUMN_STATE_ASSIGNMENTS:
            raise ExcelPackageLimitError(
                limit_name="column_metadata_targets",
                observed=assignments,
                maximum=_MAX_COLUMN_STATE_ASSIGNMENTS,
            )
        attributes = _column_attributes(element)
        for column in range(minimum, maximum + 1):
            states[column] = dict(attributes)
    return states


def _state_width(state: dict[str, str] | None) -> float | None:
    if state is None or "width" not in state:
        return None
    width = float(state["width"])
    if not math.isfinite(width):
        msg = "Workbook column width is not finite"
        raise ValueError(msg)
    return width if width > 0 else None


def _state_hidden(state: dict[str, str] | None) -> bool:
    return state is not None and state.get("hidden") in _TRUE_VALUES


def _state_best_fit(state: dict[str, str] | None) -> bool:
    return state is not None and state.get("bestFit") in _TRUE_VALUES


def _width_text(value: float) -> str:
    return format(value, ".15g")


def _apply_settings(  # noqa: C901, PLR0912
    states: list[dict[str, str] | None],
    settings: dict[int, dict[str, object]],
    *,
    sheet_name: str,
) -> tuple[_PendingColumnChange, ...]:
    atomic: list[_PendingColumnChange] = []
    for column in sorted(settings):
        before = states[column]
        old_width = _state_width(before)
        old_hidden = _state_hidden(before)
        old_best_fit = _state_best_fit(before)
        requested = settings[column]
        width = requested.get("width")
        clear_width = requested.get("clear_width") is True
        hidden = requested.get("hidden")
        best_fit = requested.get("best_fit")
        style_id = requested.get("style_id")
        old_style_fingerprint = requested.get("_old_style_fingerprint")
        new_style_fingerprint = requested.get("_new_style_fingerprint")
        style_components = requested.get("_style_changed_components")
        width_changed = (isinstance(width, float) and old_width != width) or (
            clear_width and old_width is not None
        )
        hidden_changed = isinstance(hidden, bool) and old_hidden != hidden
        best_fit_changed = isinstance(best_fit, bool) and old_best_fit != best_fit
        style_changed = (
            isinstance(style_id, int)
            and isinstance(old_style_fingerprint, str)
            and isinstance(new_style_fingerprint, str)
            and old_style_fingerprint != new_style_fingerprint
        )
        if (
            not width_changed
            and not hidden_changed
            and not best_fit_changed
            and not style_changed
        ):
            continue

        state = {} if before is None else dict(before)
        if width_changed and isinstance(width, float):
            state["width"] = _width_text(width)
            state["customWidth"] = "1"
        elif width_changed and clear_width:
            state.pop("width", None)
            state.pop("customWidth", None)
        if hidden_changed and hidden is True:
            state["hidden"] = "1"
        elif hidden_changed and hidden is False:
            state.pop("hidden", None)
        if best_fit_changed and best_fit is True:
            state["bestFit"] = "1"
        elif best_fit_changed and best_fit is False:
            state.pop("bestFit", None)
        if style_changed and style_id == 0:
            state.pop("style", None)
        elif style_changed and isinstance(style_id, int):
            state["style"] = str(style_id)
        if not state:
            states[column] = None
        else:
            states[column] = state
        atomic.append(
            _PendingColumnChange(
                sheet_name=sheet_name,
                start_column=column,
                end_column=column,
                old_width=old_width,
                new_width=_state_width(states[column]),
                old_hidden=old_hidden,
                new_hidden=_state_hidden(states[column]),
                old_best_fit=old_best_fit,
                new_best_fit=_state_best_fit(states[column]),
                old_style_fingerprint=(
                    cast("str", old_style_fingerprint) if style_changed else None
                ),
                new_style_fingerprint=(
                    cast("str", new_style_fingerprint) if style_changed else None
                ),
                style_changed_components=(
                    cast("tuple[_ColumnStyleComponent, ...]", style_components)
                    if style_changed and isinstance(style_components, tuple)
                    else ()
                ),
            )
        )

    grouped: list[_PendingColumnChange] = []
    for change in atomic:
        if (
            grouped
            and grouped[-1].sheet_name == change.sheet_name
            and grouped[-1].end_column + 1 == change.start_column
            and grouped[-1].old_width == change.old_width
            and grouped[-1].new_width == change.new_width
            and grouped[-1].old_hidden == change.old_hidden
            and grouped[-1].new_hidden == change.new_hidden
            and grouped[-1].old_best_fit == change.old_best_fit
            and grouped[-1].new_best_fit == change.new_best_fit
            and grouped[-1].old_style_fingerprint == change.old_style_fingerprint
            and grouped[-1].new_style_fingerprint == change.new_style_fingerprint
            and grouped[-1].style_changed_components == change.style_changed_components
        ):
            previous = grouped[-1]
            grouped[-1] = _PendingColumnChange(
                sheet_name=previous.sheet_name,
                start_column=previous.start_column,
                end_column=change.end_column,
                old_width=previous.old_width,
                new_width=previous.new_width,
                old_hidden=previous.old_hidden,
                new_hidden=previous.new_hidden,
                old_best_fit=previous.old_best_fit,
                new_best_fit=previous.new_best_fit,
                old_style_fingerprint=previous.old_style_fingerprint,
                new_style_fingerprint=previous.new_style_fingerprint,
                style_changed_components=previous.style_changed_components,
            )
        else:
            grouped.append(change)
    return tuple(grouped)


def _new_element(document: Document, namespace: str, local_name: str) -> Element:
    root = _document_root(document)
    qualified_name = f"{root.prefix}:{local_name}" if root.prefix else local_name
    return document.createElementNS(namespace, qualified_name)


_COLUMN_STYLE_FIELDS = (
    "font",
    "fill",
    "border",
    "alignment",
    "number_format",
    "named_style",
    "quote_prefix",
    "pivot_button",
)
_XF_ID_ATTRIBUTES = frozenset({"fontId", "fillId", "borderId", "numFmtId", "xfId"})
_XF_STORAGE_ATTRIBUTES = frozenset(
    {"applyFont", "applyFill", "applyBorder", "applyNumberFormat", "applyAlignment"}
)


def _canonical_element(element: Element) -> tuple[object, ...]:
    attributes = tuple(
        sorted(
            (attribute.name, attribute.value)
            for index in range(element.attributes.length)
            if (attribute := cast("Attr | None", element.attributes.item(index)))
            is not None
            and not attribute.name.startswith("xmlns")
        )
    )
    return (
        element.localName or element.tagName,
        attributes,
        (
            element.firstChild.data.strip()
            if element.firstChild is not None
            and element.firstChild.nodeType == Node.TEXT_NODE
            else ""
        ),
        tuple(_canonical_element(child) for child in _direct_elements(element)),
    )


def _style_records(
    container: Element,
    namespace: str,
    local_name: str,
) -> tuple[Element, ...]:
    return tuple(
        child
        for child in _direct_elements(container)
        if _spreadsheet_element(child, local_name, namespace)
    )


def _style_container(
    document: Document,
    namespace: str,
    local_name: str,
    *,
    create: bool = False,
) -> Element | None:
    root = _document_root(document)
    matches = tuple(
        child
        for child in _direct_elements(root)
        if _spreadsheet_element(child, local_name, namespace)
    )
    if len(matches) > 1:
        msg = "Workbook styles contain duplicate containers"
        raise ValueError(msg)
    if matches:
        return matches[0]
    if not create:
        return None
    container = _new_element(document, namespace, local_name)
    successors = (
        "numFmts",
        "fonts",
        "fills",
        "borders",
        "cellStyleXfs",
        "cellXfs",
        "cellStyles",
        "dxfs",
        "tableStyles",
        "colors",
        "extLst",
    )
    reference = next(
        (
            child
            for child in _direct_elements(root)
            if child.namespaceURI == namespace
            and child.localName in successors[successors.index(local_name) + 1 :]
        ),
        None,
    )
    root.insertBefore(container, reference)
    return container


def _set_count(container: Element, records: Sequence[Element]) -> None:
    container.setAttribute("count", str(len(records)))


def _backend_element(
    document: Document,
    namespace: str,
    value: object,
    component: str,
) -> Element:
    from document_sdk.excel._cell_format_modification import (
        _alignment,
        _border,
        _fill,
        _font,
    )

    backend: Any
    if component == "font":
        backend = _font(cast("CellFontPatch", value))
    elif component == "fill":
        backend = _fill(cast("CellPatternFillPatch", value))
    elif component == "border":
        backend = _border(cast("CellBorderPatch", value))
    else:
        backend = _alignment(cast("CellAlignmentPatch", value))

    def convert(node: EtElement) -> Element:
        tag = str(node.tag)
        local_name = tag.rsplit("}", 1)[-1]
        element = _new_element(document, namespace, local_name)
        for name, item in node.attrib.items():
            element.setAttribute(str(name).rsplit("}", 1)[-1], str(item))
        text = node.text
        if text:
            element.appendChild(document.createTextNode(str(text)))
        for child in node:
            element.appendChild(convert(child))
        return element

    return convert(backend.to_tree())


@dataclass(slots=True)
class _ColumnStyleTable:
    """Mutable package-level style registry used only for column formats."""

    document: Document
    namespace: str
    changed: bool = False

    @classmethod
    def parse(cls, payload: bytes) -> _ColumnStyleTable:
        document = minidom.parseString(  # noqa: S318 - bounded OOXML payload.
            payload
        )
        namespace = _document_root(document).namespaceURI
        if namespace not in _SPREADSHEETML_WORKSHEET_NAMESPACES:
            msg = "Workbook styles namespace is unsupported"
            raise ValueError(msg)
        for name in ("fonts", "fills", "borders", "cellXfs", "cellStyles"):
            if _style_container(document, namespace, name) is None:
                msg = "Workbook styles are incomplete"
                raise ValueError(msg)
        return cls(document=document, namespace=namespace)

    def _records(self, container_name: str, record_name: str) -> tuple[Element, ...]:
        container = _style_container(self.document, self.namespace, container_name)
        if container is None:  # pragma: no cover - parse invariant.
            msg = "Workbook styles are incomplete"
            raise ValueError(msg)
        return _style_records(container, self.namespace, record_name)

    def _component_id(self, component: str, value: object) -> int:
        container_name = f"{component}s"
        desired = _backend_element(self.document, self.namespace, value, component)
        records = self._records(container_name, component)
        desired_state = _canonical_element(desired)
        for index, record in enumerate(records):
            if _canonical_element(record) == desired_state:
                return index
        container = _style_container(self.document, self.namespace, container_name)
        if container is None:  # pragma: no cover - parse invariant.
            msg = "Workbook styles are incomplete"
            raise ValueError(msg)
        container.appendChild(desired)
        updated = (*records, desired)
        _set_count(container, updated)
        self.changed = True
        return len(records)

    def _number_format_id(self, format_code: str) -> int:
        from openpyxl.styles.numbers import BUILTIN_FORMATS_REVERSE

        builtin = BUILTIN_FORMATS_REVERSE.get(format_code)
        if builtin is not None:
            return int(builtin)
        container = _style_container(
            self.document,
            self.namespace,
            "numFmts",
            create=True,
        )
        if container is None:  # pragma: no cover - create invariant.
            msg = "Workbook number formats are unavailable"
            raise ValueError(msg)
        records = _style_records(container, self.namespace, "numFmt")
        used: set[int] = set()
        for record in records:
            try:
                identifier = int(record.getAttribute("numFmtId"))
            except ValueError:
                msg = "Workbook number format identifier is invalid"
                raise ValueError(msg) from None
            if identifier in used:
                msg = "Workbook number format identifiers are duplicated"
                raise ValueError(msg)
            used.add(identifier)
            if record.getAttribute("formatCode") == format_code:
                return identifier
        identifier = max({163, *used}) + 1
        record = _new_element(self.document, self.namespace, "numFmt")
        record.setAttribute("numFmtId", str(identifier))
        record.setAttribute("formatCode", format_code)
        container.appendChild(record)
        _set_count(container, (*records, record))
        self.changed = True
        return identifier

    def _named_style_id(self, name: str) -> int:
        matches: list[int] = []
        for record in self._records("cellStyles", "cellStyle"):
            if record.getAttribute("name") != name:
                continue
            try:
                matches.append(int(record.getAttribute("xfId")))
            except ValueError:
                msg = "Workbook named style identifier is invalid"
                raise ValueError(msg) from None
        if len(matches) != 1:
            msg = "Workbook column format named style does not exist"
            raise ExcelModificationError(msg)
        return matches[0]

    def _xf(self, style_id: int) -> Element:
        records = self._records("cellXfs", "xf")
        if style_id < 0 or style_id >= len(records):
            msg = "Workbook column style identifier is invalid"
            raise ValueError(msg)
        return records[style_id]

    def fingerprint(self, style_id: int) -> str:
        xf = self._xf(style_id)
        components: list[object] = []
        for container_name, record_name, attribute in (
            ("fonts", "font", "fontId"),
            ("fills", "fill", "fillId"),
            ("borders", "border", "borderId"),
        ):
            records = self._records(container_name, record_name)
            try:
                index = int(xf.getAttribute(attribute) or "0")
                component = records[index]
            except (IndexError, ValueError):
                msg = "Workbook column style component is invalid"
                raise ValueError(msg) from None
            components.append(_canonical_element(component))
        num_fmt_id = int(xf.getAttribute("numFmtId") or "0")
        custom_formats = (
            {
                int(record.getAttribute("numFmtId")): record.getAttribute("formatCode")
                for record in self._records("numFmts", "numFmt")
            }
            if _style_container(self.document, self.namespace, "numFmts")
            else {}
        )
        from openpyxl.styles.numbers import BUILTIN_FORMATS

        number_format = custom_formats.get(
            num_fmt_id,
            BUILTIN_FORMATS.get(num_fmt_id, f"builtin:{num_fmt_id}"),
        )
        xf_id = xf.getAttribute("xfId") or "0"
        named_styles = tuple(
            sorted(
                (
                    f"builtin:{record.getAttribute('builtinId')}"
                    if record.hasAttribute("builtinId")
                    else f"name:{record.getAttribute('name')}"
                )
                for record in self._records("cellStyles", "cellStyle")
                if (record.getAttribute("xfId") or "0") == xf_id
            )
        )
        attributes = tuple(
            sorted(
                (node_attribute.name, node_attribute.value)
                for index in range(xf.attributes.length)
                if (
                    node_attribute := cast(
                        "Attr | None",
                        xf.attributes.item(index),
                    )
                )
                is not None
                and node_attribute.name
                not in _XF_ID_ATTRIBUTES | _XF_STORAGE_ATTRIBUTES
            )
        )
        children = tuple(_canonical_element(child) for child in _direct_elements(xf))
        state = (*components, number_format, named_styles, attributes, children)
        return sha256(repr(state).encode("utf-8")).hexdigest()

    def resolve(  # noqa: C901, PLR0912
        self,
        base_style_id: int,
        settings: dict[str, object],
    ) -> int:
        base = self._xf(base_style_id)
        desired = cast("Element", base.cloneNode(deep=True))
        for component, (identifier_attribute, apply_attribute) in (
            ("font", ("fontId", "applyFont")),
            ("fill", ("fillId", "applyFill")),
            ("border", ("borderId", "applyBorder")),
        ):
            value = settings.get(component)
            if value is None:
                continue
            desired.setAttribute(
                identifier_attribute,
                str(self._component_id(component, value)),
            )
            desired.setAttribute(apply_attribute, "1")
        alignment = settings.get("alignment")
        if alignment is not None:
            for child in tuple(_direct_elements(desired)):
                if _spreadsheet_element(child, "alignment", self.namespace):
                    desired.removeChild(child)
            alignment_element = _backend_element(
                self.document,
                self.namespace,
                alignment,
                "alignment",
            )
            if alignment_element.attributes.length:
                desired.appendChild(alignment_element)
            desired.setAttribute("applyAlignment", "1")
        number_format = settings.get("number_format")
        if isinstance(number_format, str):
            desired.setAttribute("numFmtId", str(self._number_format_id(number_format)))
            desired.setAttribute("applyNumberFormat", "1")
        named_style = settings.get("named_style")
        if isinstance(named_style, str):
            desired.setAttribute("xfId", str(self._named_style_id(named_style)))
        for field, attribute in (
            ("quote_prefix", "quotePrefix"),
            ("pivot_button", "pivotButton"),
        ):
            value = settings.get(field)
            if isinstance(value, bool):
                desired.setAttribute(attribute, "1" if value else "0")

        desired_state = _canonical_element(desired)
        records = self._records("cellXfs", "xf")
        for index, record in enumerate(records):
            if _canonical_element(record) == desired_state:
                return index
        container = _style_container(self.document, self.namespace, "cellXfs")
        if container is None:  # pragma: no cover - parse invariant.
            msg = "Workbook cell styles are unavailable"
            raise ValueError(msg)
        container.appendChild(desired)
        _set_count(container, (*records, desired))
        self.changed = True
        return len(records)

    @staticmethod
    def _copy_xf(
        target: Element,
        source: Element,
        *,
        omitted_attributes: frozenset[str] = frozenset(),
    ) -> None:
        attribute_names = tuple(
            attribute.name
            for index in range(target.attributes.length)
            if (attribute := cast("Attr | None", target.attributes.item(index)))
            is not None
        )
        for name in attribute_names:
            target.removeAttribute(name)
        for index in range(source.attributes.length):
            attribute = cast("Attr | None", source.attributes.item(index))
            if attribute is not None and attribute.name not in omitted_attributes:
                target.setAttribute(attribute.name, attribute.value)
        for child in tuple(target.childNodes):
            target.removeChild(child)
        for child in source.childNodes:
            target.appendChild(cast("Any", child.cloneNode(deep=True)))

    def apply_default(self, settings: dict[str, object]) -> tuple[str, str]:
        """Apply complete components to the workbook default cell style."""
        old_fingerprint = self.fingerprint(0)
        desired_style_id = self.resolve(0, settings)
        new_fingerprint = self.fingerprint(desired_style_id)
        if old_fingerprint == new_fingerprint:
            return old_fingerprint, new_fingerprint
        desired = self._xf(desired_style_id)
        default = self._xf(0)
        self._copy_xf(default, desired)
        try:
            style_xf_id = int(default.getAttribute("xfId") or "0")
            style_xfs = self._records("cellStyleXfs", "xf")
            style_xf = style_xfs[style_xf_id]
        except (IndexError, ValueError):
            msg = "Workbook default named style identifier is invalid"
            raise ValueError(msg) from None
        self._copy_xf(
            style_xf,
            desired,
            omitted_attributes=frozenset({"xfId", "pivotButton", "quotePrefix"}),
        )
        self.changed = True
        return old_fingerprint, new_fingerprint

    def default_is_consistent(self) -> bool:
        """Return whether the default cell XF and linked named-style XF agree."""
        default = self._xf(0)
        try:
            style_xf_id = int(default.getAttribute("xfId") or "0")
            style_xf = self._records("cellStyleXfs", "xf")[style_xf_id]
        except (IndexError, ValueError):
            return False
        for attribute in ("fontId", "fillId", "borderId", "numFmtId"):
            if (default.getAttribute(attribute) or "0") != (
                style_xf.getAttribute(attribute) or "0"
            ):
                return False
        default_children = tuple(
            _canonical_element(item) for item in _direct_elements(default)
        )
        style_children = tuple(
            _canonical_element(item) for item in _direct_elements(style_xf)
        )
        return default_children == style_children

    def payload(self) -> bytes:
        return self.document.toxml(encoding="utf-8")


def _state_style_id(state: dict[str, str] | None) -> int:
    if state is None or "style" not in state:
        return 0
    try:
        style_id = int(state["style"])
    except ValueError:
        msg = "Workbook column style identifier is invalid"
        raise ValueError(msg) from None
    if style_id < 0:
        msg = "Workbook column style identifier is invalid"
        raise ValueError(msg)
    return style_id


def _prepare_target_styles(
    table: _ColumnStyleTable,
    worksheet_payload: bytes,
    target: _ColumnTarget,
) -> None:
    document = minidom.parseString(  # noqa: S318 - bounded OOXML payload.
        worksheet_payload
    )
    root = _document_root(document)
    namespace = root.namespaceURI
    if namespace not in _SPREADSHEETML_WORKSHEET_NAMESPACES:
        msg = "Workbook worksheet namespace is unsupported"
        raise ValueError(msg)
    states = _existing_states(_worksheet_columns(root, namespace), namespace)
    for column, settings in target.settings.items():
        components = tuple(
            field for field in _COLUMN_STYLE_FIELDS if settings.get(field) is not None
        )
        if not components:
            continue
        old_style_id = _state_style_id(states[column])
        old_fingerprint = table.fingerprint(old_style_id)
        new_style_id = table.resolve(old_style_id, settings)
        new_fingerprint = table.fingerprint(new_style_id)
        settings["style_id"] = new_style_id
        settings["_old_style_fingerprint"] = old_fingerprint
        settings["_new_style_fingerprint"] = new_fingerprint
        settings["_style_changed_components"] = components


def _columns_element(document: Document, namespace: str) -> Element:
    root = _document_root(document)
    columns = _new_element(document, namespace, "cols")
    successors = {
        "sheetData",
        "sheetCalcPr",
        "sheetProtection",
        "protectedRanges",
        "scenarios",
        "autoFilter",
        "sortState",
        "dataConsolidate",
        "customSheetViews",
        "mergeCells",
        "phoneticPr",
        "conditionalFormatting",
        "dataValidations",
        "hyperlinks",
        "printOptions",
        "pageMargins",
        "pageSetup",
        "headerFooter",
        "rowBreaks",
        "colBreaks",
        "customProperties",
        "cellWatches",
        "ignoredErrors",
        "smartTags",
        "drawing",
        "legacyDrawing",
        "legacyDrawingHF",
        "picture",
        "oleObjects",
        "controls",
        "webPublishItems",
        "tableParts",
        "extLst",
    }
    reference = next(
        (
            child
            for child in _direct_elements(root)
            if child.namespaceURI == namespace and child.localName in successors
        ),
        None,
    )
    root.insertBefore(columns, reference)
    return columns


def _worksheet_columns(root: Element, namespace: str) -> Element | None:
    """Return the sole direct SpreadsheetML column container, if present."""
    matches = tuple(
        element
        for element in _direct_elements(root)
        if _spreadsheet_element(element, "cols", namespace)
    )
    if len(matches) > 1:
        msg = "Workbook worksheet contains duplicate column containers"
        raise ValueError(msg)
    return matches[0] if matches else None


def _replace_column_elements(
    document: Document,
    columns: Element,
    namespace: str,
    states: list[dict[str, str] | None],
) -> None:
    for child in tuple(columns.childNodes):
        if child.nodeType == Node.ELEMENT_NODE and _spreadsheet_element(
            child, "col", namespace
        ):
            columns.removeChild(child)

    column = 1
    while column <= MAX_EXCEL_COLUMN:
        state = states[column]
        if state is None:
            column += 1
            continue
        maximum = column
        while maximum < MAX_EXCEL_COLUMN and states[maximum + 1] == state:
            maximum += 1
        element = _new_element(document, namespace, "col")
        element.setAttribute("min", str(column))
        element.setAttribute("max", str(maximum))
        for name, value in state.items():
            element.setAttribute(name, value)
        columns.appendChild(element)
        column = maximum + 1


def _patch_worksheet(
    payload: bytes,
    *,
    sheet_name: str,
    settings: dict[int, dict[str, object]],
) -> tuple[bytes, tuple[_PendingColumnChange, ...]]:
    document = minidom.parseString(  # noqa: S318 - bounded, DTD-screened OOXML.
        payload
    )
    root = _document_root(document)
    namespace = root.namespaceURI
    if namespace not in _SPREADSHEETML_WORKSHEET_NAMESPACES:
        msg = "Workbook worksheet namespace is unsupported"
        raise ValueError(msg)
    columns = _worksheet_columns(root, namespace)
    states = _existing_states(columns, namespace)
    changes = _apply_settings(states, settings, sheet_name=sheet_name)
    if not changes:
        return payload, ()
    actual_columns = columns or _columns_element(document, namespace)
    _replace_column_elements(document, actual_columns, namespace, states)
    return _serialize_xml(document), changes


def _copy_package(  # noqa: PLR0913
    source_path: Path,
    output_path: Path,
    replacements: dict[str, bytes],
    *,
    source_fingerprint: str,
    additions: dict[str, bytes] | None = None,
    removals: frozenset[str] = frozenset(),
) -> None:
    from document_sdk.excel._source_identity import open_verified_binary

    extra_members = additions or {}
    if not replacements and not extra_members and not removals:
        with (
            open_verified_binary(source_path, source_fingerprint) as source_stream,
            output_path.open("wb") as output_stream,
        ):
            copyfileobj(source_stream, output_stream)
        return

    with (
        open_verified_binary(source_path, source_fingerprint) as source_stream,
        ZipFile(source_stream, "r") as source,
        ZipFile(
            output_path,
            "w",
            compression=ZIP_DEFLATED,
            allowZip64=True,
            strict_timestamps=False,
        ) as output,
    ):
        output.comment = source.comment
        source_names = {info.filename for info in source.infolist()}
        if not removals.issubset(source_names):
            msg = "Workbook package removal references a missing member"
            raise ValueError(msg)
        if (source_names - removals).intersection(extra_members):
            msg = "Workbook package addition collides with an existing member"
            raise ValueError(msg)
        for info in sorted(source.infolist(), key=lambda item: item.filename):
            if info.filename in removals:
                continue
            payload = replacements.get(info.filename)
            if payload is None:
                payload = source.read(info)
            output.writestr(copy(info), payload)
        for name in sorted(extra_members):
            write_new_member(output, name, extra_members[name])


def create_column_patch_output(
    source_path: Path,
    output_path: Path,
    patches: Sequence[ColumnDimensionPatch],
    *,
    source_fingerprint: str,
) -> tuple[_PendingColumnChange, ...]:
    """Write and verify one package-level column-dimension patch output."""
    targets = _resolve_targets(
        source_path,
        patches,
        source_fingerprint=source_fingerprint,
    )
    replacements: dict[str, bytes] = {}
    pending: list[_PendingColumnChange] = []
    with _SafePackage(source_path) as package:
        package.verify_fingerprint(source_fingerprint)
        worksheet_payloads: dict[str, bytes] = {}
        for target in targets:
            with package.open_xml_stream(target.member) as stream:
                worksheet_payloads[target.member] = stream.read()
        style_requested = any(
            any(settings.get(field) is not None for field in _COLUMN_STYLE_FIELDS)
            for target in targets
            for settings in target.settings.values()
        )
        style_table: _ColumnStyleTable | None = None
        if style_requested:
            if not package.has("xl/styles.xml"):
                msg = "Workbook styles part does not exist"
                raise ExcelModificationError(msg)
            with package.open_xml_stream("xl/styles.xml") as stream:
                style_table = _ColumnStyleTable.parse(stream.read())
            for target in targets:
                _prepare_target_styles(
                    style_table,
                    worksheet_payloads[target.member],
                    target,
                )
            style_changed = any(
                settings.get("_old_style_fingerprint")
                != settings.get("_new_style_fingerprint")
                for target in targets
                for settings in target.settings.values()
                if settings.get("_old_style_fingerprint") is not None
            )
            if style_changed:
                replacements["xl/styles.xml"] = style_table.payload()
        for target in targets:
            payload = worksheet_payloads[target.member]
            replacement, changes = _patch_worksheet(
                payload,
                sheet_name=target.sheet_name,
                settings=target.settings,
            )
            if changes:
                replacements[target.member] = replacement
            pending.extend(changes)
    _copy_package(
        source_path,
        output_path,
        replacements,
        source_fingerprint=source_fingerprint,
    )
    verify_column_patch_output(output_path, patches)
    return tuple(pending)


def verify_column_patch_output(  # noqa: C901
    output_path: Path,
    patches: Sequence[ColumnDimensionPatch],
) -> None:
    """Verify requested column settings from the independently reopened package."""
    targets = _resolve_targets(output_path, patches, source_fingerprint=None)
    with _SafePackage(output_path) as package:
        style_requested = any(
            any(settings.get(field) is not None for field in _COLUMN_STYLE_FIELDS)
            for target in targets
            for settings in target.settings.values()
        )
        style_table: _ColumnStyleTable | None = None
        if style_requested:
            if not package.has("xl/styles.xml"):
                msg = "Patched workbook styles part does not exist"
                raise ExcelModificationError(msg)
            with package.open_xml_stream("xl/styles.xml") as stream:
                style_table = _ColumnStyleTable.parse(stream.read())
        for target in targets:
            with package.open_xml_stream(target.member) as stream:
                document = minidom.parse(  # noqa: S318 - bounded, DTD-screened OOXML.
                    stream
                )
            root = _document_root(document)
            namespace = root.namespaceURI
            if namespace not in _SPREADSHEETML_WORKSHEET_NAMESPACES:
                msg = "Patched workbook worksheet namespace is unsupported"
                raise ExcelModificationError(msg)
            columns = _worksheet_columns(root, namespace)
            states = _existing_states(columns, namespace)
            for column, expected in target.settings.items():
                state = states[column]
                expected_width = expected.get("width")
                if isinstance(expected_width, float) and not math.isclose(
                    _state_width(state) or 0.0,
                    expected_width,
                    rel_tol=0.0,
                    abs_tol=1e-12,
                ):
                    msg = "Patched workbook column-width verification failed"
                    raise ExcelModificationError(msg)
                expected_hidden = expected.get("hidden")
                if (
                    isinstance(expected_hidden, bool)
                    and _state_hidden(state) != expected_hidden
                ):
                    msg = "Patched workbook column-visibility verification failed"
                    raise ExcelModificationError(msg)
                if (
                    expected.get("clear_width") is True
                    and _state_width(state) is not None
                ):
                    msg = "Patched workbook column-width clearing verification failed"
                    raise ExcelModificationError(msg)
                expected_best_fit = expected.get("best_fit")
                if (
                    isinstance(expected_best_fit, bool)
                    and _state_best_fit(state) != expected_best_fit
                ):
                    msg = "Patched workbook column-best-fit verification failed"
                    raise ExcelModificationError(msg)
                if style_table is not None and any(
                    expected.get(field) is not None for field in _COLUMN_STYLE_FIELDS
                ):
                    actual_style_id = _state_style_id(state)
                    expected_style_id = style_table.resolve(
                        actual_style_id,
                        expected,
                    )
                    if style_table.fingerprint(
                        expected_style_id
                    ) != style_table.fingerprint(actual_style_id):
                        msg = "Patched workbook column-format verification failed"
                        raise ExcelModificationError(msg)


def public_column_range(change: _PendingColumnChange) -> tuple[str, str]:
    """Return public bounded letters for one pending column change."""
    return (
        excel_column_letter(change.start_column),
        excel_column_letter(change.end_column),
    )

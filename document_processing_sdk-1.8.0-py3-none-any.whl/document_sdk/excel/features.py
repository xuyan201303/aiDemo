"""Public workbook feature inventory."""

from __future__ import annotations

from typing import TYPE_CHECKING

from document_sdk.excel._dependencies import require_excel_support
from document_sdk.excel._helpers import (
    inspect_excel_input,
    translate_excel_errors,
    validate_excel_package_limits,
)
from document_sdk.excel._package import PackageFeatureScan, inspect_package_features

if TYPE_CHECKING:
    from pathlib import Path

    from document_sdk.excel.models import ExcelPackageLimits, WorkbookFeatureInventory


def _scan_workbook_features(
    path: Path,
    *,
    package_limits: ExcelPackageLimits | None = None,
) -> PackageFeatureScan:
    """Inspect a validated local workbook once for inventory and risk facts."""
    require_excel_support()
    validated_limits = validate_excel_package_limits(package_limits)
    descriptor = inspect_excel_input(path, package_limits=validated_limits)
    with translate_excel_errors(path, "inspect workbook features"):
        return inspect_package_features(
            path, descriptor=descriptor, limits=validated_limits
        )


def inspect_workbook_features(
    path: Path,
    *,
    package_limits: ExcelPackageLimits | None = None,
) -> WorkbookFeatureInventory:
    """Return a serializable inventory for one local XLSX or XLSM workbook."""
    return _scan_workbook_features(path, package_limits=package_limits).inventory

"""Bounded, read-only source details for local OOXML workbooks.

The normalized Excel readers intentionally omit physical empty cells and many
package-level representation details.  This module exposes those source facts
without changing the behavior of the existing sparse reading APIs.
"""

from __future__ import annotations

import posixpath
from collections import defaultdict
from contextlib import suppress
from dataclasses import dataclass, field
from hashlib import sha256
from pathlib import PurePosixPath
from typing import TYPE_CHECKING, Annotated, Literal, Self, cast
from xml.etree.ElementTree import (
    Element,
    ParseError,
    TreeBuilder,
    XMLParser,
    XMLPullParser,
    iterparse,
)
from zipfile import BadZipFile

from pydantic import (
    Field,
    StringConstraints,
    TypeAdapter,
    field_validator,
    model_validator,
)

from document_sdk.core import FileDescriptor  # noqa: TC001 - Pydantic field.
from document_sdk.core._excel_coordinates import (
    MAX_EXCEL_COLUMN,
    MAX_EXCEL_ROW,
    excel_column_letter,
    excel_range_bounds,
    normalize_excel_coordinate,
    normalize_excel_range,
)
from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.core.models import SdkModel, WorksheetName
from document_sdk.excel._helpers import (
    inspect_excel_input,
    translate_excel_errors,
    validate_excel_package_limits,
)
from document_sdk.excel._package import _SafePackage
from document_sdk.excel._package_chartsheet import _content_types
from document_sdk.excel._package_security import _local_name, _resolve_target
from document_sdk.excel._package_types import _SheetRecord
from document_sdk.excel._package_workbook import _sheet_type, _sheet_visibility
from document_sdk.excel._visible_text import _visible_text
from document_sdk.excel.errors import ExcelPackageLimitError
from document_sdk.excel.models import (  # noqa: TC001 - runtime limit access.
    ExcelPackageLimits,
)

if TYPE_CHECKING:
    from collections.abc import Iterable, Mapping
    from pathlib import Path

type NonEmptyString = Annotated[
    str,
    StringConstraints(min_length=1),
]
type DetailCategory = Literal[
    "style",
    "physical_cell",
    "comment",
    "defined_name",
    "drawing",
    "chart",
    "row",
    "column",
    "view",
    "page_print",
    "workbook_property",
    "custom_xml",
    "extension",
    "other",
]
type PackagePartKind = Literal["xml", "relationship", "image", "binary"]
type StyleComponent = Literal[
    "number_format",
    "font",
    "fill",
    "border",
    "cell_style_xf",
    "cell_xf",
    "cell_style",
    "differential_style",
    "table_style",
    "indexed_color",
]

_WORKSHEET_NAME_ADAPTER: TypeAdapter[str] = TypeAdapter(WorksheetName)

_RELATIONSHIPS_NAMESPACE = (
    "http://schemas.openxmlformats.org/package/2006/relationships"
)
_SPREADSHEET_NAMESPACES = frozenset(
    {
        "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
        "http://purl.oclc.org/ooxml/spreadsheetml/main",
    }
)
_OFFICE_RELATIONSHIP_NAMESPACES = frozenset(
    {
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
        "http://purl.oclc.org/ooxml/officeDocument/relationships",
    }
)
_TRANSITIONAL_OFFICE_RELATIONSHIP_NAMESPACE = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
)
_STRICT_OFFICE_RELATIONSHIP_NAMESPACE = (
    "http://purl.oclc.org/ooxml/officeDocument/relationships"
)
_DRAWING_NAMESPACES = frozenset(
    {
        "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing",
        "http://purl.oclc.org/ooxml/drawingml/spreadsheetDrawing",
    }
)
_DRAWING_MAIN_NAMESPACES = frozenset(
    {
        "http://schemas.openxmlformats.org/drawingml/2006/main",
        "http://purl.oclc.org/ooxml/drawingml/main",
    }
)
_CHART_NAMESPACES = frozenset(
    {
        "http://schemas.openxmlformats.org/drawingml/2006/chart",
        "http://purl.oclc.org/ooxml/drawingml/chart",
    }
)
_STRICT_SOURCE_NAMESPACES = frozenset(
    {
        "http://purl.oclc.org/ooxml/spreadsheetml/main",
        "http://purl.oclc.org/ooxml/drawingml/spreadsheetDrawing",
        "http://purl.oclc.org/ooxml/drawingml/main",
        "http://purl.oclc.org/ooxml/drawingml/chart",
    }
)
_TRANSITIONAL_SOURCE_NAMESPACES = (
    _SPREADSHEET_NAMESPACES
    | _DRAWING_NAMESPACES
    | _DRAWING_MAIN_NAMESPACES
    | _CHART_NAMESPACES
) - _STRICT_SOURCE_NAMESPACES
_RELATIONSHIP_ROLE_TYPES = {
    role: frozenset(
        f"{namespace}/{role}" for namespace in _OFFICE_RELATIONSHIP_NAMESPACES
    )
    for role in (
        "officeDocument",
        "worksheet",
        "chartsheet",
        "dialogsheet",
        "macrosheet",
        "xlMacrosheet",
        "styles",
        "comments",
        "drawing",
        "chart",
        "table",
        "hyperlink",
        "image",
    )
}
_RELATIONSHIP_ROLE_TYPES["xlMacrosheet"] = frozenset(
    {"http://schemas.microsoft.com/office/2006/relationships/xlMacrosheet"}
)
_ROLE_CONTENT_TYPES: dict[str, frozenset[str]] = {
    "officeDocument": frozenset(
        {
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml",
            "application/vnd.ms-excel.sheet.macroEnabled.main+xml",
        }
    ),
    "worksheet": frozenset(
        {"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"}
    ),
    "chartsheet": frozenset(
        {"application/vnd.openxmlformats-officedocument.spreadsheetml.chartsheet+xml"}
    ),
    "dialogsheet": frozenset(
        {"application/vnd.openxmlformats-officedocument.spreadsheetml.dialogsheet+xml"}
    ),
    "macrosheet": frozenset({"application/vnd.ms-excel.macrosheet+xml"}),
    "xlMacrosheet": frozenset({"application/vnd.ms-excel.macrosheet+xml"}),
    "styles": frozenset(
        {"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"}
    ),
    "comments": frozenset(
        {"application/vnd.openxmlformats-officedocument.spreadsheetml.comments+xml"}
    ),
    "drawing": frozenset({"application/vnd.openxmlformats-officedocument.drawing+xml"}),
    "chart": frozenset(
        {"application/vnd.openxmlformats-officedocument.drawingml.chart+xml"}
    ),
    "table": frozenset(
        {"application/vnd.openxmlformats-officedocument.spreadsheetml.table+xml"}
    ),
}
_RELATIONSHIP_SUFFIXES = frozenset({".rels"})
_XML_SUFFIXES = frozenset({".xml", ".vml"})
_IMAGE_PREFIX = "image/"
_READ_CHUNK_SIZE = 1024 * 1024
_DEFAULT_DETAIL_RECORD_LIMIT = 1_000_000
_DEFAULT_DETAIL_TEXT_LIMIT = 64 * 1024 * 1024
_DEFAULT_DETAIL_XML_DEPTH_LIMIT = 256
_CHART_TYPE_PATH_LENGTH = 4
_CHART_SERIES_PATH_LENGTH = 5
_STYLE_COMPONENTS = frozenset(
    {
        "numFmt",
        "font",
        "fill",
        "border",
        "xf",
        "cellStyle",
        "dxf",
        "tableStyle",
        "color",
    }
)
_VIEW_ELEMENTS = frozenset(
    {"bookViews", "workbookView", "sheetViews", "sheetView", "pane", "selection"}
)
_PAGE_PRINT_ELEMENTS = frozenset(
    {
        "pageMargins",
        "pageSetup",
        "printOptions",
        "headerFooter",
        "oddHeader",
        "oddFooter",
        "evenHeader",
        "evenFooter",
        "firstHeader",
        "firstFooter",
        "rowBreaks",
        "colBreaks",
        "brk",
        "pageSetUpPr",
    }
)
_WORKBOOK_PROPERTY_ELEMENTS = frozenset(
    {
        "workbook",
        "fileVersion",
        "workbookPr",
        "workbookProtection",
        "calcPr",
        "fileSharing",
        "smartTagPr",
    }
)
_WORKSHEET_PROPERTY_ELEMENTS = frozenset(
    {
        "worksheet",
        "sheetPr",
        "tabColor",
        "outlinePr",
        "sheetFormatPr",
        "dimension",
        "sheetCalcPr",
        "sheetProtection",
        "mergeCells",
        "mergeCell",
        "drawing",
        "legacyDrawing",
        "legacyDrawingHF",
        "picture",
    }
)
_STYLE_PATH_COMPONENTS: dict[tuple[str, ...], StyleComponent] = {
    ("styleSheet", "numFmts", "numFmt"): "number_format",
    ("styleSheet", "fonts", "font"): "font",
    ("styleSheet", "fills", "fill"): "fill",
    ("styleSheet", "borders", "border"): "border",
    ("styleSheet", "cellStyleXfs", "xf"): "cell_style_xf",
    ("styleSheet", "cellXfs", "xf"): "cell_xf",
    ("styleSheet", "cellStyles", "cellStyle"): "cell_style",
    ("styleSheet", "dxfs", "dxf"): "differential_style",
    ("styleSheet", "tableStyles", "tableStyle"): "table_style",
    ("styleSheet", "colors", "indexedColors", "rgbColor"): "indexed_color",
}
_VIEW_PATHS = frozenset(
    {
        ("workbook", "bookViews"),
        ("workbook", "bookViews", "workbookView"),
        ("worksheet", "sheetViews"),
        ("worksheet", "sheetViews", "sheetView"),
        ("worksheet", "sheetViews", "sheetView", "pane"),
        ("worksheet", "sheetViews", "sheetView", "selection"),
        ("chartsheet", "sheetViews"),
        ("chartsheet", "sheetViews", "sheetView"),
        ("chartsheet", "sheetViews", "sheetView", "selection"),
    }
)
_PAGE_PRINT_PATH_SUFFIXES = frozenset(
    {
        ("pageMargins",),
        ("pageSetup",),
        ("printOptions",),
        ("headerFooter",),
        ("headerFooter", "oddHeader"),
        ("headerFooter", "oddFooter"),
        ("headerFooter", "evenHeader"),
        ("headerFooter", "evenFooter"),
        ("headerFooter", "firstHeader"),
        ("headerFooter", "firstFooter"),
        ("rowBreaks",),
        ("rowBreaks", "brk"),
        ("colBreaks",),
        ("colBreaks", "brk"),
        ("sheetPr", "pageSetUpPr"),
    }
)
_WORKBOOK_PROPERTY_PATHS = frozenset(
    {
        ("workbook",),
        ("workbook", "sheets"),
        ("workbook", "sheets", "sheet"),
        ("workbook", "fileVersion"),
        ("workbook", "workbookPr"),
        ("workbook", "workbookProtection"),
        ("workbook", "calcPr"),
        ("workbook", "fileSharing"),
        ("workbook", "smartTagPr"),
    }
)
_WORKSHEET_PROPERTY_PATH_SUFFIXES = frozenset(
    {
        (),
        ("sheetPr",),
        ("sheetPr", "tabColor"),
        ("sheetPr", "outlinePr"),
        ("sheetFormatPr",),
        ("dimension",),
        ("sheetCalcPr",),
        ("sheetProtection",),
        ("mergeCells",),
        ("mergeCells", "mergeCell"),
        ("drawing",),
        ("legacyDrawing",),
        ("legacyDrawingHF",),
        ("picture",),
    }
)
_WORKBOOK_TYPED_PATHS = (
    _WORKBOOK_PROPERTY_PATHS
    | _VIEW_PATHS
    | frozenset({("workbook", "definedNames", "definedName")})
)
_WORKSHEET_TYPED_PATHS = (
    frozenset(path for path in _VIEW_PATHS if path[0] == "worksheet")
    | frozenset(("worksheet", *suffix) for suffix in _PAGE_PRINT_PATH_SUFFIXES)
    | frozenset(("worksheet", *suffix) for suffix in _WORKSHEET_PROPERTY_PATH_SUFFIXES)
    | frozenset(
        {
            ("worksheet", "sheetData", "row"),
            ("worksheet", "sheetData", "row", "c"),
            ("worksheet", "sheetData", "row", "c", "f"),
            ("worksheet", "sheetData", "row", "c", "v"),
            ("worksheet", "sheetData", "row", "c", "is"),
            ("worksheet", "sheetData", "row", "c", "is", "t"),
            ("worksheet", "sheetData", "row", "c", "is", "r"),
            ("worksheet", "sheetData", "row", "c", "is", "r", "t"),
            ("worksheet", "sheetData", "row", "c", "is", "rPh", "t"),
            ("worksheet", "cols", "col"),
            ("worksheet", "hyperlinks", "hyperlink"),
            ("worksheet", "dataValidations", "dataValidation"),
            (
                "worksheet",
                "dataValidations",
                "dataValidation",
                "formula1",
            ),
            (
                "worksheet",
                "dataValidations",
                "dataValidation",
                "formula2",
            ),
            ("worksheet", "conditionalFormatting"),
            ("worksheet", "conditionalFormatting", "cfRule"),
            ("worksheet", "conditionalFormatting", "cfRule", "formula"),
            ("worksheet", "autoFilter"),
        }
    )
)
_CHARTSHEET_TYPED_PATHS = frozenset(
    path for path in _VIEW_PATHS if path[0] == "chartsheet"
) | frozenset(("chartsheet", *suffix) for suffix in _PAGE_PRINT_PATH_SUFFIXES)
_COMMENT_TYPED_PATHS = frozenset(
    {
        ("comments", "authors", "author"),
        ("comments", "commentList", "comment"),
        ("comments", "commentList", "comment", "text"),
        ("comments", "commentList", "comment", "text", "t"),
        ("comments", "commentList", "comment", "text", "r"),
        ("comments", "commentList", "comment", "text", "r", "t"),
        ("comments", "commentList", "comment", "text", "rPh", "t"),
    }
)
_DRAWING_TYPED_PATHS = frozenset(
    {
        ("wsDr", "oneCellAnchor"),
        ("wsDr", "twoCellAnchor"),
        ("wsDr", "absoluteAnchor"),
    }
)
_TYPED_PATHS_BY_ROLE = {
    "workbook": _WORKBOOK_TYPED_PATHS,
    "worksheets": _WORKSHEET_TYPED_PATHS,
    "chartsheets": _CHARTSHEET_TYPED_PATHS,
    "comments": _COMMENT_TYPED_PATHS,
    "drawings": _DRAWING_TYPED_PATHS,
}
_TYPED_NAMES_BY_ROLE = {
    role: frozenset(path[-1] for path in paths)
    for role, paths in _TYPED_PATHS_BY_ROLE.items()
}


def _namespace(name: str) -> str | None:
    if name.startswith("{") and "}" in name:
        return name[1:].split("}", 1)[0]
    return None


def _bool_attribute(value: str | None, *, default: bool = False) -> bool:
    if value is None:
        return default
    if value in {"1", "true"}:
        return True
    if value in {"0", "false"}:
        return False
    msg = "Workbook Boolean attribute has an invalid lexical value"
    raise ValueError(msg)


def _optional_int(value: str | None) -> int | None:
    return None if value is None else int(value)


def _optional_float(value: str | None) -> float | None:
    return None if value is None else float(value)


def _relationship_role(relationship_type: str) -> str | None:
    return next(
        (
            role
            for role, allowed in _RELATIONSHIP_ROLE_TYPES.items()
            if relationship_type in allowed
        ),
        None,
    )


def _relationship_attribute(element: Element, *names: str) -> str | None:
    matching = [
        (_namespace(attribute), value)
        for attribute, value in element.attrib.items()
        if _local_name(attribute) in names
    ]
    source_namespace = _namespace(element.tag)
    expected_namespaces = (
        frozenset({_STRICT_OFFICE_RELATIONSHIP_NAMESPACE})
        if source_namespace in _STRICT_SOURCE_NAMESPACES
        else (
            frozenset({_TRANSITIONAL_OFFICE_RELATIONSHIP_NAMESPACE})
            if source_namespace in _TRANSITIONAL_SOURCE_NAMESPACES
            else _OFFICE_RELATIONSHIP_NAMESPACES
        )
    )
    if any(
        namespace not in expected_namespaces or not value
        for namespace, value in matching
    ):
        msg = "Workbook relationship reference namespace or value is invalid"
        raise ValueError(msg)
    if len(matching) > 1:
        msg = "Workbook relationship reference is ambiguous"
        raise ValueError(msg)
    return None if not matching else matching[0][1]


class ExcelSourceAttribute(SdkModel):
    """One exact XML attribute represented by namespace, local name, and value."""

    namespace: str | None = None
    name: NonEmptyString
    value: str


class ExcelSourceProperty(SdkModel):
    """One ordered property inside a structured OOXML source record."""

    path: NonEmptyString
    namespace: str | None = None
    name: NonEmptyString
    attributes: tuple[ExcelSourceAttribute, ...] = ()
    text: str | None = None


class ExcelSourceRelationshipReference(SdkModel):
    """One exact relationship reference that attaches a semantic object."""

    source_part: NonEmptyString
    relationship_id: NonEmptyString


class ExcelPackagePartDetail(SdkModel):
    """Identity and content classification for one validated package member."""

    part_name: NonEmptyString
    content_type: str | None = None
    kind: PackagePartKind
    semantic_representation: Literal["typed", "structured", "identity_only"] = (
        "identity_only"
    )
    size_bytes: int = Field(ge=0)
    sha256: str = Field(pattern=r"^[0-9a-f]{64}$")


class ExcelRelationshipDetail(SdkModel):
    """One OOXML relationship without exposing external target text."""

    source_part: str
    relationship_part: NonEmptyString
    path: NonEmptyString
    relationship_id: NonEmptyString
    relationship_type: NonEmptyString
    target_part: str | None = None
    raw_internal_target: str | None = None
    target_mode: Literal["Internal", "External"] | None = None
    external: bool
    external_target_sha256: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )
    additional_attributes: tuple[ExcelSourceAttribute, ...] = ()

    @model_validator(mode="after")
    def validate_target(self) -> Self:
        """Require exactly the appropriate internal or redacted external target."""
        if self.external == (self.external_target_sha256 is None):
            msg = "external relationships require only a target hash"
            raise ValueError(msg)
        if self.external == (self.target_part is not None):
            msg = "internal relationships require only a package target"
            raise ValueError(msg)
        if self.external:
            if self.raw_internal_target is not None or self.target_mode != "External":
                msg = "external relationship source representation is inconsistent"
                raise ValueError(msg)
        elif self.raw_internal_target is None or self.target_mode == "External":
            msg = "internal relationship source representation is inconsistent"
            raise ValueError(msg)
        return self


class ExcelStyleDetail(SdkModel):
    """One indexed style catalog component with its complete structured subtree."""

    component: StyleComponent
    index: int = Field(ge=0)
    part_name: NonEmptyString
    path: NonEmptyString
    attributes: tuple[ExcelSourceAttribute, ...] = ()
    properties: tuple[ExcelSourceProperty, ...] = ()


class ExcelPhysicalCellDetail(SdkModel):
    """One physical ``c`` element, including represented empty forms."""

    sheet_name: WorksheetName
    part_name: NonEmptyString
    path: NonEmptyString
    coordinate: NonEmptyString
    namespace: str | None = None
    raw_type: str | None = None
    direct_style_id: int | None = Field(default=None, ge=0)
    effective_style_id: int = Field(ge=0)
    style_source: Literal["cell", "row", "column", "default"]
    formula_present: bool
    formula_kind: Literal["ordinary", "shared", "array", "dynamic_array"] | None = None
    formula_text: str | None = None
    formula_shared_index: int | None = Field(default=None, ge=0)
    formula_range: str | None = None
    formula_attributes: tuple[ExcelSourceAttribute, ...] = ()
    cached_value_present: bool
    raw_cached_value: str | None = None
    inline_string_present: bool
    inline_text: str | None = None
    attributes: tuple[ExcelSourceAttribute, ...] = ()

    @model_validator(mode="after")
    def validate_payloads(self) -> Self:  # noqa: C901
        """Keep physical-presence flags and their retained source facts coherent."""
        formula_facts = (
            self.formula_kind,
            self.formula_text,
            self.formula_shared_index,
            self.formula_range,
        )
        if self.formula_present != (self.formula_kind is not None):
            msg = "physical cell formula presence is inconsistent"
            raise ValueError(msg)
        if not self.formula_present and (
            any(value is not None for value in formula_facts) or self.formula_attributes
        ):
            msg = "physical cell without a formula cannot retain formula facts"
            raise ValueError(msg)
        if self.formula_kind == "shared" and self.formula_shared_index is None:
            msg = "shared formula requires a shared index"
            raise ValueError(msg)
        if self.formula_kind != "shared" and self.formula_shared_index is not None:
            msg = "only a shared formula may retain a shared index"
            raise ValueError(msg)
        if not self.cached_value_present and self.raw_cached_value is not None:
            msg = "physical cell without a cache cannot retain a cached value"
            raise ValueError(msg)
        if not self.inline_string_present and self.inline_text is not None:
            msg = "physical cell without an inline string cannot retain inline text"
            raise ValueError(msg)
        if self.cached_value_present and self.inline_string_present:
            msg = "physical cell cannot contain cached and inline value payloads"
            raise ValueError(msg)
        formula_attribute_keys = [
            (item.namespace, item.name) for item in self.formula_attributes
        ]
        if len(formula_attribute_keys) != len(set(formula_attribute_keys)):
            msg = "physical cell formula attributes must be unique"
            raise ValueError(msg)
        formula_attributes = {
            item.name: item.value
            for item in self.formula_attributes
            if item.namespace is None
        }
        expected_formula_kind = {
            None: "ordinary",
            "normal": "ordinary",
            "shared": "shared",
            "array": "array",
            "dataTable": "dynamic_array",
            "dynamicArray": "dynamic_array",
        }.get(formula_attributes.get("t"))
        if self.formula_present and expected_formula_kind != self.formula_kind:
            msg = "physical cell formula type is inconsistent"
            raise ValueError(msg)
        shared_index = formula_attributes.get("si")
        try:
            parsed_shared_index = None if shared_index is None else int(shared_index)
        except ValueError:
            msg = "physical cell formula shared index is invalid"
            raise ValueError(msg) from None
        if self.formula_present and (
            (shared_index is None) != (self.formula_shared_index is None)
            or (
                shared_index is not None
                and parsed_shared_index != self.formula_shared_index
            )
        ):
            msg = "physical cell formula shared index is inconsistent"
            raise ValueError(msg)
        if self.formula_present and formula_attributes.get("ref") != self.formula_range:
            msg = "physical cell formula range is inconsistent"
            raise ValueError(msg)
        return self

    @field_validator("coordinate")
    @classmethod
    def validate_coordinate(cls, value: str) -> str:
        """Normalize and bound the source coordinate."""
        return normalize_excel_coordinate(value)


class ExcelRowDetail(SdkModel):
    """One physical row with raw and default-resolved properties."""

    sheet_name: WorksheetName
    part_name: NonEmptyString
    path: NonEmptyString
    row: int = Field(ge=1, le=MAX_EXCEL_ROW)
    height: float | None = Field(default=None, ge=0)
    effective_height: float | None = Field(default=None, ge=0)
    hidden: bool
    outline_level: int = Field(ge=0)
    collapsed: bool
    style_id: int | None = Field(default=None, ge=0)
    custom_height: bool
    custom_format: bool
    attributes: tuple[ExcelSourceAttribute, ...] = ()


class ExcelColumnDetail(SdkModel):
    """One physical column span with raw and default-resolved properties."""

    sheet_name: WorksheetName
    part_name: NonEmptyString
    path: NonEmptyString
    min_column: int = Field(ge=1, le=MAX_EXCEL_COLUMN)
    max_column: int = Field(ge=1, le=MAX_EXCEL_COLUMN)
    width: float | None = Field(default=None, ge=0)
    effective_width: float | None = Field(default=None, ge=0)
    hidden: bool
    outline_level: int = Field(ge=0)
    collapsed: bool
    style_id: int | None = Field(default=None, ge=0)
    best_fit: bool
    custom_width: bool
    attributes: tuple[ExcelSourceAttribute, ...] = ()

    @model_validator(mode="after")
    def validate_span(self) -> Self:
        """Reject reversed source column spans."""
        if self.min_column > self.max_column:
            msg = "column span minimum cannot exceed maximum"
            raise ValueError(msg)
        return self


class ExcelCommentDetail(SdkModel):
    """One legacy comment with its author, text, and exact cell location."""

    sheet_name: WorksheetName
    part_name: NonEmptyString
    path: NonEmptyString
    coordinate: NonEmptyString
    author_id: int = Field(ge=0)
    author: str
    text: str
    rich_text_runs: tuple[str, ...] = ()
    attributes: tuple[ExcelSourceAttribute, ...] = ()

    @field_validator("coordinate")
    @classmethod
    def validate_coordinate(cls, value: str) -> str:
        """Normalize and bound the comment location."""
        return normalize_excel_coordinate(value)


class ExcelDefinedNameDetail(SdkModel):
    """One complete workbook defined-name declaration."""

    part_name: NonEmptyString
    path: NonEmptyString
    name: NonEmptyString
    definition: str
    local_sheet_id: int | None = Field(default=None, ge=0)
    scope_sheet_name: WorksheetName | None = None
    hidden: bool
    function: bool
    vb_procedure: bool
    xlm: bool
    function_group_id: int | None = Field(default=None, ge=0)
    shortcut_key: str | None = None
    publish_to_server: bool
    workbook_parameter: bool
    attributes: tuple[ExcelSourceAttribute, ...] = ()

    @model_validator(mode="after")
    def validate_scope(self) -> Self:
        """Bind a local sheet index to its resolved source sheet name."""
        if (self.local_sheet_id is None) != (self.scope_sheet_name is None):
            msg = "defined-name sheet scope is inconsistent"
            raise ValueError(msg)
        return self


class ExcelHyperlinkDetail(SdkModel):
    """One worksheet hyperlink with an internal location or redacted target."""

    sheet_name: WorksheetName
    part_name: NonEmptyString
    path: NonEmptyString
    cell_range: NonEmptyString
    relationship_id: str | None = None
    target_part: str | None = None
    external_target_sha256: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )
    location: str | None = None
    display: str | None = None
    tooltip: str | None = None
    attributes: tuple[ExcelSourceAttribute, ...] = ()

    @model_validator(mode="after")
    def validate_target(self) -> Self:
        """Require one coherent location or relationship target."""
        if self.target_part is not None and self.external_target_sha256 is not None:
            msg = "hyperlink cannot have internal and external targets"
            raise ValueError(msg)
        relationship_target = (
            self.target_part is not None or self.external_target_sha256 is not None
        )
        if self.relationship_id is None and relationship_target:
            msg = "hyperlink target requires a relationship identifier"
            raise ValueError(msg)
        if self.relationship_id is not None and not relationship_target:
            msg = "hyperlink relationship requires one resolved target"
            raise ValueError(msg)
        if self.relationship_id is None and not self.location:
            msg = "hyperlink requires a location or relationship target"
            raise ValueError(msg)
        return self


class ExcelTableColumnDetail(SdkModel):
    """One declared table column and its formula or totals behavior."""

    column_id: int = Field(gt=0)
    name: str
    unique_name: str | None = None
    totals_row_label: str | None = None
    totals_row_function: str | None = None
    calculated_column_formula: str | None = None
    totals_row_formula: str | None = None
    data_cell_style: str | None = None
    header_row_cell_style: str | None = None
    totals_row_cell_style: str | None = None
    attributes: tuple[ExcelSourceAttribute, ...] = ()


class ExcelTableDetail(SdkModel):
    """One relationship-bound worksheet table with columns and style facts."""

    sheet_names: tuple[WorksheetName, ...]
    source_relationships: tuple[ExcelSourceRelationshipReference, ...] = ()
    part_name: NonEmptyString
    path: NonEmptyString
    table_id: int = Field(gt=0)
    name: NonEmptyString
    display_name: NonEmptyString
    cell_range: NonEmptyString
    header_row_count: int = Field(ge=0)
    totals_row_count: int = Field(ge=0)
    totals_row_shown: bool
    columns: tuple[ExcelTableColumnDetail, ...] = ()
    style_name: str | None = None
    show_first_column: bool
    show_last_column: bool
    show_row_stripes: bool
    show_column_stripes: bool
    attributes: tuple[ExcelSourceAttribute, ...] = ()
    properties: tuple[ExcelSourceProperty, ...] = ()

    @model_validator(mode="after")
    def validate_columns(self) -> Self:
        """Require unique positive table-column source identities."""
        identifiers = [item.column_id for item in self.columns]
        if len(identifiers) != len(set(identifiers)):
            msg = "table column identifiers must be unique"
            raise ValueError(msg)
        return self


class ExcelDataValidationDetail(SdkModel):
    """One complete worksheet data-validation rule and its target ranges."""

    sheet_name: WorksheetName
    part_name: NonEmptyString
    path: NonEmptyString
    namespace: str | None = None
    cell_ranges: tuple[NonEmptyString, ...]
    validation_type: str | None = None
    operator: str | None = None
    error_style: str | None = None
    ime_mode: str | None = None
    allow_blank: bool
    show_drop_down: bool
    show_input_message: bool
    show_error_message: bool
    error_title: str | None = None
    error: str | None = None
    prompt_title: str | None = None
    prompt: str | None = None
    formulas: tuple[str, ...] = ()
    attributes: tuple[ExcelSourceAttribute, ...] = ()
    properties: tuple[ExcelSourceProperty, ...] = ()


class ExcelConditionalFormattingRuleDetail(SdkModel):
    """One conditional-formatting rule with its ordered structured payload."""

    rule_type: str | None = None
    priority: int | None = Field(default=None, ge=0)
    differential_style_id: int | None = Field(default=None, ge=0)
    stop_if_true: bool
    operator: str | None = None
    text: str | None = None
    time_period: str | None = None
    rank: int | None = Field(default=None, ge=0)
    percent: bool
    bottom: bool
    above_average: bool | None = None
    equal_average: bool
    standard_deviations: int | None = None
    formulas: tuple[str, ...] = ()
    attributes: tuple[ExcelSourceAttribute, ...] = ()
    properties: tuple[ExcelSourceProperty, ...] = ()


class ExcelConditionalFormattingDetail(SdkModel):
    """One conditional-formatting block and every declared rule."""

    sheet_name: WorksheetName
    part_name: NonEmptyString
    path: NonEmptyString
    cell_ranges: tuple[NonEmptyString, ...]
    pivot: bool
    rules: tuple[ExcelConditionalFormattingRuleDetail, ...]
    attributes: tuple[ExcelSourceAttribute, ...] = ()


class ExcelAutoFilterDetail(SdkModel):
    """One worksheet or table auto-filter including filters and sort state."""

    sheet_names: tuple[WorksheetName, ...]
    part_name: NonEmptyString
    path: NonEmptyString
    cell_range: str | None = None
    source_kind: Literal["worksheet", "table"]
    attributes: tuple[ExcelSourceAttribute, ...] = ()
    properties: tuple[ExcelSourceProperty, ...] = ()


class ExcelDrawingMarkerDetail(SdkModel):
    """One DrawingML anchor marker in zero-based sheet coordinates."""

    column: int = Field(ge=0)
    column_offset: int = Field(ge=0)
    row: int = Field(ge=0)
    row_offset: int = Field(ge=0)


class ExcelDrawingDetail(SdkModel):
    """One worksheet or Chartsheet drawing anchor and its related object."""

    sheet_names: tuple[WorksheetName, ...]
    source_relationships: tuple[ExcelSourceRelationshipReference, ...] = ()
    part_name: NonEmptyString
    path: NonEmptyString
    anchor_type: Literal["one_cell", "two_cell", "absolute"]
    from_marker: ExcelDrawingMarkerDetail | None = None
    to_marker: ExcelDrawingMarkerDetail | None = None
    position_x: int | None = Field(default=None, ge=0)
    position_y: int | None = Field(default=None, ge=0)
    extent_cx: int | None = Field(default=None, ge=0)
    extent_cy: int | None = Field(default=None, ge=0)
    object_type: NonEmptyString
    object_name: str | None = None
    object_description: str | None = None
    relationship_id: str | None = None
    target_part: str | None = None
    external_target_sha256: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )
    target_content_type: str | None = None
    target_sha256: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    attributes: tuple[ExcelSourceAttribute, ...] = ()
    properties: tuple[ExcelSourceProperty, ...] = ()

    @model_validator(mode="after")
    def validate_target(self) -> Self:
        """Keep relationship identity and internal/external targets coherent."""
        if self.anchor_type == "one_cell" and (
            self.from_marker is None
            or self.to_marker is not None
            or self.position_x is not None
            or self.position_y is not None
            or self.extent_cx is None
            or self.extent_cy is None
        ):
            msg = "one-cell drawing anchor geometry is incomplete"
            raise ValueError(msg)
        if self.anchor_type == "two_cell" and (
            self.from_marker is None
            or self.to_marker is None
            or self.position_x is not None
            or self.position_y is not None
        ):
            msg = "two-cell drawing anchor geometry is incomplete"
            raise ValueError(msg)
        if self.anchor_type == "absolute" and (
            self.from_marker is not None
            or self.to_marker is not None
            or self.position_x is None
            or self.position_y is None
            or self.extent_cx is None
            or self.extent_cy is None
        ):
            msg = "absolute drawing anchor geometry is incomplete"
            raise ValueError(msg)
        internal_values = (
            self.target_part,
            self.target_content_type,
            self.target_sha256,
        )
        has_internal = any(value is not None for value in internal_values)
        has_external = self.external_target_sha256 is not None
        if has_internal and not all(value is not None for value in internal_values):
            msg = "drawing internal target facts must be complete"
            raise ValueError(msg)
        if has_internal and has_external:
            msg = "drawing cannot have internal and external targets"
            raise ValueError(msg)
        if self.relationship_id is None and (has_internal or has_external):
            msg = "drawing target requires a relationship identifier"
            raise ValueError(msg)
        if self.relationship_id is not None and not (has_internal or has_external):
            msg = "drawing relationship requires one resolved target"
            raise ValueError(msg)
        return self


class ExcelChartSeriesDetail(SdkModel):
    """One chart series with source formula references and literal values."""

    index: int | None = Field(default=None, ge=0)
    order: int | None = Field(default=None, ge=0)
    title_formula: str | None = None
    title_text: str | None = None
    category_formula: str | None = None
    value_formula: str | None = None
    bubble_size_formula: str | None = None
    literal_values: tuple[str, ...] = ()


class ExcelChartDetail(SdkModel):
    """Selected deterministic chart facts for one chart package part."""

    sheet_names: tuple[WorksheetName, ...]
    source_relationships: tuple[ExcelSourceRelationshipReference, ...] = ()
    part_name: NonEmptyString
    chart_types: tuple[NonEmptyString, ...]
    title_text: tuple[str, ...] = ()
    series: tuple[ExcelChartSeriesDetail, ...] = ()
    axis_ids: tuple[str, ...] = ()
    attributes: tuple[ExcelSourceAttribute, ...] = ()
    properties: tuple[ExcelSourceProperty, ...] = ()


class ExcelViewDetail(SdkModel):
    """One workbook/worksheet view, pane, or selection declaration."""

    sheet_name: WorksheetName | None = None
    part_name: NonEmptyString
    path: NonEmptyString
    kind: NonEmptyString
    attributes: tuple[ExcelSourceAttribute, ...] = ()


class ExcelPagePrintDetail(SdkModel):
    """One worksheet page, print, header/footer, or break declaration."""

    sheet_name: WorksheetName
    part_name: NonEmptyString
    path: NonEmptyString
    kind: NonEmptyString
    attributes: tuple[ExcelSourceAttribute, ...] = ()
    text: str | None = None


class ExcelWorkbookPropertyDetail(SdkModel):
    """One workbook property or calculation declaration."""

    part_name: NonEmptyString
    path: NonEmptyString
    kind: NonEmptyString
    namespace: str | None = None
    attributes: tuple[ExcelSourceAttribute, ...] = ()
    text: str | None = None


class ExcelWorksheetPropertyDetail(SdkModel):
    """One worksheet or Chartsheet property or structural declaration."""

    sheet_name: WorksheetName
    part_name: NonEmptyString
    path: NonEmptyString
    kind: NonEmptyString
    namespace: str | None = None
    attributes: tuple[ExcelSourceAttribute, ...] = ()
    text: str | None = None


class ExcelAdditionalSourceDetail(SdkModel):
    """One ordered XML source occurrence outside a typed business projection."""

    category: Literal["custom_xml", "extension", "other", "source_structure"]
    sheet_names: tuple[WorksheetName, ...] = ()
    part_name: NonEmptyString
    path: NonEmptyString
    parent_path: str | None = None
    document_order_key: tuple[int, ...]
    node_type: Literal[
        "element",
        "text",
        "tail",
        "comment",
        "processing_instruction",
        "namespace_declaration",
    ]
    namespace: str | None = None
    name: NonEmptyString
    attributes: tuple[ExcelSourceAttribute, ...] = ()
    text: str | None = None
    declared_prefix: str | None = None
    child_count: int = Field(ge=0)

    @model_validator(mode="after")
    def validate_occurrence(self) -> Self:
        """Keep occurrence-specific fields and reconstructable order coherent."""
        if not self.document_order_key or any(
            value < 0 for value in self.document_order_key
        ):
            msg = "XML source occurrence order is invalid"
            raise ValueError(msg)
        if self.node_type == "namespace_declaration":
            if self.declared_prefix is None or self.attributes or self.text is not None:
                msg = "XML namespace-declaration occurrence is inconsistent"
                raise ValueError(msg)
        elif self.declared_prefix is not None:
            msg = "Only XML namespace declarations retain a declared prefix"
            raise ValueError(msg)
        if self.node_type != "element" and (self.attributes or self.child_count):
            msg = "Only XML element occurrences retain attributes or children"
            raise ValueError(msg)
        if self.node_type in {"element", "namespace_declaration"}:
            if self.text is not None:
                msg = "XML structural occurrences cannot retain character data"
                raise ValueError(msg)
        elif self.text is None:
            msg = "XML character occurrences require their exact decoded text"
            raise ValueError(msg)
        return self


def _detail_metrics(value: object) -> tuple[int, int]:
    """Count every emitted detail model and every emitted string occurrence."""
    if isinstance(value, SdkModel):
        records = (
            1 + len(value.document_order_key)
            if isinstance(value, ExcelAdditionalSourceDetail)
            else 1
        )
        text_characters = 0
        for field_name in type(value).model_fields:
            if (
                isinstance(value, ExcelAdditionalSourceDetail)
                and field_name == "document_order_key"
            ):
                continue
            child_records, child_text = _detail_metrics(getattr(value, field_name))
            records += child_records
            text_characters += child_text
        return records, text_characters
    if isinstance(value, (tuple, list)):
        records = 0
        text_characters = 0
        for item in value:
            child_records, child_text = _detail_metrics(item)
            records += child_records
            text_characters += child_text
        return records, text_characters
    if isinstance(value, str):
        return 0, len(value)
    return 0, 0


class WorkbookSemanticDetails(SdkModel):
    """Bounded source-detail view for declared OOXML workbook record families."""

    contract_version: Literal["excel-semantic-details/v1"] = "excel-semantic-details/v1"
    file: FileDescriptor
    package_parts: tuple[ExcelPackagePartDetail, ...]
    relationships: tuple[ExcelRelationshipDetail, ...]
    styles: tuple[ExcelStyleDetail, ...]
    physical_cells: tuple[ExcelPhysicalCellDetail, ...]
    comments: tuple[ExcelCommentDetail, ...]
    defined_names: tuple[ExcelDefinedNameDetail, ...]
    hyperlinks: tuple[ExcelHyperlinkDetail, ...]
    tables: tuple[ExcelTableDetail, ...]
    data_validations: tuple[ExcelDataValidationDetail, ...]
    conditional_formatting: tuple[ExcelConditionalFormattingDetail, ...]
    auto_filters: tuple[ExcelAutoFilterDetail, ...]
    drawings: tuple[ExcelDrawingDetail, ...]
    charts: tuple[ExcelChartDetail, ...]
    rows: tuple[ExcelRowDetail, ...]
    columns: tuple[ExcelColumnDetail, ...]
    views: tuple[ExcelViewDetail, ...]
    page_print: tuple[ExcelPagePrintDetail, ...]
    workbook_properties: tuple[ExcelWorkbookPropertyDetail, ...]
    worksheet_properties: tuple[ExcelWorksheetPropertyDetail, ...]
    additional_source: tuple[ExcelAdditionalSourceDetail, ...]
    record_count: int = Field(ge=0)
    text_character_count: int = Field(ge=0)
    complete: Literal[True] = Field(
        default=True,
        description=(
            "All record families declared by this contract were consumed without "
            "truncation; this is not a claim of complete OOXML semantics."
        ),
    )

    @model_validator(mode="after")
    def validate_record_count(self) -> Self:  # noqa: C901, PLR0912, PLR0915
        """Bind completion to every returned record family."""
        collections = (
            self.package_parts,
            self.relationships,
            self.styles,
            self.physical_cells,
            self.comments,
            self.defined_names,
            self.hyperlinks,
            self.tables,
            self.data_validations,
            self.conditional_formatting,
            self.auto_filters,
            self.drawings,
            self.charts,
            self.rows,
            self.columns,
            self.views,
            self.page_print,
            self.workbook_properties,
            self.worksheet_properties,
            self.additional_source,
        )
        calculated_records, calculated_text = _detail_metrics(collections)
        if self.record_count != calculated_records:
            msg = "semantic detail record_count must match returned records"
            raise ValueError(msg)
        if self.text_character_count != calculated_text:
            msg = "semantic detail text_character_count must match returned strings"
            raise ValueError(msg)
        part_names = [item.part_name for item in self.package_parts]
        if len(part_names) != len(set(part_names)):
            msg = "semantic detail package parts must be unique"
            raise ValueError(msg)
        part_map = {item.part_name: item for item in self.package_parts}
        if any(
            item.kind != _part_kind(item.part_name, item.content_type)
            for item in self.package_parts
        ):
            msg = "semantic package-part kind is inconsistent with its content type"
            raise ValueError(msg)
        relationship_keys = [
            (item.source_part, item.relationship_id) for item in self.relationships
        ]
        if len(relationship_keys) != len(set(relationship_keys)):
            msg = "semantic detail relationships must be unique per source"
            raise ValueError(msg)
        for relationship in self.relationships:
            relationship_part = part_map.get(relationship.relationship_part)
            if relationship_part is None or relationship_part.kind != "relationship":
                msg = "semantic detail relationship source member is missing"
                raise ValueError(msg)
            if relationship.source_part and relationship.source_part not in part_map:
                msg = "semantic detail relationship source is missing"
                raise ValueError(msg)
            if (
                relationship.target_part is not None
                and relationship.target_part not in part_map
            ):
                msg = "semantic detail relationship target is missing"
                raise ValueError(msg)

        keyed_collections: tuple[tuple[object, ...], ...] = (
            tuple((item.part_name, item.component, item.index) for item in self.styles),
            tuple((item.part_name, item.coordinate) for item in self.physical_cells),
            tuple((item.part_name, item.coordinate) for item in self.comments),
            tuple(
                (item.name.casefold(), item.local_sheet_id)
                for item in self.defined_names
            ),
            tuple((item.part_name, item.path) for item in self.hyperlinks),
            tuple(item.part_name for item in self.tables),
            tuple((item.part_name, item.path) for item in self.data_validations),
            tuple((item.part_name, item.path) for item in self.conditional_formatting),
            tuple(
                (item.part_name, item.path, item.source_kind)
                for item in self.auto_filters
            ),
            tuple((item.part_name, item.path) for item in self.drawings),
            tuple(item.part_name for item in self.charts),
            tuple((item.part_name, item.row) for item in self.rows),
            tuple((item.part_name, item.path) for item in self.columns),
            tuple((item.part_name, item.path) for item in self.views),
            tuple((item.part_name, item.path) for item in self.page_print),
            tuple((item.part_name, item.path) for item in self.workbook_properties),
            tuple((item.part_name, item.path) for item in self.worksheet_properties),
            tuple(
                (item.part_name, item.path, item.category)
                for item in self.additional_source
            ),
        )
        if any(len(keys) != len(set(keys)) for keys in keyed_collections):
            msg = "semantic detail records contain duplicate source identities"
            raise ValueError(msg)
        source_order_keys = [
            (item.part_name, item.document_order_key) for item in self.additional_source
        ]
        if len(source_order_keys) != len(set(source_order_keys)):
            msg = "semantic XML source occurrence order keys must be unique"
            raise ValueError(msg)
        for part_name in {item.part_name for item in self.additional_source}:
            part_keys = [
                item.document_order_key
                for item in self.additional_source
                if item.part_name == part_name
            ]
            if part_keys != sorted(part_keys):
                msg = "semantic XML source occurrences are not in document order"
                raise ValueError(msg)
        property_groups = (
            tuple(item.properties for item in self.styles)
            + tuple(item.properties for item in self.drawings)
            + tuple(item.properties for item in self.charts)
            + tuple(item.properties for item in self.tables)
            + tuple(item.properties for item in self.data_validations)
            + tuple(
                rule.properties
                for item in self.conditional_formatting
                for rule in item.rules
            )
            + tuple(item.properties for item in self.auto_filters)
        )
        if any(
            len(properties)
            != len({property_detail.path for property_detail in properties})
            for properties in property_groups
        ):
            msg = "semantic detail nested property paths must be unique"
            raise ValueError(msg)
        detail_parts = {item.part_name for items in collections[2:-1] for item in items}
        if any(
            part_name not in part_map
            or part_map[part_name].semantic_representation != "typed"
            for part_name in detail_parts
        ):
            msg = "semantic detail typed record part classification is invalid"
            raise ValueError(msg)
        if any(
            item.part_name not in part_map
            or part_map[item.part_name].semantic_representation == "identity_only"
            for item in self.additional_source
        ):
            msg = "semantic additional-source part classification is invalid"
            raise ValueError(msg)
        relationship_map = {
            (item.source_part, item.relationship_id): item
            for item in self.relationships
        }
        projections = tuple(
            (
                item.part_name,
                item.relationship_id,
                item.target_part,
                item.external_target_sha256,
            )
            for item in self.hyperlinks
        ) + tuple(
            (
                item.part_name,
                item.relationship_id,
                item.target_part,
                item.external_target_sha256,
            )
            for item in self.drawings
        )
        for source_part, relationship_id, target_part, external_hash in projections:
            if relationship_id is None:
                continue
            projected_relationship = relationship_map.get(
                (source_part, relationship_id)
            )
            if projected_relationship is None or (
                target_part != projected_relationship.target_part
                or external_hash != projected_relationship.external_target_sha256
            ):
                msg = "semantic detail relationship projection is inconsistent"
                raise ValueError(msg)
        attached_collections = (
            (self.tables, "table"),
            (self.drawings, "drawing"),
            (self.charts, "chart"),
        )
        attachment_source_types = {
            "table": _ROLE_CONTENT_TYPES["worksheet"],
            "drawing": (
                _ROLE_CONTENT_TYPES["worksheet"] | _ROLE_CONTENT_TYPES["chartsheet"]
            ),
            "chart": _ROLE_CONTENT_TYPES["drawing"],
        }
        for items, expected_role in attached_collections:
            for item in items:
                if len(item.sheet_names) != len(set(item.sheet_names)):
                    msg = "semantic object sheet associations are duplicated"
                    raise ValueError(msg)
                references = [
                    (reference.source_part, reference.relationship_id)
                    for reference in item.source_relationships
                ]
                if len(references) != len(set(references)):
                    msg = "semantic object attachment references are duplicated"
                    raise ValueError(msg)
                part = part_map[item.part_name]
                if (part.content_type or "").casefold() not in {
                    value.casefold() for value in _ROLE_CONTENT_TYPES[expected_role]
                }:
                    msg = "semantic object content type is inconsistent"
                    raise ValueError(msg)
                for reference in item.source_relationships:
                    attached_relationship = relationship_map.get(
                        (reference.source_part, reference.relationship_id)
                    )
                    source_part_detail = part_map.get(reference.source_part)
                    if (
                        attached_relationship is None
                        or attached_relationship.external
                        or attached_relationship.target_part != item.part_name
                        or _relationship_role(attached_relationship.relationship_type)
                        != expected_role
                        or source_part_detail is None
                        or (source_part_detail.content_type or "").casefold()
                        not in {
                            value.casefold()
                            for value in attachment_source_types[expected_role]
                        }
                    ):
                        msg = "semantic object attachment relationship is inconsistent"
                        raise ValueError(msg)
        for drawing in self.drawings:
            if drawing.target_part is None:
                continue
            target = part_map[drawing.target_part]
            if (
                drawing.target_content_type != target.content_type
                or drawing.target_sha256 != target.sha256
            ):
                msg = "semantic drawing target identity is inconsistent"
                raise ValueError(msg)
        table_ids = [item.table_id for item in self.tables]
        if len(table_ids) != len(set(table_ids)):
            msg = "semantic detail table identifiers must be unique"
            raise ValueError(msg)
        return self


class _Budget:
    __slots__ = (
        "depth_limit",
        "record_limit",
        "records",
        "text_characters",
        "text_limit",
    )

    def __init__(self, limits: ExcelPackageLimits | None) -> None:
        self.record_limit = (
            _DEFAULT_DETAIL_RECORD_LIMIT
            if limits is None
            else limits.semantic_detail_records
        )
        self.text_limit = (
            _DEFAULT_DETAIL_TEXT_LIMIT
            if limits is None
            else limits.semantic_detail_text_characters
        )
        self.depth_limit = (
            _DEFAULT_DETAIL_XML_DEPTH_LIMIT
            if limits is None
            else limits.semantic_detail_xml_depth
        )
        self.records = 0
        self.text_characters = 0

    def ensure_source_capacity(
        self,
        *,
        text: Iterable[str | None] = (),
        attributes: Mapping[str, str] | None = None,
    ) -> None:
        records = 1 + (0 if attributes is None else len(attributes))
        text_characters = sum(len(value) for value in text if value is not None)
        if attributes is not None:
            text_characters += sum(
                len(_namespace(name) or "") + len(_local_name(name)) + len(value)
                for name, value in attributes.items()
            )
        self.ensure_capacity(records=records, text_characters=text_characters)

    def commit(self, detail: SdkModel) -> None:
        """Consume the exact records and strings retained by one public detail."""
        records, text_characters = _detail_metrics(detail)
        self.ensure_capacity(records=records, text_characters=text_characters)
        self.records += records
        self.text_characters += text_characters

    def ensure_capacity(self, *, records: int, text_characters: int) -> None:
        """Reject a conservative allocation estimate without consuming it."""
        projected_records = self.records + records
        if projected_records > self.record_limit:
            raise ExcelPackageLimitError(
                limit_name="semantic_detail_records",
                observed=projected_records,
                maximum=self.record_limit,
            )
        projected_text = self.text_characters + text_characters
        if projected_text > self.text_limit:
            raise ExcelPackageLimitError(
                limit_name="semantic_detail_text_characters",
                observed=projected_text,
                maximum=self.text_limit,
            )

    def ensure_depth(self, depth: int) -> None:
        """Reject excessive XML nesting before constructing a full source path."""
        if depth > self.depth_limit:
            raise ExcelPackageLimitError(
                limit_name="semantic_detail_xml_depth",
                observed=depth,
                maximum=self.depth_limit,
            )


@dataclass(slots=True)
class _Frame:
    element: Element
    name: str
    namespace: str | None
    path: str
    child_counts: dict[str, int] = field(default_factory=dict)
    retain: bool = False


def _preflight_xml_depth(
    package: _SafePackage,
    part_name: str,
    *,
    budget: _Budget,
) -> None:
    """Reject excessive nesting before a part is materialized as an XML tree."""
    depth = 0
    elements: list[Element] = []
    with package.open_xml_stream(part_name, declared_xml=True) as stream:
        for event, element in iterparse(stream, events=("start", "end")):  # noqa: S314
            if event == "start":
                budget.ensure_depth(depth + 1)
                depth += 1
                elements.append(element)
            else:
                depth -= 1
                elements.pop()
                element.clear()
                if elements:
                    elements[-1].remove(element)


@dataclass(frozen=True, slots=True)
class _PartRoles:
    workbook: frozenset[str]
    worksheets: frozenset[str]
    chartsheets: frozenset[str]
    styles: frozenset[str]
    comments: frozenset[str]
    drawings: frozenset[str]
    charts: frozenset[str]
    tables: frozenset[str]


def _frames_path_is(
    frames: list[_Frame],
    names: tuple[str, ...],
    namespaces: frozenset[str] = _SPREADSHEET_NAMESPACES,
) -> bool:
    """Match an exact typed path with one consistent allowed namespace."""
    if len(frames) != len(names) or tuple(frame.name for frame in frames) != names:
        return False
    namespace = frames[0].namespace
    return namespace in namespaces and all(
        frame.namespace == namespace for frame in frames
    )


def _element_path_is(
    element: Element,
    parents: list[_Frame],
    names: tuple[str, ...],
    namespaces: frozenset[str] = _SPREADSHEET_NAMESPACES,
) -> bool:
    if len(parents) + 1 != len(names):
        return False
    if (*tuple(frame.name for frame in parents), _local_name(element.tag)) != names:
        return False
    namespace = _namespace(element.tag)
    return namespace in namespaces and all(
        frame.namespace == namespace for frame in parents
    )


def _path_has_suffix(
    frames: list[_Frame],
    suffixes: frozenset[tuple[str, ...]],
) -> bool:
    if not frames or frames[0].name not in {"worksheet", "chartsheet"}:
        return False
    namespace = frames[0].namespace
    if namespace not in _SPREADSHEET_NAMESPACES or any(
        frame.namespace != namespace for frame in frames
    ):
        return False
    return tuple(frame.name for frame in frames[1:]) in suffixes


def _part_role(part_name: str, roles: _PartRoles) -> str | None:
    for role in (
        "workbook",
        "worksheets",
        "chartsheets",
        "styles",
        "comments",
        "drawings",
        "charts",
        "tables",
    ):
        if part_name in getattr(roles, role):
            return role
    return None


def _validate_role_root(
    element: Element,
    *,
    part_name: str,
    roles: _PartRoles,
) -> None:
    """Bind each typed package role to its exact OOXML root and namespace."""
    role = _part_role(part_name, roles)
    if role is None:
        return
    expected: dict[str, tuple[str, frozenset[str]]] = {
        "workbook": ("workbook", _SPREADSHEET_NAMESPACES),
        "worksheets": ("worksheet", _SPREADSHEET_NAMESPACES),
        "chartsheets": ("chartsheet", _SPREADSHEET_NAMESPACES),
        "styles": ("styleSheet", _SPREADSHEET_NAMESPACES),
        "comments": ("comments", _SPREADSHEET_NAMESPACES),
        "drawings": ("wsDr", _DRAWING_NAMESPACES),
        "charts": ("chartSpace", _CHART_NAMESPACES),
        "tables": ("table", _SPREADSHEET_NAMESPACES),
    }
    expected_name, namespaces = expected[role]
    if (
        _local_name(element.tag) != expected_name
        or _namespace(element.tag) not in namespaces
    ):
        msg = "Workbook semantic part root or namespace is invalid"
        raise ValueError(msg)


def _validate_typed_position(
    element: Element,
    *,
    parents: list[_Frame],
    role: str | None,
) -> None:
    """Reject core-looking records outside their declared typed parent chain."""
    if role is None or any(frame.name in {"ext", "extLst"} for frame in parents):
        return
    names = (*tuple(frame.name for frame in parents), _local_name(element.tag))
    namespace = _namespace(element.tag)
    allowed_paths: frozenset[tuple[str, ...]] | None
    candidate_names: frozenset[str] | None
    if role == "styles":
        catalog_parents = {path[-2] for path in _STYLE_PATH_COMPONENTS}
        if not parents or parents[-1].name not in catalog_parents:
            return
        allowed_paths = frozenset(_STYLE_PATH_COMPONENTS)
        candidate_names = frozenset(path[-1] for path in allowed_paths)
    else:
        allowed_paths = _TYPED_PATHS_BY_ROLE.get(role)
        candidate_names = _TYPED_NAMES_BY_ROLE.get(role)
    if allowed_paths is None or candidate_names is None:
        return
    if names[-1] not in candidate_names:
        return
    namespaces = _DRAWING_NAMESPACES if role == "drawings" else _SPREADSHEET_NAMESPACES
    if (
        names not in allowed_paths
        or namespace not in namespaces
        or any(frame.namespace != namespace for frame in parents)
    ):
        msg = "Workbook semantic record namespace or parent is invalid"
        raise ValueError(msg)


@dataclass(slots=True)
class _Collected:
    package_parts: list[ExcelPackagePartDetail] = field(default_factory=list)
    relationships: list[ExcelRelationshipDetail] = field(default_factory=list)
    styles: list[ExcelStyleDetail] = field(default_factory=list)
    physical_cells: list[ExcelPhysicalCellDetail] = field(default_factory=list)
    comments: list[ExcelCommentDetail] = field(default_factory=list)
    defined_names: list[ExcelDefinedNameDetail] = field(default_factory=list)
    hyperlinks: list[ExcelHyperlinkDetail] = field(default_factory=list)
    tables: list[ExcelTableDetail] = field(default_factory=list)
    data_validations: list[ExcelDataValidationDetail] = field(default_factory=list)
    conditional_formatting: list[ExcelConditionalFormattingDetail] = field(
        default_factory=list
    )
    auto_filters: list[ExcelAutoFilterDetail] = field(default_factory=list)
    drawings: list[ExcelDrawingDetail] = field(default_factory=list)
    charts: list[ExcelChartDetail] = field(default_factory=list)
    rows: list[ExcelRowDetail] = field(default_factory=list)
    columns: list[ExcelColumnDetail] = field(default_factory=list)
    views: list[ExcelViewDetail] = field(default_factory=list)
    page_print: list[ExcelPagePrintDetail] = field(default_factory=list)
    workbook_properties: list[ExcelWorkbookPropertyDetail] = field(default_factory=list)
    worksheet_properties: list[ExcelWorksheetPropertyDetail] = field(
        default_factory=list
    )
    additional_source: list[ExcelAdditionalSourceDetail] = field(default_factory=list)


def _attributes(element: Element) -> tuple[ExcelSourceAttribute, ...]:
    return tuple(
        ExcelSourceAttribute(
            namespace=_namespace(name),
            name=_local_name(name),
            value=value,
        )
        for name, value in sorted(
            element.attrib.items(),
            key=lambda item: ((_namespace(item[0]) or ""), _local_name(item[0])),
        )
    )


def _properties(
    element: Element,
    root_path: str,
) -> tuple[ExcelSourceProperty, ...]:
    properties: list[ExcelSourceProperty] = []
    pending: list[tuple[Element, str]] = []

    def children(node: Element, path: str) -> list[tuple[Element, str]]:
        counts: dict[str, int] = defaultdict(int)
        result: list[tuple[Element, str]] = []
        for child in node:
            name = _local_name(child.tag)
            counts[name] += 1
            child_path = f"{path}/{name}[{counts[name]}]"
            result.append((child, child_path))
        return result

    pending.extend(reversed(children(element, root_path)))
    while pending:
        child, child_path = pending.pop()
        name = _local_name(child.tag)
        properties.append(
            ExcelSourceProperty(
                path=child_path,
                namespace=_namespace(child.tag),
                name=name,
                attributes=_attributes(child),
                text=child.text,
            )
        )
        pending.extend(reversed(children(child, child_path)))
    return tuple(properties)


def _preflight_retained_part(
    package: _SafePackage,
    *,
    part: ExcelPackagePartDetail,
    budget: _Budget,
    record_factor: int,
) -> None:
    """Bound a part before a later full-tree parse retains all XML nodes."""
    # The byte size is a conservative lower bound for a single large text or
    # attribute value. Check it before even a streaming parser allocates that
    # value, then account for paths and duplicate typed projections as nodes
    # become available.
    budget.ensure_capacity(records=1, text_characters=part.size_bytes)
    stack: list[_Frame] = []
    source_record_count = 0
    property_text_characters = 0
    with package.open_xml_stream(part.part_name, declared_xml=True) as stream:
        for event, element in iterparse(stream, events=("start", "end")):  # noqa: S314
            if event == "start":
                budget.ensure_depth(len(stack) + 1)
                path = _path_for_start(stack, element)
                stack.append(
                    _Frame(
                        element=element,
                        name=_local_name(element.tag),
                        namespace=_namespace(element.tag),
                        path=path,
                    )
                )
                continue
            frame = stack.pop()
            source_record_count += 1 + len(element.attrib)
            property_text_characters += (
                len(frame.path)
                + len(frame.namespace or "")
                + len(frame.name)
                + len(element.text or "")
                + sum(
                    len(_namespace(name) or "") + len(_local_name(name)) + len(value)
                    for name, value in element.attrib.items()
                )
            )
            budget.ensure_capacity(
                records=record_factor * source_record_count + 2,
                text_characters=record_factor
                * (part.size_bytes + property_text_characters + len(part.part_name)),
            )
            element.clear()
            if stack:
                stack[-1].element.remove(element)


def _text_values(
    element: Element,
    name: str,
    *,
    namespace: str | None = None,
) -> tuple[str, ...]:
    return tuple(
        item.text or ""
        for item in element.iter()
        if _local_name(item.tag) == name
        and (namespace is None or _namespace(item.tag) == namespace)
    )


def _first_text(
    element: Element,
    name: str,
    *,
    namespace: str | None = None,
) -> str | None:
    item = _direct_child(element, name, namespace=namespace)
    return None if item is None else item.text


def _direct_child(
    element: Element,
    name: str,
    *,
    namespace: str | None = None,
) -> Element | None:
    matching = [
        child
        for child in element
        if _local_name(child.tag) == name
        and (namespace is None or _namespace(child.tag) == namespace)
    ]
    if len(matching) > 1:
        msg = "Workbook semantic direct child is duplicated"
        raise ValueError(msg)
    return None if not matching else matching[0]


def _formula_kind(
    element: Element,
) -> Literal["ordinary", "shared", "array", "dynamic_array"]:
    formula_type = element.attrib.get("t")
    if formula_type == "shared":
        return "shared"
    if formula_type == "array":
        return "array"
    if formula_type in {"dataTable", "dynamicArray"}:
        return "dynamic_array"
    if formula_type in {None, "normal"}:
        return "ordinary"
    msg = "Workbook cell formula type is unsupported"
    raise ValueError(msg)


def _coordinate(
    element: Element,
    *,
    current_row: int,
    previous_column: int,
) -> tuple[str, int]:
    raw = element.attrib.get("r")
    if raw is None:
        column = previous_column + 1
        if column > MAX_EXCEL_COLUMN:
            msg = "Worksheet physical cell is outside Excel bounds"
            raise ValueError(msg)
        return f"{excel_column_letter(column)}{current_row}", column
    coordinate = normalize_excel_coordinate(raw)
    bounds = excel_range_bounds(coordinate)
    if bounds.min_row != current_row or bounds.min_column <= previous_column:
        msg = "Worksheet physical cells are not in deterministic row order"
        raise ValueError(msg)
    return coordinate, bounds.min_column


def _column_style(
    column: int,
    columns: list[ExcelColumnDetail],
) -> int | None:
    return next(
        (
            item.style_id
            for item in reversed(columns)
            if item.min_column <= column <= item.max_column
            and item.style_id is not None
        ),
        None,
    )


def _physical_cell(  # noqa: PLR0913 - source context stays explicit.
    element: Element,
    *,
    sheet_name: str,
    part_name: str,
    path: str,
    coordinate: str,
    row_style_id: int | None,
    columns: list[ExcelColumnDetail],
) -> ExcelPhysicalCellDetail:
    namespace = _namespace(element.tag)
    direct_style_id = _optional_int(element.attrib.get("s"))
    column = excel_range_bounds(coordinate).min_column
    column_style_id = _column_style(column, columns)
    source: Literal["cell", "row", "column", "default"]
    if direct_style_id is not None:
        effective_style_id, source = direct_style_id, "cell"
    elif row_style_id is not None:
        effective_style_id, source = row_style_id, "row"
    elif column_style_id is not None:
        effective_style_id, source = column_style_id, "column"
    else:
        effective_style_id, source = 0, "default"
    formula = _direct_child(element, "f", namespace=namespace)
    cached = _direct_child(element, "v", namespace=namespace)
    inline = _direct_child(element, "is", namespace=namespace)
    inline_text = (
        None
        if inline is None
        else _visible_text(
            inline,
            container="is",
            label="Workbook inline string",
        ).value
    )
    return ExcelPhysicalCellDetail(
        sheet_name=sheet_name,
        part_name=part_name,
        path=path,
        namespace=namespace,
        coordinate=coordinate,
        raw_type=element.attrib.get("t"),
        direct_style_id=direct_style_id,
        effective_style_id=effective_style_id,
        style_source=source,
        formula_present=formula is not None,
        formula_kind=None if formula is None else _formula_kind(formula),
        formula_text=None if formula is None else formula.text,
        formula_shared_index=(
            None if formula is None else _optional_int(formula.attrib.get("si"))
        ),
        formula_range=None if formula is None else formula.attrib.get("ref"),
        formula_attributes=() if formula is None else _attributes(formula),
        cached_value_present=cached is not None,
        raw_cached_value=None if cached is None else cached.text,
        inline_string_present=inline is not None,
        inline_text=inline_text,
        attributes=_attributes(element),
    )


def _style_component(
    element: Element,
    parents: list[_Frame],
) -> StyleComponent | None:
    return next(
        (
            component
            for path, component in _STYLE_PATH_COMPONENTS.items()
            if _element_path_is(element, parents, path)
        ),
        None,
    )


def _marker(element: Element, name: str) -> ExcelDrawingMarkerDetail | None:
    namespace = _namespace(element.tag)
    marker = _direct_child(element, name, namespace=namespace)
    if marker is None:
        return None
    required = {"col", "colOff", "row", "rowOff"}
    relevant = [child for child in marker if _local_name(child.tag) in required]
    if any(_namespace(child.tag) != namespace for child in relevant):
        msg = "Workbook drawing marker child namespace is invalid"
        raise ValueError(msg)
    values = {
        field: [
            child.text
            for child in relevant
            if _local_name(child.tag) == field and child.text is not None
        ]
        for field in required
    }
    if any(len(items) != 1 for items in values.values()):
        msg = "Workbook drawing marker is incomplete or duplicated"
        raise ValueError(msg)
    return ExcelDrawingMarkerDetail(
        column=int(values["col"][0]),
        column_offset=int(values["colOff"][0]),
        row=int(values["row"][0]),
        row_offset=int(values["rowOff"][0]),
    )


def _drawing_relationship_id(element: Element) -> str | None:
    values: list[str] = []
    for child in element.iter():
        name = _local_name(child.tag)
        namespace = _namespace(child.tag)
        if (
            (name == "blip" and namespace in _DRAWING_MAIN_NAMESPACES)
            or (name == "chart" and namespace in _CHART_NAMESPACES)
            or (name in {"oleObj", "control"} and namespace in _DRAWING_NAMESPACES)
        ):
            value = _relationship_attribute(child, "embed", "link", "id")
            if value:
                values.append(value)
    if len(values) > 1:
        msg = "Workbook drawing object has multiple relationship targets"
        raise ValueError(msg)
    return None if not values else values[0]


def _chart_elements_for_anchor(anchor: Element) -> tuple[Element, ...]:
    """Return only chart references at the supported DrawingML object path."""
    drawing_namespace = _namespace(anchor.tag)
    graphic_frames = [
        child
        for child in anchor
        if _namespace(child.tag) == drawing_namespace
        and _local_name(child.tag) == "graphicFrame"
    ]
    valid: list[Element] = []
    for graphic_frame in graphic_frames:
        graphics = [
            child
            for child in graphic_frame
            if _namespace(child.tag) in _DRAWING_MAIN_NAMESPACES
            and _local_name(child.tag) == "graphic"
        ]
        if len(graphics) > 1:
            msg = "Workbook drawing graphic container is duplicated"
            raise ValueError(msg)
        if not graphics:
            continue
        main_namespace = _namespace(graphics[0].tag)
        graphic_data = [
            child
            for child in graphics[0]
            if _namespace(child.tag) == main_namespace
            and _local_name(child.tag) == "graphicData"
        ]
        if len(graphic_data) != 1:
            msg = "Workbook drawing graphic-data container is incomplete or duplicated"
            raise ValueError(msg)
        charts = [
            child
            for child in graphic_data[0]
            if _namespace(child.tag) in _CHART_NAMESPACES
            and _local_name(child.tag) == "chart"
        ]
        if len(charts) > 1:
            msg = "Workbook drawing object has multiple chart targets"
            raise ValueError(msg)
        valid.extend(charts)
    valid_ids = {id(item) for item in valid}
    if any(
        _local_name(item.tag) == "chart"
        and _namespace(item.tag) in _CHART_NAMESPACES
        and id(item) not in valid_ids
        for item in anchor.iter()
    ):
        msg = "Workbook chart reference has an invalid drawing object path"
        raise ValueError(msg)
    return tuple(valid)


def _drawing_detail(  # noqa: C901, PLR0912, PLR0913, PLR0915
    element: Element,
    *,
    part_name: str,
    path: str,
    sheet_names: tuple[str, ...],
    source_relationships: tuple[ExcelSourceRelationshipReference, ...],
    relationships: Mapping[str, ExcelRelationshipDetail],
    parts: Mapping[str, ExcelPackagePartDetail],
) -> ExcelDrawingDetail:
    namespace = _namespace(element.tag)
    direct_names = {
        "from",
        "to",
        "pos",
        "ext",
        "pic",
        "graphicFrame",
        "sp",
        "cxnSp",
        "grpSp",
        "oleObj",
        "control",
        "clientData",
    }
    if any(
        _local_name(child.tag) in direct_names and _namespace(child.tag) != namespace
        for child in element
    ):
        msg = "Workbook drawing child namespace is invalid"
        raise ValueError(msg)
    anchor_name = _local_name(element.tag)
    if anchor_name == "oneCellAnchor":
        anchor_type: Literal["one_cell", "two_cell", "absolute"] = "one_cell"
    elif anchor_name == "twoCellAnchor":
        anchor_type = "two_cell"
    else:
        anchor_type = "absolute"
    extent = _direct_child(element, "ext", namespace=namespace)
    position = _direct_child(element, "pos", namespace=namespace)
    object_elements = [
        child
        for child in element
        if _namespace(child.tag) == namespace
        and _local_name(child.tag)
        in {"pic", "graphicFrame", "sp", "cxnSp", "grpSp", "oleObj", "control"}
    ]
    if len(object_elements) != 1:
        msg = "Workbook drawing anchor must contain exactly one supported object"
        raise ValueError(msg)
    object_element = object_elements[0]
    object_type = _local_name(object_element.tag)
    non_visual_elements = [
        child
        for child in object_element.iter()
        if _namespace(child.tag) == namespace
        and _local_name(child.tag) in {"cNvPr", "nvPr"}
    ]
    if len(non_visual_elements) > 1:
        msg = "Workbook drawing object has ambiguous non-visual properties"
        raise ValueError(msg)
    non_visual = None if not non_visual_elements else non_visual_elements[0]
    relationship_id = _drawing_relationship_id(element)
    relationship = relationships.get(relationship_id or "")
    if relationship_id is not None and relationship is None:
        msg = "Workbook drawing relationship could not be resolved"
        raise ValueError(msg)
    target_part = None if relationship is None else relationship.target_part
    target = None if target_part is None else parts.get(target_part)
    if target_part is not None and target is None:
        msg = "Workbook drawing target part is missing"
        raise ValueError(msg)
    expected_relationship = object_type in {"pic", "oleObj", "control"} or any(
        _local_name(child.tag) == "chart" and _namespace(child.tag) in _CHART_NAMESPACES
        for child in element.iter()
    )
    if expected_relationship and relationship_id is None:
        msg = "Workbook drawing object relationship is missing"
        raise ValueError(msg)
    relationship_role = (
        None
        if relationship is None
        else _relationship_role(relationship.relationship_type)
    )
    if (
        object_type == "pic"
        and relationship is not None
        and relationship_role != "image"
    ):
        msg = "Workbook picture relationship has an invalid type"
        raise ValueError(msg)
    if (
        object_type == "graphicFrame"
        and relationship is not None
        and relationship_role != "chart"
    ):
        msg = "Workbook chart relationship has an invalid type"
        raise ValueError(msg)
    if (
        relationship_role == "image"
        and target is not None
        and not (target.content_type or "").casefold().startswith(_IMAGE_PREFIX)
    ):
        msg = "Workbook image relationship target has an invalid content type"
        raise ValueError(msg)
    if (
        relationship_role == "chart"
        and target is not None
        and (target.content_type or "").casefold()
        not in {item.casefold() for item in _ROLE_CONTENT_TYPES["chart"]}
    ):
        msg = "Workbook chart relationship target has an invalid content type"
        raise ValueError(msg)
    return ExcelDrawingDetail(
        sheet_names=sheet_names,
        source_relationships=source_relationships,
        part_name=part_name,
        path=path,
        anchor_type=anchor_type,
        from_marker=_marker(element, "from"),
        to_marker=_marker(element, "to"),
        position_x=None
        if position is None
        else _optional_int(position.attrib.get("x")),
        position_y=None
        if position is None
        else _optional_int(position.attrib.get("y")),
        extent_cx=None if extent is None else _optional_int(extent.attrib.get("cx")),
        extent_cy=None if extent is None else _optional_int(extent.attrib.get("cy")),
        object_type=object_type,
        object_name=None if non_visual is None else non_visual.attrib.get("name"),
        object_description=None
        if non_visual is None
        else non_visual.attrib.get("descr"),
        relationship_id=relationship_id,
        target_part=target_part,
        external_target_sha256=(
            None if relationship is None else relationship.external_target_sha256
        ),
        target_content_type=None if target is None else target.content_type,
        target_sha256=None if target is None else target.sha256,
        attributes=_attributes(element),
        properties=_properties(element, path),
    )


def _walk_with_names(root: Element) -> Iterable[tuple[Element, tuple[str, ...]]]:
    pending: list[tuple[Element, tuple[str, ...]]] = [(root, (_local_name(root.tag),))]
    while pending:
        element, names = pending.pop()
        yield element, names
        pending.extend(
            (
                child,
                (*names, _local_name(child.tag)),
            )
            for child in reversed(element)
        )


def _validate_chart_positions(
    walked: tuple[tuple[Element, tuple[str, ...]], ...],
    *,
    namespace: str | None,
) -> None:
    for element, names in walked:
        if "ext" in names or "extLst" in names:
            continue
        name = names[-1]
        if name.endswith("Chart") and name not in {"chart", "chartSpace"}:
            valid = len(names) == _CHART_TYPE_PATH_LENGTH and names[:3] == (
                "chartSpace",
                "chart",
                "plotArea",
            )
        elif name == "ser":
            valid = (
                len(names) == _CHART_SERIES_PATH_LENGTH
                and names[:3] == ("chartSpace", "chart", "plotArea")
                and names[-2].endswith("Chart")
            )
        elif name == "title":
            valid = names == ("chartSpace", "chart", "title")
        else:
            continue
        if not valid or _namespace(element.tag) != namespace:
            msg = "Workbook chart record namespace or parent is invalid"
            raise ValueError(msg)


def _chart_series(element: Element) -> ExcelChartSeriesDetail:
    namespace = _namespace(element.tag)
    values: dict[str, str | None] = {}
    for name in ("idx", "order"):
        child = _direct_child(element, name, namespace=namespace)
        values[name] = None if child is None else child.attrib.get("val")
    formulas: dict[str, str] = {}
    for container in element:
        if _namespace(container.tag) != namespace:
            continue
        container_name = _local_name(container.tag)
        if container_name not in {"tx", "cat", "xVal", "val", "yVal", "bubbleSize"}:
            continue
        formula_elements = [
            child
            for child in container.iter()
            if _namespace(child.tag) == namespace and _local_name(child.tag) == "f"
        ]
        if len(formula_elements) > 1:
            msg = "Workbook chart series source formula is duplicated"
            raise ValueError(msg)
        if formula_elements and formula_elements[0].text is not None:
            formulas[container_name] = formula_elements[0].text or ""
    title = _direct_child(element, "tx", namespace=namespace)
    title_text = (
        None
        if title is None
        else "".join(_text_values(title, "v", namespace=namespace)) or None
    )
    return ExcelChartSeriesDetail(
        index=_optional_int(values.get("idx")),
        order=_optional_int(values.get("order")),
        title_formula=formulas.get("tx"),
        title_text=title_text,
        category_formula=formulas.get("cat") or formulas.get("xVal"),
        value_formula=formulas.get("val") or formulas.get("yVal"),
        bubble_size_formula=formulas.get("bubbleSize"),
        literal_values=_text_values(element, "v", namespace=namespace),
    )


def _chart_detail(
    root: Element,
    *,
    part_name: str,
    sheet_names: tuple[str, ...],
    source_relationships: tuple[ExcelSourceRelationshipReference, ...],
) -> ExcelChartDetail:
    namespace = _namespace(root.tag)
    walked = tuple(_walk_with_names(root))
    _validate_chart_positions(walked, namespace=namespace)
    chart_types = tuple(
        names[-1]
        for item, names in walked
        if _namespace(item.tag) == namespace
        and len(names) == _CHART_TYPE_PATH_LENGTH
        and names[:3] == ("chartSpace", "chart", "plotArea")
        and names[-1].endswith("Chart")
    )
    titles = [
        item
        for item, names in walked
        if _namespace(item.tag) == namespace
        and names == ("chartSpace", "chart", "title")
    ]
    if len(titles) > 1:
        msg = "Workbook chart title is duplicated"
        raise ValueError(msg)
    title = None if not titles else titles[0]
    series_elements = tuple(
        item
        for item, names in walked
        if _namespace(item.tag) == namespace
        and len(names) == _CHART_SERIES_PATH_LENGTH
        and names[:3] == ("chartSpace", "chart", "plotArea")
        and names[-1] == "ser"
        and names[-2].endswith("Chart")
    )
    series = tuple(_chart_series(item) for item in series_elements)
    return ExcelChartDetail(
        sheet_names=sheet_names,
        source_relationships=source_relationships,
        part_name=part_name,
        chart_types=chart_types,
        title_text=(
            ()
            if title is None
            else tuple(
                item.text or ""
                for item in title.iter()
                if _local_name(item.tag) == "t"
                and _namespace(item.tag) in _DRAWING_MAIN_NAMESPACES
            )
        ),
        series=series,
        axis_ids=tuple(
            value
            for item, _names in walked
            if _namespace(item.tag) == namespace
            and _local_name(item.tag) == "axId"
            and (value := item.attrib.get("val")) is not None
        ),
        attributes=_attributes(root),
        properties=_properties(root, "/chartSpace[1]"),
    )


def _part_kind(name: str, content_type: str | None) -> PackagePartKind:
    suffix = f".{name.rsplit('.', 1)[-1].casefold()}" if "." in name else ""
    if suffix in _RELATIONSHIP_SUFFIXES:
        return "relationship"
    normalized_content_type = None if content_type is None else content_type.casefold()
    if normalized_content_type is not None and normalized_content_type.startswith(
        _IMAGE_PREFIX
    ):
        return "image"
    if normalized_content_type is not None:
        if normalized_content_type.endswith("+xml") or normalized_content_type in {
            "application/xml",
            "text/xml",
        }:
            return "xml"
        return "binary"
    if suffix in _XML_SUFFIXES:
        return "xml"
    return "binary"


def _content_type(
    name: str,
    content_types: tuple[Mapping[str, str], Mapping[str, str]],
) -> str | None:
    defaults, overrides = content_types
    if name in overrides:
        return overrides[name]
    extension = name.rsplit(".", 1)[-1].casefold() if "." in name else ""
    return defaults.get(extension)


def _member_detail(
    package: _SafePackage,
    *,
    name: str,
    content_types: tuple[Mapping[str, str], Mapping[str, str]],
) -> ExcelPackagePartDetail:
    digest = sha256()
    size = 0
    with package.open_member(name) as stream:
        while chunk := stream.read(_READ_CHUNK_SIZE):
            digest.update(chunk)
            size += len(chunk)
    content_type = _content_type(name, content_types)
    return ExcelPackagePartDetail(
        part_name=name,
        content_type=content_type,
        kind=_part_kind(name, content_type),
        size_bytes=size,
        sha256=digest.hexdigest(),
    )


def _relationship_source(name: str) -> str:
    path = PurePosixPath(name)
    if name == "_rels/.rels":
        return ""
    if path.parent.name != "_rels" or not path.name.endswith(".rels"):
        msg = "Workbook relationship part name is invalid"
        raise ValueError(msg)
    source_name = path.name[: -len(".rels")]
    return posixpath.join(str(path.parent.parent), source_name)


def _relationship_details(  # noqa: C901, PLR0915
    package: _SafePackage,
    *,
    budget: _Budget,
) -> tuple[ExcelRelationshipDetail, ...]:
    output: list[ExcelRelationshipDetail] = []
    for relationship_part in sorted(
        name for name in package.names if name.casefold().endswith(".rels")
    ):
        source_part = _relationship_source(relationship_part)
        seen_ids: set[str] = set()
        depth = 0
        relationship_index = 0
        with package.open_xml_stream(relationship_part) as stream:
            for event, element in iterparse(  # noqa: S314 - DTDs rejected upstream.
                stream,
                events=("start", "end"),
            ):
                if event == "start":
                    budget.ensure_depth(depth + 1)
                    depth += 1
                    if depth == 1 and element.tag != (
                        f"{{{_RELATIONSHIPS_NAMESPACE}}}Relationships"
                    ):
                        msg = "Workbook relationship root or namespace is invalid"
                        raise ValueError(msg)
                    if depth == 2 and element.tag != (  # noqa: PLR2004
                        f"{{{_RELATIONSHIPS_NAMESPACE}}}Relationship"
                    ):
                        msg = "Workbook relationship declaration is invalid"
                        raise ValueError(msg)
                    if depth > 2:  # noqa: PLR2004
                        msg = "Workbook relationship declaration must be empty"
                        raise ValueError(msg)
                    continue

                if depth == 2:  # noqa: PLR2004
                    relationship_index += 1
                    relationship_id = element.attrib.get("Id", "")
                    target = element.attrib.get("Target", "")
                    relationship_type = element.attrib.get("Type", "")
                    target_mode = element.attrib.get("TargetMode")
                    if (
                        not relationship_id
                        or not target
                        or not relationship_type
                        or target_mode not in {None, "Internal", "External"}
                    ):
                        msg = "Workbook package contains an invalid relationship"
                        raise ValueError(msg)
                    if relationship_id in seen_ids:
                        msg = (
                            "Workbook package contains duplicate "
                            "relationship identifiers"
                        )
                        raise ValueError(msg)
                    seen_ids.add(relationship_id)
                    validated_target_mode = cast(
                        "Literal['Internal', 'External'] | None",
                        target_mode,
                    )
                    external = validated_target_mode == "External"
                    target_part = (
                        None if external else _resolve_target(source_part, target)
                    )
                    if target_part is not None and not package.has(target_part):
                        msg = "Workbook relationship target part is missing"
                        raise ValueError(msg)
                    external_hash = (
                        sha256(target.encode("utf-8")).hexdigest() if external else None
                    )
                    detail_path = (
                        f"/Relationships[1]/Relationship[{relationship_index}]"
                    )
                    raw_internal_target = None if external else target
                    extra_raw_attributes = tuple(
                        (name, value)
                        for name, value in element.attrib.items()
                        if name not in {"Id", "Target", "Type", "TargetMode"}
                    )
                    retained_text = (
                        source_part,
                        relationship_part,
                        detail_path,
                        relationship_id,
                        relationship_type,
                        target_part,
                        raw_internal_target,
                        validated_target_mode,
                        external_hash,
                    )
                    budget.ensure_capacity(
                        records=1 + len(extra_raw_attributes),
                        text_characters=(
                            sum(
                                len(value)
                                for value in retained_text
                                if value is not None
                            )
                            + sum(
                                len(_namespace(name) or "")
                                + len(_local_name(name))
                                + len(value)
                                for name, value in extra_raw_attributes
                            )
                        ),
                    )
                    extra_attributes = tuple(
                        ExcelSourceAttribute(
                            namespace=_namespace(name),
                            name=_local_name(name),
                            value=value,
                        )
                        for name, value in sorted(
                            extra_raw_attributes,
                            key=lambda item: (
                                (_namespace(item[0]) or ""),
                                _local_name(item[0]),
                            ),
                        )
                    )
                    detail = ExcelRelationshipDetail(
                        source_part=source_part,
                        relationship_part=relationship_part,
                        path=detail_path,
                        relationship_id=relationship_id,
                        relationship_type=relationship_type,
                        target_part=target_part,
                        raw_internal_target=raw_internal_target,
                        target_mode=validated_target_mode,
                        external=external,
                        external_target_sha256=external_hash,
                        additional_attributes=extra_attributes,
                    )
                    budget.commit(detail)
                    output.append(detail)
                depth -= 1
                element.clear()
        if depth != 0:
            msg = "Workbook relationship XML is incomplete"
            raise ValueError(msg)
    return tuple(output)


def _strict_workbook_records(  # noqa: C901
    package: _SafePackage,
    *,
    relationships: tuple[ExcelRelationshipDetail, ...],
    budget: _Budget,
) -> tuple[_SheetRecord, ...]:
    """Read only exact workbook/sheets/sheet records and exact relationship IDs."""
    relationship_map = {
        item.relationship_id: item
        for item in relationships
        if item.source_part == "xl/workbook.xml"
    }
    records: list[_SheetRecord] = []
    names: set[str] = set()
    relationship_ids: set[str] = set()
    source_text_characters = 0
    stack: list[tuple[str, str | None]] = []
    workbook_namespace: str | None = None
    sheet_container_count = 0
    with package.open_xml_stream("xl/workbook.xml") as stream:
        for event, element in iterparse(  # noqa: S314 - DTDs rejected upstream.
            stream,
            events=("start", "end"),
        ):
            if event == "start":
                budget.ensure_depth(len(stack) + 1)
                name = _local_name(element.tag)
                namespace = _namespace(element.tag)
                stack.append((name, namespace))
                if len(stack) == 1:
                    workbook_namespace = namespace
                    if name != "workbook" or namespace not in _SPREADSHEET_NAMESPACES:
                        msg = "Workbook root or namespace is invalid"
                        raise ValueError(msg)
                exact_path = tuple(item[0] for item in stack)
                if (
                    name == "sheets"
                    and namespace == workbook_namespace
                    and exact_path == ("workbook", "sheets")
                ):
                    sheet_container_count += 1
                    if sheet_container_count > 1:
                        msg = "Workbook sheet container is duplicated"
                        raise ValueError(msg)
                if (
                    name == "sheet"
                    and namespace == workbook_namespace
                    and exact_path != ("workbook", "sheets", "sheet")
                ):
                    msg = "Workbook sheet declaration has an invalid parent"
                    raise ValueError(msg)
                continue

            if tuple(item[0] for item in stack) == (
                "workbook",
                "sheets",
                "sheet",
            ) and all(item[1] == workbook_namespace for item in stack):
                sheet_name = element.attrib.get("name")
                relationship_id = _relationship_attribute(element, "id")
                if not sheet_name or relationship_id is None:
                    msg = "Workbook sheet identity is incomplete"
                    raise ValueError(msg)
                sheet_name = _WORKSHEET_NAME_ADAPTER.validate_python(sheet_name)
                if (
                    sheet_name.casefold() in names
                    or relationship_id in relationship_ids
                ):
                    msg = "Workbook contains duplicate sheet references"
                    raise ValueError(msg)
                names.add(sheet_name.casefold())
                relationship_ids.add(relationship_id)
                source_text_characters += len(sheet_name) + len(relationship_id)
                budget.ensure_capacity(
                    records=len(records) + 1,
                    text_characters=source_text_characters,
                )
                relationship = relationship_map.get(relationship_id)
                records.append(
                    _SheetRecord(
                        name=sheet_name,
                        visibility=_sheet_visibility(element.attrib.get("state")),
                        relationship_id=relationship_id,
                        part_name=(
                            None if relationship is None else relationship.target_part
                        ),
                        sheet_type=(
                            "unknown"
                            if relationship is None
                            else _sheet_type(relationship.relationship_type)
                        ),
                    )
                )
            stack.pop()
            element.clear()
    return tuple(records)


def _sheet_attachment_relationship_ids(  # noqa: C901, PLR0912, PLR0915
    package: _SafePackage,
    *,
    part_name: str,
    roles: _PartRoles,
    budget: _Budget,
) -> tuple[str | None, tuple[str, ...]]:
    """Stream the bounded sheet attachment declarations without retaining its tree."""
    stack: list[tuple[str, str | None]] = []
    namespace: str | None = None
    drawing_id: str | None = None
    table_ids: list[str] = []
    seen_table_ids: set[str] = set()
    table_id_text = 0
    table_container_count = 0
    declared_table_count: int | None = None
    is_worksheet = part_name in roles.worksheets
    with package.open_xml_stream(part_name, declared_xml=True) as stream:
        for event, element in iterparse(  # noqa: S314 - DTDs rejected upstream.
            stream,
            events=("start", "end"),
        ):
            if event == "start":
                budget.ensure_depth(len(stack) + 1)
                name = _local_name(element.tag)
                element_namespace = _namespace(element.tag)
                stack.append((name, element_namespace))
                if len(stack) == 1:
                    namespace = element_namespace
                    _validate_role_root(element, part_name=part_name, roles=roles)
                names = tuple(item[0] for item in stack)
                if name == "drawing" and element_namespace == namespace:
                    if names != (stack[0][0], "drawing") or drawing_id is not None:
                        msg = "Workbook sheet drawing reference has an invalid parent"
                        raise ValueError(msg)
                    relationship_id = _relationship_attribute(element, "id")
                    if relationship_id is None:
                        msg = (
                            "Workbook sheet drawing reference is missing its "
                            "relationship ID"
                        )
                        raise ValueError(msg)
                    drawing_id = relationship_id
                if (
                    is_worksheet
                    and name == "tableParts"
                    and element_namespace == namespace
                ):
                    if names != ("worksheet", "tableParts"):
                        msg = "Workbook table-parts container has an invalid parent"
                        raise ValueError(msg)
                    table_container_count += 1
                    if table_container_count > 1:
                        msg = "Workbook table-parts container is duplicated"
                        raise ValueError(msg)
                    declared_table_count = _optional_int(element.attrib.get("count"))
                if (
                    is_worksheet
                    and name == "tablePart"
                    and element_namespace == namespace
                ):
                    if names != ("worksheet", "tableParts", "tablePart"):
                        msg = "Workbook table reference has an invalid parent"
                        raise ValueError(msg)
                    relationship_id = _relationship_attribute(element, "id")
                    if relationship_id is None or relationship_id in seen_table_ids:
                        msg = (
                            "Workbook table relationship reference is missing or "
                            "duplicated"
                        )
                        raise ValueError(msg)
                    budget.ensure_capacity(
                        records=len(table_ids) + 1,
                        text_characters=table_id_text + len(relationship_id),
                    )
                    seen_table_ids.add(relationship_id)
                    table_ids.append(relationship_id)
                    table_id_text += len(relationship_id)
                continue
            stack.pop()
            element.clear()
    if declared_table_count is not None and declared_table_count != len(table_ids):
        msg = "Workbook table reference count is inconsistent"
        raise ValueError(msg)
    return drawing_id, tuple(table_ids)


def _drawing_chart_relationship_ids(
    package: _SafePackage,
    *,
    part_name: str,
    roles: _PartRoles,
    budget: _Budget,
) -> tuple[str, ...]:
    """Stream chart attachment IDs from exact DrawingML object paths."""
    stack: list[tuple[str, str | None]] = []
    relationship_ids: list[str] = []
    relationship_id_text = 0
    anchors = {"oneCellAnchor", "twoCellAnchor", "absoluteAnchor"}
    with package.open_xml_stream(part_name, declared_xml=True) as stream:
        for event, element in iterparse(  # noqa: S314 - DTDs rejected upstream.
            stream,
            events=("start", "end"),
        ):
            if event == "start":
                budget.ensure_depth(len(stack) + 1)
                stack.append((_local_name(element.tag), _namespace(element.tag)))
                if len(stack) == 1:
                    _validate_role_root(element, part_name=part_name, roles=roles)
                if (
                    _local_name(element.tag) == "chart"
                    and _namespace(element.tag) in _CHART_NAMESPACES
                ):
                    valid_path = (
                        len(stack) == 6  # noqa: PLR2004
                        and stack[0][0] == "wsDr"
                        and stack[0][1] in _DRAWING_NAMESPACES
                        and stack[1][0] in anchors
                        and stack[1][1] == stack[0][1]
                        and stack[2] == ("graphicFrame", stack[0][1])
                        and stack[3][0] == "graphic"
                        and stack[3][1] in _DRAWING_MAIN_NAMESPACES
                        and stack[4] == ("graphicData", stack[3][1])
                    )
                    if not valid_path:
                        msg = "Workbook chart reference is outside a drawing anchor"
                        raise ValueError(msg)
                    relationship_id = _relationship_attribute(element, "id")
                    if relationship_id is None:
                        msg = "Workbook chart reference is missing its relationship ID"
                        raise ValueError(msg)
                    budget.ensure_capacity(
                        records=len(relationship_ids) + 1,
                        text_characters=relationship_id_text + len(relationship_id),
                    )
                    relationship_ids.append(relationship_id)
                    relationship_id_text += len(relationship_id)
                continue
            stack.pop()
            element.clear()
    return tuple(relationship_ids)


def _sheet_part_map(  # noqa: C901, PLR0912, PLR0915
    package: _SafePackage,
    *,
    sheets: tuple[_SheetRecord, ...],
    relationships: tuple[ExcelRelationshipDetail, ...],
    roles: _PartRoles,
    budget: _Budget,
) -> tuple[
    dict[str, tuple[str, ...]],
    tuple[str, ...],
    dict[str, tuple[tuple[str, str], ...]],
]:
    """Bind parts to sheets only through exact, role-appropriate source references."""
    all_sheet_names = tuple(sheet.name for sheet in sheets)
    relationship_map = {
        (relationship.source_part, relationship.relationship_id): relationship
        for relationship in relationships
    }
    sheet_names_by_part: dict[str, list[str]] = {}
    references_by_part: dict[str, list[tuple[str, str]]] = {}
    association_records = 0
    association_text = 0

    def associate(
        *,
        source_part: str,
        relationship_id: str,
        role: Literal["comments", "drawing", "table", "chart"],
        sheet_names: tuple[str, ...],
    ) -> str:
        nonlocal association_records, association_text
        relationship = relationship_map.get((source_part, relationship_id))
        target_role = {
            "comments": roles.comments,
            "drawing": roles.drawings,
            "table": roles.tables,
            "chart": roles.charts,
        }[role]
        if (
            relationship is None
            or relationship.external
            or relationship.target_part is None
            or _relationship_role(relationship.relationship_type) != role
            or relationship.target_part not in target_role
        ):
            msg = (
                "Workbook source relationship reference is dangling or has a wrong role"
            )
            raise ValueError(msg)
        target = relationship.target_part
        reference = (source_part, relationship_id)
        target_references = references_by_part.setdefault(target, [])
        if reference in target_references:
            msg = "Workbook source relationship reference is duplicated"
            raise ValueError(msg)
        association_records += 1
        association_text += len(source_part) + len(relationship_id)
        target_references.append(reference)
        target_sheets = sheet_names_by_part.setdefault(target, [])
        for sheet_name in sheet_names:
            if sheet_name not in target_sheets:
                association_text += len(sheet_name)
                target_sheets.append(sheet_name)
        budget.ensure_capacity(
            records=association_records,
            text_characters=association_text,
        )
        return target

    for sheet in sheets:
        if sheet.part_name is None:
            continue
        sheet_names_by_part[sheet.part_name] = [sheet.name]
        association_text += len(sheet.name)
        budget.ensure_capacity(
            records=association_records,
            text_characters=association_text,
        )

    for relationship in relationships:
        if (
            relationship.source_part in roles.worksheets
            and _relationship_role(relationship.relationship_type) == "comments"
        ):
            associate(
                source_part=relationship.source_part,
                relationship_id=relationship.relationship_id,
                role="comments",
                sheet_names=tuple(
                    sheet_names_by_part.get(relationship.source_part, ())
                ),
            )

    for sheet in sheets:
        part_name = sheet.part_name
        if part_name is None or part_name not in roles.worksheets | roles.chartsheets:
            continue
        drawing_id, table_ids = _sheet_attachment_relationship_ids(
            package,
            part_name=part_name,
            roles=roles,
            budget=budget,
        )
        if drawing_id is not None:
            associate(
                source_part=part_name,
                relationship_id=drawing_id,
                role="drawing",
                sheet_names=(sheet.name,),
            )

        if part_name not in roles.worksheets:
            continue
        for relationship_id in table_ids:
            associate(
                source_part=part_name,
                relationship_id=relationship_id,
                role="table",
                sheet_names=(sheet.name,),
            )

    for drawing_part in sorted(roles.drawings):
        for relationship_id in _drawing_chart_relationship_ids(
            package,
            part_name=drawing_part,
            roles=roles,
            budget=budget,
        ):
            associate(
                source_part=drawing_part,
                relationship_id=relationship_id,
                role="chart",
                sheet_names=tuple(sheet_names_by_part.get(drawing_part, ())),
            )

    # A relationship part is source representation for its owning part.  Keep
    # the same sheet provenance so raw relationship XML remains traceable to
    # the worksheet or chartsheet that led to it.
    for relationship in relationships:
        source_part = relationship.source_part
        if not source_part:
            continue
        source_path = PurePosixPath(source_part)
        relationship_part = posixpath.join(
            str(source_path.parent),
            "_rels",
            f"{source_path.name}.rels",
        )
        selected = sheet_names_by_part.setdefault(relationship_part, [])
        for sheet_name in sheet_names_by_part.get(source_part, ()):
            if sheet_name not in selected:
                selected.append(sheet_name)

    return (
        {part: tuple(names) for part, names in sheet_names_by_part.items()},
        all_sheet_names,
        {part: tuple(items) for part, items in references_by_part.items()},
    )


def _validated_part_roles(  # noqa: C901, PLR0915
    *,
    sheets: tuple[_SheetRecord, ...],
    relationships: tuple[ExcelRelationshipDetail, ...],
    parts: Mapping[str, ExcelPackagePartDetail],
) -> _PartRoles:
    def target_for(
        relationship: ExcelRelationshipDetail,
        *,
        role: str,
    ) -> str:
        target = relationship.target_part
        if relationship.external or target is None:
            msg = "Workbook semantic relationship target must be internal"
            raise ValueError(msg)
        part = parts.get(target)
        if part is None or part.kind != "xml":
            msg = "Workbook semantic relationship target is missing or not XML"
            raise ValueError(msg)
        allowed_types = _ROLE_CONTENT_TYPES[role]
        if (part.content_type or "").casefold() not in {
            item.casefold() for item in allowed_types
        }:
            msg = "Workbook semantic relationship target has an invalid content type"
            raise ValueError(msg)
        return target

    office_documents = tuple(
        relationship
        for relationship in relationships
        if relationship.source_part == ""
        and _relationship_role(relationship.relationship_type) == "officeDocument"
    )
    if len(office_documents) != 1:
        msg = "Workbook semantic details require one workbook part"
        raise ValueError(msg)
    workbook_part = target_for(office_documents[0], role="officeDocument")
    if workbook_part != "xl/workbook.xml":
        msg = "Workbook semantic details require the main workbook package part"
        raise ValueError(msg)
    workbook_relationships = {
        item.relationship_id: item
        for item in relationships
        if item.source_part == workbook_part
    }
    worksheets: set[str] = set()
    chartsheets: set[str] = set()
    sheet_targets: set[str] = set()
    for sheet in sheets:
        if sheet.part_name is None or sheet.part_name not in parts:
            msg = "Workbook semantic sheet target is missing"
            raise ValueError(msg)
        relationship = workbook_relationships.get(sheet.relationship_id or "")
        if relationship is None:
            msg = "Workbook semantic sheet relationship is missing"
            raise ValueError(msg)
        if sheet.part_name in sheet_targets:
            msg = "Workbook semantic sheet targets must be unique"
            raise ValueError(msg)
        sheet_targets.add(sheet.part_name)
        role = _relationship_role(relationship.relationship_type)
        if role in {"worksheet", "chartsheet"}:
            target = target_for(relationship, role=role)
            if target != sheet.part_name:
                msg = "Workbook semantic sheet target is inconsistent"
                raise ValueError(msg)
            (worksheets if role == "worksheet" else chartsheets).add(target)
        elif role in {"dialogsheet", "macrosheet", "xlMacrosheet"}:
            if target_for(relationship, role=role) != sheet.part_name:
                msg = "Workbook semantic sheet target is inconsistent"
                raise ValueError(msg)
        else:
            msg = "Workbook semantic sheet relationship type is invalid"
            raise ValueError(msg)

    def targets_for(role: str, allowed_sources: set[str]) -> frozenset[str]:
        targets: set[str] = set()
        for relationship in relationships:
            if _relationship_role(relationship.relationship_type) != role:
                continue
            if relationship.source_part not in allowed_sources:
                msg = "Workbook semantic relationship has an invalid source role"
                raise ValueError(msg)
            targets.add(target_for(relationship, role=role))
        return frozenset(targets)

    styles = targets_for("styles", {workbook_part})
    if len(styles) > 1:
        msg = "Workbook semantic details require at most one styles part"
        raise ValueError(msg)
    comments = targets_for("comments", worksheets)
    drawings = targets_for("drawing", worksheets | chartsheets)
    tables = targets_for("table", worksheets)
    charts = targets_for("chart", set(drawings))
    return _PartRoles(
        workbook=frozenset({workbook_part}),
        worksheets=frozenset(worksheets),
        chartsheets=frozenset(chartsheets),
        styles=styles,
        comments=comments,
        drawings=drawings,
        charts=charts,
        tables=tables,
    )


def _path_for_start(stack: list[_Frame], element: Element) -> str:
    name = _local_name(element.tag)
    if not stack:
        return f"/{name}[1]"
    parent = stack[-1]
    count = parent.child_counts.get(name, 0) + 1
    parent.child_counts[name] = count
    return f"{parent.path}/{name}[{count}]"


def _record_row(  # noqa: PLR0913 - source context stays explicit.
    element: Element,
    *,
    sheet_name: str,
    part_name: str,
    path: str,
    previous_row: int,
    default_height: float | None,
) -> ExcelRowDetail:
    row = (
        previous_row + 1
        if element.attrib.get("r") is None
        else int(element.attrib["r"])
    )
    if row < 1 or row > MAX_EXCEL_ROW or row <= previous_row:
        msg = "Worksheet rows are not in deterministic order"
        raise ValueError(msg)
    height = _optional_float(element.attrib.get("ht"))
    return ExcelRowDetail(
        sheet_name=sheet_name,
        part_name=part_name,
        path=path,
        row=row,
        height=height,
        effective_height=height if height is not None else default_height,
        hidden=_bool_attribute(element.attrib.get("hidden")),
        outline_level=int(element.attrib.get("outlineLevel", "0")),
        collapsed=_bool_attribute(element.attrib.get("collapsed")),
        style_id=_optional_int(element.attrib.get("s")),
        custom_height=_bool_attribute(element.attrib.get("customHeight")),
        custom_format=_bool_attribute(element.attrib.get("customFormat")),
        attributes=_attributes(element),
    )


def _record_column(
    element: Element,
    *,
    sheet_name: str,
    part_name: str,
    path: str,
    default_width: float | None,
) -> ExcelColumnDetail:
    minimum = int(element.attrib.get("min", "0"))
    maximum = int(element.attrib.get("max", "0"))
    if minimum < 1 or maximum < minimum or maximum > MAX_EXCEL_COLUMN:
        msg = "Workbook column metadata is outside Excel bounds"
        raise ValueError(msg)
    width = _optional_float(element.attrib.get("width"))
    return ExcelColumnDetail(
        sheet_name=sheet_name,
        part_name=part_name,
        path=path,
        min_column=minimum,
        max_column=maximum,
        width=width,
        effective_width=width if width is not None else default_width,
        hidden=_bool_attribute(element.attrib.get("hidden")),
        outline_level=int(element.attrib.get("outlineLevel", "0")),
        collapsed=_bool_attribute(element.attrib.get("collapsed")),
        style_id=_optional_int(element.attrib.get("style")),
        best_fit=_bool_attribute(element.attrib.get("bestFit")),
        custom_width=_bool_attribute(element.attrib.get("customWidth")),
        attributes=_attributes(element),
    )


def _defined_name(
    element: Element,
    *,
    part_name: str,
    path: str,
    sheet_names: tuple[str, ...],
) -> ExcelDefinedNameDetail:
    local_sheet_id = _optional_int(element.attrib.get("localSheetId"))
    if local_sheet_id is not None and local_sheet_id >= len(sheet_names):
        msg = "Defined-name local sheet index is outside workbook bounds"
        raise ValueError(msg)
    return ExcelDefinedNameDetail(
        part_name=part_name,
        path=path,
        name=element.attrib.get("name", ""),
        definition=element.text or "",
        local_sheet_id=local_sheet_id,
        scope_sheet_name=None
        if local_sheet_id is None
        else sheet_names[local_sheet_id],
        hidden=_bool_attribute(element.attrib.get("hidden")),
        function=_bool_attribute(element.attrib.get("function")),
        vb_procedure=_bool_attribute(element.attrib.get("vbProcedure")),
        xlm=_bool_attribute(element.attrib.get("xlm")),
        function_group_id=_optional_int(element.attrib.get("functionGroupId")),
        shortcut_key=element.attrib.get("shortcutKey"),
        publish_to_server=_bool_attribute(element.attrib.get("publishToServer")),
        workbook_parameter=_bool_attribute(element.attrib.get("workbookParameter")),
        attributes=_attributes(element),
    )


def _comment(
    element: Element,
    *,
    part_name: str,
    path: str,
    sheet_name: str,
    authors: tuple[str, ...],
) -> ExcelCommentDetail:
    author_id = int(element.attrib.get("authorId", "-1"))
    if author_id < 0 or author_id >= len(authors):
        msg = "Workbook comment author index is invalid"
        raise ValueError(msg)
    namespace = _namespace(element.tag)
    text_container = _direct_child(element, "text", namespace=namespace)
    if text_container is None:
        msg = "Workbook comment text container is missing"
        raise ValueError(msg)
    visible = _visible_text(
        text_container,
        container="text",
        label="Workbook comment",
    )
    runs: list[str] = []
    for child in text_container:
        if _namespace(child.tag) != namespace:
            continue
        if _local_name(child.tag) == "t":
            runs.append(child.text or "")
        elif _local_name(child.tag) == "r":
            run_text = _direct_child(child, "t", namespace=namespace)
            if run_text is not None:
                runs.append(run_text.text or "")
    return ExcelCommentDetail(
        sheet_name=sheet_name,
        part_name=part_name,
        path=path,
        coordinate=element.attrib.get("ref", ""),
        author_id=author_id,
        author=authors[author_id],
        text=visible.value,
        rich_text_runs=tuple(runs),
        attributes=_attributes(element),
    )


def _cell_ranges(value: str | None) -> tuple[str, ...]:
    if value is None:
        return ()
    return tuple(normalize_excel_range(item) for item in value.split() if item)


def _hyperlink(  # noqa: PLR0913 - source context stays explicit.
    element: Element,
    *,
    sheet_name: str,
    part_name: str,
    path: str,
    relationships: Mapping[str, ExcelRelationshipDetail],
    parts: Mapping[str, ExcelPackagePartDetail],
) -> ExcelHyperlinkDetail:
    relationship_id = _relationship_attribute(element, "id")
    relationship = relationships.get(relationship_id or "")
    if relationship_id is not None:
        if relationship is None:
            msg = "Workbook hyperlink relationship could not be resolved"
            raise ValueError(msg)
        if _relationship_role(relationship.relationship_type) != "hyperlink":
            msg = "Workbook hyperlink relationship has an invalid type"
            raise ValueError(msg)
        if (
            relationship.target_part is not None
            and relationship.target_part not in parts
        ):
            msg = "Workbook hyperlink target part is missing"
            raise ValueError(msg)
    return ExcelHyperlinkDetail(
        sheet_name=sheet_name,
        part_name=part_name,
        path=path,
        cell_range=normalize_excel_range(element.attrib.get("ref", "")),
        relationship_id=relationship_id,
        target_part=None if relationship is None else relationship.target_part,
        external_target_sha256=(
            None if relationship is None else relationship.external_target_sha256
        ),
        location=element.attrib.get("location"),
        display=element.attrib.get("display"),
        tooltip=element.attrib.get("tooltip"),
        attributes=_attributes(element),
    )


def _required_positive_int(element: Element, name: str) -> int:
    raw = element.attrib.get(name)
    if raw is None:
        msg = "Workbook required positive integer attribute is missing"
        raise ValueError(msg)
    value = int(raw)
    if value <= 0:
        msg = "Workbook required positive integer attribute is invalid"
        raise ValueError(msg)
    return value


def _table_column(element: Element) -> ExcelTableColumnDetail:
    namespace = _namespace(element.tag)
    return ExcelTableColumnDetail(
        column_id=_required_positive_int(element, "id"),
        name=element.attrib.get("name", ""),
        unique_name=element.attrib.get("uniqueName"),
        totals_row_label=element.attrib.get("totalsRowLabel"),
        totals_row_function=element.attrib.get("totalsRowFunction"),
        calculated_column_formula=_first_text(
            element,
            "calculatedColumnFormula",
            namespace=namespace,
        ),
        totals_row_formula=_first_text(
            element,
            "totalsRowFormula",
            namespace=namespace,
        ),
        data_cell_style=element.attrib.get("dataCellStyle"),
        header_row_cell_style=element.attrib.get("headerRowCellStyle"),
        totals_row_cell_style=element.attrib.get("totalsRowCellStyle"),
        attributes=_attributes(element),
    )


def _table_detail(
    root: Element,
    *,
    part_name: str,
    sheet_names: tuple[str, ...],
    source_relationships: tuple[ExcelSourceRelationshipReference, ...],
) -> ExcelTableDetail:
    namespace = _namespace(root.tag)
    table_positions = {
        "tableColumn": ("table", "tableColumns", "tableColumn"),
        "tableStyleInfo": ("table", "tableStyleInfo"),
        "autoFilter": ("table", "autoFilter"),
    }
    for item, names in _walk_with_names(root):
        if "ext" in names or "extLst" in names:
            continue
        expected = table_positions.get(names[-1])
        if expected is not None and (
            names != expected or _namespace(item.tag) != namespace
        ):
            msg = "Workbook table record namespace or parent is invalid"
            raise ValueError(msg)
    column_parent = _direct_child(root, "tableColumns", namespace=namespace)
    column_elements = (
        ()
        if column_parent is None
        else tuple(
            item
            for item in column_parent
            if _local_name(item.tag) == "tableColumn"
            and _namespace(item.tag) == namespace
        )
    )
    columns = tuple(_table_column(item) for item in column_elements)
    if column_parent is None or _optional_int(column_parent.attrib.get("count")) != len(
        columns
    ):
        msg = "Workbook table-column count is invalid"
        raise ValueError(msg)
    if len({item.column_id for item in columns}) != len(columns):
        msg = "Workbook table-column identifiers are duplicated"
        raise ValueError(msg)
    style = _direct_child(root, "tableStyleInfo", namespace=namespace)
    properties = _properties(root, "/table[1]")
    return ExcelTableDetail(
        sheet_names=sheet_names,
        source_relationships=source_relationships,
        part_name=part_name,
        path="/table[1]",
        table_id=_required_positive_int(root, "id"),
        name=root.attrib.get("name", ""),
        display_name=root.attrib.get("displayName", ""),
        cell_range=normalize_excel_range(root.attrib.get("ref", "")),
        header_row_count=int(root.attrib.get("headerRowCount", "1")),
        totals_row_count=int(root.attrib.get("totalsRowCount", "0")),
        totals_row_shown=_bool_attribute(
            root.attrib.get("totalsRowShown"),
            default=True,
        ),
        columns=columns,
        style_name=None if style is None else style.attrib.get("name"),
        show_first_column=(
            False
            if style is None
            else _bool_attribute(style.attrib.get("showFirstColumn"))
        ),
        show_last_column=(
            False
            if style is None
            else _bool_attribute(style.attrib.get("showLastColumn"))
        ),
        show_row_stripes=(
            False
            if style is None
            else _bool_attribute(style.attrib.get("showRowStripes"))
        ),
        show_column_stripes=(
            False
            if style is None
            else _bool_attribute(style.attrib.get("showColumnStripes"))
        ),
        attributes=_attributes(root),
        properties=properties,
    )


def _data_validation(
    element: Element,
    *,
    sheet_name: str,
    part_name: str,
    path: str,
) -> ExcelDataValidationDetail:
    namespace = _namespace(element.tag)
    properties = _properties(element, path)
    return ExcelDataValidationDetail(
        sheet_name=sheet_name,
        part_name=part_name,
        path=path,
        namespace=namespace,
        cell_ranges=_cell_ranges(
            element.attrib.get("sqref")
            or _first_text(element, "sqref", namespace=namespace)
        ),
        validation_type=element.attrib.get("type"),
        operator=element.attrib.get("operator"),
        error_style=element.attrib.get("errorStyle"),
        ime_mode=element.attrib.get("imeMode"),
        allow_blank=_bool_attribute(element.attrib.get("allowBlank")),
        show_drop_down=_bool_attribute(element.attrib.get("showDropDown")),
        show_input_message=_bool_attribute(element.attrib.get("showInputMessage")),
        show_error_message=_bool_attribute(element.attrib.get("showErrorMessage")),
        error_title=element.attrib.get("errorTitle"),
        error=element.attrib.get("error"),
        prompt_title=element.attrib.get("promptTitle"),
        prompt=element.attrib.get("prompt"),
        formulas=tuple(
            child.text or ""
            for child in element
            if _namespace(child.tag) == namespace
            and _local_name(child.tag) in {"formula1", "formula2"}
        ),
        attributes=_attributes(element),
        properties=properties,
    )


def _conditional_rule(
    element: Element,
    *,
    path: str,
) -> ExcelConditionalFormattingRuleDetail:
    namespace = _namespace(element.tag)
    properties = _properties(element, path)
    return ExcelConditionalFormattingRuleDetail(
        rule_type=element.attrib.get("type"),
        priority=_optional_int(element.attrib.get("priority")),
        differential_style_id=_optional_int(element.attrib.get("dxfId")),
        stop_if_true=_bool_attribute(element.attrib.get("stopIfTrue")),
        operator=element.attrib.get("operator"),
        text=element.attrib.get("text"),
        time_period=element.attrib.get("timePeriod"),
        rank=_optional_int(element.attrib.get("rank")),
        percent=_bool_attribute(element.attrib.get("percent")),
        bottom=_bool_attribute(element.attrib.get("bottom")),
        above_average=(
            None
            if element.attrib.get("aboveAverage") is None
            else _bool_attribute(element.attrib.get("aboveAverage"))
        ),
        equal_average=_bool_attribute(element.attrib.get("equalAverage")),
        standard_deviations=_optional_int(element.attrib.get("stdDev")),
        formulas=tuple(
            child.text or ""
            for child in element
            if _namespace(child.tag) == namespace
            and _local_name(child.tag) == "formula"
        ),
        attributes=_attributes(element),
        properties=properties,
    )


def _conditional_formatting(
    element: Element,
    *,
    sheet_name: str,
    part_name: str,
    path: str,
) -> ExcelConditionalFormattingDetail:
    namespace = _namespace(element.tag)
    rule_elements = tuple(
        item
        for item in element
        if _namespace(item.tag) == namespace and _local_name(item.tag) == "cfRule"
    )
    rules = tuple(
        _conditional_rule(
            child,
            path=f"{path}/cfRule[{index}]",
        )
        for index, child in enumerate(rule_elements, start=1)
    )
    return ExcelConditionalFormattingDetail(
        sheet_name=sheet_name,
        part_name=part_name,
        path=path,
        cell_ranges=_cell_ranges(
            element.attrib.get("sqref")
            or _first_text(element, "sqref", namespace=namespace)
        ),
        pivot=_bool_attribute(element.attrib.get("pivot")),
        rules=rules,
        attributes=_attributes(element),
    )


def _auto_filter(
    element: Element,
    *,
    sheet_names: tuple[str, ...],
    part_name: str,
    path: str,
    source_kind: Literal["worksheet", "table"],
) -> ExcelAutoFilterDetail:
    return ExcelAutoFilterDetail(
        sheet_names=sheet_names,
        part_name=part_name,
        path=path,
        cell_range=element.attrib.get("ref"),
        source_kind=source_kind,
        attributes=_attributes(element),
        properties=_properties(element, path),
    )


def _is_custom_or_unknown_part(part_name: str) -> bool:
    known_prefixes = (
        "xl/",
        "docProps/",
        "_rels/",
    )
    return part_name.startswith("customXml/") or not part_name.startswith(
        known_prefixes
    )


@dataclass(slots=True)
class _PendingSourceNode:
    element: Element
    path: str
    sibling_index: int
    category: Literal["custom_xml", "extension", "other", "source_structure"] | None


@dataclass(slots=True)
class _SourceFrame:
    element: Element
    path: str
    document_order_path: tuple[int, ...]
    sibling_index: int
    category: Literal["custom_xml", "extension", "other", "source_structure"] | None
    occurrence_index: int | None
    preserve_space: bool
    child_counts: dict[str, int] = field(default_factory=dict)
    child_count: int = 0
    next_markup_sibling: int = 0
    pending_child: _PendingSourceNode | None = None


def _append_source_occurrence(  # noqa: PLR0913 - source identity stays explicit.
    target: list[ExcelAdditionalSourceDetail],
    *,
    budget: _Budget,
    category: Literal["custom_xml", "extension", "other", "source_structure"],
    sheet_names: tuple[str, ...],
    part_name: str,
    path: str,
    parent_path: str | None,
    document_order_key: tuple[int, ...],
    node_type: Literal[
        "element",
        "text",
        "tail",
        "comment",
        "processing_instruction",
        "namespace_declaration",
    ],
    namespace: str | None,
    name: str,
    attributes: Mapping[str, str] | None = None,
    text: str | None = None,
    declared_prefix: str | None = None,
    child_count: int = 0,
) -> int:
    raw_attributes = {} if attributes is None else attributes
    source_text = (
        category,
        *sheet_names,
        part_name,
        path,
        parent_path,
        node_type,
        namespace,
        name,
        text,
        declared_prefix,
    )
    budget.ensure_capacity(
        records=1 + len(raw_attributes) + len(document_order_key),
        text_characters=(
            sum(len(value) for value in source_text if value is not None)
            + sum(
                len(_namespace(attribute_name) or "")
                + len(_local_name(attribute_name))
                + len(attribute_value)
                for attribute_name, attribute_value in raw_attributes.items()
            )
        ),
    )
    source_attributes = tuple(
        ExcelSourceAttribute(
            namespace=_namespace(attribute_name),
            name=_local_name(attribute_name),
            value=attribute_value,
        )
        for attribute_name, attribute_value in sorted(
            raw_attributes.items(),
            key=lambda item: ((_namespace(item[0]) or ""), _local_name(item[0])),
        )
    )
    detail = ExcelAdditionalSourceDetail(
        category=category,
        sheet_names=sheet_names,
        part_name=part_name,
        path=path,
        parent_path=parent_path,
        document_order_key=document_order_key,
        node_type=node_type,
        namespace=namespace,
        name=name,
        attributes=source_attributes,
        text=text,
        declared_prefix=declared_prefix,
        child_count=child_count,
    )
    budget.commit(detail)
    target.append(detail)
    return len(target) - 1


def _source_category(
    *,
    part_name: str,
    role: str | None,
    parent: _SourceFrame | None,
    name: str,
) -> Literal["custom_xml", "extension", "other", "source_structure"]:
    if role is not None:
        if (parent is not None and parent.category == "extension") or name in {
            "ext",
            "extLst",
        }:
            return "extension"
        return "source_structure"
    if part_name.startswith("customXml/"):
        return "custom_xml"
    return "other" if _is_custom_or_unknown_part(part_name) else "source_structure"


def _collect_source_occurrences(  # noqa: C901, PLR0913, PLR0915
    package: _SafePackage,
    *,
    part_name: str,
    sheet_names: tuple[str, ...],
    roles: _PartRoles,
    budget: _Budget,
    output: _Collected,
    retain_attributes: bool = True,
) -> None:
    """Stream bounded ordered XML structure without exposing redacted fields."""
    role = _part_role(part_name, roles)
    frames: list[_SourceFrame] = []
    occurrences: list[ExcelAdditionalSourceDetail] = []
    pending_namespaces: list[tuple[str, str]] = []
    pending_namespace_text = 0
    document_sibling = 0
    document_special_counts: dict[str, int] = defaultdict(int)

    def flush_pending(parent: _SourceFrame) -> None:
        pending = parent.pending_child
        if pending is None:
            return
        tail = pending.element.tail
        if pending.category is not None and tail is not None:
            _append_source_occurrence(
                occurrences,
                budget=budget,
                category=pending.category,
                sheet_names=sheet_names,
                part_name=part_name,
                path=f"{pending.path}/tail()[1]",
                parent_path=parent.path,
                document_order_key=(
                    *parent.document_order_path,
                    5 + 2 * pending.sibling_index,
                ),
                node_type="tail",
                namespace=None,
                name="#tail",
                text=tail,
            )
        pending.element.clear()
        with suppress(ValueError):
            parent.element.remove(pending.element)
        parent.pending_child = None

    def special(event: str, element: Element) -> None:
        nonlocal document_sibling
        if frames:
            parent = frames[-1]
            flush_pending(parent)
            sibling_index = parent.next_markup_sibling
            parent.next_markup_sibling += 1
            parent.child_count += 1
            category = parent.category
            path_kind = "comment" if event == "comment" else "processing-instruction"
            path_count = parent.child_counts.get(path_kind, 0) + 1
            parent.child_counts[path_kind] = path_count
            path = (
                f"{parent.path}/comment()[{path_count}]"
                if event == "comment"
                else f"{parent.path}/processing-instruction()[{path_count}]"
            )
            parent_path = parent.path
            order_path = (*parent.document_order_path, 4 + 2 * sibling_index)
        else:
            sibling_index = document_sibling
            document_sibling += 1
            category = _source_category(
                part_name=part_name,
                role=role,
                parent=None,
                name="#document",
            )
            path_kind = "comment" if event == "comment" else "processing-instruction"
            document_special_counts[path_kind] += 1
            path_count = document_special_counts[path_kind]
            path = (
                f"/comment()[{path_count}]"
                if event == "comment"
                else f"/processing-instruction()[{path_count}]"
            )
            parent_path = None
            order_path = (2 + 2 * sibling_index,)
        raw_text = element.text or ""
        if event == "pi":
            name = "#processing-instruction"
            value = raw_text
            node_type: Literal["comment", "processing_instruction"] = (
                "processing_instruction"
            )
        else:
            name = "#comment"
            value = raw_text
            node_type = "comment"
        if category is not None:
            _append_source_occurrence(
                occurrences,
                budget=budget,
                category=category,
                sheet_names=sheet_names,
                part_name=part_name,
                path=path,
                parent_path=parent_path,
                document_order_key=(*order_path, 0),
                node_type=node_type,
                namespace=None,
                name=name,
                text=value,
            )
        if frames:
            frames[-1].pending_child = _PendingSourceNode(
                element=element,
                path=path,
                sibling_index=sibling_index,
                category=category,
            )
        else:
            element.clear()

    def start(element: Element) -> None:
        nonlocal document_sibling, pending_namespace_text
        parent = frames[-1] if frames else None
        if parent is not None:
            flush_pending(parent)
            sibling_index = parent.next_markup_sibling
            parent.next_markup_sibling += 1
            parent.child_count += 1
            name = _local_name(element.tag)
            count = parent.child_counts.get(name, 0) + 1
            parent.child_counts[name] = count
            path = f"{parent.path}/{name}[{count}]"
            parent_path = parent.path
            order_path = (*parent.document_order_path, 4 + 2 * sibling_index)
        else:
            sibling_index = document_sibling
            document_sibling += 1
            name = _local_name(element.tag)
            path = f"/{name}[1]"
            parent_path = None
            order_path = (2 + 2 * sibling_index,)
        namespace = _namespace(element.tag)
        category = _source_category(
            part_name=part_name,
            role=role,
            parent=parent,
            name=name,
        )
        occurrence_index: int | None = None
        if category is not None:
            occurrence_index = _append_source_occurrence(
                occurrences,
                budget=budget,
                category=category,
                sheet_names=sheet_names,
                part_name=part_name,
                path=path,
                parent_path=parent_path,
                document_order_key=(*order_path, 0),
                node_type="element",
                namespace=namespace,
                name=name,
                attributes=element.attrib if retain_attributes else None,
            )
            for declaration_index, (prefix, uri) in enumerate(pending_namespaces):
                _append_source_occurrence(
                    occurrences,
                    budget=budget,
                    category=category,
                    sheet_names=sheet_names,
                    part_name=part_name,
                    path=(f"{path}/namespace()[{declaration_index + 1}]"),
                    parent_path=path,
                    document_order_key=(*order_path, 1, declaration_index),
                    node_type="namespace_declaration",
                    namespace=uri,
                    name=prefix or "#default",
                    declared_prefix=prefix,
                )
        pending_namespaces.clear()
        pending_namespace_text = 0
        inherited_preserve = parent.preserve_space if parent is not None else False
        space = element.attrib.get("{http://www.w3.org/XML/1998/namespace}space")
        preserve_space = (
            space == "preserve"
            if space in {"default", "preserve"}
            else inherited_preserve
        )
        frames.append(
            _SourceFrame(
                element=element,
                path=path,
                document_order_path=order_path,
                sibling_index=sibling_index,
                category=category,
                occurrence_index=occurrence_index,
                preserve_space=preserve_space,
            )
        )

    def end(element: Element) -> None:
        if not frames:
            return
        frame = frames.pop()
        flush_pending(frame)
        text = element.text
        if frame.category is not None and (text is not None or frame.child_count == 0):
            _append_source_occurrence(
                occurrences,
                budget=budget,
                category=frame.category,
                sheet_names=sheet_names,
                part_name=part_name,
                path=f"{frame.path}/text()[1]",
                parent_path=frame.path,
                document_order_key=(*frame.document_order_path, 3),
                node_type="text",
                namespace=None,
                name="#text",
                text=text or "",
            )
        if frame.occurrence_index is not None:
            occurrences[frame.occurrence_index] = occurrences[
                frame.occurrence_index
            ].model_copy(update={"child_count": frame.child_count})
        if frames:
            frames[-1].pending_child = _PendingSourceNode(
                element=element,
                path=frame.path,
                sibling_index=frame.sibling_index,
                category=frame.category,
            )
        else:
            element.clear()

    tree_builder = TreeBuilder(insert_comments=True, insert_pis=True)
    xml_parser = XMLParser(target=tree_builder)  # noqa: S314 - DTDs rejected upstream.
    parser = XMLPullParser(
        events=("start", "end", "start-ns", "end-ns", "comment", "pi"),
        _parser=xml_parser,
    )

    def process_events() -> None:
        nonlocal pending_namespace_text
        events = cast("Iterable[tuple[str, object]]", parser.read_events())
        for event, payload in events:
            if event == "start-ns":
                prefix, uri = cast("tuple[str | None, str]", payload)
                budget.ensure_capacity(
                    records=len(pending_namespaces) + 1,
                    text_characters=pending_namespace_text
                    + len(prefix or "")
                    + len(uri),
                )
                pending_namespaces.append((prefix or "", uri))
                pending_namespace_text += len(prefix or "") + len(uri)
            elif event == "end-ns":
                continue
            elif event in {"comment", "pi"}:
                special(event, cast("Element", payload))
            elif event == "start":
                budget.ensure_depth(len(frames) + 1)
                start(cast("Element", payload))
            else:
                end(cast("Element", payload))

    with package.open_xml_stream(part_name, declared_xml=True) as stream:
        while chunk := stream.read(64 * 1024):
            parser.feed(chunk)
            process_events()
    parser.close()
    process_events()
    if frames or pending_namespaces:
        msg = "Workbook XML source enumeration is incomplete"
        raise ValueError(msg)
    output.additional_source.extend(
        sorted(occurrences, key=lambda item: item.document_order_key)
    )


def _parse_part(  # noqa: C901, PLR0912, PLR0913, PLR0915
    package: _SafePackage,
    *,
    part_name: str,
    sheet_names: tuple[str, ...],
    all_sheet_names: tuple[str, ...],
    source_relationships_by_part: Mapping[str, tuple[tuple[str, str], ...]],
    relationship_by_source: Mapping[str, Mapping[str, ExcelRelationshipDetail]],
    parts: Mapping[str, ExcelPackagePartDetail],
    roles: _PartRoles,
    budget: _Budget,
    output: _Collected,
) -> None:
    role = _part_role(part_name, roles)
    relationship_part = part_name.casefold().endswith(".rels")
    _collect_source_occurrences(
        package,
        part_name=part_name,
        sheet_names=sheet_names,
        roles=roles,
        budget=budget,
        output=output,
        # Relationship declarations have a dedicated typed projection that
        # hashes external targets. Their generic structural projection retains
        # element/namespace/text facts, while every attribute is compared via
        # the typed relationship record below the public boundary.
        retain_attributes=not relationship_part,
    )
    if relationship_part:
        return
    if role is None:
        return
    raw_source_relationships = source_relationships_by_part.get(part_name, ())
    budget.ensure_capacity(
        records=len(raw_source_relationships),
        text_characters=(
            sum(
                len(source_part) + len(relationship_id)
                for source_part, relationship_id in raw_source_relationships
            )
            + sum(len(sheet_name) for sheet_name in sheet_names)
        ),
    )
    source_relationships = tuple(
        ExcelSourceRelationshipReference(
            source_part=source_part,
            relationship_id=relationship_id,
        )
        for source_part, relationship_id in raw_source_relationships
    )
    if part_name in roles.charts:
        _preflight_retained_part(
            package,
            part=parts[part_name],
            budget=budget,
            record_factor=2,
        )
        root = package.read_xml(part_name, declared_xml=True)
        _validate_role_root(root, part_name=part_name, roles=roles)
        chart_detail = _chart_detail(
            root,
            part_name=part_name,
            sheet_names=sheet_names,
            source_relationships=source_relationships,
        )
        budget.ensure_source_capacity(
            text=(part_name, *chart_detail.title_text, *chart_detail.chart_types),
            attributes=root.attrib,
        )
        budget.commit(chart_detail)
        output.charts.append(chart_detail)
        return
    if part_name in roles.tables:
        _preflight_retained_part(
            package,
            part=parts[part_name],
            budget=budget,
            record_factor=3,
        )
        root = package.read_xml(part_name, declared_xml=True)
        _validate_role_root(root, part_name=part_name, roles=roles)
        table_detail = _table_detail(
            root,
            part_name=part_name,
            sheet_names=sheet_names,
            source_relationships=source_relationships,
        )
        budget.ensure_source_capacity(
            text=(
                part_name,
                table_detail.path,
                *sheet_names,
                table_detail.name,
                table_detail.display_name,
            ),
            attributes=root.attrib,
        )
        budget.commit(table_detail)
        output.tables.append(table_detail)
        auto_filters = tuple(
            item
            for item in root
            if _local_name(item.tag) == "autoFilter"
            and _namespace(item.tag) == _namespace(root.tag)
        )
        for index, auto_filter in enumerate(auto_filters, start=1):
            filter_detail = _auto_filter(
                auto_filter,
                sheet_names=sheet_names,
                part_name=part_name,
                path=f"/table[1]/autoFilter[{index}]",
                source_kind="table",
            )
            budget.ensure_source_capacity(
                text=(
                    part_name,
                    filter_detail.path,
                    *sheet_names,
                    filter_detail.cell_range,
                ),
                attributes=auto_filter.attrib,
            )
            budget.commit(filter_detail)
            output.auto_filters.append(filter_detail)
        return

    is_worksheet = part_name in roles.worksheets
    is_chartsheet = part_name in roles.chartsheets
    is_styles = part_name in roles.styles
    is_comments = part_name in roles.comments
    is_workbook = part_name in roles.workbook
    is_drawing = part_name in roles.drawings
    stack: list[_Frame] = []
    retained_depth = 0
    retained_record_count = 0
    retained_text_characters = 0
    current_row = 0
    previous_row = 0
    previous_column = 0
    row_style_id: int | None = None
    default_row_height: float | None = None
    default_column_width: float | None = None
    worksheet_columns: list[ExcelColumnDetail] = []
    authors: list[str] = []
    author_text_characters = 0

    style_indexes: dict[str, int] = defaultdict(int)
    relationship_map = relationship_by_source.get(part_name, {})
    with package.open_xml_stream(part_name, declared_xml=True) as stream:
        for event, element in iterparse(stream, events=("start", "end")):  # noqa: S314
            name = _local_name(element.tag)
            if event == "start":
                budget.ensure_depth(len(stack) + 1)
                path = _path_for_start(stack, element)
                if not stack:
                    _validate_role_root(element, part_name=part_name, roles=roles)
                _validate_typed_position(element, parents=stack, role=role)
                retain = (
                    (
                        is_worksheet
                        and _element_path_is(
                            element,
                            stack,
                            ("worksheet", "sheetData", "row", "c"),
                        )
                    )
                    or (is_styles and _style_component(element, stack) is not None)
                    or (
                        is_comments
                        and _element_path_is(
                            element,
                            stack,
                            ("comments", "commentList", "comment"),
                        )
                    )
                    or (
                        is_drawing
                        and any(
                            _element_path_is(
                                element,
                                stack,
                                ("wsDr", anchor),
                                _DRAWING_NAMESPACES,
                            )
                            for anchor in (
                                "oneCellAnchor",
                                "twoCellAnchor",
                                "absoluteAnchor",
                            )
                        )
                    )
                    or (
                        is_worksheet
                        and (
                            _element_path_is(
                                element,
                                stack,
                                ("worksheet", "dataValidations", "dataValidation"),
                            )
                            or _element_path_is(
                                element,
                                stack,
                                ("worksheet", "conditionalFormatting"),
                            )
                            or _element_path_is(
                                element,
                                stack,
                                ("worksheet", "autoFilter"),
                            )
                        )
                    )
                )
                stack.append(
                    _Frame(
                        element=element,
                        name=name,
                        namespace=_namespace(element.tag),
                        path=path,
                        retain=retain,
                    )
                )
                if retain:
                    if retained_depth:
                        msg = "Workbook semantic retained subtrees overlap"
                        raise ValueError(msg)
                    retained_record_count = 0
                    retained_text_characters = 0
                    retained_depth += 1
                if retained_depth:
                    retained_record_count += 1 + len(element.attrib)
                    retained_text_characters += (
                        len(path)
                        + len(_namespace(element.tag) or "")
                        + len(name)
                        + sum(
                            len(_namespace(attribute) or "")
                            + len(_local_name(attribute))
                            + len(value)
                            for attribute, value in element.attrib.items()
                        )
                    )
                    budget.ensure_capacity(
                        records=2 * retained_record_count,
                        text_characters=2 * retained_text_characters,
                    )
                if is_worksheet and _frames_path_is(
                    stack,
                    ("worksheet", "sheetFormatPr"),
                ):
                    default_row_height = _optional_float(
                        element.attrib.get("defaultRowHeight")
                    )
                    default_column_width = _optional_float(
                        element.attrib.get("defaultColWidth")
                    )
                elif is_worksheet and _frames_path_is(
                    stack,
                    ("worksheet", "sheetData", "row"),
                ):
                    budget.ensure_source_capacity(
                        text=(sheet_names[0], part_name, path),
                        attributes=element.attrib,
                    )
                    row_detail = _record_row(
                        element,
                        sheet_name=sheet_names[0],
                        part_name=part_name,
                        path=path,
                        previous_row=previous_row,
                        default_height=default_row_height,
                    )
                    current_row = row_detail.row
                    previous_column = 0
                    row_style_id = (
                        row_detail.style_id if row_detail.custom_format else None
                    )
                    budget.commit(row_detail)
                    output.rows.append(row_detail)
                elif is_worksheet and _frames_path_is(
                    stack,
                    ("worksheet", "cols", "col"),
                ):
                    budget.ensure_source_capacity(
                        text=(sheet_names[0], part_name, path),
                        attributes=element.attrib,
                    )
                    column_detail = _record_column(
                        element,
                        sheet_name=sheet_names[0],
                        part_name=part_name,
                        path=path,
                        default_width=default_column_width,
                    )
                    worksheet_columns.append(column_detail)
                    budget.commit(column_detail)
                    output.columns.append(column_detail)
                continue

            frame = stack[-1]
            if retained_depth:
                retained_text_characters += len(element.text or "") + len(
                    element.tail or ""
                )
                budget.ensure_capacity(
                    records=2 * retained_record_count,
                    text_characters=2 * retained_text_characters,
                )
            if is_comments and _frames_path_is(
                stack,
                ("comments", "authors", "author"),
            ):
                author = element.text or ""
                author_text_characters += len(author)
                budget.ensure_capacity(
                    records=len(authors) + 1,
                    text_characters=author_text_characters,
                )
                authors.append(author)
            elif is_worksheet and _frames_path_is(
                stack,
                ("worksheet", "sheetData", "row", "c"),
            ):
                coordinate, previous_column = _coordinate(
                    element,
                    current_row=current_row,
                    previous_column=previous_column,
                )
                cell_detail = _physical_cell(
                    element,
                    sheet_name=sheet_names[0],
                    part_name=part_name,
                    path=frame.path,
                    coordinate=coordinate,
                    row_style_id=row_style_id,
                    columns=worksheet_columns,
                )
                budget.ensure_source_capacity(
                    text=(
                        cell_detail.sheet_name,
                        part_name,
                        frame.path,
                        coordinate,
                        cell_detail.raw_type,
                        cell_detail.formula_text,
                        cell_detail.raw_cached_value,
                        cell_detail.inline_text,
                    ),
                    attributes=element.attrib,
                )
                budget.commit(cell_detail)
                output.physical_cells.append(cell_detail)
            elif is_worksheet and _frames_path_is(
                stack,
                ("worksheet", "sheetData", "row"),
            ):
                previous_row = current_row
                current_row = 0
                row_style_id = None
            elif (
                is_styles
                and (component := _style_component(element, stack[:-1])) is not None
            ):
                index = style_indexes[component]
                style_indexes[component] += 1
                style_detail = ExcelStyleDetail(
                    component=component,
                    index=index,
                    part_name=part_name,
                    path=frame.path,
                    attributes=_attributes(element),
                    properties=_properties(element, frame.path),
                )
                budget.ensure_source_capacity(
                    text=(part_name, frame.path, component),
                    attributes=element.attrib,
                )
                budget.commit(style_detail)
                output.styles.append(style_detail)
            elif is_comments and _frames_path_is(
                stack,
                ("comments", "commentList", "comment"),
            ):
                if len(sheet_names) != 1:
                    msg = "Workbook comment part does not resolve to one sheet"
                    raise ValueError(msg)
                comment_detail = _comment(
                    element,
                    part_name=part_name,
                    path=frame.path,
                    sheet_name=sheet_names[0],
                    authors=tuple(authors),
                )
                budget.ensure_source_capacity(
                    text=(
                        comment_detail.sheet_name,
                        part_name,
                        frame.path,
                        comment_detail.coordinate,
                        comment_detail.author,
                        comment_detail.text,
                    ),
                    attributes=element.attrib,
                )
                budget.commit(comment_detail)
                output.comments.append(comment_detail)
            elif is_workbook and _frames_path_is(
                stack,
                ("workbook", "definedNames", "definedName"),
            ):
                name_detail = _defined_name(
                    element,
                    part_name=part_name,
                    path=frame.path,
                    sheet_names=all_sheet_names,
                )
                budget.ensure_source_capacity(
                    text=(
                        part_name,
                        frame.path,
                        name_detail.name,
                        name_detail.definition,
                        name_detail.scope_sheet_name,
                    ),
                    attributes=element.attrib,
                )
                budget.commit(name_detail)
                output.defined_names.append(name_detail)
            elif is_drawing and any(
                _frames_path_is(
                    stack,
                    ("wsDr", anchor),
                    _DRAWING_NAMESPACES,
                )
                for anchor in (
                    "oneCellAnchor",
                    "twoCellAnchor",
                    "absoluteAnchor",
                )
            ):
                drawing_detail = _drawing_detail(
                    element,
                    part_name=part_name,
                    path=frame.path,
                    sheet_names=sheet_names,
                    source_relationships=source_relationships,
                    relationships=relationship_map,
                    parts=parts,
                )
                budget.ensure_source_capacity(
                    text=(
                        *sheet_names,
                        part_name,
                        frame.path,
                        drawing_detail.object_type,
                        drawing_detail.object_name,
                        drawing_detail.object_description,
                        drawing_detail.relationship_id,
                        drawing_detail.target_part,
                        drawing_detail.external_target_sha256,
                        drawing_detail.target_content_type,
                        drawing_detail.target_sha256,
                    ),
                    attributes=element.attrib,
                )
                budget.commit(drawing_detail)
                output.drawings.append(drawing_detail)
            elif (
                (is_workbook or is_worksheet or is_chartsheet)
                and tuple(frame.name for frame in stack) in _VIEW_PATHS
                and _frames_path_is(
                    stack,
                    tuple(frame.name for frame in stack),
                )
            ):
                view_detail = ExcelViewDetail(
                    sheet_name=sheet_names[0] if len(sheet_names) == 1 else None,
                    part_name=part_name,
                    path=frame.path,
                    kind=name,
                    attributes=_attributes(element),
                )
                budget.ensure_source_capacity(
                    text=(view_detail.sheet_name, part_name, frame.path, name),
                    attributes=element.attrib,
                )
                budget.commit(view_detail)
                output.views.append(view_detail)
            elif (is_worksheet or is_chartsheet) and _path_has_suffix(
                stack,
                _PAGE_PRINT_PATH_SUFFIXES,
            ):
                page_detail = ExcelPagePrintDetail(
                    sheet_name=sheet_names[0],
                    part_name=part_name,
                    path=frame.path,
                    kind=name,
                    attributes=_attributes(element),
                    text=element.text,
                )
                budget.ensure_source_capacity(
                    text=(
                        page_detail.sheet_name,
                        part_name,
                        frame.path,
                        name,
                        element.text,
                    ),
                    attributes=element.attrib,
                )
                budget.commit(page_detail)
                output.page_print.append(page_detail)
            elif (
                is_workbook
                and tuple(frame.name for frame in stack) in _WORKBOOK_PROPERTY_PATHS
                and _frames_path_is(
                    stack,
                    tuple(frame.name for frame in stack),
                )
            ):
                property_detail = ExcelWorkbookPropertyDetail(
                    part_name=part_name,
                    path=frame.path,
                    kind=name,
                    namespace=frame.namespace,
                    attributes=_attributes(element),
                    text=element.text,
                )
                budget.ensure_source_capacity(
                    text=(part_name, frame.path, name, element.text),
                    attributes=element.attrib,
                )
                budget.commit(property_detail)
                output.workbook_properties.append(property_detail)
            elif (is_worksheet or is_chartsheet) and _path_has_suffix(
                stack,
                _WORKSHEET_PROPERTY_PATH_SUFFIXES,
            ):
                worksheet_property = ExcelWorksheetPropertyDetail(
                    sheet_name=sheet_names[0],
                    part_name=part_name,
                    path=frame.path,
                    kind=name,
                    namespace=_namespace(element.tag),
                    attributes=_attributes(element),
                    text=element.text,
                )
                budget.ensure_source_capacity(
                    text=(
                        worksheet_property.sheet_name,
                        part_name,
                        frame.path,
                        name,
                        element.text,
                    ),
                    attributes=element.attrib,
                )
                budget.commit(worksheet_property)
                output.worksheet_properties.append(worksheet_property)
            elif is_worksheet and _frames_path_is(
                stack,
                ("worksheet", "hyperlinks", "hyperlink"),
            ):
                hyperlink_detail = _hyperlink(
                    element,
                    sheet_name=sheet_names[0],
                    part_name=part_name,
                    path=frame.path,
                    relationships=relationship_map,
                    parts=parts,
                )
                budget.ensure_source_capacity(
                    text=(
                        hyperlink_detail.sheet_name,
                        part_name,
                        frame.path,
                        hyperlink_detail.cell_range,
                        hyperlink_detail.relationship_id,
                        hyperlink_detail.target_part,
                        hyperlink_detail.external_target_sha256,
                        hyperlink_detail.location,
                        hyperlink_detail.display,
                        hyperlink_detail.tooltip,
                    ),
                    attributes=element.attrib,
                )
                budget.commit(hyperlink_detail)
                output.hyperlinks.append(hyperlink_detail)
            elif is_worksheet and _frames_path_is(
                stack,
                ("worksheet", "dataValidations", "dataValidation"),
            ):
                validation_detail = _data_validation(
                    element,
                    sheet_name=sheet_names[0],
                    part_name=part_name,
                    path=frame.path,
                )
                budget.ensure_source_capacity(
                    text=(
                        validation_detail.sheet_name,
                        part_name,
                        frame.path,
                        *validation_detail.cell_ranges,
                        *validation_detail.formulas,
                        validation_detail.error,
                        validation_detail.prompt,
                    ),
                    attributes=element.attrib,
                )
                budget.commit(validation_detail)
                output.data_validations.append(validation_detail)
            elif is_worksheet and _frames_path_is(
                stack,
                ("worksheet", "conditionalFormatting"),
            ):
                conditional_detail = _conditional_formatting(
                    element,
                    sheet_name=sheet_names[0],
                    part_name=part_name,
                    path=frame.path,
                )
                budget.ensure_source_capacity(
                    text=(
                        conditional_detail.sheet_name,
                        part_name,
                        frame.path,
                        *conditional_detail.cell_ranges,
                    ),
                    attributes=element.attrib,
                )
                budget.commit(conditional_detail)
                output.conditional_formatting.append(conditional_detail)
            elif is_worksheet and _frames_path_is(
                stack,
                ("worksheet", "autoFilter"),
            ):
                filter_detail = _auto_filter(
                    element,
                    sheet_names=sheet_names,
                    part_name=part_name,
                    path=frame.path,
                    source_kind="worksheet",
                )
                budget.ensure_source_capacity(
                    text=(
                        part_name,
                        frame.path,
                        *sheet_names,
                        filter_detail.cell_range,
                    ),
                    attributes=element.attrib,
                )
                budget.commit(filter_detail)
                output.auto_filters.append(filter_detail)

            if frame.retain:
                retained_depth -= 1
                retained_record_count = 0
                retained_text_characters = 0
            stack.pop()
            if retained_depth == 0:
                element.clear()
                if stack:
                    stack[-1].element.remove(element)


def _inspect_package(
    path: Path,
    *,
    descriptor: FileDescriptor,
    limits: ExcelPackageLimits | None,
) -> WorkbookSemanticDetails:
    try:
        package_context = _SafePackage(path, limits=limits)
    except BadZipFile as exc:
        msg = "Workbook is not a valid OOXML package"
        _raise_redacted_translation(exc, ValueError(msg))
    budget = _Budget(limits)
    output = _Collected()
    with package_context as package:
        package.verify_fingerprint(descriptor.fingerprint.value)
        _preflight_xml_depth(package, "[Content_Types].xml", budget=budget)
        content_types = _content_types(package)
        for name in package.names:
            detail = _member_detail(package, name=name, content_types=content_types)
            budget.ensure_source_capacity(
                text=(name, detail.content_type, detail.sha256),
            )
            output.package_parts.append(detail)
        relationships = _relationship_details(package, budget=budget)
        output.relationships.extend(relationships)
        sheets = _strict_workbook_records(
            package,
            relationships=relationships,
            budget=budget,
        )
        relationships_by_source: dict[str, dict[str, ExcelRelationshipDetail]] = (
            defaultdict(dict)
        )
        for relationship in relationships:
            relationships_by_source[relationship.source_part][
                relationship.relationship_id
            ] = relationship
        part_map = {item.part_name: item for item in output.package_parts}
        roles = _validated_part_roles(
            sheets=sheets,
            relationships=relationships,
            parts=part_map,
        )
        linked_targets = {
            relationship.target_part
            for relationship in relationships
            if not relationship.external and relationship.target_part is not None
        }
        malformed_unused_shared_strings: set[str] = set()
        for detail in output.package_parts:
            if (
                detail.kind != "xml"
                or detail.part_name.casefold() != "xl/sharedstrings.xml"
                or detail.part_name in linked_targets
            ):
                continue
            try:
                _preflight_xml_depth(package, detail.part_name, budget=budget)
            except ParseError:
                malformed_unused_shared_strings.add(detail.part_name)
        sheet_parts, all_sheet_names, source_relationships_by_part = _sheet_part_map(
            package,
            sheets=sheets,
            relationships=relationships,
            roles=roles,
            budget=budget,
        )
        typed_parts = frozenset().union(
            roles.workbook,
            roles.worksheets,
            roles.chartsheets,
            roles.styles,
            roles.comments,
            roles.drawings,
            roles.charts,
            roles.tables,
            {
                item.part_name
                for item in output.package_parts
                if item.kind == "relationship"
            },
        )
        output.package_parts = [
            item.model_copy(
                update={
                    "semantic_representation": (
                        "typed"
                        if item.part_name in typed_parts
                        else (
                            "identity_only"
                            if item.part_name in malformed_unused_shared_strings
                            else "structured"
                            if item.kind == "xml"
                            else "identity_only"
                        )
                    )
                }
            )
            for item in output.package_parts
        ]
        for detail in output.package_parts:
            budget.commit(detail)
        part_map = {item.part_name: item for item in output.package_parts}
        for part in output.package_parts:
            if part.kind not in {"xml", "relationship"} or (
                part.semantic_representation == "identity_only"
            ):
                continue
            _parse_part(
                package,
                part_name=part.part_name,
                sheet_names=sheet_parts.get(part.part_name, ()),
                all_sheet_names=all_sheet_names,
                source_relationships_by_part=source_relationships_by_part,
                relationship_by_source=relationships_by_source,
                parts=part_map,
                roles=roles,
                budget=budget,
                output=output,
            )
        package.verify_fingerprint(descriptor.fingerprint.value)

    return WorkbookSemanticDetails(
        file=descriptor,
        package_parts=tuple(output.package_parts),
        relationships=tuple(output.relationships),
        styles=tuple(output.styles),
        physical_cells=tuple(output.physical_cells),
        comments=tuple(output.comments),
        defined_names=tuple(output.defined_names),
        hyperlinks=tuple(output.hyperlinks),
        tables=tuple(output.tables),
        data_validations=tuple(output.data_validations),
        conditional_formatting=tuple(output.conditional_formatting),
        auto_filters=tuple(output.auto_filters),
        drawings=tuple(output.drawings),
        charts=tuple(output.charts),
        rows=tuple(output.rows),
        columns=tuple(output.columns),
        views=tuple(output.views),
        page_print=tuple(output.page_print),
        workbook_properties=tuple(output.workbook_properties),
        worksheet_properties=tuple(output.worksheet_properties),
        additional_source=tuple(output.additional_source),
        record_count=budget.records,
        text_character_count=budget.text_characters,
    )


def inspect_workbook_semantic_details(
    path: Path,
    *,
    package_limits: ExcelPackageLimits | None = None,
) -> WorkbookSemanticDetails:
    """Return bounded source details without changing sparse Excel read semantics.

    The result contains one record for every validated package member and
    relationship plus semantically named records for known workbook families.
    Custom XML and extension nodes are returned as ordered structured facts;
    raw XML and binary payloads are never embedded in the public result.
    """
    validated_limits = validate_excel_package_limits(package_limits)
    descriptor = inspect_excel_input(path, package_limits=validated_limits)
    with translate_excel_errors(path, "inspect workbook semantic details"):
        return _inspect_package(
            path,
            descriptor=descriptor,
            limits=validated_limits,
        )


__all__ = [
    "ExcelAdditionalSourceDetail",
    "ExcelAutoFilterDetail",
    "ExcelChartDetail",
    "ExcelChartSeriesDetail",
    "ExcelColumnDetail",
    "ExcelCommentDetail",
    "ExcelConditionalFormattingDetail",
    "ExcelConditionalFormattingRuleDetail",
    "ExcelDataValidationDetail",
    "ExcelDefinedNameDetail",
    "ExcelDrawingDetail",
    "ExcelDrawingMarkerDetail",
    "ExcelHyperlinkDetail",
    "ExcelPackagePartDetail",
    "ExcelPagePrintDetail",
    "ExcelPhysicalCellDetail",
    "ExcelRelationshipDetail",
    "ExcelRowDetail",
    "ExcelSourceAttribute",
    "ExcelSourceProperty",
    "ExcelSourceRelationshipReference",
    "ExcelStyleDetail",
    "ExcelTableColumnDetail",
    "ExcelTableDetail",
    "ExcelViewDetail",
    "ExcelWorkbookPropertyDetail",
    "ExcelWorksheetPropertyDetail",
    "WorkbookSemanticDetails",
    "inspect_workbook_semantic_details",
]

"""Preserve untouched worksheet cell-style references across cell rewrites."""

from __future__ import annotations

import os
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import TYPE_CHECKING, cast
from xml.dom import Node, minidom

from document_sdk.core._excel_coordinates import MAX_EXCEL_ROW, excel_range_bounds
from document_sdk.excel._column_modification import (
    _ColumnStyleTable,
    _copy_package,
    _direct_elements,
    _document_root,
    _existing_states,
    _spreadsheet_element,
)
from document_sdk.excel._package import _SafePackage
from document_sdk.excel._package_security import _serialize_xml
from document_sdk.excel._package_workbook import _workbook_records
from document_sdk.excel._package_worksheet import (
    _SPREADSHEETML_WORKSHEET_NAMESPACES,
)
from document_sdk.excel.errors import ExcelPackageLimitError
from document_sdk.files import calculate_sha256

if TYPE_CHECKING:
    from collections.abc import Iterable
    from xml.dom.minidom import Attr, Document, Element

    from document_sdk.excel.models import CellFormatPatch


_MAX_STYLE_REFERENCES = 5_000_000
_CONTENT_TYPES_MEMBER = "[Content_Types].xml"
_CONTENT_TYPES_NAMESPACE = (
    "http://schemas.openxmlformats.org/package/2006/content-types"
)
_METADATA_MEMBER = "xl/metadata.xml"
_METADATA_PART_NAME = "/xl/metadata.xml"
_METADATA_CONTENT_TYPE = (
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheetMetadata+xml"
)
_WORKBOOK_RELATIONSHIPS_MEMBER = "xl/_rels/workbook.xml.rels"
_RELATIONSHIPS_NAMESPACE = (
    "http://schemas.openxmlformats.org/package/2006/relationships"
)
_WORKSHEET_CHILD_ORDER = (
    "sheetPr",
    "dimension",
    "sheetViews",
    "sheetFormatPr",
    "cols",
    "sheetData",
    "sheetCalcPr",
    "sheetProtection",
    "protectedRanges",
    "scenarios",
    "autoFilter",
    "sortState",
    "dataConsolidate",
    "customSheetViews",
    "mergeCells",
    "phoneticPr",
    "conditionalFormatting",
    "dataValidations",
    "hyperlinks",
    "printOptions",
    "pageMargins",
    "pageSetup",
    "headerFooter",
    "rowBreaks",
    "colBreaks",
    "customProperties",
    "cellWatches",
    "ignoredErrors",
    "smartTags",
    "drawing",
    "legacyDrawing",
    "legacyDrawingHF",
    "picture",
    "oleObjects",
    "controls",
    "webPublishItems",
    "tableParts",
    "extLst",
)


def _worksheet_document(payload: bytes) -> tuple[Document, Element, str]:
    document = minidom.parseString(  # noqa: S318 - bounded, DTD-screened OOXML.
        payload
    )
    root = _document_root(document)
    namespace = root.namespaceURI
    if namespace not in _SPREADSHEETML_WORKSHEET_NAMESPACES:
        msg = "Workbook worksheet namespace is unsupported"
        raise ValueError(msg)
    return document, root, namespace


def _cell_elements(root: Element, namespace: str) -> Iterable[Element]:
    for observed, node in enumerate(
        root.getElementsByTagNameNS(namespace, "c"), start=1
    ):
        if observed > _MAX_STYLE_REFERENCES:
            raise ExcelPackageLimitError(
                limit_name="cell_style_references",
                observed=observed,
                maximum=_MAX_STYLE_REFERENCES,
            )
        yield node


def _cell_references(
    root: Element,
    namespace: str,
) -> dict[str, dict[str, str | None]]:
    references: dict[str, dict[str, str | None]] = {}
    for element in _cell_elements(root, namespace):
        coordinate = element.getAttribute("r")
        if not coordinate or coordinate in references:
            msg = "Workbook worksheet contains invalid cell references"
            raise ValueError(msg)
        values = tuple(
            child
            for child in element.childNodes
            if child.nodeType == Node.ELEMENT_NODE
            and getattr(child, "namespaceURI", None) == namespace
            and getattr(child, "localName", None) == "v"
        )
        formulas = tuple(
            child
            for child in element.childNodes
            if child.nodeType == Node.ELEMENT_NODE
            and getattr(child, "namespaceURI", None) == namespace
            and getattr(child, "localName", None) == "f"
        )
        numeric_text = None
        if element.getAttribute("t") in {"", "n"} and not formulas and len(values) == 1:
            numeric_text = "".join(
                child.data
                for child in values[0].childNodes
                if isinstance(child, minidom.Text)
            )
        references[coordinate] = {
            name: element.getAttribute(name) if element.hasAttribute(name) else None
            for name in ("s", "cm", "vm")
        }
        references[coordinate]["numeric_text"] = numeric_text
    return references


def _row_elements(
    root: Element,
    namespace: str,
) -> Iterable[tuple[int, Element]]:
    previous_row = 0
    for observed, node in enumerate(
        root.getElementsByTagNameNS(namespace, "row"), start=1
    ):
        if observed > _MAX_STYLE_REFERENCES:
            raise ExcelPackageLimitError(
                limit_name="row_style_references",
                observed=observed,
                maximum=_MAX_STYLE_REFERENCES,
            )
        raw_row = node.getAttribute("r")
        try:
            row = previous_row + 1 if raw_row == "" else int(raw_row)
        except ValueError:
            msg = "Workbook row style reference is outside Excel bounds"
            raise ValueError(msg) from None
        if row < 1 or row > MAX_EXCEL_ROW or row <= previous_row:
            msg = "Workbook row style reference is outside Excel bounds"
            raise ValueError(msg)
        previous_row = row
        yield row, node


def _row_references(
    root: Element,
    namespace: str,
) -> dict[int, dict[str, str | None]]:
    return {
        row: {
            name: element.getAttribute(name) if element.hasAttribute(name) else None
            for name in ("s", "customFormat")
        }
        for row, element in _row_elements(root, namespace)
    }


def _restore_cell_attribute(
    element: Element,
    name: str,
    value: str | None,
) -> None:
    if value is None:
        if element.hasAttribute(name):
            element.removeAttribute(name)
    else:
        element.setAttribute(name, value)


def _restore_payload(  # noqa: C901
    source: bytes,
    output: bytes,
    *,
    style_targets: frozenset[str],
    metadata_targets: frozenset[str],
    modified_merged_ranges: frozenset[str],
) -> bytes:
    _source_document, source_root, source_namespace = _worksheet_document(source)
    output_document, output_root, output_namespace = _worksheet_document(output)
    if source_namespace != output_namespace:
        msg = "Patched workbook worksheet namespace changed"
        raise ValueError(msg)
    source_rows = _row_references(source_root, source_namespace)
    for row, element in _row_elements(output_root, output_namespace):
        source_state = source_rows.get(row)
        if source_state is None:
            continue
        for name in ("s", "customFormat"):
            _restore_cell_attribute(element, name, source_state[name])
    source_references = _cell_references(source_root, source_namespace)
    for element in _cell_elements(output_root, output_namespace):
        coordinate = element.getAttribute("r")
        if coordinate not in source_references:
            continue
        source_state = source_references[coordinate]
        if coordinate not in style_targets:
            _restore_cell_attribute(element, "s", source_state["s"])
        if coordinate not in metadata_targets:
            for name in ("cm", "vm"):
                _restore_cell_attribute(element, name, source_state[name])
            numeric_text = source_state["numeric_text"]
            if numeric_text is not None and element.getAttribute("t") in {"", "n"}:
                values = tuple(
                    child
                    for child in element.childNodes
                    if child.nodeType == Node.ELEMENT_NODE
                    and getattr(child, "namespaceURI", None) == output_namespace
                    and getattr(child, "localName", None) == "v"
                )
                formulas = tuple(
                    child
                    for child in element.childNodes
                    if child.nodeType == Node.ELEMENT_NODE
                    and getattr(child, "namespaceURI", None) == output_namespace
                    and getattr(child, "localName", None) == "f"
                )
                if not formulas and len(values) == 1:
                    while values[0].firstChild is not None:
                        values[0].removeChild(values[0].firstChild)
                    values[0].appendChild(output_document.createTextNode(numeric_text))
    _restore_duplicate_merged_nonanchors(
        source_root,
        output_root,
        output_namespace,
        modified_merged_ranges,
    )
    return output_document.toxml(encoding="utf-8")


def _direct_worksheet_element(
    root: Element,
    namespace: str,
    local_name: str,
) -> Element | None:
    matches = tuple(
        child
        for child in _direct_elements(root)
        if _spreadsheet_element(child, local_name, namespace)
    )
    if len(matches) > 1:
        msg = "Workbook worksheet contains duplicate state containers"
        raise ValueError(msg)
    return matches[0] if matches else None


def _merged_range_bounds(
    root: Element,
    namespace: str,
) -> dict[tuple[int, int, int, int], str]:
    container = _direct_worksheet_element(root, namespace, "mergeCells")
    if container is None:
        return {}
    ranges: dict[tuple[int, int, int, int], str] = {}
    for element in _direct_elements(container):
        if not _spreadsheet_element(element, "mergeCell", namespace):
            continue
        cell_range = element.getAttribute("ref")
        try:
            bounds = excel_range_bounds(cell_range)
        except ValueError:
            msg = "Workbook merged range is invalid"
            raise ValueError(msg) from None
        identity = (
            bounds.min_column,
            bounds.min_row,
            bounds.max_column,
            bounds.max_row,
        )
        if identity in ranges:
            msg = "Workbook contains duplicate merged ranges"
            raise ValueError(msg)
        ranges[identity] = cell_range
    return ranges


def _cell_position(coordinate: str) -> tuple[int, int]:
    bounds = excel_range_bounds(coordinate)
    if bounds.min_column != bounds.max_column or bounds.min_row != bounds.max_row:
        msg = "Workbook worksheet contains invalid cell references"
        raise ValueError(msg)
    return bounds.min_row, bounds.min_column


def _cell_without_coordinate(element: Element) -> bytes:
    clone = cast("Element", element.cloneNode(deep=True))
    clone.removeAttribute("r")
    return clone.toxml(encoding="utf-8")


def _restore_duplicate_merged_nonanchors(
    source_root: Element,
    output_root: Element,
    namespace: str,
    modified_merged_ranges: frozenset[str],
) -> None:
    source_ranges = _merged_range_bounds(source_root, namespace)
    output_ranges = _merged_range_bounds(output_root, namespace)
    unchanged = sorted(
        bounds
        for bounds in set(source_ranges) & set(output_ranges)
        if source_ranges[bounds] not in modified_merged_ranges
    )
    if not unchanged:
        return
    source_cells = {
        element.getAttribute("r"): element
        for element in _cell_elements(source_root, namespace)
    }
    output_cells = {
        element.getAttribute("r"): element
        for element in _cell_elements(output_root, namespace)
    }
    for minimum_column, minimum_row, maximum_column, maximum_row in unchanged:
        anchor = next(
            (
                coordinate
                for coordinate in source_cells
                if _cell_position(coordinate) == (minimum_row, minimum_column)
            ),
            None,
        )
        if anchor is None or anchor not in output_cells:
            continue
        source_anchor = source_cells[anchor]
        output_anchor = output_cells[anchor]
        for coordinate, source_cell in sorted(source_cells.items()):
            row, column = _cell_position(coordinate)
            if (
                not (
                    minimum_column <= column <= maximum_column
                    and minimum_row <= row <= maximum_row
                )
                or (column, row) == (minimum_column, minimum_row)
                or _cell_without_coordinate(source_cell)
                != _cell_without_coordinate(source_anchor)
            ):
                continue
            replacement = cast("Element", output_anchor.cloneNode(deep=True))
            replacement.setAttribute("r", coordinate)
            existing = output_cells.get(coordinate)
            if existing is None:
                continue
            parent = existing.parentNode
            if parent is None:
                msg = "Workbook worksheet contains invalid cell references"
                raise ValueError(msg)
            parent.replaceChild(replacement, existing)
            output_cells[coordinate] = replacement


def _insert_worksheet_element(
    root: Element,
    element: Element,
    namespace: str,
    local_name: str,
) -> None:
    rank = _WORKSHEET_CHILD_ORDER.index(local_name)
    reference = next(
        (
            child
            for child in _direct_elements(root)
            if child.namespaceURI == namespace
            and child.localName in _WORKSHEET_CHILD_ORDER
            and _WORKSHEET_CHILD_ORDER.index(child.localName) > rank
        ),
        None,
    )
    root.insertBefore(element, reference)


def _restore_direct_worksheet_element(
    source_root: Element,
    output_document: Document,
    output_root: Element,
    namespace: str,
    local_name: str,
) -> None:
    source_element = _direct_worksheet_element(source_root, namespace, local_name)
    output_element = _direct_worksheet_element(output_root, namespace, local_name)
    if source_element is None:
        if output_element is not None:
            output_root.removeChild(output_element)
        return
    replacement = output_document.importNode(source_element, deep=True)
    if output_element is not None:
        output_root.replaceChild(replacement, output_element)
    else:
        _insert_worksheet_element(
            output_root,
            replacement,
            namespace,
            local_name,
        )


def _restore_direct_worksheet_elements(
    source_root: Element,
    output_document: Document,
    output_root: Element,
    namespace: str,
    local_name: str,
) -> None:
    source_elements = tuple(
        child
        for child in _direct_elements(source_root)
        if _spreadsheet_element(child, local_name, namespace)
    )
    for element in tuple(_direct_elements(output_root)):
        if _spreadsheet_element(element, local_name, namespace):
            output_root.removeChild(element)
    for source_element in source_elements:
        _insert_worksheet_element(
            output_root,
            output_document.importNode(source_element, deep=True),
            namespace,
            local_name,
        )


def _restore_worksheet_state_payload(  # noqa: PLR0913
    source: bytes,
    output: bytes,
    *,
    preserve_sheet_views: bool,
    preserve_auto_filter: bool,
    preserve_conditional_formatting: bool,
    preserve_data_validations: bool,
) -> bytes:
    _source_document, source_root, source_namespace = _worksheet_document(source)
    output_document, output_root, output_namespace = _worksheet_document(output)
    if source_namespace != output_namespace:
        msg = "Patched workbook worksheet namespace changed"
        raise ValueError(msg)
    for index in range(source_root.attributes.length):
        attribute = cast("Attr | None", source_root.attributes.item(index))
        if attribute is not None and not output_root.hasAttribute(attribute.name):
            output_root.setAttribute(attribute.name, attribute.value)
    names = [
        "cols",
        "customSheetViews",
        "hyperlinks",
        "drawing",
        "legacyDrawing",
        "legacyDrawingHF",
        "picture",
        "oleObjects",
        "controls",
        "pageSetup",
        "tableParts",
        "extLst",
    ]
    if preserve_sheet_views:
        names.append("sheetViews")
    if preserve_auto_filter:
        names.append("autoFilter")
    if preserve_data_validations:
        names.append("dataValidations")
    for local_name in names:
        _restore_direct_worksheet_element(
            source_root,
            output_document,
            output_root,
            output_namespace,
            local_name,
        )
    if preserve_conditional_formatting:
        _restore_direct_worksheet_elements(
            source_root,
            output_document,
            output_root,
            output_namespace,
            "conditionalFormatting",
        )
    return _serialize_xml(output_document)


def _replace_output_package(
    output_path: Path,
    replacements: dict[str, bytes],
    *,
    label: str,
    additions: dict[str, bytes] | None = None,
) -> None:
    extra_members = additions or {}
    if not replacements and not extra_members:
        return
    with NamedTemporaryFile(
        dir=output_path.parent,
        prefix=f".{output_path.name}.{label}.",
        suffix=output_path.suffix,
        delete=False,
    ) as temporary_file:
        replacement_path = Path(temporary_file.name)
    try:
        _copy_package(
            output_path,
            replacement_path,
            replacements,
            source_fingerprint=calculate_sha256(output_path).value,
            additions=extra_members,
        )
        os.replace(replacement_path, output_path)  # noqa: PTH105 - atomic API.
    finally:
        replacement_path.unlink(missing_ok=True)


def _package_document(
    payload: bytes,
    *,
    namespace: str,
    label: str,
) -> tuple[Document, Element]:
    document = minidom.parseString(  # noqa: S318 - bounded, DTD-screened OOXML.
        payload
    )
    root = _document_root(document)
    if root.namespaceURI != namespace:
        msg = f"Workbook {label} namespace is unsupported"
        raise ValueError(msg)
    return document, root


def _metadata_relationship(element: Element) -> bool:
    return (
        element.namespaceURI == _RELATIONSHIPS_NAMESPACE
        and element.localName == "Relationship"
        and element.getAttribute("Type").rsplit("/", 1)[-1] == "sheetMetadata"
    )


def _restore_metadata_relationship(source: bytes, output: bytes) -> bytes:
    _source_document, source_root = _package_document(
        source,
        namespace=_RELATIONSHIPS_NAMESPACE,
        label="relationship",
    )
    output_document, output_root = _package_document(
        output,
        namespace=_RELATIONSHIPS_NAMESPACE,
        label="relationship",
    )
    source_matches = tuple(
        child
        for child in _direct_elements(source_root)
        if _metadata_relationship(child)
    )
    output_matches = tuple(
        child
        for child in _direct_elements(output_root)
        if _metadata_relationship(child)
    )
    if len(source_matches) != 1 or len(output_matches) > 1:
        msg = "Workbook metadata relationship is invalid"
        raise ValueError(msg)
    source_relationship = source_matches[0]
    if source_relationship.getAttribute("Target") not in {
        "metadata.xml",
        "/xl/metadata.xml",
    } or source_relationship.getAttribute("TargetMode") not in {"", "Internal"}:
        msg = "Workbook metadata relationship target is invalid"
        raise ValueError(msg)
    replacement = output_document.importNode(source_relationship, deep=True)
    if output_matches:
        output_relationship_id = output_matches[0].getAttribute("Id")
        if not output_relationship_id:
            msg = "Workbook metadata relationship identifier is invalid"
            raise ValueError(msg)
        replacement.setAttribute("Id", output_relationship_id)
        output_root.replaceChild(replacement, output_matches[0])
        return output_document.toxml(encoding="utf-8")

    used_ids = {
        child.getAttribute("Id")
        for child in _direct_elements(output_root)
        if child.namespaceURI == _RELATIONSHIPS_NAMESPACE
        and child.localName == "Relationship"
    }
    relationship_id = replacement.getAttribute("Id")
    if not relationship_id:
        msg = "Workbook metadata relationship identifier is invalid"
        raise ValueError(msg)
    if relationship_id in used_ids:
        suffix = 1
        while f"rIdMetadata{suffix}" in used_ids:
            suffix += 1
        replacement.setAttribute("Id", f"rIdMetadata{suffix}")
    output_root.appendChild(replacement)
    return output_document.toxml(encoding="utf-8")


def _metadata_content_type(element: Element) -> bool:
    return (
        element.namespaceURI == _CONTENT_TYPES_NAMESPACE
        and element.localName == "Override"
        and element.getAttribute("PartName") == _METADATA_PART_NAME
    )


def _restore_metadata_content_type(source: bytes, output: bytes) -> bytes:
    _source_document, source_root = _package_document(
        source,
        namespace=_CONTENT_TYPES_NAMESPACE,
        label="content-type",
    )
    output_document, output_root = _package_document(
        output,
        namespace=_CONTENT_TYPES_NAMESPACE,
        label="content-type",
    )
    source_matches = tuple(
        child
        for child in _direct_elements(source_root)
        if _metadata_content_type(child)
    )
    output_matches = tuple(
        child
        for child in _direct_elements(output_root)
        if _metadata_content_type(child)
    )
    if len(source_matches) != 1 or len(output_matches) > 1:
        msg = "Workbook metadata content type is invalid"
        raise ValueError(msg)
    if source_matches[0].getAttribute("ContentType") != _METADATA_CONTENT_TYPE:
        msg = "Workbook metadata content type is invalid"
        raise ValueError(msg)
    replacement = output_document.importNode(source_matches[0], deep=True)
    if output_matches:
        output_root.replaceChild(replacement, output_matches[0])
    else:
        output_root.appendChild(replacement)
    return output_document.toxml(encoding="utf-8")


def _member_payload(package: _SafePackage, member: str) -> bytes:
    with package.open_xml_stream(member) as stream:
        return stream.read()


def preserve_dynamic_array_metadata(
    source_path: Path,
    output_path: Path,
    *,
    source_fingerprint: str,
) -> None:
    """Restore untouched dynamic-array metadata package reachability."""
    replacements: dict[str, bytes] = {}
    additions: dict[str, bytes] = {}
    with (
        _SafePackage(source_path) as source_package,
        _SafePackage(output_path) as output_package,
    ):
        source_package.verify_fingerprint(source_fingerprint)
        if not source_package.has(_METADATA_MEMBER):
            return
        source_metadata = _member_payload(source_package, _METADATA_MEMBER)
        if output_package.has(_METADATA_MEMBER):
            replacements[_METADATA_MEMBER] = source_metadata
        else:
            additions[_METADATA_MEMBER] = source_metadata
        for member, restore in (
            (_WORKBOOK_RELATIONSHIPS_MEMBER, _restore_metadata_relationship),
            (_CONTENT_TYPES_MEMBER, _restore_metadata_content_type),
        ):
            source_payload = _member_payload(source_package, member)
            output_payload = _member_payload(output_package, member)
            restored = restore(source_payload, output_payload)
            if restored != output_payload:
                replacements[member] = restored
    _replace_output_package(
        output_path,
        replacements,
        additions=additions,
        label="dynamic-array-metadata",
    )


def preserve_untargeted_cell_styles(  # noqa: PLR0913
    source_path: Path,
    output_path: Path,
    *,
    targets: dict[str, frozenset[str]],
    metadata_targets: dict[str, frozenset[str]],
    modified_merged_ranges: dict[str, frozenset[str]],
    source_fingerprint: str,
) -> None:
    """Restore style and metadata IDs for existing non-target worksheet cells."""
    replacements: dict[str, bytes] = {}
    with (
        _SafePackage(source_path) as source_package,
        _SafePackage(output_path) as output_package,
    ):
        source_package.verify_fingerprint(source_fingerprint)
        _source_workbook, source_records = _workbook_records(source_package)
        _output_workbook, output_records = _workbook_records(output_package)
        output_by_name = {record.name: record for record in output_records}
        for source_record in source_records:
            style_requested = targets.get(
                source_record.name.casefold(),
                frozenset(),
            )
            metadata_requested = metadata_targets.get(
                source_record.name.casefold(),
                frozenset(),
            )
            modified_ranges = modified_merged_ranges.get(
                source_record.name.casefold(),
                frozenset(),
            )
            output_record = output_by_name.get(source_record.name)
            if (
                source_record.sheet_type != "worksheet"
                or source_record.part_name is None
                or output_record is None
                or output_record.sheet_type != "worksheet"
                or output_record.part_name is None
            ):
                continue
            with (
                source_package.open_xml_stream(
                    source_record.part_name
                ) as source_stream,
                output_package.open_xml_stream(
                    output_record.part_name
                ) as output_stream,
            ):
                source_payload = source_stream.read()
                output_payload = output_stream.read()
            restored = _restore_payload(
                source_payload,
                output_payload,
                style_targets=style_requested,
                metadata_targets=metadata_requested,
                modified_merged_ranges=modified_ranges,
            )
            if restored != output_payload:
                replacements[output_record.part_name] = restored
    if not replacements:
        return

    with NamedTemporaryFile(
        dir=output_path.parent,
        prefix=f".{output_path.name}.cell-styles.",
        suffix=output_path.suffix,
        delete=False,
    ) as temporary_file:
        replacement_path = Path(temporary_file.name)
    try:
        _copy_package(
            output_path,
            replacement_path,
            replacements,
            source_fingerprint=calculate_sha256(output_path).value,
        )
        os.replace(replacement_path, output_path)  # noqa: PTH105 - atomic API.
    finally:
        replacement_path.unlink(missing_ok=True)


def preserve_untargeted_worksheet_state(  # noqa: PLR0913
    source_path: Path,
    output_path: Path,
    *,
    freeze_pane_targets: frozenset[str],
    auto_filter_targets: frozenset[str],
    conditional_formatting_targets: frozenset[str],
    data_validation_targets: frozenset[str],
    source_fingerprint: str,
) -> None:
    """Restore package state that an unrelated backend rewrite may normalize."""
    replacements: dict[str, bytes] = {}
    with (
        _SafePackage(source_path) as source_package,
        _SafePackage(output_path) as output_package,
    ):
        source_package.verify_fingerprint(source_fingerprint)
        _source_workbook, source_records = _workbook_records(source_package)
        _output_workbook, output_records = _workbook_records(output_package)
        output_by_name = {record.name: record for record in output_records}
        for source_record in source_records:
            output_record = output_by_name.get(source_record.name)
            if (
                source_record.sheet_type != "worksheet"
                or source_record.part_name is None
                or output_record is None
                or output_record.sheet_type != "worksheet"
                or output_record.part_name is None
            ):
                continue
            with (
                source_package.open_xml_stream(
                    source_record.part_name
                ) as source_stream,
                output_package.open_xml_stream(
                    output_record.part_name
                ) as output_stream,
            ):
                source_payload = source_stream.read()
                output_payload = output_stream.read()
            restored = _restore_worksheet_state_payload(
                source_payload,
                output_payload,
                preserve_sheet_views=(
                    source_record.name.casefold() not in freeze_pane_targets
                ),
                preserve_auto_filter=(
                    source_record.name.casefold() not in auto_filter_targets
                ),
                preserve_conditional_formatting=(
                    source_record.name.casefold() not in conditional_formatting_targets
                ),
                preserve_data_validations=(
                    source_record.name.casefold() not in data_validation_targets
                ),
            )
            if restored != output_payload:
                replacements[output_record.part_name] = restored
    _replace_output_package(
        output_path,
        replacements,
        label="worksheet-state",
    )


def _element_style_id(element: Element) -> int:
    value = element.getAttribute("s") if element.hasAttribute("s") else "0"
    try:
        style_id = int(value)
    except ValueError:
        msg = "Workbook cell style identifier is invalid"
        raise ValueError(msg) from None
    if style_id < 0:
        msg = "Workbook cell style identifier is invalid"
        raise ValueError(msg)
    return style_id


def _source_style_id(value: str | None) -> int:
    if value is None:
        return 0
    try:
        style_id = int(value)
    except ValueError:
        msg = "Workbook cell style identifier is invalid"
        raise ValueError(msg) from None
    if style_id < 0:
        msg = "Workbook cell style identifier is invalid"
        raise ValueError(msg)
    return style_id


def _worksheet_style_context(
    root: Element,
    namespace: str,
) -> tuple[dict[int, int], list[dict[str, str] | None]]:
    row_styles = {
        row: _source_style_id(element.getAttribute("s"))
        for row, element in _row_elements(root, namespace)
        if element.hasAttribute("s")
    }
    columns = _direct_worksheet_element(root, namespace, "cols")
    return row_styles, _existing_states(columns, namespace)


def _inherited_style_id(
    coordinate: str,
    row_styles: dict[int, int],
    column_states: list[dict[str, str] | None],
) -> int:
    bounds = excel_range_bounds(coordinate)
    row_style = row_styles.get(bounds.min_row)
    if row_style is not None:
        return row_style
    column_state = column_states[bounds.min_column]
    if column_state is not None and "style" in column_state:
        return _source_style_id(column_state["style"])
    return 0


def _format_settings(patch: CellFormatPatch) -> dict[str, object]:
    return {
        field: value
        for field in (
            "font",
            "fill",
            "border",
            "alignment",
            "number_format",
            "named_style",
            "quote_prefix",
            "pivot_button",
        )
        if (value := getattr(patch, field)) is not None
    }


def _format_base_style_id(  # noqa: PLR0913
    element: Element,
    coordinate: str,
    patch: CellFormatPatch,
    *,
    source_cell_present: bool,
    source_direct_style: str | None,
    source_row_styles: dict[int, int],
    source_column_states: list[dict[str, str] | None],
    output_row_styles: dict[int, int],
    output_column_states: list[dict[str, str] | None],
) -> int:
    if patch.named_style is not None:
        return _element_style_id(element)
    if source_cell_present and source_direct_style is not None:
        return _source_style_id(source_direct_style)
    if source_cell_present:
        return _inherited_style_id(
            coordinate,
            source_row_styles,
            source_column_states,
        )
    if element.hasAttribute("s"):
        return _element_style_id(element)
    return _inherited_style_id(
        coordinate,
        output_row_styles,
        output_column_states,
    )


def _write_direct_style_id(  # noqa: PLR0913
    element: Element,
    coordinate: str,
    style_id: int,
    style_table: _ColumnStyleTable,
    *,
    source_cell_present: bool,
    source_direct_style: str | None,
    output_row_styles: dict[int, int],
    output_column_states: list[dict[str, str] | None],
) -> None:
    if style_id != 0:
        element.setAttribute("s", str(style_id))
        return
    inherited_style_id = _inherited_style_id(
        coordinate,
        output_row_styles,
        output_column_states,
    )
    direct_identity_required = (
        not source_cell_present
        or source_direct_style is not None
        or style_table.fingerprint(inherited_style_id)
        != style_table.fingerprint(style_id)
    )
    if direct_identity_required:
        element.setAttribute("s", "0")
    elif element.hasAttribute("s"):
        element.removeAttribute("s")


def _reapply_worksheet_formats(
    source_payload: bytes | None,
    output_payload: bytes,
    requested: dict[str, CellFormatPatch],
    style_table: _ColumnStyleTable,
) -> bytes:
    output_document, output_root, output_namespace = _worksheet_document(output_payload)
    source_styles: dict[str, str | None] = {}
    source_row_styles: dict[int, int] = {}
    source_column_states: list[dict[str, str] | None] = []
    if source_payload is not None:
        _source_document, source_root, source_namespace = _worksheet_document(
            source_payload
        )
        if source_namespace != output_namespace:
            msg = "Patched workbook worksheet namespace changed"
            raise ValueError(msg)
        source_styles = {
            coordinate: state["s"]
            for coordinate, state in _cell_references(
                source_root,
                source_namespace,
            ).items()
        }
        source_row_styles, source_column_states = _worksheet_style_context(
            source_root,
            source_namespace,
        )
    output_row_styles, output_column_states = _worksheet_style_context(
        output_root,
        output_namespace,
    )
    output_cells = {
        element.getAttribute("r"): element
        for element in _cell_elements(output_root, output_namespace)
    }
    if not set(requested).issubset(output_cells):
        msg = "Workbook format patch cell does not exist"
        raise ValueError(msg)
    for coordinate, patch in requested.items():
        element = output_cells[coordinate]
        source_cell_present = coordinate in source_styles
        source_direct_style = source_styles.get(coordinate)
        base_style_id = _format_base_style_id(
            element,
            coordinate,
            patch,
            source_cell_present=source_cell_present,
            source_direct_style=source_direct_style,
            source_row_styles=source_row_styles,
            source_column_states=source_column_states,
            output_row_styles=output_row_styles,
            output_column_states=output_column_states,
        )
        style_id = style_table.resolve(base_style_id, _format_settings(patch))
        _write_direct_style_id(
            element,
            coordinate,
            style_id,
            style_table,
            source_cell_present=source_cell_present,
            source_direct_style=source_direct_style,
            output_row_styles=output_row_styles,
            output_column_states=output_column_states,
        )
    return output_document.toxml(encoding="utf-8")


def reapply_targeted_cell_formats(  # noqa: C901
    source_path: Path,
    output_path: Path,
    patches: tuple[CellFormatPatch, ...],
    *,
    source_fingerprint: str,
) -> None:
    """Reapply requested components over source styles at package level."""
    if not patches:
        return
    by_sheet: dict[str, dict[str, CellFormatPatch]] = {}
    for patch in patches:
        targets = by_sheet.setdefault(patch.sheet_name.casefold(), {})
        if patch.coordinate in targets:
            msg = "Workbook format patch coordinates must be unique"
            raise ValueError(msg)
        targets[patch.coordinate] = patch

    replacements: dict[str, bytes] = {}
    with (
        _SafePackage(source_path) as source_package,
        _SafePackage(output_path) as output_package,
    ):
        source_package.verify_fingerprint(source_fingerprint)
        if not output_package.has("xl/styles.xml"):
            msg = "Workbook styles part does not exist"
            raise ValueError(msg)
        with output_package.open_xml_stream("xl/styles.xml") as styles_stream:
            style_table = _ColumnStyleTable.parse(styles_stream.read())
        _source_workbook, source_records = _workbook_records(source_package)
        _output_workbook, output_records = _workbook_records(output_package)
        source_by_name = {record.name.casefold(): record for record in source_records}
        output_by_name = {record.name.casefold(): record for record in output_records}
        for sheet_key, requested in by_sheet.items():
            source_record = source_by_name.get(sheet_key)
            output_record = output_by_name.get(sheet_key)
            if (
                output_record is None
                or output_record.sheet_type != "worksheet"
                or output_record.part_name is None
            ):
                msg = "Workbook format patch worksheet does not exist"
                raise ValueError(msg)
            source_payload: bytes | None = None
            if source_record is not None:
                if (
                    source_record.sheet_type != "worksheet"
                    or source_record.part_name is None
                ):
                    msg = "Workbook format patch worksheet does not exist"
                    raise ValueError(msg)
                with source_package.open_xml_stream(
                    source_record.part_name
                ) as source_stream:
                    source_payload = source_stream.read()
            with output_package.open_xml_stream(
                output_record.part_name
            ) as output_stream:
                output_payload = output_stream.read()
            updated = _reapply_worksheet_formats(
                source_payload,
                output_payload,
                requested,
                style_table,
            )
            if updated != output_payload:
                replacements[output_record.part_name] = updated
        if style_table.changed:
            replacements["xl/styles.xml"] = style_table.payload()
    _replace_output_package(
        output_path,
        replacements,
        label="targeted-cell-formats",
    )

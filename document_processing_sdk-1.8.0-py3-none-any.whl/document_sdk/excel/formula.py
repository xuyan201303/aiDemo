"""Dependency-free OOXML formula metadata inspection."""

from __future__ import annotations

import re
from dataclasses import dataclass, replace
from types import MappingProxyType
from typing import TYPE_CHECKING, Literal
from xml.etree.ElementTree import iterparse
from zipfile import ZipFile

from document_sdk.core._excel_coordinates import (
    ExcelRangeBounds,
    excel_range_bounds,
    normalize_excel_range,
)
from document_sdk.excel._ooxml import (
    _cell_coordinate,
    _ensure_no_dtd,
    _local_name,
    _row_index,
    _workbook_relationships,
    _workbook_sheets,
    _worksheet_member,
)
from document_sdk.excel._source_identity import open_verified_binary
from document_sdk.excel._worksheet_xml import _worksheet_child, _worksheet_events

if TYPE_CHECKING:
    from collections.abc import Mapping
    from pathlib import Path
    from xml.etree.ElementTree import Element


type FormulaKind = Literal["ordinary", "shared", "array", "dynamic_array"]
type FormulaMetadataIndex = Mapping[tuple[str, str], "FormulaMetadata"]

_EXTERNAL_REFERENCE_PATTERN = re.compile(
    r"(?:'[^']*\[[^][]+\][^']*'|\[[^][]+\][^!']*)!",
)


@dataclass(frozen=True, slots=True)
class FormulaMetadata:
    """OOXML formula facts that openpyxl does not expose consistently."""

    kind: FormulaKind
    shared_index: int | None
    formula_range: str | None
    external_reference: bool
    cache_element_present: bool
    has_cached_value: bool

    @property
    def is_ordinary(self) -> bool:
        """Return whether this is an ordinary scalar formula."""
        return self.kind == "ordinary"

    @property
    def is_shared(self) -> bool:
        """Return whether this cell participates in a shared formula."""
        return self.kind == "shared"

    @property
    def is_array(self) -> bool:
        """Return whether this is a legacy array formula."""
        return self.kind == "array"

    @property
    def is_dynamic_array(self) -> bool:
        """Return whether cell metadata marks this as a dynamic array."""
        return self.kind == "dynamic_array"


@dataclass(frozen=True, slots=True)
class _FormulaRecord:
    """One formula record before shared-formula flags are propagated."""

    coordinate: str
    metadata: FormulaMetadata
    formula_text: str | None


def _normalized_formula_range(element: Element) -> str | None:
    """Normalize an optional OOXML array or shared-formula range."""
    reference = element.attrib.get("ref")
    if reference is None:
        return None
    return normalize_excel_range(reference.replace("$", ""))


def _shared_index(element: Element) -> int | None:
    """Return a validated shared-formula index when present."""
    value = element.attrib.get("si")
    if value is None:
        return None
    index = int(value)
    if index < 0:
        msg = "shared formula index must not be negative"
        raise ValueError(msg)
    return index


def _has_external_reference(formula_text: str | None) -> bool:
    """Detect an external workbook reference without exposing its target."""
    return bool(
        formula_text and _EXTERNAL_REFERENCE_PATTERN.search(formula_text) is not None
    )


def _dynamic_metadata_indexes(archive: ZipFile) -> frozenset[int]:
    """Return one-based cell-metadata indexes carrying XLDAPR properties."""
    member = "xl/metadata.xml"
    if member not in archive.namelist():
        return frozenset()

    metadata_types: list[str] = []
    dynamic_indexes: set[int] = set()
    inside_cell_metadata = False
    block_index = 0

    _ensure_no_dtd(archive, member)
    with archive.open(member) as stream:
        for event, element in iterparse(  # noqa: S314 - DTDs rejected above.
            stream,
            events=("start", "end"),
        ):
            name = _local_name(element.tag)
            if event == "start":
                if name == "cellMetadata":
                    inside_cell_metadata = True
                continue

            if name == "metadataType":
                type_name = element.attrib.get("name")
                if type_name is not None:
                    metadata_types.append(type_name)
                element.clear()
            elif name == "bk" and inside_cell_metadata:
                block_index += 1
                type_indexes = {
                    int(candidate.attrib["t"])
                    for candidate in element.iter()
                    if _local_name(candidate.tag) == "rc" and "t" in candidate.attrib
                }
                if any(
                    0 < type_index <= len(metadata_types)
                    and metadata_types[type_index - 1] == "XLDAPR"
                    for type_index in type_indexes
                ):
                    dynamic_indexes.add(block_index)
                element.clear()
            elif name == "cellMetadata":
                inside_cell_metadata = False
                element.clear()

    return frozenset(dynamic_indexes)


def _formula_kind(
    cell: Element,
    formula: Element,
    *,
    dynamic_metadata_indexes: frozenset[int],
) -> FormulaKind:
    """Classify standard, shared, legacy-array, and dynamic-array formulas."""
    formula_type = formula.attrib.get("t", "normal")
    if formula_type == "shared":
        return "shared"
    if formula_type != "array":
        return "ordinary"

    metadata_index = cell.attrib.get("cm")
    if metadata_index is not None and int(metadata_index) in dynamic_metadata_indexes:
        return "dynamic_array"
    return "array"


def _worksheet_formula_records(
    archive: ZipFile,
    *,
    member: str,
    dynamic_metadata_indexes: frozenset[int],
    bounds: ExcelRangeBounds | None = None,
) -> tuple[_FormulaRecord, ...]:
    """Stream formula facts from one worksheet member."""
    records: list[_FormulaRecord] = []
    previous_row = 0
    current_row: int | None = None
    previous_cell_column = 0

    _ensure_no_dtd(archive, member)
    with archive.open(member) as stream:
        for event, element, name in _worksheet_events(stream):
            if event == "start":
                if name == "row":
                    current_row = _row_index(element, previous_row)
                    previous_cell_column = 0
                    if bounds is not None and current_row > bounds.max_row:
                        break
                continue

            if name == "c":
                coordinate, previous_cell_column = _cell_coordinate(
                    element,
                    current_row=current_row,
                    previous_column=previous_cell_column,
                )
                formula = _worksheet_child(element, "f")
                if formula is not None:
                    cache = _worksheet_child(element, "v")
                    formula_text = formula.text
                    metadata = FormulaMetadata(
                        kind=_formula_kind(
                            element,
                            formula,
                            dynamic_metadata_indexes=(dynamic_metadata_indexes),
                        ),
                        shared_index=_shared_index(formula),
                        formula_range=_normalized_formula_range(formula),
                        external_reference=_has_external_reference(formula_text),
                        cache_element_present=cache is not None,
                        has_cached_value=cache is not None and cache.text is not None,
                    )
                    coordinate_bounds = excel_range_bounds(coordinate)
                    in_bounds = bounds is None or (
                        bounds.min_row <= coordinate_bounds.min_row <= bounds.max_row
                        and bounds.min_column
                        <= coordinate_bounds.min_column
                        <= bounds.max_column
                    )
                    if in_bounds or (
                        metadata.kind == "shared" and metadata.external_reference
                    ):
                        records.append(
                            _FormulaRecord(
                                coordinate=coordinate,
                                metadata=metadata,
                                formula_text=formula_text,
                            )
                        )
                element.clear()
            elif name == "row":
                if current_row is None:
                    msg = "worksheet row state is invalid"
                    raise ValueError(msg)
                previous_row = current_row
                current_row = None
                previous_cell_column = 0
                element.clear()

    return tuple(records)


def _resolved_formula_metadata(
    records: tuple[_FormulaRecord, ...],
) -> dict[str, FormulaMetadata]:
    """Propagate external-reference state from shared-formula masters."""
    shared_external = {
        record.metadata.shared_index: True
        for record in records
        if record.metadata.kind == "shared"
        and record.metadata.shared_index is not None
        and record.metadata.external_reference
    }
    resolved: dict[str, FormulaMetadata] = {}
    for record in records:
        metadata = record.metadata
        if (
            metadata.kind == "shared"
            and metadata.shared_index is not None
            and shared_external.get(metadata.shared_index, False)
            and not metadata.external_reference
        ):
            metadata = replace(metadata, external_reference=True)
        if record.coordinate in resolved:
            msg = "worksheet contains a duplicate formula coordinate"
            raise ValueError(msg)
        resolved[record.coordinate] = metadata
    return resolved


def inspect_formula_metadata(
    path: Path,
    *,
    sheet_name: str | None = None,
    bounds: ExcelRangeBounds | None = None,
    expected_fingerprint: str | None = None,
) -> FormulaMetadataIndex:
    """Return immutable formula metadata indexed by sheet name and coordinate.

    Formula text and cached values are deliberately excluded. The helper reads
    only OOXML metadata, never evaluates formulas, and reports only whether a
    cached value exists.
    """
    indexed: dict[tuple[str, str], FormulaMetadata] = {}
    with (
        open_verified_binary(path, expected_fingerprint) as source,
        ZipFile(source, "r") as archive,
    ):
        sheets = _workbook_sheets(archive)
        relationships = _workbook_relationships(archive)
        dynamic_metadata_indexes = _dynamic_metadata_indexes(archive)
        for sheet in sheets:
            if sheet_name is not None and sheet.name != sheet_name:
                continue
            relationship = relationships.get(sheet.relationship_id)
            if relationship is None:
                msg = "workbook sheet relationship does not exist"
                raise ValueError(msg)
            member = _worksheet_member(relationship)
            records = _worksheet_formula_records(
                archive,
                member=member,
                dynamic_metadata_indexes=dynamic_metadata_indexes,
                bounds=bounds,
            )
            for coordinate, metadata in _resolved_formula_metadata(records).items():
                if bounds is not None:
                    coordinate_bounds = excel_range_bounds(coordinate)
                    if not (
                        bounds.min_row <= coordinate_bounds.min_row <= bounds.max_row
                        and bounds.min_column
                        <= coordinate_bounds.min_column
                        <= bounds.max_column
                    ):
                        continue
                indexed[(sheet.name, coordinate)] = metadata
    return MappingProxyType(indexed)

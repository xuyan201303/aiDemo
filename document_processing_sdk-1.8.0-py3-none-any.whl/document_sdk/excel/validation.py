"""Generic table schema validation over normalized worksheet data."""

from __future__ import annotations

import re
from collections import defaultdict
from datetime import date, datetime
from decimal import Decimal
from typing import TYPE_CHECKING

from document_sdk.core import ExcelSourceReference, WorksheetData
from document_sdk.core._excel_coordinates import (
    excel_column_letter,
    excel_range_bounds,
)
from document_sdk.excel._helpers import revalidate_excel_model
from document_sdk.excel.models import (
    ColumnSchema,
    ExcelPatchScalar,
    NormalizationOptions,
    NormalizedCell,
    NormalizedRow,
    TableSchema,
    TableValidationResult,
    ValidationIssue,
)
from document_sdk.excel.normalization import normalize_value

if TYPE_CHECKING:
    from document_sdk.core import ExcelCell


def _cell_value(cell: ExcelCell) -> ExcelPatchScalar:
    """Choose a non-calculating value view for generic validation."""
    if cell.formula is not None:
        return cell.formula
    if cell.formula_kind is not None:
        return None
    return cell.value


def _issue(  # noqa: PLR0913
    *,
    code: str,
    message: str,
    source: ExcelSourceReference,
    column: ColumnSchema | None = None,
    original_value: ExcelPatchScalar = None,
    normalized_value: ExcelPatchScalar = None,
) -> ValidationIssue:
    """Create one deterministic issue without embedding workbook content."""
    return ValidationIssue(
        code=code,
        message=message,
        column_name=None if column is None else column.name,
        source=source,
        original_value=original_value,
        normalized_value=normalized_value,
    )


def _compare_bounds(
    value: ExcelPatchScalar,
    column: ColumnSchema,
    *,
    source: ExcelSourceReference,
    original_value: ExcelPatchScalar,
) -> tuple[ValidationIssue, ...]:
    """Validate generic scalar, length, and allowed-value bounds."""
    issues: list[ValidationIssue] = []
    numeric_value = (
        Decimal(value)
        if isinstance(value, int) and not isinstance(value, bool)
        else value
        if isinstance(value, Decimal)
        else None
    )
    if isinstance(value, str):
        if column.minimum_length is not None and len(value) < column.minimum_length:
            issues.append(
                _issue(
                    code="minimum_length",
                    message="Value is shorter than the configured minimum.",
                    source=source,
                    column=column,
                    original_value=original_value,
                    normalized_value=value,
                )
            )
        if column.maximum_length is not None and len(value) > column.maximum_length:
            issues.append(
                _issue(
                    code="maximum_length",
                    message="Value is longer than the configured maximum.",
                    source=source,
                    column=column,
                    original_value=original_value,
                    normalized_value=value,
                )
            )
        if column.pattern is not None and re.fullmatch(column.pattern, value) is None:
            issues.append(
                _issue(
                    code="pattern",
                    message="Value does not match the configured pattern.",
                    source=source,
                    column=column,
                    original_value=original_value,
                    normalized_value=value,
                )
            )
    if column.allowed_values and value not in column.allowed_values:
        issues.append(
            _issue(
                code="allowed_values",
                message="Value is outside the configured allowed set.",
                source=source,
                column=column,
                original_value=original_value,
                normalized_value=value,
            )
        )
    try:
        below_minimum = (
            (
                isinstance(numeric_value, Decimal)
                and isinstance(column.minimum, Decimal)
                and numeric_value < column.minimum
            )
            or (
                isinstance(value, datetime)
                and isinstance(column.minimum, datetime)
                and value < column.minimum
            )
            or (
                isinstance(value, date)
                and not isinstance(value, datetime)
                and isinstance(column.minimum, date)
                and not isinstance(column.minimum, datetime)
                and value < column.minimum
            )
        )
    except TypeError:
        issues.append(
            _issue(
                code="bound_comparison",
                message="Value and bound timezone awareness are incompatible.",
                source=source,
                column=column,
                original_value=original_value,
                normalized_value=value,
            )
        )
        return tuple(issues)
    if below_minimum:
        issues.append(
            _issue(
                code="minimum",
                message="Value is below the configured minimum.",
                source=source,
                column=column,
                original_value=original_value,
                normalized_value=value,
            )
        )
    try:
        above_maximum = (
            (
                isinstance(numeric_value, Decimal)
                and isinstance(column.maximum, Decimal)
                and numeric_value > column.maximum
            )
            or (
                isinstance(value, datetime)
                and isinstance(column.maximum, datetime)
                and value > column.maximum
            )
            or (
                isinstance(value, date)
                and not isinstance(value, datetime)
                and isinstance(column.maximum, date)
                and not isinstance(column.maximum, datetime)
                and value > column.maximum
            )
        )
    except TypeError:
        issues.append(
            _issue(
                code="bound_comparison",
                message="Value and bound timezone awareness are incompatible.",
                source=source,
                column=column,
                original_value=original_value,
                normalized_value=value,
            )
        )
        return tuple(issues)
    if above_maximum:
        issues.append(
            _issue(
                code="maximum",
                message="Value is above the configured maximum.",
                source=source,
                column=column,
                original_value=original_value,
                normalized_value=value,
            )
        )
    return tuple(issues)


def _headers(
    data: WorksheetData,
    schema: TableSchema,
    options: NormalizationOptions,
) -> tuple[dict[str, tuple[ExcelCell, ...]], dict[int, ExcelCell]]:
    """Return every normalized header group and its physical cells."""
    grouped: dict[str, list[ExcelCell]] = defaultdict(list)
    by_column: dict[int, ExcelCell] = {}
    for cell in data.cells:
        bounds = excel_range_bounds(cell.coordinate)
        if bounds.min_row != schema.header_row:
            continue
        original = _cell_value(cell)
        normalized = normalize_value(
            original,
            options=options,
            target_type="string",
        ).normalized_value
        if isinstance(normalized, str):
            grouped[normalized.casefold()].append(cell)
            by_column[bounds.min_column] = cell
    return (
        {
            name: tuple(
                sorted(
                    cells,
                    key=lambda item: excel_range_bounds(item.coordinate).min_column,
                )
            )
            for name, cells in sorted(grouped.items())
        },
        by_column,
    )


def _header_key(value: str, options: NormalizationOptions) -> str:
    """Normalize one schema header through the same explicit text pipeline."""
    normalized = normalize_value(
        value,
        options=options,
        target_type="string",
    ).normalized_value
    if not isinstance(normalized, str):
        msg = "schema column name normalizes to a blank value"
        raise ValueError(msg)  # noqa: TRY004 - normalization produced no name.
    return normalized.casefold()


def validate_table(  # noqa: C901, PLR0912, PLR0915
    data: WorksheetData,
    schema: TableSchema,
    *,
    normalization: NormalizationOptions | None = None,
) -> TableValidationResult:
    """Validate worksheet data using only caller-provided generic rules."""
    validated_data = revalidate_excel_model(
        data,
        WorksheetData,
        "Worksheet data is invalid",
    )
    validated_schema = revalidate_excel_model(
        schema,
        TableSchema,
        "Table schema is invalid",
    )
    options = (
        NormalizationOptions()
        if normalization is None
        else revalidate_excel_model(
            normalization,
            NormalizationOptions,
            "Excel normalization options are invalid",
        )
    )
    data = validated_data
    schema = validated_schema
    header_groups, header_cells = _headers(data, schema, options)
    fallback_header_source = next(
        (cell.source for cell in header_cells.values()),
        ExcelSourceReference(
            file_id=data.file.file_id,
            sheet_name=data.sheet_name,
            cell_range=f"A{schema.header_row}",
        ),
    )
    issues: list[ValidationIssue] = []
    schema_by_header: dict[str, ColumnSchema] = {}
    for column in schema.columns:
        key = _header_key(column.name, options)
        if key in schema_by_header:
            msg = "schema column names collide after header normalization"
            raise ValueError(msg)
        schema_by_header[key] = column

    for header_name, cells in header_groups.items():
        if len(cells) <= 1:
            continue
        schema_column = schema_by_header.get(header_name)
        issues.extend(
            _issue(
                code="duplicate_header",
                message="Normalized table header is ambiguous.",
                source=cell.source,
                column=schema_column,
                original_value=_cell_value(cell),
                normalized_value=header_name,
            )
            for cell in cells
        )

    column_indexes: dict[str, int] = {}
    for column in schema.columns:
        key = _header_key(column.name, options)
        matching_headers = header_groups.get(key, ())
        if not matching_headers:
            if column.required:
                issues.append(
                    _issue(
                        code="required_column",
                        message="Required column is missing.",
                        column=column,
                        source=fallback_header_source,
                    )
                )
            continue
        if len(matching_headers) != 1:
            continue
        matched_column_index = excel_range_bounds(
            matching_headers[0].coordinate
        ).min_column
        column_indexes[column.name] = matched_column_index

    expected_names = set(schema_by_header)
    if not schema.allow_extra_columns:
        issues.extend(
            _issue(
                code="extra_column",
                message="An extra column is not allowed by the schema.",
                source=cell.source,
                original_value=_cell_value(cell),
                normalized_value=header_name,
            )
            for header_name in sorted(set(header_groups) - expected_names)
            for cell in header_groups[header_name]
        )

    cells_by_row: dict[int, dict[int, ExcelCell]] = defaultdict(dict)
    for cell in data.cells:
        bounds = excel_range_bounds(cell.coordinate)
        if bounds.min_row > schema.header_row:
            cells_by_row[bounds.min_row][bounds.min_column] = cell

    normalized_rows: list[NormalizedRow] = []
    unique_values: dict[str, dict[ExcelPatchScalar, ExcelSourceReference]] = {
        column.name: {} for column in schema.columns if column.unique
    }
    row_signatures: dict[tuple[ExcelPatchScalar, ...], int] = {}
    for row_number in sorted(cells_by_row):
        row_cells: list[NormalizedCell] = []
        signature: list[ExcelPatchScalar] = []
        row_conversion_failed = False
        for column in schema.columns:
            column_index = column_indexes.get(column.name)
            if column_index is None:
                signature.append(None)
                continue
            row_cell = cells_by_row[row_number].get(column_index)
            original = None if row_cell is None else _cell_value(row_cell)
            source = (
                ExcelSourceReference(
                    file_id=data.file.file_id,
                    sheet_name=data.sheet_name,
                    cell_range=f"{excel_column_letter(column_index)}{row_number}",
                )
                if row_cell is None
                else row_cell.source
            )
            normalized: ExcelPatchScalar = None
            conversion_failed = False
            formula_requires_recalculation = (
                row_cell is not None and row_cell.formula_kind is not None
            )
            if formula_requires_recalculation:
                conversion_failed = True
                row_conversion_failed = True
                issues.append(
                    _issue(
                        code="formula_requires_recalculation",
                        message=(
                            "Formula results cannot be validated without an "
                            "external recalculation."
                        ),
                        column=column,
                        source=source,
                        original_value=original,
                    )
                )
            elif original is not None:
                try:
                    normalized = normalize_value(
                        original,
                        options=options,
                        target_type=column.data_type,
                    ).normalized_value
                except ValueError:
                    conversion_failed = True
                    row_conversion_failed = True
                    issues.append(
                        _issue(
                            code="data_type",
                            message=(
                                "Value cannot be normalized to the configured type."
                            ),
                            column=column,
                            source=source,
                            original_value=original,
                        )
                    )
            if normalized is None and not conversion_failed and not column.nullable:
                issues.append(
                    _issue(
                        code="required_value",
                        message="A non-null value is required.",
                        column=column,
                        source=source,
                        original_value=original,
                    )
                )
            if normalized is not None:
                issues.extend(
                    _compare_bounds(
                        normalized,
                        column,
                        source=source,
                        original_value=original,
                    )
                )
                if column.unique:
                    previous = unique_values[column.name].get(normalized)
                    if previous is not None:
                        issues.append(
                            _issue(
                                code="unique",
                                message="Duplicate value violates uniqueness.",
                                column=column,
                                source=source,
                                original_value=original,
                                normalized_value=normalized,
                            )
                        )
                    else:
                        unique_values[column.name][normalized] = source
            row_cells.append(
                NormalizedCell(
                    column_name=column.name,
                    original_value=original,
                    normalized_value=normalized,
                    source=source,
                )
            )
            signature.append(normalized)
        signature_key = tuple(signature)
        comparable_signature = bool(row_cells) and not row_conversion_failed
        if (
            schema.require_unique_rows
            and comparable_signature
            and signature_key in row_signatures
        ):
            first_source = next(
                (cell.source for cell in row_cells),
                next(
                    (
                        cell.source
                        for _column, cell in sorted(cells_by_row[row_number].items())
                    ),
                    ExcelSourceReference(
                        file_id=data.file.file_id,
                        sheet_name=data.sheet_name,
                        cell_range=f"A{row_number}",
                    ),
                ),
            )
            issues.append(
                _issue(
                    code="duplicate_row",
                    message="Duplicate normalized row is not allowed.",
                    source=first_source,
                )
            )
        elif schema.require_unique_rows and comparable_signature:
            row_signatures[signature_key] = row_number
        normalized_rows.append(
            NormalizedRow(
                row_number=row_number,
                cells=tuple(row_cells),
            )
        )

    return TableValidationResult(
        valid=not any(issue.severity == "error" for issue in issues),
        table_schema=schema,
        rows=tuple(normalized_rows),
        issues=tuple(issues),
        source_file=data.file,
        sheet_name=data.sheet_name,
    )

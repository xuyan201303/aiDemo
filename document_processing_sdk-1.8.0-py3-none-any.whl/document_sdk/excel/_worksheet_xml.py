"""Coherent SpreadsheetML worksheet events shared by bounded readers."""

from __future__ import annotations

from typing import TYPE_CHECKING
from xml.etree.ElementTree import iterparse

from document_sdk.excel._visible_text import _SPREADSHEETML_NAMESPACES, _namespace

if TYPE_CHECKING:
    from collections.abc import Iterator
    from typing import IO
    from xml.etree.ElementTree import Element


_STRUCTURAL_PARENTS = {
    "sheetData": "worksheet",
    "row": "sheetData",
    "c": "row",
    "cols": "worksheet",
    "col": "cols",
    "mergeCells": "worksheet",
    "mergeCell": "mergeCells",
    "hyperlinks": "worksheet",
    "hyperlink": "hyperlinks",
}
_CELL_CONTENT_NAMES = frozenset({"v", "f", "is", "r", "t"})
_CELL_TYPES = frozenset({None, "n", "b", "d", "e", "s", "str", "inlineStr"})


def _validate_cell_type(element: Element) -> None:
    """Reject unknown stored cell kinds before a selected value can be omitted."""
    if element.get("t") not in _CELL_TYPES:
        msg = "Worksheet cell type is invalid"
        raise ValueError(msg)


def _worksheet_child(element: Element, name: str) -> Element | None:
    """Return a direct child in the same main namespace as its parent cell."""
    return element.find(f"{{{_namespace(element.tag)}}}{name}")


def _worksheet_event_name(
    tag: str,
    *,
    namespace: str,
    parent_name: str,
) -> str:
    """Keep core structure unambiguous without promoting extension lookalikes."""
    name = tag.rsplit("}", 1)[-1]
    actual_namespace = _namespace(tag)
    if actual_namespace != namespace:
        if (
            name in {"sheetData", "row", "c"}
            and _STRUCTURAL_PARENTS[name] == parent_name
        ) or (
            actual_namespace in _SPREADSHEETML_NAMESPACES
            and (name in _STRUCTURAL_PARENTS or name in _CELL_CONTENT_NAMES)
        ):
            msg = "Worksheet core elements use inconsistent namespaces"
            raise ValueError(msg)
        return ""
    if name in _STRUCTURAL_PARENTS and parent_name != _STRUCTURAL_PARENTS[name]:
        msg = "Worksheet core element has an invalid parent"
        raise ValueError(msg)
    return name if parent_name else ""


def _worksheet_events(stream: IO[bytes]) -> Iterator[tuple[str, Element, str]]:
    """Validate the root and core hierarchy while retaining only the tag stack.

    The caller must reject DTD/entity declarations and enforce its XML limits
    before supplying the stream. Foreign v/f and legal extension subtrees are
    left in the XML tree, but their local names cannot become worksheet facts.
    """
    names: list[str] = []
    namespace = ""
    for event, element in iterparse(  # noqa: S314 - caller rejects DTD/entities.
        stream, events=("start", "end")
    ):
        if event == "start":
            if not names:
                namespace = _namespace(element.tag)
                if (
                    namespace not in _SPREADSHEETML_NAMESPACES
                    or element.tag != f"{{{namespace}}}worksheet"
                ):
                    msg = "Worksheet root or namespace is invalid"
                    raise ValueError(msg)
                name = "worksheet"
            else:
                name = _worksheet_event_name(
                    element.tag, namespace=namespace, parent_name=names[-1]
                )
            names.append(name)
        else:
            name = names.pop()
        yield event, element, name

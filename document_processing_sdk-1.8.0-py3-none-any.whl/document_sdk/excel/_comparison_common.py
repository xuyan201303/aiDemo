# ruff: noqa: PLR0913
"""Shared bounded state and selection helpers for workbook comparison."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from document_sdk.core import DocumentProcessingError, ExcelSourceReference
from document_sdk.core._excel_coordinates import excel_range_bounds
from document_sdk.excel._streaming_ooxml import _represented_cells
from document_sdk.excel.errors import ExcelComparisonLimitError

if TYPE_CHECKING:
    from pathlib import Path

    from document_sdk.core import FileDescriptor
    from document_sdk.core._excel_coordinates import ExcelRangeBounds
    from document_sdk.excel._comparison_package import _WorksheetComparisonState
    from document_sdk.excel._streaming_ooxml import _RawCell
    from document_sdk.excel.models import (
        CellDiff,
        FeatureDiff,
        WorkbookComparisonOptions,
    )


@dataclass(slots=True)
class _SheetDiffBuilder:
    """Mutable bounded differences for one sheet."""

    cell_diffs: list[CellDiff] = field(default_factory=list)
    feature_diffs: list[FeatureDiff] = field(default_factory=list)


@dataclass(slots=True)
class _DiffCollector:
    """Apply one global deterministic difference limit."""

    maximum: int
    count: int = 0
    truncated: bool = False
    sheets_added: list[str] = field(default_factory=list)
    sheets_removed: list[str] = field(default_factory=list)
    workbook_features: list[FeatureDiff] = field(default_factory=list)
    sheets: dict[str, _SheetDiffBuilder] = field(default_factory=dict)

    def _accept(self) -> bool:
        if self.count >= self.maximum:
            self.truncated = True
            return False
        self.count += 1
        return True

    def add_sheet(self, name: str, *, added: bool) -> None:
        """Record one added or removed sheet if capacity remains."""
        if not self._accept():
            return
        target = self.sheets_added if added else self.sheets_removed
        target.append(name)

    def add_workbook_feature(self, difference: FeatureDiff) -> None:
        """Record one workbook-level feature difference."""
        if self._accept():
            self.workbook_features.append(difference)

    def add_cell(self, sheet_name: str, difference: CellDiff) -> None:
        """Record one cell difference."""
        if self._accept():
            self.sheets.setdefault(sheet_name, _SheetDiffBuilder()).cell_diffs.append(
                difference
            )

    def add_sheet_feature(self, sheet_name: str, difference: FeatureDiff) -> None:
        """Record one worksheet feature difference."""
        if self._accept():
            self.sheets.setdefault(
                sheet_name,
                _SheetDiffBuilder(),
            ).feature_diffs.append(difference)


@dataclass(frozen=True, slots=True)
class _PreparedSheetComparison:
    """Bounded sparse cell state prepared before feature loading."""

    sheet_name: str
    ranges: tuple[ExcelRangeBounds, ...]
    old_cells: dict[str, _RawCell]
    new_cells: dict[str, _RawCell]
    coordinates: tuple[str, ...]


def _source(
    descriptor: FileDescriptor,
    sheet_name: str,
    cell_range: str,
) -> ExcelSourceReference:
    """Build a traceable comparison source."""
    return ExcelSourceReference(
        file_id=descriptor.file_id,
        sheet_name=sheet_name,
        cell_range=cell_range,
    )


def _selected_sheet_order(
    old_names: tuple[str, ...],
    new_names: tuple[str, ...],
    options: WorkbookComparisonOptions,
) -> tuple[str, ...]:
    """Return deterministic comparison scope in caller or workbook order."""
    if options.selected_sheets:
        selected = options.selected_sheets
    elif options.selected_ranges:
        selected = tuple(
            dict.fromkeys(item.sheet_name for item in options.selected_ranges)
        )
    else:
        selected = old_names + tuple(
            name for name in new_names if name not in old_names
        )
    missing = [
        name for name in selected if name not in old_names and name not in new_names
    ]
    if missing:
        msg = f"Selected worksheet does not exist: {missing[0]}"
        raise DocumentProcessingError(msg)
    return selected


def _ranges_by_sheet(
    options: WorkbookComparisonOptions,
) -> dict[str, tuple[ExcelRangeBounds, ...]]:
    """Index optional selected ranges by exact worksheet name."""
    indexed: dict[str, list[ExcelRangeBounds]] = {}
    canonical_names = {name.casefold(): name for name in options.selected_sheets}
    for selection in options.selected_ranges:
        sheet_name = canonical_names.get(
            selection.sheet_name.casefold(),
            selection.sheet_name,
        )
        indexed.setdefault(sheet_name, []).append(
            excel_range_bounds(selection.cell_range)
        )
    return {name: tuple(ranges) for name, ranges in indexed.items()}


def _coordinate_key(coordinate: str) -> tuple[int, int]:
    """Return a row-major sort key."""
    bounds = excel_range_bounds(coordinate)
    return bounds.min_row, bounds.min_column


def _coordinate_selected(
    coordinate: str,
    ranges: tuple[ExcelRangeBounds, ...],
) -> bool:
    """Return whether a coordinate is in the selected range union."""
    if not ranges:
        return True
    row, column = _coordinate_key(coordinate)
    return any(
        bounds.min_row <= row <= bounds.max_row
        and bounds.min_column <= column <= bounds.max_column
        for bounds in ranges
    )


def _range_selected(
    cell_range: str,
    ranges: tuple[ExcelRangeBounds, ...],
) -> bool:
    """Return whether a feature range intersects the selected range union."""
    if not ranges:
        return True
    candidate = excel_range_bounds(cell_range)
    return any(
        candidate.min_row <= selected.max_row
        and candidate.max_row >= selected.min_row
        and candidate.min_column <= selected.max_column
        and candidate.max_column >= selected.min_column
        for selected in ranges
    )


def _column_selected(
    column: str,
    ranges: tuple[ExcelRangeBounds, ...],
) -> bool:
    """Return whether a column intersects the selected range union."""
    if not ranges:
        return True
    column_number = excel_range_bounds(f"{column}1").min_column
    return any(
        selected.min_column <= column_number <= selected.max_column
        for selected in ranges
    )


def _raw_cell_map(
    path: Path,
    sheet_name: str,
    *,
    ranges: tuple[ExcelRangeBounds, ...],
    ignore_empty: bool,
    known_coordinates: set[str],
    observed_offset: int,
    max_cells: int,
    expected_fingerprint: str,
) -> dict[str, _RawCell]:
    """Read represented cells without expanding their rectangular bounds."""
    result: dict[str, _RawCell] = {}
    unique_observed = observed_offset + len(known_coordinates)
    records = _represented_cells(
        path,
        sheet_name,
        expected_fingerprint=expected_fingerprint,
        selected_ranges=ranges,
    )
    try:
        for record in records:
            if not _coordinate_selected(record.coordinate, ranges):
                continue
            if ignore_empty and not record.has_content:
                continue
            if record.coordinate in result:
                msg = "worksheet contains a duplicate cell coordinate"
                raise DocumentProcessingError(msg)
            result[record.coordinate] = record
            if record.coordinate not in known_coordinates:
                unique_observed += 1
                if unique_observed > max_cells:
                    raise ExcelComparisonLimitError(
                        observed_cells=unique_observed,
                        max_cells=max_cells,
                    )
    finally:
        close = getattr(records, "close", None)
        if callable(close):
            close()
    return result


def _cell_coordinates_from_features(
    worksheet: _WorksheetComparisonState,
) -> set[str]:
    """Return single-cell locations carrying hyperlink or comment features."""
    return {
        reference.split(":", 1)[0]
        for reference in worksheet.hyperlinks.keys() | worksheet.comments.keys()
    }


def _prepare_sheet_comparisons(
    *,
    old_path: Path,
    new_path: Path,
    sheet_order: tuple[str, ...],
    selected_ranges: dict[str, tuple[ExcelRangeBounds, ...]],
    common_sheets: set[str],
    old_descriptor: FileDescriptor,
    new_descriptor: FileDescriptor,
    options: WorkbookComparisonOptions,
) -> tuple[_PreparedSheetComparison, ...]:
    """Prepare sparse selected cell state before worksheet feature loading."""
    prepared_sheets: list[_PreparedSheetComparison] = []
    observed_cells = 0
    for sheet_name in sheet_order:
        if sheet_name not in common_sheets:
            continue
        ranges = selected_ranges.get(sheet_name, ())
        old_cells = _raw_cell_map(
            old_path,
            sheet_name,
            ranges=ranges,
            ignore_empty=options.ignore_empty_cells,
            known_coordinates=set(),
            observed_offset=observed_cells,
            max_cells=options.max_cells,
            expected_fingerprint=old_descriptor.fingerprint.value,
        )
        new_cells = _raw_cell_map(
            new_path,
            sheet_name,
            ranges=ranges,
            ignore_empty=options.ignore_empty_cells,
            known_coordinates=set(old_cells),
            observed_offset=observed_cells,
            max_cells=options.max_cells,
            expected_fingerprint=new_descriptor.fingerprint.value,
        )
        coordinates = set(old_cells) | set(new_cells)
        observed_cells += len(coordinates)
        if observed_cells > options.max_cells:
            raise ExcelComparisonLimitError(
                observed_cells=observed_cells,
                max_cells=options.max_cells,
            )
        prepared_sheets.append(
            _PreparedSheetComparison(
                sheet_name=sheet_name,
                ranges=ranges,
                old_cells=old_cells,
                new_cells=new_cells,
                coordinates=tuple(sorted(coordinates, key=_coordinate_key)),
            )
        )
    return tuple(prepared_sheets)


def _attach_feature_coordinates(
    prepared_sheets: tuple[_PreparedSheetComparison, ...],
    *,
    old_states: dict[str, _WorksheetComparisonState],
    new_states: dict[str, _WorksheetComparisonState],
    max_cells: int,
) -> tuple[_PreparedSheetComparison, ...]:
    """Add selected hyperlink/comment cells under the same global cell bound."""
    completed: list[_PreparedSheetComparison] = []
    observed_cells = 0
    for prepared in prepared_sheets:
        coordinates = set(prepared.coordinates)
        coordinates.update(
            _cell_coordinates_from_features(old_states[prepared.sheet_name])
        )
        coordinates.update(
            _cell_coordinates_from_features(new_states[prepared.sheet_name])
        )
        observed_cells += len(coordinates)
        if observed_cells > max_cells:
            raise ExcelComparisonLimitError(
                observed_cells=observed_cells,
                max_cells=max_cells,
            )
        completed.append(
            _PreparedSheetComparison(
                sheet_name=prepared.sheet_name,
                ranges=prepared.ranges,
                old_cells=prepared.old_cells,
                new_cells=prepared.new_cells,
                coordinates=tuple(sorted(coordinates, key=_coordinate_key)),
            )
        )
    return tuple(completed)

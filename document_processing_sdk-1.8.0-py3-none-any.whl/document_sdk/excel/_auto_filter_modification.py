"""Typed basic automatic-filter range modification and verification."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import TYPE_CHECKING, cast
from xml.dom import Node, minidom
from xml.etree.ElementTree import tostring

from document_sdk.excel._column_modification import (
    _copy_package,
    _direct_elements,
    _document_root,
)
from document_sdk.excel._package import _SafePackage
from document_sdk.excel._package_security import _serialize_xml
from document_sdk.excel._package_workbook import _workbook_records
from document_sdk.excel._package_worksheet import (
    _SPREADSHEETML_WORKSHEET_NAMESPACES,
)
from document_sdk.excel._staging import create_staging_path
from document_sdk.excel._xml_namespaces import namespace_prefix
from document_sdk.excel.errors import ExcelModificationError
from document_sdk.files import calculate_sha256

if TYPE_CHECKING:
    from collections.abc import Sequence
    from pathlib import Path
    from xml.dom.minidom import Attr, Element, Text

    from openpyxl.workbook.workbook import Workbook
    from openpyxl.worksheet.worksheet import Worksheet

    from document_sdk.excel.models import AutoFilterPatch


@dataclass(frozen=True, slots=True)
class _PendingAutoFilterChange:
    """One requested filter range before public file identities exist."""

    sheet_name: str
    old_cell_range: str | None
    new_cell_range: str | None
    old_state_fingerprint: str
    new_state_fingerprint: str
    old_backend_fingerprint: str
    new_backend_fingerprint: str

    @property
    def changed(self) -> bool:
        """Return whether the requested range changes workbook semantics."""
        return self.old_state_fingerprint != self.new_state_fingerprint

    @property
    def backend_changed(self) -> bool:
        """Return whether openpyxl must rewrite the standard filter structure."""
        return self.old_backend_fingerprint != self.new_backend_fingerprint


_REVISION_NAMESPACE = "http://schemas.microsoft.com/office/spreadsheetml/2014/revision"
_XMLNS_NAMESPACE = "http://www.w3.org/2000/xmlns/"


def _worksheet(workbook: Workbook, sheet_name: str) -> Worksheet:
    matches = [
        worksheet
        for worksheet in workbook.worksheets
        if worksheet.title.casefold() == sheet_name.casefold()
    ]
    if len(matches) != 1:
        msg = "Workbook auto-filter worksheet does not exist"
        raise ExcelModificationError(msg)
    return matches[0]


def _range(worksheet: Worksheet) -> str | None:
    value = worksheet.auto_filter.ref
    return None if value is None else str(value).replace("$", "")


def _fingerprint(worksheet: Worksheet) -> str:
    auto_filter = worksheet.auto_filter
    payload = b"" if auto_filter.ref is None else tostring(auto_filter.to_tree())
    return hashlib.sha256(payload).hexdigest()


def _replace_filter(worksheet: Worksheet, patch: AutoFilterPatch) -> None:
    from openpyxl.worksheet.filters import (
        AutoFilter,
        ColorFilter,
        CustomFilter,
        CustomFilters,
        FilterColumn,
    )

    auto_filter = AutoFilter(ref=patch.cell_range)
    for value_filter in patch.value_filters:
        auto_filter.add_filter_column(
            value_filter.column_id,
            list(value_filter.values),
            blank=value_filter.include_blank,
        )
        column = auto_filter.filterColumn[-1]
        column.hiddenButton = value_filter.hidden_button
        column.showButton = value_filter.show_button
    for custom_filter in patch.custom_filters:
        auto_filter.filterColumn.append(
            FilterColumn(
                colId=custom_filter.column_id,
                hiddenButton=custom_filter.hidden_button,
                showButton=custom_filter.show_button,
                customFilters=CustomFilters(
                    _and=custom_filter.and_operator,
                    customFilter=tuple(
                        CustomFilter(
                            operator=criterion.operator,
                            val=criterion.value,
                        )
                        for criterion in custom_filter.criteria
                    ),
                ),
            )
        )
    for color_filter in patch.color_filters:
        auto_filter.filterColumn.append(
            FilterColumn(
                colId=color_filter.column_id,
                hiddenButton=color_filter.hidden_button,
                showButton=color_filter.show_button,
                colorFilter=ColorFilter(
                    dxfId=color_filter.differential_format_id,
                    cellColor=color_filter.cell_color,
                ),
            )
        )
    for condition in patch.sort_conditions:
        auto_filter.add_sort_condition(
            condition.cell_range,
            descending=condition.descending,
        )
    if auto_filter.sortState is not None:
        auto_filter.sortState.ref = patch.sort_range
    worksheet.auto_filter = auto_filter


def apply_auto_filter_patches(
    workbook: Workbook,
    patches: Sequence[AutoFilterPatch],
) -> tuple[_PendingAutoFilterChange, ...]:
    """Set basic worksheet filter ranges and retain verification evidence."""
    evidence: list[_PendingAutoFilterChange] = []
    for patch in patches:
        worksheet = _worksheet(workbook, patch.sheet_name)
        old_cell_range = _range(worksheet)
        old_state_fingerprint = _fingerprint(worksheet)
        new_cell_range = patch.cell_range
        _replace_filter(worksheet, patch)
        new_state_fingerprint = _fingerprint(worksheet)
        evidence.append(
            _PendingAutoFilterChange(
                sheet_name=worksheet.title,
                old_cell_range=old_cell_range,
                new_cell_range=new_cell_range,
                old_state_fingerprint=old_state_fingerprint,
                new_state_fingerprint=new_state_fingerprint,
                old_backend_fingerprint=old_state_fingerprint,
                new_backend_fingerprint=new_state_fingerprint,
            )
        )
    return tuple(evidence)


def verify_auto_filter_patches(
    workbook: Workbook,
    evidence: Sequence[_PendingAutoFilterChange],
) -> None:
    """Verify each requested basic filter range from the reopened workbook."""
    for expected in evidence:
        worksheet = _worksheet(workbook, expected.sheet_name)
        if (
            _range(worksheet) != expected.new_cell_range
            or _fingerprint(worksheet) != expected.new_backend_fingerprint
        ):
            msg = "Patched workbook auto-filter verification failed"
            raise ExcelModificationError(msg)


def _spreadsheet_child(parent: Element, local_name: str) -> Element | None:
    matches = tuple(
        child
        for child in _direct_elements(parent)
        if child.namespaceURI in _SPREADSHEETML_WORKSHEET_NAMESPACES
        and child.localName == local_name
    )
    if len(matches) > 1:
        msg = "Workbook worksheet contains duplicate auto-filter metadata"
        raise ValueError(msg)
    return matches[0] if matches else None


def _canonical_element(element: Element | None) -> tuple[object, ...] | None:
    if element is None:
        return None
    attributes = []
    for index in range(element.attributes.length):
        attribute = cast("Attr | None", element.attributes.item(index))
        if attribute is None or attribute.namespaceURI == _XMLNS_NAMESPACE:
            continue
        attributes.append(
            (
                attribute.namespaceURI or "",
                attribute.localName or attribute.name,
                attribute.value,
            )
        )
    text = "".join(
        cast("Text", child).data
        for child in element.childNodes
        if child.nodeType in {Node.TEXT_NODE, Node.CDATA_SECTION_NODE}
    ).strip()
    return (
        element.namespaceURI or "",
        element.localName or element.tagName,
        tuple(sorted(attributes)),
        text,
        tuple(_canonical_element(child) for child in _direct_elements(element)),
    )


def _filter_fingerprints(
    path: Path,
    sheet_names: Sequence[str],
    *,
    expected_fingerprint: str | None = None,
) -> dict[str, str]:
    requested = {name.casefold() for name in sheet_names}
    fingerprints: dict[str, str] = {}
    with _SafePackage(path) as package:
        if expected_fingerprint is not None:
            package.verify_fingerprint(expected_fingerprint)
        _workbook, records = _workbook_records(package)
        for record in records:
            key = record.name.casefold()
            if key not in requested:
                continue
            if (
                record.sheet_type != "worksheet"
                or record.part_name is None
                or not package.has(record.part_name)
            ):
                msg = "Workbook auto-filter worksheet does not exist"
                raise ExcelModificationError(msg)
            with package.open_xml_stream(record.part_name) as stream:
                document = minidom.parseString(  # noqa: S318 - bounded OOXML.
                    stream.read()
                )
            root = _document_root(document)
            auto_filter = _spreadsheet_child(root, "autoFilter")
            fingerprints[key] = hashlib.sha256(
                repr(_canonical_element(auto_filter)).encode("utf-8")
            ).hexdigest()
    if set(fingerprints) != requested:
        msg = "Workbook auto-filter worksheet does not exist"
        raise ExcelModificationError(msg)
    return fingerprints


def _remove_revision_uid(element: Element) -> None:
    for index in range(element.attributes.length - 1, -1, -1):
        attribute = cast("Attr | None", element.attributes.item(index))
        if (
            attribute is not None
            and attribute.namespaceURI == _REVISION_NAMESPACE
            and attribute.localName == "uid"
        ):
            element.removeAttributeNode(attribute)


def _apply_metadata(element: Element, patch: AutoFilterPatch) -> None:
    _remove_revision_uid(element)
    document = element.ownerDocument
    if document is None:
        msg = "Workbook auto-filter metadata document is invalid"
        raise ValueError(msg)
    root = _document_root(document)
    if patch.revision_uid is not None:
        prefix = namespace_prefix(root, _REVISION_NAMESPACE, "xr")
        element.setAttributeNS(
            _REVISION_NAMESPACE,
            f"{prefix}:uid",
            patch.revision_uid,
        )

    extension = _spreadsheet_child(element, "extLst")
    if extension is not None:
        element.removeChild(extension)
    if patch.extension_list == "empty":
        prefix = f"{element.prefix}:" if element.prefix else ""
        element.appendChild(
            document.createElementNS(
                element.namespaceURI,
                f"{prefix}extLst",
            )
        )


def _verify_metadata(element: Element | None, patch: AutoFilterPatch) -> None:
    if patch.cell_range is None:
        if element is not None:
            msg = "Patched workbook auto-filter metadata verification failed"
            raise ExcelModificationError(msg)
        return
    if element is None:
        msg = "Patched workbook auto-filter metadata verification failed"
        raise ExcelModificationError(msg)
    revision_uids = [
        cast("Attr", attribute).value
        for index in range(element.attributes.length)
        if (attribute := element.attributes.item(index)) is not None
        and attribute.namespaceURI == _REVISION_NAMESPACE
        and attribute.localName == "uid"
    ]
    extensions = tuple(
        child
        for child in _direct_elements(element)
        if child.namespaceURI in _SPREADSHEETML_WORKSHEET_NAMESPACES
        and child.localName == "extLst"
    )
    expected_uids = [] if patch.revision_uid is None else [patch.revision_uid]
    valid_extension = (
        not extensions
        if patch.extension_list == "absent"
        else len(extensions) == 1
        and extensions[0].attributes.length == 0
        and not tuple(_direct_elements(extensions[0]))
        and not any(
            child.nodeType in {Node.TEXT_NODE, Node.CDATA_SECTION_NODE}
            and cast("Text", child).data.strip()
            for child in extensions[0].childNodes
        )
    )
    if revision_uids != expected_uids or not valid_extension:
        msg = "Patched workbook auto-filter metadata verification failed"
        raise ExcelModificationError(msg)


def apply_persisted_auto_filter_metadata(  # noqa: PLR0913
    source_path: Path,
    output_path: Path,
    patches: Sequence[AutoFilterPatch],
    evidence: Sequence[_PendingAutoFilterChange],
    *,
    source_fingerprint: str,
    created_sheet_names: Sequence[str],
) -> tuple[_PendingAutoFilterChange, ...]:
    """Write and verify supported namespaced metadata at the OOXML boundary."""
    if not patches:
        return tuple(evidence)
    created = {name.casefold() for name in created_sheet_names}
    old_fingerprints = _filter_fingerprints(
        source_path,
        [
            patch.sheet_name
            for patch in patches
            if patch.sheet_name.casefold() not in created
        ],
        expected_fingerprint=source_fingerprint,
    )
    absent_fingerprint = hashlib.sha256(
        repr(_canonical_element(None)).encode("utf-8")
    ).hexdigest()
    old_fingerprints.update(
        (patch.sheet_name.casefold(), absent_fingerprint)
        for patch in patches
        if patch.sheet_name.casefold() in created
    )
    replacements: dict[str, bytes] = {}
    with _SafePackage(output_path) as package:
        _workbook, records = _workbook_records(package)
        by_name = {record.name.casefold(): record for record in records}
        for patch in patches:
            record = by_name.get(patch.sheet_name.casefold())
            if (
                record is None
                or record.sheet_type != "worksheet"
                or record.part_name is None
            ):
                msg = "Workbook auto-filter worksheet does not exist"
                raise ExcelModificationError(msg)
            with package.open_xml_stream(record.part_name) as stream:
                payload = stream.read()
            document = minidom.parseString(payload)  # noqa: S318 - bounded OOXML.
            root = _document_root(document)
            auto_filter = _spreadsheet_child(root, "autoFilter")
            if patch.cell_range is not None:
                if auto_filter is None:
                    msg = "Patched workbook auto-filter metadata is missing"
                    raise ExcelModificationError(msg)
                _apply_metadata(auto_filter, patch)
            _verify_metadata(auto_filter, patch)
            updated = _serialize_xml(document)
            if updated != payload:
                replacements[record.part_name] = updated

    if replacements:
        replacement_path = create_staging_path(
            output_path,
            output_path.suffix,
            purpose="auto-filter",
        )
        try:
            _copy_package(
                output_path,
                replacement_path,
                replacements,
                source_fingerprint=calculate_sha256(output_path).value,
            )
            replacement_path.replace(output_path)
        finally:
            replacement_path.unlink(missing_ok=True)

    new_fingerprints = _filter_fingerprints(
        output_path,
        [patch.sheet_name for patch in patches],
    )
    updated_evidence: list[_PendingAutoFilterChange] = []
    for item in evidence:
        key = item.sheet_name.casefold()
        updated_evidence.append(
            _PendingAutoFilterChange(
                sheet_name=item.sheet_name,
                old_cell_range=item.old_cell_range,
                new_cell_range=item.new_cell_range,
                old_state_fingerprint=old_fingerprints[key],
                new_state_fingerprint=new_fingerprints[key],
                old_backend_fingerprint=item.old_backend_fingerprint,
                new_backend_fingerprint=item.new_backend_fingerprint,
            )
        )
    return tuple(updated_evidence)

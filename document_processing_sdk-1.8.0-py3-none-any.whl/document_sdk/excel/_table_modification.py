"""Package-level resizing for existing worksheet tables."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, cast
from xml.dom import minidom

from document_sdk.core._excel_coordinates import excel_range_bounds
from document_sdk.excel._column_modification import (
    _copy_package,
    _direct_elements,
    _document_root,
)
from document_sdk.excel._package import _SafePackage
from document_sdk.excel._package_security import (
    _attribute_by_local_name,
    _local_name,
    _relationships,
)
from document_sdk.excel._package_workbook import _workbook_records
from document_sdk.excel._package_worksheet import (
    _SPREADSHEETML_WORKSHEET_NAMESPACES,
)
from document_sdk.excel.errors import ExcelModificationError

if TYPE_CHECKING:
    from collections.abc import Sequence
    from pathlib import Path
    from xml.dom.minidom import Document, Element

    from document_sdk.excel.models import TableColumnPatch, TableRangePatch


@dataclass(frozen=True, slots=True)
class _PendingTableRangeChange:
    """One verified table range change before public file IDs are known."""

    sheet_name: str
    table_name: str
    old_range: str
    new_range: str


@dataclass(frozen=True, slots=True)
class _TableTarget:
    """One uniquely resolved table part and its requested range."""

    sheet_name: str
    table_name: str
    member: str
    cell_range: str
    columns: tuple[TableColumnPatch, ...] | None


def _worksheet_table_members(package: _SafePackage, member: str) -> tuple[str, ...]:
    root = package.read_xml(member)
    if root.tag.partition("}")[0].removeprefix("{") not in (
        _SPREADSHEETML_WORKSHEET_NAMESPACES
    ):
        msg = "Workbook worksheet namespace is unsupported"
        raise ValueError(msg)
    relationships = _relationships(package, member)
    targets: list[str] = []
    for element in root.iter():
        if _local_name(element.tag) != "tablePart":
            continue
        relationship_id = _attribute_by_local_name(element, "id")
        relationship = relationships.get(relationship_id or "")
        if (
            relationship is None
            or relationship.external
            or relationship.target is None
            or relationship.relationship_type.rsplit("/", 1)[-1].casefold() != "table"
        ):
            msg = "Workbook table relationship is invalid"
            raise ValueError(msg)
        targets.append(relationship.target)
    if len(targets) != len(set(targets)):
        msg = "Workbook contains duplicate table relationships"
        raise ValueError(msg)
    return tuple(targets)


def _table_document(payload: bytes) -> tuple[Document, Element]:
    document = minidom.parseString(  # noqa: S318 - bounded, DTD-screened OOXML.
        payload
    )
    root = _document_root(document)
    if (
        root.namespaceURI not in _SPREADSHEETML_WORKSHEET_NAMESPACES
        or root.localName != "table"
    ):
        msg = "Workbook table namespace is unsupported"
        raise ValueError(msg)
    return document, root


def _resolve_targets(
    package: _SafePackage,
    patches: Sequence[TableRangePatch],
) -> tuple[_TableTarget, ...]:
    _workbook, sheets = _workbook_records(package)
    targets: list[_TableTarget] = []
    for patch in patches:
        sheet_matches = [
            sheet
            for sheet in sheets
            if sheet.name.casefold() == patch.sheet_name.casefold()
        ]
        if (
            len(sheet_matches) != 1
            or sheet_matches[0].sheet_type != "worksheet"
            or sheet_matches[0].part_name is None
        ):
            msg = "Workbook table patch worksheet does not exist"
            raise ExcelModificationError(msg)
        sheet = sheet_matches[0]
        sheet_part_name = sheet.part_name
        if sheet_part_name is None:
            msg = "Workbook table patch worksheet does not exist"
            raise ExcelModificationError(msg)
        table_matches: list[tuple[str, str]] = []
        for member in _worksheet_table_members(package, sheet_part_name):
            with package.open_xml_stream(member) as stream:
                _document, root = _table_document(stream.read())
            names = {
                value.casefold()
                for value in (
                    root.getAttribute("name"),
                    root.getAttribute("displayName"),
                )
                if value
            }
            if patch.table_name.casefold() in names:
                table_matches.append(
                    (
                        member,
                        root.getAttribute("displayName") or root.getAttribute("name"),
                    )
                )
        if len(table_matches) != 1:
            msg = "Workbook table patch target does not exist"
            raise ExcelModificationError(msg)
        member, actual_name = table_matches[0]
        targets.append(
            _TableTarget(
                sheet_name=sheet.name,
                table_name=actual_name,
                member=member,
                cell_range=patch.cell_range,
                columns=patch.columns,
            )
        )
    return tuple(targets)


def _resize_table(  # noqa: C901, PLR0912
    payload: bytes,
    target: _TableTarget,
) -> tuple[bytes, _PendingTableRangeChange | None]:
    document, root = _table_document(payload)
    old_range = root.getAttribute("ref")
    if not old_range:
        msg = "Workbook table range is missing"
        raise ValueError(msg)
    old_bounds = excel_range_bounds(old_range)
    new_bounds = excel_range_bounds(target.cell_range)
    if (
        old_bounds.min_row != new_bounds.min_row
        or old_bounds.min_column != new_bounds.min_column
    ):
        msg = "Table range patches must retain the header row and first column"
        raise ExcelModificationError(msg)
    columns = next(
        (
            element
            for element in _direct_elements(root)
            if element.namespaceURI in _SPREADSHEETML_WORKSHEET_NAMESPACES
            and element.localName == "tableColumns"
        ),
        None,
    )
    if columns is None:
        msg = "Workbook table columns are missing"
        raise ValueError(msg)
    expected_width = new_bounds.max_column - new_bounds.min_column + 1
    column_records = tuple(
        element
        for element in _direct_elements(columns)
        if element.namespaceURI in _SPREADSHEETML_WORKSHEET_NAMESPACES
        and element.localName == "tableColumn"
    )
    requested_columns = target.columns
    if requested_columns is None and len(column_records) != expected_width:
        msg = "Table range width does not match its column definitions"
        raise ExcelModificationError(msg)
    if requested_columns is not None:
        by_id = {element.getAttribute("id"): element for element in column_records}
        replacements: list[Element] = []
        for requested in requested_columns:
            identifier = str(requested.column_id)
            existing = by_id.get(identifier)
            element = (
                cast("Element", existing.cloneNode(deep=True))
                if existing is not None
                else document.createElementNS(root.namespaceURI, "tableColumn")
            )
            element.setAttribute("id", identifier)
            element.setAttribute("name", requested.name)
            if requested.totals_row_function is None:
                if element.hasAttribute("totalsRowFunction"):
                    element.removeAttribute("totalsRowFunction")
            else:
                element.setAttribute(
                    "totalsRowFunction",
                    requested.totals_row_function,
                )
            replacements.append(element)
        for element in column_records:
            columns.removeChild(element)
        for element in replacements:
            columns.appendChild(element)
        columns.setAttribute("count", str(len(replacements)))
    header_rows = int(root.getAttribute("headerRowCount") or "1")
    total_rows = int(root.getAttribute("totalsRowCount") or "0")
    if new_bounds.max_row - new_bounds.min_row + 1 < header_rows + total_rows:
        msg = "Table range is too small for its header and total rows"
        raise ExcelModificationError(msg)
    columns_changed = requested_columns is not None and tuple(
        (
            element.getAttribute("id"),
            element.getAttribute("name"),
            element.getAttribute("totalsRowFunction") or None,
        )
        for element in column_records
    ) != tuple(
        (
            str(column.column_id),
            column.name,
            column.totals_row_function,
        )
        for column in requested_columns
    )
    if old_range == target.cell_range and not columns_changed:
        return payload, None
    root.setAttribute("ref", target.cell_range)
    for element in root.getElementsByTagNameNS(root.namespaceURI, "autoFilter"):
        current = element.getAttribute("ref")
        if current and current != old_range:
            msg = "Workbook table filter range is inconsistent"
            raise ValueError(msg)
        element.setAttribute("ref", target.cell_range)
    return (
        document.toxml(encoding="utf-8"),
        _PendingTableRangeChange(
            sheet_name=target.sheet_name,
            table_name=target.table_name,
            old_range=old_range,
            new_range=target.cell_range,
        ),
    )


def create_table_range_patch_output(
    source_path: Path,
    output_path: Path,
    patches: Sequence[TableRangePatch],
    *,
    source_fingerprint: str,
) -> tuple[_PendingTableRangeChange, ...]:
    """Write and verify bounded existing-table range changes."""
    replacements: dict[str, bytes] = {}
    pending: list[_PendingTableRangeChange] = []
    with _SafePackage(source_path) as package:
        package.verify_fingerprint(source_fingerprint)
        package.reject_forbidden_xml_declarations()
        targets = _resolve_targets(package, patches)
        for target in targets:
            with package.open_xml_stream(target.member) as stream:
                replacement, change = _resize_table(stream.read(), target)
            if change is not None:
                replacements[target.member] = replacement
                pending.append(change)
    _copy_package(
        source_path,
        output_path,
        replacements,
        source_fingerprint=source_fingerprint,
    )
    with _SafePackage(output_path) as package:
        verified = _resolve_targets(package, patches)
        for target in verified:
            with package.open_xml_stream(target.member) as stream:
                _document, root = _table_document(stream.read())
            if root.getAttribute("ref") != target.cell_range:
                msg = "Workbook table range verification failed"
                raise ExcelModificationError(msg)
            if target.columns is not None:
                containers = tuple(
                    element
                    for element in _direct_elements(root)
                    if element.namespaceURI in _SPREADSHEETML_WORKSHEET_NAMESPACES
                    and element.localName == "tableColumns"
                )
                actual = (
                    tuple(
                        (
                            element.getAttribute("id"),
                            element.getAttribute("name"),
                            element.getAttribute("totalsRowFunction") or None,
                        )
                        for element in _direct_elements(containers[0])
                        if element.namespaceURI in _SPREADSHEETML_WORKSHEET_NAMESPACES
                        and element.localName == "tableColumn"
                    )
                    if len(containers) == 1
                    else ()
                )
                expected = tuple(
                    (
                        str(column.column_id),
                        column.name,
                        column.totals_row_function,
                    )
                    for column in target.columns
                )
                if actual != expected:
                    msg = "Workbook table column verification failed"
                    raise ExcelModificationError(msg)
    return tuple(pending)

"""Private openpyxl normalization helpers."""

from __future__ import annotations

from contextlib import contextmanager
from datetime import date, datetime, time
from typing import TYPE_CHECKING, cast

from pydantic import BaseModel

from document_sdk.core import (
    DocumentProcessingError,
    DocumentSdkError,
    FileDescriptor,
    UnsupportedFileError,
)
from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.errors import _raise_redacted_translation, safe_file_label
from document_sdk.excel._package import validate_package
from document_sdk.files import inspect_file

if TYPE_CHECKING:
    from collections.abc import Iterator
    from pathlib import Path

    from document_sdk.excel.models import ExcelPackageLimits

type NormalizedExcelValue = str | int | float | bool | date | datetime | time | None


def revalidate_excel_model[ModelT: BaseModel](
    value: object,
    expected_type: type[ModelT],
    message: str,
) -> ModelT:
    """Revalidate one public Excel model without calling instance hooks."""
    try:
        return _revalidate_model_instance_json(
            cast("BaseModel", value),
            expected_type,
            message,
        )
    except Exception as exc:  # noqa: BLE001 - public boundary is sanitized.
        _raise_redacted_translation(exc, DocumentProcessingError(message))


def validate_excel_package_limits(
    value: ExcelPackageLimits | None,
) -> ExcelPackageLimits | None:
    """Rebuild optional package limits at the public Excel boundary."""
    if value is None:
        return None
    from document_sdk.excel.models import ExcelPackageLimits

    return revalidate_excel_model(
        value,
        ExcelPackageLimits,
        "Excel package limits are invalid",
    )


def inspect_excel_input(
    path: Path,
    *,
    package_limits: ExcelPackageLimits | None = None,
) -> FileDescriptor:
    """Inspect a local input and enforce the Excel adapter's format boundary."""
    descriptor = inspect_file(path)
    if descriptor.extension not in {".xlsx", ".xlsm"}:
        msg = "Excel APIs require a .xlsx or .xlsm file"
        raise UnsupportedFileError(msg)
    try:
        validate_package(path, limits=package_limits)
    except DocumentSdkError:
        raise
    except Exception as exc:  # noqa: BLE001 - package boundary is sanitized.
        msg = f"Unable to inspect workbook package: {safe_file_label(path)}"
        _raise_redacted_translation(exc, DocumentProcessingError(msg))
    return descriptor


@contextmanager
def translate_excel_errors(path: Path, operation: str) -> Iterator[None]:
    """Translate backend failures without retaining sensitive cause messages."""
    try:
        yield
    except DocumentSdkError:
        raise
    except Exception as exc:  # noqa: BLE001 - adapter boundary normalizes backends.
        msg = f"Unable to {operation} workbook: {safe_file_label(path)}"
        _raise_redacted_translation(exc, DocumentProcessingError(msg))


def normalize_excel_value(value: object) -> NormalizedExcelValue:
    """Convert an openpyxl value to the SDK's supported scalar union."""
    if value is None or isinstance(
        value,
        (str, int, float, bool, date, datetime, time),
    ):
        return value
    return str(value)

"""Atomic, preservation-aware local workbook patching."""

from __future__ import annotations

import math
import os
import re
import warnings
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from decimal import Decimal
from shutil import copyfileobj
from typing import TYPE_CHECKING, Literal, cast
from xml.etree.ElementTree import iterparse

from document_sdk.core import (
    DocumentSdkError,
    ExcelSourceReference,
    FileAccessError,
    FileDescriptor,
    UnsupportedFileError,
)
from document_sdk.core._excel_coordinates import ExcelRangeBounds, excel_range_bounds
from document_sdk.core.errors import _raise_redacted_translation, safe_file_label
from document_sdk.excel._auto_filter_modification import (
    _PendingAutoFilterChange,
    apply_auto_filter_patches,
    apply_persisted_auto_filter_metadata,
    verify_auto_filter_patches,
)
from document_sdk.excel._cell_format_modification import (
    _PendingExistingCellFormatRangeChange,
    _PendingFormatChange,
    apply_existing_cell_format_range_patches,
    apply_format_patches,
    verify_existing_cell_format_range_patches,
    verify_format_patches,
    verify_persisted_format_borders,
)
from document_sdk.excel._cell_style_preservation import (
    preserve_dynamic_array_metadata,
    preserve_untargeted_cell_styles,
    preserve_untargeted_worksheet_state,
    reapply_targeted_cell_formats,
)
from document_sdk.excel._column_modification import (
    _PendingColumnChange,
    create_column_patch_output,
    public_column_range,
)
from document_sdk.excel._conditional_format_modification import (
    _PendingConditionalFormattingChange,
    apply_conditional_formatting_patches,
    verify_conditional_formatting_patches,
)
from document_sdk.excel._data_validation_modification import (
    _PendingDataValidationChange,
    apply_data_validation_patches,
    apply_persisted_data_validation_revision_uids,
    verify_data_validation_patches,
    verify_persisted_data_validation_revision_uids,
)
from document_sdk.excel._default_style_modification import (
    _PendingDefaultStyleChange,
    create_default_style_patch_output,
)
from document_sdk.excel._defined_name_preservation import (
    _PendingDefinedNameChange,
    apply_workbook_defined_name_patches,
    preserve_workbook_defined_names,
    workbook_defined_name_identity_counts,
)
from document_sdk.excel._dependencies import require_excel_support
from document_sdk.excel._external_link_modification import (
    create_external_link_cleanup_output,
    create_external_link_removal_output,
)
from document_sdk.excel._helpers import (
    inspect_excel_input,
    normalize_excel_value,
    revalidate_excel_model,
)
from document_sdk.excel._modification_vba import (
    _has_vba_project_evidence,
    _vba_evidence_issues,
    _vba_part_evidence,
)
from document_sdk.excel._named_style_modification import (
    apply_named_style_imports,
    verify_named_style_imports,
)
from document_sdk.excel._package import _SafePackage
from document_sdk.excel._package_graph_modification import (
    _PendingGraphChange,
    create_package_graph_patch_output,
)
from document_sdk.excel._package_part_preservation import (
    preserve_macro_sheet_workbook_state,
    preserve_opaque_package_parts,
    verify_chartsheet_preservation,
    verify_macro_sheet_preservation,
    verify_request_aware_image_preservation,
)
from document_sdk.excel._package_workbook import _workbook_records
from document_sdk.excel._package_worksheet import (
    _SPREADSHEETML_WORKSHEET_NAMESPACES,
)
from document_sdk.excel._package_zip import copy_with_deterministic_timestamps
from document_sdk.excel._row_modification import (
    _PendingRowChange,
    create_row_patch_output,
)
from document_sdk.excel._sheet_order_modification import (
    _PendingSheetOrderChange,
    create_sheet_order_patch_output,
)
from document_sdk.excel._source_identity import open_verified_binary
from document_sdk.excel._staging import create_staging_path, owned_staging_paths
from document_sdk.excel._structural_modification import (
    _PendingStructuralInsertion,
    create_structural_insertion_output,
)
from document_sdk.excel._table_modification import (
    _PendingTableRangeChange,
    create_table_range_patch_output,
)
from document_sdk.excel._worksheet_annotation_modification import (
    _PendingHyperlinkChange,
    _PendingLegacyCommentChange,
    create_worksheet_annotation_patch_output,
)
from document_sdk.excel.errors import (
    ExcelModificationError,
    ExcelPackageLimitError,
    WorkbookPreservationError,
)
from document_sdk.excel.models import (
    _EXCEL_ERROR_VALUES,
    AutoFilterModification,
    CellFormatModification,
    CellModification,
    CellPatchValue,
    ColumnDimensionModification,
    ConditionalFormattingModification,
    DataValidationModification,
    DefinedNameModification,
    DefinedNamePatch,
    ExistingCellFormatRangeModification,
    FreezePaneModification,
    HyperlinkModification,
    LegacyCommentsModification,
    MergedRangeModification,
    PreservationItem,
    RowDimensionModification,
    SheetVisibility,
    TableRangeModification,
    WorkbookDefaultStyleModification,
    WorkbookModificationResult,
    WorkbookPatchRequest,
    WorkbookPreservationReport,
    WorkbookSheetOrderModification,
    WorkbookStructuralModification,
    WorksheetCreationModification,
)
from document_sdk.excel.preservation import assess_workbook_preservation
from document_sdk.files import calculate_sha256

if TYPE_CHECKING:
    from collections.abc import Iterator, Sequence
    from pathlib import Path
    from typing import BinaryIO

    from openpyxl.cell.cell import Cell
    from openpyxl.workbook.defined_name import DefinedName
    from openpyxl.workbook.workbook import Workbook
    from openpyxl.worksheet.worksheet import Worksheet

    from document_sdk.core import FileFingerprint
    from document_sdk.excel._modification_vba import _VbaPartEvidence
    from document_sdk.excel.models import WorkbookSheetOrderPatch


type _PatchScalar = str | int | float | Decimal | bool | date | datetime | time | None
type _PatchTarget = tuple[str, str]

_VBA_PRESERVATION_WARNING = (
    "vba_preservation: VBA binary, content-type, or workbook relationship "
    "evidence is missing or changed"
)
_MAX_ARRAY_FORMULA_CELLS = 100_000
_FILTER_DATABASE_NAME = "_xlnm._FilterDatabase"
_EXCEL_MICROSECOND_DAYS = 1.0 / 86_400_000_000
_MAX_PLAIN_DECIMAL_CHARACTERS = 1_024
_SPREADSHEET_CELL_TAGS = frozenset(
    f"{{{namespace}}}c" for namespace in _SPREADSHEETML_WORKSHEET_NAMESPACES
)
_SPREADSHEET_ROW_TAGS = frozenset(
    f"{{{namespace}}}row" for namespace in _SPREADSHEETML_WORKSHEET_NAMESPACES
)
_SPREADSHEET_VALUE_TAGS = frozenset(
    f"{{{namespace}}}v" for namespace in _SPREADSHEETML_WORKSHEET_NAMESPACES
)


@dataclass(frozen=True, slots=True)
class _ResolvedPatch:
    """One unique worksheet cell target resolved before mutation."""

    sheet_name: str
    coordinate: str
    content: CellPatchValue


@dataclass(frozen=True, slots=True)
class _PendingChange:
    """Modification evidence collected before the output identity is known."""

    sheet_name: str
    coordinate: str
    old_value: _PatchScalar
    new_value: _PatchScalar
    old_formula: str | None
    new_formula: str | None
    number_format: str | None


@dataclass(frozen=True, slots=True)
class _PendingSheetCreation:
    """One created worksheet before output file identity is known."""

    sheet_name: str
    index: int
    visibility: SheetVisibility


@dataclass(frozen=True, slots=True)
class _PendingFreezePaneChange:
    """One frozen-pane change before public file identities are known."""

    sheet_name: str
    old_coordinate: str | None
    new_coordinate: str | None


@dataclass(frozen=True, slots=True)
class _PendingMergedRangeChange:
    """One merge-range operation before public file identities are known."""

    sheet_name: str
    cell_range: str
    operation: Literal["merge", "unmerge"]


def _apply_sheet_creations(
    workbook: Workbook,
    request: WorkbookPatchRequest,
) -> tuple[_PendingSheetCreation, ...]:
    pending: list[_PendingSheetCreation] = []
    names = {name.casefold() for name in workbook.sheetnames}
    for patch in request.create_sheets:
        if patch.name.casefold() in names or patch.index > len(workbook.sheetnames):
            msg = "Workbook worksheet creation target is invalid"
            raise ExcelModificationError(msg)
        worksheet = workbook.create_sheet(title=patch.name, index=patch.index)
        worksheet.sheet_state = patch.visibility
        names.add(patch.name.casefold())
        pending.append(
            _PendingSheetCreation(
                sheet_name=worksheet.title,
                index=patch.index,
                visibility=patch.visibility,
            )
        )
    return tuple(pending)


def _freeze_coordinate(worksheet: Worksheet) -> str | None:
    value = worksheet.freeze_panes
    if value is None:
        return None
    coordinate = value.coordinate if hasattr(value, "coordinate") else str(value)
    return None if coordinate == "A1" else coordinate


def _apply_freeze_panes(
    workbook: Workbook,
    request: WorkbookPatchRequest,
) -> tuple[_PendingFreezePaneChange, ...]:
    pending: list[_PendingFreezePaneChange] = []
    for patch in request.freeze_panes:
        worksheet = _worksheet(workbook, patch.sheet_name)
        old_coordinate = _freeze_coordinate(worksheet)
        if old_coordinate == patch.coordinate:
            continue
        worksheet.freeze_panes = patch.coordinate
        pending.append(
            _PendingFreezePaneChange(
                sheet_name=worksheet.title,
                old_coordinate=old_coordinate,
                new_coordinate=patch.coordinate,
            )
        )
    return tuple(pending)


def _ranges_overlap(first: ExcelRangeBounds, second: ExcelRangeBounds) -> bool:
    return not (
        first.max_row < second.min_row
        or second.max_row < first.min_row
        or first.max_column < second.min_column
        or second.max_column < first.min_column
    )


def _merge_range_is_empty(worksheet: Worksheet, cell_range: str) -> bool:
    bounds = excel_range_bounds(cell_range)
    anchor = (bounds.min_row, bounds.min_column)
    return all(
        (row, column) == anchor or cell.value is None
        for (row, column), cell in worksheet._cells.items()  # noqa: SLF001
        if bounds.min_row <= row <= bounds.max_row
        and bounds.min_column <= column <= bounds.max_column
    )


def _apply_merged_ranges(
    workbook: Workbook,
    request: WorkbookPatchRequest,
    *,
    operation: Literal["merge", "unmerge"],
) -> tuple[_PendingMergedRangeChange, ...]:
    pending: list[_PendingMergedRangeChange] = []
    for patch in request.merged_ranges:
        if patch.operation != operation:
            continue
        worksheet = _worksheet(workbook, patch.sheet_name)
        existing = {str(item) for item in worksheet.merged_cells.ranges}
        if operation == "merge":
            if patch.cell_range in existing:
                continue
            requested = excel_range_bounds(patch.cell_range)
            if any(
                _ranges_overlap(requested, excel_range_bounds(item))
                for item in existing
            ):
                msg = "Workbook merge patch overlaps an existing merged range"
                raise ExcelModificationError(msg)
            if not _merge_range_is_empty(worksheet, patch.cell_range):
                msg = "Workbook merge patch would replace non-anchor content"
                raise ExcelModificationError(msg)
            worksheet.merge_cells(patch.cell_range)
        else:
            if patch.cell_range not in existing:
                continue
            worksheet.unmerge_cells(patch.cell_range)
        pending.append(
            _PendingMergedRangeChange(
                sheet_name=worksheet.title,
                cell_range=patch.cell_range,
                operation=operation,
            )
        )
    return tuple(pending)


def _verify_sheet_structure(
    workbook: Workbook,
    freeze_changes: Sequence[_PendingFreezePaneChange],
    merge_changes: Sequence[_PendingMergedRangeChange],
) -> None:
    for change in freeze_changes:
        if _freeze_coordinate(_worksheet(workbook, change.sheet_name)) != (
            change.new_coordinate
        ):
            msg = "Patched workbook freeze pane verification failed"
            raise ExcelModificationError(msg)
    final_merge_changes = {
        (change.sheet_name.casefold(), change.cell_range): change
        for change in merge_changes
    }
    for merge_change in final_merge_changes.values():
        worksheet = _worksheet(workbook, merge_change.sheet_name)
        present = merge_change.cell_range in {
            str(item) for item in worksheet.merged_cells.ranges
        }
        if present != (merge_change.operation == "merge"):
            msg = "Patched workbook merged range verification failed"
            raise ExcelModificationError(msg)


def _verify_sheet_creations(
    workbook: Workbook,
    pending: Sequence[_PendingSheetCreation],
) -> None:
    for creation in pending:
        if creation.index >= len(workbook.sheetnames):
            msg = "Patched workbook worksheet creation verification failed"
            raise ExcelModificationError(msg)
        if workbook.sheetnames[creation.index] != creation.sheet_name:
            msg = "Patched workbook worksheet creation verification failed"
            raise ExcelModificationError(msg)
        worksheet = workbook[creation.sheet_name]
        if (
            worksheet.title != creation.sheet_name
            or worksheet.sheet_state != creation.visibility
        ):
            msg = "Patched workbook worksheet creation verification failed"
            raise ExcelModificationError(msg)


@contextmanager
def _translate_modification_errors(
    path: Path,
    operation: str,
) -> Iterator[None]:
    """Translate backend failures without retaining backend messages."""
    try:
        yield
    except DocumentSdkError:
        raise
    except Exception as exc:  # noqa: BLE001 - adapter boundary normalizes backends.
        msg = f"Unable to {operation} workbook: {safe_file_label(path)}"
        _raise_redacted_translation(exc, ExcelModificationError(msg))


def _workbook_descriptor(
    path: Path,
    *,
    file_id: str | None = None,
) -> FileDescriptor:
    """Inspect XLSX or XLSM input without adding paths to public models."""
    descriptor = inspect_excel_input(path)

    if file_id is None:
        return descriptor
    return FileDescriptor(
        file_id=file_id,
        filename=descriptor.filename,
        extension=descriptor.extension,
        mime_type=descriptor.mime_type,
        size_bytes=descriptor.size_bytes,
        fingerprint=descriptor.fingerprint,
    )


def _validate_destination(
    source_path: Path,
    output_path: Path,
    *,
    overwrite: bool,
) -> None:
    """Validate the output boundary before opening the workbook."""
    source_extension = source_path.suffix.lower()
    output_extension = output_path.suffix.lower()
    if source_extension == ".xlsm" and output_extension == ".xlsx":
        msg = "Macro-enabled workbooks cannot be patched to .xlsx"
        raise UnsupportedFileError(msg)
    if output_extension != source_extension:
        msg = "Patched workbook output must use the source extension"
        raise UnsupportedFileError(msg)
    if not output_path.parent.exists() or not output_path.parent.is_dir():
        msg = (
            f"Workbook output directory does not exist: "
            f"{safe_file_label(output_path.parent)}"
        )
        raise FileAccessError(msg)
    if output_path.exists():
        if not output_path.is_file():
            msg = (
                f"Workbook output is not a regular file: {safe_file_label(output_path)}"
            )
            raise FileAccessError(msg)
        if not overwrite:
            msg = f"Workbook output already exists: {safe_file_label(output_path)}"
            raise FileAccessError(msg)

    try:
        same_file = output_path.exists() and source_path.samefile(output_path)
        same_resolved_path = source_path.resolve() == output_path.resolve()
    except OSError as exc:
        msg = "Unable to validate workbook source and output locations"
        _raise_redacted_translation(exc, FileAccessError(msg))
    if same_file or same_resolved_path:
        msg = "Workbook source and output must be different files"
        raise ExcelModificationError(msg)


def _unsupported_features(
    report: WorkbookPreservationReport,
) -> tuple[str, ...]:
    """Return present features that the patch operation cannot preserve."""
    return tuple(
        item.feature
        for item in report.items
        if item.present and item.status == "UNSUPPORTED"
    )


def _preservation_warnings(
    report: WorkbookPreservationReport,
) -> tuple[str, ...]:
    """Return deterministic warnings for non-guaranteed present features."""
    warnings = list(report.warnings)
    warnings.extend(
        f"{item.feature}: {item.details}"
        for item in report.items
        if item.present and item.status != "SAFE"
    )
    return tuple(dict.fromkeys(warnings))


def _request_aware_preservation(
    report: WorkbookPreservationReport,
    request: WorkbookPatchRequest,
) -> WorkbookPreservationReport:
    """Describe request-specific package preservation guarantees."""
    targeted = bool(
        request.structural_insertions
        or request.delete_sheets
        or request.drawing_removals
        or request.image_additions
    )
    macro_structural_change = bool(
        request.create_sheets
        or request.delete_sheets
        or request.structural_insertions
        or request.sheet_order is not None
    )
    if not targeted and not macro_structural_change:
        return report
    items = []
    for item in report.items:
        if item.feature == "macro_sheets" and item.present and macro_structural_change:
            items.append(
                PreservationItem(
                    feature=item.feature,
                    present=True,
                    status="UNSUPPORTED",
                    disposition="unsupported",
                    details=(
                        "Worksheet structure or workbook order changes cannot safely "
                        "rewrite Excel 4.0 Macro Sheet references or scoped names."
                    ),
                )
            )
            continue
        if item.feature not in {"images", "shapes_drawings"} or not item.present:
            items.append(item)
            continue
        items.append(
            PreservationItem(
                feature=item.feature,
                present=True,
                status="SAFE_WITH_WARNINGS",
                disposition="expected_preserved",
                details=(
                    "Untargeted media, drawings, and relationships are preserved and "
                    "verified; requested additions, removals, or structurally shifted "
                    "anchors are verified against their requested final state."
                ),
            )
        )
    item_tuple = tuple(items)
    overall: Literal["SAFE", "SAFE_WITH_WARNINGS", "UNSUPPORTED"] = (
        "UNSUPPORTED"
        if any(item.present and item.status == "UNSUPPORTED" for item in item_tuple)
        else "SAFE_WITH_WARNINGS"
        if any(
            item.present and item.status == "SAFE_WITH_WARNINGS" for item in item_tuple
        )
        else "SAFE"
    )
    return WorkbookPreservationReport(
        file=report.file,
        operation=report.operation,
        overall_status=overall,
        items=item_tuple,
        warnings=tuple(
            f"{item.feature}: {item.details}"
            for item in item_tuple
            if item.present and item.status != "SAFE"
        ),
    )


def _worksheet(workbook: Workbook, sheet_name: str) -> Worksheet:
    """Return an exact named worksheet, excluding non-worksheet sheets."""
    for worksheet in workbook.worksheets:
        if worksheet.title == sheet_name:
            return worksheet
    msg = f"Worksheet does not exist: {sheet_name}"
    raise ExcelModificationError(msg)


def _defined_name(workbook: Workbook, requested_name: str) -> DefinedName:
    """Return one unambiguous global or worksheet-local defined name."""
    candidates = list(workbook.defined_names.values())
    for worksheet in workbook.worksheets:
        candidates.extend(worksheet.defined_names.values())
    matches = [
        defined_name
        for defined_name in candidates
        if isinstance(getattr(defined_name, "name", None), str)
        and defined_name.name.casefold() == requested_name.casefold()
    ]
    if not matches:
        msg = f"Workbook-defined name does not exist: {requested_name}"
        raise ExcelModificationError(msg)
    if len(matches) != 1:
        msg = f"Workbook-defined name is ambiguous: {requested_name}"
        raise ExcelModificationError(msg)
    return cast("DefinedName", matches[0])


def _named_range_target(
    workbook: Workbook,
    requested_name: str,
) -> tuple[Worksheet, tuple[int, int, int, int]]:
    """Resolve one finite internal global named range."""
    from openpyxl.utils.cell import range_boundaries

    defined_name = _defined_name(workbook, requested_name)
    if (
        getattr(defined_name, "is_external", False)
        or getattr(
            defined_name,
            "type",
            None,
        )
        != "RANGE"
    ):
        msg = f"Workbook-defined name is not an internal range: {requested_name}"
        raise ExcelModificationError(msg)
    try:
        destinations = tuple(defined_name.destinations)
    except Exception as exc:  # noqa: BLE001 - openpyxl parsing boundary.
        msg = f"Workbook-defined name is not a fillable range: {requested_name}"
        _raise_redacted_translation(exc, ExcelModificationError(msg))
    if len(destinations) != 1:
        msg = (
            f"Workbook-defined name must resolve to exactly one range: {requested_name}"
        )
        raise ExcelModificationError(msg)

    sheet_name, cell_range = destinations[0]
    worksheet = _worksheet(workbook, sheet_name)
    try:
        bounds = range_boundaries(cell_range)
    except ValueError as exc:
        msg = f"Workbook-defined name has an invalid range: {requested_name}"
        _raise_redacted_translation(exc, ExcelModificationError(msg))
    min_column, min_row, max_column, max_row = bounds
    if min_column is None or min_row is None or max_column is None or max_row is None:
        msg = f"Workbook-defined name must use a finite cell range: {requested_name}"
        raise ExcelModificationError(msg)
    return worksheet, (min_column, min_row, max_column, max_row)


def _resolve_patches(
    workbook: Workbook,
    request: WorkbookPatchRequest,
) -> tuple[_ResolvedPatch, ...]:
    """Resolve direct and named-range changes and reject target overlap."""
    from openpyxl.utils.cell import get_column_letter

    resolved: list[_ResolvedPatch] = []
    target_ranges: list[tuple[str, int, int, int, int]] = []

    def add_patch(patch: _ResolvedPatch) -> None:
        bounds = _resolved_patch_bounds(patch)
        sheet_key = patch.sheet_name.casefold()
        if any(
            sheet_key == other_sheet
            and bounds.min_column <= other_max_column
            and bounds.max_column >= other_min_column
            and bounds.min_row <= other_max_row
            and bounds.max_row >= other_min_row
            for (
                other_sheet,
                other_min_column,
                other_min_row,
                other_max_column,
                other_max_row,
            ) in target_ranges
        ):
            msg = "Workbook patch target ranges must not overlap"
            raise ExcelModificationError(msg)
        target_ranges.append(
            (
                sheet_key,
                bounds.min_column,
                bounds.min_row,
                bounds.max_column,
                bounds.max_row,
            )
        )
        resolved.append(patch)

    for patch in request.cells:
        worksheet = _worksheet(workbook, patch.sheet_name)
        add_patch(
            _ResolvedPatch(
                sheet_name=worksheet.title,
                coordinate=patch.coordinate,
                content=patch.content,
            )
        )

    for named_patch in request.named_ranges:
        worksheet, bounds = _named_range_target(workbook, named_patch.name)
        min_column, min_row, max_column, max_row = bounds
        expected_height = max_row - min_row + 1
        expected_width = max_column - min_column + 1
        if (
            len(named_patch.values) != expected_height
            or len(named_patch.values[0]) != expected_width
        ):
            msg = (
                f"Named-range patch dimensions do not match the target: "
                f"{named_patch.name}"
            )
            raise ExcelModificationError(msg)
        for row_offset, row in enumerate(named_patch.values):
            for column_offset, content in enumerate(row):
                coordinate = (
                    f"{get_column_letter(min_column + column_offset)}"
                    f"{min_row + row_offset}"
                )
                add_patch(
                    _ResolvedPatch(
                        sheet_name=worksheet.title,
                        coordinate=coordinate,
                        content=content,
                    )
                )

    return tuple(resolved)


def _resolved_patch_bounds(patch: _ResolvedPatch) -> ExcelRangeBounds:
    """Return bounded target geometry for one scalar or array patch."""
    target_range = patch.content.formula_range or patch.coordinate
    bounds = excel_range_bounds(target_range)
    if patch.content.formula_range is None:
        return bounds
    anchor_bounds = excel_range_bounds(patch.coordinate)
    if (
        anchor_bounds.min_column != bounds.min_column
        or anchor_bounds.min_row != bounds.min_row
    ):
        msg = "Array formula patch coordinate must match its range anchor"
        raise ExcelModificationError(msg)
    if bounds.cell_count > _MAX_ARRAY_FORMULA_CELLS:
        raise ExcelPackageLimitError(
            limit_name="array_formula_cells",
            observed=bounds.cell_count,
            maximum=_MAX_ARRAY_FORMULA_CELLS,
        )
    return bounds


def _ensure_merged_anchor(worksheet: Worksheet, coordinate: str) -> None:
    """Reject writes to merged cells other than the writable anchor."""
    from openpyxl.utils.cell import coordinate_to_tuple, range_boundaries

    row, column = coordinate_to_tuple(coordinate)
    for merged_range in worksheet.merged_cells.ranges:
        min_column, min_row, max_column, max_row = range_boundaries(str(merged_range))
        if (
            min_column is None
            or min_row is None
            or max_column is None
            or max_row is None
        ):  # pragma: no cover - openpyxl merged ranges are finite.
            msg = "Workbook contains an invalid merged-cell range"
            raise ExcelModificationError(msg)
        if (
            min_row <= row <= max_row
            and min_column <= column <= max_column
            and (row, column) != (min_row, min_column)
        ):
            msg = (
                f"Cannot patch a non-anchor merged cell: {worksheet.title}!{coordinate}"
            )
            raise ExcelModificationError(msg)


def _formula_text(cell: Cell) -> str | None:
    """Return normalized formula text from scalar or array formula cells."""
    if cell.data_type != "f":
        return None
    value = cell.value
    if isinstance(value, str):
        return value if value.startswith("=") else f"={value}"
    text = getattr(value, "text", None)
    if isinstance(text, str):
        return text if text.startswith("=") else f"={text}"
    return None


def _old_value(cell: Cell, old_formula: str | None) -> _PatchScalar:
    """Return a safe SDK scalar for modification evidence."""
    if old_formula is not None or cell.data_type == "f":
        return None
    value = cell.value
    if isinstance(value, Decimal):
        return value
    return normalize_excel_value(value)


def _canonical_decimal_text(value: Decimal) -> str:
    """Return exact deterministic OOXML numeric text without binary conversion."""
    if not value.is_finite():  # pragma: no cover - public model invariant.
        msg = "Workbook decimal patch value is not finite"
        raise ExcelModificationError(msg)
    sign, raw_digits, raw_exponent = value.as_tuple()
    digits = list(raw_digits)
    if not any(digits):
        return "0"
    exponent = cast("int", raw_exponent)
    while len(digits) > 1 and digits[-1] == 0:
        digits.pop()
        exponent += 1
    normalized = Decimal((sign, tuple(digits), exponent))
    decimal_position = len(digits) + exponent
    if exponent >= 0:
        plain_length = sign + decimal_position
    elif decimal_position > 0:
        plain_length = sign + len(digits) + 1
    else:
        plain_length = sign + 2 - decimal_position + len(digits)
    if plain_length <= _MAX_PLAIN_DECIMAL_CHARACTERS:
        return format(normalized, "f")
    return str(normalized)


def _set_ordinary_cell_value(cell: Cell, value: _PatchScalar) -> None:
    cell.value = value
    if isinstance(value, Decimal):
        cell._value = _canonical_decimal_text(  # type: ignore[attr-defined]  # noqa: SLF001
            value
        )
        cell.data_type = "n"
    elif isinstance(value, str) and (
        value.startswith("=") or value in _EXCEL_ERROR_VALUES
    ):
        cell.data_type = "s"


def _apply_patches(
    workbook: Workbook,
    patches: Sequence[_ResolvedPatch],
) -> tuple[_PendingChange, ...]:
    """Apply already resolved patches without replacing styles or layout."""
    original_values: dict[tuple[str, str], tuple[str | None, _PatchScalar]] = {}
    for patch in patches:
        worksheet = _worksheet(workbook, patch.sheet_name)
        cell = worksheet[patch.coordinate]
        old_formula = _formula_text(cell)
        original_values[(patch.sheet_name, patch.coordinate)] = (
            old_formula,
            _old_value(cell, old_formula),
        )

    changes: list[_PendingChange] = []
    for patch in patches:
        worksheet = _worksheet(workbook, patch.sheet_name)
        _ensure_merged_anchor(worksheet, patch.coordinate)
        cell = worksheet[patch.coordinate]
        old_formula, old_value = original_values[(patch.sheet_name, patch.coordinate)]

        if patch.content.kind == "clear":
            cell.value = None
            new_value: _PatchScalar = None
            new_formula = None
        elif patch.content.kind in {"formula", "array_formula"}:
            formula = patch.content.value
            if not isinstance(formula, str):  # pragma: no cover - model invariant.
                msg = "Formula patch value is invalid"
                raise ExcelModificationError(msg)
            if patch.content.kind == "array_formula":
                _apply_array_formula(worksheet, cell, patch, formula)
            else:
                cell.value = formula
            new_value = None
            new_formula = formula
        elif patch.content.kind == "error":
            cell.value = patch.content.value
            cell.data_type = "e"
            new_value = patch.content.value
            new_formula = None
        else:
            value = patch.content.value
            _set_ordinary_cell_value(cell, value)
            new_value = value
            new_formula = None

        if patch.content.number_format is not None:
            cell.number_format = patch.content.number_format

        changes.append(
            _PendingChange(
                sheet_name=patch.sheet_name,
                coordinate=patch.coordinate,
                old_value=old_value,
                new_value=new_value,
                old_formula=old_formula,
                new_formula=new_formula,
                number_format=cell.number_format,
            )
        )
    return tuple(changes)


def _apply_array_formula(  # noqa: C901
    worksheet: Worksheet,
    cell: Cell,
    patch: _ResolvedPatch,
    formula: str,
) -> None:
    """Write one bounded array formula without materializing blank range cells."""
    from openpyxl.worksheet.formula import ArrayFormula

    formula_range = patch.content.formula_range
    if formula_range is None:  # pragma: no cover - model invariant.
        msg = "Array formula patch range is invalid"
        raise ExcelModificationError(msg)
    bounds = excel_range_bounds(formula_range)
    existing_bounds: ExcelRangeBounds | None = None
    existing_reference = getattr(cell.value, "ref", None)
    if cell.data_type == "f" and isinstance(existing_reference, str):
        try:
            candidate = excel_range_bounds(existing_reference)
        except ValueError:
            msg = "Existing array formula range is invalid"
            raise ExcelModificationError(msg) from None
        anchor = excel_range_bounds(patch.coordinate)
        if (
            candidate.min_row == anchor.min_row
            and candidate.min_column == anchor.min_column
        ):
            existing_bounds = candidate
    requested_clears = set(patch.content.clear_existing_cells)
    occupied: set[str] = set()
    for (row, column), target in worksheet._cells.items():  # noqa: SLF001
        if (
            bounds.min_row <= row <= bounds.max_row
            and bounds.min_column <= column <= bounds.max_column
            and target.coordinate != patch.coordinate
            and target.value is not None
            and not (
                existing_bounds is not None
                and existing_bounds.min_row <= row <= existing_bounds.max_row
                and existing_bounds.min_column <= column <= existing_bounds.max_column
            )
        ):
            occupied.add(target.coordinate)
    if occupied != requested_clears:
        msg = "Array formula existing content does not match explicit clear targets"
        raise ExcelModificationError(msg)
    for coordinate in sorted(requested_clears):
        worksheet[coordinate].value = None
    if existing_bounds is not None:
        for (row, column), target in worksheet._cells.items():  # noqa: SLF001
            if (
                existing_bounds.min_row <= row <= existing_bounds.max_row
                and existing_bounds.min_column <= column <= existing_bounds.max_column
                and target.coordinate != patch.coordinate
            ):
                target.value = None
    cell.value = ArrayFormula(ref=formula_range, text=formula)


def _equivalent_value(
    actual: object,
    expected: _PatchScalar,
    *,
    epoch: datetime,
) -> bool:
    """Compare reopened values while accounting for Decimal serialization."""
    if (
        isinstance(expected, (int, float, Decimal))
        and not isinstance(expected, bool)
        and isinstance(actual, (date, datetime, time, timedelta))
    ):
        from openpyxl.utils.datetime import to_excel

        return math.isclose(
            float(expected),
            float(to_excel(actual, epoch)),  # type: ignore[no-untyped-call]
            rel_tol=0.0,
            abs_tol=_EXCEL_MICROSECOND_DAYS,
        )
    if isinstance(expected, Decimal):
        if isinstance(actual, bool) or not isinstance(actual, (int, float, Decimal)):
            return False
        return Decimal(str(actual)) == expected
    if (
        isinstance(expected, date)
        and not isinstance(expected, datetime)
        and isinstance(actual, datetime)
    ):
        return actual.date() == expected and (
            actual.hour,
            actual.minute,
            actual.second,
            actual.microsecond,
        ) == (0, 0, 0, 0)
    return actual == expected


def _decimal_patch_texts(
    patches: Sequence[_ResolvedPatch],
) -> dict[_PatchTarget, str]:
    return {
        (patch.sheet_name.casefold(), patch.coordinate): _canonical_decimal_text(value)
        for patch in patches
        if patch.content.kind == "value"
        and isinstance((value := patch.content.value), Decimal)
    }


def _verify_decimal_worksheet(
    package: _SafePackage,
    *,
    member: str,
    sheet_name: str,
    coordinates: dict[str, str],
) -> set[str]:
    observed: set[str] = set()
    with package.open_xml_stream(member) as stream:
        for _event, element in iterparse(  # noqa: S314 - DTD-screened stream.
            stream,
            events=("end",),
        ):
            if element.tag in _SPREADSHEET_ROW_TAGS:
                element.clear()
                continue
            if element.tag not in _SPREADSHEET_CELL_TAGS:
                continue
            coordinate = element.attrib.get("r")
            if coordinate not in coordinates:
                element.clear()
                continue
            if coordinate in observed:
                msg = "Patched workbook contains duplicate decimal cells"
                raise ExcelModificationError(msg)
            values = tuple(
                child for child in element if child.tag in _SPREADSHEET_VALUE_TAGS
            )
            if (
                element.attrib.get("t") not in {None, "n"}
                or len(values) != 1
                or values[0].text != coordinates[coordinate]
            ):
                msg = (
                    "Patched workbook decimal verification failed: "
                    f"{sheet_name}!{coordinate}"
                )
                raise ExcelModificationError(msg)
            observed.add(coordinate)
            element.clear()
    return observed


def _verify_exact_decimal_patches(
    path: Path,
    patches: Sequence[_ResolvedPatch],
) -> frozenset[_PatchTarget]:
    """Verify exact Decimal lexical values directly from bounded worksheet XML."""
    expected = _decimal_patch_texts(patches)
    if not expected:
        return frozenset()
    by_sheet: dict[str, dict[str, str]] = {}
    for (sheet_name, coordinate), value in expected.items():
        by_sheet.setdefault(sheet_name, {})[coordinate] = value

    verified: set[_PatchTarget] = set()
    with _SafePackage(path) as package:
        _workbook, records = _workbook_records(package)
        record_by_name = {record.name.casefold(): record for record in records}
        for sheet_name, coordinates in by_sheet.items():
            record = record_by_name.get(sheet_name)
            if (
                record is None
                or record.sheet_type != "worksheet"
                or record.part_name is None
                or not package.has(record.part_name)
            ):
                msg = "Patched workbook decimal worksheet does not exist"
                raise ExcelModificationError(msg)
            observed = _verify_decimal_worksheet(
                package,
                member=record.part_name,
                sheet_name=record.name,
                coordinates=coordinates,
            )
            verified.update((sheet_name, coordinate) for coordinate in observed)
            missing = set(coordinates) - observed
            if missing:
                coordinate = min(missing)
                msg = (
                    "Patched workbook decimal verification failed: "
                    f"{record.name}!{coordinate}"
                )
                raise ExcelModificationError(msg)
    if verified != set(expected):  # pragma: no cover - grouped-map invariant.
        msg = "Patched workbook decimal verification failed"
        raise ExcelModificationError(msg)
    return frozenset(verified)


def _verify_patches(
    workbook: Workbook,
    *,
    expected_sheet_names: tuple[str, ...],
    patches: Sequence[_ResolvedPatch],
    exact_decimal_targets: frozenset[_PatchTarget] = frozenset(),
) -> None:
    """Verify the temporary workbook reopened with every requested value."""
    if tuple(workbook.sheetnames) != expected_sheet_names:
        msg = "Patched workbook sheet verification failed"
        raise ExcelModificationError(msg)
    for patch in patches:
        worksheet = _worksheet(workbook, patch.sheet_name)
        cell = worksheet[patch.coordinate]
        if patch.content.kind == "clear":
            verified = cell.value is None
        elif patch.content.kind == "formula":
            verified = cell.value == patch.content.value
        elif patch.content.kind == "array_formula":
            value = cell.value
            verified = (
                getattr(value, "text", None) == patch.content.value
                and getattr(value, "ref", None) == patch.content.formula_range
                and cell.data_type == "f"
            )
        elif patch.content.kind == "error":
            verified = cell.value == patch.content.value and cell.data_type == "e"
        elif isinstance(patch.content.value, Decimal):
            verified = (
                patch.sheet_name.casefold(),
                patch.coordinate,
            ) in exact_decimal_targets
        else:
            verified = _equivalent_value(
                cell.value,
                patch.content.value,
                epoch=workbook.epoch,
            ) and not (
                isinstance(patch.content.value, str)
                and patch.content.value.startswith("=")
                and cell.data_type == "f"
            )
        if not verified:
            msg = (
                f"Patched workbook cell verification failed: "
                f"{patch.sheet_name}!{patch.coordinate}"
            )
            raise ExcelModificationError(msg)
        if (
            patch.content.number_format is not None
            and cell.number_format != patch.content.number_format
        ):
            msg = (
                f"Patched workbook number-format verification failed: "
                f"{patch.sheet_name}!{patch.coordinate}"
            )
            raise ExcelModificationError(msg)


def _source_is_unchanged(
    source_path: Path,
    expected_fingerprint: FileFingerprint,
) -> bool:
    """Compare the source fingerprint without exposing it."""
    return calculate_sha256(source_path) == expected_fingerprint


def _public_changes(
    pending: Sequence[_PendingChange],
    *,
    source_file_id: str,
    output_file_id: str,
) -> tuple[CellModification, ...]:
    """Attach source and output identities to verified changes."""
    return tuple(
        CellModification(
            sheet_name=change.sheet_name,
            coordinate=change.coordinate,
            old_value=change.old_value,
            new_value=change.new_value,
            old_formula=change.old_formula,
            new_formula=change.new_formula,
            number_format=change.number_format,
            source=ExcelSourceReference(
                file_id=source_file_id,
                sheet_name=change.sheet_name,
                cell_range=change.coordinate,
            ),
            output_source=ExcelSourceReference(
                file_id=output_file_id,
                sheet_name=change.sheet_name,
                cell_range=change.coordinate,
            ),
        )
        for change in pending
    )


def _public_format_changes(
    pending: Sequence[_PendingFormatChange],
    *,
    source_file_id: str,
    output_file_id: str,
) -> tuple[CellFormatModification, ...]:
    """Attach source and output identities to verified format changes."""
    return tuple(
        CellFormatModification(
            sheet_name=change.sheet_name,
            coordinate=change.coordinate,
            changed_components=change.changed_components,
            source=ExcelSourceReference(
                file_id=source_file_id,
                sheet_name=change.sheet_name,
                cell_range=change.coordinate,
            ),
            output_source=ExcelSourceReference(
                file_id=output_file_id,
                sheet_name=change.sheet_name,
                cell_range=change.coordinate,
            ),
        )
        for change in pending
    )


def _public_format_range_changes(
    pending: Sequence[_PendingExistingCellFormatRangeChange],
    *,
    source_file_id: str,
    output_file_id: str,
) -> tuple[ExistingCellFormatRangeModification, ...]:
    """Attach file identities to compact existing-cell range-format evidence."""
    return tuple(
        ExistingCellFormatRangeModification(
            sheet_name=change.sheet_name,
            cell_ranges=change.cell_ranges,
            target_cell_count=len(change.target_coordinates),
            changed_components=change.changed_components,
            source_file_id=source_file_id,
            output_file_id=output_file_id,
        )
        for change in pending
    )


def _public_sheet_creations(
    pending: Sequence[_PendingSheetCreation],
    *,
    output_file_id: str,
) -> tuple[WorksheetCreationModification, ...]:
    """Attach output identity to newly created worksheet evidence."""
    return tuple(
        WorksheetCreationModification(
            sheet_name=creation.sheet_name,
            index=creation.index,
            visibility=creation.visibility,
            output_source=ExcelSourceReference(
                file_id=output_file_id,
                sheet_name=creation.sheet_name,
                cell_range="A1:XFD1048576",
            ),
        )
        for creation in pending
    )


def _public_freeze_pane_changes(
    pending: Sequence[_PendingFreezePaneChange],
    *,
    source_file_id: str,
    output_file_id: str,
) -> tuple[FreezePaneModification, ...]:
    """Attach source and output identities to frozen-pane evidence."""
    return tuple(
        FreezePaneModification(
            sheet_name=change.sheet_name,
            old_coordinate=change.old_coordinate,
            new_coordinate=change.new_coordinate,
            source=ExcelSourceReference(
                file_id=source_file_id,
                sheet_name=change.sheet_name,
                cell_range="A1:XFD1048576",
            ),
            output_source=ExcelSourceReference(
                file_id=output_file_id,
                sheet_name=change.sheet_name,
                cell_range="A1:XFD1048576",
            ),
        )
        for change in pending
    )


def _public_auto_filter_changes(
    pending: Sequence[_PendingAutoFilterChange],
    *,
    source_file_id: str,
    output_file_id: str,
) -> tuple[AutoFilterModification, ...]:
    """Attach source and output identities to basic filter-range evidence."""
    return tuple(
        AutoFilterModification(
            sheet_name=change.sheet_name,
            old_cell_range=change.old_cell_range,
            new_cell_range=change.new_cell_range,
            old_state_fingerprint=change.old_state_fingerprint,
            new_state_fingerprint=change.new_state_fingerprint,
            source=ExcelSourceReference(
                file_id=source_file_id,
                sheet_name=change.sheet_name,
                cell_range="A1:XFD1048576",
            ),
            output_source=ExcelSourceReference(
                file_id=output_file_id,
                sheet_name=change.sheet_name,
                cell_range="A1:XFD1048576",
            ),
        )
        for change in pending
        if change.changed
    )


def _public_merged_range_changes(
    pending: Sequence[_PendingMergedRangeChange],
    *,
    source_file_id: str,
    output_file_id: str,
) -> tuple[MergedRangeModification, ...]:
    """Attach source and output identities to merge-range evidence."""
    return tuple(
        MergedRangeModification(
            sheet_name=change.sheet_name,
            cell_range=change.cell_range,
            operation=change.operation,
            source=ExcelSourceReference(
                file_id=source_file_id,
                sheet_name=change.sheet_name,
                cell_range=change.cell_range,
            ),
            output_source=ExcelSourceReference(
                file_id=output_file_id,
                sheet_name=change.sheet_name,
                cell_range=change.cell_range,
            ),
        )
        for change in pending
    )


def _public_table_range_changes(
    pending: Sequence[_PendingTableRangeChange],
    *,
    source_file_id: str,
    output_file_id: str,
) -> tuple[TableRangeModification, ...]:
    """Attach source and output identities to table-range evidence."""
    return tuple(
        TableRangeModification(
            sheet_name=change.sheet_name,
            table_name=change.table_name,
            old_range=change.old_range,
            new_range=change.new_range,
            source=ExcelSourceReference(
                file_id=source_file_id,
                sheet_name=change.sheet_name,
                cell_range=change.old_range,
            ),
            output_source=ExcelSourceReference(
                file_id=output_file_id,
                sheet_name=change.sheet_name,
                cell_range=change.new_range,
            ),
        )
        for change in pending
    )


def _public_defined_name_changes(
    pending: Sequence[_PendingDefinedNameChange],
    *,
    source_file_id: str,
    output_file_id: str,
) -> tuple[DefinedNameModification, ...]:
    """Attach source and output identities to defined-name evidence."""
    return tuple(
        DefinedNameModification(
            name=change.name,
            operation=cast("Literal['create', 'update', 'delete']", change.operation),
            scope_sheet_name=change.scope_sheet_name,
            old_formula=change.old_formula,
            new_formula=change.new_formula,
            old_hidden=change.old_hidden,
            new_hidden=change.new_hidden,
            source_file_id=source_file_id,
            output_file_id=output_file_id,
        )
        for change in pending
    )


def _public_sheet_order_change(
    pending: _PendingSheetOrderChange | None,
    *,
    source_file_id: str,
    output_file_id: str,
) -> WorkbookSheetOrderModification | None:
    """Attach source and output identities to verified sheet-order evidence."""
    if pending is None:
        return None
    return WorkbookSheetOrderModification(
        old_sheet_names=pending.old_sheet_names,
        new_sheet_names=pending.new_sheet_names,
        source_file_id=source_file_id,
        output_file_id=output_file_id,
    )


def _public_conditional_formatting_changes(
    pending: Sequence[_PendingConditionalFormattingChange],
    *,
    source_file_id: str,
    output_file_id: str,
) -> tuple[ConditionalFormattingModification, ...]:
    """Attach source and output identities to changed rule-set evidence."""
    return tuple(
        ConditionalFormattingModification(
            sheet_name=change.sheet_name,
            old_rule_count=change.old_rule_count,
            new_rule_count=change.new_rule_count,
            old_rule_set_fingerprint=change.old_rule_set_fingerprint,
            new_rule_set_fingerprint=change.new_rule_set_fingerprint,
            source=ExcelSourceReference(
                file_id=source_file_id,
                sheet_name=change.sheet_name,
                cell_range="A1:XFD1048576",
            ),
            output_source=ExcelSourceReference(
                file_id=output_file_id,
                sheet_name=change.sheet_name,
                cell_range="A1:XFD1048576",
            ),
        )
        for change in pending
        if change.changed
    )


def _public_hyperlink_changes(
    pending: Sequence[_PendingHyperlinkChange],
    *,
    source_file_id: str,
    output_file_id: str,
) -> tuple[HyperlinkModification, ...]:
    """Attach source and output identities to hyperlink-set evidence."""
    return tuple(
        HyperlinkModification(
            sheet_name=change.sheet_name,
            old_count=change.old_count,
            new_count=change.new_count,
            old_fingerprint=change.old_fingerprint,
            new_fingerprint=change.new_fingerprint,
            source=ExcelSourceReference(
                file_id=source_file_id,
                sheet_name=change.sheet_name,
                cell_range="A1:XFD1048576",
            ),
            output_source=ExcelSourceReference(
                file_id=output_file_id,
                sheet_name=change.sheet_name,
                cell_range="A1:XFD1048576",
            ),
        )
        for change in pending
    )


def _public_legacy_comment_changes(
    pending: Sequence[_PendingLegacyCommentChange],
    *,
    source_file_id: str,
    output_file_id: str,
) -> tuple[LegacyCommentsModification, ...]:
    """Attach source and output identities to legacy-comment-set evidence."""
    return tuple(
        LegacyCommentsModification(
            sheet_name=change.sheet_name,
            old_count=change.old_count,
            new_count=change.new_count,
            old_fingerprint=change.old_fingerprint,
            new_fingerprint=change.new_fingerprint,
            source=ExcelSourceReference(
                file_id=source_file_id,
                sheet_name=change.sheet_name,
                cell_range="A1:XFD1048576",
            ),
            output_source=ExcelSourceReference(
                file_id=output_file_id,
                sheet_name=change.sheet_name,
                cell_range="A1:XFD1048576",
            ),
        )
        for change in pending
    )


def _public_data_validation_changes(
    pending: Sequence[_PendingDataValidationChange],
    *,
    source_file_id: str,
    output_file_id: str,
) -> tuple[DataValidationModification, ...]:
    """Attach source and output identities to changed validation evidence."""
    return tuple(
        DataValidationModification(
            sheet_name=change.sheet_name,
            old_rule_count=change.old_rule_count,
            new_rule_count=change.new_rule_count,
            old_rule_set_fingerprint=change.old_rule_set_fingerprint,
            new_rule_set_fingerprint=change.new_rule_set_fingerprint,
            source=ExcelSourceReference(
                file_id=source_file_id,
                sheet_name=change.sheet_name,
                cell_range="A1:XFD1048576",
            ),
            output_source=ExcelSourceReference(
                file_id=output_file_id,
                sheet_name=change.sheet_name,
                cell_range="A1:XFD1048576",
            ),
        )
        for change in pending
        if change.changed
    )


def _auto_filter_defined_name_patches(
    pending: Sequence[_PendingAutoFilterChange],
    explicit: Sequence[DefinedNamePatch],
    existing: dict[tuple[str, str | None], int],
) -> tuple[DefinedNamePatch, ...]:
    explicit_targets = {
        (
            patch.name.casefold(),
            None
            if patch.scope_sheet_name is None
            else patch.scope_sheet_name.casefold(),
        )
        for patch in explicit
    }
    patches: list[DefinedNamePatch] = []
    for change in pending:
        if not change.changed:
            continue
        target = (_FILTER_DATABASE_NAME.casefold(), change.sheet_name.casefold())
        if target in explicit_targets:
            msg = "Auto-filter and explicit defined-name patches overlap"
            raise ExcelModificationError(msg)
        existing_count = existing.get(target, 0)
        if existing_count > 1:
            msg = "Workbook contains duplicate defined name identities"
            raise ExcelModificationError(msg)
        operation: Literal["create", "update", "delete"]
        if change.new_cell_range is None:
            if existing_count == 0:
                continue
            operation = "delete"
        elif existing_count == 1:
            operation = "update"
        else:
            operation = "create"
        formula = None
        hidden = False
        if change.new_cell_range is not None:
            absolute_range = re.sub(
                r"([A-Z]+)([0-9]+)",
                r"$\1$\2",
                change.new_cell_range,
            )
            quoted_sheet = change.sheet_name.replace("'", "''")
            formula = f"'{quoted_sheet}'!{absolute_range}"
            hidden = True
        patches.append(
            DefinedNamePatch(
                name=_FILTER_DATABASE_NAME,
                operation=operation,
                formula=formula,
                scope_sheet_name=change.sheet_name,
                hidden=hidden,
            )
        )
    return tuple(patches)


def _public_column_changes(
    pending: Sequence[_PendingColumnChange],
    *,
    source_file_id: str,
    output_file_id: str,
) -> tuple[ColumnDimensionModification, ...]:
    """Attach source and output identities to verified column changes."""
    changes: list[ColumnDimensionModification] = []
    for change in pending:
        start_column, end_column = public_column_range(change)
        cell_range = f"{start_column}1:{end_column}1048576"
        changes.append(
            ColumnDimensionModification(
                sheet_name=change.sheet_name,
                start_column=start_column,
                end_column=end_column,
                old_width=change.old_width,
                new_width=change.new_width,
                old_hidden=change.old_hidden,
                new_hidden=change.new_hidden,
                old_best_fit=change.old_best_fit,
                new_best_fit=change.new_best_fit,
                old_style_fingerprint=change.old_style_fingerprint,
                new_style_fingerprint=change.new_style_fingerprint,
                style_changed_components=change.style_changed_components,
                source=ExcelSourceReference(
                    file_id=source_file_id,
                    sheet_name=change.sheet_name,
                    cell_range=cell_range,
                ),
                output_source=ExcelSourceReference(
                    file_id=output_file_id,
                    sheet_name=change.sheet_name,
                    cell_range=cell_range,
                ),
            )
        )
    return tuple(changes)


def _public_default_style_change(
    pending: _PendingDefaultStyleChange | None,
    *,
    source_file_id: str,
    output_file_id: str,
) -> WorkbookDefaultStyleModification | None:
    """Attach source and output identities to default-style evidence."""
    if pending is None:
        return None
    return WorkbookDefaultStyleModification(
        old_fingerprint=pending.old_fingerprint,
        new_fingerprint=pending.new_fingerprint,
        changed_components=pending.changed_components,
        source_file_id=source_file_id,
        output_file_id=output_file_id,
    )


def _public_row_changes(
    pending: Sequence[_PendingRowChange],
    *,
    source_file_id: str,
    output_file_id: str,
) -> tuple[RowDimensionModification, ...]:
    """Attach source and output identities to verified row changes."""
    return tuple(
        RowDimensionModification(
            sheet_name=change.sheet_name,
            start_row=change.start_row,
            end_row=change.end_row,
            old_height=change.old_height,
            new_height=change.new_height,
            old_hidden=change.old_hidden,
            new_hidden=change.new_hidden,
            source=ExcelSourceReference(
                file_id=source_file_id,
                sheet_name=change.sheet_name,
                cell_range=f"A{change.start_row}:XFD{change.end_row}",
            ),
            output_source=ExcelSourceReference(
                file_id=output_file_id,
                sheet_name=change.sheet_name,
                cell_range=f"A{change.start_row}:XFD{change.end_row}",
            ),
        )
        for change in pending
    )


def _temporary_output_path(output_path: Path, source_extension: str) -> Path:
    """Create one closed same-directory temporary output file."""
    return create_staging_path(output_path, f".tmp{source_extension}")


def _verify_vba_parts(
    temporary_path: Path,
    source_vba: _VbaPartEvidence | None,
    *,
    strict_preservation: bool,
) -> tuple[bool, str | None]:
    """Verify opaque VBA bytes and normalized OOXML macro reachability."""
    output_vba = _vba_part_evidence(temporary_path)
    evidence_valid = (
        not _vba_evidence_issues(source_vba)
        and not _vba_evidence_issues(output_vba)
        and source_vba == output_vba
    )
    if evidence_valid:
        return True, None
    if strict_preservation:
        msg = "Patched workbook VBA reachability verification failed"
        raise ExcelModificationError(msg)
    return False, _VBA_PRESERVATION_WARNING


def _close_workbook(workbook: Workbook) -> None:
    """Close both the workbook reader and openpyxl's copied VBA archive."""
    vba_archive = getattr(workbook, "vba_archive", None)
    workbook.close()
    if vba_archive is not None:
        vba_archive.close()


def _load_patch_workbook(
    source: Path | BinaryIO,
    *,
    keep_vba: bool,
) -> Workbook:
    """Load a patch workbook while package restoration retains its extensions."""
    from openpyxl import load_workbook

    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            message=r".+ extension is not supported and will be removed",
            category=UserWarning,
            module=r"openpyxl\.worksheet\._reader",
        )
        return load_workbook(
            source,
            read_only=False,
            data_only=False,
            keep_vba=keep_vba,
            keep_links=True,
            rich_text=True,
        )


def _create_verified_temporary(  # noqa: C901, PLR0912, PLR0913, PLR0915
    source_path: Path,
    output_path: Path,
    request: WorkbookPatchRequest,
    *,
    keep_vba: bool,
    source_vba: _VbaPartEvidence | None,
    source_fingerprint: str,
    strict_preservation: bool,
) -> tuple[
    Path,
    tuple[_PendingChange, ...],
    tuple[_PendingFormatChange, ...],
    tuple[_PendingExistingCellFormatRangeChange, ...],
    tuple[_PendingSheetCreation, ...],
    tuple[_PendingFreezePaneChange, ...],
    tuple[_PendingAutoFilterChange, ...],
    tuple[_PendingMergedRangeChange, ...],
    tuple[_PendingDefinedNameChange, ...],
    tuple[_PendingConditionalFormattingChange, ...],
    tuple[_PendingDataValidationChange, ...],
    bool | None,
    str | None,
]:
    """Save and reopen one temporary patch result before atomic replacement."""
    temporary_path = _temporary_output_path(
        output_path,
        source_path.suffix.lower(),
    )
    try:
        with open_verified_binary(source_path, source_fingerprint) as source_stream:
            workbook = _load_patch_workbook(
                source_stream,
                keep_vba=keep_vba,
            )
            try:
                pending_sheet_creations = _apply_sheet_creations(workbook, request)
                imported_named_styles = apply_named_style_imports(
                    workbook,
                    request.named_styles,
                )
                pending_unmerge_changes = _apply_merged_ranges(
                    workbook,
                    request,
                    operation="unmerge",
                )
                pending_freeze_changes = _apply_freeze_panes(workbook, request)
                pending_auto_filter_changes = apply_auto_filter_patches(
                    workbook,
                    request.auto_filters,
                )
                expected_sheet_names = tuple(workbook.sheetnames)
                patches = _resolve_patches(workbook, request)
                pending_changes = _apply_patches(workbook, patches)
                for format_patch in request.formats:
                    worksheet = _worksheet(workbook, format_patch.sheet_name)
                    _ensure_merged_anchor(worksheet, format_patch.coordinate)
                pending_format_changes = apply_format_patches(
                    workbook,
                    request.formats,
                )
                pending_format_range_changes = apply_existing_cell_format_range_patches(
                    workbook,
                    request.existing_cell_format_ranges,
                )
                pending_merge_changes = _apply_merged_ranges(
                    workbook,
                    request,
                    operation="merge",
                )
                pending_merge_changes = (
                    *pending_unmerge_changes,
                    *pending_merge_changes,
                )
                pending_conditional_formatting_changes = (
                    apply_conditional_formatting_patches(
                        workbook,
                        request.conditional_formatting,
                    )
                )
                pending_data_validation_changes = apply_data_validation_patches(
                    workbook,
                    request.data_validations,
                )
                backend_saved = bool(
                    imported_named_styles
                    or pending_changes
                    or pending_format_changes
                    or pending_format_range_changes
                    or pending_sheet_creations
                    or pending_merge_changes
                    or pending_freeze_changes
                    or any(
                        change.backend_changed for change in pending_auto_filter_changes
                    )
                    or any(
                        change.changed
                        for change in pending_conditional_formatting_changes
                    )
                    or any(change.changed for change in pending_data_validation_changes)
                )
                if backend_saved:
                    workbook.save(temporary_path)
            finally:
                _close_workbook(workbook)

        if backend_saved:
            deterministic_path = _temporary_output_path(
                output_path,
                source_path.suffix.lower(),
            )
            copy_with_deterministic_timestamps(temporary_path, deterministic_path)
            temporary_path.unlink(missing_ok=True)
            temporary_path = deterministic_path
            preserve_macro_sheet_workbook_state(
                source_path,
                temporary_path,
                source_fingerprint=source_fingerprint,
            )
            preserve_workbook_defined_names(
                source_path,
                temporary_path,
                source_fingerprint=source_fingerprint,
            )
            style_targets: dict[str, set[str]] = {}
            metadata_targets: dict[str, set[str]] = {}
            for format_patch in request.formats:
                style_targets.setdefault(
                    format_patch.sheet_name.casefold(),
                    set(),
                ).add(format_patch.coordinate)
            for change in pending_format_range_changes:
                style_targets.setdefault(change.sheet_name.casefold(), set()).update(
                    change.target_coordinates
                )
            for patch in patches:
                metadata_targets.setdefault(
                    patch.sheet_name.casefold(),
                    set(),
                ).add(patch.coordinate)
                if patch.content.number_format is not None:
                    style_targets.setdefault(
                        patch.sheet_name.casefold(),
                        set(),
                    ).add(patch.coordinate)
            preserve_untargeted_cell_styles(
                source_path,
                temporary_path,
                targets={
                    sheet: frozenset(coordinates)
                    for sheet, coordinates in style_targets.items()
                },
                metadata_targets={
                    sheet: frozenset(coordinates)
                    for sheet, coordinates in metadata_targets.items()
                },
                modified_merged_ranges={
                    sheet_name: frozenset(
                        patch.cell_range
                        for patch in request.merged_ranges
                        if patch.sheet_name.casefold() == sheet_name
                    )
                    for sheet_name in {
                        patch.sheet_name.casefold() for patch in request.merged_ranges
                    }
                },
                source_fingerprint=source_fingerprint,
            )
            preserve_untargeted_worksheet_state(
                source_path,
                temporary_path,
                freeze_pane_targets=frozenset(
                    patch.sheet_name.casefold() for patch in request.freeze_panes
                ),
                auto_filter_targets=frozenset(
                    patch.sheet_name.casefold() for patch in request.auto_filters
                ),
                conditional_formatting_targets=frozenset(
                    patch.sheet_name.casefold()
                    for patch in request.conditional_formatting
                ),
                data_validation_targets=frozenset(
                    patch.sheet_name.casefold() for patch in request.data_validations
                ),
                source_fingerprint=source_fingerprint,
            )
            preserve_dynamic_array_metadata(
                source_path,
                temporary_path,
                source_fingerprint=source_fingerprint,
            )
            preserve_opaque_package_parts(
                source_path,
                temporary_path,
                source_fingerprint=source_fingerprint,
            )
            reapply_targeted_cell_formats(
                source_path,
                temporary_path,
                request.formats,
                source_fingerprint=source_fingerprint,
            )
        else:
            with (
                open_verified_binary(source_path, source_fingerprint) as source_stream,
                temporary_path.open("wb") as output_stream,
            ):
                copyfileobj(source_stream, output_stream)

        pending_auto_filter_changes = apply_persisted_auto_filter_metadata(
            source_path,
            temporary_path,
            request.auto_filters,
            pending_auto_filter_changes,
            source_fingerprint=source_fingerprint,
            created_sheet_names=tuple(
                creation.sheet_name for creation in pending_sheet_creations
            ),
        )

        pending_data_validation_changes = apply_persisted_data_validation_revision_uids(
            source_path,
            temporary_path,
            request.data_validations,
            pending_data_validation_changes,
            source_fingerprint=source_fingerprint,
        )
        verify_persisted_data_validation_revision_uids(
            temporary_path,
            request.data_validations,
            pending_data_validation_changes,
        )

        persisted_border_targets = verify_persisted_format_borders(
            temporary_path,
            request.formats,
        )

        existing_defined_names = workbook_defined_name_identity_counts(temporary_path)
        derived_filter_names = _auto_filter_defined_name_patches(
            pending_auto_filter_changes,
            request.defined_names,
            existing_defined_names,
        )
        pending_defined_name_changes = apply_workbook_defined_name_patches(
            temporary_path,
            (*request.defined_names, *derived_filter_names),
        )
        exact_decimal_targets = _verify_exact_decimal_patches(
            temporary_path,
            patches,
        )

        verification = _load_patch_workbook(
            temporary_path,
            keep_vba=keep_vba,
        )
        try:
            _verify_patches(
                verification,
                expected_sheet_names=expected_sheet_names,
                patches=patches,
                exact_decimal_targets=exact_decimal_targets,
            )
            verify_format_patches(
                verification,
                request.formats,
                persisted_border_targets=persisted_border_targets,
            )
            verify_existing_cell_format_range_patches(
                verification,
                request.existing_cell_format_ranges,
            )
            verify_named_style_imports(verification, request.named_styles)
            _verify_sheet_creations(verification, pending_sheet_creations)
            _verify_sheet_structure(
                verification,
                pending_freeze_changes,
                pending_merge_changes,
            )
            verify_auto_filter_patches(
                verification,
                pending_auto_filter_changes,
            )
            verify_conditional_formatting_patches(
                verification,
                pending_conditional_formatting_changes,
            )
            verify_data_validation_patches(
                verification,
                pending_data_validation_changes,
            )
        finally:
            _close_workbook(verification)

        vba_preserved: bool | None = None
        vba_warning: str | None = None
        if source_vba is not None:
            vba_preserved, vba_warning = _verify_vba_parts(
                temporary_path,
                source_vba,
                strict_preservation=strict_preservation,
            )
    except Exception:
        temporary_path.unlink(missing_ok=True)
        raise
    else:
        return (
            temporary_path,
            pending_changes,
            pending_format_changes,
            pending_format_range_changes,
            pending_sheet_creations,
            pending_freeze_changes,
            pending_auto_filter_changes,
            pending_merge_changes,
            pending_defined_name_changes,
            pending_conditional_formatting_changes,
            pending_data_validation_changes,
            vba_preserved,
            vba_warning,
        )


def _append_default_style_patch(  # noqa: PLR0913
    temporary_path: Path | None,
    source_path: Path,
    output_path: Path,
    request: WorkbookPatchRequest,
    *,
    source_fingerprint: str,
    source_vba: _VbaPartEvidence | None,
    strict_preservation: bool,
) -> tuple[
    Path,
    _PendingDefaultStyleChange | None,
    bool | None,
    str | None,
]:
    """Apply one package-level workbook default-style patch."""
    default_source = temporary_path or source_path
    default_fingerprint = (
        calculate_sha256(default_source).value
        if temporary_path is not None
        else source_fingerprint
    )
    default_output = _temporary_output_path(output_path, source_path.suffix.lower())
    if request.default_style is None:  # pragma: no cover - caller invariant.
        msg = "Workbook default style patch is missing"
        raise ExcelModificationError(msg)
    try:
        pending = create_default_style_patch_output(
            default_source,
            default_output,
            request.default_style,
            source_fingerprint=default_fingerprint,
        )
        vba_preserved: bool | None = None
        vba_warning: str | None = None
        if source_vba is not None:
            vba_preserved, vba_warning = _verify_vba_parts(
                default_output,
                source_vba,
                strict_preservation=strict_preservation,
            )
    except Exception:
        default_output.unlink(missing_ok=True)
        raise
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)
    return default_output, pending, vba_preserved, vba_warning


def _append_column_patch(  # noqa: PLR0913
    temporary_path: Path | None,
    source_path: Path,
    output_path: Path,
    request: WorkbookPatchRequest,
    *,
    source_fingerprint: str,
    source_vba: _VbaPartEvidence | None,
    strict_preservation: bool,
) -> tuple[Path, tuple[_PendingColumnChange, ...], bool | None, str | None]:
    """Apply package-level column patches after any existing cell rewrite."""
    column_source = temporary_path or source_path
    column_fingerprint = (
        calculate_sha256(column_source).value
        if temporary_path is not None
        else source_fingerprint
    )
    column_output = _temporary_output_path(output_path, source_path.suffix.lower())
    try:
        pending = create_column_patch_output(
            column_source,
            column_output,
            request.column_dimensions,
            source_fingerprint=column_fingerprint,
        )
        vba_preserved: bool | None = None
        vba_warning: str | None = None
        if source_vba is not None:
            vba_preserved, vba_warning = _verify_vba_parts(
                column_output,
                source_vba,
                strict_preservation=strict_preservation,
            )
    except Exception:
        column_output.unlink(missing_ok=True)
        raise
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)
    return column_output, pending, vba_preserved, vba_warning


def _append_row_patch(  # noqa: PLR0913
    temporary_path: Path | None,
    source_path: Path,
    output_path: Path,
    request: WorkbookPatchRequest,
    *,
    source_fingerprint: str,
    source_vba: _VbaPartEvidence | None,
    strict_preservation: bool,
) -> tuple[Path, tuple[_PendingRowChange, ...], bool | None, str | None]:
    """Apply package-level row patches after earlier cell or column changes."""
    row_source = temporary_path or source_path
    row_fingerprint = (
        calculate_sha256(row_source).value
        if temporary_path is not None
        else source_fingerprint
    )
    row_output = _temporary_output_path(output_path, source_path.suffix.lower())
    try:
        pending = create_row_patch_output(
            row_source,
            row_output,
            request.row_dimensions,
            source_fingerprint=row_fingerprint,
        )
        vba_preserved: bool | None = None
        vba_warning: str | None = None
        if source_vba is not None:
            vba_preserved, vba_warning = _verify_vba_parts(
                row_output,
                source_vba,
                strict_preservation=strict_preservation,
            )
    except Exception:
        row_output.unlink(missing_ok=True)
        raise
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)
    return row_output, pending, vba_preserved, vba_warning


def _append_sheet_order_patch(  # noqa: PLR0913
    temporary_path: Path | None,
    source_path: Path,
    output_path: Path,
    request: WorkbookPatchRequest,
    *,
    source_fingerprint: str,
    source_vba: _VbaPartEvidence | None,
    strict_preservation: bool,
) -> tuple[Path, _PendingSheetOrderChange | None, bool | None, str | None]:
    """Apply a package-level sheet ordering after all earlier workbook changes."""
    order_source = temporary_path or source_path
    order_fingerprint = (
        calculate_sha256(order_source).value
        if temporary_path is not None
        else source_fingerprint
    )
    order_output = _temporary_output_path(output_path, source_path.suffix.lower())
    try:
        pending = create_sheet_order_patch_output(
            order_source,
            order_output,
            cast("WorkbookSheetOrderPatch", request.sheet_order),
            source_fingerprint=order_fingerprint,
        )
        vba_preserved: bool | None = None
        vba_warning: str | None = None
        if source_vba is not None:
            vba_preserved, vba_warning = _verify_vba_parts(
                order_output,
                source_vba,
                strict_preservation=strict_preservation,
            )
    except Exception:
        order_output.unlink(missing_ok=True)
        raise
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)
    return order_output, pending, vba_preserved, vba_warning


def _append_external_link_cleanup(  # noqa: PLR0913
    temporary_path: Path | None,
    source_path: Path,
    output_path: Path,
    *,
    source_fingerprint: str,
    source_vba: _VbaPartEvidence | None,
    strict_preservation: bool,
) -> tuple[Path, int, bool | None, str | None]:
    """Remove now-unreferenced external-link package state last."""
    cleanup_source = temporary_path or source_path
    cleanup_fingerprint = (
        calculate_sha256(cleanup_source).value
        if temporary_path is not None
        else source_fingerprint
    )
    cleanup_output = _temporary_output_path(output_path, source_path.suffix.lower())
    try:
        removed = create_external_link_cleanup_output(
            cleanup_source,
            cleanup_output,
            source_fingerprint=cleanup_fingerprint,
        )
        vba_preserved: bool | None = None
        vba_warning: str | None = None
        if source_vba is not None:
            vba_preserved, vba_warning = _verify_vba_parts(
                cleanup_output,
                source_vba,
                strict_preservation=strict_preservation,
            )
    except Exception:
        cleanup_output.unlink(missing_ok=True)
        raise
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)
    return cleanup_output, removed, vba_preserved, vba_warning


def _append_external_link_removal(  # noqa: PLR0913
    temporary_path: Path | None,
    source_path: Path,
    output_path: Path,
    request: WorkbookPatchRequest,
    *,
    source_fingerprint: str,
    source_vba: _VbaPartEvidence | None,
    strict_preservation: bool,
    final_formula_cells: frozenset[tuple[str, str]],
) -> tuple[Path, int, bool | None, str | None]:
    """Remove selected external links from the fully patched request state."""
    removal_source = temporary_path or source_path
    removal_fingerprint = (
        calculate_sha256(removal_source).value
        if temporary_path is not None
        else source_fingerprint
    )
    removal_output = _temporary_output_path(output_path, source_path.suffix.lower())
    try:
        removed = create_external_link_removal_output(
            removal_source,
            removal_output,
            request.external_link_removals,
            source_fingerprint=removal_fingerprint,
            final_request=request,
            final_formula_cells=final_formula_cells,
        )
        vba_preserved: bool | None = None
        vba_warning: str | None = None
        if source_vba is not None:
            vba_preserved, vba_warning = _verify_vba_parts(
                removal_output,
                source_vba,
                strict_preservation=strict_preservation,
            )
    except Exception:
        removal_output.unlink(missing_ok=True)
        raise
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)
    return removal_output, removed, vba_preserved, vba_warning


def _append_table_range_patch(  # noqa: PLR0913
    temporary_path: Path | None,
    source_path: Path,
    output_path: Path,
    request: WorkbookPatchRequest,
    *,
    source_fingerprint: str,
    source_vba: _VbaPartEvidence | None,
    strict_preservation: bool,
) -> tuple[
    Path,
    tuple[_PendingTableRangeChange, ...],
    bool | None,
    str | None,
]:
    """Apply package-level existing-table range patches last."""
    table_source = temporary_path or source_path
    table_fingerprint = (
        calculate_sha256(table_source).value
        if temporary_path is not None
        else source_fingerprint
    )
    table_output = _temporary_output_path(output_path, source_path.suffix.lower())
    try:
        pending = create_table_range_patch_output(
            table_source,
            table_output,
            request.table_ranges,
            source_fingerprint=table_fingerprint,
        )
        vba_preserved: bool | None = None
        vba_warning: str | None = None
        if source_vba is not None:
            vba_preserved, vba_warning = _verify_vba_parts(
                table_output,
                source_vba,
                strict_preservation=strict_preservation,
            )
    except Exception:
        table_output.unlink(missing_ok=True)
        raise
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)
    return table_output, pending, vba_preserved, vba_warning


def _append_worksheet_annotation_patch(  # noqa: PLR0913
    temporary_path: Path | None,
    source_path: Path,
    output_path: Path,
    request: WorkbookPatchRequest,
    *,
    source_fingerprint: str,
    source_vba: _VbaPartEvidence | None,
    strict_preservation: bool,
) -> tuple[
    Path,
    tuple[_PendingHyperlinkChange, ...],
    tuple[_PendingLegacyCommentChange, ...],
    bool | None,
    str | None,
]:
    """Apply package-level worksheet hyperlink and legacy-comment patches."""
    annotation_source = temporary_path or source_path
    annotation_fingerprint = (
        calculate_sha256(annotation_source).value
        if temporary_path is not None
        else source_fingerprint
    )
    annotation_output = _temporary_output_path(
        output_path,
        source_path.suffix.lower(),
    )
    try:
        hyperlinks, comments = create_worksheet_annotation_patch_output(
            annotation_source,
            annotation_output,
            request.hyperlinks,
            request.legacy_comments,
            source_fingerprint=annotation_fingerprint,
        )
        vba_preserved: bool | None = None
        vba_warning: str | None = None
        if source_vba is not None:
            vba_preserved, vba_warning = _verify_vba_parts(
                annotation_output,
                source_vba,
                strict_preservation=strict_preservation,
            )
    except Exception:
        annotation_output.unlink(missing_ok=True)
        raise
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)
    return (
        annotation_output,
        hyperlinks,
        comments,
        vba_preserved,
        vba_warning,
    )


def _apply_initial_package_transactions(
    source_path: Path,
    output_path: Path,
    request: WorkbookPatchRequest,
    *,
    source_fingerprint: str,
) -> tuple[
    Path | None,
    tuple[_PendingStructuralInsertion, ...],
    tuple[_PendingGraphChange, ...],
]:
    """Apply structural/package graph changes before addressed workbook patches."""
    current: Path | None = None
    current_fingerprint = source_fingerprint
    pending_insertions: tuple[_PendingStructuralInsertion, ...] = ()
    pending_graph: tuple[_PendingGraphChange, ...] = ()

    def next_output() -> Path:
        return _temporary_output_path(output_path, source_path.suffix.lower())

    if request.structural_insertions:
        target = next_output()
        pending_insertions = create_structural_insertion_output(
            source_path,
            target,
            request.structural_insertions,
            source_fingerprint=current_fingerprint,
        )
        current = target
        current_fingerprint = calculate_sha256(target).value
    if request.delete_sheets or request.drawing_removals or request.image_additions:
        graph_source = current or source_path
        target = next_output()
        try:
            pending_graph = create_package_graph_patch_output(
                graph_source,
                target,
                delete_sheets=request.delete_sheets,
                drawing_removals=request.drawing_removals,
                image_additions=request.image_additions,
                request=request,
                source_fingerprint=current_fingerprint,
            )
        finally:
            if current is not None:
                current.unlink(missing_ok=True)
        current = target
        current_fingerprint = calculate_sha256(target).value
    return current, pending_insertions, pending_graph


def _public_structural_changes(
    insertions: tuple[_PendingStructuralInsertion, ...],
    graph_changes: tuple[_PendingGraphChange, ...],
    *,
    source_file_id: str,
    output_file_id: str,
) -> tuple[WorkbookStructuralModification, ...]:
    changes = [
        WorkbookStructuralModification(
            operation="insert_rows" if item.axis == "row" else "insert_columns",
            target=f"{item.sheet_name}!{item.before}",
            count=item.count,
            source_file_id=source_file_id,
            output_file_id=output_file_id,
        )
        for item in insertions
    ]
    changes.extend(
        WorkbookStructuralModification(
            operation=cast(
                "Literal['delete_worksheet', 'remove_drawings', 'add_image']",
                item.operation,
            ),
            target=item.target,
            count=item.count,
            source_file_id=source_file_id,
            output_file_id=output_file_id,
        )
        for item in graph_changes
    )
    return tuple(changes)


def _patch_workbook_owned(  # noqa: C901, PLR0912, PLR0915
    source_path: Path,
    output_path: Path,
    request: WorkbookPatchRequest,
    *,
    strict_preservation: bool = True,
    overwrite: bool = False,
) -> WorkbookModificationResult:
    """Apply typed workbook patches to a distinct, verified output file.

    The source is never saved. Cell changes retain the existing openpyxl-backed
    behavior; row- and column-dimension changes edit only targeted worksheet XML
    package parts. XLSM inputs use
    ``keep_vba=True``; opaque VBA package hashes, content types, and workbook
    relationships are verified before commit without parsing or executing VBA.
    """
    validated_request = revalidate_excel_model(
        request,
        WorkbookPatchRequest,
        "Workbook patch request is invalid",
    )
    require_excel_support()

    source_descriptor = _workbook_descriptor(source_path)
    _validate_destination(source_path, output_path, overwrite=overwrite)
    preservation = _request_aware_preservation(
        assess_workbook_preservation(source_path, operation="patch"),
        validated_request,
    )
    unsupported = _unsupported_features(preservation)
    if strict_preservation and unsupported:
        raise WorkbookPreservationError(
            operation="patch",
            unsupported_features=unsupported,
        )
    warnings = _preservation_warnings(preservation)
    keep_vba = source_descriptor.extension == ".xlsm"
    collected_vba = (
        _vba_part_evidence(
            source_path,
            expected_fingerprint=source_descriptor.fingerprint.value,
        )
        if keep_vba
        else None
    )
    source_vba = (
        collected_vba
        if collected_vba is not None and _has_vba_project_evidence(collected_vba)
        else None
    )

    temporary_path: Path | None = None
    pending_structural_insertions: tuple[_PendingStructuralInsertion, ...] = ()
    pending_graph_changes: tuple[_PendingGraphChange, ...] = ()
    pending_changes: tuple[_PendingChange, ...] = ()
    pending_format_changes: tuple[_PendingFormatChange, ...] = ()
    pending_format_range_changes: tuple[_PendingExistingCellFormatRangeChange, ...] = ()
    pending_sheet_creations: tuple[_PendingSheetCreation, ...] = ()
    pending_sheet_order_change: _PendingSheetOrderChange | None = None
    pending_freeze_changes: tuple[_PendingFreezePaneChange, ...] = ()
    pending_auto_filter_changes: tuple[_PendingAutoFilterChange, ...] = ()
    pending_merge_changes: tuple[_PendingMergedRangeChange, ...] = ()
    pending_table_range_changes: tuple[_PendingTableRangeChange, ...] = ()
    pending_defined_name_changes: tuple[_PendingDefinedNameChange, ...] = ()
    pending_conditional_formatting_changes: tuple[
        _PendingConditionalFormattingChange, ...
    ] = ()
    pending_data_validation_changes: tuple[_PendingDataValidationChange, ...] = ()
    pending_hyperlink_changes: tuple[_PendingHyperlinkChange, ...] = ()
    pending_legacy_comment_changes: tuple[_PendingLegacyCommentChange, ...] = ()
    pending_default_style_change: _PendingDefaultStyleChange | None = None
    pending_column_changes: tuple[_PendingColumnChange, ...] = ()
    pending_row_changes: tuple[_PendingRowChange, ...] = ()
    external_links_removed = 0
    vba_preserved: bool | None = None
    vba_warning: str | None = None
    try:
        with _translate_modification_errors(source_path, "patch"):
            (
                temporary_path,
                pending_structural_insertions,
                pending_graph_changes,
            ) = _apply_initial_package_transactions(
                source_path,
                output_path,
                validated_request,
                source_fingerprint=source_descriptor.fingerprint.value,
            )
            if (
                validated_request.cells
                or validated_request.formats
                or validated_request.existing_cell_format_ranges
                or validated_request.named_styles
                or validated_request.create_sheets
                or validated_request.freeze_panes
                or validated_request.auto_filters
                or validated_request.merged_ranges
                or validated_request.defined_names
                or validated_request.conditional_formatting
                or validated_request.data_validations
                or validated_request.named_ranges
            ):
                backend_source = temporary_path or source_path
                backend_fingerprint = (
                    calculate_sha256(backend_source).value
                    if temporary_path is not None
                    else source_descriptor.fingerprint.value
                )
                backend_input = temporary_path
                (
                    temporary_path,
                    pending_changes,
                    pending_format_changes,
                    pending_format_range_changes,
                    pending_sheet_creations,
                    pending_freeze_changes,
                    pending_auto_filter_changes,
                    pending_merge_changes,
                    pending_defined_name_changes,
                    pending_conditional_formatting_changes,
                    pending_data_validation_changes,
                    vba_preserved,
                    vba_warning,
                ) = _create_verified_temporary(
                    backend_source,
                    output_path,
                    validated_request,
                    keep_vba=keep_vba,
                    source_vba=source_vba,
                    source_fingerprint=backend_fingerprint,
                    strict_preservation=strict_preservation,
                )
                if backend_input is not None and backend_input != temporary_path:
                    backend_input.unlink(missing_ok=True)
            if validated_request.default_style is not None:
                (
                    temporary_path,
                    pending_default_style_change,
                    vba_preserved,
                    vba_warning,
                ) = _append_default_style_patch(
                    temporary_path,
                    source_path,
                    output_path,
                    validated_request,
                    source_fingerprint=source_descriptor.fingerprint.value,
                    source_vba=source_vba,
                    strict_preservation=strict_preservation,
                )
            if validated_request.column_dimensions:
                (
                    temporary_path,
                    pending_column_changes,
                    vba_preserved,
                    vba_warning,
                ) = _append_column_patch(
                    temporary_path,
                    source_path,
                    output_path,
                    validated_request,
                    source_fingerprint=source_descriptor.fingerprint.value,
                    source_vba=source_vba,
                    strict_preservation=strict_preservation,
                )
            if validated_request.row_dimensions:
                (
                    temporary_path,
                    pending_row_changes,
                    vba_preserved,
                    vba_warning,
                ) = _append_row_patch(
                    temporary_path,
                    source_path,
                    output_path,
                    validated_request,
                    source_fingerprint=source_descriptor.fingerprint.value,
                    source_vba=source_vba,
                    strict_preservation=strict_preservation,
                )
            if validated_request.sheet_order is not None:
                (
                    temporary_path,
                    pending_sheet_order_change,
                    vba_preserved,
                    vba_warning,
                ) = _append_sheet_order_patch(
                    temporary_path,
                    source_path,
                    output_path,
                    validated_request,
                    source_fingerprint=source_descriptor.fingerprint.value,
                    source_vba=source_vba,
                    strict_preservation=strict_preservation,
                )
            if validated_request.table_ranges:
                (
                    temporary_path,
                    pending_table_range_changes,
                    vba_preserved,
                    vba_warning,
                ) = _append_table_range_patch(
                    temporary_path,
                    source_path,
                    output_path,
                    validated_request,
                    source_fingerprint=source_descriptor.fingerprint.value,
                    source_vba=source_vba,
                    strict_preservation=strict_preservation,
                )
            if validated_request.hyperlinks or validated_request.legacy_comments:
                (
                    temporary_path,
                    pending_hyperlink_changes,
                    pending_legacy_comment_changes,
                    vba_preserved,
                    vba_warning,
                ) = _append_worksheet_annotation_patch(
                    temporary_path,
                    source_path,
                    output_path,
                    validated_request,
                    source_fingerprint=source_descriptor.fingerprint.value,
                    source_vba=source_vba,
                    strict_preservation=strict_preservation,
                )
            if validated_request.external_link_removals:
                final_formula_cells = frozenset(
                    (change.sheet_name.casefold(), change.coordinate)
                    for change in pending_changes
                    if change.new_formula is not None
                )
                (
                    temporary_path,
                    external_links_removed,
                    vba_preserved,
                    vba_warning,
                ) = _append_external_link_removal(
                    temporary_path,
                    source_path,
                    output_path,
                    validated_request,
                    source_fingerprint=source_descriptor.fingerprint.value,
                    source_vba=source_vba,
                    strict_preservation=strict_preservation,
                    final_formula_cells=final_formula_cells,
                )
            if validated_request.remove_unreferenced_external_links:
                (
                    temporary_path,
                    cleanup_removed,
                    vba_preserved,
                    vba_warning,
                ) = _append_external_link_cleanup(
                    temporary_path,
                    source_path,
                    output_path,
                    source_fingerprint=source_descriptor.fingerprint.value,
                    source_vba=source_vba,
                    strict_preservation=strict_preservation,
                )
                external_links_removed += cleanup_removed

            if temporary_path is not None:
                verify_chartsheet_preservation(
                    source_path,
                    temporary_path,
                    source_fingerprint=source_descriptor.fingerprint.value,
                    create_sheets=validated_request.create_sheets,
                    delete_sheets=validated_request.delete_sheets,
                )
                verify_macro_sheet_preservation(
                    source_path,
                    temporary_path,
                    source_fingerprint=source_descriptor.fingerprint.value,
                )
                verify_request_aware_image_preservation(
                    source_path,
                    temporary_path,
                    source_fingerprint=source_descriptor.fingerprint.value,
                    structural_insertions=validated_request.structural_insertions,
                    delete_sheets=validated_request.delete_sheets,
                    drawing_removals=validated_request.drawing_removals,
                    image_additions=validated_request.image_additions,
                )

            if not _source_is_unchanged(
                source_path,
                source_descriptor.fingerprint,
            ):
                msg = "Workbook source changed during patching"
                raise ExcelModificationError(msg)
            if temporary_path is None:  # pragma: no cover - request invariant.
                msg = "Workbook patch did not create an output"
                raise ExcelModificationError(msg)
            source_unchanged = _source_is_unchanged(
                source_path,
                source_descriptor.fingerprint,
            )
            if not source_unchanged:
                msg = "Workbook source changed during output verification"
                raise ExcelModificationError(msg)
            if vba_warning is not None:
                warnings = tuple(dict.fromkeys((*warnings, vba_warning)))
            staged_descriptor = _workbook_descriptor(
                temporary_path,
                file_id=validated_request.output_file_id,
            )
            output_descriptor = FileDescriptor(
                file_id=staged_descriptor.file_id,
                filename=output_path.name,
                extension=staged_descriptor.extension,
                mime_type=staged_descriptor.mime_type,
                size_bytes=staged_descriptor.size_bytes,
                fingerprint=staged_descriptor.fingerprint,
            )
            result = WorkbookModificationResult(
                source_file=source_descriptor,
                output_file=output_descriptor,
                changes=_public_changes(
                    pending_changes,
                    source_file_id=source_descriptor.file_id,
                    output_file_id=output_descriptor.file_id,
                ),
                format_changes=_public_format_changes(
                    pending_format_changes,
                    source_file_id=source_descriptor.file_id,
                    output_file_id=output_descriptor.file_id,
                ),
                existing_cell_format_range_changes=_public_format_range_changes(
                    pending_format_range_changes,
                    source_file_id=source_descriptor.file_id,
                    output_file_id=output_descriptor.file_id,
                ),
                default_style_change=_public_default_style_change(
                    pending_default_style_change,
                    source_file_id=source_descriptor.file_id,
                    output_file_id=output_descriptor.file_id,
                ),
                sheet_creations=_public_sheet_creations(
                    pending_sheet_creations,
                    output_file_id=output_descriptor.file_id,
                ),
                sheet_order_change=_public_sheet_order_change(
                    pending_sheet_order_change,
                    source_file_id=source_descriptor.file_id,
                    output_file_id=output_descriptor.file_id,
                ),
                freeze_pane_changes=_public_freeze_pane_changes(
                    pending_freeze_changes,
                    source_file_id=source_descriptor.file_id,
                    output_file_id=output_descriptor.file_id,
                ),
                auto_filter_changes=_public_auto_filter_changes(
                    pending_auto_filter_changes,
                    source_file_id=source_descriptor.file_id,
                    output_file_id=output_descriptor.file_id,
                ),
                merged_range_changes=_public_merged_range_changes(
                    pending_merge_changes,
                    source_file_id=source_descriptor.file_id,
                    output_file_id=output_descriptor.file_id,
                ),
                table_range_changes=_public_table_range_changes(
                    pending_table_range_changes,
                    source_file_id=source_descriptor.file_id,
                    output_file_id=output_descriptor.file_id,
                ),
                defined_name_changes=_public_defined_name_changes(
                    pending_defined_name_changes,
                    source_file_id=source_descriptor.file_id,
                    output_file_id=output_descriptor.file_id,
                ),
                conditional_formatting_changes=_public_conditional_formatting_changes(
                    pending_conditional_formatting_changes,
                    source_file_id=source_descriptor.file_id,
                    output_file_id=output_descriptor.file_id,
                ),
                data_validation_changes=_public_data_validation_changes(
                    pending_data_validation_changes,
                    source_file_id=source_descriptor.file_id,
                    output_file_id=output_descriptor.file_id,
                ),
                hyperlink_changes=_public_hyperlink_changes(
                    pending_hyperlink_changes,
                    source_file_id=source_descriptor.file_id,
                    output_file_id=output_descriptor.file_id,
                ),
                legacy_comment_changes=_public_legacy_comment_changes(
                    pending_legacy_comment_changes,
                    source_file_id=source_descriptor.file_id,
                    output_file_id=output_descriptor.file_id,
                ),
                column_changes=_public_column_changes(
                    pending_column_changes,
                    source_file_id=source_descriptor.file_id,
                    output_file_id=output_descriptor.file_id,
                ),
                row_changes=_public_row_changes(
                    pending_row_changes,
                    source_file_id=source_descriptor.file_id,
                    output_file_id=output_descriptor.file_id,
                ),
                structural_changes=_public_structural_changes(
                    pending_structural_insertions,
                    pending_graph_changes,
                    source_file_id=source_descriptor.file_id,
                    output_file_id=output_descriptor.file_id,
                ),
                external_links_removed=external_links_removed,
                preservation=preservation,
                warnings=warnings,
                source_unchanged=source_unchanged,
                vba_preserved=vba_preserved,
            )
            os.replace(temporary_path, output_path)  # noqa: PTH105 - atomic API.
            temporary_path = None
            return result
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)


def patch_workbook(
    source_path: Path,
    output_path: Path,
    request: WorkbookPatchRequest,
    *,
    strict_preservation: bool = True,
    overwrite: bool = False,
) -> WorkbookModificationResult:
    """Apply typed workbook patches through one owned staging transaction."""
    with owned_staging_paths():
        return _patch_workbook_owned(
            source_path,
            output_path,
            request,
            strict_preservation=strict_preservation,
            overwrite=overwrite,
        )

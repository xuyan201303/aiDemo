"""Local Excel workbook generation."""

from __future__ import annotations

import os
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import TYPE_CHECKING

from document_sdk.core import (
    DocumentProcessingError,
    FileAccessError,
    UnsupportedFileError,
    WorkbookInspection,
    WorkbookWriteRequest,
)
from document_sdk.core.errors import safe_file_label
from document_sdk.excel._dependencies import require_excel_support
from document_sdk.excel._helpers import revalidate_excel_model, translate_excel_errors
from document_sdk.excel.inspection import inspect_workbook

if TYPE_CHECKING:
    from openpyxl.workbook.workbook import Workbook


def _populate_workbook(
    workbook: Workbook,
    request: WorkbookWriteRequest,
) -> None:
    """Populate an openpyxl workbook from strict SDK request models."""
    first_sheet = workbook.active
    if first_sheet is None:
        msg = "Unable to create the initial worksheet"
        raise DocumentProcessingError(msg)
    first_sheet.title = request.sheets[0].name
    for cell_request in request.sheets[0].cells:
        first_sheet[cell_request.coordinate.upper()] = cell_request.value

    for sheet_request in request.sheets[1:]:
        worksheet = workbook.create_sheet(sheet_request.name)
        for cell_request in sheet_request.cells:
            worksheet[cell_request.coordinate.upper()] = cell_request.value


def write_workbook(
    request: WorkbookWriteRequest,
    output_path: Path,
) -> WorkbookInspection:
    """Create, save, reopen, and inspect a local XLSX workbook.

    Args:
        request: Strict workbook and addressed-cell creation data.
        output_path: Destination ending in ``.xlsx``.

    Returns:
        Inspection of the successfully reopened output workbook.
    """
    validated_request = revalidate_excel_model(
        request,
        WorkbookWriteRequest,
        "Workbook write request is invalid",
    )
    require_excel_support()
    if output_path.suffix.lower() != ".xlsx":
        msg = "Workbook output must use the .xlsx extension"
        raise UnsupportedFileError(msg)
    if not output_path.parent.exists() or not output_path.parent.is_dir():
        msg = (
            f"Workbook output directory does not exist: {safe_file_label(output_path)}"
        )
        raise FileAccessError(msg)
    if output_path.exists() and not output_path.is_file():
        msg = f"Workbook output is not a regular file: {safe_file_label(output_path)}"
        raise FileAccessError(msg)

    from openpyxl import Workbook, load_workbook

    temporary_path: Path | None = None
    try:
        with translate_excel_errors(output_path, "write"):
            workbook = Workbook()
            try:
                _populate_workbook(workbook, validated_request)
                with NamedTemporaryFile(
                    dir=output_path.parent,
                    prefix=f".{output_path.name}.",
                    suffix=".tmp.xlsx",
                    delete=False,
                ) as temporary_file:
                    temporary_path = Path(temporary_file.name)
                workbook.save(temporary_path)
            finally:
                workbook.close()

            verification = load_workbook(
                temporary_path,
                read_only=True,
                data_only=False,
            )
            try:
                expected_names = [sheet.name for sheet in validated_request.sheets]
                if verification.sheetnames != expected_names:
                    msg = "Saved workbook worksheet verification failed"
                    raise DocumentProcessingError(msg)
            finally:
                verification.close()
            os.replace(temporary_path, output_path)  # noqa: PTH105 - atomic API.
            temporary_path = None
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)

    return inspect_workbook(output_path)

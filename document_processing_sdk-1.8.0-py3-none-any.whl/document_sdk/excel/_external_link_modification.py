"""Remove external-link package state only after references are gone."""

from __future__ import annotations

import re
from pathlib import PurePosixPath
from typing import TYPE_CHECKING
from xml.dom import minidom

from document_sdk.excel._column_modification import (
    _copy_package,
    _direct_elements,
    _document_root,
)
from document_sdk.excel._formula_references import (
    external_workbook_references,
    formula_has_external_reference,
    rewrite_external_workbook_indexes,
)
from document_sdk.excel._package import _SafePackage
from document_sdk.excel._package_security import _local_name, _resolve_target
from document_sdk.excel._package_workbook import _workbook_records
from document_sdk.excel._package_worksheet import (
    _SPREADSHEETML_WORKSHEET_NAMESPACES,
)
from document_sdk.excel.errors import ExcelModificationError

if TYPE_CHECKING:
    from collections.abc import Sequence
    from pathlib import Path
    from xml.dom.minidom import Document, Element

    from document_sdk.excel.models import ExternalLinkRemovalPatch, WorkbookPatchRequest


_CONTENT_TYPES_MEMBER = "[Content_Types].xml"
_CONTENT_TYPES_NAMESPACE = (
    "http://schemas.openxmlformats.org/package/2006/content-types"
)
_RELATIONSHIPS_MEMBER = "xl/_rels/workbook.xml.rels"
_RELATIONSHIPS_NAMESPACE = (
    "http://schemas.openxmlformats.org/package/2006/relationships"
)
_WORKBOOK_MEMBER = "xl/workbook.xml"
_EXTERNAL_LINK_PREFIX = "xl/externallinks/"
_X14_NAMESPACE = "http://schemas.microsoft.com/office/spreadsheetml/2009/9/main"
_XM_NAMESPACE = "http://schemas.microsoft.com/office/excel/2006/main"
_CHART_NAMESPACES = frozenset(
    {
        "http://schemas.openxmlformats.org/drawingml/2006/chart",
        "http://purl.oclc.org/ooxml/drawingml/chart",
    }
)


def _payload(package: _SafePackage, member: str) -> bytes:
    with package.open_xml_stream(member) as stream:
        return stream.read()


def _document(
    payload: bytes,
    *,
    namespace: str | frozenset[str],
    label: str,
) -> tuple[Document, Element]:
    document = minidom.parseString(  # noqa: S318 - bounded, DTD-screened OOXML.
        payload
    )
    root = _document_root(document)
    allowed = {namespace} if isinstance(namespace, str) else namespace
    if root.namespaceURI not in allowed:
        msg = f"Workbook {label} namespace is unsupported"
        raise ValueError(msg)
    return document, root


def _attribute_by_local_name(element: Element, local_name: str) -> str | None:
    attributes = element.attributes
    for index in range(attributes.length):
        attribute = attributes.item(index)
        if attribute is not None and attribute.localName == local_name:
            value = getattr(attribute, "value", None)
            return value if isinstance(value, str) else None
    return None


def _external_relationships(root: Element) -> tuple[Element, ...]:
    relationships: list[Element] = []
    for element in _direct_elements(root):
        if (
            element.namespaceURI == _RELATIONSHIPS_NAMESPACE
            and element.localName == "Relationship"
            and element.getAttribute("Type").rsplit("/", 1)[-1].casefold()
            == "externallink"
        ):
            if element.getAttribute("TargetMode") not in {"", "Internal"}:
                msg = "Workbook external-link relationship mode is unsupported"
                raise ValueError(msg)
            relationships.append(element)
    return tuple(relationships)


def _external_reference_ids(root: Element) -> tuple[str, ...]:
    containers = tuple(
        element
        for element in _direct_elements(root)
        if element.namespaceURI in _SPREADSHEETML_WORKSHEET_NAMESPACES
        and element.localName == "externalReferences"
    )
    if len(containers) > 1:
        msg = "Workbook contains duplicate external-reference containers"
        raise ValueError(msg)
    if not containers:
        return ()
    identifiers: list[str] = []
    for element in _direct_elements(containers[0]):
        if (
            element.namespaceURI not in _SPREADSHEETML_WORKSHEET_NAMESPACES
            or element.localName != "externalReference"
        ):
            msg = "Workbook external-reference container is invalid"
            raise ValueError(msg)
        identifier = _attribute_by_local_name(element, "id")
        if not identifier or identifier in identifiers:
            msg = "Workbook external-reference identifier is invalid"
            raise ValueError(msg)
        identifiers.append(identifier)
    return tuple(identifiers)


def _formula_element_allowed(member: str, element: Element) -> bool:
    lowered = member.casefold()
    namespace = element.namespaceURI
    name = element.localName
    if lowered == _WORKBOOK_MEMBER:
        return (
            namespace in _SPREADSHEETML_WORKSHEET_NAMESPACES and name == "definedName"
        )
    if re.fullmatch(r"xl/worksheets/[^/]+\.xml", lowered):
        return (
            namespace in _SPREADSHEETML_WORKSHEET_NAMESPACES
            and name in {"f", "formula", "formula1", "formula2"}
        ) or (
            namespace in {_X14_NAMESPACE, _XM_NAMESPACE}
            and name in {"f", "formula1", "formula2"}
        )
    if re.fullmatch(r"xl/tables/[^/]+\.xml", lowered):
        return namespace in _SPREADSHEETML_WORKSHEET_NAMESPACES and name in {
            "calculatedColumnFormula",
            "totalsRowFormula",
        }
    return bool(
        re.fullmatch(r"xl/charts/[^/]+\.xml", lowered)
        and namespace in _CHART_NAMESPACES
        and name == "f"
    )


def _formula_text_nodes(document: Document, member: str) -> tuple[minidom.Text, ...]:
    nodes: list[minidom.Text] = []
    for element in document.getElementsByTagName("*"):
        if not _formula_element_allowed(member, element):
            continue
        nodes.extend(
            child
            for child in element.childNodes
            if isinstance(child, minidom.Text) and child.data
        )
    return tuple(nodes)


def _validate_final_formula_references(
    package: _SafePackage,
    replacements: dict[str, bytes],
    *,
    final_link_count: int,
) -> None:
    """Validate every supported formula against the final compacted link space."""
    for member in sorted(package.names):
        lowered = member.casefold()
        if lowered.startswith(_EXTERNAL_LINK_PREFIX) or not lowered.endswith(".xml"):
            continue
        payload = (
            replacements[member]
            if member in replacements
            else _payload(package, member)
        )
        document = minidom.parseString(  # noqa: S318 - bounded OOXML.
            payload
        )
        for node in _formula_text_nodes(document, member):
            references = external_workbook_references(node.data)
            if any(index is None for index in references):
                msg = "Workbook external path reference cannot be mapped after removal"
                raise ExcelModificationError(msg)
            if any(
                index is not None and not 1 <= index <= final_link_count
                for index in references
            ):
                msg = "Workbook external formula index is invalid after removal"
                raise ExcelModificationError(msg)


def _verify_final_external_graph(
    package: _SafePackage,
    *,
    expected_count: int,
) -> None:
    workbook_document, workbook_root = _document(
        _payload(package, _WORKBOOK_MEMBER),
        namespace=_SPREADSHEETML_WORKSHEET_NAMESPACES,
        label="workbook",
    )
    del workbook_document
    relationships_document, relationships_root = _document(
        _payload(package, _RELATIONSHIPS_MEMBER),
        namespace=_RELATIONSHIPS_NAMESPACE,
        label="relationship",
    )
    del relationships_document
    reference_ids = _external_reference_ids(workbook_root)
    relationships = _external_relationships(relationships_root)
    by_id = {element.getAttribute("Id"): element for element in relationships}
    expected_members = tuple(
        f"xl/externalLinks/externalLink{index}.xml"
        for index in range(1, expected_count + 1)
    )
    actual_members = tuple(
        _resolve_target(_WORKBOOK_MEMBER, by_id[identifier].getAttribute("Target"))
        for identifier in reference_ids
        if identifier in by_id
    )
    if (
        len(reference_ids) != expected_count
        or set(reference_ids) != set(by_id)
        or actual_members != expected_members
        or any(not package.has(member) for member in expected_members)
    ):
        msg = "Workbook external-link removal graph verification failed"
        raise ExcelModificationError(msg)
    _validate_final_formula_references(
        package,
        {},
        final_link_count=expected_count,
    )


def _reject_remaining_references(package: _SafePackage) -> None:
    for member in sorted(package.names):
        lowered = member.casefold()
        if lowered.startswith(_EXTERNAL_LINK_PREFIX) or not lowered.endswith(".xml"):
            continue
        document = minidom.parseString(  # noqa: S318 - bounded OOXML.
            _payload(package, member)
        )
        if any(
            formula_has_external_reference(node.data)
            for node in _formula_text_nodes(document, member)
        ):
            msg = "Workbook still contains an external formula reference"
            raise ExcelModificationError(msg)


def _remove_external_references(document: Document, root: Element) -> bytes:
    for element in tuple(_direct_elements(root)):
        if (
            element.namespaceURI in _SPREADSHEETML_WORKSHEET_NAMESPACES
            and element.localName == "externalReferences"
        ):
            root.removeChild(element)
    return document.toxml(encoding="utf-8")


def _remove_external_relationships(document: Document, root: Element) -> bytes:
    for element in _external_relationships(root):
        root.removeChild(element)
    return document.toxml(encoding="utf-8")


def _remove_external_content_types(document: Document, root: Element) -> bytes:
    for element in tuple(_direct_elements(root)):
        if (
            element.namespaceURI == _CONTENT_TYPES_NAMESPACE
            and element.localName == "Override"
            and element.getAttribute("PartName")
            .lstrip("/")
            .casefold()
            .startswith(_EXTERNAL_LINK_PREFIX)
        ):
            root.removeChild(element)
    return document.toxml(encoding="utf-8")


def create_external_link_cleanup_output(
    source_path: Path,
    output_path: Path,
    *,
    source_fingerprint: str,
) -> int:
    """Remove all external-link parts when no formula reference remains."""
    with _SafePackage(source_path) as package:
        package.verify_fingerprint(source_fingerprint)
        package.reject_forbidden_xml_declarations()
        workbook_payload = _payload(package, _WORKBOOK_MEMBER)
        relationships_payload = _payload(package, _RELATIONSHIPS_MEMBER)
        content_types_payload = _payload(package, _CONTENT_TYPES_MEMBER)
        workbook_document, workbook_root = _document(
            workbook_payload,
            namespace=_SPREADSHEETML_WORKSHEET_NAMESPACES,
            label="workbook",
        )
        relationships_document, relationships_root = _document(
            relationships_payload,
            namespace=_RELATIONSHIPS_NAMESPACE,
            label="relationship",
        )
        content_types_document, content_types_root = _document(
            content_types_payload,
            namespace=_CONTENT_TYPES_NAMESPACE,
            label="content-type",
        )
        relationships = _external_relationships(relationships_root)
        relationship_ids = tuple(
            element.getAttribute("Id") for element in relationships
        )
        reference_ids = _external_reference_ids(workbook_root)
        external_members = frozenset(
            member
            for member in package.names
            if member.casefold().startswith(_EXTERNAL_LINK_PREFIX)
        )
        if not relationships and not reference_ids and not external_members:
            _copy_package(
                source_path,
                output_path,
                {},
                source_fingerprint=source_fingerprint,
            )
            return 0
        if (
            not relationships
            or any(not identifier for identifier in relationship_ids)
            or len(relationship_ids) != len(set(relationship_ids))
            or set(relationship_ids) != set(reference_ids)
            or not external_members
            or any(
                _resolve_target(
                    _WORKBOOK_MEMBER,
                    element.getAttribute("Target"),
                )
                not in external_members
                for element in relationships
            )
        ):
            msg = "Workbook external-link package state is inconsistent"
            raise ValueError(msg)
        _reject_remaining_references(package)
        replacements = {
            _WORKBOOK_MEMBER: _remove_external_references(
                workbook_document,
                workbook_root,
            ),
            _RELATIONSHIPS_MEMBER: _remove_external_relationships(
                relationships_document,
                relationships_root,
            ),
            _CONTENT_TYPES_MEMBER: _remove_external_content_types(
                content_types_document,
                content_types_root,
            ),
        }

    _copy_package(
        source_path,
        output_path,
        replacements,
        removals=external_members,
        source_fingerprint=source_fingerprint,
    )
    with _SafePackage(output_path) as output_package:
        if any(
            member.casefold().startswith(_EXTERNAL_LINK_PREFIX)
            for member in output_package.names
        ):
            msg = "Workbook external-link cleanup verification failed"
            raise ExcelModificationError(msg)
        output_workbook = output_package.read_xml(_WORKBOOK_MEMBER)
        if any(
            _local_name(element.tag) == "externalReferences"
            for element in output_workbook.iter()
        ):
            msg = "Workbook external-link cleanup verification failed"
            raise ExcelModificationError(msg)
    return len(relationships)


def _relationship_part(member: str) -> str:
    path = PurePosixPath(member)
    return str(path.parent / "_rels" / f"{path.name}.rels")


def _rewrite_external_indexes(  # noqa: PLR0913
    payload: bytes,
    *,
    member: str,
    mapping: dict[int, int],
    removed: frozenset[int],
    request: WorkbookPatchRequest | None = None,
    sheet_name: str | None = None,
    sheet_names: tuple[str, ...] = (),
    final_formula_cells: frozenset[tuple[str, str]] = frozenset(),
) -> bytes:
    document = minidom.parseString(  # noqa: S318 - bounded, DTD-screened OOXML.
        payload
    )
    changed = False
    for child in _formula_text_nodes(document, member):
        if request is not None and _is_requested_final_formula(
            child,
            member=member,
            request=request,
            sheet_name=sheet_name,
            sheet_names=sheet_names,
            final_formula_cells=final_formula_cells,
        ):
            continue

        def replace(index: int) -> int | None:
            if index in removed:
                msg = "Workbook removed external link is still referenced"
                raise ExcelModificationError(msg)
            return mapping.get(index)

        rewritten = rewrite_external_workbook_indexes(child.data, replace)
        changed = changed or rewritten != child.data
        child.data = rewritten
    return document.toxml(encoding="utf-8") if changed else payload


def _ancestor_element(node: minidom.Node, local_name: str) -> Element | None:
    parent = node.parentNode
    while parent is not None:
        if isinstance(parent, minidom.Element) and parent.localName == local_name:
            return parent
        parent = parent.parentNode
    return None


def _is_requested_final_formula(  # noqa: PLR0911, PLR0913
    node: minidom.Text,
    *,
    member: str,
    request: WorkbookPatchRequest,
    sheet_name: str | None,
    sheet_names: tuple[str, ...],
    final_formula_cells: frozenset[tuple[str, str]],
) -> bool:
    if member.casefold() == _WORKBOOK_MEMBER:
        definition = _ancestor_element(node, "definedName")
        if definition is None:
            return False
        raw_scope = definition.getAttribute("localSheetId")
        scope: str | None = None
        if raw_scope:
            if not raw_scope.isdigit() or int(raw_scope) >= len(sheet_names):
                msg = "Workbook defined name scope is invalid"
                raise ValueError(msg)
            scope = sheet_names[int(raw_scope)].casefold()
        defined_name_identity = (definition.getAttribute("name").casefold(), scope)
        return defined_name_identity in {
            (
                patch.name.casefold(),
                patch.scope_sheet_name.casefold()
                if patch.scope_sheet_name is not None
                else None,
            )
            for patch in request.defined_names
            if patch.operation != "delete"
        }
    if sheet_name is None:
        return False
    sheet_identity = sheet_name.casefold()
    if (
        sheet_identity
        in {patch.sheet_name.casefold() for patch in request.data_validations}
        and _ancestor_element(node, "dataValidation") is not None
    ):
        return True
    if (
        sheet_identity
        in {patch.sheet_name.casefold() for patch in request.conditional_formatting}
        and _ancestor_element(node, "cfRule") is not None
    ):
        return True
    cell = _ancestor_element(node, "c")
    if cell is None:
        return False
    coordinate = cell.getAttribute("r")
    if (sheet_identity, coordinate) in final_formula_cells:
        return True
    return (sheet_identity, coordinate) in {
        (patch.sheet_name.casefold(), patch.coordinate)
        for patch in request.cells
        if patch.content.kind in {"formula", "array_formula"}
    }


def create_external_link_removal_output(  # noqa: C901, PLR0912, PLR0913, PLR0915
    source_path: Path,
    output_path: Path,
    patches: Sequence[ExternalLinkRemovalPatch],
    *,
    source_fingerprint: str,
    final_request: WorkbookPatchRequest | None = None,
    final_formula_cells: frozenset[tuple[str, str]] = frozenset(),
) -> int:
    """Remove selected external-link identities and compact later indexes."""
    requested = frozenset(patch.link_index for patch in patches)
    with _SafePackage(source_path) as package:
        package.verify_fingerprint(source_fingerprint)
        package.reject_forbidden_xml_declarations()
        _workbook, sheet_records = _workbook_records(package)
        sheet_names = tuple(record.name for record in sheet_records)
        sheet_by_member = {
            record.part_name: record.name
            for record in sheet_records
            if record.part_name is not None
        }
        workbook_payload = _payload(package, _WORKBOOK_MEMBER)
        relationships_payload = _payload(package, _RELATIONSHIPS_MEMBER)
        content_types_payload = _payload(package, _CONTENT_TYPES_MEMBER)
        workbook_document, workbook_root = _document(
            workbook_payload,
            namespace=_SPREADSHEETML_WORKSHEET_NAMESPACES,
            label="workbook",
        )
        relationships_document, relationships_root = _document(
            relationships_payload,
            namespace=_RELATIONSHIPS_NAMESPACE,
            label="relationship",
        )
        content_types_document, content_types_root = _document(
            content_types_payload,
            namespace=_CONTENT_TYPES_NAMESPACE,
            label="content-type",
        )
        relationships = _external_relationships(relationships_root)
        reference_ids = _external_reference_ids(workbook_root)
        by_id = {element.getAttribute("Id"): element for element in relationships}
        if (
            not requested
            or max(requested) > len(reference_ids)
            or set(reference_ids) != set(by_id)
        ):
            msg = "Workbook external-link removal target is invalid"
            raise ExcelModificationError(msg)
        ordered_members: list[str] = []
        for identifier in reference_ids:
            member = _resolve_target(
                _WORKBOOK_MEMBER,
                by_id[identifier].getAttribute("Target"),
            )
            if not package.has(member):
                msg = "Workbook external-link package state is inconsistent"
                raise ValueError(msg)
            ordered_members.append(member)
        mapping: dict[int, int] = {}
        next_index = 1
        for old_index in range(1, len(ordered_members) + 1):
            if old_index in requested:
                continue
            mapping[old_index] = next_index
            next_index += 1
        removals: set[str] = set(ordered_members)
        additions: dict[str, bytes] = {}
        for old_index, member in enumerate(ordered_members, start=1):
            relationship_member = _relationship_part(member)
            if package.has(relationship_member):
                removals.add(relationship_member)
            if old_index in requested:
                continue
            new_member = f"xl/externalLinks/externalLink{mapping[old_index]}.xml"
            additions[new_member] = _payload(package, member)
            if package.has(relationship_member):
                additions[_relationship_part(new_member)] = _payload(
                    package,
                    relationship_member,
                )
        container = next(
            (
                element
                for element in _direct_elements(workbook_root)
                if element.namespaceURI in _SPREADSHEETML_WORKSHEET_NAMESPACES
                and element.localName == "externalReferences"
            ),
            None,
        )
        if container is None:  # pragma: no cover - reference-id invariant.
            msg = "Workbook external-link package state is inconsistent"
            raise ValueError(msg)
        for old_index in sorted(requested, reverse=True):
            identifier = reference_ids[old_index - 1]
            reference = next(
                element
                for element in _direct_elements(container)
                if _attribute_by_local_name(element, "id") == identifier
            )
            container.removeChild(reference)
            relationships_root.removeChild(by_id[identifier])
        if not tuple(_direct_elements(container)):
            workbook_root.removeChild(container)
        remaining_ids = [
            identifier
            for index, identifier in enumerate(reference_ids, start=1)
            if index not in requested
        ]
        for new_index, identifier in enumerate(remaining_ids, start=1):
            by_id[identifier].setAttribute(
                "Target",
                f"externalLinks/externalLink{new_index}.xml",
            )
        for element in tuple(_direct_elements(content_types_root)):
            if (
                element.namespaceURI != _CONTENT_TYPES_NAMESPACE
                or element.localName != "Override"
            ):
                continue
            part_name = element.getAttribute("PartName").lstrip("/")
            if part_name not in ordered_members:
                continue
            old_index = ordered_members.index(part_name) + 1
            if old_index in requested:
                content_types_root.removeChild(element)
            else:
                element.setAttribute(
                    "PartName",
                    f"/xl/externalLinks/externalLink{mapping[old_index]}.xml",
                )
        replacements = {
            _WORKBOOK_MEMBER: _rewrite_external_indexes(
                workbook_document.toxml(encoding="utf-8"),
                member=_WORKBOOK_MEMBER,
                mapping=mapping,
                removed=requested,
                request=final_request,
                sheet_names=sheet_names,
                final_formula_cells=final_formula_cells,
            ),
            _RELATIONSHIPS_MEMBER: relationships_document.toxml(encoding="utf-8"),
            _CONTENT_TYPES_MEMBER: content_types_document.toxml(encoding="utf-8"),
        }
        for member in package.names:
            lowered = member.casefold()
            if (
                not lowered.endswith(".xml")
                or lowered.startswith(_EXTERNAL_LINK_PREFIX)
                or not (lowered == _WORKBOOK_MEMBER or lowered.startswith("xl/"))
                or member in replacements
            ):
                continue
            rewritten = _rewrite_external_indexes(
                _payload(package, member),
                member=member,
                mapping=mapping,
                removed=requested,
                request=final_request,
                sheet_name=sheet_by_member.get(member),
                sheet_names=sheet_names,
                final_formula_cells=final_formula_cells,
            )
            if rewritten != _payload(package, member):
                replacements[member] = rewritten
        _validate_final_formula_references(
            package,
            replacements,
            final_link_count=len(mapping),
        )

    _copy_package(
        source_path,
        output_path,
        replacements,
        additions=additions,
        removals=frozenset(removals),
        source_fingerprint=source_fingerprint,
    )
    with _SafePackage(output_path) as output_package:
        _verify_final_external_graph(output_package, expected_count=len(mapping))
    return len(requested)

"""Atomic worksheet, drawing, and media package-graph modification."""

from __future__ import annotations

import re
from base64 import b64decode
from dataclasses import dataclass
from pathlib import PurePosixPath
from typing import TYPE_CHECKING
from xml.dom import minidom

from document_sdk.excel._column_modification import (
    _copy_package,
    _direct_elements,
    _document_root,
)
from document_sdk.excel._formula_references import is_external_workbook_range
from document_sdk.excel._package import _SafePackage
from document_sdk.excel._package_security import _resolve_target, _serialize_xml
from document_sdk.excel._package_workbook import _workbook_records
from document_sdk.excel._package_worksheet import (
    _SPREADSHEETML_WORKSHEET_NAMESPACES,
)
from document_sdk.excel._structural_modification import (
    _pivot_cache_worksheet_sources,
)
from document_sdk.excel._xml_namespaces import namespace_prefix
from document_sdk.excel.errors import ExcelModificationError

if TYPE_CHECKING:
    from collections.abc import Sequence
    from pathlib import Path
    from xml.dom.minidom import Document, Element

    from document_sdk.excel._package_types import _Relationship, _SheetRecord
    from document_sdk.excel.models import (
        DrawingMarkerPatch,
        WorkbookPatchRequest,
        WorksheetDeletePatch,
        WorksheetDrawingRemovalPatch,
        WorksheetImagePatch,
    )


_CONTENT_TYPES_MEMBER = "[Content_Types].xml"
_CONTENT_TYPES_NAMESPACE = (
    "http://schemas.openxmlformats.org/package/2006/content-types"
)
_RELATIONSHIPS_NAMESPACE = (
    "http://schemas.openxmlformats.org/package/2006/relationships"
)
_RELATIONSHIPS_DOCUMENT_NAMESPACE = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
)
_DRAWING_NAMESPACE = (
    "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing"
)
_DRAWING_MAIN_NAMESPACE = "http://schemas.openxmlformats.org/drawingml/2006/main"
_DRAWING_CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.drawing+xml"
_WORKBOOK_MEMBER = "xl/workbook.xml"
_WORKBOOK_RELS_MEMBER = "xl/_rels/workbook.xml.rels"
_X14_NAMESPACE = "http://schemas.microsoft.com/office/spreadsheetml/2009/9/main"
_XM_NAMESPACE = "http://schemas.microsoft.com/office/excel/2006/main"
_CHART_NAMESPACES = frozenset(
    {
        "http://schemas.openxmlformats.org/drawingml/2006/chart",
        "http://purl.oclc.org/ooxml/drawingml/chart",
    }
)
_STRICT_SPREADSHEET_NAMESPACE = "http://purl.oclc.org/ooxml/spreadsheetml/main"
_STRICT_DRAWING_NAMESPACE = "http://purl.oclc.org/ooxml/drawingml/spreadsheetDrawing"
_STRICT_DRAWING_MAIN_NAMESPACE = "http://purl.oclc.org/ooxml/drawingml/main"
_STRICT_RELATIONSHIPS_DOCUMENT_NAMESPACE = (
    "http://purl.oclc.org/ooxml/officeDocument/relationships"
)


@dataclass(frozen=True, slots=True)
class _PendingGraphChange:
    operation: str
    target: str
    count: int = 1


def _rels_member(member: str) -> str:
    path = PurePosixPath(member)
    return str(path.parent / "_rels" / f"{path.name}.rels")


def _document(payload: bytes) -> tuple[Document, Element]:
    document = minidom.parseString(  # noqa: S318 - bounded, DTD-screened OOXML.
        payload
    )
    return document, _document_root(document)


def _relationship_elements(root: Element) -> tuple[Element, ...]:
    return tuple(
        element
        for element in _direct_elements(root)
        if element.namespaceURI == _RELATIONSHIPS_NAMESPACE
        and element.localName == "Relationship"
    )


def _relationship_id(element: Element) -> str | None:
    for index in range(element.attributes.length):
        attribute = element.attributes.item(index)
        if attribute is not None and attribute.localName == "id":
            value = getattr(attribute, "value", None)
            return value if isinstance(value, str) else None
    return None


def _next_identifier(elements: Sequence[Element], prefix: str = "rId") -> str:
    used = {element.getAttribute("Id") for element in elements}
    index = 1
    while f"{prefix}{index}" in used:
        index += 1
    return f"{prefix}{index}"


def _next_member(names: frozenset[str], directory: str, stem: str, suffix: str) -> str:
    pattern = re.compile(
        rf"{re.escape(directory)}/{re.escape(stem)}([1-9][0-9]*){re.escape(suffix)}$",
        re.IGNORECASE,
    )
    used = {
        int(match.group(1))
        for name in names
        if (match := pattern.fullmatch(name)) is not None
    }
    index = 1
    while index in used:
        index += 1
    return f"{directory}/{stem}{index}{suffix}"


def _load_relationship_document(
    package: _SafePackage,
    member: str,
    replacements: dict[str, bytes] | None = None,
    additions: dict[str, bytes] | None = None,
) -> tuple[Document, Element, bytes | None]:
    replacement_payload = (replacements or {}).get(member)
    addition_payload = (additions or {}).get(member)
    payload = replacement_payload or addition_payload
    if payload is not None or package.has(member):
        payload = payload if payload is not None else _read_payload(package, member)
        document, root = _document(payload)
        if root.namespaceURI != _RELATIONSHIPS_NAMESPACE:
            msg = "Workbook relationship namespace is unsupported"
            raise ValueError(msg)
        return document, root, payload
    document = minidom.Document()
    root = document.createElementNS(_RELATIONSHIPS_NAMESPACE, "Relationships")
    root.setAttribute("xmlns", _RELATIONSHIPS_NAMESPACE)
    document.appendChild(root)
    return document, root, None


def _read_payload(package: _SafePackage, member: str) -> bytes:
    with package.open_xml_stream(member) as stream:
        return stream.read()


def _owned_graph(package: _SafePackage, roots: set[str]) -> set[str]:
    owned = set(roots)
    pending = list(roots)
    while pending:
        member = pending.pop()
        rels_member = _rels_member(member)
        if not package.has(rels_member):
            continue
        owned.add(rels_member)
        document, root = _document(_read_payload(package, rels_member))
        del document
        if root.namespaceURI != _RELATIONSHIPS_NAMESPACE:
            msg = "Workbook relationship namespace is unsupported"
            raise ValueError(msg)
        for relationship in _relationship_elements(root):
            if relationship.getAttribute("TargetMode") == "External":
                continue
            target = _resolve_target(member, relationship.getAttribute("Target"))
            if package.has(target) and target not in owned:
                owned.add(target)
                pending.append(target)
    return owned


def _externally_referenced_parts(
    package: _SafePackage,
    candidates: set[str],
) -> set[str]:
    referenced: set[str] = set()
    for rels_member in package.names:
        if not rels_member.endswith(".rels") or rels_member in candidates:
            continue
        path = PurePosixPath(rels_member)
        if path.parent.name != "_rels":
            continue
        owner = str(path.parent.parent / path.name.removesuffix(".rels"))
        if owner in candidates:
            continue
        _document_value, root = _document(_read_payload(package, rels_member))
        for relationship in _relationship_elements(root):
            if relationship.getAttribute("TargetMode") == "External":
                continue
            target = _resolve_target(owner, relationship.getAttribute("Target"))
            if target in candidates:
                referenced.add(target)
    return referenced


def _safe_removals(package: _SafePackage, roots: set[str]) -> set[str]:
    candidates = _owned_graph(package, roots)
    protected = _externally_referenced_parts(package, candidates)
    return candidates - protected


def _relationship_owner(member: str) -> str | None:
    path = PurePosixPath(member)
    if path.name == ".rels" and str(path.parent) == "_rels":
        return ""
    if path.parent.name != "_rels" or not path.name.endswith(".rels"):
        return None
    return str(path.parent.parent / path.name.removesuffix(".rels"))


def _state_payload(
    package: _SafePackage,
    member: str,
    replacements: dict[str, bytes],
    additions: dict[str, bytes],
) -> bytes:
    if member in replacements:
        return replacements[member]
    if member in additions:
        return additions[member]
    return _read_payload(package, member)


def _final_safe_removals(  # noqa: C901
    package: _SafePackage,
    roots: set[str],
    replacements: dict[str, bytes],
    additions: dict[str, bytes],
) -> set[str]:
    """Resolve requested removals against the final in-memory relationship graph."""
    if not roots:
        return set()
    candidates = _owned_graph(package, roots)
    names = set(package.names) | set(additions)
    protected: set[str] = set()
    final_edges: dict[str, set[str]] = {}
    for rels_member in sorted(name for name in names if name.endswith(".rels")):
        owner = _relationship_owner(rels_member)
        if owner is None:
            continue
        _document_value, root = _document(
            _state_payload(package, rels_member, replacements, additions)
        )
        targets: set[str] = set()
        for relationship in _relationship_elements(root):
            if relationship.getAttribute("TargetMode") == "External":
                continue
            target = _resolve_target(owner, relationship.getAttribute("Target"))
            targets.add(target)
            if owner not in candidates and target in candidates:
                protected.add(target)
        final_edges[owner] = targets
    pending = list(protected)
    while pending:
        member = pending.pop()
        rels_member = _rels_member(member)
        if rels_member in candidates and rels_member not in protected:
            protected.add(rels_member)
        for target in final_edges.get(member, set()):
            if target in candidates and target not in protected:
                protected.add(target)
                pending.append(target)
    return candidates - protected


def _reachable_parts(package: _SafePackage) -> set[str]:
    """Return parts reachable from the package root, including their rels."""
    reachable: set[str] = set()
    pending = [""]
    visited: set[str] = set()
    while pending:
        owner = pending.pop()
        if owner in visited:
            continue
        visited.add(owner)
        rels_member = "_rels/.rels" if not owner else _rels_member(owner)
        if not package.has(rels_member):
            continue
        reachable.add(rels_member)
        document, root = _document(_read_payload(package, rels_member))
        del document
        if root.namespaceURI != _RELATIONSHIPS_NAMESPACE:
            msg = "Workbook relationship namespace is unsupported"
            raise ValueError(msg)
        for relationship in _relationship_elements(root):
            if relationship.getAttribute("TargetMode") == "External":
                continue
            target = _resolve_target(owner, relationship.getAttribute("Target"))
            if not package.has(target):
                msg = "Patched workbook relationship target is missing"
                raise ExcelModificationError(msg)
            if target not in reachable:
                reachable.add(target)
                pending.append(target)
    return reachable


def _verify_relationship_targets(
    package: _SafePackage,
    *,
    required_reachable: frozenset[str] = frozenset(),
) -> None:
    """Reject missing targets and transaction-created unreachable members."""
    reachable = _reachable_parts(package)
    for rels_member in sorted(name for name in package.names if name.endswith(".rels")):
        owner = _relationship_owner(rels_member)
        if owner is None:
            continue
        document, root = _document(_read_payload(package, rels_member))
        del document
        if root.namespaceURI != _RELATIONSHIPS_NAMESPACE:
            msg = "Workbook relationship namespace is unsupported"
            raise ValueError(msg)
        for relationship in _relationship_elements(root):
            if relationship.getAttribute("TargetMode") == "External":
                continue
            target = _resolve_target(owner, relationship.getAttribute("Target"))
            if not package.has(target):
                msg = "Patched workbook relationship target is missing"
                raise ExcelModificationError(msg)
    if not required_reachable <= reachable:
        msg = "Patched workbook contains an unreachable transaction member"
        raise ExcelModificationError(msg)


def _sheet_token_identity(value: str) -> str:
    value = value.strip()
    if value.startswith("'") and value.endswith("'"):
        value = value[1:-1].replace("''", "'")
    return value.casefold()


def _formula_references_deleted_sheet(
    formula: str,
    deleted: frozenset[str],
    sheet_order: tuple[str, ...],
) -> bool:
    from openpyxl.formula import Tokenizer

    source = formula if formula.startswith("=") else f"={formula}"
    try:
        tokens = Tokenizer(source).items
    except Exception:  # noqa: BLE001 - third-party parser may raise undocumented exceptions
        msg = "Workbook formula cannot be safely checked before worksheet deletion"
        raise ExcelModificationError(msg) from None
    order = [name.casefold() for name in sheet_order]
    for token in tokens:
        if (
            token.type != "OPERAND"
            or token.subtype != "RANGE"
            or "!" not in token.value
        ):
            continue
        if is_external_workbook_range(token.value):
            continue
        sheet_token = token.value.rsplit("!", 1)[0]
        identity = _sheet_token_identity(sheet_token)
        if identity in deleted:
            return True
        if ":" not in identity:
            continue
        start, end = identity.split(":", 1)
        if start not in order or end not in order:
            msg = "Workbook 3D reference cannot be safely checked before deletion"
            raise ExcelModificationError(msg)
        minimum, maximum = sorted((order.index(start), order.index(end)))
        if deleted & set(order[minimum : maximum + 1]):
            return True
    return False


def _element_text(element: Element) -> str:
    return "".join(
        str(getattr(child, "data", ""))
        for child in element.childNodes
        if child.nodeType in {minidom.Node.TEXT_NODE, minidom.Node.CDATA_SECTION_NODE}
    )


def _preflight_worksheet_deletions(  # noqa: C901, PLR0912, PLR0915
    package: _SafePackage,
    records: Sequence[_SheetRecord],
    requested: set[str],
    request: WorkbookPatchRequest,
) -> None:
    """Reject deletions that would leave a surviving supported reference stale."""
    sheet_order = tuple(str(record.name) for record in records)
    deleted = frozenset(requested)
    removed_indexes = {
        index
        for index, record in enumerate(records)
        if str(record.name).casefold() in deleted
    }
    requested_cells = {
        (patch.sheet_name.casefold(), patch.coordinate) for patch in request.cells
    }
    requested_validations = {
        patch.sheet_name.casefold() for patch in request.data_validations
    }
    requested_conditionals = {
        patch.sheet_name.casefold() for patch in request.conditional_formatting
    }
    requested_hyperlinks = {patch.sheet_name.casefold() for patch in request.hyperlinks}
    requested_names = {
        (
            patch.name.casefold(),
            patch.scope_sheet_name.casefold()
            if patch.scope_sheet_name is not None
            else None,
        )
        for patch in request.defined_names
    }
    _preflight_requested_worksheet_references(request, deleted, sheet_order)
    if any(
        source.sheet_name.casefold() in deleted
        for source in _pivot_cache_worksheet_sources(package)
    ):
        msg = "Workbook worksheet deletion has a retained Pivot Cache source"
        raise ExcelModificationError(msg)
    workbook_document, workbook_root = _document(
        _read_payload(package, _WORKBOOK_MEMBER)
    )
    del workbook_document
    for element in workbook_root.getElementsByTagNameNS("*", "definedName"):
        if element.namespaceURI not in _SPREADSHEETML_WORKSHEET_NAMESPACES:
            continue
        raw_scope = element.getAttribute("localSheetId")
        if raw_scope:
            if not raw_scope.isdigit() or int(raw_scope) >= len(sheet_order):
                msg = "Workbook defined name scope is invalid"
                raise ValueError(msg)
            if int(raw_scope) in removed_indexes:
                continue
        scope_name = sheet_order[int(raw_scope)].casefold() if raw_scope else None
        if (element.getAttribute("name").casefold(), scope_name) in requested_names:
            continue
        formula = _element_text(element)
        if formula and _formula_references_deleted_sheet(formula, deleted, sheet_order):
            msg = "Workbook worksheet deletion has surviving defined-name references"
            raise ExcelModificationError(msg)
    if package.has("xl/calcChain.xml"):
        msg = "Workbook worksheet deletion with a calculation chain is unsupported"
        raise ExcelModificationError(msg)
    for record in records:
        name = str(record.name)
        member = record.part_name
        if name.casefold() in deleted or not isinstance(member, str):
            continue
        document, root = _document(_read_payload(package, member))
        del document
        related_parts: set[str] = set()
        for relationship in _relationships_for_member(package, member):
            relationship_kind = relationship.relationship_type.rsplit("/", 1)[
                -1
            ].casefold()
            if relationship.target is None:
                continue
            if record.sheet_type == "worksheet" and relationship_kind == "table":
                related_parts.add(relationship.target)
            if relationship_kind != "drawing" or record.sheet_type not in {
                "worksheet",
                "chartsheet",
            }:
                continue
            related_parts.add(relationship.target)
            related_parts.update(
                child.target
                for child in _relationships_for_member(package, relationship.target)
                if child.target is not None
                and child.relationship_type.rsplit("/", 1)[-1].casefold() == "chart"
            )
        for current_member, current_root in (
            (member, root),
            *(
                (part, _document(_read_payload(package, part))[1])
                for part in sorted(related_parts)
            ),
        ):
            for element in current_root.getElementsByTagName("*"):
                if current_member == member and _source_element_is_replaced(
                    element,
                    sheet_name=name,
                    requested_cells=requested_cells,
                    requested_validations=requested_validations,
                    requested_conditionals=requested_conditionals,
                    requested_hyperlinks=requested_hyperlinks,
                ):
                    continue
                if (
                    current_member == member
                    and element.namespaceURI in _SPREADSHEETML_WORKSHEET_NAMESPACES
                    and element.localName == "hyperlink"
                    and element.hasAttribute("location")
                    and _formula_references_deleted_sheet(
                        element.getAttribute("location"),
                        deleted,
                        sheet_order,
                    )
                ):
                    msg = (
                        "Workbook worksheet deletion has a surviving "
                        "internal hyperlink reference"
                    )
                    raise ExcelModificationError(msg)
                is_formula = (
                    (
                        element.namespaceURI in _SPREADSHEETML_WORKSHEET_NAMESPACES
                        and element.localName
                        in {
                            "f",
                            "formula",
                            "formula1",
                            "formula2",
                            "calculatedColumnFormula",
                            "totalsRowFormula",
                        }
                    )
                    or (
                        element.namespaceURI in {_X14_NAMESPACE, _XM_NAMESPACE}
                        and element.localName in {"f", "formula1", "formula2"}
                    )
                    or (
                        element.namespaceURI in _CHART_NAMESPACES
                        and element.localName == "f"
                    )
                )
                formula = _element_text(element) if is_formula else ""
                if formula and _formula_references_deleted_sheet(
                    formula,
                    deleted,
                    sheet_order,
                ):
                    msg = "Workbook worksheet deletion has surviving formula references"
                    raise ExcelModificationError(msg)
                if _unknown_element_references_deleted_sheet(
                    element,
                    deleted=deleted,
                    sheet_order=sheet_order,
                ):
                    msg = "Workbook unknown extension references a deleted worksheet"
                    raise ExcelModificationError(msg)
            del current_member


def _element_ancestor_names(element: Element) -> frozenset[str]:
    names: set[str] = set()
    parent = element.parentNode
    while parent is not None:
        local_name = getattr(parent, "localName", None)
        if isinstance(local_name, str):
            names.add(local_name)
        parent = parent.parentNode
    return frozenset(names)


def _source_element_is_replaced(  # noqa: PLR0913
    element: Element,
    *,
    sheet_name: str,
    requested_cells: set[tuple[str, str]],
    requested_validations: set[str],
    requested_conditionals: set[str],
    requested_hyperlinks: set[str],
) -> bool:
    identity = sheet_name.casefold()
    if (
        identity in requested_hyperlinks
        and element.namespaceURI in _SPREADSHEETML_WORKSHEET_NAMESPACES
        and element.localName == "hyperlink"
    ):
        return True
    ancestors = _element_ancestor_names(element)
    if identity in requested_validations and "dataValidation" in ancestors:
        return True
    if identity in requested_conditionals and (
        "conditionalFormatting" in ancestors or "cfRule" in ancestors
    ):
        return True
    if element.localName != "f":
        return False
    parent = element.parentNode
    coordinate = (
        parent.getAttribute("r")
        if isinstance(parent, minidom.Element) and parent.localName == "c"
        else ""
    )
    return (identity, coordinate) in requested_cells


def _preflight_requested_worksheet_references(
    request: WorkbookPatchRequest,
    deleted: frozenset[str],
    sheet_order: tuple[str, ...],
) -> None:
    if deleted & {patch.name.casefold() for patch in request.create_sheets}:
        msg = "Workbook worksheet deletion conflicts with worksheet creation"
        raise ExcelModificationError(msg)
    if request.sheet_order is not None and deleted & {
        name.casefold() for name in request.sheet_order.sheet_names
    }:
        msg = "Workbook sheet order contains a deleted worksheet"
        raise ExcelModificationError(msg)
    formulas = _requested_formula_values(request)
    if any(
        _formula_references_deleted_sheet(formula, deleted, sheet_order)
        for formula in formulas
    ):
        msg = "Workbook patch would retain a reference to a deleted worksheet"
        raise ExcelModificationError(msg)


def _requested_formula_values(request: WorkbookPatchRequest) -> list[str]:
    """Collect every supported formula introduced by one workbook request."""
    formulas = [
        str(patch.content.value)
        for patch in request.cells
        if patch.content.kind in {"formula", "array_formula"}
    ]
    formulas.extend(
        str(patch.formula)
        for patch in request.defined_names
        if patch.operation != "delete" and patch.formula is not None
    )
    formulas.extend(
        formula
        for patch in request.data_validations
        for rule in patch.rules
        for formula in (rule.formula1, rule.formula2)
        if formula is not None
    )
    formulas.extend(
        formula
        for patch in request.conditional_formatting
        for block in patch.blocks
        for rule in block.rules
        for formula in rule.formulas
    )
    formulas.extend(
        link.location
        for patch in request.hyperlinks
        for link in patch.links
        if link.location is not None
    )
    formulas.extend(
        str(value.value)
        for patch in request.named_ranges
        for row in patch.values
        for value in row
        if value.kind in {"formula", "array_formula"}
    )
    return formulas


def _unknown_element_references_deleted_sheet(
    element: Element,
    *,
    deleted: frozenset[str],
    sheet_order: tuple[str, ...],
) -> bool:
    known_namespaces = (
        _SPREADSHEETML_WORKSHEET_NAMESPACES
        | {_X14_NAMESPACE, _XM_NAMESPACE}
        | _CHART_NAMESPACES
    )
    if element.namespaceURI in known_namespaces:
        return False
    values: list[str] = []
    for index in range(element.attributes.length):
        attribute = element.attributes.item(index)
        if attribute is not None and attribute.localName in {
            "ref",
            "sqref",
            "formula",
            "formula1",
            "formula2",
        }:
            values.append(str(getattr(attribute, "value", "")))
    if element.localName in {"f", "formula", "formula1", "formula2", "ref", "sqref"}:
        value = _element_text(element)
        if value:
            values.append(value)
    return any(
        _formula_references_deleted_sheet(value, deleted, sheet_order)
        for value in values
    )


def _relationships_for_member(
    package: _SafePackage,
    member: str,
) -> tuple[_Relationship, ...]:
    from document_sdk.excel._package_security import _relationships

    return tuple(_relationships(package, member).values())


def _remove_content_type_overrides(
    root: Element,
    removals: set[str],
) -> None:
    for element in tuple(_direct_elements(root)):
        if (
            element.namespaceURI == _CONTENT_TYPES_NAMESPACE
            and element.localName == "Override"
            and element.getAttribute("PartName").lstrip("/") in removals
        ):
            root.removeChild(element)


def _ensure_content_type_override(
    document: Document,
    root: Element,
    member: str,
    content_type: str,
) -> None:
    part_name = f"/{member}"
    for element in _direct_elements(root):
        if (
            element.namespaceURI == _CONTENT_TYPES_NAMESPACE
            and element.localName == "Override"
            and element.getAttribute("PartName") == part_name
        ):
            return
    element = document.createElementNS(_CONTENT_TYPES_NAMESPACE, "Override")
    element.setAttribute("PartName", part_name)
    element.setAttribute("ContentType", content_type)
    root.appendChild(element)


def _ensure_content_type_default(
    document: Document,
    root: Element,
    extension: str,
    content_type: str,
) -> None:
    for element in _direct_elements(root):
        if (
            element.namespaceURI == _CONTENT_TYPES_NAMESPACE
            and element.localName == "Default"
            and element.getAttribute("Extension").casefold() == extension.casefold()
        ):
            if element.getAttribute("ContentType") != content_type:
                msg = "Workbook image extension has a conflicting content type"
                raise ExcelModificationError(msg)
            return
    element = document.createElementNS(_CONTENT_TYPES_NAMESPACE, "Default")
    element.setAttribute("Extension", extension)
    element.setAttribute("ContentType", content_type)
    root.appendChild(element)


def _remove_drawings(
    package: _SafePackage,
    replacements: dict[str, bytes],
    removal_roots: set[str],
    *,
    worksheet_member: str,
) -> int:
    worksheet_document, worksheet_root = _document(
        replacements.get(worksheet_member, _read_payload(package, worksheet_member))
    )
    rels_member = _rels_member(worksheet_member)
    rels_document, rels_root, rels_payload = _load_relationship_document(
        package,
        rels_member,
    )
    drawing_relationships = [
        relationship
        for relationship in _relationship_elements(rels_root)
        if relationship.getAttribute("Type").rsplit("/", 1)[-1] == "drawing"
    ]
    if not drawing_relationships:
        return 0
    identifiers = {
        relationship.getAttribute("Id") for relationship in drawing_relationships
    }
    roots = {
        _resolve_target(worksheet_member, relationship.getAttribute("Target"))
        for relationship in drawing_relationships
    }
    for element in tuple(_direct_elements(worksheet_root)):
        if (
            element.namespaceURI in _SPREADSHEETML_WORKSHEET_NAMESPACES
            and element.localName == "drawing"
            and _relationship_id(element) in identifiers
        ):
            worksheet_root.removeChild(element)
    for relationship in drawing_relationships:
        rels_root.removeChild(relationship)
    replacements[worksheet_member] = _serialize_xml(worksheet_document)
    if rels_payload is not None:
        replacements[rels_member] = _serialize_xml(rels_document)
    removal_roots.update(roots)
    return len(drawing_relationships)


def _marker(
    document: Document,
    name: str,
    marker: DrawingMarkerPatch,
    *,
    drawing_prefix: str,
    drawing_namespace: str,
) -> Element:
    element = document.createElementNS(
        drawing_namespace,
        f"{drawing_prefix}:{name}",
    )
    for child_name, value in (
        ("col", marker.column),
        ("colOff", marker.column_offset),
        ("row", marker.row),
        ("rowOff", marker.row_offset),
    ):
        child = document.createElementNS(
            drawing_namespace,
            f"{drawing_prefix}:{child_name}",
        )
        child.appendChild(document.createTextNode(str(value)))
        element.appendChild(child)
    return element


def _picture_anchor(  # noqa: PLR0913
    document: Document,
    patch: WorksheetImagePatch,
    *,
    relationship_id: str,
    object_id: int,
    drawing_prefix: str,
    main_prefix: str,
    relationship_prefix: str,
    drawing_namespace: str,
    main_namespace: str,
    relationship_namespace: str,
) -> Element:
    anchor = document.createElementNS(
        drawing_namespace,
        f"{drawing_prefix}:twoCellAnchor",
    )
    anchor.appendChild(
        _marker(
            document,
            "from",
            patch.from_marker,
            drawing_prefix=drawing_prefix,
            drawing_namespace=drawing_namespace,
        )
    )
    anchor.appendChild(
        _marker(
            document,
            "to",
            patch.to_marker,
            drawing_prefix=drawing_prefix,
            drawing_namespace=drawing_namespace,
        )
    )
    picture = document.createElementNS(drawing_namespace, f"{drawing_prefix}:pic")
    non_visual = document.createElementNS(
        drawing_namespace,
        f"{drawing_prefix}:nvPicPr",
    )
    properties = document.createElementNS(
        drawing_namespace,
        f"{drawing_prefix}:cNvPr",
    )
    properties.setAttribute("id", str(object_id))
    properties.setAttribute("name", patch.name)
    non_visual.appendChild(properties)
    non_visual.appendChild(
        document.createElementNS(
            drawing_namespace,
            f"{drawing_prefix}:cNvPicPr",
        )
    )
    picture.appendChild(non_visual)
    fill = document.createElementNS(
        drawing_namespace,
        f"{drawing_prefix}:blipFill",
    )
    blip = document.createElementNS(
        main_namespace,
        f"{main_prefix}:blip",
    )
    blip.setAttributeNS(
        relationship_namespace,
        f"{relationship_prefix}:embed",
        relationship_id,
    )
    fill.appendChild(blip)
    stretch = document.createElementNS(
        main_namespace,
        f"{main_prefix}:stretch",
    )
    stretch.appendChild(
        document.createElementNS(
            main_namespace,
            f"{main_prefix}:fillRect",
        )
    )
    fill.appendChild(stretch)
    picture.appendChild(fill)
    shape = document.createElementNS(
        drawing_namespace,
        f"{drawing_prefix}:spPr",
    )
    geometry = document.createElementNS(
        main_namespace,
        f"{main_prefix}:prstGeom",
    )
    geometry.setAttribute("prst", "rect")
    geometry.appendChild(
        document.createElementNS(
            main_namespace,
            f"{main_prefix}:avLst",
        )
    )
    shape.appendChild(geometry)
    picture.appendChild(shape)
    anchor.appendChild(picture)
    anchor.appendChild(
        document.createElementNS(
            drawing_namespace,
            f"{drawing_prefix}:clientData",
        )
    )
    return anchor


def _add_image(  # noqa: PLR0913, PLR0915
    package: _SafePackage,
    replacements: dict[str, bytes],
    additions: dict[str, bytes],
    content_types_document: Document,
    content_types_root: Element,
    *,
    worksheet_member: str,
    patch: WorksheetImagePatch,
) -> None:
    worksheet_document, worksheet_root = _document(
        replacements.get(worksheet_member, _read_payload(package, worksheet_member))
    )
    strict = worksheet_root.namespaceURI == _STRICT_SPREADSHEET_NAMESPACE
    drawing_namespace = _STRICT_DRAWING_NAMESPACE if strict else _DRAWING_NAMESPACE
    main_namespace = (
        _STRICT_DRAWING_MAIN_NAMESPACE if strict else _DRAWING_MAIN_NAMESPACE
    )
    office_relationship_namespace = (
        _STRICT_RELATIONSHIPS_DOCUMENT_NAMESPACE
        if strict
        else _RELATIONSHIPS_DOCUMENT_NAMESPACE
    )
    worksheet_rels_member = _rels_member(worksheet_member)
    worksheet_rels_document, worksheet_rels_root, _worksheet_rels_payload = (
        _load_relationship_document(
            package,
            worksheet_rels_member,
            replacements,
            additions,
        )
    )
    drawing_relationships = [
        relationship
        for relationship in _relationship_elements(worksheet_rels_root)
        if relationship.getAttribute("Type").rsplit("/", 1)[-1] == "drawing"
    ]
    if len(drawing_relationships) > 1:
        msg = "Workbook worksheet has duplicate drawing relationships"
        raise ExcelModificationError(msg)
    if drawing_relationships:
        drawing_member = _resolve_target(
            worksheet_member,
            drawing_relationships[0].getAttribute("Target"),
        )
        drawing_document, drawing_root = _document(
            _state_payload(package, drawing_member, replacements, additions)
        )
        if drawing_root.namespaceURI not in {
            _DRAWING_NAMESPACE,
            _STRICT_DRAWING_NAMESPACE,
        }:
            msg = "Workbook drawing namespace is unsupported"
            raise ValueError(msg)
        drawing_namespace = drawing_root.namespaceURI
        strict_drawing = drawing_namespace == _STRICT_DRAWING_NAMESPACE
        main_namespace = (
            _STRICT_DRAWING_MAIN_NAMESPACE
            if strict_drawing
            else _DRAWING_MAIN_NAMESPACE
        )
        office_relationship_namespace = (
            _STRICT_RELATIONSHIPS_DOCUMENT_NAMESPACE
            if strict_drawing
            else _RELATIONSHIPS_DOCUMENT_NAMESPACE
        )
    else:
        drawing_member = _next_member(
            frozenset((*package.names, *additions)),
            "xl/drawings",
            "drawing",
            ".xml",
        )
        drawing_document = minidom.Document()
        drawing_root = drawing_document.createElementNS(
            drawing_namespace,
            "xdr:wsDr",
        )
        drawing_root.setAttribute("xmlns:xdr", drawing_namespace)
        drawing_root.setAttribute("xmlns:a", main_namespace)
        drawing_root.setAttribute("xmlns:r", office_relationship_namespace)
        drawing_document.appendChild(drawing_root)
        relationship = worksheet_rels_document.createElementNS(
            _RELATIONSHIPS_NAMESPACE,
            "Relationship",
        )
        relationship.setAttribute(
            "Id",
            _next_identifier(_relationship_elements(worksheet_rels_root)),
        )
        relationship.setAttribute(
            "Type",
            f"{office_relationship_namespace}/drawing",
        )
        relationship.setAttribute(
            "Target",
            f"../drawings/{PurePosixPath(drawing_member).name}",
        )
        worksheet_rels_root.appendChild(relationship)
        drawing_element = worksheet_document.createElementNS(
            worksheet_root.namespaceURI,
            "drawing",
        )
        relationship_prefix = namespace_prefix(
            worksheet_root,
            office_relationship_namespace,
            "r",
        )
        drawing_element.setAttributeNS(
            office_relationship_namespace,
            f"{relationship_prefix}:id",
            relationship.getAttribute("Id"),
        )
        successor = next(
            (
                element
                for element in _direct_elements(worksheet_root)
                if element.namespaceURI in _SPREADSHEETML_WORKSHEET_NAMESPACES
                and element.localName == "extLst"
            ),
            None,
        )
        worksheet_root.insertBefore(drawing_element, successor)
        additions[drawing_member] = b""
        _ensure_content_type_override(
            content_types_document,
            content_types_root,
            drawing_member,
            _DRAWING_CONTENT_TYPE,
        )
    drawing_rels_member = _rels_member(drawing_member)
    drawing_rels_document, drawing_rels_root, _drawing_rels_payload = (
        _load_relationship_document(
            package,
            drawing_rels_member,
            replacements,
            additions,
        )
        if package.has(drawing_rels_member) or drawing_rels_member in additions
        else _load_relationship_document_from_additions()
    )
    extension = {
        "image/png": ".png",
        "image/jpeg": ".jpeg",
        "image/gif": ".gif",
    }[patch.content_type]
    media_member = _next_member(
        frozenset((*package.names, *additions)),
        "xl/media",
        "image",
        extension,
    )
    image_relationship = drawing_rels_document.createElementNS(
        _RELATIONSHIPS_NAMESPACE,
        "Relationship",
    )
    image_relationship.setAttribute(
        "Id",
        _next_identifier(_relationship_elements(drawing_rels_root)),
    )
    image_relationship.setAttribute(
        "Type",
        f"{office_relationship_namespace}/image",
    )
    image_relationship.setAttribute(
        "Target",
        f"../media/{PurePosixPath(media_member).name}",
    )
    drawing_rels_root.appendChild(image_relationship)
    object_ids = [
        int(element.getAttribute("id"))
        for element in drawing_document.getElementsByTagNameNS(
            drawing_namespace,
            "cNvPr",
        )
        if element.getAttribute("id").isdigit()
    ]
    drawing_prefix = namespace_prefix(drawing_root, drawing_namespace, "xdr")
    main_prefix = namespace_prefix(drawing_root, main_namespace, "a")
    relationship_prefix = namespace_prefix(
        drawing_root,
        office_relationship_namespace,
        "r",
    )
    drawing_root.appendChild(
        _picture_anchor(
            drawing_document,
            patch,
            relationship_id=image_relationship.getAttribute("Id"),
            object_id=max(object_ids, default=0) + 1,
            drawing_prefix=drawing_prefix,
            main_prefix=main_prefix,
            relationship_prefix=relationship_prefix,
            drawing_namespace=drawing_namespace,
            main_namespace=main_namespace,
            relationship_namespace=office_relationship_namespace,
        )
    )
    payload = b64decode(patch.data_base64, validate=True)
    additions[media_member] = payload
    _ensure_content_type_default(
        content_types_document,
        content_types_root,
        extension.lstrip("."),
        patch.content_type,
    )
    replacements[worksheet_member] = _serialize_xml(worksheet_document)
    serialized_worksheet_rels = _serialize_xml(worksheet_rels_document)
    if package.has(worksheet_rels_member):
        replacements[worksheet_rels_member] = serialized_worksheet_rels
    else:
        additions[worksheet_rels_member] = serialized_worksheet_rels
    serialized_drawing = _serialize_xml(drawing_document)
    if package.has(drawing_member):
        replacements[drawing_member] = serialized_drawing
    else:
        additions[drawing_member] = serialized_drawing
    serialized_drawing_rels = _serialize_xml(drawing_rels_document)
    if package.has(drawing_rels_member):
        replacements[drawing_rels_member] = serialized_drawing_rels
    else:
        additions[drawing_rels_member] = serialized_drawing_rels


def _load_relationship_document_from_additions() -> tuple[Document, Element, None]:
    document = minidom.Document()
    root = document.createElementNS(_RELATIONSHIPS_NAMESPACE, "Relationships")
    root.setAttribute("xmlns", _RELATIONSHIPS_NAMESPACE)
    document.appendChild(root)
    return document, root, None


def _delete_worksheets(  # noqa: C901, PLR0912, PLR0915
    package: _SafePackage,
    replacements: dict[str, bytes],
    removal_roots: set[str],
    patches: Sequence[WorksheetDeletePatch],
    request: WorkbookPatchRequest,
) -> tuple[_PendingGraphChange, ...]:
    if not patches:
        return ()
    workbook_document, workbook_root = _document(
        _read_payload(package, _WORKBOOK_MEMBER)
    )
    relationships_document, relationships_root = _document(
        _read_payload(package, _WORKBOOK_RELS_MEMBER)
    )
    _workbook, records = _workbook_records(package)
    by_name = {record.name.casefold(): record for record in records}
    requested = {patch.name.casefold(): patch.name for patch in patches}
    if (
        not set(requested) <= set(by_name)
        or any(by_name[name].sheet_type != "worksheet" for name in requested)
        or len(records) - len(requested) < 1
    ):
        msg = "Workbook worksheet deletion target is invalid"
        raise ExcelModificationError(msg)
    _preflight_worksheet_deletions(package, records, set(requested), request)
    relationships = {
        element.getAttribute("Id"): element
        for element in _relationship_elements(relationships_root)
    }
    sheets = next(
        (
            element
            for element in _direct_elements(workbook_root)
            if element.namespaceURI in _SPREADSHEETML_WORKSHEET_NAMESPACES
            and element.localName == "sheets"
        ),
        None,
    )
    if sheets is None:
        msg = "Workbook worksheet collection is missing"
        raise ValueError(msg)
    removed_indexes = {
        index
        for index, record in enumerate(records)
        if record.name.casefold() in requested
    }
    for sheet in tuple(_direct_elements(sheets)):
        if sheet.getAttribute("name").casefold() not in requested:
            continue
        identifier = _relationship_id(sheet)
        relationship = relationships.get(identifier or "")
        record = by_name[sheet.getAttribute("name").casefold()]
        if relationship is None or record.part_name is None:
            msg = "Workbook worksheet deletion graph is invalid"
            raise ExcelModificationError(msg)
        sheets.removeChild(sheet)
        relationships_root.removeChild(relationship)
        removal_roots.add(record.part_name)
    containers = [
        element
        for element in _direct_elements(workbook_root)
        if element.namespaceURI in _SPREADSHEETML_WORKSHEET_NAMESPACES
        and element.localName == "definedNames"
    ]
    if len(containers) > 1:
        msg = "Workbook contains duplicate defined-name containers"
        raise ValueError(msg)
    if containers:
        container = containers[0]
        for definition in tuple(_direct_elements(container)):
            if not definition.hasAttribute("localSheetId"):
                continue
            try:
                old_index = int(definition.getAttribute("localSheetId"))
            except ValueError:
                msg = "Workbook defined name scope is invalid"
                raise ValueError(msg) from None
            if old_index in removed_indexes:
                container.removeChild(definition)
                continue
            shift = sum(index < old_index for index in removed_indexes)
            definition.setAttribute("localSheetId", str(old_index - shift))
        if not tuple(_direct_elements(container)):
            workbook_root.removeChild(container)
    remaining_count = len(records) - len(removed_indexes)
    for view in workbook_document.getElementsByTagNameNS("*", "workbookView"):
        raw = view.getAttribute("activeTab")
        if not raw.isdigit():
            continue
        active = int(raw)
        if active in removed_indexes:
            active = min(active, remaining_count - 1)
        else:
            active -= sum(index < active for index in removed_indexes)
        view.setAttribute("activeTab", str(max(active, 0)))
    replacements[_WORKBOOK_MEMBER] = _serialize_xml(workbook_document)
    replacements[_WORKBOOK_RELS_MEMBER] = _serialize_xml(relationships_document)
    return tuple(
        _PendingGraphChange("delete_worksheet", requested[name])
        for name in sorted(requested)
    )


def create_package_graph_patch_output(  # noqa: PLR0913
    source_path: Path,
    output_path: Path,
    *,
    delete_sheets: Sequence[WorksheetDeletePatch],
    drawing_removals: Sequence[WorksheetDrawingRemovalPatch],
    image_additions: Sequence[WorksheetImagePatch],
    request: WorkbookPatchRequest,
    source_fingerprint: str,
) -> tuple[_PendingGraphChange, ...]:
    """Apply bounded package graph changes in one deterministic transaction."""
    with _SafePackage(source_path) as package:
        package.verify_fingerprint(source_fingerprint)
        package.reject_forbidden_xml_declarations()
        content_types_document, content_types_root = _document(
            _read_payload(package, _CONTENT_TYPES_MEMBER)
        )
        if content_types_root.namespaceURI != _CONTENT_TYPES_NAMESPACE:
            msg = "Workbook content-type namespace is unsupported"
            raise ValueError(msg)
        replacements: dict[str, bytes] = {}
        additions: dict[str, bytes] = {}
        removal_roots: set[str] = set()
        pending = list(
            _delete_worksheets(
                package,
                replacements,
                removal_roots,
                delete_sheets,
                request,
            )
        )
        _workbook, records = _workbook_records(package)
        deleted = {patch.name.casefold() for patch in delete_sheets}
        by_name = {
            record.name.casefold(): record
            for record in records
            if record.name.casefold() not in deleted
        }
        for removal_patch in drawing_removals:
            record = by_name.get(removal_patch.sheet_name.casefold())
            if (
                record is None
                or record.part_name is None
                or record.sheet_type != "worksheet"
            ):
                msg = "Workbook drawing removal worksheet does not exist"
                raise ExcelModificationError(msg)
            count = _remove_drawings(
                package,
                replacements,
                removal_roots,
                worksheet_member=record.part_name,
            )
            if count:
                pending.append(
                    _PendingGraphChange("remove_drawings", record.name, count)
                )
        for image_patch in image_additions:
            record = by_name.get(image_patch.sheet_name.casefold())
            if (
                record is None
                or record.part_name is None
                or record.sheet_type != "worksheet"
            ):
                msg = "Workbook image target worksheet does not exist"
                raise ExcelModificationError(msg)
            _add_image(
                package,
                replacements,
                additions,
                content_types_document,
                content_types_root,
                worksheet_member=record.part_name,
                patch=image_patch,
            )
            pending.append(_PendingGraphChange("add_image", record.name))
        removals = _final_safe_removals(
            package,
            removal_roots,
            replacements,
            additions,
        )
        _remove_content_type_overrides(content_types_root, removals)
        replacements[_CONTENT_TYPES_MEMBER] = _serialize_xml(content_types_document)
    _copy_package(
        source_path,
        output_path,
        replacements,
        additions=additions,
        removals=frozenset(removals),
        source_fingerprint=source_fingerprint,
    )
    with _SafePackage(output_path) as output_package:
        output_package.reject_forbidden_xml_declarations()
        _workbook_records(output_package)
        _verify_relationship_targets(
            output_package,
            required_reachable=frozenset(additions),
        )
    return tuple(pending)

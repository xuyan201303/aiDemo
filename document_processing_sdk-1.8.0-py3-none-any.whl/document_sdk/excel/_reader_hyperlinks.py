"""Bounded hyperlink-value extraction for one selected worksheet."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from document_sdk.core._excel_coordinates import (
    ExcelRangeBounds,
    excel_column_letter,
    excel_range_bounds,
)
from document_sdk.excel._package import _SafePackage
from document_sdk.excel._package_security import (
    _attribute_by_local_name,
    _local_name,
    _relationship_part,
    _resolve_target,
)
from document_sdk.excel._package_workbook import _workbook_records
from document_sdk.excel._visible_text import _namespace

if TYPE_CHECKING:
    from pathlib import Path
    from xml.etree.ElementTree import Element


@dataclass(frozen=True, slots=True)
class _HyperlinkRelationship:
    """One validated worksheet relationship used by a hyperlink."""

    target: str
    relationship_type: str


def _selected_worksheet_part(package: _SafePackage, sheet_name: str) -> str:
    """Resolve one exact worksheet without reading other worksheet parts."""
    _workbook, sheets = _workbook_records(package)
    matches = tuple(sheet for sheet in sheets if sheet.name == sheet_name)
    if len(matches) != 1:
        msg = "Workbook must contain exactly one selected worksheet"
        raise ValueError(msg)
    selected = matches[0]
    if selected.sheet_type != "worksheet" or selected.part_name is None:
        msg = "Selected sheet is not a readable worksheet"
        raise ValueError(msg)
    return selected.part_name


def _hyperlink_relationships(
    package: _SafePackage,
    worksheet_part: str,
) -> dict[str, _HyperlinkRelationship]:
    """Read validated relationship targets for one selected worksheet."""
    relationship_part = _relationship_part(worksheet_part)
    if not package.has(relationship_part):
        return {}

    root = package.read_xml(relationship_part)
    relationships: dict[str, _HyperlinkRelationship] = {}
    for element in root.iter():
        if _local_name(element.tag) != "Relationship":
            continue
        relationship_id = element.attrib.get("Id")
        target = element.attrib.get("Target")
        relationship_type = element.attrib.get("Type")
        target_mode = element.attrib.get("TargetMode")
        if not relationship_id or not target or not relationship_type:
            msg = "Worksheet contains an invalid relationship"
            raise ValueError(msg)
        if relationship_id in relationships:
            msg = "Worksheet contains duplicate relationship identifiers"
            raise ValueError(msg)
        if target_mode not in {None, "Internal", "External"}:
            msg = "Worksheet relationship has an invalid target mode"
            raise ValueError(msg)
        normalized_target = (
            target
            if target_mode == "External"
            else _resolve_target(worksheet_part, target)
        )
        relationships[relationship_id] = _HyperlinkRelationship(
            target=normalized_target,
            relationship_type=relationship_type,
        )
    return relationships


def _intersection(
    left: ExcelRangeBounds,
    right: ExcelRangeBounds,
) -> tuple[int, int, int, int] | None:
    """Return inclusive bounds shared by two ranges."""
    min_column = max(left.min_column, right.min_column)
    min_row = max(left.min_row, right.min_row)
    max_column = min(left.max_column, right.max_column)
    max_row = min(left.max_row, right.max_row)
    if min_column > max_column or min_row > max_row:
        return None
    return min_column, min_row, max_column, max_row


def _merged_anchor(
    column: int,
    row: int,
    merged_ranges: tuple[ExcelRangeBounds, ...],
) -> tuple[int, int] | None:
    """Return the anchor of a merged cell, if the coordinate is merged."""
    return next(
        (
            (merged.min_column, merged.min_row)
            for merged in merged_ranges
            if merged.min_column <= column <= merged.max_column
            and merged.min_row <= row <= merged.max_row
        ),
        None,
    )


def _coordinate_in_bounds(
    column: int,
    row: int,
    bounds: ExcelRangeBounds,
) -> bool:
    """Return whether a coordinate is inside inclusive requested bounds."""
    return (
        bounds.min_column <= column <= bounds.max_column
        and bounds.min_row <= row <= bounds.max_row
    )


def _hyperlink_value(
    element: Element,
    relationships: dict[str, _HyperlinkRelationship],
) -> str | None:
    """Resolve one hyperlink target without exposing it in errors."""
    relationship_id = _attribute_by_local_name(element, "id")
    target: str | None = None
    if relationship_id is not None:
        relationship = relationships.get(relationship_id)
        if relationship is None or not relationship.relationship_type.endswith(
            "/hyperlink"
        ):
            msg = "Worksheet hyperlink relationship is invalid"
            raise ValueError(msg)
        target = relationship.target
    return target or element.attrib.get("location")


def _add_hyperlink_values(
    values: dict[str, str],
    *,
    hyperlink_bounds: ExcelRangeBounds,
    requested_bounds: ExcelRangeBounds,
    merged_ranges: tuple[ExcelRangeBounds, ...],
    value: str,
) -> None:
    """Add target-backed coordinates limited to approved bounds."""
    if ":" not in hyperlink_bounds.normalized:
        column = hyperlink_bounds.min_column
        row = hyperlink_bounds.min_row
        anchor = _merged_anchor(column, row, merged_ranges)
        if anchor is not None:
            column, row = anchor
        if _coordinate_in_bounds(column, row, requested_bounds):
            coordinate = f"{excel_column_letter(column)}{row}"
            values.setdefault(coordinate, value)
        return

    intersection = _intersection(hyperlink_bounds, requested_bounds)
    if intersection is None:
        return
    min_column, min_row, max_column, max_row = intersection
    for row in range(min_row, max_row + 1):
        for column in range(min_column, max_column + 1):
            anchor = _merged_anchor(column, row, merged_ranges)
            if anchor is not None and anchor != (column, row):
                continue
            coordinate = f"{excel_column_letter(column)}{row}"
            values.setdefault(coordinate, value)


def hyperlink_values(
    path: Path,
    *,
    sheet_name: str,
    bounds: ExcelRangeBounds,
    merged_ranges: tuple[str, ...],
    expected_fingerprint: str,
) -> dict[str, str]:
    """Return target-backed blank-cell values inside already-approved bounds."""
    with _SafePackage(path) as package:
        package.verify_fingerprint(expected_fingerprint)
        worksheet_part = _selected_worksheet_part(package, sheet_name)
        relationships = _hyperlink_relationships(package, worksheet_part)
        root = package.read_xml(worksheet_part)

    merged_bounds = tuple(excel_range_bounds(item) for item in merged_ranges)
    values: dict[str, str] = {}
    namespace = _namespace(root.tag)
    for element in root.iterfind(f"{{{namespace}}}hyperlinks/{{{namespace}}}hyperlink"):
        reference = element.attrib.get("ref")
        if reference is None:
            msg = "Worksheet hyperlink is missing its reference"
            raise ValueError(msg)
        hyperlink_bounds = excel_range_bounds(reference)
        value = _hyperlink_value(element, relationships)
        if value is None:
            continue
        _add_hyperlink_values(
            values,
            hyperlink_bounds=hyperlink_bounds,
            requested_bounds=bounds,
            merged_ranges=merged_bounds,
            value=value,
        )
    return values

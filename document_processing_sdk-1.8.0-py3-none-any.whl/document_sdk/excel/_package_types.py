"""Shared private state for bounded OOXML package inspection."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

from document_sdk.excel.models import (
    ColumnWidthFeature,
    ExcelTableFeature,
    LocatedWorkbookFeature,
    RowHeightFeature,
    WorksheetFeatureInventory,
)

type SheetVisibility = Literal["visible", "hidden", "veryHidden"]
type UnsupportedSheetType = Literal[
    "chartsheet", "dialog_sheet", "macro_sheet", "unknown"
]


@dataclass(frozen=True, slots=True)
class _Relationship:
    target: str | None
    relationship_type: str
    external: bool


@dataclass(frozen=True, slots=True)
class _SheetRecord:
    name: str
    visibility: SheetVisibility
    relationship_id: str | None
    part_name: str | None
    sheet_type: Literal[
        "worksheet", "chartsheet", "dialog_sheet", "macro_sheet", "unknown"
    ]


@dataclass(slots=True)
class _WorksheetFacts:
    """Mutable facts assembled from one worksheet and its related parts."""

    name: str
    visibility: SheetVisibility
    feature_record_limit: int | None = field(default=None, repr=False)
    freeze_panes: str | None = None
    merged_ranges: list[str] = field(default_factory=list)
    row_heights: list[RowHeightFeature] = field(default_factory=list)
    column_widths: list[ColumnWidthFeature] = field(default_factory=list)
    print_area: list[str] = field(default_factory=list)
    print_title_rows: str | None = None
    print_title_columns: str | None = None
    page_orientation: Literal["portrait", "landscape"] | None = None
    hyperlinks: list[LocatedWorkbookFeature] = field(default_factory=list)
    comments: list[LocatedWorkbookFeature] = field(default_factory=list)
    data_validations: list[LocatedWorkbookFeature] = field(default_factory=list)
    conditional_formats: list[LocatedWorkbookFeature] = field(default_factory=list)
    tables: list[ExcelTableFeature] = field(default_factory=list)
    formulas: list[LocatedWorkbookFeature] = field(default_factory=list)
    hidden_rows: list[int] = field(default_factory=list)
    hidden_columns: list[str] = field(default_factory=list)
    drawing_count: int = 0
    image_count: int = 0
    chart_count: int = 0
    styled_cell_count: int = 0
    cell_values_present: bool = False
    formula_cache_present: bool = False
    shape_or_unknown_drawing_present: bool = False
    worksheet_extension_present: bool = False

    def to_inventory(self) -> WorksheetFeatureInventory:
        """Freeze collected worksheet facts into the public model."""
        return WorksheetFeatureInventory(
            name=self.name,
            visibility=self.visibility,
            freeze_panes=self.freeze_panes,
            merged_ranges=tuple(self.merged_ranges),
            row_heights=tuple(self.row_heights),
            column_widths=tuple(self.column_widths),
            print_area=tuple(self.print_area),
            print_title_rows=self.print_title_rows,
            print_title_columns=self.print_title_columns,
            page_orientation=self.page_orientation,
            hyperlinks=tuple(self.hyperlinks),
            comments=tuple(self.comments),
            data_validations=tuple(self.data_validations),
            conditional_formats=tuple(self.conditional_formats),
            tables=tuple(self.tables),
            formulas=tuple(self.formulas),
            hidden_rows=tuple(self.hidden_rows),
            hidden_columns=tuple(self.hidden_columns),
            drawing_count=self.drawing_count,
            image_count=self.image_count,
            chart_count=self.chart_count,
            styled_cell_count=self.styled_cell_count,
            hyperlink_count=len(self.hyperlinks),
            comment_count=len(self.comments),
            data_validation_count=len(self.data_validations),
            conditional_formatting_count=len(self.conditional_formats),
            table_count=len(self.tables),
            formula_count=len(self.formulas),
        )

"""Worksheet-level OOXML feature collection."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from document_sdk.core._excel_coordinates import (
    MAX_EXCEL_COLUMN,
    MAX_EXCEL_ROW,
    excel_column_letter,
    excel_range_bounds,
    normalize_excel_coordinate,
    normalize_excel_range,
)
from document_sdk.excel._package_security import (
    _attribute_by_local_name,
    _local_name,
    _relationships,
    _SafePackage,
)
from document_sdk.excel._package_types import (
    _Relationship,
    _SheetRecord,
    _WorksheetFacts,
)
from document_sdk.excel._package_workbook import _RELATIONSHIP_ID, _source
from document_sdk.excel._worksheet_xml import _worksheet_child, _worksheet_events
from document_sdk.excel.errors import ExcelPackageLimitError
from document_sdk.excel.models import (
    ColumnWidthFeature,
    ExcelTableFeature,
    LocatedWorkbookFeature,
    RowHeightFeature,
)

if TYPE_CHECKING:
    from xml.etree.ElementTree import Element


_WHOLE_COLUMNS = re.compile(r"^\$?(?P<start>[A-Za-z]{1,3}):\$?(?P<end>[A-Za-z]{1,3})$")
_WHOLE_ROWS = re.compile(r"^\$?(?P<start>\d+):\$?(?P<end>\d+)$")
_SQREF_TOKEN = re.compile(r"\S+")
_MAX_WORKSHEET_FEATURE_RECORDS = 100_000
_SPREADSHEETML_WORKSHEET_NAMESPACES = frozenset(
    {
        "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
        "http://purl.oclc.org/ooxml/spreadsheetml/main",
    }
)
_STANDARD_VIEW_PANE_PATH = ("worksheet", "sheetViews", "sheetView", "pane")


@dataclass(slots=True)
class _WorksheetStreamState:
    previous_row: int = 0
    previous_column: int = 0
    current_row: int | None = None
    element_names: list[str] = field(default_factory=list)
    element_tags: list[str] = field(default_factory=list)
    deferred_depth: int = 0


def _feature_record_count(facts: _WorksheetFacts) -> int:
    """Return the materialized worksheet feature-record count."""
    return sum(
        len(records)
        for records in (
            facts.merged_ranges,
            facts.row_heights,
            facts.column_widths,
            facts.hyperlinks,
            facts.comments,
            facts.data_validations,
            facts.conditional_formats,
            facts.tables,
            facts.formulas,
            facts.hidden_rows,
            facts.hidden_columns,
        )
    )


def _reserve_feature_records(
    facts: _WorksheetFacts,
    additional: int,
) -> None:
    """Reject record expansion before allocating public feature objects."""
    maximum = (
        _MAX_WORKSHEET_FEATURE_RECORDS
        if facts.feature_record_limit is None
        else facts.feature_record_limit
    )
    observed = _feature_record_count(facts) + additional
    if observed > maximum:
        raise ExcelPackageLimitError(
            limit_name="worksheet_feature_records",
            observed=observed,
            maximum=maximum,
        )


def _sqref_reference_count(value: str | None) -> int:
    """Count range references without first materializing split strings."""
    if not value:
        return 0
    return sum(1 for _match in _SQREF_TOKEN.finditer(value))


def _normalized_sqref(value: str | None) -> tuple[str, ...]:
    """Normalize a pre-budgeted sqref value without an unbounded split list."""
    if not value:
        return ()
    return tuple(
        _normalize_feature_range(match.group())
        for match in _SQREF_TOKEN.finditer(value)
    )


def _normalize_feature_range(value: str) -> str:
    cleaned = value.replace("$", "")
    column_match = _WHOLE_COLUMNS.fullmatch(cleaned)
    if column_match is not None:
        start = normalize_excel_coordinate(f"{column_match.group('start')}1")
        end = normalize_excel_coordinate(f"{column_match.group('end')}{MAX_EXCEL_ROW}")
        return normalize_excel_range(f"{start}:{end}")
    row_match = _WHOLE_ROWS.fullmatch(cleaned)
    if row_match is not None:
        return normalize_excel_range(
            f"A{row_match.group('start')}:"
            f"{excel_column_letter(MAX_EXCEL_COLUMN)}{row_match.group('end')}"
        )
    return normalize_excel_range(cleaned)


def _formula_kind(formula: Element) -> str:
    formula_type = formula.attrib.get("t", "")
    if formula_type == "shared":
        return "shared"
    if formula_type == "array":
        return "array"
    if formula_type in {"dataTable", "dynamicArray"}:
        return "dynamic_array"
    return "ordinary"


def _apply_layout_element(element: Element, facts: _WorksheetFacts) -> None:
    if not any(
        element.tag.startswith(f"{{{namespace}}}")
        for namespace in _SPREADSHEETML_WORKSHEET_NAMESPACES
    ):
        return
    local_name = _local_name(element.tag)
    if local_name == "pane":
        top_left = element.attrib.get("topLeftCell")
        if (
            element.attrib.get("state") in {"frozen", "frozenSplit"}
            and top_left is not None
        ):
            facts.freeze_panes = normalize_excel_coordinate(top_left)
    elif local_name == "mergeCell":
        reference = element.attrib.get("ref")
        if reference:
            _reserve_feature_records(facts, 1)
            facts.merged_ranges.append(_normalize_feature_range(reference))
    elif local_name == "col":
        _apply_column_element(element, facts)
    elif local_name == "pageSetup":
        orientation = element.attrib.get("orientation")
        if orientation == "portrait":
            facts.page_orientation = "portrait"
        elif orientation == "landscape":
            facts.page_orientation = "landscape"


def _is_standard_view_pane(state: _WorksheetStreamState) -> bool:
    """Return whether the active stream path is the current worksheet pane."""
    if (
        len(state.element_names) != len(_STANDARD_VIEW_PANE_PATH)
        or tuple(state.element_names) != _STANDARD_VIEW_PANE_PATH
    ):
        return False
    return all(
        any(
            tag.startswith(f"{{{namespace}}}")
            for namespace in _SPREADSHEETML_WORKSHEET_NAMESPACES
        )
        for tag in state.element_tags[-4:]
    )


def _row_index(element: Element, previous_row: int) -> int:
    """Return an explicit or positionally inferred worksheet row."""
    row_text = element.attrib.get("r")
    row = previous_row + 1 if row_text is None else int(row_text)
    if row < 1 or row > MAX_EXCEL_ROW:
        msg = "Worksheet row is outside Excel bounds"
        raise ValueError(msg)
    if row <= previous_row:
        msg = "Worksheet rows are not in deterministic order"
        raise ValueError(msg)
    return row


def _apply_row_element(
    element: Element,
    facts: _WorksheetFacts,
    *,
    row: int,
) -> None:
    height_text = element.attrib.get("ht")
    if element.attrib.get("hidden") in {"1", "true"}:
        _reserve_feature_records(facts, 1)
        facts.hidden_rows.append(row)
    if height_text:
        height = float(height_text)
        if height > 0:
            _reserve_feature_records(facts, 1)
            facts.row_heights.append(RowHeightFeature(row=row, height=height))


def _cell_coordinate(
    element: Element,
    *,
    current_row: int,
    previous_column: int,
) -> tuple[str, int]:
    """Return an explicit or positionally inferred worksheet coordinate."""
    coordinate = element.attrib.get("r")
    if coordinate is None:
        column = previous_column + 1
        if column > MAX_EXCEL_COLUMN:
            msg = "Worksheet cell is outside Excel bounds"
            raise ValueError(msg)
        return f"{excel_column_letter(column)}{current_row}", column

    normalized = normalize_excel_coordinate(coordinate)
    bounds = excel_range_bounds(normalized)
    if bounds.min_row != current_row:
        msg = "Worksheet cell coordinate does not match its row"
        raise ValueError(msg)
    if bounds.min_column <= previous_column:
        msg = "Worksheet cells are not in deterministic row order"
        raise ValueError(msg)
    return normalized, bounds.min_column


def _apply_column_element(element: Element, facts: _WorksheetFacts) -> None:
    minimum = int(element.attrib.get("min", "0"))
    maximum = int(element.attrib.get("max", "0"))
    if minimum < 1 or maximum < minimum or maximum > MAX_EXCEL_COLUMN:
        msg = "Workbook column metadata is outside Excel bounds"
        raise ValueError(msg)
    width_text = element.attrib.get("width")
    column_count = maximum - minimum + 1
    records_per_column = int(element.attrib.get("hidden") in {"1", "true"}) + int(
        width_text is not None and float(width_text) > 0
    )
    _reserve_feature_records(facts, column_count * records_per_column)
    for column_number in range(minimum, maximum + 1):
        column = excel_column_letter(column_number)
        if element.attrib.get("hidden") in {"1", "true"}:
            facts.hidden_columns.append(column)
        if width_text:
            width = float(width_text)
            if width > 0:
                facts.column_widths.append(
                    ColumnWidthFeature(column=column, width=width)
                )


def _apply_hyperlink_element(
    element: Element,
    *,
    facts: _WorksheetFacts,
    file_id: str,
) -> None:
    reference = element.attrib.get("ref")
    if not reference:
        return
    relationship_id = element.attrib.get(_RELATIONSHIP_ID) or _attribute_by_local_name(
        element, "id"
    )
    _reserve_feature_records(facts, 1)
    facts.hyperlinks.append(
        LocatedWorkbookFeature(
            feature_type="hyperlink",
            source=_source(
                file_id,
                facts.name,
                _normalize_feature_range(reference),
            ),
            details="external" if relationship_id else "internal",
        )
    )


def _apply_multi_range_element(
    element: Element,
    *,
    facts: _WorksheetFacts,
    file_id: str,
) -> None:
    local_name = _local_name(element.tag)
    sqref = element.attrib.get("sqref")
    reference_count = _sqref_reference_count(sqref)
    if local_name == "dataValidation":
        _reserve_feature_records(facts, reference_count)
        references = _normalized_sqref(sqref)
        facts.data_validations.extend(
            LocatedWorkbookFeature(
                feature_type="data_validation",
                source=_source(file_id, facts.name, reference),
                details=element.attrib.get("type") or "custom",
            )
            for reference in references
        )
    else:
        if reference_count == 0:
            return
        rule_count = sum(1 for child in element if _local_name(child.tag) == "cfRule")
        effective_rule_count = rule_count or 1
        _reserve_feature_records(facts, reference_count * effective_rule_count)
        rule_types = tuple(
            child.attrib.get("type")
            for child in element
            if _local_name(child.tag) == "cfRule"
        ) or (None,)
        references = _normalized_sqref(sqref)
        for reference in references:
            facts.conditional_formats.extend(
                LocatedWorkbookFeature(
                    feature_type="conditional_formatting",
                    source=_source(file_id, facts.name, reference),
                    details=rule_type,
                )
                for rule_type in rule_types
            )


def _apply_cell_element(
    element: Element,
    *,
    coordinate: str,
    facts: _WorksheetFacts,
    file_id: str,
) -> None:
    if element.attrib.get("s") is not None:
        facts.styled_cell_count += 1
    formula = _worksheet_child(element, "f")
    value = _worksheet_child(element, "v")
    inline_string = _worksheet_child(element, "is")
    if formula is not None:
        _reserve_feature_records(facts, 1)
        facts.formulas.append(
            LocatedWorkbookFeature(
                feature_type="formula",
                source=_source(
                    file_id,
                    facts.name,
                    coordinate,
                ),
                details=_formula_kind(formula),
            )
        )
        facts.cell_values_present = True
        if value is not None and value.text is not None:
            facts.formula_cache_present = True
    elif value is not None or inline_string is not None:
        facts.cell_values_present = True


def _start_worksheet_element(
    element: Element,
    *,
    local_name: str,
    facts: _WorksheetFacts,
    state: _WorksheetStreamState,
) -> None:
    parent_name = state.element_names[-1] if state.element_names else None
    state.element_names.append(local_name)
    state.element_tags.append(element.tag)
    if local_name == "row" and parent_name == "sheetData":
        state.current_row = _row_index(element, state.previous_row)
        _apply_row_element(element, facts, row=state.current_row)
        state.previous_column = 0
    elif (
        local_name == "c" and parent_name == "row" and state.current_row is not None
    ) or local_name == "conditionalFormatting":
        state.deferred_depth += 1


def _end_worksheet_element(
    element: Element,
    *,
    local_name: str,
    facts: _WorksheetFacts,
    file_id: str,
    state: _WorksheetStreamState,
) -> None:
    parent_name = state.element_names[-2] if len(state.element_names) > 1 else None
    if local_name == "c" and parent_name == "row" and state.current_row is not None:
        coordinate, state.previous_column = _cell_coordinate(
            element,
            current_row=state.current_row,
            previous_column=state.previous_column,
        )
        _apply_cell_element(
            element,
            coordinate=coordinate,
            facts=facts,
            file_id=file_id,
        )
        state.deferred_depth -= 1
    elif (
        local_name == "row"
        and parent_name == "sheetData"
        and state.current_row is not None
    ):
        state.previous_row = state.current_row
        state.current_row = None
    elif local_name == "conditionalFormatting":
        _apply_multi_range_element(element, facts=facts, file_id=file_id)
        state.deferred_depth -= 1
    elif state.deferred_depth == 0:
        if local_name in {"mergeCell", "col", "pageSetup"} or (
            local_name == "pane" and _is_standard_view_pane(state)
        ):
            _apply_layout_element(element, facts)
        elif local_name == "extLst" and any(
            element.tag.startswith(f"{{{namespace}}}")
            for namespace in _SPREADSHEETML_WORKSHEET_NAMESPACES
        ):
            facts.worksheet_extension_present = (
                facts.worksheet_extension_present or len(element) > 0
            )
        elif local_name == "hyperlink":
            _apply_hyperlink_element(element, facts=facts, file_id=file_id)
        elif local_name == "dataValidation":
            _apply_multi_range_element(element, facts=facts, file_id=file_id)
    if state.deferred_depth == 0:
        element.clear()
    state.element_names.pop()
    state.element_tags.pop()


def _stream_worksheet_xml(
    package: _SafePackage,
    *,
    member_name: str,
    facts: _WorksheetFacts,
    file_id: str,
) -> None:
    """Collect worksheet facts while retaining only the active XML fragments."""
    state = _WorksheetStreamState()
    with package.open_xml_stream(member_name) as stream:
        for event, element, event_name in _worksheet_events(stream):
            # Extension-defined validation inventories remain supported. Core
            # cells and layout, unlike these explicit extension records, must
            # belong to the worksheet's own SpreadsheetML namespace.
            local_name = event_name
            if not event_name and _local_name(element.tag) in {
                "dataValidation",
                "conditionalFormatting",
            }:
                local_name = _local_name(element.tag)
            if event == "start":
                _start_worksheet_element(
                    element, local_name=local_name, facts=facts, state=state
                )
            else:
                _end_worksheet_element(
                    element,
                    local_name=local_name,
                    facts=facts,
                    file_id=file_id,
                    state=state,
                )


def _worksheet_xml_facts(
    package: _SafePackage,
    *,
    sheet: _SheetRecord,
    file_id: str,
    feature_record_limit: int | None = None,
) -> _WorksheetFacts:
    if sheet.part_name is None:
        msg = "Worksheet package part is missing"
        raise ValueError(msg)
    facts = _WorksheetFacts(
        name=sheet.name,
        visibility=sheet.visibility,
        feature_record_limit=feature_record_limit,
    )
    _stream_worksheet_xml(
        package,
        member_name=sheet.part_name,
        facts=facts,
        file_id=file_id,
    )

    worksheet_relationships = _relationships(package, sheet.part_name)
    _add_related_comments(
        package,
        relationships=worksheet_relationships,
        facts=facts,
        file_id=file_id,
    )
    _add_related_tables(
        package,
        relationships=worksheet_relationships,
        facts=facts,
        file_id=file_id,
    )
    _add_related_drawings(
        package,
        relationships=worksheet_relationships,
        facts=facts,
    )
    return facts


def _add_related_comments(
    package: _SafePackage,
    *,
    relationships: dict[str, _Relationship],
    facts: _WorksheetFacts,
    file_id: str,
) -> None:
    for relationship in relationships.values():
        if (
            relationship.target is None
            or relationship.relationship_type.rsplit("/", 1)[-1] != "comments"
        ):
            continue
        root = package.read_xml(relationship.target)
        for element in root.iter():
            if _local_name(element.tag) != "comment":
                continue
            reference = element.attrib.get("ref")
            if reference:
                _reserve_feature_records(facts, 1)
                facts.comments.append(
                    LocatedWorkbookFeature(
                        feature_type="comment",
                        source=_source(
                            file_id,
                            facts.name,
                            _normalize_feature_range(reference),
                        ),
                    )
                )


def _add_related_tables(
    package: _SafePackage,
    *,
    relationships: dict[str, _Relationship],
    facts: _WorksheetFacts,
    file_id: str,
) -> None:
    for relationship in relationships.values():
        if (
            relationship.target is None
            or relationship.relationship_type.rsplit("/", 1)[-1] != "table"
        ):
            continue
        root = package.read_xml(relationship.target)
        reference = root.attrib.get("ref")
        name = root.attrib.get("name")
        display_name = root.attrib.get("displayName")
        if not reference or not name or not display_name:
            continue
        normalized = _normalize_feature_range(reference)
        _reserve_feature_records(facts, 1)
        facts.tables.append(
            ExcelTableFeature(
                name=name,
                display_name=display_name,
                cell_range=normalized,
                source=_source(file_id, facts.name, normalized),
            )
        )


def _add_related_drawings(
    package: _SafePackage,
    *,
    relationships: dict[str, _Relationship],
    facts: _WorksheetFacts,
) -> None:
    for relationship in relationships.values():
        if (
            relationship.target is None
            or relationship.relationship_type.rsplit("/", 1)[-1] != "drawing"
        ):
            continue
        if not package.has(relationship.target):
            facts.shape_or_unknown_drawing_present = True
            continue
        facts.drawing_count += 1
        drawing = package.read_xml(relationship.target)
        drawing_relationships = _relationships(package, relationship.target)
        image_count = sum(
            item.relationship_type.rsplit("/", 1)[-1] == "image"
            for item in drawing_relationships.values()
        )
        chart_count = sum(
            item.relationship_type.rsplit("/", 1)[-1] == "chart"
            for item in drawing_relationships.values()
        )
        facts.image_count += image_count
        facts.chart_count += chart_count
        drawing_types = {
            _local_name(element.tag)
            for element in drawing.iter()
            if _local_name(element.tag)
            in {"sp", "cxnSp", "grpSp", "graphicFrame", "oleObj", "control"}
        }
        graphic_frame_count = sum(
            _local_name(element.tag) == "graphicFrame" for element in drawing.iter()
        )
        if drawing_types & {"sp", "cxnSp", "grpSp", "oleObj", "control"} or (
            graphic_frame_count > chart_count
        ):
            facts.shape_or_unknown_drawing_present = True

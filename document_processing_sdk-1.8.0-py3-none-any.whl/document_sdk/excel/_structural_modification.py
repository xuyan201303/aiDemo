"""Bounded row/column insertion with package-wide A1 reference rewriting."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal
from xml.dom import minidom

from document_sdk.core._excel_coordinates import (
    MAX_EXCEL_COLUMN,
    MAX_EXCEL_ROW,
    excel_column_letter,
    excel_range_bounds,
)
from document_sdk.excel._column_modification import _copy_package, _document_root
from document_sdk.excel._formula_references import is_external_workbook_range
from document_sdk.excel._package import _SafePackage
from document_sdk.excel._package_security import (
    _local_name,
    _relationships,
    _serialize_xml,
)
from document_sdk.excel._package_workbook import _workbook_records
from document_sdk.excel._package_worksheet import (
    _SPREADSHEETML_WORKSHEET_NAMESPACES,
)
from document_sdk.excel.errors import ExcelModificationError

if TYPE_CHECKING:
    from collections.abc import Sequence
    from pathlib import Path

    from document_sdk.excel.models import WorksheetStructuralInsertionPatch


_CELL_REFERENCE = re.compile(
    r"(?P<column_abs>\$?)(?P<column>[A-Za-z]{1,3})"
    r"(?P<row_abs>\$?)(?P<row>[1-9][0-9]*)"
)
_A1_REFERENCE = re.compile(
    r"^(?:(?P<sheet>'(?:[^']|'')+'|[^!]+)!)?"
    r"(?P<start>\$?[A-Za-z]{1,3}\$?[1-9][0-9]*)"
    r"(?::(?P<end>\$?[A-Za-z]{1,3}\$?[1-9][0-9]*))?$"
)
_WHOLE_COLUMN_REFERENCE = re.compile(
    r"^(?:(?P<sheet>'(?:[^']|'')+'|[^!]+)!)?"
    r"(?P<start_abs>\$?)(?P<start>[A-Za-z]{1,3}):"
    r"(?P<end_abs>\$?)(?P<end>[A-Za-z]{1,3})$"
)
_WHOLE_ROW_REFERENCE = re.compile(
    r"^(?:(?P<sheet>'(?:[^']|'')+'|[^!]+)!)?"
    r"(?P<start_abs>\$?)(?P<start>[1-9][0-9]*):"
    r"(?P<end_abs>\$?)(?P<end>[1-9][0-9]*)$"
)
_REFERENCE_ATTRIBUTES = frozenset(
    {
        "ref",
        "sqref",
        "activeCell",
        "topLeftCell",
    }
)
_FORMULA_ELEMENTS = frozenset(
    {
        "definedName",
        "f",
        "formula",
        "formula1",
        "formula2",
        "calculatedColumnFormula",
        "totalsRowFormula",
    }
)
_WORKBOOK_MEMBER = "xl/workbook.xml"
_DRAWING_NAMESPACES = frozenset(
    {
        "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing",
        "http://purl.oclc.org/ooxml/drawingml/spreadsheetDrawing",
    }
)
_CHART_NAMESPACES = frozenset(
    {
        "http://schemas.openxmlformats.org/drawingml/2006/chart",
        "http://purl.oclc.org/ooxml/drawingml/chart",
    }
)
_X14_NAMESPACE = "http://schemas.microsoft.com/office/spreadsheetml/2009/9/main"
_XM_NAMESPACE = "http://schemas.microsoft.com/office/excel/2006/main"
_VML_EXCEL_NAMESPACE = "urn:schemas-microsoft-com:office:excel"
_VML_ANCHOR_COMPONENT_COUNT = 8
_UNSUPPORTED_STRUCTURAL_RELATIONSHIPS = frozenset(
    {
        "ctrlProp",
        "pivotCacheDefinition",
        "pivotCacheRecords",
        "pivotTable",
        "slicer",
        "slicerCache",
        "threadedComment",
        "timeline",
        "timelineCache",
    }
)
_UNKNOWN_REFERENCE_NAMES = frozenset(
    {"f", "formula", "formula1", "formula2", "ref", "sqref"}
)
type _ReferenceAnalysis = Literal[
    "SUPPORTED_AFFECTED",
    "UNAFFECTED",
    "UNSUPPORTED_AFFECTED",
]


@dataclass(frozen=True, slots=True)
class _PendingStructuralInsertion:
    sheet_name: str
    axis: Literal["row", "column"]
    before: int
    count: int


@dataclass(frozen=True, slots=True)
class _PivotCacheWorksheetSource:
    """One retained workbook Pivot Cache with a direct worksheet source."""

    member: str
    sheet_name: str
    reference: str | None


def normalize_structural_insertions(
    patches: Sequence[WorksheetStructuralInsertionPatch],
) -> tuple[WorksheetStructuralInsertionPatch, ...]:
    """Normalize original-source coordinates into deterministic application order."""
    return tuple(
        sorted(
            patches,
            key=lambda patch: (
                patch.sheet_name.casefold(),
                0 if patch.axis == "column" else 1,
                -patch.before,
            ),
        )
    )


def _sheet_identity(value: str) -> str:
    if value.startswith("'") and value.endswith("'"):
        value = value[1:-1].replace("''", "'")
    return value.casefold()


def _shift_index(index: int, *, before: int, count: int) -> int:
    return index + count if index >= before else index


def _shift_bounds(
    start: int,
    end: int,
    *,
    before: int,
    count: int,
) -> tuple[int, int]:
    if before <= start:
        return start + count, end + count
    if before <= end:
        return start, end + count
    return start, end


def _check_shifted_bounds(
    start: int,
    end: int,
    *,
    maximum: int,
    label: str,
) -> None:
    if start < 1 or end < start or end > maximum:
        msg = f"worksheet {label} insertion exceeds Excel bounds"
        raise ExcelModificationError(msg)


def _reference_sheet_applies(
    sheet: str | None,
    *,
    target_sheet: str,
    context_sheet: str | None,
) -> bool:
    return (
        _sheet_identity(sheet) == target_sheet.casefold()
        if sheet is not None
        else context_sheet is not None
        and context_sheet.casefold() == target_sheet.casefold()
    )


def _reference_analysis(  # noqa: C901, PLR0911
    value: str,
    *,
    target_sheet: str,
    context_sheet: str | None,
    axis: Literal["row", "column"],
) -> _ReferenceAnalysis:
    if is_external_workbook_range(value):
        return "UNAFFECTED"
    explicit_sheet = value.rsplit("!", 1)[0] if "!" in value else None
    if explicit_sheet is not None and ":" in explicit_sheet:
        return "UNSUPPORTED_AFFECTED"
    for pattern in (_A1_REFERENCE, _WHOLE_COLUMN_REFERENCE, _WHOLE_ROW_REFERENCE):
        match = pattern.fullmatch(value)
        if match is None:
            continue
        if not _reference_sheet_applies(
            match.group("sheet"),
            target_sheet=target_sheet,
            context_sheet=context_sheet,
        ):
            return "UNAFFECTED"
        if pattern is _WHOLE_COLUMN_REFERENCE and axis != "column":
            return "UNAFFECTED"
        if pattern is _WHOLE_ROW_REFERENCE and axis != "row":
            return "UNAFFECTED"
        return "SUPPORTED_AFFECTED"
    if re.match(r"^'?\[[1-9][0-9]*\]", value):
        return "UNAFFECTED"
    applies = _reference_sheet_applies(
        explicit_sheet,
        target_sheet=target_sheet,
        context_sheet=context_sheet,
    )
    if "[" in value or "]" in value:
        return "UNSUPPORTED_AFFECTED" if applies else "UNAFFECTED"
    if applies and re.search(r"(?:\$?[A-Za-z]{1,3}|\$?[1-9][0-9]*):", value):
        return "UNSUPPORTED_AFFECTED"
    return "UNAFFECTED"


def _rewrite_cell(
    value: str,
    *,
    axis: Literal["row", "column"],
    before: int,
    count: int,
) -> str:
    match = _CELL_REFERENCE.fullmatch(value)
    if match is None:
        return value
    column = excel_range_bounds(f"{match.group('column')}1").min_column
    row = int(match.group("row"))
    if axis == "column":
        column = _shift_index(column, before=before, count=count)
        if column > MAX_EXCEL_COLUMN:
            msg = "worksheet column insertion exceeds Excel bounds"
            raise ExcelModificationError(msg)
    else:
        row = _shift_index(row, before=before, count=count)
        if row > MAX_EXCEL_ROW:
            msg = "worksheet row insertion exceeds Excel bounds"
            raise ExcelModificationError(msg)
    return (
        f"{match.group('column_abs')}{excel_column_letter(column)}"
        f"{match.group('row_abs')}{row}"
    )


def _cell_indexes(value: str) -> tuple[int, int, re.Match[str]]:
    match = _CELL_REFERENCE.fullmatch(value)
    if match is None:  # pragma: no cover - caller regex invariant.
        msg = "Workbook A1 reference is invalid"
        raise ExcelModificationError(msg)
    column = excel_range_bounds(f"{match.group('column')}1").min_column
    return column, int(match.group("row")), match


def rewrite_a1_reference(  # noqa: C901, PLR0911, PLR0913
    value: str,
    *,
    target_sheet: str,
    context_sheet: str | None,
    axis: Literal["row", "column"],
    before: int,
    count: int,
) -> str:
    """Rewrite one deterministic A1 reference for a structural insertion."""
    analysis = _reference_analysis(
        value,
        target_sheet=target_sheet,
        context_sheet=context_sheet,
        axis=axis,
    )
    if analysis == "UNSUPPORTED_AFFECTED":
        msg = "Workbook reference cannot be safely rewritten for insertion"
        raise ExcelModificationError(msg)
    if analysis == "UNAFFECTED":
        return value
    match = _A1_REFERENCE.fullmatch(value)
    if match is not None:
        sheet = match.group("sheet")
        applies = (
            _sheet_identity(sheet) == target_sheet.casefold()
            if sheet is not None
            else context_sheet is not None
            and context_sheet.casefold() == target_sheet.casefold()
        )
        if not applies:
            return value
        start = match.group("start")
        end = match.group("end")
        if end is None:
            rewritten = _rewrite_cell(
                start,
                axis=axis,
                before=before,
                count=count,
            )
        else:
            start_column, start_row, start_match = _cell_indexes(start)
            end_column, end_row, end_match = _cell_indexes(end)
            if axis == "column":
                start_column, end_column = _shift_bounds(
                    start_column,
                    end_column,
                    before=before,
                    count=count,
                )
            else:
                start_row, end_row = _shift_bounds(
                    start_row,
                    end_row,
                    before=before,
                    count=count,
                )
            _check_shifted_bounds(
                start_column,
                end_column,
                maximum=MAX_EXCEL_COLUMN,
                label="column",
            )
            _check_shifted_bounds(
                start_row,
                end_row,
                maximum=MAX_EXCEL_ROW,
                label="row",
            )
            rewritten = (
                f"{start_match.group('column_abs')}{excel_column_letter(start_column)}"
                f"{start_match.group('row_abs')}{start_row}:"
                f"{end_match.group('column_abs')}{excel_column_letter(end_column)}"
                f"{end_match.group('row_abs')}{end_row}"
            )
        return f"{sheet}!{rewritten}" if sheet is not None else rewritten
    column_match = _WHOLE_COLUMN_REFERENCE.fullmatch(value)
    if column_match is not None and axis == "column":
        sheet = column_match.group("sheet")
        applies = (
            _sheet_identity(sheet) == target_sheet.casefold()
            if sheet is not None
            else context_sheet is not None
            and context_sheet.casefold() == target_sheet.casefold()
        )
        if not applies:
            return value
        start = excel_range_bounds(f"{column_match.group('start')}1").min_column
        end = excel_range_bounds(f"{column_match.group('end')}1").min_column
        start, end = _shift_bounds(start, end, before=before, count=count)
        _check_shifted_bounds(
            start,
            end,
            maximum=MAX_EXCEL_COLUMN,
            label="column",
        )
        rewritten = (
            f"{column_match.group('start_abs')}{excel_column_letter(start)}:"
            f"{column_match.group('end_abs')}{excel_column_letter(end)}"
        )
        return f"{sheet}!{rewritten}" if sheet is not None else rewritten
    row_match = _WHOLE_ROW_REFERENCE.fullmatch(value)
    if row_match is not None and axis == "row":
        sheet = row_match.group("sheet")
        applies = (
            _sheet_identity(sheet) == target_sheet.casefold()
            if sheet is not None
            else context_sheet is not None
            and context_sheet.casefold() == target_sheet.casefold()
        )
        if not applies:
            return value
        start, end = _shift_bounds(
            int(row_match.group("start")),
            int(row_match.group("end")),
            before=before,
            count=count,
        )
        _check_shifted_bounds(
            start,
            end,
            maximum=MAX_EXCEL_ROW,
            label="row",
        )
        rewritten = (
            f"{row_match.group('start_abs')}{start}:{row_match.group('end_abs')}{end}"
        )
        return f"{sheet}!{rewritten}" if sheet is not None else rewritten
    return value


def rewrite_formula_references(  # noqa: PLR0913
    formula: str,
    *,
    target_sheet: str,
    context_sheet: str | None,
    axis: Literal["row", "column"],
    before: int,
    count: int,
) -> str:
    """Tokenize a formula and rewrite only supported A1 range operands."""
    from openpyxl.formula import Tokenizer

    has_equals = formula.startswith("=")
    source = formula if has_equals else f"={formula}"
    try:
        tokens = Tokenizer(source).items
    except Exception:  # noqa: BLE001 - third-party parser may raise undocumented exceptions
        msg = "Workbook formula cannot be safely rewritten for insertion"
        raise ExcelModificationError(msg) from None
    rewritten: list[str] = ["="]
    for token in tokens:
        value = token.value
        if token.type == "OPERAND" and token.subtype == "RANGE":
            value = rewrite_a1_reference(
                value,
                target_sheet=target_sheet,
                context_sheet=context_sheet,
                axis=axis,
                before=before,
                count=count,
            )
        rewritten.append(value)
    result = "".join(rewritten)
    return result if has_equals else result[1:]


def _rewrite_space_separated_references(  # noqa: PLR0913
    value: str,
    *,
    target_sheet: str,
    context_sheet: str | None,
    axis: Literal["row", "column"],
    before: int,
    count: int,
) -> str:
    return " ".join(
        rewrite_a1_reference(
            item,
            target_sheet=target_sheet,
            context_sheet=context_sheet,
            axis=axis,
            before=before,
            count=count,
        )
        for item in value.split()
    )


def _reject_affected_unknown_reference(
    element: minidom.Element,
    *,
    context_sheet: str | None,
    patch: WorksheetStructuralInsertionPatch,
) -> None:
    known_namespaces = (
        _SPREADSHEETML_WORKSHEET_NAMESPACES
        | _DRAWING_NAMESPACES
        | _CHART_NAMESPACES
        | {_X14_NAMESPACE, _XM_NAMESPACE}
    )
    if element.namespaceURI in known_namespaces:
        return
    values: list[tuple[str, bool]] = []
    for index in range(element.attributes.length):
        attribute = element.attributes.item(index)
        if attribute is None or attribute.localName not in _UNKNOWN_REFERENCE_NAMES:
            continue
        values.append(
            (
                str(getattr(attribute, "value", "")),
                attribute.localName in {"ref", "sqref"},
            )
        )
    if element.localName in _UNKNOWN_REFERENCE_NAMES:
        value = "".join(
            str(getattr(child, "data", ""))
            for child in element.childNodes
            if child.nodeType
            in {minidom.Node.TEXT_NODE, minidom.Node.CDATA_SECTION_NODE}
        )
        if value:
            values.append((value, element.localName in {"ref", "sqref"}))
    for value, is_reference in values:
        try:
            rewritten = (
                _rewrite_space_separated_references(
                    value,
                    target_sheet=patch.sheet_name,
                    context_sheet=context_sheet,
                    axis=patch.axis,
                    before=patch.before,
                    count=patch.count,
                )
                if is_reference
                else rewrite_formula_references(
                    value,
                    target_sheet=patch.sheet_name,
                    context_sheet=context_sheet,
                    axis=patch.axis,
                    before=patch.before,
                    count=patch.count,
                )
            )
        except ExcelModificationError:
            msg = "Workbook unknown extension contains an affected reference"
            raise ExcelModificationError(msg) from None
        if rewritten != value:
            msg = "Workbook unknown extension contains an affected reference"
            raise ExcelModificationError(msg)


def _rewrite_document(  # noqa: C901, PLR0912, PLR0915
    payload: bytes,
    *,
    context_sheet: str | None,
    patch: WorksheetStructuralInsertionPatch,
    part_kind: Literal["worksheet", "workbook", "table", "drawing", "chart"],
    sheet_names: tuple[str, ...] = (),
) -> bytes:
    document = minidom.parseString(  # noqa: S318 - bounded, DTD-screened OOXML.
        payload
    )
    _document_root(document)
    changed = False
    for element in document.getElementsByTagName("*"):
        _reject_affected_unknown_reference(
            element,
            context_sheet=context_sheet,
            patch=patch,
        )
        local_name = element.localName
        namespace = element.namespaceURI
        spreadsheet_element = namespace in _SPREADSHEETML_WORKSHEET_NAMESPACES
        if (
            part_kind in {"worksheet", "table"}
            and context_sheet == patch.sheet_name
            and spreadsheet_element
        ):
            if (
                local_name == "row"
                and patch.axis == "row"
                and element.hasAttribute("r")
            ):
                row = int(element.getAttribute("r"))
                _check_shifted_bounds(
                    row,
                    row,
                    maximum=MAX_EXCEL_ROW,
                    label="row",
                )
                shifted = _shift_index(row, before=patch.before, count=patch.count)
                _check_shifted_bounds(
                    shifted,
                    shifted,
                    maximum=MAX_EXCEL_ROW,
                    label="row",
                )
                element.setAttribute(
                    "r",
                    str(shifted),
                )
            elif local_name == "c" and element.hasAttribute("r"):
                element.setAttribute(
                    "r",
                    _rewrite_cell(
                        element.getAttribute("r"),
                        axis=patch.axis,
                        before=patch.before,
                        count=patch.count,
                    ),
                )
            elif local_name == "col" and patch.axis == "column":
                try:
                    start = int(element.getAttribute("min"))
                    end = int(element.getAttribute("max"))
                except ValueError:
                    msg = "Workbook column metadata is outside Excel bounds"
                    raise ValueError(msg) from None
                start, end = _shift_bounds(
                    start,
                    end,
                    before=patch.before,
                    count=patch.count,
                )
                _check_shifted_bounds(
                    start,
                    end,
                    maximum=MAX_EXCEL_COLUMN,
                    label="column",
                )
                element.setAttribute("min", str(start))
                element.setAttribute("max", str(end))
            for attribute in _REFERENCE_ATTRIBUTES:
                if not element.hasAttribute(attribute):
                    continue
                raw = element.getAttribute(attribute)
                element.setAttribute(
                    attribute,
                    _rewrite_space_separated_references(
                        raw,
                        target_sheet=patch.sheet_name,
                        context_sheet=context_sheet,
                        axis=patch.axis,
                        before=patch.before,
                        count=patch.count,
                    ),
                )
        formula_element = (
            (spreadsheet_element and local_name in _FORMULA_ELEMENTS)
            or (
                namespace in {_X14_NAMESPACE, _XM_NAMESPACE}
                and local_name in {"f", "formula1", "formula2"}
            )
            or (
                part_kind == "chart"
                and namespace in _CHART_NAMESPACES
                and local_name == "f"
            )
        )
        if namespace == _XM_NAMESPACE and local_name == "sqref":
            for child in element.childNodes:
                if isinstance(child, minidom.Text) and child.data:
                    child.data = _rewrite_space_separated_references(
                        child.data,
                        target_sheet=patch.sheet_name,
                        context_sheet=context_sheet,
                        axis=patch.axis,
                        before=patch.before,
                        count=patch.count,
                    )
        if formula_element:
            formula_context = context_sheet
            if part_kind == "workbook" and local_name == "definedName":
                formula_context = None
                raw_scope = element.getAttribute("localSheetId")
                if raw_scope:
                    if not raw_scope.isdigit() or int(raw_scope) >= len(sheet_names):
                        msg = "Workbook defined name scope is invalid"
                        raise ValueError(msg)
                    formula_context = sheet_names[int(raw_scope)]
            for child in element.childNodes:
                if isinstance(child, minidom.Text) and child.data:
                    rewritten = rewrite_formula_references(
                        child.data,
                        target_sheet=patch.sheet_name,
                        context_sheet=formula_context,
                        axis=patch.axis,
                        before=patch.before,
                        count=patch.count,
                    )
                    changed = changed or rewritten != child.data
                    child.data = rewritten
        if (
            part_kind == "drawing"
            and namespace in _DRAWING_NAMESPACES
            and context_sheet == patch.sheet_name
        ):
            marker_name = getattr(element.parentNode, "localName", None)
            if (
                patch.axis == "column"
                and local_name == "col"
                and marker_name
                in {
                    "from",
                    "to",
                }
            ):
                current = int(
                    "".join(
                        child.data
                        for child in element.childNodes
                        if isinstance(child, minidom.Text)
                    )
                )
                if current >= patch.before - 1:
                    shifted = current + patch.count
                    if shifted >= MAX_EXCEL_COLUMN:
                        msg = "worksheet drawing column insertion exceeds Excel bounds"
                        raise ExcelModificationError(msg)
                    text_node = element.firstChild
                    if isinstance(text_node, minidom.Text):
                        text_node.data = str(shifted)
            if (
                patch.axis == "row"
                and local_name == "row"
                and marker_name
                in {
                    "from",
                    "to",
                }
            ):
                current = int(
                    "".join(
                        child.data
                        for child in element.childNodes
                        if isinstance(child, minidom.Text)
                    )
                )
                if current >= patch.before - 1:
                    shifted = current + patch.count
                    if shifted >= MAX_EXCEL_ROW:
                        msg = "worksheet drawing row insertion exceeds Excel bounds"
                        raise ExcelModificationError(msg)
                    text_node = element.firstChild
                    if isinstance(text_node, minidom.Text):
                        text_node.data = str(shifted)
    if part_kind == "chart" and not changed:
        return payload
    return _serialize_xml(document)


def _related_parts(
    package: _SafePackage,
    worksheet_member: str,
) -> tuple[set[str], set[str]]:
    relationships = _relationships(package, worksheet_member)
    tables = {
        relationship.target
        for relationship in relationships.values()
        if relationship.relationship_type.rsplit("/", 1)[-1] == "table"
        and relationship.target is not None
    }
    drawings = {
        relationship.target
        for relationship in relationships.values()
        if relationship.relationship_type.rsplit("/", 1)[-1] == "drawing"
        and relationship.target is not None
    }
    return tables, drawings


def _package_chart_parts(package: _SafePackage) -> tuple[str, ...]:
    """Inventory every internally related chart part in the package."""
    charts: set[str] = set()
    for member in package.names:
        if member.casefold().endswith(".rels"):
            continue
        for relationship in _relationships(package, member).values():
            if (
                relationship.external
                or relationship.relationship_type.rsplit("/", 1)[-1].casefold()
                != "chart"
            ):
                continue
            if relationship.target is None or not package.has(relationship.target):
                msg = "Workbook chart relationship target is missing"
                raise ValueError(msg)
            charts.add(relationship.target)
    return tuple(sorted(charts))


def _pivot_cache_worksheet_sources(  # noqa: C901, PLR0912
    package: _SafePackage,
) -> tuple[_PivotCacheWorksheetSource, ...]:
    """Inventory retained workbook Pivot Cache direct worksheet sources."""
    workbook_root = package.read_xml(_WORKBOOK_MEMBER)
    relationship_ids: list[str] = []
    for element in workbook_root.iter():
        if (
            element.tag.startswith("{")
            and element.tag.partition("}")[0].removeprefix("{")
            in _SPREADSHEETML_WORKSHEET_NAMESPACES
            and _local_name(element.tag) == "pivotCache"
        ):
            identifier = next(
                (
                    value
                    for attribute, value in element.attrib.items()
                    if _local_name(attribute) == "id"
                ),
                None,
            )
            if not identifier or identifier in relationship_ids:
                msg = "Workbook Pivot Cache relationship identity is invalid"
                raise ValueError(msg)
            relationship_ids.append(identifier)
    relationships = _relationships(package, _WORKBOOK_MEMBER)
    sources: list[_PivotCacheWorksheetSource] = []
    visited: set[str] = set()
    for identifier in relationship_ids:
        relationship = relationships.get(identifier)
        if (
            relationship is None
            or relationship.external
            or relationship.target is None
            or relationship.relationship_type.rsplit("/", 1)[-1].casefold()
            != "pivotcachedefinition"
        ):
            msg = "Workbook Pivot Cache relationship is invalid"
            raise ValueError(msg)
        member = relationship.target
        if member in visited:
            continue
        visited.add(member)
        if not package.has(member):
            msg = "Workbook Pivot Cache definition is missing"
            raise ValueError(msg)
        document = minidom.parseString(  # noqa: S318 - bounded, screened OOXML.
            _read_payload(package, member)
        )
        root = _document_root(document)
        if root.namespaceURI not in _SPREADSHEETML_WORKSHEET_NAMESPACES:
            msg = "Workbook Pivot Cache namespace is unsupported"
            raise ValueError(msg)
        for cache_source in root.getElementsByTagNameNS(
            root.namespaceURI, "cacheSource"
        ):
            if cache_source.getAttribute("type") != "worksheet":
                continue
            worksheet_sources = tuple(
                element
                for element in cache_source.getElementsByTagNameNS(
                    root.namespaceURI,
                    "worksheetSource",
                )
            )
            if len(worksheet_sources) != 1:
                msg = "Workbook Pivot Cache worksheet source is invalid"
                raise ValueError(msg)
            worksheet_source = worksheet_sources[0]
            sheet_name = worksheet_source.getAttribute("sheet")
            if not sheet_name:
                continue
            reference = worksheet_source.getAttribute("ref") or None
            if reference is not None:
                try:
                    excel_range_bounds(reference)
                except ValueError:
                    msg = "Workbook Pivot Cache worksheet reference is invalid"
                    raise ValueError(msg) from None
            sources.append(
                _PivotCacheWorksheetSource(
                    member=member,
                    sheet_name=sheet_name,
                    reference=reference,
                )
            )
    return tuple(sources)


def _preflight_pivot_cache_sources(
    package: _SafePackage,
    patch: WorksheetStructuralInsertionPatch,
) -> None:
    for source in _pivot_cache_worksheet_sources(package):
        if source.sheet_name.casefold() != patch.sheet_name.casefold():
            continue
        if source.reference is None or _reference_is_affected(
            source.reference,
            patch=patch,
        ):
            msg = "Workbook Pivot Cache source cannot be safely shifted"
            raise ExcelModificationError(msg)


def _reference_is_affected(
    value: str,
    *,
    patch: WorksheetStructuralInsertionPatch,
) -> bool:
    return (
        rewrite_a1_reference(
            value,
            target_sheet=patch.sheet_name,
            context_sheet=patch.sheet_name,
            axis=patch.axis,
            before=patch.before,
            count=patch.count,
        )
        != value
    )


def _legacy_comment_part_is_affected(
    payload: bytes,
    *,
    relationship_kind: str,
    patch: WorksheetStructuralInsertionPatch,
) -> bool:
    document = minidom.parseString(  # noqa: S318 - bounded, DTD-screened OOXML.
        payload
    )
    _document_root(document)
    if relationship_kind == "comments":
        return any(
            element.namespaceURI in _SPREADSHEETML_WORKSHEET_NAMESPACES
            and element.localName == "comment"
            and element.hasAttribute("ref")
            and _reference_is_affected(element.getAttribute("ref"), patch=patch)
            for element in document.getElementsByTagName("*")
        )
    marker_name = "Column" if patch.axis == "column" else "Row"
    for element in document.getElementsByTagName("*"):
        if element.namespaceURI != _VML_EXCEL_NAMESPACE:
            continue
        if element.localName == "Anchor":
            raw_anchor = "".join(
                str(getattr(child, "data", ""))
                for child in element.childNodes
                if child.nodeType == minidom.Node.TEXT_NODE
            )
            parts = tuple(item.strip() for item in raw_anchor.split(","))
            if len(parts) != _VML_ANCHOR_COMPONENT_COUNT or any(
                not item.isdigit() for item in parts
            ):
                msg = "Workbook legacy drawing anchor is invalid"
                raise ValueError(msg)
            coordinate_indexes = (0, 4) if patch.axis == "column" else (2, 6)
            if any(
                int(parts[index]) >= patch.before - 1 for index in coordinate_indexes
            ):
                return True
            continue
        if element.localName != marker_name:
            continue
        raw = "".join(
            str(getattr(child, "data", ""))
            for child in element.childNodes
            if child.nodeType == minidom.Node.TEXT_NODE
        ).strip()
        if not raw.isdigit():
            msg = "Workbook legacy drawing anchor is invalid"
            raise ValueError(msg)
        if int(raw) >= patch.before - 1:
            return True
    return False


def _preflight_related_parts(
    package: _SafePackage,
    worksheet_member: str,
    patch: WorksheetStructuralInsertionPatch,
) -> None:
    for relationship in _relationships(package, worksheet_member).values():
        if relationship.external:
            continue
        kind = relationship.relationship_type.rsplit("/", 1)[-1]
        target = relationship.target
        if target is None:
            msg = "Workbook structural relationship target is invalid"
            raise ValueError(msg)
        if kind in _UNSUPPORTED_STRUCTURAL_RELATIONSHIPS:
            msg = "Workbook related structure cannot be safely shifted"
            raise ExcelModificationError(msg)
        if kind not in {"comments", "vmlDrawing"}:
            continue
        if not package.has(target):
            msg = "Workbook structural relationship target is missing"
            raise ValueError(msg)
        if _legacy_comment_part_is_affected(
            _read_payload(package, target),
            relationship_kind=kind,
            patch=patch,
        ):
            msg = "Workbook legacy comment structure cannot be safely shifted"
            raise ExcelModificationError(msg)


def create_structural_insertion_output(  # noqa: C901
    source_path: Path,
    output_path: Path,
    patches: Sequence[WorksheetStructuralInsertionPatch],
    *,
    source_fingerprint: str,
) -> tuple[_PendingStructuralInsertion, ...]:
    """Apply deterministic structural insertions without a workbook rewrite."""
    with _SafePackage(source_path) as package:
        package.verify_fingerprint(source_fingerprint)
        package.reject_forbidden_xml_declarations()
        _workbook, records = _workbook_records(package)
        by_name = {record.name: record for record in records}
        replacements: dict[str, bytes] = {}
        normalized_patches = normalize_structural_insertions(patches)
        chart_parts = _package_chart_parts(package)
        original_charts = {
            member: _read_payload(package, member) for member in chart_parts
        }
        for patch in normalized_patches:
            record = by_name.get(patch.sheet_name)
            if (
                record is None
                or record.sheet_type != "worksheet"
                or record.part_name is None
            ):
                msg = "Workbook structural insertion worksheet does not exist"
                raise ExcelModificationError(msg)
            _preflight_pivot_cache_sources(package, patch)
            _preflight_related_parts(package, record.part_name, patch)
            tables, drawings = _related_parts(package, record.part_name)
            sheet_names = tuple(item.name for item in records)
            for sheet_record in records:
                if (
                    sheet_record.sheet_type != "worksheet"
                    or sheet_record.part_name is None
                ):
                    continue
                member = sheet_record.part_name
                replacements[member] = _rewrite_document(
                    replacements.get(member, _read_payload(package, member)),
                    context_sheet=sheet_record.name,
                    patch=patch,
                    part_kind="worksheet",
                )
            replacements[_WORKBOOK_MEMBER] = _rewrite_document(
                replacements.get(
                    _WORKBOOK_MEMBER,
                    _read_payload(package, _WORKBOOK_MEMBER),
                ),
                context_sheet=None,
                patch=patch,
                part_kind="workbook",
                sheet_names=sheet_names,
            )
            for member in tables:
                replacements[member] = _rewrite_document(
                    replacements.get(member, _read_payload(package, member)),
                    context_sheet=patch.sheet_name,
                    patch=patch,
                    part_kind="table",
                )
            for member in drawings:
                replacements[member] = _rewrite_document(
                    replacements.get(member, _read_payload(package, member)),
                    context_sheet=patch.sheet_name,
                    patch=patch,
                    part_kind="drawing",
                )
            for member in chart_parts:
                current = replacements.get(member, original_charts[member])
                rewritten = _rewrite_document(
                    current,
                    context_sheet=None,
                    patch=patch,
                    part_kind="chart",
                )
                if rewritten != current or member in replacements:
                    replacements[member] = rewritten
    _copy_package(
        source_path,
        output_path,
        replacements,
        source_fingerprint=source_fingerprint,
    )
    with _SafePackage(output_path) as output_package:
        for member in chart_parts:
            expected = replacements.get(member, original_charts[member])
            if _read_payload(output_package, member) != expected:
                msg = "Workbook chart reference verification failed"
                raise ExcelModificationError(msg)
    return tuple(
        _PendingStructuralInsertion(
            sheet_name=patch.sheet_name,
            axis=patch.axis,
            before=patch.before,
            count=patch.count,
        )
        for patch in normalized_patches
    )


def _read_payload(package: _SafePackage, member: str) -> bytes:
    with package.open_xml_stream(member) as stream:
        return stream.read()

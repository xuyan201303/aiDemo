"""Bounded, dependency-free OOXML feature inspection."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import PurePosixPath
from typing import TYPE_CHECKING
from zipfile import BadZipFile

from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.excel._package_chartsheet import _chartsheet_facts
from document_sdk.excel._package_macrosheet import (
    _macro_sheet_facts,
    _SharedStringTableCache,
)
from document_sdk.excel._package_security import _local_name, _PackageLimits
from document_sdk.excel._package_security import _SafePackage as _BoundedSafePackage
from document_sdk.excel._package_workbook import (
    _active_x_count,
    _apply_print_names,
    _calculation_mode,
    _defined_names,
    _unknown_package_parts,
    _unsupported_sheet,
    _validate_main_workbook,
    _workbook_protection_present,
    _workbook_records,
)
from document_sdk.excel._package_worksheet import _worksheet_xml_facts
from document_sdk.excel.models import (
    ExcelPackageLimits,
    UnsupportedSheetFeature,
    WorkbookFeatureInventory,
)

if TYPE_CHECKING:
    from pathlib import Path

    from document_sdk.core import FileDescriptor
    from document_sdk.excel._package_types import _WorksheetFacts


_MAX_PACKAGE_MEMBERS = 10_000
_MAX_TOTAL_UNCOMPRESSED_BYTES = 512 * 1024 * 1024
_MAX_XML_MEMBER_BYTES = 64 * 1024 * 1024
_MAX_COMPRESSION_RATIO = 1_000


@dataclass(frozen=True, slots=True)
class PackageRiskFacts:
    """Private facts needed for conservative preservation decisions."""

    cell_values_present: bool
    formula_cache_present: bool
    shape_or_unknown_drawing_present: bool
    worksheet_extension_present: bool
    dynamic_array_metadata_present: bool


@dataclass(frozen=True, slots=True)
class PackageFeatureScan:
    """A public inventory plus private preservation-only facts."""

    inventory: WorkbookFeatureInventory
    risk_facts: PackageRiskFacts


class _SafePackage(_BoundedSafePackage):
    """Compatibility wrapper using limits patched on this entry module."""

    def __init__(self, path: Path, *, limits: ExcelPackageLimits | None = None) -> None:
        selected = limits
        super().__init__(
            path,
            limits=_PackageLimits(
                package_members=(
                    _MAX_PACKAGE_MEMBERS
                    if selected is None
                    else selected.package_members
                ),
                total_uncompressed_bytes=(
                    _MAX_TOTAL_UNCOMPRESSED_BYTES
                    if selected is None
                    else selected.total_uncompressed_bytes
                ),
                xml_member_bytes=(
                    _MAX_XML_MEMBER_BYTES
                    if selected is None
                    else selected.xml_member_bytes
                ),
                compression_ratio=(
                    _MAX_COMPRESSION_RATIO
                    if selected is None
                    else selected.compression_ratio
                ),
            ),
        )


def validate_package(path: Path, *, limits: ExcelPackageLimits | None = None) -> None:
    """Validate OOXML ZIP safety and the required main workbook identity."""
    try:
        package_context = _SafePackage(path, limits=limits)
    except BadZipFile as exc:
        msg = "Workbook is not a valid OOXML package"
        _raise_redacted_translation(exc, ValueError(msg))
    with package_context as package:
        package.reject_forbidden_xml_declarations()
        _validate_main_workbook(package)


def validate_package_nonworksheet_sheets(
    path: Path,
    *,
    descriptor: FileDescriptor,
    limits: ExcelPackageLimits | None = None,
) -> None:
    """Validate supported non-worksheet sheet parts for structural inspection."""
    try:
        package_context = _SafePackage(path, limits=limits)
    except BadZipFile as exc:
        msg = "Workbook is not a valid OOXML package"
        _raise_redacted_translation(exc, ValueError(msg))
    with package_context as package:
        package.verify_fingerprint(descriptor.fingerprint.value)
        workbook, sheets = _workbook_records(package)
        shared_strings = _SharedStringTableCache(
            package,
            entry_limit=(limits.shared_string_entries if limits is not None else None),
        )
        for workbook_order, sheet in enumerate(sheets, start=1):
            if sheet.sheet_type == "chartsheet":
                _chartsheet_facts(
                    package,
                    sheet=sheet,
                    workbook_order=workbook_order,
                )
            elif sheet.sheet_type == "macro_sheet":
                _macro_sheet_facts(
                    package,
                    workbook=workbook,
                    sheet=sheet,
                    workbook_order=workbook_order,
                    feature_record_limit=(
                        limits.worksheet_feature_records if limits is not None else None
                    ),
                    shared_string_entry_limit=(
                        limits.shared_string_entries if limits is not None else None
                    ),
                    shared_string_loader=shared_strings,
                )


def _dynamic_array_metadata_present(package: _SafePackage) -> bool:
    """Return whether cell metadata declares dynamic-array properties."""
    if not package.has("xl/metadata.xml"):
        return False
    root = package.read_xml("xl/metadata.xml")
    return any(
        _local_name(element.tag) == "metadataType"
        and element.attrib.get("name", "").casefold() == "xldapr"
        for element in root.iter()
    )


def inspect_package_features(
    path: Path,
    *,
    descriptor: FileDescriptor,
    limits: ExcelPackageLimits | None = None,
) -> PackageFeatureScan:
    """Inspect workbook features without instantiating provider objects."""
    try:
        package_context = _SafePackage(path, limits=limits)
    except BadZipFile as exc:
        msg = "Workbook is not a valid OOXML package"
        _raise_redacted_translation(exc, ValueError(msg))

    with package_context as package:
        package.verify_fingerprint(descriptor.fingerprint.value)
        workbook, sheets = _workbook_records(package)
        facts_by_name: dict[str, _WorksheetFacts] = {}
        unsupported: list[UnsupportedSheetFeature] = []
        ordered_worksheets: list[_WorksheetFacts] = []
        chartsheets = []
        macro_sheet_facts = []
        shared_strings = _SharedStringTableCache(
            package,
            entry_limit=(limits.shared_string_entries if limits is not None else None),
        )
        for workbook_order, sheet in enumerate(sheets, start=1):
            if sheet.sheet_type == "chartsheet":
                chartsheets.append(
                    _chartsheet_facts(
                        package,
                        sheet=sheet,
                        workbook_order=workbook_order,
                    ).inventory
                )
                continue
            if sheet.sheet_type == "macro_sheet":
                macro_sheet_facts.append(
                    _macro_sheet_facts(
                        package,
                        workbook=workbook,
                        sheet=sheet,
                        workbook_order=workbook_order,
                        feature_record_limit=(
                            limits.worksheet_feature_records
                            if limits is not None
                            else None
                        ),
                        shared_string_entry_limit=(
                            limits.shared_string_entries if limits is not None else None
                        ),
                        shared_string_loader=shared_strings,
                    )
                )
                continue
            if sheet.sheet_type != "worksheet":
                unsupported.append(_unsupported_sheet(sheet))
                continue
            facts = _worksheet_xml_facts(
                package,
                sheet=sheet,
                file_id=descriptor.file_id,
                feature_record_limit=(
                    limits.worksheet_feature_records if limits is not None else None
                ),
            )
            facts_by_name[sheet.name] = facts
            ordered_worksheets.append(facts)

        _apply_print_names(
            workbook,
            facts_by_name=facts_by_name,
        )
        names = package.names
        non_comment_vml_present = any(
            name.lower().startswith("xl/drawings/")
            and name.lower().endswith(".vml")
            and not PurePosixPath(name).name.lower().startswith("commentsdrawing")
            for name in names
        )
        worksheets = tuple(facts.to_inventory() for facts in ordered_worksheets)
        inventory = WorkbookFeatureInventory(
            file=descriptor,
            workbook_type="xlsm" if descriptor.extension == ".xlsm" else "xlsx",
            sheet_names=tuple(sheet.name for sheet in sheets),
            worksheet_count=len(worksheets),
            worksheets=worksheets,
            chartsheet_count=len(chartsheets),
            chartsheets=tuple(chartsheets),
            macro_sheet_count=len(macro_sheet_facts),
            macro_sheets=tuple(facts.inventory for facts in macro_sheet_facts),
            unsupported_sheets=tuple(unsupported),
            defined_names=_defined_names(
                workbook,
                file_id=descriptor.file_id,
                sheets=sheets,
            ),
            external_link_count=sum(
                name.startswith("xl/externalLinks/externalLink")
                and name.endswith(".xml")
                for name in names
            ),
            calculation_mode=_calculation_mode(workbook),
            vba_project_present="xl/vbaProject.bin" in names,
            workbook_protection_present=_workbook_protection_present(workbook),
            active_x_count=_active_x_count(names),
            unknown_package_parts=_unknown_package_parts(names),
        )
        return PackageFeatureScan(
            inventory=inventory,
            risk_facts=PackageRiskFacts(
                cell_values_present=any(
                    facts.cell_values_present for facts in ordered_worksheets
                ),
                formula_cache_present=any(
                    facts.formula_cache_present for facts in ordered_worksheets
                )
                or any(facts.formula_cache_present for facts in macro_sheet_facts),
                shape_or_unknown_drawing_present=any(
                    facts.shape_or_unknown_drawing_present
                    for facts in ordered_worksheets
                )
                or non_comment_vml_present,
                worksheet_extension_present=any(
                    facts.worksheet_extension_present for facts in ordered_worksheets
                ),
                dynamic_array_metadata_present=_dynamic_array_metadata_present(package),
            ),
        )

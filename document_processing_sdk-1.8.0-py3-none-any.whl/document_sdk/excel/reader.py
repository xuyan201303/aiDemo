"""Local Excel worksheet and bounded-range reading."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, time, timedelta
from heapq import merge
from itertools import zip_longest
from typing import TYPE_CHECKING
from zipfile import ZipFile, ZipInfo

from document_sdk.core import (
    DocumentProcessingError,
    ExcelCell,
    ExcelCellLimitExceededError,
    ExcelSourceReference,
    FileDescriptor,
    WorksheetData,
)
from document_sdk.core._excel_coordinates import (
    ExcelRangeBounds,
    excel_column_letter,
    excel_range_bounds,
    format_excel_range,
)
from document_sdk.excel._dependencies import require_excel_support
from document_sdk.excel._helpers import (
    inspect_excel_input,
    normalize_excel_value,
    translate_excel_errors,
)
from document_sdk.excel._ooxml import WorksheetStructure, inspect_ooxml_worksheet
from document_sdk.excel._reader_hyperlinks import hyperlink_values
from document_sdk.excel._source_identity import verify_open_binary
from document_sdk.excel._streaming_ooxml import (
    _represented_cells,
    _support_members,
    _workbook_relationships,
)
from document_sdk.excel.formula import inspect_formula_metadata
from document_sdk.excel.streaming import _close_iterator

if TYPE_CHECKING:
    from collections.abc import Mapping
    from pathlib import Path
    from typing import BinaryIO

    from openpyxl.workbook.workbook import Workbook

    from document_sdk.excel.formula import FormulaMetadata
    from document_sdk.excel.models import FormulaView


DEFAULT_MAX_RANGE_CELLS = 100_000


@dataclass(frozen=True, slots=True)
class _ReaderCell:
    """One normalized cell and its original backend temporal-type fact."""

    cell: ExcelCell
    temporal_source_eligible: bool


def _validate_formula_view(formula_view: FormulaView) -> FormulaView:
    """Validate a formula projection without accepting arbitrary strings."""
    if formula_view not in {"both", "formula", "cached"}:
        msg = "formula_view must be 'both', 'formula', or 'cached'"
        raise ValueError(msg)
    return formula_view


def _validate_max_cells(
    max_cells: int | None,
    *,
    allow_none: bool,
) -> int | None:
    """Validate a positive cell-count limit without accepting booleans."""
    if max_cells is None and allow_none:
        return None
    if isinstance(max_cells, bool) or not isinstance(max_cells, int) or max_cells <= 0:
        msg = "max_cells must be a positive integer"
        raise ValueError(msg)
    return max_cells


def _enforce_cell_limit(*, requested_cells: int, max_cells: int | None) -> None:
    """Fail before worksheet iteration when a configured limit is exceeded."""
    if max_cells is not None and requested_cells > max_cells:
        raise ExcelCellLimitExceededError(
            requested_cells=requested_cells,
            max_cells=max_cells,
        )


def _worksheet_structure(
    path: Path,
    sheet_name: str,
    *,
    expected_fingerprint: str,
    selected_bounds: ExcelRangeBounds | None = None,
) -> WorksheetStructure:
    """Return one named sparse worksheet structure or a public safe error."""
    structure = inspect_ooxml_worksheet(
        path,
        sheet_name,
        expected_fingerprint=expected_fingerprint,
        validate_cell_types=True,
        selected_bounds=selected_bounds,
    )
    if structure is not None:
        return structure
    msg = f"Worksheet does not exist: {sheet_name}"
    raise DocumentProcessingError(msg)


def _excel_cell(  # noqa: PLR0913 - explicit conversion inputs stay auditable.
    *,
    descriptor: FileDescriptor,
    sheet_name: str,
    expected_coordinate: str,
    formula_cell: object,
    cached_cell: object,
    formula_metadata: Mapping[tuple[str, str], FormulaMetadata],
    formula_view: FormulaView,
    hyperlink_value: str | None,
) -> ExcelCell | None:
    """Normalize one openpyxl read-only cell without returning backend objects."""
    value = getattr(formula_cell, "value", None)
    hyperlink_only = value is None and hyperlink_value is not None
    if value is None and not hyperlink_only:
        return None
    if hyperlink_only:
        coordinate = expected_coordinate
        data_type_value = "s"
    else:
        coordinate_value = getattr(formula_cell, "coordinate", None)
        raw_data_type = getattr(formula_cell, "data_type", None)
        if not isinstance(coordinate_value, str) or not isinstance(
            raw_data_type,
            str,
        ):
            msg = "Workbook returned invalid cell metadata"
            raise DocumentProcessingError(msg)
        coordinate = coordinate_value.upper()
        data_type_value = raw_data_type
    style_id_value = getattr(formula_cell, "style_id", None)
    style_id = (
        style_id_value
        if isinstance(style_id_value, int)
        else (0 if hyperlink_only else None)
    )
    number_format_value = getattr(formula_cell, "number_format", None)
    number_format = (
        number_format_value
        if isinstance(number_format_value, str)
        else ("General" if hyperlink_only else None)
    )
    source = ExcelSourceReference(
        file_id=descriptor.file_id,
        sheet_name=sheet_name,
        cell_range=coordinate,
    )
    if hyperlink_only:
        return ExcelCell(
            coordinate=coordinate,
            value=hyperlink_value,
            data_type=data_type_value,
            style_id=style_id,
            number_format=number_format,
            source=source,
        )
    if data_type_value == "f":
        metadata = formula_metadata.get((sheet_name, coordinate))
        cached_value = normalize_excel_value(getattr(cached_cell, "value", None))
        cache_available = bool(metadata and metadata.has_cached_value)
        if formula_view == "cached":
            cached_data_type = getattr(cached_cell, "data_type", None)
            return ExcelCell(
                coordinate=coordinate,
                value=cached_value,
                cached_value=cached_value if cache_available else None,
                has_cached_value=cache_available,
                formula_kind=metadata.kind if metadata is not None else "ordinary",
                external_reference=bool(metadata and metadata.external_reference),
                requires_recalculation=True,
                data_type=(
                    f"formula_cache:{cached_data_type}"
                    if isinstance(cached_data_type, str)
                    else "formula_cache"
                ),
                style_id=style_id,
                number_format=number_format,
                source=source,
            )
        formula_text_value = (
            value if isinstance(value, str) else getattr(value, "text", None)
        )
        if not isinstance(formula_text_value, str):
            msg = "Workbook returned invalid formula text"
            raise DocumentProcessingError(msg)
        formula_text = (
            formula_text_value
            if formula_text_value.startswith("=")
            else f"={formula_text_value}"
        )
        include_cache = formula_view == "both"
        return ExcelCell(
            coordinate=coordinate,
            formula=formula_text,
            cached_value=cached_value if include_cache else None,
            has_cached_value=cache_available,
            formula_kind=metadata.kind if metadata is not None else "ordinary",
            external_reference=bool(metadata and metadata.external_reference),
            requires_recalculation=True,
            data_type="formula",
            style_id=style_id,
            number_format=number_format,
            source=source,
        )
    return ExcelCell(
        coordinate=coordinate,
        value=normalize_excel_value(value),
        data_type=data_type_value,
        style_id=style_id,
        number_format=number_format,
        source=source,
    )


def _read_cells(  # noqa: C901, PLR0913 - explicit resource lifecycle is auditable.
    path: Path,
    *,
    descriptor: FileDescriptor,
    sheet_name: str,
    bounds: ExcelRangeBounds,
    merged_ranges: tuple[str, ...],
    requires_hyperlink_values: bool,
    expected_fingerprint: str,
    formula_view: FormulaView,
    has_formulas: bool,
) -> tuple[ExcelCell, ...]:
    """Read non-empty cells inside exact inclusive bounds through openpyxl."""
    formula_workbook = None
    cached_workbook = None
    formula_stream = None
    cached_stream = None
    try:
        formula_metadata = (
            inspect_formula_metadata(
                path,
                sheet_name=sheet_name,
                bounds=bounds,
                expected_fingerprint=expected_fingerprint,
            )
            if has_formulas
            else {}
        )
        hyperlink_value_by_coordinate = (
            hyperlink_values(
                path,
                sheet_name=sheet_name,
                bounds=bounds,
                merged_ranges=merged_ranges,
                expected_fingerprint=expected_fingerprint,
            )
            if requires_hyperlink_values
            else {}
        )
        formula_stream = path.open("rb")
        verify_open_binary(formula_stream, expected_fingerprint)
        styles_member = _reader_style_member(formula_stream)
        formula_workbook = _load_reader_workbook(
            formula_stream,
            styles_member=styles_member,
            data_only=False,
        )
        cached_stream = path.open("rb")
        verify_open_binary(cached_stream, expected_fingerprint)
        cached_workbook = _load_reader_workbook(
            cached_stream,
            styles_member=styles_member,
            data_only=True,
        )
        if sheet_name not in formula_workbook.sheetnames:
            msg = f"Worksheet does not exist: {sheet_name}"
            raise DocumentProcessingError(msg)
        formula_sheet = formula_workbook[sheet_name]
        cached_sheet = cached_workbook[sheet_name]
        formula_rows = formula_sheet.iter_rows(
            min_row=bounds.min_row,
            max_row=bounds.max_row,
            min_col=bounds.min_column,
            max_col=bounds.max_column,
        )
        cached_rows = cached_sheet.iter_rows(
            min_row=bounds.min_row,
            max_row=bounds.max_row,
            min_col=bounds.min_column,
            max_col=bounds.max_column,
        )
        cells: list[_ReaderCell] = []
        for row, (formula_row, cached_row) in enumerate(
            zip_longest(
                formula_rows,
                cached_rows,
                fillvalue=(),
            ),
            start=bounds.min_row,
        ):
            for column, (formula_cell, cached_cell) in enumerate(
                zip_longest(
                    formula_row,
                    cached_row,
                    fillvalue=None,
                ),
                start=bounds.min_column,
            ):
                expected_coordinate = f"{excel_column_letter(column)}{row}"
                hyperlink_value = hyperlink_value_by_coordinate.pop(
                    expected_coordinate,
                    None,
                )
                temporal_source_eligible = _temporal_source_eligible(
                    formula_cell,
                    cached_cell,
                    formula_view=formula_view,
                )
                cell = _excel_cell(
                    descriptor=descriptor,
                    sheet_name=sheet_name,
                    expected_coordinate=expected_coordinate,
                    formula_cell=formula_cell,
                    cached_cell=cached_cell,
                    formula_metadata=formula_metadata,
                    formula_view=formula_view,
                    hyperlink_value=hyperlink_value,
                )
                if cell is not None:
                    cells.append(_ReaderCell(cell, temporal_source_eligible))
        hyperlink_cells: list[_ReaderCell] = []
        for coordinate, hyperlink_value in hyperlink_value_by_coordinate.items():
            cell = _excel_cell(
                descriptor=descriptor,
                sheet_name=sheet_name,
                expected_coordinate=coordinate,
                formula_cell=None,
                cached_cell=None,
                formula_metadata=formula_metadata,
                formula_view=formula_view,
                hyperlink_value=hyperlink_value,
            )
            if cell is not None:  # pragma: no branch - target is always present.
                hyperlink_cells.append(
                    _ReaderCell(cell, temporal_source_eligible=False)
                )
        hyperlink_cells.sort(key=_reader_cell_position)
        result = tuple(
            merge(
                cells,
                hyperlink_cells,
                key=_reader_cell_position,
            )
        )
    finally:
        if formula_workbook is not None:
            formula_workbook.close()
        if cached_workbook is not None:
            cached_workbook.close()
        if formula_stream is not None:
            formula_stream.close()
        if cached_stream is not None:
            cached_stream.close()
    return _with_temporal_sources(
        path,
        result,
        sheet_name=sheet_name,
        bounds=bounds,
        expected_fingerprint=expected_fingerprint,
    )


def _reader_style_member(stream: BinaryIO) -> str | None:
    """Resolve bounded support declarations on the already verified input."""
    with ZipFile(stream) as archive:
        shared_strings, styles = _support_members(_workbook_relationships(archive))
        for member in (shared_strings, styles):
            if member is not None:
                archive.getinfo(member)
    return styles


class _StyleTargetArchive(ZipFile):
    """Let one backend instance read its fixed styles name at the real target."""

    def __init__(self, stream: BinaryIO, styles_member: str) -> None:
        self._styles_member = styles_member
        super().__init__(stream)

    def read(self, name: str | ZipInfo, pwd: bytes | None = None) -> bytes:
        """Redirect only the backend's styles read; retain ordinary ZIP safety."""
        member = self._styles_member if name == "xl/styles.xml" else name
        return super().read(member, pwd)


def _load_reader_workbook(
    stream: BinaryIO,
    *,
    styles_member: str | None,
    data_only: bool,
) -> Workbook:
    """Reuse openpyxl decoding while honoring a safe relocated styles part."""
    from openpyxl import load_workbook

    if styles_member is None or styles_member == "xl/styles.xml":
        return load_workbook(stream, read_only=True, data_only=data_only)

    from openpyxl.reader.excel import ExcelReader

    backend = ExcelReader(stream, read_only=True, data_only=data_only)
    backend.archive.close()
    backend.archive = _StyleTargetArchive(stream, styles_member)
    try:
        backend.read()
        workbook = backend.wb
    except BaseException:
        backend.archive.close()
        raise
    else:
        return workbook


def _temporal_source_eligible(
    formula_cell: object,
    cached_cell: object,
    *,
    formula_view: FormulaView,
) -> bool:
    """Retain backend temporal typing before normalization can stringify durations."""
    is_formula = getattr(formula_cell, "data_type", None) == "f"
    if is_formula and formula_view == "formula":
        return False
    value = getattr(cached_cell if is_formula else formula_cell, "value", None)
    return isinstance(value, (date, time, timedelta))


def _with_temporal_sources(
    path: Path,
    cells: tuple[_ReaderCell, ...],
    *,
    sheet_name: str,
    bounds: ExcelRangeBounds,
    expected_fingerprint: str,
) -> tuple[ExcelCell, ...]:
    """Merge one bounded source stream with ordered, already normalized cells.

    Only one raw cell is retained. Non-temporal cells keep the existing reader
    decoding route, and no public streaming cell-count default is introduced.
    """
    if not any(record.temporal_source_eligible for record in cells):
        return tuple(record.cell for record in cells)
    records = _represented_cells(
        path,
        sheet_name,
        expected_fingerprint=expected_fingerprint,
        selected_ranges=(bounds,),
        selected_coordinates=(
            record.cell.coordinate
            for record in cells
            if record.temporal_source_eligible
        ),
        source_only=True,
    )
    projected: list[ExcelCell] = []
    try:
        for record in cells:
            cell = record.cell
            if not record.temporal_source_eligible:
                projected.append(cell)
                continue
            raw = next(records, None)
            if (
                raw is None
                or raw.coordinate != cell.coordinate
                or raw.temporal_source is None
            ):
                msg = "Workbook temporal source does not match its exposed cell"
                raise DocumentProcessingError(msg)
            projected.append(
                ExcelCell.model_validate(
                    {**cell.model_dump(), "temporal_source": raw.temporal_source}
                )
            )
        if next(records, None) is not None:
            msg = "Workbook returned an unexpected temporal source cell"
            raise DocumentProcessingError(msg)
        return tuple(projected)
    finally:
        _close_iterator(records)


def _used_range(cells: tuple[ExcelCell, ...]) -> str | None:
    """Return actual non-empty bounds for a normalized cell tuple."""
    if not cells:
        return None
    bounds = [excel_range_bounds(cell.coordinate) for cell in cells]
    return format_excel_range(
        min(item.min_column for item in bounds),
        min(item.min_row for item in bounds),
        max(item.max_column for item in bounds),
        max(item.max_row for item in bounds),
    )


def _cell_position(cell: ExcelCell) -> tuple[int, int]:
    """Return a deterministic row-major coordinate key."""
    bounds = excel_range_bounds(cell.coordinate)
    return bounds.min_row, bounds.min_column


def _reader_cell_position(record: _ReaderCell) -> tuple[int, int]:
    """Order the private typing flag with its normalized cell."""
    return _cell_position(record.cell)


def read_sheet(
    path: Path,
    sheet_name: str,
    *,
    max_cells: int | None = None,
    formula_view: FormulaView = "both",
) -> WorksheetData:
    """Read one worksheet with an optional rectangular cell-count limit.

    Args:
        path: Local ``.xlsx`` or ``.xlsm`` path.
        sheet_name: Exact worksheet name.
        max_cells: Optional positive maximum for the non-empty used rectangle.
            ``None`` preserves the existing unlimited default behavior.
        formula_view: Return formula text, cached values, or both.

    Returns:
        Normalized non-empty cells with source references.

    Raises:
        ExcelCellLimitExceededError: If the used rectangle exceeds max_cells.
    """
    require_excel_support()
    validated_limit = _validate_max_cells(max_cells, allow_none=True)
    validated_formula_view = _validate_formula_view(formula_view)
    descriptor = inspect_excel_input(path)

    with translate_excel_errors(path, "read"):
        expected_fingerprint = descriptor.fingerprint.value
        structure = _worksheet_structure(
            path,
            sheet_name,
            expected_fingerprint=expected_fingerprint,
        )
        if structure.used_range is None:
            return WorksheetData(
                file=descriptor,
                sheet_name=sheet_name,
                used_range=None,
            )
        bounds = excel_range_bounds(structure.used_range)
        _enforce_cell_limit(
            requested_cells=bounds.cell_count,
            max_cells=validated_limit,
        )
        cells = _read_cells(
            path,
            descriptor=descriptor,
            sheet_name=sheet_name,
            bounds=bounds,
            merged_ranges=structure.merged_ranges,
            requires_hyperlink_values=structure.requires_full_read,
            expected_fingerprint=expected_fingerprint,
            formula_view=validated_formula_view,
            has_formulas=structure.formula_cell_count > 0,
        )

    return WorksheetData(
        file=descriptor,
        sheet_name=sheet_name,
        used_range=_used_range(cells),
        cells=cells,
    )


def read_range(
    path: Path,
    sheet_name: str,
    cell_range: str,
    *,
    max_cells: int = DEFAULT_MAX_RANGE_CELLS,
    formula_view: FormulaView = "both",
) -> WorksheetData:
    """Read non-empty cells from one exact, bounded worksheet range.

    Empty cells are omitted, matching :class:`WorksheetData`. The returned
    ``used_range`` is the actual non-empty bounds within the requested range,
    or ``None`` when the requested range contains no values. Formula text and
    available cached values are preserved; formulas are never calculated.

    Args:
        path: Local ``.xlsx`` or ``.xlsm`` path.
        sheet_name: Exact worksheet name.
        cell_range: Inclusive Excel cell or rectangular range.
        max_cells: Positive maximum requested rectangular cell count.
        formula_view: Return formula text, cached values, or both.

    Returns:
        Normalized non-empty cells limited to cell_range.

    Raises:
        ExcelCellLimitExceededError: If cell_range exceeds max_cells.
    """
    require_excel_support()
    validated_limit = _validate_max_cells(max_cells, allow_none=False)
    validated_formula_view = _validate_formula_view(formula_view)
    bounds = excel_range_bounds(cell_range)
    _enforce_cell_limit(
        requested_cells=bounds.cell_count,
        max_cells=validated_limit,
    )
    descriptor = inspect_excel_input(path)

    with translate_excel_errors(path, "read"):
        expected_fingerprint = descriptor.fingerprint.value
        structure = _worksheet_structure(
            path,
            sheet_name,
            expected_fingerprint=expected_fingerprint,
            selected_bounds=bounds,
        )
        cells = _read_cells(
            path,
            descriptor=descriptor,
            sheet_name=sheet_name,
            bounds=bounds,
            merged_ranges=structure.merged_ranges,
            requires_hyperlink_values=structure.requires_full_read,
            expected_fingerprint=expected_fingerprint,
            formula_view=validated_formula_view,
            has_formulas=structure.formula_cell_count > 0,
        )

    return WorksheetData(
        file=descriptor,
        sheet_name=sheet_name,
        used_range=_used_range(cells),
        cells=cells,
    )

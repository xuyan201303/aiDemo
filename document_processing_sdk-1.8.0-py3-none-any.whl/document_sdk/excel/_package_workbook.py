"""Workbook-level OOXML records, names, and preservation risk helpers."""

from __future__ import annotations

import re
from pathlib import PurePosixPath
from typing import TYPE_CHECKING, Literal

from document_sdk.core import ExcelSourceReference
from document_sdk.core._excel_coordinates import normalize_excel_range
from document_sdk.excel._package_security import (
    _attribute_by_local_name,
    _first_descendant,
    _local_name,
    _relationships,
    _SafePackage,
)
from document_sdk.excel._package_types import (
    SheetVisibility,
    UnsupportedSheetType,
    _SheetRecord,
    _WorksheetFacts,
)
from document_sdk.excel._visible_text import _SPREADSHEETML_NAMESPACES
from document_sdk.excel.errors import ExcelPackageLimitError
from document_sdk.excel.models import (
    DefinedNameFeature,
    UnsupportedSheetFeature,
)

if TYPE_CHECKING:
    from xml.etree.ElementTree import Element


_RELATIONSHIP_ID = (
    "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
)
_DEFINED_RANGE = re.compile(
    r"^(?P<sheet>'(?:[^']|'')+'|[^!,]+)!"
    r"(?P<range>\$?[A-Za-z]{1,3}\$?\d+(?::\$?[A-Za-z]{1,3}\$?\d+)?)$"
)
_PRINT_ROWS = re.compile(
    r"^(?P<sheet>'(?:[^']|'')+'|[^!,]+)!"
    r"\$?(?P<start>\d+):\$?(?P<end>\d+)$"
)
_PRINT_COLUMNS = re.compile(
    r"^(?P<sheet>'(?:[^']|'')+'|[^!,]+)!"
    r"\$?(?P<start>[A-Za-z]{1,3}):\$?(?P<end>[A-Za-z]{1,3})$"
)
_EXTERNAL_DEFINED_NAME_REFERENCE = re.compile(
    r"\[[^][]+\][^!()\[\],+*/^&<>=]*!",
    re.IGNORECASE,
)
_MAX_DEFINED_NAMES = 100_000
_MAX_DEFINED_NAME_TARGETS = 100_000
_OFFICE_DOCUMENT_RELATIONSHIPS = frozenset(
    {
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument",
        "http://purl.oclc.org/ooxml/officeDocument/relationships/officeDocument",
    }
)
_WORKBOOK_CONTENT_TYPES = frozenset(
    {
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml",
        "application/vnd.ms-excel.sheet.macroEnabled.main+xml",
    }
)


def _validate_main_workbook(package: _SafePackage) -> None:
    """Bind the root Office identity to the workbook consumed by Excel readers."""
    from document_sdk.excel._package_chartsheet import (
        _content_types,
        _part_content_type,
    )

    main_relationships = tuple(
        relationship
        for relationship in _relationships(package, "").values()
        if relationship.relationship_type in _OFFICE_DOCUMENT_RELATIONSHIPS
    )
    if len(main_relationships) != 1 or main_relationships[0].external:
        msg = "Workbook requires one internal Office document relationship"
        raise ValueError(msg)
    target = main_relationships[0].target
    # Existing Excel parsers consume this exact part. Checking its identity does
    # not impose a new directory whitelist on supporting relationship targets.
    if target != "xl/workbook.xml" or not package.has(target):
        msg = "Workbook main relationship does not identify the parsed workbook"
        raise ValueError(msg)
    content_type = _part_content_type(target, _content_types(package))
    if content_type not in _WORKBOOK_CONTENT_TYPES:
        msg = "Workbook main relationship has an invalid content type"
        raise ValueError(msg)


class _DefinedNameTargetBudget:
    """Bound target parsing across all defined names in one workbook pass."""

    __slots__ = ("_observed",)

    def __init__(self) -> None:
        self._observed = 0

    def reserve(self) -> None:
        """Reserve one target before allocating its normalized string."""
        observed = self._observed + 1
        if observed > _MAX_DEFINED_NAME_TARGETS:
            raise ExcelPackageLimitError(
                limit_name="defined_name_targets",
                observed=observed,
                maximum=_MAX_DEFINED_NAME_TARGETS,
            )
        self._observed = observed


def _sheet_type(
    relationship_type: str,
) -> Literal["worksheet", "chartsheet", "dialog_sheet", "macro_sheet", "unknown"]:
    suffix = relationship_type.rsplit("/", 1)[-1].lower()
    mapping: dict[
        str,
        Literal["worksheet", "chartsheet", "dialog_sheet", "macro_sheet", "unknown"],
    ] = {
        "worksheet": "worksheet",
        "chartsheet": "chartsheet",
        "dialogsheet": "dialog_sheet",
        "macrosheet": "macro_sheet",
        "xlmacrosheet": "macro_sheet",
    }
    return mapping.get(suffix, "unknown")


def _sheet_visibility(value: str | None) -> SheetVisibility:
    if value in {None, "visible"}:
        return "visible"
    if value == "hidden":
        return "hidden"
    if value == "veryHidden":
        return "veryHidden"
    msg = "Workbook sheet has an invalid visibility state"
    raise ValueError(msg)


def _workbook_records(
    package: _SafePackage,
) -> tuple[Element, tuple[_SheetRecord, ...]]:
    _validate_main_workbook(package)
    workbook = package.read_xml("xl/workbook.xml")
    if workbook.tag not in {
        f"{{{namespace}}}workbook" for namespace in _SPREADSHEETML_NAMESPACES
    }:
        msg = "Workbook root or namespace is invalid"
        raise ValueError(msg)
    workbook_relationships = _relationships(package, "xl/workbook.xml")
    records: list[_SheetRecord] = []
    sheet_names: set[str] = set()
    relationship_ids: set[str] = set()
    for element in workbook.iter():
        if _local_name(element.tag) != "sheet":
            continue
        name = element.attrib.get("name")
        if not name:
            msg = "Workbook sheet is missing its name"
            raise ValueError(msg)
        relationship_id = element.attrib.get(
            _RELATIONSHIP_ID
        ) or _attribute_by_local_name(element, "id")
        normalized_name = name.casefold()
        if normalized_name in sheet_names or (
            relationship_id is not None and relationship_id in relationship_ids
        ):
            msg = "Workbook contains duplicate sheet references"
            raise ValueError(msg)
        sheet_names.add(normalized_name)
        if relationship_id is not None:
            relationship_ids.add(relationship_id)
        relationship = workbook_relationships.get(relationship_id or "")
        records.append(
            _SheetRecord(
                name=name,
                visibility=_sheet_visibility(element.attrib.get("state")),
                relationship_id=relationship_id,
                part_name=relationship.target if relationship else None,
                sheet_type=(
                    _sheet_type(relationship.relationship_type)
                    if relationship
                    else "unknown"
                ),
            )
        )
    return workbook, tuple(records)


def _source(file_id: str, sheet_name: str, cell_range: str) -> ExcelSourceReference:
    return ExcelSourceReference(
        file_id=file_id,
        sheet_name=sheet_name,
        cell_range=cell_range,
    )


def _defined_name_target(
    definition: str,
    *,
    start: int,
    end: int,
    budget: _DefinedNameTargetBudget,
) -> str | None:
    """Return one trimmed target after reserving its allocation."""
    while start < end and definition[start].isspace():
        start += 1
    while end > start and definition[end - 1].isspace():
        end -= 1
    if start == end:
        return None
    budget.reserve()
    return definition[start:end]


def _split_defined_name_targets(
    definition: str,
    *,
    budget: _DefinedNameTargetBudget,
) -> tuple[str, ...]:
    targets: list[str] = []
    quoted = False
    start = 0
    index = 0
    while index < len(definition):
        character = definition[index]
        if character == "'":
            if quoted and index + 1 < len(definition) and definition[index + 1] == "'":
                index += 2
                continue
            quoted = not quoted
        if character == "," and not quoted:
            target = _defined_name_target(
                definition,
                start=start,
                end=index,
                budget=budget,
            )
            if target is not None:
                targets.append(target)
            start = index + 1
        index += 1
    target = _defined_name_target(
        definition,
        start=start,
        end=len(definition),
        budget=budget,
    )
    if target is not None:
        targets.append(target)
    return tuple(targets)


def _unquote_sheet_name(value: str) -> str:
    if value.startswith("'") and value.endswith("'"):
        return value[1:-1].replace("''", "'")
    return value


def _defined_range(
    target: str,
    *,
    file_id: str,
    sheet_names: set[str],
) -> ExcelSourceReference | None:
    match = _DEFINED_RANGE.fullmatch(target)
    if match is None:
        return None
    sheet_name = _unquote_sheet_name(match.group("sheet"))
    if sheet_name not in sheet_names:
        return None
    cell_range = normalize_excel_range(match.group("range").replace("$", ""))
    return _source(file_id, sheet_name, cell_range)


def _defined_name_scope(
    element: Element,
    sheets: tuple[_SheetRecord, ...],
) -> str | None:
    local_sheet_id = element.attrib.get("localSheetId")
    if local_sheet_id is None:
        return None
    if not local_sheet_id.isdigit():
        msg = "Workbook defined-name scope is invalid"
        raise ValueError(msg)
    index = int(local_sheet_id)
    if index >= len(sheets):
        msg = "Workbook defined-name scope is outside sheet bounds"
        raise ValueError(msg)
    return sheets[index].name


def _defined_name_kind(
    *,
    name: str,
    definition: str,
    external: bool,
    destination_count: int,
    target_count: int,
) -> Literal["range", "constant", "formula", "external", "reserved"]:
    if external:
        return "external"
    if name.startswith("_xlnm."):
        return "reserved"
    if destination_count and destination_count == target_count:
        return "range"
    if definition.startswith('"') or definition.upper() in {"TRUE", "FALSE"}:
        return "constant"
    try:
        float(definition)
    except ValueError:
        return "formula"
    return "constant"


def _defined_names(
    workbook: Element,
    *,
    file_id: str,
    sheets: tuple[_SheetRecord, ...],
) -> tuple[DefinedNameFeature, ...]:
    sheet_names = {sheet.name for sheet in sheets}
    features: list[DefinedNameFeature] = []
    target_budget = _DefinedNameTargetBudget()
    for element in workbook.iter():
        if _local_name(element.tag) != "definedName":
            continue
        name = element.attrib.get("name")
        if not name:
            continue
        if len(features) >= _MAX_DEFINED_NAMES:
            raise ExcelPackageLimitError(
                limit_name="defined_names",
                observed=len(features) + 1,
                maximum=_MAX_DEFINED_NAMES,
            )
        definition = (element.text or "").strip()
        normalized_definition = definition.casefold()
        external = (
            _EXTERNAL_DEFINED_NAME_REFERENCE.search(definition) is not None
            or "file://" in normalized_definition
            or normalized_definition.startswith(("http://", "https://"))
        )
        targets = _split_defined_name_targets(definition, budget=target_budget)
        destinations = (
            ()
            if external
            else tuple(
                destination
                for target in targets
                if (
                    destination := _defined_range(
                        target,
                        file_id=file_id,
                        sheet_names=sheet_names,
                    )
                )
                is not None
            )
        )
        kind = _defined_name_kind(
            name=name,
            definition=definition,
            external=external,
            destination_count=len(destinations),
            target_count=len(targets),
        )
        features.append(
            DefinedNameFeature(
                name=name,
                scope=_defined_name_scope(element, sheets),
                kind=kind,
                definition=None,
                destinations=destinations,
                external_reference=external,
                fillable=kind == "range" and len(destinations) == 1,
            )
        )
    return tuple(features)


def _apply_print_names(
    workbook: Element,
    *,
    facts_by_name: dict[str, _WorksheetFacts],
) -> None:
    target_budget = _DefinedNameTargetBudget()
    for element in workbook.iter():
        if _local_name(element.tag) != "definedName":
            continue
        name = element.attrib.get("name", "")
        if name not in {"_xlnm.Print_Area", "_xlnm.Print_Titles"}:
            continue
        definition = (element.text or "").strip()
        for target in _split_defined_name_targets(
            definition,
            budget=target_budget,
        ):
            range_match = _DEFINED_RANGE.fullmatch(target)
            row_match = _PRINT_ROWS.fullmatch(target)
            column_match = _PRINT_COLUMNS.fullmatch(target)
            match = range_match or row_match or column_match
            if match is None:
                continue
            sheet_name = _unquote_sheet_name(match.group("sheet"))
            facts = facts_by_name.get(sheet_name)
            if facts is None:
                continue
            if name == "_xlnm.Print_Area" and range_match is not None:
                cell_range = normalize_excel_range(
                    range_match.group("range").replace("$", "")
                )
                facts.print_area.append(cell_range)
            elif row_match is not None:
                facts.print_title_rows = (
                    f"{row_match.group('start')}:{row_match.group('end')}"
                )
            elif column_match is not None:
                facts.print_title_columns = (
                    f"{column_match.group('start').upper()}:"
                    f"{column_match.group('end').upper()}"
                )


def _unsupported_sheet(sheet: _SheetRecord) -> UnsupportedSheetFeature:
    sheet_type: UnsupportedSheetType = (
        "unknown" if sheet.sheet_type == "worksheet" else sheet.sheet_type
    )
    return UnsupportedSheetFeature(
        name=sheet.name,
        sheet_type=sheet_type,
        visibility=sheet.visibility,
    )


def _calculation_mode(
    workbook: Element,
) -> Literal["auto", "autoNoTable", "manual"] | None:
    calculation = _first_descendant(workbook, "calcPr")
    if calculation is None:
        return None
    value = calculation.attrib.get("calcMode")
    if value == "auto":
        return "auto"
    if value == "autoNoTable":
        return "autoNoTable"
    if value == "manual":
        return "manual"
    return None


def _workbook_protection_present(workbook: Element) -> bool:
    protection = _first_descendant(workbook, "workbookProtection")
    if protection is None:
        return False
    lock_attributes = {"lockStructure", "lockWindows", "lockRevision"}
    if any(
        protection.attrib.get(name, "").lower() in {"1", "true"}
        for name in lock_attributes
    ):
        return True
    return any(
        bool(value)
        for name, value in protection.attrib.items()
        if name not in lock_attributes
    )


def _active_x_count(names: tuple[str, ...]) -> int:
    controls = {
        PurePosixPath(name).stem.lower()
        for name in names
        if name.lower().startswith("xl/activex/")
        and name.lower().endswith((".xml", ".bin"))
        and "/_rels/" not in name.lower()
    }
    return len(controls)


def _part_risk_category(name: str) -> str | None:
    prefix_categories = (
        (("customxml/",), "custom_xml"),
        (("xl/embeddings/",), "embedded_objects"),
        (("xl/ctrlprops/",), "control_properties"),
        (("xl/slicers/", "xl/slicercaches/"), "slicer_content"),
        (("xl/pivot",), "pivot_content"),
        (("xl/threadedcomments/",), "threaded_comments"),
        (("xl/webextensions/",), "web_extensions"),
        (("xl/querytables/",), "query_tables"),
        (("customui/",), "custom_ui"),
    )
    if name == "xl/connections.xml":
        return "connections"
    if name.endswith("vbaprojectsignature.bin"):
        return "vba_signature"
    return next(
        (
            category
            for prefixes, category in prefix_categories
            if name.startswith(prefixes)
        ),
        None,
    )


def _unknown_package_parts(names: tuple[str, ...]) -> tuple[str, ...]:
    categories: set[str] = set()
    for name in names:
        lowered = name.lower()
        category = _part_risk_category(lowered)
        if category is not None:
            categories.add(category)
        elif not _is_known_part(lowered):
            categories.add("unrecognized_package_part")
    return tuple(sorted(categories))


def _is_known_part(name: str) -> bool:
    exact = {
        "[content_types].xml",
        "_rels/.rels",
        "xl/workbook.xml",
        "xl/_rels/workbook.xml.rels",
        "xl/styles.xml",
        "xl/sharedstrings.xml",
        "xl/metadat.xml",
        "xl/metadata.xml",
        "xl/calcchain.xml",
        "xl/vbaproject.bin",
    }
    prefixes = (
        "docprops/",
        "xl/theme/",
        "xl/worksheets/",
        "xl/chartsheets/",
        "xl/dialogsheets/",
        "xl/macrosheets/",
        "xl/tables/",
        "xl/drawings/",
        "xl/charts/",
        "xl/media/",
        "xl/comments",
        "xl/persons/",
        "xl/externallinks/",
        "xl/printersettings/",
        "xl/activex/",
    )
    return name in exact or name.startswith(prefixes)

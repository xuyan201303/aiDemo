"""Selective package state used only by bounded workbook comparison."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from hashlib import sha256
from typing import TYPE_CHECKING

from document_sdk.core._excel_coordinates import (
    MAX_EXCEL_COLUMN,
    MAX_EXCEL_ROW,
    excel_column_letter,
)
from document_sdk.excel._comparison_common import _range_selected
from document_sdk.excel._package import _SafePackage
from document_sdk.excel._package_security import (
    _attribute_by_local_name,
    _first_descendant,
    _local_name,
    _relationship_part,
    _relationships,
)
from document_sdk.excel._package_types import _SheetRecord, _WorksheetFacts
from document_sdk.excel._package_workbook import (
    _defined_names,
    _source,
    _workbook_records,
)
from document_sdk.excel._package_worksheet import (
    _normalize_feature_range,
    _normalized_sqref,
    _sqref_reference_count,
)
from document_sdk.excel._worksheet_xml import _worksheet_events
from document_sdk.excel.errors import ExcelPackageLimitError
from document_sdk.excel.models import (
    ColumnWidthFeature,
    ExcelTableFeature,
    LocatedWorkbookFeature,
    RowHeightFeature,
)

if TYPE_CHECKING:
    from pathlib import Path
    from xml.etree.ElementTree import Element

    from document_sdk.core import FileDescriptor
    from document_sdk.core._excel_coordinates import ExcelRangeBounds
    from document_sdk.excel.models import (
        DefinedNameFeature,
        WorksheetFeatureInventory,
    )


@dataclass(frozen=True, slots=True)
class _WorkbookComparisonIndex:
    """Workbook metadata that does not require loading worksheet cells."""

    sheet_names: tuple[str, ...]
    sheets: tuple[_SheetRecord, ...]
    defined_names: tuple[DefinedNameFeature, ...]
    defined_name_signatures: dict[tuple[str, str], str]
    style_fingerprints: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class _WorksheetComparisonState:
    """Selected worksheet state without third-party worksheet objects."""

    inventory: WorksheetFeatureInventory
    hyperlinks: dict[str, str]
    comments: dict[str, str]
    validations: dict[str, str]
    tables: dict[str, tuple[str, ...]]


@dataclass(frozen=True, slots=True)
class _RelationshipState:
    """Non-reversible relationship comparison state."""

    external: bool
    fingerprint: str


_MAX_COMPARISON_FEATURE_RECORDS = 100_000
_MAX_COMPARISON_STYLE_RECORDS = 100_000


@dataclass(slots=True)
class _FeatureRecordBudget:
    """Bound materialized worksheet comparison feature state."""

    observed: int = 0

    def reserve(self, additional: int) -> None:
        """Reject feature expansion before appending records."""
        self.observed += additional
        if self.observed > _MAX_COMPARISON_FEATURE_RECORDS:
            raise ExcelPackageLimitError(
                limit_name="comparison_feature_records",
                observed=self.observed,
                maximum=_MAX_COMPARISON_FEATURE_RECORDS,
            )


def _fingerprint(value: object) -> str:
    """Return a deterministic non-reversible state fingerprint."""
    return sha256(repr(value).encode("utf-8")).hexdigest()


def _canonical_element(element: Element) -> tuple[object, ...]:
    """Normalize an XML subtree independently of namespace and attribute order."""
    return (
        _local_name(element.tag),
        tuple(
            sorted((_local_name(name), value) for name, value in element.attrib.items())
        ),
        (element.text or "").strip(),
        tuple(_canonical_element(child) for child in element),
    )


def _container_children(
    root: Element,
    *,
    container_name: str,
    child_name: str,
) -> tuple[Element, ...]:
    container = _first_descendant(root, container_name)
    if container is None:
        return ()
    children = tuple(
        child for child in container if _local_name(child.tag) == child_name
    )
    if len(children) > _MAX_COMPARISON_STYLE_RECORDS:
        raise ExcelPackageLimitError(
            limit_name="comparison_style_records",
            observed=len(children),
            maximum=_MAX_COMPARISON_STYLE_RECORDS,
        )
    return children


def _component(
    elements: tuple[tuple[object, ...], ...],
    index_text: str | None,
) -> tuple[object, ...]:
    index = int(index_text or "0")
    if index < 0 or index >= len(elements):
        return ("missing", index)
    return elements[index]


def _number_format_state(
    custom_formats: dict[int, str],
    value: str | None,
) -> tuple[str, str | int]:
    number_format_id = int(value or "0")
    from openpyxl.styles.numbers import BUILTIN_FORMATS

    format_code = custom_formats.get(
        number_format_id,
        BUILTIN_FORMATS.get(number_format_id),
    )
    if format_code is not None:
        return "code", format_code
    return "builtin", number_format_id


def _xf_state(
    element: Element,
    *,
    fonts: tuple[tuple[object, ...], ...],
    fills: tuple[tuple[object, ...], ...],
    borders: tuple[tuple[object, ...], ...],
    custom_formats: dict[int, str],
) -> tuple[object, ...]:
    ignored = {"fontId", "fillId", "borderId", "numFmtId", "xfId"}
    return (
        _component(fonts, element.attrib.get("fontId")),
        _component(fills, element.attrib.get("fillId")),
        _component(borders, element.attrib.get("borderId")),
        _number_format_state(custom_formats, element.attrib.get("numFmtId")),
        tuple(
            sorted(
                (_local_name(name), value)
                for name, value in element.attrib.items()
                if _local_name(name) not in ignored
            )
        ),
        tuple(_canonical_element(child) for child in element),
    )


def _style_member(package: _SafePackage) -> str | None:
    """Resolve the declared stylesheet while retaining the legacy absent default."""
    styles = tuple(
        relationship
        for relationship in _relationships(package, "xl/workbook.xml").values()
        if relationship.relationship_type.rsplit("/", 1)[-1] == "styles"
    )
    if len(styles) > 1 or (styles and styles[0].external):
        msg = "Workbook contains an invalid styles relationship"
        raise ValueError(msg)
    member = styles[0].target if styles else "xl/styles.xml"
    if member is None:
        msg = "Workbook styles relationship has no internal target"
        raise ValueError(msg)
    if not styles and not package.has(member):
        return None
    return member


def _style_fingerprints(package: _SafePackage) -> tuple[str, ...]:
    """Resolve indexed cell styles to stable semantic fingerprints."""
    member = _style_member(package)
    if member is None:
        return (_fingerprint(("default-style",)),)
    root = package.read_xml(member)
    fonts = tuple(
        _canonical_element(element)
        for element in _container_children(
            root,
            container_name="fonts",
            child_name="font",
        )
    )
    fills = tuple(
        _canonical_element(element)
        for element in _container_children(
            root,
            container_name="fills",
            child_name="fill",
        )
    )
    borders = tuple(
        _canonical_element(element)
        for element in _container_children(
            root,
            container_name="borders",
            child_name="border",
        )
    )
    custom_formats: dict[int, str] = {}
    for element in _container_children(
        root,
        container_name="numFmts",
        child_name="numFmt",
    ):
        if "numFmtId" not in element.attrib or "formatCode" not in element.attrib:
            continue
        identifier = int(element.attrib["numFmtId"])
        if identifier in custom_formats:
            msg = "Workbook styles contain duplicate number formats"
            raise ValueError(msg)
        custom_formats[identifier] = element.attrib["formatCode"]
    named_xfs = _container_children(
        root,
        container_name="cellStyleXfs",
        child_name="xf",
    )
    named_states = tuple(
        _xf_state(
            element,
            fonts=fonts,
            fills=fills,
            borders=borders,
            custom_formats=custom_formats,
        )
        for element in named_xfs
    )
    cell_xfs = _container_children(
        root,
        container_name="cellXfs",
        child_name="xf",
    )
    fingerprints: list[str] = []
    for element in cell_xfs:
        base_id = int(element.attrib.get("xfId", "0"))
        base_state: object = (
            named_states[base_id]
            if 0 <= base_id < len(named_states)
            else ("missing-base-style", base_id)
        )
        fingerprints.append(
            _fingerprint(
                (
                    _xf_state(
                        element,
                        fonts=fonts,
                        fills=fills,
                        borders=borders,
                        custom_formats=custom_formats,
                    ),
                    base_state,
                )
            )
        )
    return tuple(fingerprints) or (_fingerprint(("default-style",)),)


def _defined_name_signatures(
    workbook: Element,
    sheets: tuple[_SheetRecord, ...],
) -> dict[tuple[str, str], str]:
    """Hash full defined-name behavior without exposing raw definitions."""
    signatures: dict[tuple[str, str], str] = {}
    for element in workbook.iter():
        if _local_name(element.tag) != "definedName":
            continue
        name = element.attrib.get("name")
        if not name:
            continue
        local_sheet_id = element.attrib.get("localSheetId")
        scope = ""
        if local_sheet_id is not None and local_sheet_id.isdigit():
            index = int(local_sheet_id)
            if index < len(sheets):
                scope = sheets[index].name
        key = (scope, name)
        if key in signatures:
            msg = "Workbook contains duplicate defined names"
            raise ValueError(msg)
        signatures[key] = _fingerprint(
            (
                (element.text or "").strip(),
                tuple(
                    sorted(
                        (_local_name(attribute), value)
                        for attribute, value in element.attrib.items()
                        if _local_name(attribute) not in {"name", "localSheetId"}
                    )
                ),
            )
        )
    return signatures


def _comparison_workbook_index(
    path: Path,
    *,
    descriptor: FileDescriptor,
) -> _WorkbookComparisonIndex:
    """Read workbook-global comparison state without opening worksheet XML."""
    with _SafePackage(path) as package:
        package.verify_fingerprint(descriptor.fingerprint.value)
        workbook, sheets = _workbook_records(package)
        return _WorkbookComparisonIndex(
            sheet_names=tuple(sheet.name for sheet in sheets),
            sheets=sheets,
            defined_names=_defined_names(
                workbook,
                file_id=descriptor.file_id,
                sheets=sheets,
            ),
            defined_name_signatures=_defined_name_signatures(workbook, sheets),
            style_fingerprints=_style_fingerprints(package),
        )


def _relationship_states(
    package: _SafePackage,
    source_part: str,
) -> dict[str, _RelationshipState]:
    """Hash relationship targets without retaining or returning their values."""
    part = _relationship_part(source_part)
    if not package.has(part):
        return {}
    root = package.read_xml(part)
    result: dict[str, _RelationshipState] = {}
    seen_identifiers: set[str] = set()
    for element in root.iter():
        if _local_name(element.tag) != "Relationship":
            continue
        identifier = element.attrib.get("Id")
        target = element.attrib.get("Target")
        if not identifier:
            continue
        if identifier in seen_identifiers:
            msg = "Worksheet relationships contain a duplicate identifier"
            raise ValueError(msg)
        seen_identifiers.add(identifier)
        if target is None:
            continue
        external = element.attrib.get("TargetMode") == "External"
        result[identifier] = _RelationshipState(
            external=external,
            fingerprint=_fingerprint(
                (
                    element.attrib.get("Type"),
                    "external" if external else "internal",
                    target,
                )
            ),
        )
    return result


def _selected_row(row: int, ranges: tuple[ExcelRangeBounds, ...]) -> bool:
    return not ranges or any(item.min_row <= row <= item.max_row for item in ranges)


def _selected_column(
    column: int,
    ranges: tuple[ExcelRangeBounds, ...],
) -> bool:
    return not ranges or any(
        item.min_column <= column <= item.max_column for item in ranges
    )


def _apply_row_attributes(
    attributes: dict[str, str],
    *,
    row: int,
    facts: _WorksheetFacts,
    budget: _FeatureRecordBudget,
) -> None:
    if attributes.get("hidden") in {"1", "true", "on"}:
        budget.reserve(1)
        facts.hidden_rows.append(row)
    height_text = attributes.get("ht")
    if height_text is not None and (height := float(height_text)) > 0:
        budget.reserve(1)
        facts.row_heights.append(RowHeightFeature(row=row, height=height))


def _apply_column_attributes(
    attributes: dict[str, str],
    *,
    facts: _WorksheetFacts,
    ranges: tuple[ExcelRangeBounds, ...],
    budget: _FeatureRecordBudget,
) -> None:
    minimum = int(attributes.get("min", "0"))
    maximum = int(attributes.get("max", "0"))
    if minimum < 1 or maximum < minimum or maximum > MAX_EXCEL_COLUMN:
        msg = "Workbook column metadata is outside Excel bounds"
        raise ValueError(msg)
    width_text = attributes.get("width")
    for column_number in range(minimum, maximum + 1):
        if not _selected_column(column_number, ranges):
            continue
        column = excel_column_letter(column_number)
        if attributes.get("hidden") in {"1", "true", "on"}:
            budget.reserve(1)
            facts.hidden_columns.append(column)
        if width_text is not None and (width := float(width_text)) > 0:
            budget.reserve(1)
            facts.column_widths.append(ColumnWidthFeature(column=column, width=width))


def _boolean_behavior(attributes: dict[str, str], name: str) -> str:
    return (
        "true"
        if attributes.get(name, "").casefold() in {"1", "true", "on"}
        else "false"
    )


def _validation_signature(
    attributes: dict[str, str],
    formulas: dict[str, str],
) -> str:
    """Hash complete data-validation behavior, including user-facing messages."""
    return _fingerprint(
        (
            attributes.get("type"),
            attributes.get("operator"),
            formulas.get("formula1"),
            formulas.get("formula2"),
            _boolean_behavior(attributes, "allowBlank"),
            _boolean_behavior(attributes, "showDropDown"),
            _boolean_behavior(attributes, "showErrorMessage"),
            _boolean_behavior(attributes, "showInputMessage"),
            attributes.get("errorStyle"),
            attributes.get("errorTitle"),
            attributes.get("error"),
            attributes.get("promptTitle"),
            attributes.get("prompt"),
            attributes.get("imeMode"),
        )
    )


def _collapse_states(states: dict[str, list[str]]) -> dict[str, str]:
    """Collapse duplicate feature locations without order-dependent overwrites."""
    return {
        reference: _fingerprint(tuple(sorted(fingerprints)))
        for reference, fingerprints in states.items()
    }


def _collapse_hyperlinks(states: dict[str, list[str]]) -> dict[str, str]:
    """Retain only target class plus a non-reversible combined fingerprint."""
    collapsed: dict[str, str] = {}
    for reference, values in states.items():
        target_classes = {value.split(":", 1)[0] for value in values}
        target_class = (
            next(iter(target_classes)) if len(target_classes) == 1 else "mixed"
        )
        collapsed[reference] = f"{target_class}:{_fingerprint(tuple(sorted(values)))}"
    return collapsed


def _stream_worksheet_state(  # noqa: C901, PLR0912, PLR0913, PLR0915
    package: _SafePackage,
    *,
    sheet: _SheetRecord,
    facts: _WorksheetFacts,
    file_id: str,
    ranges: tuple[ExcelRangeBounds, ...],
    relationship_states: dict[str, _RelationshipState],
    budget: _FeatureRecordBudget,
) -> tuple[dict[str, str], dict[str, str]]:
    """Stream selected layout, validation, and hyperlink state."""
    if sheet.part_name is None:
        msg = "Worksheet package part is missing"
        raise ValueError(msg)
    hyperlink_groups: dict[str, list[str]] = defaultdict(list)
    validation_groups: dict[str, list[str]] = defaultdict(list)
    current_validation: dict[str, str] | None = None
    current_formulas: dict[str, str] = {}
    previous_row = 0
    current_row: int | None = None
    stack: list[Element] = []

    with package.open_xml_stream(sheet.part_name) as stream:
        for event, element, event_name in _worksheet_events(stream):
            local_name = event_name
            if (
                not event_name
                and element.tag.startswith(
                    "{http://schemas.microsoft.com/office/spreadsheetml/2009/9/main}"
                )
                and _local_name(element.tag)
                in {"dataValidation", "formula1", "formula2"}
            ):
                local_name = _local_name(element.tag)
            if event == "start":
                stack.append(element)
                if local_name == "row":
                    row_text = element.attrib.get("r")
                    current_row = (
                        previous_row + 1 if row_text is None else int(row_text)
                    )
                    if (
                        current_row < 1
                        or current_row > MAX_EXCEL_ROW
                        or current_row <= previous_row
                    ):
                        msg = "Worksheet rows are not in deterministic bounds"
                        raise ValueError(msg)
                    if _selected_row(current_row, ranges):
                        _apply_row_attributes(
                            element.attrib,
                            row=current_row,
                            facts=facts,
                            budget=budget,
                        )
                elif local_name == "dataValidation":
                    current_validation = dict(element.attrib)
                    current_formulas = {}
                continue

            if (
                local_name in {"formula1", "formula2"}
                and current_validation is not None
            ):
                current_formulas[local_name] = element.text or ""
            elif local_name == "dataValidation":
                if current_validation is None:
                    msg = "Worksheet validation state is invalid"
                    raise ValueError(msg)
                signature = _validation_signature(
                    current_validation,
                    current_formulas,
                )
                sqref = current_validation.get("sqref")
                budget.reserve(_sqref_reference_count(sqref))
                for reference in _normalized_sqref(sqref):
                    if not _range_selected(reference, ranges):
                        continue
                    validation_groups[reference].append(signature)
                    facts.data_validations.append(
                        LocatedWorkbookFeature(
                            feature_type="data_validation",
                            source=_source(file_id, facts.name, reference),
                            details=current_validation.get("type") or "custom",
                        )
                    )
                current_validation = None
                current_formulas = {}
            elif local_name == "hyperlink":
                reference_text = element.attrib.get("ref")
                if reference_text:
                    reference = _normalize_feature_range(reference_text)
                    if _range_selected(reference, ranges):
                        relationship_id = _attribute_by_local_name(element, "id")
                        relationship = relationship_states.get(relationship_id or "")
                        target_class = (
                            "external"
                            if relationship is not None and relationship.external
                            else "internal"
                        )
                        signature = _fingerprint(
                            (
                                relationship.fingerprint
                                if relationship is not None
                                else None,
                                element.attrib.get("location"),
                                element.attrib.get("tooltip"),
                                element.attrib.get("display"),
                            )
                        )
                        anchor = reference.split(":", 1)[0]
                        budget.reserve(1)
                        hyperlink_groups[anchor].append(f"{target_class}:{signature}")
                        facts.hyperlinks.append(
                            LocatedWorkbookFeature(
                                feature_type="hyperlink",
                                source=_source(
                                    file_id,
                                    facts.name,
                                    reference,
                                ),
                                details=target_class,
                            )
                        )
            elif local_name == "pane":
                top_left = element.attrib.get("topLeftCell")
                if (
                    element.attrib.get("state") in {"frozen", "frozenSplit"}
                    and top_left is not None
                ):
                    facts.freeze_panes = _normalize_feature_range(top_left)
            elif local_name == "mergeCell":
                reference_text = element.attrib.get("ref")
                if reference_text:
                    reference = _normalize_feature_range(reference_text)
                    if _range_selected(reference, ranges):
                        budget.reserve(1)
                        facts.merged_ranges.append(reference)
            elif local_name == "col":
                _apply_column_attributes(
                    element.attrib,
                    facts=facts,
                    ranges=ranges,
                    budget=budget,
                )
            elif local_name == "pageSetup":
                orientation = element.attrib.get("orientation")
                if orientation == "portrait":
                    facts.page_orientation = "portrait"
                elif orientation == "landscape":
                    facts.page_orientation = "landscape"
            elif local_name == "row":
                if current_row is None:
                    msg = "Worksheet row state is invalid"
                    raise ValueError(msg)
                previous_row = current_row
                current_row = None

            if not stack or stack[-1] is not element:
                msg = "Worksheet XML element stack is invalid"
                raise ValueError(msg)
            if len(stack) > 1:
                stack[-2].remove(element)
            element.clear()
            stack.pop()

    return _collapse_hyperlinks(hyperlink_groups), _collapse_states(validation_groups)


def _comment_states(  # noqa: PLR0913 - explicit state keeps parsing auditable.
    package: _SafePackage,
    *,
    sheet: _SheetRecord,
    facts: _WorksheetFacts,
    file_id: str,
    ranges: tuple[ExcelRangeBounds, ...],
    budget: _FeatureRecordBudget,
) -> dict[str, str]:
    if sheet.part_name is None:
        return {}
    groups: dict[str, list[str]] = defaultdict(list)
    for relationship in _relationships(package, sheet.part_name).values():
        if (
            relationship.target is None
            or relationship.relationship_type.rsplit("/", 1)[-1] != "comments"
        ):
            continue
        root = package.read_xml(relationship.target)
        authors = tuple(
            element.text or ""
            for element in root.iter()
            if _local_name(element.tag) == "author"
        )
        for element in root.iter():
            if _local_name(element.tag) != "comment":
                continue
            reference_text = element.attrib.get("ref")
            if not reference_text:
                continue
            reference = _normalize_feature_range(reference_text)
            if not _range_selected(reference, ranges):
                continue
            author_id = int(element.attrib.get("authorId", "-1"))
            author = authors[author_id] if 0 <= author_id < len(authors) else ""
            text = "".join(
                descendant.text or ""
                for descendant in element.iter()
                if _local_name(descendant.tag) == "t"
            )
            budget.reserve(1)
            groups[reference].append(_fingerprint((author, text)))
            facts.comments.append(
                LocatedWorkbookFeature(
                    feature_type="comment",
                    source=_source(file_id, facts.name, reference),
                )
            )
    return _collapse_states(groups)


def _table_states(  # noqa: PLR0913 - explicit state keeps parsing auditable.
    package: _SafePackage,
    *,
    sheet: _SheetRecord,
    facts: _WorksheetFacts,
    file_id: str,
    ranges: tuple[ExcelRangeBounds, ...],
    budget: _FeatureRecordBudget,
) -> dict[str, tuple[str, ...]]:
    if sheet.part_name is None:
        return {}
    states: dict[str, tuple[str, ...]] = {}
    for relationship in _relationships(package, sheet.part_name).values():
        if (
            relationship.target is None
            or relationship.relationship_type.rsplit("/", 1)[-1] != "table"
        ):
            continue
        root = package.read_xml(relationship.target)
        reference_text = root.attrib.get("ref")
        name = root.attrib.get("name")
        display_name = root.attrib.get("displayName")
        if not reference_text or not name or not display_name:
            continue
        reference = _normalize_feature_range(reference_text)
        if not _range_selected(reference, ranges):
            continue
        style = _first_descendant(root, "tableStyleInfo")
        style_state = (
            ()
            if style is None
            else tuple(
                sorted(
                    (
                        _local_name(attribute),
                        (
                            _boolean_behavior(style.attrib, _local_name(attribute))
                            if _local_name(attribute).startswith("show")
                            else value
                        ),
                    )
                    for attribute, value in style.attrib.items()
                )
            )
        )
        state = (display_name, reference, _fingerprint(style_state))
        if name in states:
            msg = "Worksheet contains duplicate table names"
            raise ValueError(msg)
        budget.reserve(1)
        states[name] = state
        facts.tables.append(
            ExcelTableFeature(
                name=name,
                display_name=display_name,
                cell_range=reference,
                source=_source(file_id, facts.name, reference),
            )
        )
    return states


def _selected_worksheet_states(
    path: Path,
    *,
    descriptor: FileDescriptor,
    index: _WorkbookComparisonIndex,
    sheet_names: tuple[str, ...],
    selected_ranges: dict[str, tuple[ExcelRangeBounds, ...]],
) -> dict[str, _WorksheetComparisonState]:
    """Load only selected worksheet parts after sparse cell bounds pass."""
    requested = set(sheet_names)
    records = {
        sheet.name: sheet
        for sheet in index.sheets
        if sheet.name in requested and sheet.sheet_type == "worksheet"
    }
    result: dict[str, _WorksheetComparisonState] = {}
    with _SafePackage(path) as package:
        package.verify_fingerprint(descriptor.fingerprint.value)
        budget = _FeatureRecordBudget()
        for sheet_name in sheet_names:
            sheet = records.get(sheet_name)
            if sheet is None:
                continue
            ranges = selected_ranges.get(sheet_name, ())
            facts = _WorksheetFacts(
                name=sheet.name,
                visibility=sheet.visibility,
            )
            relationship_states = _relationship_states(package, sheet.part_name or "")
            hyperlinks, validations = _stream_worksheet_state(
                package,
                sheet=sheet,
                facts=facts,
                file_id=descriptor.file_id,
                ranges=ranges,
                relationship_states=relationship_states,
                budget=budget,
            )
            comments = _comment_states(
                package,
                sheet=sheet,
                facts=facts,
                file_id=descriptor.file_id,
                ranges=ranges,
                budget=budget,
            )
            tables = _table_states(
                package,
                sheet=sheet,
                facts=facts,
                file_id=descriptor.file_id,
                ranges=ranges,
                budget=budget,
            )
            result[sheet_name] = _WorksheetComparisonState(
                inventory=facts.to_inventory(),
                hyperlinks=hyperlinks,
                comments=comments,
                validations=validations,
                tables=tables,
            )
    return result

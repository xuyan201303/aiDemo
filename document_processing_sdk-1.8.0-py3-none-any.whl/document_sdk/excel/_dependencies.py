"""Optional Excel dependency loading."""

from importlib import import_module

from document_sdk.core import DependencyNotInstalledError
from document_sdk.core.errors import _raise_redacted_translation

EXCEL_DEPENDENCY_MESSAGE = (
    "Excel support is not installed.\n"
    "Install it with:\n"
    '  pip install "document-processing-sdk[excel]"\n'
    "or:\n"
    '  uv add "document-processing-sdk[excel]"'
)


def require_excel_support() -> None:
    """Raise the documented SDK error when the Excel extra is unavailable."""
    try:
        import_module("openpyxl")
    except ImportError as exc:
        _raise_redacted_translation(
            exc,
            DependencyNotInstalledError(EXCEL_DEPENDENCY_MESSAGE),
        )

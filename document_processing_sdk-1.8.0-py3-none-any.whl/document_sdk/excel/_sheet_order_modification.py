"""Package-level workbook sheet ordering with index-reference preservation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from document_sdk.excel._column_modification import (
    _copy_package,
    _direct_elements,
    _spreadsheet_element,
)
from document_sdk.excel._defined_name_preservation import (
    _defined_names,
    _workbook_document,
)
from document_sdk.excel._package import _SafePackage
from document_sdk.excel.errors import ExcelModificationError

if TYPE_CHECKING:
    from pathlib import Path
    from xml.dom.minidom import Element

    from document_sdk.excel.models import WorkbookSheetOrderPatch


_WORKBOOK_MEMBER = "xl/workbook.xml"


@dataclass(frozen=True, slots=True)
class _PendingSheetOrderChange:
    """One verified workbook order change before public file identities exist."""

    old_sheet_names: tuple[str, ...]
    new_sheet_names: tuple[str, ...]


def _sheets_container(root: Element, namespace: str) -> Element:
    matches = tuple(
        child
        for child in _direct_elements(root)
        if _spreadsheet_element(child, "sheets", namespace)
    )
    if len(matches) != 1:
        msg = "Workbook must contain one sheet container"
        raise ExcelModificationError(msg)
    return matches[0]


def _sheet_elements(container: Element, namespace: str) -> tuple[Element, ...]:
    sheets = tuple(
        child
        for child in _direct_elements(container)
        if _spreadsheet_element(child, "sheet", namespace)
    )
    names = [sheet.getAttribute("name") for sheet in sheets]
    if (
        not sheets
        or any(not name for name in names)
        or len({name.casefold() for name in names}) != len(names)
    ):
        msg = "Workbook sheet identities are invalid"
        raise ExcelModificationError(msg)
    return sheets


def _actual_order(
    sheets: tuple[Element, ...],
    requested: WorkbookSheetOrderPatch,
) -> tuple[str, ...]:
    by_identity = {sheet.getAttribute("name").casefold(): sheet for sheet in sheets}
    requested_identities = tuple(name.casefold() for name in requested.sheet_names)
    if set(requested_identities) != set(by_identity) or len(
        requested_identities
    ) != len(sheets):
        msg = "Workbook sheet order must include every existing sheet exactly once"
        raise ExcelModificationError(msg)
    return tuple(
        by_identity[identity].getAttribute("name") for identity in requested_identities
    )


def _remap_index(
    value: str, old_order: tuple[str, ...], new_order: tuple[str, ...]
) -> str:
    try:
        old_index = int(value)
        sheet_name = old_order[old_index]
    except (IndexError, ValueError):
        msg = "Workbook sheet index reference is invalid"
        raise ExcelModificationError(msg) from None
    return str(new_order.index(sheet_name))


def _remap_defined_names(
    root: Element,
    namespace: str,
    old_order: tuple[str, ...],
    new_order: tuple[str, ...],
) -> None:
    container = _defined_names(root, namespace)
    if container is None:
        return
    for element in _direct_elements(container):
        if not _spreadsheet_element(element, "definedName", namespace):
            continue
        if element.hasAttribute("localSheetId"):
            element.setAttribute(
                "localSheetId",
                _remap_index(
                    element.getAttribute("localSheetId"),
                    old_order,
                    new_order,
                ),
            )


def _remap_workbook_views(
    root: Element,
    namespace: str,
    old_order: tuple[str, ...],
    new_order: tuple[str, ...],
) -> None:
    for element in root.getElementsByTagNameNS(namespace, "workbookView"):
        for attribute in ("activeTab", "firstSheet"):
            if element.hasAttribute(attribute):
                element.setAttribute(
                    attribute,
                    _remap_index(
                        element.getAttribute(attribute),
                        old_order,
                        new_order,
                    ),
                )


def _apply_sheet_order_payload(
    payload: bytes,
    requested: WorkbookSheetOrderPatch,
) -> tuple[bytes, _PendingSheetOrderChange | None]:
    document, root, namespace = _workbook_document(payload)
    container = _sheets_container(root, namespace)
    sheets = _sheet_elements(container, namespace)
    old_order = tuple(sheet.getAttribute("name") for sheet in sheets)
    new_order = _actual_order(sheets, requested)
    if old_order == new_order:
        return payload, None
    by_name = {sheet.getAttribute("name"): sheet for sheet in sheets}
    for name in new_order:
        container.appendChild(by_name[name])
    _remap_defined_names(root, namespace, old_order, new_order)
    _remap_workbook_views(root, namespace, old_order, new_order)
    return document.toxml(encoding="utf-8"), _PendingSheetOrderChange(
        old_sheet_names=old_order,
        new_sheet_names=new_order,
    )


def _workbook_order(path: Path) -> tuple[str, ...]:
    with (
        _SafePackage(path) as package,
        package.open_xml_stream(_WORKBOOK_MEMBER) as stream,
    ):
        _document, root, namespace = _workbook_document(stream.read())
    return tuple(
        element.getAttribute("name")
        for element in _sheet_elements(_sheets_container(root, namespace), namespace)
    )


def create_sheet_order_patch_output(
    source_path: Path,
    output_path: Path,
    patch: WorkbookSheetOrderPatch,
    *,
    source_fingerprint: str,
) -> _PendingSheetOrderChange | None:
    """Write and independently verify one complete workbook sheet ordering."""
    with _SafePackage(source_path) as package:
        package.verify_fingerprint(source_fingerprint)
        with package.open_xml_stream(_WORKBOOK_MEMBER) as stream:
            payload = stream.read()
    replacement, pending = _apply_sheet_order_payload(payload, patch)
    _copy_package(
        source_path,
        output_path,
        {} if pending is None else {_WORKBOOK_MEMBER: replacement},
        source_fingerprint=source_fingerprint,
    )
    expected = (
        pending.new_sheet_names if pending is not None else _workbook_order(source_path)
    )
    if _workbook_order(output_path) != expected:
        msg = "Patched workbook sheet-order verification failed"
        raise ExcelModificationError(msg)
    return pending

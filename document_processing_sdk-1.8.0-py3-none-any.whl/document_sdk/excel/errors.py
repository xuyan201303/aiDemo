"""Typed public errors for advanced Excel operations."""

from document_sdk.core import DocumentProcessingError, DocumentSdkError


class WorkbookPreservationError(DocumentSdkError):
    """Raised when strict preservation rejects present workbook features."""

    def __init__(
        self,
        *,
        operation: str,
        unsupported_features: tuple[str, ...],
    ) -> None:
        """Create a safe structured preservation failure."""
        self.operation = operation
        self.unsupported_features = unsupported_features
        joined = ", ".join(unsupported_features) or "unknown"
        super().__init__(
            f"Strict {operation} preservation rejected workbook features: {joined}"
        )


class ExcelModificationError(DocumentProcessingError):
    """Raised when a requested workbook modification is invalid or unsafe."""


class ExcelComparisonLimitError(DocumentSdkError):
    """Raised when comparison input exceeds its configured cell bound."""

    def __init__(self, *, observed_cells: int, max_cells: int) -> None:
        """Create a safe structured comparison limit failure."""
        self.observed_cells = observed_cells
        self.max_cells = max_cells
        super().__init__(
            f"Excel comparison observed {observed_cells} cells, "
            f"exceeding the configured maximum of {max_cells}"
        )


class UnsupportedWorkbookFeatureError(DocumentSdkError):
    """Raised for a specifically unsupported workbook feature request."""


class ExcelPackageLimitError(DocumentSdkError):
    """Raised before unsafe OOXML package expansion."""

    def __init__(self, *, limit_name: str, observed: int, maximum: int) -> None:
        """Create a safe structured OOXML package-limit failure."""
        self.limit_name = limit_name
        self.observed = observed
        self.maximum = maximum
        super().__init__(
            f"Excel package {limit_name} limit exceeded: "
            f"observed {observed}, maximum {maximum}"
        )

# ruff: noqa: BLE001, PLR0913
"""Deterministic, bounded comparison for local OOXML workbooks."""

from __future__ import annotations

from typing import TYPE_CHECKING

from document_sdk.core import DocumentProcessingError, DocumentSdkError
from document_sdk.core.errors import _raise_redacted_translation, safe_file_label
from document_sdk.excel._comparison_cells import _add_cell_differences
from document_sdk.excel._comparison_common import (
    _attach_feature_coordinates,
    _DiffCollector,
    _prepare_sheet_comparisons,
    _ranges_by_sheet,
    _selected_sheet_order,
)
from document_sdk.excel._comparison_features import (
    _add_sheet_features,
    _add_unsupported_sheet_features,
    _add_workbook_features,
)
from document_sdk.excel._comparison_package import (
    _comparison_workbook_index,
    _selected_worksheet_states,
)
from document_sdk.excel._dependencies import require_excel_support
from document_sdk.excel._helpers import revalidate_excel_model
from document_sdk.excel.models import (
    SheetDiff,
    WorkbookComparisonOptions,
    WorkbookDiff,
)
from document_sdk.excel.streaming import _inspect_streaming_input

if TYPE_CHECKING:
    from pathlib import Path

    from document_sdk.core import FileDescriptor
    from document_sdk.excel._comparison_common import _PreparedSheetComparison
    from document_sdk.excel._comparison_package import (
        _WorkbookComparisonIndex,
        _WorksheetComparisonState,
    )


def _compare_prepared_sheets(
    collector: _DiffCollector,
    *,
    prepared_sheets: tuple[_PreparedSheetComparison, ...],
    old_states: dict[str, _WorksheetComparisonState],
    new_states: dict[str, _WorksheetComparisonState],
    old_index: _WorkbookComparisonIndex,
    new_index: _WorkbookComparisonIndex,
    old_descriptor: FileDescriptor,
    new_descriptor: FileDescriptor,
    options: WorkbookComparisonOptions,
) -> None:
    """Compare bounded sparse cells with selectively loaded feature state."""
    for prepared in prepared_sheets:
        old_sheet = old_states[prepared.sheet_name]
        new_sheet = new_states[prepared.sheet_name]
        for coordinate in prepared.coordinates:
            _add_cell_differences(
                collector,
                sheet_name=prepared.sheet_name,
                coordinate=coordinate,
                old_record=prepared.old_cells.get(coordinate),
                new_record=prepared.new_cells.get(coordinate),
                old_sheet=old_sheet,
                new_sheet=new_sheet,
                old_style_fingerprints=old_index.style_fingerprints,
                new_style_fingerprints=new_index.style_fingerprints,
                old_descriptor=old_descriptor,
                new_descriptor=new_descriptor,
                options=options,
            )
        _add_sheet_features(
            collector,
            sheet_name=prepared.sheet_name,
            old_sheet=old_sheet,
            new_sheet=new_sheet,
            old_descriptor=old_descriptor,
            new_descriptor=new_descriptor,
            ranges=prepared.ranges,
        )


def _compare_workbooks(
    old_path: Path,
    new_path: Path,
    *,
    old_descriptor: FileDescriptor,
    new_descriptor: FileDescriptor,
    options: WorkbookComparisonOptions,
) -> WorkbookDiff:
    """Perform comparison after public input validation."""
    old_index = _comparison_workbook_index(
        old_path,
        descriptor=old_descriptor,
    )
    new_index = _comparison_workbook_index(
        new_path,
        descriptor=new_descriptor,
    )
    sheet_order = _selected_sheet_order(
        old_index.sheet_names,
        new_index.sheet_names,
        options,
    )
    selected_ranges = _ranges_by_sheet(options)
    old_names = set(old_index.sheet_names)
    new_names = set(new_index.sheet_names)
    collector = _DiffCollector(options.max_differences)
    for name in sheet_order:
        if name in old_names and name not in new_names:
            collector.add_sheet(name, added=False)
        elif name in new_names and name not in old_names:
            collector.add_sheet(name, added=True)

    scope = set(sheet_order)
    scoped_old_order = tuple(name for name in old_index.sheet_names if name in scope)
    scoped_new_order = tuple(name for name in new_index.sheet_names if name in scope)
    _add_unsupported_sheet_features(
        collector,
        sheet_order=sheet_order,
        old_sheets=old_index.sheets,
        new_sheets=new_index.sheets,
    )

    old_worksheets = {
        item.name for item in old_index.sheets if item.sheet_type == "worksheet"
    }
    new_worksheets = {
        item.name for item in new_index.sheets if item.sheet_type == "worksheet"
    }
    common_sheets = old_worksheets & new_worksheets
    prepared_sheets = _prepare_sheet_comparisons(
        old_path=old_path,
        new_path=new_path,
        sheet_order=sheet_order,
        selected_ranges=selected_ranges,
        common_sheets=common_sheets,
        old_descriptor=old_descriptor,
        new_descriptor=new_descriptor,
        options=options,
    )

    prepared_names = tuple(item.sheet_name for item in prepared_sheets)
    old_states = _selected_worksheet_states(
        old_path,
        descriptor=old_descriptor,
        index=old_index,
        sheet_names=prepared_names,
        selected_ranges=selected_ranges,
    )
    new_states = _selected_worksheet_states(
        new_path,
        descriptor=new_descriptor,
        index=new_index,
        sheet_names=prepared_names,
        selected_ranges=selected_ranges,
    )
    if set(old_states) != set(prepared_names) or set(new_states) != set(prepared_names):
        msg = "Workbook comparison worksheet state is unavailable"
        raise DocumentProcessingError(msg)
    prepared_sheets = _attach_feature_coordinates(
        prepared_sheets,
        old_states=old_states,
        new_states=new_states,
        max_cells=options.max_cells,
    )
    _add_workbook_features(
        collector,
        old_names=scoped_old_order,
        new_names=scoped_new_order,
        old_defined_names=old_index.defined_names,
        new_defined_names=new_index.defined_names,
        old_name_signatures=old_index.defined_name_signatures,
        new_name_signatures=new_index.defined_name_signatures,
    )
    _compare_prepared_sheets(
        collector,
        prepared_sheets=prepared_sheets,
        old_states=old_states,
        new_states=new_states,
        old_index=old_index,
        new_index=new_index,
        old_descriptor=old_descriptor,
        new_descriptor=new_descriptor,
        options=options,
    )

    sheet_diffs = tuple(
        SheetDiff(
            sheet_name=name,
            cell_diffs=tuple(collector.sheets[name].cell_diffs),
            feature_diffs=tuple(collector.sheets[name].feature_diffs),
        )
        for name in sheet_order
        if name in collector.sheets
    )
    return WorkbookDiff(
        old_file=old_descriptor,
        new_file=new_descriptor,
        sheets_added=tuple(collector.sheets_added),
        sheets_removed=tuple(collector.sheets_removed),
        sheet_diffs=sheet_diffs,
        feature_diffs=tuple(collector.workbook_features),
        difference_count=collector.count,
        truncated=collector.truncated,
    )


def compare_workbooks(
    old_path: Path,
    new_path: Path,
    *,
    options: WorkbookComparisonOptions | None = None,
) -> WorkbookDiff:
    """Compare two local XLSX/XLSM workbooks within explicit generic bounds."""
    resolved_options = (
        WorkbookComparisonOptions()
        if options is None
        else revalidate_excel_model(
            options,
            WorkbookComparisonOptions,
            "Workbook comparison options are invalid",
        )
    )
    require_excel_support()
    old_descriptor = _inspect_streaming_input(old_path)
    new_descriptor = _inspect_streaming_input(new_path)
    try:
        return _compare_workbooks(
            old_path,
            new_path,
            old_descriptor=old_descriptor,
            new_descriptor=new_descriptor,
            options=resolved_options,
        )
    except DocumentSdkError:
        raise
    except Exception as exc:
        labels = f"{safe_file_label(old_path)} and {safe_file_label(new_path)}"
        msg = f"Unable to compare workbooks: {labels}"
        _raise_redacted_translation(exc, DocumentProcessingError(msg))

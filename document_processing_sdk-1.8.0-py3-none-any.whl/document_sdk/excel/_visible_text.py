"""Internal SpreadsheetML visible rich-text choice handling."""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from xml.etree.ElementTree import Element


_SPREADSHEETML_NAMESPACES = frozenset(
    {
        "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
        "http://purl.oclc.org/ooxml/spreadsheetml/main",
    }
)


def _local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _namespace(tag: str) -> str:
    return tag[1:].split("}", 1)[0] if tag.startswith("{") else ""


@dataclass(frozen=True, slots=True)
class _VisibleText:
    """One validated visible-text projection without annotation descendants."""

    value: str
    choice_present: bool


class _VisibleTextAccumulator:
    """Validate and hash one plain-text or rich-run SpreadsheetML choice."""

    def __init__(self, *, label: str, retain_text: bool) -> None:
        self._label = label
        self._digest = sha256()
        self._parts: list[str] | None = [] if retain_text else None
        self._plain_seen = False
        self._rich_seen = False
        self._run_text_seen = False

    @property
    def choice_present(self) -> bool:
        return self._plain_seen or self._rich_seen

    def start_plain(self) -> None:
        if self._plain_seen or self._rich_seen:
            msg = f"{self._label} text choice is invalid"
            raise ValueError(msg)
        self._plain_seen = True

    def start_run(self) -> None:
        if self._plain_seen:
            msg = f"{self._label} text choice is invalid"
            raise ValueError(msg)
        self._rich_seen = True
        self._run_text_seen = False

    def start_run_text(self) -> None:
        if not self._rich_seen or self._run_text_seen:
            msg = f"{self._label} rich-text run is invalid"
            raise ValueError(msg)
        self._run_text_seen = True

    def finish_run(self) -> None:
        if not self._run_text_seen:
            msg = f"{self._label} rich-text run is invalid"
            raise ValueError(msg)

    def update(self, value: str | None) -> None:
        text = value or ""
        self._digest.update(text.encode("utf-8"))
        if self._parts is not None:
            self._parts.append(text)

    def text(self) -> str:
        if self._parts is None:
            msg = "Visible text was not retained"
            raise RuntimeError(msg)
        return "".join(self._parts)

    def hexdigest(self) -> str:
        return self._digest.hexdigest()


def _visible_text(element: Element, *, container: str, label: str) -> _VisibleText:
    """Project only direct base text or direct rich-run text from a container."""
    namespace = _namespace(element.tag)
    if (
        _local_name(element.tag) != container
        or namespace not in _SPREADSHEETML_NAMESPACES
    ):
        return _VisibleText(value="", choice_present=False)

    collector = _VisibleTextAccumulator(label=label, retain_text=True)
    for child in element:
        if _namespace(child.tag) != namespace:
            continue
        child_name = _local_name(child.tag)
        if child_name == "t":
            collector.start_plain()
            collector.update(child.text)
            continue
        if child_name != "r":
            continue
        collector.start_run()
        for run_child in child:
            if (
                _namespace(run_child.tag) == namespace
                and _local_name(run_child.tag) == "t"
            ):
                collector.start_run_text()
                collector.update(run_child.text)
        collector.finish_run()
    return _VisibleText(
        value=collector.text(),
        choice_present=collector.choice_present,
    )

"""Local Excel workbook inspection."""

from __future__ import annotations

from typing import TYPE_CHECKING

from document_sdk.core import WorkbookInspection, WorksheetInspection
from document_sdk.excel._dependencies import require_excel_support
from document_sdk.excel._helpers import (
    inspect_excel_input,
    translate_excel_errors,
    validate_excel_package_limits,
)
from document_sdk.excel._ooxml import inspect_ooxml_workbook
from document_sdk.excel._package import validate_package_nonworksheet_sheets

if TYPE_CHECKING:
    from pathlib import Path

    from document_sdk.excel.models import ExcelPackageLimits


def inspect_workbook(
    path: Path,
    *,
    package_limits: ExcelPackageLimits | None = None,
) -> WorkbookInspection:
    """Inspect local XLSX/XLSM structure without returning backend objects.

    Args:
        path: Local ``.xlsx`` or ``.xlsm`` path.
        package_limits: Optional finite OOXML expansion limits.

    Returns:
        Workbook and worksheet inspection models.
    """
    require_excel_support()
    validated_limits = validate_excel_package_limits(package_limits)
    descriptor = inspect_excel_input(path, package_limits=validated_limits)

    with translate_excel_errors(path, "inspect"):
        validate_package_nonworksheet_sheets(
            path,
            descriptor=descriptor,
            limits=validated_limits,
        )
        structure = inspect_ooxml_workbook(
            path,
            expected_fingerprint=descriptor.fingerprint.value,
        )
        worksheets = tuple(
            WorksheetInspection(
                name=worksheet.name,
                used_range=worksheet.used_range,
                max_row=worksheet.max_row,
                max_column=worksheet.max_column,
                merged_ranges=worksheet.merged_ranges,
                hidden_rows=worksheet.hidden_rows,
                hidden_columns=worksheet.hidden_columns,
                formula_cell_count=worksheet.formula_cell_count,
            )
            for worksheet in structure.worksheets
        )

    return WorkbookInspection(
        file=descriptor,
        sheet_names=structure.sheet_names,
        worksheets=worksheets,
    )

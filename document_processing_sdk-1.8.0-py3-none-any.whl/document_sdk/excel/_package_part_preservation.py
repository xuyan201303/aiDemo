"""Restore untouched opaque OOXML parts after a third-party workbook save."""

from __future__ import annotations

import posixpath
from dataclasses import dataclass
from hashlib import sha256
from typing import TYPE_CHECKING, cast
from xml.dom import minidom
from xml.etree.ElementTree import Element as EtElement
from xml.etree.ElementTree import iterparse

from document_sdk.excel._column_modification import (
    _copy_package,
    _direct_elements,
    _document_root,
)
from document_sdk.excel._package import _SafePackage
from document_sdk.excel._package_chartsheet import _chartsheet_facts
from document_sdk.excel._package_macrosheet import (
    _macro_sheet_facts,
    _relevant_defined_name_record_digests,
    _shared_string_index,
    _shared_string_table,
)
from document_sdk.excel._package_security import (
    _relationship_part,
    _relationships,
    _resolve_target,
)
from document_sdk.excel._package_workbook import (
    _is_known_part,
    _part_risk_category,
    _workbook_records,
)
from document_sdk.excel._package_worksheet import (
    _SPREADSHEETML_WORKSHEET_NAMESPACES,
)
from document_sdk.excel._staging import create_staging_path
from document_sdk.excel._structural_modification import (
    normalize_structural_insertions,
)
from document_sdk.excel.errors import ExcelModificationError
from document_sdk.excel.models import ExcelPackageLimits
from document_sdk.files import calculate_sha256

if TYPE_CHECKING:
    from collections.abc import Sequence
    from pathlib import Path
    from xml.dom.minidom import Attr, Document, Element

    from document_sdk.excel._package_macrosheet import _SharedStringTable
    from document_sdk.excel.models import (
        WorksheetCreatePatch,
        WorksheetDeletePatch,
        WorksheetDrawingRemovalPatch,
        WorksheetImagePatch,
        WorksheetStructuralInsertionPatch,
    )


_CONTENT_TYPES_MEMBER = "[Content_Types].xml"
_WORKBOOK_MEMBER = "xl/workbook.xml"
_WORKBOOK_RELATIONSHIPS_MEMBER = "xl/_rels/workbook.xml.rels"
_CONTENT_TYPES_NAMESPACE = (
    "http://schemas.openxmlformats.org/package/2006/content-types"
)
_RELATIONSHIPS_NAMESPACE = (
    "http://schemas.openxmlformats.org/package/2006/relationships"
)
_OFFICE_RELATIONSHIP_NAMESPACES = frozenset(
    {
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
        "http://purl.oclc.org/ooxml/officeDocument/relationships",
    }
)
_WORKSHEET_CELL_STACK_LENGTH = 4
_WORKSHEET_VALUE_STACK_LENGTH = 5
_REGENERATED_MEMBERS = frozenset(
    {
        "xl/calcchain.xml",
        "xl/metadata.xml",
        "xl/sharedstrings.xml",
    }
)
_DRAWING_NAMESPACES = frozenset(
    {
        "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing",
        "http://purl.oclc.org/ooxml/drawingml/spreadsheetDrawing",
    }
)


@dataclass(frozen=True, slots=True)
class _ImageGraphEvidence:
    """Content-safe identity of every reachable worksheet image graph."""

    drawing_edges: tuple[tuple[str, str, str, str], ...]
    image_edges: tuple[tuple[str, str, str, str], ...]
    part_hashes: tuple[tuple[str, str], ...]
    content_types: tuple[tuple[str, str], ...]


@dataclass(frozen=True, slots=True)
class _ChartsheetGraphEvidence:
    """Content-safe identity of every Chartsheet relationship closure."""

    inventories: tuple[str, ...]
    workbook_records: tuple[tuple[str, str, str], ...]
    chartsheet_positions: tuple[tuple[str, int], ...]
    sheet_records: tuple[tuple[str, str], ...]
    relationship_edges: tuple[tuple[str, str, str, str | None, bool], ...]
    part_hashes: tuple[tuple[str, str], ...]
    content_types: tuple[tuple[str, str], ...]


@dataclass(frozen=True, slots=True)
class _MacroSheetGraphEvidence:
    """Content-safe identity of every Macro Sheet relationship closure."""

    inventories: tuple[str, ...]
    workbook_records: tuple[tuple[str, str, str], ...]
    macro_sheet_positions: tuple[tuple[str, int], ...]
    relationship_edges: tuple[tuple[str, str, str, str | None, bool], ...]
    shared_string_dependencies: tuple[tuple[str, str, str], ...]
    part_hashes: tuple[tuple[str, str], ...]
    content_types: tuple[tuple[str, str], ...]
    defined_name_evidence: tuple[str, ...]


def _payload(package: _SafePackage, member: str) -> bytes:
    with package.open_member(member) as stream:
        return stream.read()


def _xml_payload(package: _SafePackage, member: str) -> bytes:
    with package.open_xml_stream(member) as stream:
        return stream.read()


def _is_risk_member(name: str) -> bool:
    lowered = name.casefold()
    return (
        lowered.startswith(
            (
                "xl/externallinks/",
                "xl/chartsheets/",
                "xl/macrosheets/",
                "xl/drawings/",
                "xl/charts/",
                "xl/media/",
                "xl/printersettings/",
            )
        )
        or _part_risk_category(lowered) is not None
        or not _is_known_part(lowered)
    )


def _relationship_source_part(member: str) -> str:
    if member == "_rels/.rels":
        return ""
    directory, filename = posixpath.split(member)
    if not directory.endswith("/_rels") or not filename.endswith(".rels"):
        msg = "Workbook relationship part name is invalid"
        raise ValueError(msg)
    source_directory = directory.removesuffix("/_rels")
    return posixpath.join(source_directory, filename.removesuffix(".rels"))


def _document(
    payload: bytes,
    *,
    namespace: str,
    label: str,
) -> tuple[Document, Element]:
    document = minidom.parseString(  # noqa: S318 - bounded, DTD-screened OOXML.
        payload
    )
    root = _document_root(document)
    if root.namespaceURI != namespace:
        msg = f"Workbook {label} namespace is unsupported"
        raise ValueError(msg)
    return document, root


def _relationship_identity(
    element: Element,
    *,
    source_part: str,
) -> tuple[str, str, str] | None:
    if (
        element.namespaceURI != _RELATIONSHIPS_NAMESPACE
        or element.localName != "Relationship"
    ):
        return None
    target = element.getAttribute("Target")
    relationship_type = element.getAttribute("Type")
    target_mode = element.getAttribute("TargetMode")
    if not target or not relationship_type or target_mode not in {"", "Internal"}:
        return None
    return relationship_type, _resolve_target(source_part, target), target_mode


def _next_relationship_id(used: set[str]) -> str:
    suffix = 1
    while f"rIdPreserved{suffix}" in used:
        suffix += 1
    return f"rIdPreserved{suffix}"


def _merge_relationships(
    source: bytes,
    output: bytes,
    *,
    source_part: str,
    restored_members: frozenset[str],
) -> bytes:
    _source_document, source_root = _document(
        source,
        namespace=_RELATIONSHIPS_NAMESPACE,
        label="relationship",
    )
    output_document, output_root = _document(
        output,
        namespace=_RELATIONSHIPS_NAMESPACE,
        label="relationship",
    )
    output_relationships = tuple(_direct_elements(output_root))
    output_identities = {
        identity
        for element in output_relationships
        if (identity := _relationship_identity(element, source_part=source_part))
        is not None
    }
    used_ids = {
        element.getAttribute("Id")
        for element in output_relationships
        if element.namespaceURI == _RELATIONSHIPS_NAMESPACE
        and element.localName == "Relationship"
    }
    changed = False
    for source_element in _direct_elements(source_root):
        identity = _relationship_identity(source_element, source_part=source_part)
        if identity is None or identity[1] not in restored_members:
            continue
        if identity in output_identities:
            continue
        imported = output_document.importNode(source_element, deep=True)
        relationship_id = imported.getAttribute("Id")
        if not relationship_id:
            msg = "Workbook preserved relationship identifier is invalid"
            raise ValueError(msg)
        if relationship_id in used_ids:
            if source_part not in {"", "xl/workbook.xml"}:
                msg = "Workbook preserved relationship identifier collides"
                raise ValueError(msg)
            relationship_id = _next_relationship_id(used_ids)
            imported.setAttribute("Id", relationship_id)
        output_root.appendChild(imported)
        used_ids.add(relationship_id)
        output_identities.add(identity)
        changed = True
    return output_document.toxml(encoding="utf-8") if changed else output


@dataclass(frozen=True, slots=True)
class _ContentTypeEntries:
    """Validated effective Content-Type declarations and their XML elements."""

    defaults: dict[str, str]
    overrides: dict[str, str]
    override_elements: dict[str, Element]


def _normalized_content_type_part_name(value: str) -> str:
    if (
        not value.startswith("/")
        or value.startswith("//")
        or "\\" in value
        or "?" in value
        or "#" in value
    ):
        msg = "Workbook content type PartName is invalid"
        raise ValueError(msg)
    member = value[1:]
    if not member or posixpath.normpath(member) != member:
        msg = "Workbook content type PartName is invalid"
        raise ValueError(msg)
    return member


def _content_type_entries(root: Element) -> _ContentTypeEntries:
    if root.localName != "Types":
        msg = "Workbook content-type root is invalid"
        raise ValueError(msg)
    defaults: dict[str, str] = {}
    overrides: dict[str, str] = {}
    override_elements: dict[str, Element] = {}
    for element in _direct_elements(root):
        if element.namespaceURI != _CONTENT_TYPES_NAMESPACE:
            continue
        content_type = element.getAttribute("ContentType")
        if element.localName == "Default":
            extension = element.getAttribute("Extension").casefold()
            if not extension or not content_type or extension in defaults:
                msg = "Workbook Default content type declaration is invalid"
                raise ValueError(msg)
            defaults[extension] = content_type
        elif element.localName == "Override":
            member = _normalized_content_type_part_name(
                element.getAttribute("PartName")
            )
            if not content_type or member in overrides:
                msg = "Workbook Override content type declaration is invalid"
                raise ValueError(msg)
            overrides[member] = content_type
            override_elements[member] = element
    return _ContentTypeEntries(
        defaults=defaults,
        overrides=overrides,
        override_elements=override_elements,
    )


def _effective_content_type(
    member: str,
    entries: _ContentTypeEntries,
) -> str | None:
    override = entries.overrides.get(member)
    if override is not None:
        return override
    extension = posixpath.splitext(member)[1].lstrip(".").casefold()
    return entries.defaults.get(extension)


def _verify_restored_content_types(
    source: _ContentTypeEntries,
    output: _ContentTypeEntries,
    restored_members: frozenset[str],
) -> None:
    for member in sorted(restored_members):
        if _effective_content_type(member, output) != _effective_content_type(
            member,
            source,
        ):
            msg = "Workbook restored member content type verification failed"
            raise ValueError(msg)


def _remove_content_type_overrides(
    root: Element,
    entries: _ContentTypeEntries,
    removed_members: frozenset[str],
) -> bool:
    changed = False
    for member in sorted(removed_members):
        removed_override = entries.override_elements.pop(member, None)
        if removed_override is None:
            continue
        root.removeChild(removed_override)
        removed_override.unlink()
        entries.overrides.pop(member)
        changed = True
    return changed


def _merge_content_types(
    source: bytes,
    output: bytes,
    *,
    restored_members: frozenset[str],
    removed_members: frozenset[str] = frozenset(),
) -> bytes:
    _source_document, source_root = _document(
        source,
        namespace=_CONTENT_TYPES_NAMESPACE,
        label="content-type",
    )
    output_document, output_root = _document(
        output,
        namespace=_CONTENT_TYPES_NAMESPACE,
        label="content-type",
    )
    source_entries = _content_type_entries(source_root)
    output_entries = _content_type_entries(output_root)
    changed = _remove_content_type_overrides(
        output_root,
        output_entries,
        removed_members,
    )
    required_overrides: list[tuple[str, str]] = []
    for member in sorted(restored_members):
        source_content_type = _effective_content_type(member, source_entries)
        if source_content_type is None:
            msg = "Workbook restored member has no source content type"
            raise ValueError(msg)
        output_override = output_entries.override_elements.get(member)
        if output_override is not None:
            if output_entries.overrides[member] != source_content_type:
                output_override.setAttribute("ContentType", source_content_type)
                output_entries.overrides[member] = source_content_type
                changed = True
            continue
        extension = posixpath.splitext(member)[1].lstrip(".").casefold()
        if output_entries.defaults.get(extension) == source_content_type:
            continue
        required_overrides.append((member, source_content_type))

    override_name = (
        f"{output_root.prefix}:Override" if output_root.prefix else "Override"
    )
    for member, content_type in required_overrides:
        override = output_document.createElementNS(
            _CONTENT_TYPES_NAMESPACE,
            override_name,
        )
        override.setAttribute("PartName", f"/{member}")
        override.setAttribute("ContentType", content_type)
        output_root.appendChild(override)
        output_entries.overrides[member] = content_type
        output_entries.override_elements[member] = override
        changed = True

    if not changed:
        _verify_restored_content_types(
            source_entries,
            output_entries,
            restored_members,
        )
        return output

    merged = output_document.toxml(encoding="utf-8")
    _merged_document, merged_root = _document(
        merged,
        namespace=_CONTENT_TYPES_NAMESPACE,
        label="content-type",
    )
    merged_entries = _content_type_entries(merged_root)
    if any(member in merged_entries.overrides for member in removed_members):
        msg = "Workbook removed member content type verification failed"
        raise ValueError(msg)
    _verify_restored_content_types(
        source_entries,
        merged_entries,
        restored_members,
    )
    return merged


def _content_types(package: _SafePackage) -> tuple[dict[str, str], dict[str, str]]:
    root = package.read_xml(_CONTENT_TYPES_MEMBER)
    root_namespace = root.tag.partition("}")[0].lstrip("{") if "}" in root.tag else ""
    if root_namespace != _CONTENT_TYPES_NAMESPACE:
        msg = "Workbook image content types are invalid"
        raise ExcelModificationError(msg)
    defaults: dict[str, str] = {}
    overrides: dict[str, str] = {}
    for element in root.iter():
        namespace = (
            element.tag.partition("}")[0].lstrip("{") if "}" in element.tag else ""
        )
        if namespace != _CONTENT_TYPES_NAMESPACE:
            continue
        local_name = element.tag.rsplit("}", 1)[-1]
        if local_name == "Default":
            extension = element.attrib.get("Extension", "").casefold()
            content_type = element.attrib.get("ContentType", "")
            if not extension or not content_type or extension in defaults:
                msg = "Workbook image content types are invalid"
                raise ExcelModificationError(msg)
            defaults[extension] = content_type
        elif local_name == "Override":
            part = element.attrib.get("PartName", "").lstrip("/")
            content_type = element.attrib.get("ContentType", "")
            if not part or not content_type or part in overrides:
                msg = "Workbook image content types are invalid"
                raise ExcelModificationError(msg)
            overrides[part] = content_type
    return defaults, overrides


def _part_content_type(
    member: str,
    defaults: dict[str, str],
    overrides: dict[str, str],
) -> str:
    content_type = overrides.get(member)
    if content_type is None:
        extension = posixpath.splitext(member)[1].lstrip(".").casefold()
        content_type = defaults.get(extension)
    if content_type is None:
        msg = "Workbook image package part has no content type"
        raise ExcelModificationError(msg)
    return content_type


def _member_hash(package: _SafePackage, member: str) -> str:
    digest = sha256()
    with package.open_member(member) as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _workbook_document(payload: bytes) -> tuple[Document, Element]:
    document = minidom.parseString(  # noqa: S318 - bounded, DTD-screened OOXML.
        payload
    )
    root = _document_root(document)
    if root.namespaceURI not in _SPREADSHEETML_WORKSHEET_NAMESPACES:
        msg = "Workbook XML namespace is unsupported"
        raise ValueError(msg)
    return document, root


def _workbook_sheet_elements(root: Element) -> tuple[Element, tuple[Element, ...]]:
    containers = tuple(
        element
        for element in _direct_elements(root)
        if element.namespaceURI == root.namespaceURI and element.localName == "sheets"
    )
    if len(containers) != 1:
        msg = "Workbook sheet container is invalid"
        raise ValueError(msg)
    container = containers[0]
    sheets = tuple(
        element
        for element in _direct_elements(container)
        if element.namespaceURI == root.namespaceURI and element.localName == "sheet"
    )
    return container, sheets


def _sheet_relationship_attribute(element: Element) -> Attr:
    attributes: list[Attr] = []
    for index in range(element.attributes.length):
        attribute = cast("Attr | None", element.attributes.item(index))
        if (
            attribute is not None
            and attribute.localName == "id"
            and attribute.namespaceURI in _OFFICE_RELATIONSHIP_NAMESPACES
        ):
            attributes.append(attribute)
    if len(attributes) != 1 or not attributes[0].value:
        msg = "Workbook sheet relationship reference is invalid"
        raise ValueError(msg)
    return attributes[0]


def _rebuild_sheet_element(  # noqa: PLR0913
    document: Document,
    source: Element,
    *,
    namespace: str,
    qualified_name: str,
    relationship_template: Attr,
    relationship_id: str,
) -> Element:
    rebuilt = document.createElementNS(namespace, qualified_name)
    for index in range(source.attributes.length):
        attribute = cast("Attr | None", source.attributes.item(index))
        if attribute is None or (
            attribute.localName == "id"
            and attribute.namespaceURI in _OFFICE_RELATIONSHIP_NAMESPACES
        ):
            continue
        if attribute.namespaceURI is None:
            rebuilt.setAttribute(attribute.name, attribute.value)
        else:
            rebuilt.setAttributeNS(
                attribute.namespaceURI,
                attribute.name,
                attribute.value,
            )
    rebuilt.setAttributeNS(
        relationship_template.namespaceURI,
        relationship_template.name,
        relationship_id,
    )
    return rebuilt


def _relationship_elements(root: Element) -> dict[str, Element]:
    relationships: dict[str, Element] = {}
    for element in _direct_elements(root):
        if (
            element.namespaceURI != _RELATIONSHIPS_NAMESPACE
            or element.localName != "Relationship"
        ):
            continue
        relationship_id = element.getAttribute("Id")
        if not relationship_id or relationship_id in relationships:
            msg = "Workbook relationship identifier is invalid"
            raise ValueError(msg)
        relationships[relationship_id] = element
    return relationships


def _macro_relationship(element: Element | None) -> bool:
    if element is None:
        return False
    return element.getAttribute("Type").rsplit("/", 1)[-1].casefold() in {
        "macrosheet",
        "xlmacrosheet",
    }


def _shared_strings_relationship(element: Element | None) -> bool:
    if element is None:
        return False
    return element.getAttribute("Type").rsplit("/", 1)[-1].casefold() == "sharedstrings"


def _element_namespace(element: EtElement) -> str:
    tag = str(element.tag)
    return tag.partition("}")[0].lstrip("{") if "}" in tag else ""


def _element_local_name(element: EtElement) -> str:
    return str(element.tag).rsplit("}", 1)[-1]


def _is_worksheet_cell_path(stack: list[EtElement]) -> bool:
    if len(stack) != _WORKSHEET_CELL_STACK_LENGTH:
        return False
    namespace = _element_namespace(stack[0])
    return (
        namespace in _SPREADSHEETML_WORKSHEET_NAMESPACES
        and _element_local_name(stack[0]) == "worksheet"
        and _element_namespace(stack[1]) == namespace
        and _element_local_name(stack[1]) == "sheetData"
        and _element_namespace(stack[2]) == namespace
        and _element_local_name(stack[2]) == "row"
        and _element_namespace(stack[3]) == namespace
        and _element_local_name(stack[3]) == "c"
    )


def _optional_shared_string_table(package: _SafePackage) -> _SharedStringTable | None:
    relationships = _relationships(package, _WORKBOOK_MEMBER)
    candidates = tuple(
        relationship
        for relationship in relationships.values()
        if relationship.relationship_type.rsplit("/", 1)[-1].casefold()
        == "sharedstrings"
    )
    if not candidates:
        return None
    return _shared_string_table(package, content_types=_content_types(package))


def _verify_worksheet_shared_string_compatibility(  # noqa: C901, PLR0912
    package: _SafePackage,
    member: str,
    *,
    source_entries: tuple[str, ...],
    output_entries: tuple[str, ...] | None,
) -> None:
    stack: list[EtElement] = []
    current_shared = False
    current_value: str | None = None
    current_value_seen = False
    with package.open_xml_stream(member) as stream:
        for event, element in iterparse(  # noqa: S314 - DTD/entities rejected.
            stream,
            events=("start", "end"),
        ):
            if event == "start":
                if not stack and (
                    _element_local_name(element) != "worksheet"
                    or _element_namespace(element)
                    not in _SPREADSHEETML_WORKSHEET_NAMESPACES
                ):
                    msg = "Patched workbook Worksheet XML is invalid"
                    raise ExcelModificationError(msg)
                stack.append(element)
                if _is_worksheet_cell_path(stack):
                    current_shared = element.attrib.get("t") == "s"
                    current_value = None
                    current_value_seen = False
                continue

            if (
                current_shared
                and len(stack) == _WORKSHEET_VALUE_STACK_LENGTH
                and _element_local_name(element) == "v"
                and _element_namespace(element) in _SPREADSHEETML_WORKSHEET_NAMESPACES
                and _is_worksheet_cell_path(stack[:4])
            ):
                if current_value_seen:
                    msg = "Patched workbook Worksheet Shared String value is invalid"
                    raise ExcelModificationError(msg)
                current_value = element.text
                current_value_seen = True
            elif _is_worksheet_cell_path(stack):
                if current_shared:
                    if not current_value_seen:
                        msg = (
                            "Patched workbook Worksheet Shared String index is missing"
                        )
                        raise ExcelModificationError(msg)
                    try:
                        index = _shared_string_index(current_value)
                    except ValueError:
                        msg = (
                            "Patched workbook Worksheet Shared String index is invalid"
                        )
                        raise ExcelModificationError(msg) from None
                    if (
                        output_entries is None
                        or index >= len(output_entries)
                        or index >= len(source_entries)
                        or output_entries[index] != source_entries[index]
                    ):
                        msg = (
                            "Patched workbook Worksheet Shared String dependency "
                            "is incompatible"
                        )
                        raise ExcelModificationError(msg)
                current_shared = False

            if len(stack) > 1:
                parent = stack[-2]
                element.clear()
                parent.remove(element)
            stack.pop()
    if stack:
        msg = "Patched workbook Worksheet XML is incomplete"
        raise ExcelModificationError(msg)


def _verify_output_shared_string_compatibility(
    package: _SafePackage,
    *,
    macro_names: frozenset[str],
    source_entries: tuple[str, ...],
) -> None:
    output_table = _optional_shared_string_table(package)
    output_entries = None if output_table is None else output_table.entry_digests
    _workbook, records = _workbook_records(package)
    for record in records:
        if (
            record.sheet_type != "worksheet"
            or record.part_name is None
            or record.name.casefold() in macro_names
        ):
            continue
        _verify_worksheet_shared_string_compatibility(
            package,
            record.part_name,
            source_entries=source_entries,
            output_entries=output_entries,
        )


def preserve_macro_sheet_workbook_state(  # noqa: C901, PLR0912, PLR0915
    source_path: Path,
    output_path: Path,
    *,
    source_fingerprint: str,
) -> None:
    """Restore Macro Sheet records and workbook relationships before name repair."""
    shared_string_entry_limit = ExcelPackageLimits().shared_string_entries
    source_shared_table = None
    source_shared_payload: bytes | None = None
    with _SafePackage(source_path) as source_package:
        source_package.verify_fingerprint(source_fingerprint)
        source_workbook_element, source_records = _workbook_records(source_package)
        source_macro_names = frozenset(
            record.name.casefold()
            for record in source_records
            if record.sheet_type == "macro_sheet"
        )
        source_macro_facts = tuple(
            _macro_sheet_facts(
                source_package,
                workbook=source_workbook_element,
                sheet=record,
                workbook_order=workbook_order,
                shared_string_entry_limit=shared_string_entry_limit,
            )
            for workbook_order, record in enumerate(source_records, start=1)
            if record.sheet_type == "macro_sheet"
        )
        shared_parts = {
            facts.shared_strings_part
            for facts in source_macro_facts
            if facts.shared_strings_part is not None
        }
        if len(shared_parts) > 1:
            msg = "Macro Sheet Shared Strings dependency is inconsistent"
            raise ExcelModificationError(msg)
        if shared_parts:
            source_shared_table = _shared_string_table(
                source_package,
                content_types=_content_types(source_package),
                entry_limit=shared_string_entry_limit,
            )
            if source_shared_table.part not in shared_parts:
                msg = "Macro Sheet Shared Strings dependency is inconsistent"
                raise ExcelModificationError(msg)
            source_shared_payload = _xml_payload(
                source_package,
                source_shared_table.part,
            )
        source_workbook = _xml_payload(source_package, _WORKBOOK_MEMBER)
        source_relationships = _xml_payload(
            source_package,
            _WORKBOOK_RELATIONSHIPS_MEMBER,
        )
        source_content_types = _xml_payload(source_package, _CONTENT_TYPES_MEMBER)
        source_names = frozenset(source_package.names)
    with _SafePackage(output_path) as output_package:
        if source_shared_table is not None:
            _verify_output_shared_string_compatibility(
                output_package,
                macro_names=source_macro_names,
                source_entries=source_shared_table.entry_digests,
            )
        output_workbook = _xml_payload(output_package, _WORKBOOK_MEMBER)
        output_relationships = _xml_payload(
            output_package,
            _WORKBOOK_RELATIONSHIPS_MEMBER,
        )
        output_content_types = _xml_payload(output_package, _CONTENT_TYPES_MEMBER)
        output_names = frozenset(output_package.names)

    source_document, source_root = _workbook_document(source_workbook)
    del source_document
    output_document, output_root = _workbook_document(output_workbook)
    source_container, source_sheets = _workbook_sheet_elements(source_root)
    del source_container
    output_container, output_sheets = _workbook_sheet_elements(output_root)
    source_rels_document, source_rels_root = _document(
        source_relationships,
        namespace=_RELATIONSHIPS_NAMESPACE,
        label="relationship",
    )
    del source_rels_document
    output_rels_document, output_rels_root = _document(
        output_relationships,
        namespace=_RELATIONSHIPS_NAMESPACE,
        label="relationship",
    )
    source_rels = _relationship_elements(source_rels_root)
    output_rels = _relationship_elements(output_rels_root)

    source_macro_sheets = tuple(
        sheet
        for sheet in source_sheets
        if _macro_relationship(
            source_rels.get(_sheet_relationship_attribute(sheet).value)
        )
    )
    if not source_macro_sheets:
        return
    macro_names = frozenset(
        sheet.getAttribute("name").casefold() for sheet in source_macro_sheets
    )
    if macro_names != source_macro_names:
        msg = "Macro Sheet workbook records are inconsistent"
        raise ExcelModificationError(msg)
    surrogate_sheets = tuple(
        sheet
        for sheet in output_sheets
        if sheet.getAttribute("name").casefold() in macro_names
    )
    stale_members: set[str] = set()
    for sheet in surrogate_sheets:
        relationship_id = _sheet_relationship_attribute(sheet).value
        relationship = output_rels.get(relationship_id)
        identity = (
            None
            if relationship is None
            else _relationship_identity(
                relationship,
                source_part=_WORKBOOK_MEMBER,
            )
        )
        if (
            relationship is not None
            and identity is not None
            and not _macro_relationship(relationship)
        ):
            target = identity[1]
            if target not in source_names and target in output_names:
                stale_members.add(target)
                relationship_part = _relationship_part(target)
                if relationship_part in output_names:
                    stale_members.add(relationship_part)
            output_rels_root.removeChild(relationship)
            output_rels.pop(relationship_id)

    source_has_vba_relationship = any(
        element.getAttribute("Type").rsplit("/", 1)[-1].casefold() == "vbaproject"
        for element in source_rels.values()
    )
    if not source_has_vba_relationship:
        for relationship_id, relationship in tuple(output_rels.items()):
            if (
                relationship.getAttribute("Type").rsplit("/", 1)[-1].casefold()
                == "vbaproject"
            ):
                output_rels_root.removeChild(relationship)
                output_rels.pop(relationship_id)

    restored_members: set[str] = set()
    additions: dict[str, bytes] = {}
    if source_shared_table is not None:
        source_shared_relationships = tuple(
            (relationship_id, relationship)
            for relationship_id, relationship in source_rels.items()
            if _shared_strings_relationship(relationship)
        )
        if len(source_shared_relationships) != 1:
            msg = "Macro Sheet Shared Strings relationship is invalid"
            raise ExcelModificationError(msg)
        source_shared_id, source_shared_relationship = source_shared_relationships[0]
        source_shared_identity = _relationship_identity(
            source_shared_relationship,
            source_part=_WORKBOOK_MEMBER,
        )
        if (
            source_shared_identity is None
            or source_shared_identity[1] != source_shared_table.part
        ):
            msg = "Macro Sheet Shared Strings relationship is invalid"
            raise ExcelModificationError(msg)

        for relationship_id, relationship in tuple(output_rels.items()):
            if not _shared_strings_relationship(relationship):
                continue
            identity = _relationship_identity(
                relationship,
                source_part=_WORKBOOK_MEMBER,
            )
            if identity is None:
                msg = "Patched workbook Shared Strings relationship is invalid"
                raise ExcelModificationError(msg)
            target = identity[1]
            if target != source_shared_table.part and target in output_names:
                if target in source_names:
                    msg = "Patched workbook Shared Strings dependency conflicts"
                    raise ExcelModificationError(msg)
                stale_members.add(target)
                relationship_part = _relationship_part(target)
                if relationship_part in output_names:
                    stale_members.add(relationship_part)
            output_rels_root.removeChild(relationship)
            output_rels.pop(relationship_id)

        used_ids = set(output_rels)
        assigned_shared_id = source_shared_id
        if assigned_shared_id in used_ids:
            assigned_shared_id = _next_relationship_id(used_ids)
        imported_shared_relationship = output_rels_document.importNode(
            source_shared_relationship,
            deep=True,
        )
        imported_shared_relationship.setAttribute("Id", assigned_shared_id)
        output_rels_root.appendChild(imported_shared_relationship)
        output_rels[assigned_shared_id] = imported_shared_relationship
        restored_members.add(source_shared_table.part)
        if source_shared_payload is None:
            msg = "Macro Sheet Shared Strings payload is missing"
            raise ExcelModificationError(msg)
        if source_shared_table.part not in output_names:
            additions[source_shared_table.part] = source_shared_payload

    output_nonmacro = tuple(
        sheet
        for sheet in output_sheets
        if sheet.getAttribute("name").casefold() not in macro_names
    )
    source_nonmacro = tuple(
        sheet for sheet in source_sheets if sheet not in source_macro_sheets
    )
    if tuple(sheet.getAttribute("name") for sheet in output_nonmacro) != tuple(
        sheet.getAttribute("name") for sheet in source_nonmacro
    ):
        msg = "Macro Sheet preservation requires unchanged workbook sheet structure"
        raise ExcelModificationError(msg)
    output_by_name = {sheet.getAttribute("name"): sheet for sheet in output_nonmacro}
    if len(output_by_name) != len(output_nonmacro):
        msg = "Patched workbook contains duplicate sheet names"
        raise ExcelModificationError(msg)

    identities = {
        identity: element
        for element in output_rels.values()
        if (
            identity := _relationship_identity(
                element,
                source_part=_WORKBOOK_MEMBER,
            )
        )
        is not None
    }
    used_ids = set(output_rels)
    macro_ids: dict[str, str] = {}
    for sheet in source_macro_sheets:
        source_id = _sheet_relationship_attribute(sheet).value
        source_relationship = source_rels.get(source_id)
        identity = (
            None
            if source_relationship is None
            else _relationship_identity(
                source_relationship,
                source_part=_WORKBOOK_MEMBER,
            )
        )
        if (
            source_relationship is None
            or identity is None
            or not _macro_relationship(source_relationship)
            or not identity[1].casefold().startswith("xl/macrosheets/")
        ):
            msg = "Macro Sheet workbook relationship is invalid"
            raise ExcelModificationError(msg)
        existing = identities.get(identity)
        if existing is not None:
            assigned_id = existing.getAttribute("Id")
        else:
            assigned_id = source_id
            if assigned_id in used_ids:
                assigned_id = _next_relationship_id(used_ids)
            imported_relationship = output_rels_document.importNode(
                source_relationship,
                deep=True,
            )
            imported_relationship.setAttribute("Id", assigned_id)
            output_rels_root.appendChild(imported_relationship)
            used_ids.add(assigned_id)
            identities[identity] = imported_relationship
        macro_ids[sheet.getAttribute("name")] = assigned_id

    for sheet in output_sheets:
        output_container.removeChild(sheet)
    relationship_template = (
        _sheet_relationship_attribute(output_sheets[0])
        if output_sheets
        else _sheet_relationship_attribute(source_sheets[0])
    )
    relationship_namespace = relationship_template.namespaceURI
    output_namespace = output_root.namespaceURI
    if relationship_namespace is None or output_namespace is None:
        msg = "Workbook sheet namespace is invalid"
        raise ValueError(msg)
    if relationship_template.prefix and not output_root.hasAttribute(
        f"xmlns:{relationship_template.prefix}"
    ):
        output_root.setAttributeNS(
            "http://www.w3.org/2000/xmlns/",
            f"xmlns:{relationship_template.prefix}",
            relationship_namespace,
        )
    for source_sheet in source_sheets:
        name = source_sheet.getAttribute("name")
        if source_sheet in source_macro_sheets:
            relationship_id = macro_ids[name]
        else:
            relationship_id = _sheet_relationship_attribute(output_by_name[name]).value
        rebuilt = _rebuild_sheet_element(
            output_document,
            source_sheet,
            namespace=output_namespace,
            qualified_name=output_sheets[0].tagName if output_sheets else "sheet",
            relationship_template=relationship_template,
            relationship_id=relationship_id,
        )
        output_container.appendChild(rebuilt)

    replacements = {
        _WORKBOOK_MEMBER: output_document.toxml(encoding="utf-8"),
        _WORKBOOK_RELATIONSHIPS_MEMBER: output_rels_document.toxml(encoding="utf-8"),
        _CONTENT_TYPES_MEMBER: _merge_content_types(
            source_content_types,
            output_content_types,
            restored_members=frozenset(restored_members),
            removed_members=frozenset(stale_members),
        ),
    }
    if source_shared_table is not None and source_shared_table.part in output_names:
        if source_shared_payload is None:
            msg = "Macro Sheet Shared Strings payload is missing"
            raise ExcelModificationError(msg)
        replacements[source_shared_table.part] = source_shared_payload
    replacement_path = create_staging_path(
        output_path,
        output_path.suffix,
        purpose="macro-sheet-workbook",
    )
    try:
        _copy_package(
            output_path,
            replacement_path,
            replacements,
            removals=frozenset(stale_members),
            source_fingerprint=calculate_sha256(output_path).value,
            additions=additions,
        )
        replacement_path.replace(output_path)
    finally:
        replacement_path.unlink(missing_ok=True)


def _chartsheet_graph_evidence(
    path: Path,
    *,
    expected_fingerprint: str | None = None,
) -> _ChartsheetGraphEvidence:
    inventories: list[str] = []
    workbook_records: list[tuple[str, str, str]] = []
    chartsheet_positions: list[tuple[str, int]] = []
    edges: set[tuple[str, str, str, str | None, bool]] = set()
    closure_members: set[str] = set()
    with _SafePackage(path) as package:
        if expected_fingerprint is not None:
            package.verify_fingerprint(expected_fingerprint)
        _workbook, records = _workbook_records(package)
        sheet_records = tuple((record.name, record.sheet_type) for record in records)
        for workbook_order, record in enumerate(records, start=1):
            if record.sheet_type != "chartsheet":
                continue
            facts = _chartsheet_facts(
                package,
                sheet=record,
                workbook_order=workbook_order,
            )
            inventories.append(
                facts.inventory.model_dump_json(exclude={"workbook_order"})
            )
            workbook_records.append(
                (
                    record.name,
                    record.visibility,
                    record.part_name or "",
                )
            )
            chartsheet_positions.append((record.name, workbook_order))
            edges.update(facts.relationship_edges)
            closure_members.update(facts.closure_members)
        hashes = tuple(
            sorted(
                (member, _member_hash(package, member)) for member in closure_members
            )
        )
        defaults, overrides = _content_types(package)
        content_types = tuple(
            sorted(
                (
                    member,
                    _part_content_type(member, defaults, overrides),
                )
                for member in closure_members
            )
        )
    return _ChartsheetGraphEvidence(
        inventories=tuple(inventories),
        workbook_records=tuple(workbook_records),
        chartsheet_positions=tuple(chartsheet_positions),
        sheet_records=sheet_records,
        relationship_edges=tuple(sorted(edges)),
        part_hashes=hashes,
        content_types=content_types,
    )


def _expected_chartsheet_positions(
    source: _ChartsheetGraphEvidence,
    *,
    create_sheets: Sequence[WorksheetCreatePatch],
    delete_sheets: Sequence[WorksheetDeletePatch],
) -> tuple[tuple[str, int], ...]:
    order = list(source.sheet_records)
    for deletion in delete_sheets:
        identity = deletion.name.casefold()
        matches = [
            index
            for index, (name, _kind) in enumerate(order)
            if name.casefold() == identity
        ]
        if len(matches) != 1 or order[matches[0]][1] != "worksheet":
            msg = "Workbook Chartsheet preservation request is invalid"
            raise ExcelModificationError(msg)
        order.pop(matches[0])
    for creation in create_sheets:
        if creation.index > len(order) or any(
            name.casefold() == creation.name.casefold() for name, _kind in order
        ):
            msg = "Workbook Chartsheet preservation request is invalid"
            raise ExcelModificationError(msg)
        order.insert(creation.index, (creation.name, "worksheet"))
    return tuple(
        (name, index)
        for index, (name, kind) in enumerate(order, start=1)
        if kind == "chartsheet"
    )


def verify_chartsheet_preservation(
    source_path: Path,
    output_path: Path,
    *,
    source_fingerprint: str,
    create_sheets: Sequence[WorksheetCreatePatch] = (),
    delete_sheets: Sequence[WorksheetDeletePatch] = (),
) -> None:
    """Verify exact Chartsheet relationship closure after an unrelated patch."""
    source = _chartsheet_graph_evidence(
        source_path,
        expected_fingerprint=source_fingerprint,
    )
    if not source.inventories:
        return
    output = _chartsheet_graph_evidence(output_path)
    expected_positions = _expected_chartsheet_positions(
        source,
        create_sheets=create_sheets,
        delete_sheets=delete_sheets,
    )
    if (
        output.inventories != source.inventories
        or output.workbook_records != source.workbook_records
        or output.chartsheet_positions != expected_positions
        or output.relationship_edges != source.relationship_edges
        or output.part_hashes != source.part_hashes
        or output.content_types != source.content_types
    ):
        msg = "Patched workbook Chartsheet preservation verification failed"
        raise ExcelModificationError(msg)


def _macro_defined_name_evidence(
    workbook: EtElement,
    macro_sheet_positions: tuple[tuple[str, int], ...],
) -> tuple[str, ...]:
    return _relevant_defined_name_record_digests(
        workbook,
        sheets=tuple(
            (sheet_name, workbook_order - 1)
            for sheet_name, workbook_order in macro_sheet_positions
        ),
    )


def _macro_sheet_graph_evidence(
    path: Path,
    *,
    expected_fingerprint: str | None = None,
) -> _MacroSheetGraphEvidence:
    shared_string_entry_limit = ExcelPackageLimits().shared_string_entries
    inventories: list[str] = []
    workbook_records: list[tuple[str, str, str]] = []
    macro_sheet_positions: list[tuple[str, int]] = []
    edges: set[tuple[str, str, str, str | None, bool]] = set()
    shared_dependencies: set[tuple[str, str, str]] = set()
    closure_members: set[str] = set()
    with _SafePackage(path) as package:
        if expected_fingerprint is not None:
            package.verify_fingerprint(expected_fingerprint)
        workbook, records = _workbook_records(package)
        for workbook_order, record in enumerate(records, start=1):
            if record.sheet_type != "macro_sheet":
                continue
            facts = _macro_sheet_facts(
                package,
                workbook=workbook,
                sheet=record,
                workbook_order=workbook_order,
                shared_string_entry_limit=shared_string_entry_limit,
            )
            inventories.append(
                facts.inventory.model_dump_json(exclude={"workbook_order"})
            )
            workbook_records.append(
                (
                    record.name,
                    record.visibility,
                    record.part_name or "",
                )
            )
            macro_sheet_positions.append((record.name, workbook_order))
            edges.update(facts.relationship_edges)
            closure_members.update(facts.closure_members)
            if facts.shared_strings_part is not None:
                if (
                    facts.shared_strings_part_sha256 is None
                    or facts.shared_strings_relationship_type is None
                ):
                    msg = "Macro Sheet Shared Strings dependency is incomplete"
                    raise ExcelModificationError(msg)
                closure_members.add(facts.shared_strings_part)
                shared_dependencies.add(
                    (
                        facts.shared_strings_part,
                        facts.shared_strings_relationship_type,
                        facts.shared_strings_part_sha256,
                    )
                )
        hashes = tuple(
            sorted(
                (member, _member_hash(package, member)) for member in closure_members
            )
        )
        defaults, overrides = _content_types(package)
        content_types = tuple(
            sorted(
                (
                    member,
                    _part_content_type(member, defaults, overrides),
                )
                for member in closure_members
            )
        )
        defined_name_evidence = _macro_defined_name_evidence(
            workbook,
            tuple(macro_sheet_positions),
        )
    return _MacroSheetGraphEvidence(
        inventories=tuple(inventories),
        workbook_records=tuple(workbook_records),
        macro_sheet_positions=tuple(macro_sheet_positions),
        relationship_edges=tuple(sorted(edges)),
        shared_string_dependencies=tuple(sorted(shared_dependencies)),
        part_hashes=hashes,
        content_types=content_types,
        defined_name_evidence=defined_name_evidence,
    )


def verify_macro_sheet_preservation(
    source_path: Path,
    output_path: Path,
    *,
    source_fingerprint: str,
) -> None:
    """Verify exact Macro Sheet records, names, and bounded package closure."""
    source = _macro_sheet_graph_evidence(
        source_path,
        expected_fingerprint=source_fingerprint,
    )
    if not source.inventories:
        return
    output = _macro_sheet_graph_evidence(output_path)
    if output != source:
        msg = "Patched workbook Macro Sheet preservation verification failed"
        raise ExcelModificationError(msg)


def _relationship_references(package: _SafePackage, member: str) -> frozenset[str]:
    """Return namespace-qualified relationship IDs used by one bounded XML part."""
    with package.open_xml_stream(member) as stream:
        document = minidom.parseString(  # noqa: S318 - bounded OOXML.
            stream.read()
        )
    root = _document_root(document)
    references: set[str] = set()
    for element in (root, *root.getElementsByTagName("*")):
        for index in range(element.attributes.length):
            attribute = cast("Attr | None", element.attributes.item(index))
            if (
                attribute is not None
                and attribute.namespaceURI in _OFFICE_RELATIONSHIP_NAMESPACES
                and attribute.value
            ):
                references.add(attribute.value)
    return frozenset(references)


def _drawing_image_edges(
    package: _SafePackage,
    drawing_part: str,
) -> tuple[set[tuple[str, str, str, str]], set[str]]:
    references = _relationship_references(package, drawing_part)
    relationships = _relationships(package, drawing_part)
    edges: set[tuple[str, str, str, str]] = set()
    image_parts: set[str] = set()
    image_relationship_ids: set[str] = set()
    for relationship_id, relationship in relationships.items():
        if relationship.relationship_type.rsplit("/", 1)[-1] != "image":
            continue
        target = relationship.target
        if (
            relationship.external
            or target is None
            or not target.casefold().startswith("xl/media/")
            or not package.has(target)
            or relationship_id not in references
        ):
            msg = "Workbook image relationship graph is invalid"
            raise ExcelModificationError(msg)
        edges.add(
            (
                drawing_part,
                relationship_id,
                relationship.relationship_type,
                target,
            )
        )
        image_parts.add(target)
        image_relationship_ids.add(relationship_id)
    for reference_id in references:
        referenced_relationship = relationships.get(reference_id)
        if referenced_relationship is None or (
            referenced_relationship.relationship_type.rsplit("/", 1)[-1] == "image"
            and reference_id not in image_relationship_ids
        ):
            msg = "Workbook image relationship graph is invalid"
            raise ExcelModificationError(msg)
    return edges, image_parts


def _image_graph_evidence(
    path: Path,
    *,
    expected_fingerprint: str | None = None,
) -> _ImageGraphEvidence:
    drawing_edges: set[tuple[str, str, str, str]] = set()
    image_edges: set[tuple[str, str, str, str]] = set()
    image_parts: set[str] = set()
    drawing_parts: set[str] = set()
    with _SafePackage(path) as package:
        if expected_fingerprint is not None:
            package.verify_fingerprint(expected_fingerprint)
        _workbook, records = _workbook_records(package)
        for record in records:
            if record.sheet_type != "worksheet" or record.part_name is None:
                continue
            worksheet_references = _relationship_references(package, record.part_name)
            for relationship_id, relationship in _relationships(
                package,
                record.part_name,
            ).items():
                if relationship.relationship_type.rsplit("/", 1)[-1] != "drawing":
                    continue
                target = relationship.target
                if (
                    relationship.external
                    or target is None
                    or not target.casefold().startswith("xl/drawings/")
                    or not package.has(target)
                    or relationship_id not in worksheet_references
                ):
                    msg = "Workbook image relationship graph is invalid"
                    raise ExcelModificationError(msg)
                drawing_edges.add(
                    (
                        record.part_name,
                        relationship_id,
                        relationship.relationship_type,
                        target,
                    )
                )
                drawing_parts.add(target)
                drawing_image_edges, drawing_image_parts = _drawing_image_edges(
                    package,
                    target,
                )
                image_edges.update(drawing_image_edges)
                image_parts.update(drawing_image_parts)
        defaults, overrides = _content_types(package)
        parts = drawing_parts | image_parts
        hashes = tuple(
            sorted((member, _member_hash(package, member)) for member in parts)
        )
        content_types = tuple(
            sorted(
                (
                    member,
                    _part_content_type(member, defaults, overrides),
                )
                for member in parts
            )
        )
    return _ImageGraphEvidence(
        drawing_edges=tuple(sorted(drawing_edges)),
        image_edges=tuple(sorted(image_edges)),
        part_hashes=hashes,
        content_types=content_types,
    )


def verify_opaque_image_preservation(
    source_path: Path,
    output_path: Path,
    *,
    source_fingerprint: str,
) -> None:
    """Verify exact reachable image parts and relationship identity after patching."""
    source = _image_graph_evidence(
        source_path,
        expected_fingerprint=source_fingerprint,
    )
    if not source.image_edges:
        return
    output = _image_graph_evidence(output_path)
    if output != source:
        msg = "Patched workbook image preservation verification failed"
        raise ExcelModificationError(msg)


def _marker_state(element: Element) -> tuple[int, int, int, int]:
    values: dict[str, int] = {}
    for child in _direct_elements(element):
        if child.namespaceURI not in _DRAWING_NAMESPACES or child.localName not in {
            "col",
            "colOff",
            "row",
            "rowOff",
        }:
            continue
        text = "".join(
            str(getattr(node, "data", ""))
            for node in child.childNodes
            if node.nodeType == minidom.Node.TEXT_NODE
        )
        if not text.isdigit():
            msg = "Workbook drawing marker is invalid"
            raise ExcelModificationError(msg)
        values[child.localName] = int(text)
    if set(values) != {"col", "colOff", "row", "rowOff"}:
        msg = "Workbook drawing marker is incomplete"
        raise ExcelModificationError(msg)
    return values["col"], values["colOff"], values["row"], values["rowOff"]


def _drawing_anchor_states(
    package: _SafePackage,
    member: str,
) -> tuple[tuple[str, tuple[tuple[str, tuple[int, int, int, int]], ...]], ...]:
    with package.open_xml_stream(member) as stream:
        document = minidom.parseString(  # noqa: S318 - bounded OOXML.
            stream.read()
        )
    root = _document_root(document)
    if root.namespaceURI not in _DRAWING_NAMESPACES:
        msg = "Workbook drawing namespace is unsupported"
        raise ExcelModificationError(msg)
    states = []
    for anchor in _direct_elements(root):
        if anchor.namespaceURI not in _DRAWING_NAMESPACES:
            continue
        markers = tuple(
            (child.localName, _marker_state(child))
            for child in _direct_elements(anchor)
            if child.namespaceURI in _DRAWING_NAMESPACES
            and child.localName in {"from", "to"}
        )
        states.append((anchor.localName, markers))
    return tuple(states)


def _shift_anchor_states(
    states: tuple[tuple[str, tuple[tuple[str, tuple[int, int, int, int]], ...]], ...],
    patches: Sequence[WorksheetStructuralInsertionPatch],
) -> tuple[tuple[str, tuple[tuple[str, tuple[int, int, int, int]], ...]], ...]:
    shifted = states
    for patch in normalize_structural_insertions(patches):
        updated = []
        for kind, markers in shifted:
            marker_values = []
            for name, (column, column_offset, row, row_offset) in markers:
                shifted_column = column
                shifted_row = row
                if patch.axis == "column" and column >= patch.before - 1:
                    shifted_column += patch.count
                if patch.axis == "row" and row >= patch.before - 1:
                    shifted_row += patch.count
                marker_values.append(
                    (name, (shifted_column, column_offset, shifted_row, row_offset))
                )
            updated.append((kind, tuple(marker_values)))
        shifted = tuple(updated)
    return shifted


def verify_request_aware_image_preservation(  # noqa: C901, PLR0912, PLR0913, PLR0915
    source_path: Path,
    output_path: Path,
    *,
    source_fingerprint: str,
    structural_insertions: Sequence[WorksheetStructuralInsertionPatch],
    delete_sheets: Sequence[WorksheetDeletePatch],
    drawing_removals: Sequence[WorksheetDrawingRemovalPatch],
    image_additions: Sequence[WorksheetImagePatch],
) -> None:
    """Verify untargeted image state and expected structural anchor movement."""
    source = _image_graph_evidence(
        source_path,
        expected_fingerprint=source_fingerprint,
    )
    output = _image_graph_evidence(output_path)
    with (
        _SafePackage(source_path) as source_package,
        _SafePackage(output_path) as output_package,
    ):
        _workbook, records = _workbook_records(source_package)
        by_name = {
            record.name.casefold(): record.part_name
            for record in records
            if record.part_name is not None
        }
        structural_by_member: dict[str, list[WorksheetStructuralInsertionPatch]] = {}
        for patch in structural_insertions:
            member = by_name.get(patch.sheet_name.casefold())
            if member is not None:
                structural_by_member.setdefault(member, []).append(patch)
        removed_members = {
            by_name[name]
            for name in {
                *(patch.name.casefold() for patch in delete_sheets),
                *(patch.sheet_name.casefold() for patch in drawing_removals),
            }
            if name in by_name
        }
        added_members = {
            by_name[patch.sheet_name.casefold()]
            for patch in image_additions
            if patch.sheet_name.casefold() in by_name
        }
        targeted_members = set(structural_by_member) | removed_members | added_members
        source_untargeted_edges = tuple(
            edge for edge in source.drawing_edges if edge[0] not in targeted_members
        )
        output_untargeted_edges = tuple(
            edge for edge in output.drawing_edges if edge[0] not in targeted_members
        )
        if source_untargeted_edges != output_untargeted_edges:
            msg = "Patched workbook untargeted drawing graph verification failed"
            raise ExcelModificationError(msg)
        source_hashes = dict(source.part_hashes)
        output_hashes = dict(output.part_hashes)
        source_types = dict(source.content_types)
        output_types = dict(output.content_types)
        untargeted_drawings = {edge[3] for edge in source_untargeted_edges}
        source_untargeted_image_edges = tuple(
            edge for edge in source.image_edges if edge[0] in untargeted_drawings
        )
        output_untargeted_image_edges = tuple(
            edge for edge in output.image_edges if edge[0] in untargeted_drawings
        )
        if source_untargeted_image_edges != output_untargeted_image_edges:
            msg = "Patched workbook untargeted image graph verification failed"
            raise ExcelModificationError(msg)
        for member in untargeted_drawings:
            if source_hashes.get(member) != output_hashes.get(
                member
            ) or source_types.get(member) != output_types.get(member):
                msg = "Patched workbook untargeted drawing preservation failed"
                raise ExcelModificationError(msg)
        source_media = {edge[3] for edge in source.image_edges}
        output_media = {edge[3] for edge in output.image_edges}
        for member in source_media & output_media:
            if source_hashes.get(member) != output_hashes.get(
                member
            ) or source_types.get(member) != output_types.get(member):
                msg = "Patched workbook image media preservation failed"
                raise ExcelModificationError(msg)
        for worksheet_member in removed_members:
            if any(edge[0] == worksheet_member for edge in output.drawing_edges):
                msg = "Patched workbook drawing removal verification failed"
                raise ExcelModificationError(msg)
        for worksheet_member in added_members:
            source_edges = {
                edge for edge in source.drawing_edges if edge[0] == worksheet_member
            }
            output_edges = {
                edge for edge in output.drawing_edges if edge[0] == worksheet_member
            }
            if not source_edges <= output_edges:
                msg = "Patched workbook existing drawing graph preservation failed"
                raise ExcelModificationError(msg)
            source_drawings = {edge[3] for edge in source_edges}
            if not {
                edge for edge in source.image_edges if edge[0] in source_drawings
            } <= set(output.image_edges):
                msg = "Patched workbook existing image graph preservation failed"
                raise ExcelModificationError(msg)
        for worksheet_member, patches in structural_by_member.items():
            if worksheet_member in removed_members:
                continue
            source_drawings = {
                edge[3] for edge in source.drawing_edges if edge[0] == worksheet_member
            }
            output_drawings = {
                edge[3] for edge in output.drawing_edges if edge[0] == worksheet_member
            }
            if source_drawings != output_drawings:
                msg = "Patched workbook structural drawing graph verification failed"
                raise ExcelModificationError(msg)
            if {edge for edge in source.image_edges if edge[0] in source_drawings} != {
                edge for edge in output.image_edges if edge[0] in output_drawings
            }:
                msg = "Patched workbook structural image graph verification failed"
                raise ExcelModificationError(msg)
            for drawing in source_drawings:
                expected = _shift_anchor_states(
                    _drawing_anchor_states(source_package, drawing),
                    patches,
                )
                if _drawing_anchor_states(output_package, drawing) != expected:
                    msg = "Patched workbook structural image anchor verification failed"
                    raise ExcelModificationError(msg)


def preserve_opaque_package_parts(
    source_path: Path,
    output_path: Path,
    *,
    source_fingerprint: str,
) -> None:
    """Restore untouched opaque members and their package reachability."""
    replacements: dict[str, bytes] = {}
    additions: dict[str, bytes] = {}
    with (
        _SafePackage(source_path) as source_package,
        _SafePackage(output_path) as output_package,
    ):
        source_package.verify_fingerprint(source_fingerprint)
        source_package.reject_forbidden_xml_declarations()
        source_names = set(source_package.names)
        output_names = set(output_package.names)
        risk_members = {name for name in source_names if _is_risk_member(name)}
        worksheet_relationships = {
            name
            for name in source_names
            if name.casefold().startswith("xl/worksheets/_rels/")
            and name.casefold().endswith(".rels")
        }
        missing_members = {
            name
            for name in source_names - output_names
            if name.casefold() not in _REGENERATED_MEMBERS
        }
        restored_members = frozenset(
            risk_members
            | missing_members
            | worksheet_relationships
            | ({"docProps/core.xml"} & source_names)
        )
        stale_relationship_parts = frozenset(
            relationship_part
            for member in restored_members
            if not member.casefold().endswith(".rels")
            and (relationship_part := _relationship_part(member)) in output_names
            and relationship_part not in source_names
        )
        for member in sorted(restored_members):
            source_payload = _payload(source_package, member)
            if member in output_names:
                replacements[member] = source_payload
            else:
                additions[member] = source_payload

        for member in sorted(source_names & output_names):
            if not member.casefold().endswith(".rels") or member in restored_members:
                continue
            source_payload = _xml_payload(source_package, member)
            output_payload = _xml_payload(output_package, member)
            merged = _merge_relationships(
                source_payload,
                output_payload,
                source_part=_relationship_source_part(member),
                restored_members=restored_members,
            )
            if merged != output_payload:
                replacements[member] = merged

        source_content_types = _xml_payload(source_package, _CONTENT_TYPES_MEMBER)
        output_content_types = _xml_payload(output_package, _CONTENT_TYPES_MEMBER)
        merged_content_types = _merge_content_types(
            source_content_types,
            output_content_types,
            restored_members=restored_members,
            removed_members=stale_relationship_parts,
        )
        if merged_content_types != output_content_types:
            replacements[_CONTENT_TYPES_MEMBER] = merged_content_types

    if not replacements and not additions and not stale_relationship_parts:
        return
    replacement_path = create_staging_path(
        output_path,
        output_path.suffix,
        purpose="opaque-parts",
    )
    try:
        _copy_package(
            output_path,
            replacement_path,
            replacements,
            additions=additions,
            removals=stale_relationship_parts,
            source_fingerprint=calculate_sha256(output_path).value,
        )
        replacement_path.replace(output_path)
    finally:
        replacement_path.unlink(missing_ok=True)

"""Typed conditional-formatting replacement and reopened verification."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any
from xml.etree import ElementTree as ET

from document_sdk.excel._cell_format_modification import (
    _alignment,
    _border,
    _fill,
    _font,
)
from document_sdk.excel.errors import ExcelModificationError

if TYPE_CHECKING:
    from collections.abc import Sequence

    from openpyxl.formatting.rule import Rule
    from openpyxl.styles.differential import DifferentialStyle
    from openpyxl.workbook.workbook import Workbook
    from openpyxl.worksheet.worksheet import Worksheet

    from document_sdk.excel.models import (
        ConditionalFormattingRulePatch,
        DifferentialFormatPatch,
        WorksheetConditionalFormattingPatch,
    )


@dataclass(frozen=True, slots=True)
class _PendingConditionalFormattingChange:
    """One requested rule-set replacement before public file identities exist."""

    sheet_name: str
    old_rule_count: int
    new_rule_count: int
    old_rule_set_fingerprint: str
    new_rule_set_fingerprint: str

    @property
    def changed(self) -> bool:
        """Return whether the replacement changes the semantic rule set."""
        return self.old_rule_set_fingerprint != self.new_rule_set_fingerprint


def _worksheet(workbook: Workbook, sheet_name: str) -> Worksheet:
    matches = [
        worksheet
        for worksheet in workbook.worksheets
        if worksheet.title.casefold() == sheet_name.casefold()
    ]
    if len(matches) != 1:
        msg = "Workbook conditional-formatting worksheet does not exist"
        raise ExcelModificationError(msg)
    return matches[0]


def _xml_text(value: object | None) -> str | None:
    if value is None:
        return None
    to_tree = getattr(value, "to_tree", None)
    if not callable(to_tree):  # pragma: no cover - openpyxl model invariant.
        msg = "Workbook conditional-formatting style is invalid"
        raise ExcelModificationError(msg)
    return ET.tostring(to_tree(), encoding="unicode")


def _rule_state(rule: Rule) -> dict[str, object]:
    return {
        "type": rule.type,
        "operator": rule.operator,
        "formulas": tuple(rule.formula or ()),
        "text": rule.text,
        "stop_if_true": bool(rule.stopIfTrue),
        "rank": rule.rank,
        "bottom": None if rule.bottom is None else bool(rule.bottom),
        "differential_format": _xml_text(rule.dxf),
    }


def _rule_set_state(worksheet: Worksheet) -> tuple[dict[str, object], ...]:
    return tuple(
        {
            "cell_ranges": tuple(str(block.sqref).split()),
            "rules": tuple(_rule_state(rule) for rule in block.rules),
        }
        for block in worksheet.conditional_formatting
    )


def _rule_count(worksheet: Worksheet) -> int:
    return sum(len(block.rules) for block in worksheet.conditional_formatting)


def _fingerprint(state: tuple[dict[str, object], ...]) -> str:
    payload = json.dumps(
        state,
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _differential_style(
    value: DifferentialFormatPatch | None,
) -> DifferentialStyle | None:
    if value is None:
        return None
    from openpyxl.styles.differential import DifferentialStyle
    from openpyxl.styles.numbers import NumberFormat

    return DifferentialStyle(
        font=None if value.font is None else _font(value.font),
        fill=None if value.fill is None else _fill(value.fill),
        border=None if value.border is None else _border(value.border),
        alignment=None if value.alignment is None else _alignment(value.alignment),
        numFmt=(
            None
            if value.number_format is None
            else NumberFormat(numFmtId=164, formatCode=value.number_format)
        ),
    )


def _rule(value: ConditionalFormattingRulePatch, priority: int) -> Rule:
    from openpyxl.formatting.rule import Rule

    arguments: dict[str, Any] = {
        "type": value.rule_type,
        "priority": priority,
        "stopIfTrue": value.stop_if_true,
        "formula": list(value.formulas),
        "dxf": _differential_style(value.differential_format),
    }
    arguments.update(
        {
            name: item
            for name, item in {
                "operator": value.operator,
                "text": value.text,
                "rank": value.rank,
                "bottom": value.bottom,
            }.items()
            if item is not None
        }
    )
    return Rule(**arguments)


def _replace_rule_set(
    worksheet: Worksheet,
    patch: WorksheetConditionalFormattingPatch,
) -> None:
    from openpyxl.formatting.formatting import ConditionalFormattingList

    replacement = ConditionalFormattingList()
    priority = 1
    for block in patch.blocks:
        cell_ranges = " ".join(block.cell_ranges)
        for requested_rule in block.rules:
            replacement.add(cell_ranges, _rule(requested_rule, priority))
            priority += 1
    worksheet.conditional_formatting = replacement


def apply_conditional_formatting_patches(
    workbook: Workbook,
    patches: Sequence[WorksheetConditionalFormattingPatch],
) -> tuple[_PendingConditionalFormattingChange, ...]:
    """Replace requested worksheet rule sets and retain all verification evidence."""
    evidence: list[_PendingConditionalFormattingChange] = []
    for patch in patches:
        worksheet = _worksheet(workbook, patch.sheet_name)
        old_state = _rule_set_state(worksheet)
        old_rule_count = _rule_count(worksheet)
        _replace_rule_set(worksheet, patch)
        new_state = _rule_set_state(worksheet)
        new_rule_count = _rule_count(worksheet)
        evidence.append(
            _PendingConditionalFormattingChange(
                sheet_name=worksheet.title,
                old_rule_count=old_rule_count,
                new_rule_count=new_rule_count,
                old_rule_set_fingerprint=_fingerprint(old_state),
                new_rule_set_fingerprint=_fingerprint(new_state),
            )
        )
    return tuple(evidence)


def verify_conditional_formatting_patches(
    workbook: Workbook,
    evidence: Sequence[_PendingConditionalFormattingChange],
) -> None:
    """Verify each requested rule set from the reopened output workbook."""
    for expected in evidence:
        worksheet = _worksheet(workbook, expected.sheet_name)
        state = _rule_set_state(worksheet)
        if (
            _rule_count(worksheet) != expected.new_rule_count
            or _fingerprint(state) != expected.new_rule_set_fingerprint
        ):
            msg = "Patched workbook conditional-formatting verification failed"
            raise ExcelModificationError(msg)

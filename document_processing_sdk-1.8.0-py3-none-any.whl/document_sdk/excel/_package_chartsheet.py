"""Bounded Chartsheet structure and relationship-closure inspection."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from document_sdk.excel._package_security import (
    _local_name,
    _relationship_part,
    _relationships,
    _SafePackage,
    _validate_member_name,
)
from document_sdk.excel._package_worksheet import (
    _SPREADSHEETML_WORKSHEET_NAMESPACES,
)
from document_sdk.excel.models import ChartsheetFeatureInventory

if TYPE_CHECKING:
    from collections.abc import Mapping
    from xml.etree.ElementTree import Element

    from document_sdk.excel._package_types import _Relationship, _SheetRecord


_OFFICE_RELATIONSHIP_NAMESPACES = frozenset(
    {
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
        "http://purl.oclc.org/ooxml/officeDocument/relationships",
    }
)
_DRAWING_NAMESPACES = frozenset(
    {
        "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing",
        "http://purl.oclc.org/ooxml/drawingml/spreadsheetDrawing",
    }
)
_CHART_NAMESPACES = frozenset(
    {
        "http://schemas.openxmlformats.org/drawingml/2006/chart",
        "http://purl.oclc.org/ooxml/drawingml/chart",
    }
)
_CONTENT_TYPES_NAMESPACE = (
    "http://schemas.openxmlformats.org/package/2006/content-types"
)
_PACKAGE_RELATIONSHIPS_NAMESPACE = (
    "http://schemas.openxmlformats.org/package/2006/relationships"
)
_CHART_CONTENT_TYPE = (
    "application/vnd.openxmlformats-officedocument.drawingml.chart+xml"
)
_CHARTSHEET_CONTENT_TYPE = (
    "application/vnd.openxmlformats-officedocument.spreadsheetml.chartsheet+xml"
)
_DRAWING_CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.drawing+xml"
_PRINTER_SETTINGS_CONTENT_TYPE = (
    "application/vnd.openxmlformats-officedocument.spreadsheetml.printerSettings"
)


@dataclass(frozen=True, slots=True)
class _ChartsheetFacts:
    """Public inventory plus private package-closure preservation evidence."""

    inventory: ChartsheetFeatureInventory
    relationship_edges: tuple[tuple[str, str, str, str | None, bool], ...]
    closure_members: tuple[str, ...]


def _namespace(tag: str) -> str:
    return tag.partition("}")[0].lstrip("{") if "}" in tag else ""


def _direct_children(root: Element, name: str, namespace: str) -> tuple[Element, ...]:
    return tuple(
        child
        for child in root
        if _local_name(child.tag) == name and _namespace(child.tag) == namespace
    )


def _relationship_references(root: Element) -> frozenset[str]:
    references: set[str] = set()
    for element in root.iter():
        for name, value in element.attrib.items():
            if (
                _namespace(name) in _OFFICE_RELATIONSHIP_NAMESPACES
                and _local_name(name) in {"id", "embed", "link"}
                and value
            ):
                references.add(value)
    return frozenset(references)


def _direct_relationship_ids(
    root: Element,
    *,
    name: str,
    namespace: str,
    required: bool = True,
) -> tuple[str, ...]:
    identifiers: list[str] = []
    for child in _direct_children(root, name, namespace):
        values = [
            value
            for attribute, value in child.attrib.items()
            if _namespace(attribute) in _OFFICE_RELATIONSHIP_NAMESPACES
            and _local_name(attribute) == "id"
            and value
        ]
        if len(values) > 1 or (required and not values):
            msg = "Chartsheet relationship reference is invalid"
            raise ValueError(msg)
        if values:
            identifiers.append(values[0])
    return tuple(identifiers)


def _relationship_suffix(value: str) -> str:
    return value.rsplit("/", 1)[-1].casefold()


def _content_types(package: _SafePackage) -> tuple[dict[str, str], dict[str, str]]:
    root = package.read_xml("[Content_Types].xml")
    if _local_name(root.tag) != "Types" or _namespace(root.tag) != (
        _CONTENT_TYPES_NAMESPACE
    ):
        msg = "Workbook content types are invalid"
        raise ValueError(msg)
    defaults: dict[str, str] = {}
    overrides: dict[str, str] = {}
    for element in root:
        if _namespace(element.tag) != _CONTENT_TYPES_NAMESPACE:
            continue
        local_name = _local_name(element.tag)
        content_type = element.attrib.get("ContentType", "")
        if local_name == "Default":
            extension = element.attrib.get("Extension", "").casefold()
            if not extension or not content_type or extension in defaults:
                msg = "Workbook content types are invalid"
                raise ValueError(msg)
            defaults[extension] = content_type
        elif local_name == "Override":
            raw_member = element.attrib.get("PartName", "")
            member = raw_member[1:] if raw_member.startswith("/") else ""
            try:
                _validate_member_name(member)
            except ValueError:
                member = ""
            if (
                not member
                or raw_member != f"/{member}"
                or not content_type
                or member in overrides
            ):
                msg = "Workbook content types are invalid"
                raise ValueError(msg)
            overrides[member] = content_type
    return defaults, overrides


def _part_content_type(
    member: str,
    content_types: tuple[Mapping[str, str], Mapping[str, str]],
) -> str:
    defaults, overrides = content_types
    content_type = overrides.get(member)
    if content_type is None:
        extension = member.rsplit(".", 1)[-1].casefold() if "." in member else ""
        content_type = defaults.get(extension)
    if content_type is None:
        msg = "Chartsheet relationship target has no content type"
        raise ValueError(msg)
    return content_type


def _internal_target(  # noqa: PLR0913 - target constraints stay explicit at callers.
    package: _SafePackage,
    relationships: Mapping[str, _Relationship],
    relationship_id: str,
    *,
    expected_suffix: str,
    content_types: tuple[Mapping[str, str], Mapping[str, str]] | None = None,
    target_prefix: str | None = None,
    expected_content_type: str | None = None,
    require_image_content_type: bool = False,
) -> str:
    relationship = relationships.get(relationship_id)
    if relationship is None:
        msg = "Chartsheet relationship reference does not exist"
        raise ValueError(msg)
    relationship_type = relationship.relationship_type
    target = relationship.target
    if (
        relationship.external
        or _relationship_suffix(relationship_type) != expected_suffix.casefold()
        or not isinstance(target, str)
        or not package.has(target)
    ):
        msg = "Chartsheet internal relationship target is invalid"
        raise ValueError(msg)
    if target_prefix is not None and not target.casefold().startswith(
        target_prefix.casefold()
    ):
        msg = "Chartsheet internal relationship target type is invalid"
        raise ValueError(msg)
    if content_types is not None:
        content_type = _part_content_type(target, content_types)
        if expected_content_type is not None and content_type != expected_content_type:
            msg = "Chartsheet relationship target content type is invalid"
            raise ValueError(msg)
        if require_image_content_type and not content_type.casefold().startswith(
            "image/"
        ):
            msg = "Chartsheet image target content type is invalid"
            raise ValueError(msg)
    return target


def _validate_image_relationship(
    package: _SafePackage,
    relationships: Mapping[str, _Relationship],
    relationship_id: str,
    *,
    content_types: tuple[Mapping[str, str], Mapping[str, str]],
) -> None:
    relationship = relationships.get(relationship_id)
    if (
        relationship is None
        or _relationship_suffix(relationship.relationship_type) != "image"
    ):
        msg = "Chartsheet image relationship is invalid"
        raise ValueError(msg)
    if relationship.external:
        return
    _internal_target(
        package,
        relationships,
        relationship_id,
        expected_suffix="image",
        content_types=content_types,
        target_prefix="xl/media/",
        require_image_content_type=True,
    )


def _validate_chart_relationships(
    package: _SafePackage,
    chart_part: str,
    chart_root: Element,
) -> None:
    relationships = _relationships(package, chart_part)
    references = _relationship_references(chart_root)
    if any(reference not in relationships for reference in references):
        msg = "Chartsheet chart relationship reference does not exist"
        raise ValueError(msg)
    for reference in references:
        relationship = relationships[reference]
        if relationship.external:
            continue
        target = relationship.target
        if target is None or not package.has(target):
            msg = "Chartsheet chart relationship target is missing"
            raise ValueError(msg)


def _raw_relationship_targets(
    package: _SafePackage,
    relationship_part: str,
    *,
    expected_ids: frozenset[str],
) -> dict[str, str]:
    """Return exact direct relationship targets without descendant shadowing."""
    root = package.read_xml(relationship_part)
    if root.tag != f"{{{_PACKAGE_RELATIONSHIPS_NAMESPACE}}}Relationships":
        msg = "Chartsheet DrawingML relationships are invalid"
        raise ValueError(msg)
    targets: dict[str, str] = {}
    for element in root:
        if element.tag != f"{{{_PACKAGE_RELATIONSHIPS_NAMESPACE}}}Relationship" or len(
            element
        ):
            msg = "Chartsheet DrawingML relationship declaration is invalid"
            raise ValueError(msg)
        relationship_id = element.attrib.get("Id")
        target = element.attrib.get("Target")
        if not relationship_id or not target or relationship_id in targets:
            msg = "Chartsheet DrawingML relationship declaration is invalid"
            raise ValueError(msg)
        targets[relationship_id] = target
    if set(targets) != expected_ids:
        msg = "Chartsheet DrawingML relationship declarations are incomplete"
        raise ValueError(msg)
    return targets


def _relationship_closure(
    package: _SafePackage,
    source_part: str,
) -> tuple[
    tuple[tuple[str, str, str, str | None, bool], ...],
    tuple[str, ...],
    int,
]:
    pending = [source_part]
    visited: set[str] = set()
    members = {source_part}
    edges: list[tuple[str, str, str, str | None, bool]] = []
    external_count = 0
    while pending:
        source = pending.pop()
        if source in visited:
            continue
        visited.add(source)
        relationship_member = _relationship_part(source)
        if package.has(relationship_member):
            members.add(relationship_member)
        for relationship_id, relationship in _relationships(package, source).items():
            edge = (
                source,
                relationship_id,
                relationship.relationship_type,
                relationship.target,
                relationship.external,
            )
            edges.append(edge)
            if relationship.external:
                external_count += 1
                continue
            target = relationship.target
            if target is None or not package.has(target):
                msg = "Chartsheet relationship closure contains a missing target"
                raise ValueError(msg)
            members.add(target)
            pending.append(target)
    return tuple(sorted(edges)), tuple(sorted(members)), external_count


def _validate_drawing(
    package: _SafePackage,
    drawing_part: str,
    *,
    content_types: tuple[Mapping[str, str], Mapping[str, str]],
) -> frozenset[str]:
    root = package.read_xml(drawing_part)
    if (
        _local_name(root.tag) != "wsDr"
        or _namespace(root.tag) not in _DRAWING_NAMESPACES
    ):
        msg = "Chartsheet DrawingML part is invalid"
        raise ValueError(msg)
    relationships = _relationships(package, drawing_part)
    references = _relationship_references(root)
    if any(reference not in relationships for reference in references):
        msg = "Chartsheet DrawingML relationship reference does not exist"
        raise ValueError(msg)
    raw_targets = (
        _raw_relationship_targets(
            package,
            _relationship_part(drawing_part),
            expected_ids=frozenset(relationships),
        )
        if relationships
        else {}
    )
    chart_parts: set[str] = set()
    for relationship_id in references:
        relationship = relationships[relationship_id]
        relationship_suffix = _relationship_suffix(relationship.relationship_type)
        if relationship_suffix == "image":
            _validate_image_relationship(
                package,
                relationships,
                relationship_id,
                content_types=content_types,
            )
            continue
        if relationship_suffix != "chart":
            if not relationship.external and (
                relationship.target is None or not package.has(relationship.target)
            ):
                msg = "Chartsheet DrawingML relationship target is missing"
                raise ValueError(msg)
            continue
        chart_part = _internal_target(
            package,
            relationships,
            relationship_id,
            expected_suffix="chart",
            content_types=content_types,
            expected_content_type=_CHART_CONTENT_TYPE,
        )
        if ":" in chart_part or raw_targets[relationship_id].startswith("//"):
            msg = "Chartsheet chart target must be an internal package part"
            raise ValueError(msg)
        chart_root = package.read_xml(chart_part)
        if (
            _local_name(chart_root.tag) != "chartSpace"
            or _namespace(chart_root.tag) not in _CHART_NAMESPACES
        ):
            msg = "Chartsheet chart target is invalid"
            raise ValueError(msg)
        _validate_chart_relationships(package, chart_part, chart_root)
        chart_parts.add(chart_part)
    return frozenset(chart_parts)


def _chartsheet_facts(
    package: _SafePackage,
    *,
    sheet: _SheetRecord,
    workbook_order: int,
) -> _ChartsheetFacts:
    """Validate one Chartsheet and return bounded deterministic facts."""
    part = sheet.part_name
    if sheet.sheet_type != "chartsheet" or part is None or not package.has(part):
        msg = "Chartsheet package part is missing"
        raise ValueError(msg)
    root = package.read_xml(part)
    namespace = _namespace(root.tag)
    if (
        _local_name(root.tag) != "chartsheet"
        or namespace not in _SPREADSHEETML_WORKSHEET_NAMESPACES
    ):
        msg = "Chartsheet SpreadsheetML part is invalid"
        raise ValueError(msg)

    content_types = _content_types(package)
    if (
        not part.casefold().startswith("xl/chartsheets/")
        or _part_content_type(
            part,
            content_types,
        )
        != _CHARTSHEET_CONTENT_TYPE
    ):
        msg = "Chartsheet package part content type is invalid"
        raise ValueError(msg)
    relationships = _relationships(package, part)
    references = _relationship_references(root)
    if any(reference not in relationships for reference in references):
        msg = "Chartsheet relationship reference does not exist"
        raise ValueError(msg)

    drawing_ids = _direct_relationship_ids(
        root,
        name="drawing",
        namespace=namespace,
    )
    picture_ids = _direct_relationship_ids(
        root,
        name="picture",
        namespace=namespace,
    )
    page_setup_ids = _direct_relationship_ids(
        root,
        name="pageSetup",
        namespace=namespace,
        required=False,
    )
    drawing_parts = {
        _internal_target(
            package,
            relationships,
            relationship_id,
            expected_suffix="drawing",
            content_types=content_types,
            target_prefix="xl/drawings/",
            expected_content_type=_DRAWING_CONTENT_TYPE,
        )
        for relationship_id in drawing_ids
    }
    for relationship_id in picture_ids:
        _validate_image_relationship(
            package,
            relationships,
            relationship_id,
            content_types=content_types,
        )
    for relationship_id in page_setup_ids:
        _internal_target(
            package,
            relationships,
            relationship_id,
            expected_suffix="printersettings",
            content_types=content_types,
            target_prefix="xl/printersettings/",
            expected_content_type=_PRINTER_SETTINGS_CONTENT_TYPE,
        )

    chart_parts: set[str] = set()
    for drawing_part in drawing_parts:
        chart_parts.update(
            _validate_drawing(
                package,
                drawing_part,
                content_types=content_types,
            )
        )
    edges, closure_members, external_count = _relationship_closure(package, part)

    inventory = ChartsheetFeatureInventory(
        name=sheet.name,
        workbook_order=workbook_order,
        visibility=sheet.visibility,
        part_present=True,
        drawing_relationship_count=len(drawing_ids),
        drawing_part_count=len(drawing_parts),
        chart_part_count=len(chart_parts),
        printer_settings_present=bool(page_setup_ids),
        page_margins_present=bool(_direct_children(root, "pageMargins", namespace)),
        page_setup_present=bool(_direct_children(root, "pageSetup", namespace)),
        header_footer_present=bool(_direct_children(root, "headerFooter", namespace)),
        sheet_protection_present=bool(
            _direct_children(root, "sheetProtection", namespace)
        ),
        external_relationship_count=external_count,
    )
    return _ChartsheetFacts(
        inventory=inventory,
        relationship_edges=edges,
        closure_members=closure_members,
    )

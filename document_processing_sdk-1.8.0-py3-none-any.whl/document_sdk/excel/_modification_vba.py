"""Opaque VBA package and macro-reachability evidence."""

from __future__ import annotations

import posixpath
from dataclasses import dataclass
from hashlib import sha256
from typing import TYPE_CHECKING

from document_sdk.excel._package import _SafePackage
from document_sdk.excel._package_security import _local_name

if TYPE_CHECKING:
    from pathlib import Path
    from xml.etree.ElementTree import Element


_HASH_CHUNK_SIZE = 1024 * 1024
_CONTENT_TYPES_MEMBER = "[Content_Types].xml"
_WORKBOOK_RELATIONSHIPS_MEMBER = "xl/_rels/workbook.xml.rels"
_WORKBOOK_PART = "xl/workbook.xml"
_VBA_PROJECT_PART = "xl/vbaproject.bin"
_MACRO_WORKBOOK_CONTENT_TYPE = "application/vnd.ms-excel.sheet.macroenabled.main+xml"
_VBA_PROJECT_CONTENT_TYPE = "application/vnd.ms-office.vbaproject"
_VBA_PROJECT_RELATIONSHIP_TYPE = (
    "http://schemas.microsoft.com/office/2006/relationships/vbaproject"
)


@dataclass(frozen=True, slots=True)
class _VbaPartEvidence:
    """Opaque VBA hashes plus normalized package reachability evidence."""

    parts: tuple[tuple[str, str], ...]
    workbook_content_types: tuple[str, ...]
    vba_content_types: tuple[str, ...]
    vba_relationships: tuple[tuple[str, str, bool], ...]


def _normalized_type(value: str) -> str:
    return value.strip().casefold()


def _normalized_part_name(value: str) -> str | None:
    candidate = value.strip()
    if not candidate or "\\" in candidate:
        return None
    normalized = posixpath.normpath(candidate.lstrip("/"))
    if normalized in {"", ".", ".."} or normalized.startswith("../"):
        return None
    return normalized.casefold()


def _normalized_relationship_target(value: str) -> str | None:
    candidate = value.strip()
    if not candidate or "\\" in candidate:
        return None
    if candidate.startswith("/"):
        normalized = posixpath.normpath(candidate.lstrip("/"))
    else:
        normalized = posixpath.normpath(
            posixpath.join(posixpath.dirname(_WORKBOOK_PART), candidate)
        )
    if normalized in {"", ".", ".."} or normalized.startswith("../"):
        return None
    return normalized.casefold()


def _content_type_evidence(
    root: Element | None,
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    if root is None:
        return (), ()
    workbook_types: list[str] = []
    vba_override_types: list[str] = []
    vba_default_types: list[str] = []
    for element in root.iter():
        local_name = _local_name(element.tag)
        content_type = element.attrib.get("ContentType")
        if content_type is None:
            continue
        normalized_type = _normalized_type(content_type)
        if local_name == "Override":
            part_name = _normalized_part_name(element.attrib.get("PartName", ""))
            if part_name == _WORKBOOK_PART:
                workbook_types.append(normalized_type)
            if part_name == _VBA_PROJECT_PART:
                vba_override_types.append(normalized_type)
        elif local_name == "Default":
            extension = (
                element.attrib.get("Extension", "").strip().lstrip(".").casefold()
            )
            if extension == "bin":
                vba_default_types.append(normalized_type)
    effective_vba_types = vba_override_types or vba_default_types
    return tuple(sorted(workbook_types)), tuple(sorted(effective_vba_types))


def _relationship_evidence(
    root: Element | None,
) -> tuple[tuple[str, str, bool], ...]:
    if root is None:
        return ()
    relationships: list[tuple[str, str, bool]] = []
    for element in root.iter():
        if _local_name(element.tag) != "Relationship":
            continue
        relationship_type = _normalized_type(element.attrib.get("Type", ""))
        target = _normalized_relationship_target(element.attrib.get("Target", ""))
        if (
            relationship_type == _VBA_PROJECT_RELATIONSHIP_TYPE
            or target == _VBA_PROJECT_PART
        ):
            relationships.append(
                (
                    target or "<invalid>",
                    relationship_type,
                    element.attrib.get("TargetMode", "").casefold() == "external",
                )
            )
    return tuple(sorted(relationships))


def _opaque_vba_hashes(package: _SafePackage) -> tuple[tuple[str, str], ...]:
    """Hash opaque VBA-related parts through one preflighted package."""
    hashed_parts: list[tuple[str, str]] = []
    for member in sorted(
        name for name in package.names if name.lower().startswith("xl/vba")
    ):
        digest = sha256()
        with package.open_member(member) as stream:
            while chunk := stream.read(_HASH_CHUNK_SIZE):
                digest.update(chunk)
        hashed_parts.append((member, digest.hexdigest()))
    return tuple(hashed_parts)


def _vba_part_evidence(
    path: Path,
    *,
    expected_fingerprint: str | None = None,
) -> _VbaPartEvidence:
    """Collect hashes and normalized OOXML declarations without parsing VBA."""
    with _SafePackage(path) as package:
        if expected_fingerprint is not None:
            package.verify_fingerprint(expected_fingerprint)
        content_types = (
            package.read_xml(_CONTENT_TYPES_MEMBER)
            if package.has(_CONTENT_TYPES_MEMBER)
            else None
        )
        relationships = (
            package.read_xml(_WORKBOOK_RELATIONSHIPS_MEMBER)
            if package.has(_WORKBOOK_RELATIONSHIPS_MEMBER)
            else None
        )
        workbook_types, vba_types = _content_type_evidence(content_types)
        return _VbaPartEvidence(
            parts=_opaque_vba_hashes(package),
            workbook_content_types=workbook_types,
            vba_content_types=vba_types,
            vba_relationships=_relationship_evidence(relationships),
        )


def _vba_evidence_issues(
    evidence: _VbaPartEvidence | None,
) -> tuple[str, ...]:
    """Return internal issue categories for incomplete macro reachability."""
    if evidence is None:
        return ("missing_evidence",)
    issues: list[str] = []
    if _VBA_PROJECT_PART not in {
        part_name.casefold() for part_name, _digest in evidence.parts
    }:
        issues.append("vba_project_part")
    if evidence.workbook_content_types != (_MACRO_WORKBOOK_CONTENT_TYPE,):
        issues.append("macro_workbook_content_type")

    if evidence.vba_content_types != (_VBA_PROJECT_CONTENT_TYPE,):
        issues.append("vba_project_content_type")

    expected_relationship = (
        _VBA_PROJECT_PART,
        _VBA_PROJECT_RELATIONSHIP_TYPE,
        False,
    )
    if evidence.vba_relationships != (expected_relationship,):
        issues.append("vba_project_relationship")
    return tuple(issues)


def _has_vba_project_evidence(evidence: _VbaPartEvidence) -> bool:
    """Return whether any project part, content type, or relationship is present."""
    return bool(
        evidence.parts or evidence.vba_content_types or evidence.vba_relationships
    )

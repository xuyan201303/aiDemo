# ruff: noqa: BLE001, PLR0913
"""Bounded, deterministic streaming for local OOXML worksheets."""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

from document_sdk.core import (
    DocumentProcessingError,
    DocumentSdkError,
    ExcelCell,
    ExcelCellLimitExceededError,
    ExcelSourceReference,
    FileDescriptor,
)
from document_sdk.core._excel_coordinates import (
    ExcelRangeBounds,
    excel_column_letter,
    excel_range_bounds,
)
from document_sdk.core.errors import _raise_redacted_translation, safe_file_label
from document_sdk.excel._dependencies import require_excel_support
from document_sdk.excel._helpers import (
    inspect_excel_input,
    validate_excel_package_limits,
)
from document_sdk.excel._ooxml import inspect_ooxml_worksheet
from document_sdk.excel._streaming_ooxml import _RawCell, _represented_cells
from document_sdk.excel.errors import ExcelPackageLimitError
from document_sdk.excel.models import (
    FormulaView,
    WorksheetRow,
)

if TYPE_CHECKING:
    from collections.abc import Iterator
    from pathlib import Path

    from document_sdk.excel.models import ExcelPackageLimits


DEFAULT_MAX_STREAM_CELLS = 1_000_000
DEFAULT_MAX_STREAM_ROWS = 100_000
DEFAULT_STREAM_BATCH_SIZE = 1_000


@runtime_checkable
class _ClosableIterator(Protocol):
    """Iterator resource that supports deterministic early closure."""

    def close(self) -> None:
        """Close resources owned by the iterator."""


def _positive_int(value: int, name: str) -> int:
    """Validate a positive integer without accepting booleans."""
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        msg = f"{name} must be a positive integer"
        raise ValueError(msg)
    return value


def _formula_view(value: FormulaView) -> FormulaView:
    """Validate a runtime formula-view argument."""
    if value not in {"both", "formula", "cached"}:
        msg = "formula_view must be 'both', 'formula', or 'cached'"
        raise ValueError(msg)
    return value


def _inspect_streaming_input(
    path: Path,
    *,
    package_limits: ExcelPackageLimits | None = None,
) -> FileDescriptor:
    """Inspect an XLSX/XLSM input and run the central package preflight."""
    return inspect_excel_input(path, package_limits=package_limits)


def _within_bounds(coordinate: str, bounds: ExcelRangeBounds | None) -> bool:
    """Return whether a coordinate is inside optional inclusive bounds."""
    if bounds is None:
        return True
    coordinate_bounds = excel_range_bounds(coordinate)
    return (
        bounds.min_row <= coordinate_bounds.min_row <= bounds.max_row
        and bounds.min_column <= coordinate_bounds.min_column <= bounds.max_column
    )


def _public_cell(
    raw: _RawCell,
    *,
    descriptor: FileDescriptor,
    sheet_name: str,
    formula_view: FormulaView,
) -> ExcelCell:
    """Project one raw cell into the requested formula view."""
    source = ExcelSourceReference(
        file_id=descriptor.file_id,
        sheet_name=sheet_name,
        cell_range=raw.coordinate,
    )
    if raw.formula is None:
        return ExcelCell(
            coordinate=raw.coordinate,
            value=raw.value,
            temporal_source=raw.temporal_source,
            data_type=raw.data_type,
            style_id=raw.style_id,
            number_format=raw.number_format,
            source=source,
        )
    if formula_view == "cached":
        return ExcelCell(
            coordinate=raw.coordinate,
            value=raw.cached_value,
            temporal_source=raw.temporal_source,
            cached_value=raw.cached_value if raw.has_cached_value else None,
            has_cached_value=raw.has_cached_value,
            formula_kind=raw.formula_kind or "ordinary",
            external_reference=raw.external_reference,
            requires_recalculation=True,
            data_type=f"formula_cache:{raw.cached_data_type}",
            style_id=raw.style_id,
            number_format=raw.number_format,
            source=source,
        )
    return ExcelCell(
        coordinate=raw.coordinate,
        formula=raw.formula,
        cached_value=(raw.cached_value if formula_view == "both" else None),
        temporal_source=raw.temporal_source if formula_view == "both" else None,
        has_cached_value=raw.has_cached_value,
        formula_kind=raw.formula_kind or "ordinary",
        external_reference=raw.external_reference,
        requires_recalculation=True,
        data_type="formula",
        style_id=raw.style_id,
        number_format=raw.number_format,
        source=source,
    )


def _close_iterator(iterator: Iterator[object]) -> None:
    """Close a nested generator when its consumer stops early."""
    if isinstance(iterator, _ClosableIterator):
        iterator.close()


def _iter_non_empty_cells(
    path: Path,
    descriptor: FileDescriptor,
    sheet_name: str,
    *,
    bounds: ExcelRangeBounds | None,
    max_cells: int,
    batch_size: int,
    formula_view: FormulaView,
    package_limits: ExcelPackageLimits | None = None,
) -> Iterator[ExcelCell]:
    """Project bounded raw cells while retaining parser early closure."""
    records = _represented_cells(
        path,
        sheet_name,
        expected_fingerprint=descriptor.fingerprint.value,
        selected_ranges=() if bounds is None else (bounds,),
        package_limits=package_limits,
    )
    observed = 0
    batch: list[ExcelCell] = []
    try:
        for raw in records:
            if not raw.has_content or not _within_bounds(raw.coordinate, bounds):
                continue
            observed += 1
            if observed > max_cells:
                raise ExcelCellLimitExceededError(
                    requested_cells=observed,
                    max_cells=max_cells,
                )
            batch.append(
                _public_cell(
                    raw,
                    descriptor=descriptor,
                    sheet_name=sheet_name,
                    formula_view=formula_view,
                )
            )
            if len(batch) == batch_size:
                yield from batch
                batch.clear()
        yield from batch
    finally:
        _close_iterator(records)


def iter_non_empty_cells(
    path: Path,
    sheet_name: str,
    *,
    cell_range: str | None = None,
    max_cells: int = DEFAULT_MAX_STREAM_CELLS,
    batch_size: int = DEFAULT_STREAM_BATCH_SIZE,
    formula_view: FormulaView = "both",
    package_limits: ExcelPackageLimits | None = None,
) -> Iterator[ExcelCell]:
    """Stream represented non-empty cells in stable row-major order.

    The configured limit counts yielded cells rather than the rectangular
    distance between them, so sparse sheets remain sparse. Formula caches are
    read from OOXML and are never calculated.
    """
    require_excel_support()
    validated_limit = _positive_int(max_cells, "max_cells")
    validated_batch = _positive_int(batch_size, "batch_size")
    validated_view = _formula_view(formula_view)
    bounds = None if cell_range is None else excel_range_bounds(cell_range)
    validated_package_limits = validate_excel_package_limits(package_limits)
    descriptor = _inspect_streaming_input(
        path,
        package_limits=validated_package_limits,
    )
    return _iter_non_empty_cells(
        path,
        descriptor,
        sheet_name,
        bounds=bounds,
        max_cells=validated_limit,
        batch_size=validated_batch,
        formula_view=validated_view,
        package_limits=validated_package_limits,
    )


def _sparse_rows(
    cells: Iterator[ExcelCell],
    *,
    max_rows: int,
) -> Iterator[WorksheetRow]:
    """Group sparse cells without constructing omitted rows or columns."""
    current_row: int | None = None
    current_cells: list[ExcelCell] = []
    observed_rows = 0
    try:
        for cell in cells:
            row = excel_range_bounds(cell.coordinate).min_row
            if current_row is not None and row != current_row:
                observed_rows += 1
                if observed_rows > max_rows:
                    raise ExcelPackageLimitError(
                        limit_name="streamed_rows",
                        observed=observed_rows,
                        maximum=max_rows,
                    )
                yield WorksheetRow(
                    row_number=current_row,
                    cells=tuple(current_cells),
                )
                current_cells = []
            current_row = row
            current_cells.append(cell)
        if current_row is not None:
            observed_rows += 1
            if observed_rows > max_rows:
                raise ExcelPackageLimitError(
                    limit_name="streamed_rows",
                    observed=observed_rows,
                    maximum=max_rows,
                )
            yield WorksheetRow(
                row_number=current_row,
                cells=tuple(current_cells),
            )
    finally:
        _close_iterator(cells)


def _empty_cell(
    *,
    descriptor: FileDescriptor,
    sheet_name: str,
    coordinate: str,
) -> ExcelCell:
    """Create an explicit bounded empty cell for dense row iteration."""
    return ExcelCell(
        coordinate=coordinate,
        value=None,
        data_type="n",
        source=ExcelSourceReference(
            file_id=descriptor.file_id,
            sheet_name=sheet_name,
            cell_range=coordinate,
        ),
    )


def _dense_rows(
    cells: Iterator[ExcelCell],
    *,
    descriptor: FileDescriptor,
    sheet_name: str,
    bounds: ExcelRangeBounds,
) -> Iterator[WorksheetRow]:
    """Fill one explicitly bounded rectangle while retaining early closure."""
    current = next(cells, None)
    try:
        for row in range(bounds.min_row, bounds.max_row + 1):
            row_cells: list[ExcelCell] = []
            for column in range(bounds.min_column, bounds.max_column + 1):
                coordinate = f"{excel_column_letter(column)}{row}"
                if current is not None and current.coordinate == coordinate:
                    row_cells.append(current)
                    current = next(cells, None)
                else:
                    row_cells.append(
                        _empty_cell(
                            descriptor=descriptor,
                            sheet_name=sheet_name,
                            coordinate=coordinate,
                        )
                    )
            yield WorksheetRow(row_number=row, cells=tuple(row_cells))
    finally:
        _close_iterator(cells)


def _used_bounds(
    path: Path,
    sheet_name: str,
    *,
    expected_fingerprint: str,
) -> ExcelRangeBounds | None:
    """Return sparse non-empty bounds for implicit dense iteration."""
    try:
        structure = inspect_ooxml_worksheet(
            path,
            sheet_name,
            expected_fingerprint=expected_fingerprint,
        )
        if structure is not None:
            return (
                None
                if structure.used_range is None
                else excel_range_bounds(structure.used_range)
            )
    except DocumentSdkError:
        raise
    except Exception as exc:
        msg = f"Unable to stream workbook: {safe_file_label(path)}"
        _raise_redacted_translation(exc, DocumentProcessingError(msg))
    msg = f"Worksheet does not exist: {sheet_name}"
    raise DocumentProcessingError(msg)


def iter_rows(
    path: Path,
    sheet_name: str,
    *,
    cell_range: str | None = None,
    max_cells: int = DEFAULT_MAX_STREAM_CELLS,
    max_rows: int = DEFAULT_MAX_STREAM_ROWS,
    batch_size: int = DEFAULT_STREAM_BATCH_SIZE,
    include_empty: bool = False,
    formula_view: FormulaView = "both",
    package_limits: ExcelPackageLimits | None = None,
) -> Iterator[WorksheetRow]:
    """Stream worksheet rows with explicit cell and row safety bounds.

    By default only rows and cells represented by non-empty OOXML values are
    yielded. ``include_empty=True`` deliberately fills a bounded rectangle
    after checking both limits before cell iteration.
    """
    require_excel_support()
    validated_cells = _positive_int(max_cells, "max_cells")
    validated_rows = _positive_int(max_rows, "max_rows")
    validated_batch = _positive_int(batch_size, "batch_size")
    validated_view = _formula_view(formula_view)
    validated_package_limits = validate_excel_package_limits(package_limits)
    explicit_bounds = None if cell_range is None else excel_range_bounds(cell_range)
    descriptor = _inspect_streaming_input(
        path,
        package_limits=validated_package_limits,
    )

    if not include_empty:
        cells = _iter_non_empty_cells(
            path,
            descriptor,
            sheet_name,
            bounds=explicit_bounds,
            max_cells=validated_cells,
            batch_size=validated_batch,
            formula_view=validated_view,
            package_limits=validated_package_limits,
        )
        return _sparse_rows(cells, max_rows=validated_rows)

    bounds = explicit_bounds or _used_bounds(
        path,
        sheet_name,
        expected_fingerprint=descriptor.fingerprint.value,
    )
    if bounds is None:
        return iter(())
    row_count = bounds.max_row - bounds.min_row + 1
    if row_count > validated_rows:
        raise ExcelPackageLimitError(
            limit_name="streamed_rows",
            observed=row_count,
            maximum=validated_rows,
        )
    if bounds.cell_count > validated_cells:
        raise ExcelCellLimitExceededError(
            requested_cells=bounds.cell_count,
            max_cells=validated_cells,
        )
    cells = _iter_non_empty_cells(
        path,
        descriptor,
        sheet_name,
        bounds=bounds,
        max_cells=validated_cells,
        batch_size=validated_batch,
        formula_view=validated_view,
        package_limits=validated_package_limits,
    )
    return _dense_rows(
        cells,
        descriptor=descriptor,
        sheet_name=sheet_name,
        bounds=bounds,
    )

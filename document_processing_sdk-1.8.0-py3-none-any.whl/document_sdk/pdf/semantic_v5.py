"""Opt-in semantic PDF view; candidates are never author intent by default."""

from __future__ import annotations

import json
from dataclasses import dataclass
from hashlib import sha256
from typing import TYPE_CHECKING, Literal, NoReturn, Self

from pydantic import Field, PrivateAttr, ValidationInfo, model_validator

from document_sdk.core import InvalidSourceReferenceError
from document_sdk.core.models import SdkModel
from document_sdk.pdf._structural_engine.canonical.contracts import CanonicalDocument
from document_sdk.pdf._structural_engine.canonical.identifiers import (
    canonical_payload_bytes,
    canonical_payload_sha256,
)
from document_sdk.pdf._structural_engine.semantic.authority import (
    AuthorityArtifact,
    AuthorityEvaluationRequest,
    TrustedAuthorityPolicy,
    evaluate_authority,
)
from document_sdk.pdf._structural_engine.semantic.overlay import (
    BorderlessLatticeCandidate,
    CanonicalSemanticOverlay,
    ConfirmedTableReference,
    DocumentTableHypothesis,
    ObservableTableCandidate,
    SupplementalTableCandidate,
    TableCandidate,
    TransitionHypothesis,
    build_candidate,
    build_overlay,
    candidate_scope,
    confirmed_references,
)
from document_sdk.pdf._structural_engine.semantic.supplemental_ruled_grid import (
    supplemental_ruled_candidates,
)
from document_sdk.pdf.local_evidence_members import PdfLocalEvidenceV3
from document_sdk.pdf.unified import (
    PdfAnalysisMode,
    UnifiedPdfAnalysisOptions,
    UnifiedPdfPage,
    UnifiedPdfResult,
    _analyze_pdf_with_canonical,
    _map_canonical_document,
    _revalidate_analysis_options,
    _UnifiedPdfProvenance,
)

from ._structural_engine.semantic.supplemental_borderless_lattice import (
    supplemental_borderless_candidates,
)

if TYPE_CHECKING:
    from os import PathLike

UNIFIED_PDF_RESULT_V5_VERSION: Literal["document_sdk.pdf.unified_result.v5"] = (
    "document_sdk.pdf.unified_result.v5"
)


def _fail(message: str) -> NoReturn:
    raise ValueError(message)


class SemanticArtifactReference(SdkModel):
    """A content-addressed artifact; this reference itself confers no trust."""

    artifact_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    pointer: Literal[""] = ""


class PdfSemanticContext(SdkModel):
    """Caller input context with untrusted artifacts and separately pinned receipts.

    Applications must obtain ``trusted_policy`` from their own trusted local
    configuration, never from a PDF or an artifact submitted with that PDF.
    """

    schema_version: Literal["document_sdk.pdf.semantic_context.v1"] = (
        "document_sdk.pdf.semantic_context.v1"
    )
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    sidecars: tuple[SemanticArtifactReference, ...] = ()
    underdetermination_certificates: tuple[SemanticArtifactReference, ...] = ()
    artifacts: tuple[AuthorityArtifact, ...] = ()
    trusted_policy: TrustedAuthorityPolicy

    def references(self) -> dict[str, object]:
        """Return the evaluator's reference-only context without mixing in trust."""
        return {
            "schema_version": self.schema_version,
            "source_sha256": self.source_sha256,
            "trust_policy_sha256": self.trusted_policy.policy_sha256,
            "sidecars": [item.model_dump() for item in self.sidecars],
            "underdetermination_certificates": [
                item.model_dump() for item in self.underdetermination_certificates
            ],
        }


def authorized_context_sha256(
    source_sha256: str,
    options: UnifiedPdfAnalysisOptions,
    semantic_context: PdfSemanticContext | None,
    *,
    password_provided: bool = False,
) -> str:
    """Bind input/options/sidecars/policy without circularly hashing review receipts."""
    return canonical_payload_sha256(
        {
            "domain": "document_sdk.pdf.authorized_input_context.v1",
            "source_sha256": source_sha256,
            "options": options,
            "password_contract": "PROVIDED" if password_provided else "NONE",
            "sidecars": semantic_context.sidecars if semantic_context else (),
            "trust_policy_sha256": (
                semantic_context.trusted_policy.policy_sha256
                if semantic_context
                else None
            ),
        }
    )


@dataclass(frozen=True, slots=True)
class SemanticVerificationContext:
    """External source and caller trust required to revalidate nontrivial decisions."""

    source_bytes: bytes
    options: UnifiedPdfAnalysisOptions
    semantic_context: PdfSemanticContext | None = None
    password_provided: bool = False


class SemanticPage(SdkModel):
    """Keep page text/geometry while separating candidate and confirmed inventories."""

    page_id: str
    page_number: int
    width_points: float = Field(gt=0)
    height_points: float = Field(gt=0)
    rotation: Literal[0, 90, 180, 270]
    text: str
    availability: Literal[
        "AVAILABLE", "PARTIAL", "UNAVAILABLE", "UNSUPPORTED", "LIMITED_EVIDENCE"
    ]
    limitations: tuple[str, ...]
    table_candidate_ids: tuple[str, ...]
    table_ids: tuple[str, ...]
    legacy_page: UnifiedPdfPage


class SemanticLossReceipt(SdkModel):
    """Explicitly describe information discarded by same-call legacy projection."""

    source_sha256: str
    retained_v4_sha256: str
    candidate_ids: tuple[str, ...]
    discarded_semantic_statuses: tuple[str, ...]
    discarded_authority_ids: tuple[str, ...]
    discarded_proof_ids: tuple[str, ...]
    losses: tuple[str, ...] = (
        "candidate_semantics",
        "semantic_status",
        "authority_and_proof_fields",
    )


class UnifiedPdfResultV5(SdkModel):
    """Versioned semantic view with a complete, same-call legacy evidence base."""

    schema_version: Literal["document_sdk.pdf.unified_result.v5"] = (
        UNIFIED_PDF_RESULT_V5_VERSION
    )
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    authorized_input_context_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    document_id: str
    status: Literal["COMPLETED"]
    availability: Literal["AVAILABLE", "PARTIAL", "UNAVAILABLE"]
    page_count: int = Field(ge=0)
    warnings: tuple[str, ...]
    limitations: tuple[str, ...]
    provenance: _UnifiedPdfProvenance
    family: None = None
    family_status: Literal["REVIEW_REQUIRED"] = "REVIEW_REQUIRED"
    family_auto_assignment: Literal[False] = False
    processing_mode: Literal[PdfAnalysisMode.ADVANCED_LOCAL] = (
        PdfAnalysisMode.ADVANCED_LOCAL
    )
    candidate_inventory_state: Literal["COMPLETE", "INCOMPLETE"]
    document_table_count: Literal[0] = 0
    transition_count: Literal[0] = 0
    text: str
    pages: tuple[SemanticPage, ...]
    table_candidates: tuple[ObservableTableCandidate, ...]
    tables: tuple[ConfirmedTableReference, ...]
    document_table_candidates: tuple[DocumentTableHypothesis, ...]
    candidate_transitions: tuple[TransitionHypothesis, ...]
    document_tables: tuple[()] = ()
    transitions: tuple[()] = ()
    semantic_overlay: CanonicalSemanticOverlay
    canonical_base: CanonicalDocument
    local_evidence: PdfLocalEvidenceV3
    retained_v4_base: UnifiedPdfResult | None
    retained_v4_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    _verification: SemanticVerificationContext | None = PrivateAttr(default=None)

    @model_validator(mode="after")
    def validate_retained_content(self, info: ValidationInfo) -> Self:
        """Rebuild retained inventories and independently check authority."""
        CanonicalDocument.model_validate_json(self.canonical_base.model_dump_json())
        base = _map_canonical_document(
            self.canonical_base,
            mode=PdfAnalysisMode.ADVANCED_LOCAL,
            local_evidence=self.local_evidence,
        )
        if (
            self.source_sha256 != base.source_sha256
            or self.document_id != base.document_id
            or self.text != base.text
            or sha256(base.to_json_bytes()).hexdigest() != self.retained_v4_sha256
        ):
            _fail("v5 document differs from its unchanged Canonical/v4 base")
        if self.retained_v4_base is not None and (
            self.retained_v4_base.to_json_bytes() != base.to_json_bytes()
        ):
            _fail("retained legacy base differs from same-call evidence")
        _validate_non_table_fields(self, base)
        if self.candidate_inventory_state != _inventory_state(base):
            _fail("candidate inventory completeness claim mismatch")
        expected = _observable_candidates(
            base, self.canonical_base, self.local_evidence
        )
        if len(expected) != len(self.table_candidates) or any(
            a.observable_payload() != b.observable_payload()
            or a.candidate_id != b.candidate_id
            for a, b in zip(expected, self.table_candidates, strict=False)
        ):
            _fail("candidate inventory lost or changed observable content")
        verification = _verification_context(info.context)
        _validate_decisions(self, verification)
        if self.tables != confirmed_references(self.table_candidates):
            _fail("confirmed table inventory differs from authorized candidate subset")
        if self.pages != _pages(base, self.canonical_base, self.table_candidates):
            _fail("page candidate/confirmed inventory mismatch")
        groups, transitions = _hypotheses(self.canonical_base, self.table_candidates)
        if (self.document_table_candidates, self.candidate_transitions) != (
            groups,
            transitions,
        ):
            _fail("observable continuity hypotheses changed or were omitted")
        if self.semantic_overlay != build_overlay(
            self.source_sha256, self.canonical_base, self.table_candidates
        ):
            _fail("semantic overlay binding mismatch")
        self._verification = verification
        return self

    def to_json_bytes(self) -> bytes:
        """Revalidate aliases and proofs before deterministic, strict JSON encoding."""
        payload = self.model_dump_json()
        validated = type(self).model_validate_json(payload, context=self._verification)
        return canonical_payload_bytes(validated.model_dump(mode="json"))

    def to_json_dict(self) -> dict[str, object]:
        """Return a detached JSON-shaped copy after complete model revalidation."""
        value: dict[str, object] = json.loads(self.to_json_bytes())
        return value

    def to_v4_json_bytes(
        self,
        *,
        allow_semantic_loss: bool = False,
    ) -> tuple[bytes, SemanticLossReceipt]:
        """Project same-call v4 bytes with an explicit semantic loss receipt."""
        if allow_semantic_loss is not True:
            _fail("v4 projection requires explicit semantic loss permission")
        if self.retained_v4_base is None:
            _fail("same-call retained v4 base is unavailable")
        self.to_json_bytes()
        wire = self.retained_v4_base.to_json_bytes()
        decisions = tuple(c.semantic_assertion for c in self.table_candidates)
        return wire, SemanticLossReceipt(
            source_sha256=self.source_sha256,
            retained_v4_sha256=self.retained_v4_sha256,
            candidate_ids=tuple(c.candidate_id for c in self.table_candidates),
            discarded_semantic_statuses=tuple(d.disposition for d in decisions),
            discarded_authority_ids=tuple(
                d.authority_id for d in decisions if d.authority_id
            ),
            discarded_proof_ids=tuple(d.proof_id for d in decisions if d.proof_id),
        )


def _verification_context(value: object) -> SemanticVerificationContext | None:
    if value is None:
        return None
    if not isinstance(value, SemanticVerificationContext):
        _fail("semantic verification requires an external source/trust context")
    return value


def _observable_candidates(
    base: UnifiedPdfResult, canonical: CanonicalDocument, evidence: PdfLocalEvidenceV3
) -> tuple[ObservableTableCandidate, ...]:
    pages = {page.page_number: page for page in evidence.pages}
    table_pages = {
        table_id: page.page_number
        for page in canonical.pages
        for table_id in page.table_ids
    }
    identities = {table.table_id: table.source_identity for table in base.tables}
    if any(value is None for value in identities.values()):
        _fail("candidate source identity is unavailable")
    legacy = tuple(
        build_candidate(
            table,
            pages[table_pages[table.table_id]],
            identity,
            base.source_sha256,
        )
        for table in canonical.tables
        if (identity := identities[table.table_id]) is not None
    )
    return (
        *legacy,
        *supplemental_ruled_candidates(canonical, evidence),
        *supplemental_borderless_candidates(canonical, evidence),
    )


def _evaluate_candidate(
    candidate: ObservableTableCandidate,
    evidence: PdfLocalEvidenceV3,
    context_sha256: str,
    verification: SemanticVerificationContext,
) -> ObservableTableCandidate:
    # Physical separator evidence does not establish text ownership or author
    # intent. No authority evaluator may promote the supplemental variant.
    if isinstance(candidate, (SupplementalTableCandidate, BorderlessLatticeCandidate)):
        return candidate
    context = verification.semantic_context
    page = next(p for p in evidence.pages if p.page_number == candidate.page_number)
    decision = evaluate_authority(
        AuthorityEvaluationRequest(
            source_bytes=verification.source_bytes,
            input_sha256=candidate.source_sha256,
            expected_context_sha256=context_sha256,
            candidate=candidate_scope(candidate, page),
            semantic_context=context.references() if context else None,
            artifacts=context.artifacts if context else (),
            trusted_policy=context.trusted_policy if context else None,
        )
    )
    return TableCandidate.model_validate(
        {
            **candidate.model_dump(),
            "semantic_assertion": decision,
        }
    )


def _validate_decisions(
    result: UnifiedPdfResultV5, verification: SemanticVerificationContext | None
) -> None:
    if verification is None:
        for candidate in result.table_candidates:
            decision = candidate.semantic_assertion
            if (
                decision.disposition != "UNRESOLVED"
                or decision.authority_id is not None
                or decision.proof_id is not None
                or decision.receipt_sha256 is not None
                or decision.claim is not None
            ):
                _fail(
                    "semantic decision requires independent source and trusted receipts"
                )
        return
    if (
        sha256(verification.source_bytes).hexdigest() != result.source_sha256
        or authorized_context_sha256(
            result.source_sha256,
            verification.options,
            verification.semantic_context,
            password_provided=verification.password_provided,
        )
        != result.authorized_input_context_sha256
    ):
        _fail("semantic source or authorized context identity mismatch")
    for candidate in result.table_candidates:
        if isinstance(
            candidate, (SupplementalTableCandidate, BorderlessLatticeCandidate)
        ):
            continue
        independently = _evaluate_candidate(
            candidate,
            result.local_evidence,
            result.authorized_input_context_sha256,
            verification,
        )
        if independently.semantic_assertion != candidate.semantic_assertion:
            _fail("semantic decision is unsupported by independent authority")


def _pages(
    base: UnifiedPdfResult,
    canonical: CanonicalDocument,
    candidates: tuple[ObservableTableCandidate, ...],
) -> tuple[SemanticPage, ...]:
    confirmed = confirmed_references(candidates)
    page_ids = {page.page_number: page.page_id for page in canonical.pages}
    return tuple(
        SemanticPage(
            page_id=page_ids[page.page_number],
            page_number=page.page_number,
            legacy_page=page,
            width_points=page.width_points,
            height_points=page.height_points,
            rotation=page.rotation,
            text=page.text,
            availability=page.availability,
            limitations=page.limitations,
            table_candidate_ids=tuple(
                c.candidate_id for c in candidates if c.page_number == page.page_number
            ),
            table_ids=tuple(
                t.table_id for t in confirmed if t.page_id == page_ids[page.page_number]
            ),
        )
        for page in base.pages
    )


def _hypotheses(
    canonical: CanonicalDocument, candidates: tuple[ObservableTableCandidate, ...]
) -> tuple[tuple[DocumentTableHypothesis, ...], tuple[TransitionHypothesis, ...]]:
    ids = {
        c.legacy_canonical_table_id: c.candidate_id
        for c in candidates
        if c.legacy_canonical_table_id is not None
    }
    return (
        tuple(
            DocumentTableHypothesis(
                candidate_ids=tuple(ids[t] for t in group.table_ids),
                legacy=group,
            )
            for group in canonical.document_tables
        ),
        tuple(
            TransitionHypothesis(
                candidate_ids=(ids[t.left_table_id], ids[t.right_table_id]),
                legacy=t,
            )
            for t in canonical.transitions
        ),
    )


def _checked_context(value: PdfSemanticContext | None) -> PdfSemanticContext | None:
    if value is None:
        return None
    if type(value) is not PdfSemanticContext:
        _fail("semantic_context must be PdfSemanticContext")
    return PdfSemanticContext.model_validate_json(value.model_dump_json())


def _validate_non_table_fields(
    result: UnifiedPdfResultV5, base: UnifiedPdfResult
) -> None:
    for name in (
        "status",
        "availability",
        "page_count",
        "warnings",
        "limitations",
        "provenance",
        "family",
        "family_status",
        "family_auto_assignment",
        "processing_mode",
    ):
        if getattr(result, name) != getattr(base, name):
            _fail("v5 changed a retained non-table field")


def _inventory_state(base: UnifiedPdfResult) -> Literal["COMPLETE", "INCOMPLETE"]:
    evidence = base.local_evidence
    if not isinstance(evidence, PdfLocalEvidenceV3):
        return "INCOMPLETE"
    if base.availability != "AVAILABLE" or any(
        page.projection_truncated
        or page.source_group_truncated
        or page.source_member_inventory_status != "COMPLETE"
        for page in evidence.pages
    ):
        return "INCOMPLETE"
    return "COMPLETE"


def analyze_pdf_v5(
    source: bytes | bytearray | memoryview | str | PathLike[str],
    *,
    options: UnifiedPdfAnalysisOptions,
    password: str | None = None,
    semantic_context: PdfSemanticContext | None = None,
) -> UnifiedPdfResultV5:
    """Analyze once through legacy Local and apply independently scoped authority.

    Only ADVANCED_LOCAL is supported. No PDF geometry, confidence or missing tag
    can confirm a table or approve an underdetermination proof.
    """
    selected = _revalidate_analysis_options(options)
    if selected.mode is not PdfAnalysisMode.ADVANCED_LOCAL:
        message = "v5 requires explicit ADVANCED_LOCAL options"
        raise InvalidSourceReferenceError(message)
    context = _checked_context(semantic_context)
    base, canonical, content = _analyze_pdf_with_canonical(
        source,
        options=selected,
        password=password,
    )
    return _build_v5_result(
        (base, canonical, content),
        selected,
        context,
        password_provided=password is not None,
    )


def _build_v5_result(
    parsed: tuple[UnifiedPdfResult, CanonicalDocument, bytes],
    selected: UnifiedPdfAnalysisOptions,
    context: PdfSemanticContext | None,
    *,
    password_provided: bool,
) -> UnifiedPdfResultV5:
    """Build the unchanged v5 projection from one completed local parse."""
    base, canonical, content = parsed
    if not isinstance(base.local_evidence, PdfLocalEvidenceV3):
        _fail("v5 requires complete same-call local evidence v3")
    if context is not None and context.source_sha256 != base.source_sha256:
        _fail("semantic context source identity mismatch")
    verification = SemanticVerificationContext(
        content, selected, context, password_provided
    )
    context_sha = authorized_context_sha256(
        base.source_sha256, selected, context, password_provided=password_provided
    )
    candidates = tuple(
        _evaluate_candidate(c, base.local_evidence, context_sha, verification)
        for c in _observable_candidates(base, canonical, base.local_evidence)
    )
    groups, transitions = _hypotheses(canonical, candidates)
    return UnifiedPdfResultV5.model_validate(
        {
            "source_sha256": base.source_sha256,
            "authorized_input_context_sha256": context_sha,
            "document_id": base.document_id,
            "text": base.text,
            "status": base.status,
            "availability": base.availability,
            "page_count": base.page_count,
            "warnings": base.warnings,
            "limitations": base.limitations,
            "provenance": base.provenance,
            "candidate_inventory_state": _inventory_state(base),
            "pages": _pages(base, canonical, candidates),
            "table_candidates": candidates,
            "tables": confirmed_references(candidates),
            "document_table_candidates": groups,
            "candidate_transitions": transitions,
            "semantic_overlay": build_overlay(
                base.source_sha256, canonical, candidates
            ),
            "canonical_base": canonical,
            "local_evidence": base.local_evidence,
            "retained_v4_base": base,
            "retained_v4_sha256": sha256(base.to_json_bytes()).hexdigest(),
        },
        context=verification,
    )

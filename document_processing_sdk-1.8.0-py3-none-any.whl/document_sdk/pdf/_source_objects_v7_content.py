"""Bounded source content traversal for images, paths, fonts, and text state."""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from hashlib import sha256
from typing import TYPE_CHECKING, Literal

from document_sdk.pdf._document_objects_v6 import PdfObjectValue
from document_sdk.pdf._source_objects_v7 import (
    PdfContentLocatorV7,
    PdfFormInvocationV7,
    PdfImageOccurrenceV7,
    PdfMarkedSourceScopeV7,
    PdfSourceClipV7,
    PdfSourceContentStreamV7,
    PdfSourceFontV7,
    PdfSourceGraphicsStateV7,
    PdfSourcePathOperatorV7,
    PdfSourcePathPaintV7,
    PdfSourceTextStateV7,
)
from document_sdk.pdf._source_objects_v7_values import (
    IDENTITY,
    SourceBudget,
    SourceLimitError,
    SourceReadError,
    box,
    corners,
    decode_stream,
    dictionary,
    encoded_bytes,
    matrix,
    multiply,
    numbers,
    payload,
    recover_content_stream,
    resolve,
    source,
    stream_dictionary,
    value,
)
from document_sdk.pdf._source_objects_v7_values import (
    field as source_field,
)

if TYPE_CHECKING:
    from typing import Any

    from pypdf import PdfReader

    from document_sdk.pdf._document_objects_v6 import PdfObjectSource
    from document_sdk.pdf._source_objects_v7 import (
        Matrix,
        PdfSourceStreamRecoveryV7,
        SourceChannelName,
        SourceState,
    )

_PATH_OPERATORS = frozenset({b"m", b"l", b"c", b"v", b"y", b"h", b"re"})
_PAINT_OPERATORS = frozenset(
    {b"S", b"s", b"f", b"F", b"f*", b"B", b"B*", b"b", b"b*", b"n"}
)
_TEXT_SHOW = frozenset({b"Tj", b"TJ", b"'", b'"'})
_TEXT_POSITION = frozenset({b"Td", b"TD", b"T*"})
_FILLED = frozenset({b"f", b"F", b"f*", b"B", b"B*", b"b", b"b*"})
_PIXEL_EIGHT_BITS = 8
_RGB_CHANNELS = 3
_CMYK_CHANNELS = 4
_TEXT_CLIP_MODE = 4


@dataclass
class _State:
    ctm: Matrix = IDENTITY
    line_width: float = 1.0
    dash_array: tuple[float, ...] = ()
    dash_phase: float = 0.0
    line_cap: int = 0
    line_join: int = 0
    miter_limit: float = 10.0
    stroke_alpha: float = 1.0
    fill_alpha: float = 1.0
    blend_mode: PdfObjectValue = field(
        default_factory=lambda: PdfObjectValue(
            state="PRESENT", type_name="name", text="/Normal"
        )
    )
    stroke_color: tuple[float, ...] = (0.0,)
    fill_color: tuple[float, ...] = (0.0,)
    stroke_colorspace: str = "/DeviceGray"
    fill_colorspace: str = "/DeviceGray"
    clips: tuple[str, ...] = ()
    unsupported: tuple[str, ...] = ()
    font_name: str | None = None
    font_size: float = 0.0
    character_spacing: float = 0.0
    word_spacing: float = 0.0
    horizontal_scale: float = 100.0
    leading: float = 0.0
    rendering_mode: int = 0
    rise: float = 0.0
    text_matrix: Matrix | None = None
    text_positions: tuple[str, ...] = ()
    marked: tuple[PdfMarkedSourceScopeV7, ...] = ()

    def public(self) -> PdfSourceGraphicsStateV7:
        """Project the actual graphics state at one paint occurrence."""
        return PdfSourceGraphicsStateV7(
            ctm=self.ctm,
            line_width=self.line_width,
            dash_array=self.dash_array,
            dash_phase=self.dash_phase,
            line_cap=self.line_cap,
            line_join=self.line_join,
            miter_limit=self.miter_limit,
            stroke_alpha=self.stroke_alpha,
            fill_alpha=self.fill_alpha,
            blend_mode=self.blend_mode,
            stroke_color=self.stroke_color,
            fill_color=self.fill_color,
            stroke_colorspace=self.stroke_colorspace,
            fill_colorspace=self.fill_colorspace,
            active_clip_ids=self.clips,
            unsupported_state_operators=self.unsupported,
        )


@dataclass(frozen=True)
class _Context:
    page_number: int
    stream_source: PdfObjectSource
    resources: Any
    resources_path: str
    invocation_path: tuple[PdfObjectSource, ...] = ()
    invocation_indices: tuple[int, ...] = ()
    operator_offset: int = 0

    def locator(self, index: int) -> PdfContentLocatorV7:
        """Bind one source operation to its page and Form invocation occurrence."""
        return PdfContentLocatorV7(
            page_number=self.page_number,
            stream_source=self.stream_source,
            operator_index=index,
            invocation_path=self.invocation_path,
            invocation_indices=self.invocation_indices,
        )


@dataclass(frozen=True)
class _Call:
    context: _Context
    location: PdfContentLocatorV7
    state: _State
    depth: int


@dataclass
class _ContentSequence:
    """Interpret one page's streams continuously, or one isolated Form call."""

    state: _State = field(default_factory=_State)
    stack: list[_State] = field(default_factory=list)
    path: list[PdfSourcePathOperatorV7] = field(default_factory=list)
    pending_clip: tuple[PdfContentLocatorV7, bytes] | None = None
    operations_seen: int = 0


@dataclass
class SourceContentInventory:
    """Incremental source records; incomplete channels keep already read content."""

    images: list[PdfImageOccurrenceV7] = field(default_factory=list)
    paints: list[PdfSourcePathPaintV7] = field(default_factory=list)
    clips: list[PdfSourceClipV7] = field(default_factory=list)
    texts: list[PdfSourceTextStateV7] = field(default_factory=list)
    fonts: list[PdfSourceFontV7] = field(default_factory=list)
    forms: list[PdfFormInvocationV7] = field(default_factory=list)
    streams: list[PdfSourceContentStreamV7] = field(default_factory=list)
    limitations: dict[SourceChannelName, list[str]] = field(default_factory=dict)

    def limitation(self, channel: SourceChannelName, reason: str) -> None:
        """Retain the exact reason without confusing a gap with source absence."""
        reasons = self.limitations.setdefault(channel, [])
        if reason not in reasons:
            reasons.append(reason)


class ContentWalker:
    """Read ordered source operations without borrowing visual layout results."""

    def __init__(
        self, reader: PdfReader, budget: SourceBudget, original: bytes | None = None
    ) -> None:
        """Use one reader and shared finite budgets for all source occurrences."""
        self.reader = reader
        self.budget = budget
        self.original = original
        self.inventory = SourceContentInventory()
        self._font_seen: set[tuple[object, ...]] = set()
        self._stream_seen: set[tuple[object, ...]] = set()
        self._decoded_streams: dict[tuple[object, ...], bytes] = {}

    def _key(self, ref: Any, path: str) -> tuple[object, ...]:
        identity = source(ref, path)
        return (
            (identity.object_number, identity.generation)
            if identity.object_number is not None
            else (path,)
        )

    def _resource(self, context: _Context, kind: str, name: str) -> tuple[Any, str]:
        resources = dictionary(context.resources)
        selected = dictionary(resources.get(kind, {}))
        if name not in selected:
            message = "SOURCE_RESOURCE_REFERENCE_MISSING"
            raise SourceReadError(message)
        return selected.raw_get(
            name
        ), context.resources_path + kind + "/" + name.removeprefix("/")

    def _stream(self, ref: Any, path: str) -> bytes:
        from pypdf.errors import PdfReadError

        key = self._key(ref, path)
        if key in self._decoded_streams:
            return self._decoded_streams[key]
        recovery = None
        try:
            stream = dictionary(ref)
            raw = encoded_bytes(stream, self.budget)
        except (SourceReadError, PdfReadError):
            stream, recovery = recover_content_stream(
                self.reader, ref, self.budget, self.original
            )
            raw = encoded_bytes(stream, self.budget)
            for channel in ("images", "graphics", "text_state"):
                for reason in recovery.limitation_codes:
                    self.inventory.limitation(channel, reason)
        decoded = None
        try:
            decoded = decode_stream(raw, stream, self.budget)
        except SourceReadError:
            self._record_stream(ref, path, (raw, None), stream, recovery=recovery)
            raise
        self._decoded_streams[key] = decoded
        if key not in self._stream_seen:
            self._record_stream(ref, path, (raw, decoded), stream, recovery=recovery)
        return decoded

    def _record_stream(
        self,
        ref: Any,
        path: str,
        data: tuple[bytes, bytes | None],
        stream: Any,
        *,
        recovery: PdfSourceStreamRecoveryV7 | None = None,
    ) -> None:
        raw, decoded = data
        key = self._key(ref, path)
        self._stream_seen.add(key)
        self.inventory.streams.append(
            PdfSourceContentStreamV7(
                source=source(ref, path),
                filters=source_field(stream, "/Filter", self.budget),
                decode_parameters=source_field(stream, "/DecodeParms", self.budget),
                encoded=payload(raw),
                decoded=payload(decoded) if decoded is not None else None,
                decoding_state="COMPLETE" if decoded is not None else "UNSUPPORTED",
                encoding_basis="RECOVERED_ORIGINAL_INPUT_BYTE_RANGE"
                if recovery is not None
                else "AFTER_PDF_SECURITY_HANDLER",
                recovery=recovery,
            )
        )

    def page(self, page: Any, number: int) -> None:
        """Read a page's content array in order; Form calls are not deduplicated."""
        contents = page.get("/Contents")
        if contents is None:
            return
        refs = (
            list(resolve(contents))
            if isinstance(resolve(contents), list | tuple)
            else [contents]
        )
        sequence = _ContentSequence()
        for index, ref in enumerate(refs):
            path = f"/Pages/{number - 1}/Contents/{index}"
            context = _Context(
                number,
                source(ref, path),
                page.get("/Resources", {}),
                f"/Pages/{number - 1}/Resources",
                operator_offset=sequence.operations_seen,
            )
            self._walk(ref, context, sequence, 0)
        self._finish_sequence(sequence)

    def _walk(
        self, ref: Any, context: _Context, sequence: _ContentSequence, depth: int
    ) -> None:
        from pypdf.generic import ContentStream, DecodedStreamObject

        if depth > self.budget.limits.max_depth:
            message = "SOURCE_FORM_DEPTH_LIMIT"
            raise SourceLimitError(message)
        self._register_fonts(context)
        decoded = self._stream(ref, context.stream_source.source_path)
        temporary = DecodedStreamObject()
        temporary.set_data(decoded)
        parsed = ContentStream(temporary, self.reader)
        state = sequence.state
        for index, (operands, operator) in enumerate(parsed.operations):
            self.budget.operation()
            sequence.operations_seen += 1
            location = context.locator(index)
            if operator == b"q":
                sequence.stack.append(replace(state))
            elif operator == b"Q":
                if not sequence.stack:
                    message = "SOURCE_GRAPHICS_STACK_UNDERFLOW"
                    raise SourceReadError(message)
                restored = sequence.stack.pop()
                text_matrix = state.text_matrix
                text_positions = state.text_positions
                marked = state.marked
                state.__dict__.update(restored.__dict__)
                state.text_matrix = text_matrix
                state.text_positions = text_positions
                state.marked = marked
            elif operator in _PATH_OPERATORS:
                sequence.path.append(
                    PdfSourcePathOperatorV7(
                        locator=location,
                        operator=operator.decode("ascii"),
                        operands=numbers(operands),
                        ctm=state.ctm,
                    )
                )
            elif operator in (b"W", b"W*"):
                sequence.pending_clip = location, operator
            elif operator in _PAINT_OPERATORS:
                self._paint(location, operator, sequence.path, state)
                self._clip(sequence.pending_clip, location, sequence.path, state)
                sequence.path.clear()
                sequence.pending_clip = None
            else:
                self._dispatch(
                    operands, operator, _Call(context, location, state, depth)
                )

    def _finish_sequence(self, sequence: _ContentSequence) -> None:
        """Report unfinished syntax only at the page or Form execution boundary."""
        if sequence.stack or sequence.path or sequence.pending_clip is not None:
            self.inventory.limitation(
                "graphics", "SOURCE_UNBALANCED_OR_UNPAINTED_CONTENT"
            )

    def _paint(
        self,
        location: PdfContentLocatorV7,
        operator: bytes,
        path: list[PdfSourcePathOperatorV7],
        state: _State,
    ) -> None:
        if operator == b"n":
            return
        fill_rule: Literal["EVEN_ODD", "NONZERO"] = (
            "EVEN_ODD" if b"*" in operator else "NONZERO"
        )
        self.inventory.paints.append(
            PdfSourcePathPaintV7(
                locator=location,
                operator=operator.decode("ascii"),
                path=tuple(path),
                fill_rule=fill_rule if operator in _FILLED else "NOT_FILLED",
                state=state.public(),
            )
        )

    def _clip(
        self,
        declaration: tuple[PdfContentLocatorV7, bytes] | None,
        activation: PdfContentLocatorV7,
        path: list[PdfSourcePathOperatorV7],
        state: _State,
    ) -> None:
        if declaration is None:
            return
        location, operator = declaration
        token = location.model_dump_json().encode("utf-8")
        clip_id = "PDFCLIP-" + sha256(token).hexdigest()
        self.inventory.clips.append(
            PdfSourceClipV7(
                clip_id=clip_id,
                locator=location,
                activation_locator=activation,
                path=tuple(path),
                fill_rule="EVEN_ODD" if operator == b"W*" else "NONZERO",
            )
        )
        state.clips += (clip_id,)

    def _dispatch(
        self,
        operands: Any,
        operator: bytes,
        call: _Call,
    ) -> None:
        context, location, state = call.context, call.location, call.state
        if operator == b"Do":
            self._xobject(str(operands[0]), call)
        elif operator == b"INLINE IMAGE":
            self._inline(operands, location, state)
        elif operator == b"gs":
            self._extended(str(operands[0]), context, state)
        elif operator in _TEXT_SHOW:
            self._show(operands, operator, context, location, state)
        elif operator in (b"BMC", b"BDC", b"EMC"):
            self._marked(operands, operator, context, state)
        elif not self._simple_state(operands, operator, state):
            self._text_state(operands, operator, context, state)

    def _simple_state(self, operands: Any, operator: bytes, state: _State) -> bool:
        scalar = {
            b"w": "line_width",
            b"J": "line_cap",
            b"j": "line_join",
            b"M": "miter_limit",
        }
        if operator in scalar:
            number = float(operands[0])
            setattr(
                state,
                scalar[operator],
                int(number) if operator in (b"J", b"j") else number,
            )
        elif operator == b"cm":
            state.ctm = multiply(matrix(operands), state.ctm)
        elif operator == b"d":
            state.dash_array, state.dash_phase = (
                numbers(operands[0]),
                float(operands[1]),
            )
        elif operator in (b"G", b"RG", b"K", b"g", b"rg", b"k"):
            self._color(operands, operator, state)
        elif operator in (b"CS", b"cs"):
            setattr(
                state,
                "stroke_colorspace" if operator == b"CS" else "fill_colorspace",
                str(operands[0]),
            )
        elif operator in (b"SC", b"sc"):
            setattr(
                state,
                "stroke_color" if operator == b"SC" else "fill_color",
                numbers(operands),
            )
        elif operator in (b"SCN", b"scn", b"sh"):
            state.unsupported += (operator.decode("ascii"),)
            self.inventory.limitation(
                "graphics", "SOURCE_PATTERN_OR_SHADING_STATE_UNSUPPORTED"
            )
        else:
            return False
        return True

    def _color(self, operands: Any, operator: bytes, state: _State) -> None:
        stroke = operator in (b"G", b"RG", b"K")
        setattr(state, "stroke_color" if stroke else "fill_color", numbers(operands))
        kind = {
            b"G": "/DeviceGray",
            b"RG": "/DeviceRGB",
            b"K": "/DeviceCMYK",
            b"g": "/DeviceGray",
            b"rg": "/DeviceRGB",
            b"k": "/DeviceCMYK",
        }[operator]
        setattr(state, "stroke_colorspace" if stroke else "fill_colorspace", kind)

    def _extended(self, name: str, context: _Context, state: _State) -> None:
        ref, _ = self._resource(context, "/ExtGState", name)
        mapping = dictionary(ref)
        assignments = {
            "/CA": "stroke_alpha",
            "/ca": "fill_alpha",
            "/LW": "line_width",
            "/ML": "miter_limit",
            "/LC": "line_cap",
            "/LJ": "line_join",
        }
        for key, attribute in assignments.items():
            if key in mapping:
                number = float(mapping[key])
                setattr(
                    state, attribute, int(number) if key in ("/LC", "/LJ") else number
                )
        if "/BM" in mapping:
            state.blend_mode = value(mapping.raw_get("/BM"), self.budget)
        if "/D" in mapping:
            dash = resolve(mapping["/D"])
            state.dash_array, state.dash_phase = numbers(dash[0]), float(dash[1])
        supported = set(assignments) | {"/Type", "/BM", "/D"}
        for key in mapping:
            if str(key) not in supported:
                state.unsupported += ("gs:" + str(key),)
                self.inventory.limitation(
                    "graphics", "SOURCE_EXTENDED_GRAPHICS_STATE_PARTIAL"
                )

    def _text_state(
        self, operands: Any, operator: bytes, context: _Context, state: _State
    ) -> None:
        scalar = {
            b"Tc": "character_spacing",
            b"Tw": "word_spacing",
            b"Tz": "horizontal_scale",
            b"TL": "leading",
            b"Tr": "rendering_mode",
            b"Ts": "rise",
        }
        if operator in scalar:
            number = float(operands[0])
            setattr(
                state, scalar[operator], int(number) if operator == b"Tr" else number
            )
        elif operator == b"Tf":
            state.font_name, state.font_size = str(operands[0]), float(operands[1])
            self._font(context, state.font_name)
        elif operator == b"Tm":
            state.text_matrix, state.text_positions = matrix(operands), ()
        elif operator in _TEXT_POSITION:
            state.text_positions += (
                operator.decode("ascii") + ":" + repr(numbers(operands)),
            )
            if operator == b"TD":
                state.leading = -float(operands[1])
        elif operator == b"BT":
            state.text_matrix, state.text_positions = IDENTITY, ()
        elif operator == b"ET" and state.rendering_mode >= _TEXT_CLIP_MODE:
            self.inventory.limitation(
                "graphics", "SOURCE_TEXT_CLIP_GEOMETRY_UNSUPPORTED"
            )
            self.inventory.limitation(
                "text_state", "SOURCE_TEXT_CLIP_GEOMETRY_UNSUPPORTED"
            )

    def _marked(
        self, operands: Any, operator: bytes, context: _Context, state: _State
    ) -> None:
        if operator == b"EMC":
            if not state.marked:
                message = "SOURCE_MARKED_CONTENT_STACK_UNDERFLOW"
                raise SourceReadError(message)
            state.marked = state.marked[:-1]
            return
        properties, reference = value(None, self.budget, present=False), None
        if operator == b"BDC":
            raw = operands[1]
            if str(raw).startswith("/"):
                raw, path = self._resource(context, "/Properties", str(raw))
                reference = source(raw, path)
            properties = value(resolve(raw), self.budget)
        state.marked += (
            PdfMarkedSourceScopeV7(
                tag=str(operands[0]), properties=properties, property_source=reference
            ),
        )

    def _show(
        self,
        operands: Any,
        operator: bytes,
        context: _Context,
        location: PdfContentLocatorV7,
        state: _State,
    ) -> None:
        if operator == b'"':
            state.word_spacing, state.character_spacing = (
                float(operands[0]),
                float(operands[1]),
            )
        if operator in (b"'", b'"'):
            state.text_positions += ("T*:IMPLICIT",)
        font_source = None
        if state.font_name is not None:
            ref, path = self._resource(context, "/Font", state.font_name)
            font_source = source(ref, path)
        self.inventory.texts.append(
            PdfSourceTextStateV7(
                locator=location,
                operator=operator.decode("ascii"),
                operands=tuple(value(item, self.budget) for item in operands),
                font_source=font_source,
                font_resource_name=state.font_name,
                nominal_font_size=state.font_size,
                character_spacing=state.character_spacing,
                word_spacing=state.word_spacing,
                horizontal_scale_percent=state.horizontal_scale,
                leading=state.leading,
                rendering_mode=state.rendering_mode,
                rise=state.rise,
                declared_text_matrix=state.text_matrix,
                positioning_operators=state.text_positions,
                ctm=state.ctm,
                active_clip_ids=state.clips,
                marked_scopes=state.marked,
            )
        )
        state.text_positions += (
            operator.decode("ascii") + ":GLYPH_ADVANCE_NOT_INFERRED",
        )

    def _font(self, context: _Context, name: str) -> None:
        ref, path = self._resource(context, "/Font", name)
        key = (*self._key(ref, path), path)
        if key in self._font_seen:
            return
        self._font_seen.add(key)
        mapping = dictionary(ref)
        encoded = decoded = unicode_source = None
        unicode_filters = value(None, self.budget, present=False)
        unicode_parameters = value(None, self.budget, present=False)
        unicode_state: SourceState = "ABSENT"
        if "/ToUnicode" in mapping:
            cmap = mapping.raw_get("/ToUnicode")
            unicode_source = source(cmap, path + "/ToUnicode")
            raw = encoded_bytes(dictionary(cmap), self.budget)
            encoded = payload(raw)
            unicode_filters = source_field(dictionary(cmap), "/Filter", self.budget)
            unicode_parameters = source_field(
                dictionary(cmap), "/DecodeParms", self.budget
            )
            try:
                decoded = payload(decode_stream(raw, dictionary(cmap), self.budget))
                unicode_state = "COMPLETE"
            except SourceReadError as error:
                unicode_state = "UNSUPPORTED"
                self.inventory.limitation("text_state", str(error))
        encoding = (
            resolve(mapping.raw_get("/Encoding")) if "/Encoding" in mapping else None
        )

        self.inventory.fonts.append(
            PdfSourceFontV7(
                source=source(ref, path),
                resource_name=name,
                subtype=source_field(mapping, "/Subtype", self.budget),
                base_font=source_field(mapping, "/BaseFont", self.budget),
                encoding=value(encoding, self.budget, present="/Encoding" in mapping),
                encoding_source=source(mapping.raw_get("/Encoding"), path + "/Encoding")
                if "/Encoding" in mapping
                else None,
                to_unicode_source=unicode_source,
                to_unicode_encoded=encoded,
                to_unicode_decoded=decoded,
                to_unicode_state=unicode_state,
                to_unicode_filters=unicode_filters,
                to_unicode_decode_parameters=unicode_parameters,
                font_dictionary=value(mapping, self.budget),
                char_procedures=self._char_procedures(mapping, path),
            )
        )

    def _register_fonts(self, context: _Context) -> None:
        resources = dictionary(context.resources)
        if "/Font" not in resources:
            return
        fonts = dictionary(resources["/Font"])
        for name in fonts:
            try:
                self._font(context, str(name))
            except SourceReadError as error:
                self.inventory.limitation("text_state", str(error))

    def _xobject(
        self,
        name: str,
        call: _Call,
    ) -> None:
        context, location, state = call.context, call.location, call.state
        ref, resource_path = self._resource(context, "/XObject", name)
        mapping = dictionary(ref)
        kind = str(mapping.get("/Subtype"))
        if kind == "/Image":
            self._image(mapping, (ref, name, resource_path), location, state)
        elif kind == "/Form":
            self._form(mapping, ref, name, call)
        else:
            self.inventory.limitation("graphics", "SOURCE_XOBJECT_SUBTYPE_UNSUPPORTED")

    def _form(
        self,
        mapping: Any,
        ref: Any,
        name: str,
        call: _Call,
    ) -> None:
        context, location, state, depth = (
            call.context,
            call.location,
            call.state,
            call.depth,
        )
        form_source = source(
            ref,
            context.resources_path + "/XObject/" + name.removeprefix("/"),
        )
        transform = matrix(mapping["/Matrix"]) if "/Matrix" in mapping else IDENTITY
        effective = multiply(transform, state.ctm)
        raw_bbox = box(mapping["/BBox"]) if "/BBox" in mapping else None
        self.inventory.forms.append(
            PdfFormInvocationV7(
                locator=location,
                resource_name=name,
                form_source=form_source,
                matrix=transform,
                effective_ctm=effective,
                raw_bbox=raw_bbox,
            )
        )
        child = _Context(
            context.page_number,
            form_source,
            mapping.get("/Resources", context.resources),
            form_source.source_path + "/Resources"
            if "/Resources" in mapping
            else context.resources_path,
            (*context.invocation_path, form_source),
            (
                *context.invocation_indices,
                context.operator_offset + location.operator_index,
            ),
        )
        if form_source in context.invocation_path:
            message = "SOURCE_FORM_INVOCATION_CYCLE"
            raise SourceReadError(message)
        copied = replace(state, ctm=effective)
        if raw_bbox is not None:
            clip_id = (
                "PDFCLIP-FORM-"
                + sha256(location.model_dump_json().encode("utf-8")).hexdigest()
            )
            self.inventory.clips.append(
                PdfSourceClipV7(
                    clip_id=clip_id,
                    locator=location,
                    activation_locator=location,
                    path=(),
                    fill_rule="NONZERO",
                    kind="FORM_BBOX",
                    raw_bbox=raw_bbox,
                    bbox_source=source(ref, form_source.source_path + "/BBox"),
                )
            )
            copied.clips += (clip_id,)
        sequence = _ContentSequence(state=copied)
        self._walk(ref, child, sequence, depth + 1)
        self._finish_sequence(sequence)

    def _char_procedures(
        self, mapping: Any, path: str
    ) -> tuple[PdfSourceContentStreamV7, ...]:
        if "/CharProcs" not in mapping:
            return ()
        procedures = dictionary(mapping["/CharProcs"])
        result: list[PdfSourceContentStreamV7] = []
        for name in procedures:
            ref = procedures.raw_get(name)
            procedure = dictionary(ref)
            raw = encoded_bytes(procedure, self.budget)
            decoded = None
            state: SourceState = "COMPLETE"
            try:
                decoded = payload(decode_stream(raw, procedure, self.budget))
            except SourceReadError as error:
                state = "UNSUPPORTED"
                self.inventory.limitation("graphics", str(error))
            result.append(
                PdfSourceContentStreamV7(
                    source=source(
                        ref, path + "/CharProcs/" + str(name).removeprefix("/")
                    ),
                    filters=source_field(procedure, "/Filter", self.budget),
                    decode_parameters=source_field(
                        procedure, "/DecodeParms", self.budget
                    ),
                    encoded=payload(raw),
                    decoded=decoded,
                    decoding_state=state,
                )
            )
        self.inventory.limitation(
            "graphics", "SOURCE_TYPE3_GLYPH_PAINT_PLACEMENT_UNPROVED"
        )
        return tuple(result)

    def _inline(
        self, operands: Any, location: PdfContentLocatorV7, state: _State
    ) -> None:
        settings = dictionary(operands["settings"])
        raw = operands["data"]
        if not isinstance(raw, bytes):
            message = "SOURCE_INLINE_IMAGE_BYTES_UNAVAILABLE"
            raise SourceReadError(message)
        self.budget.encoded(len(raw))
        self._image_record(settings, raw, None, location, state)

    def _image(
        self,
        mapping: Any,
        resource: tuple[Any, str, str],
        location: PdfContentLocatorV7,
        state: _State,
    ) -> None:
        raw = encoded_bytes(mapping, self.budget)
        self._image_record(mapping, raw, resource, location, state)

    def _image_record(
        self,
        mapping: Any,
        raw: bytes,
        resource: tuple[Any, str, str] | None,
        location: PdfContentLocatorV7,
        state: _State,
    ) -> None:
        width = int(mapping.get("/Width", mapping.get("/W", 0)))
        height = int(mapping.get("/Height", mapping.get("/H", 0)))
        if width < 1 or height < 1:
            message = "SOURCE_IMAGE_DIMENSIONS_INVALID"
            raise SourceReadError(message)
        if width * height > self.budget.limits.max_image_pixels:
            message = "SOURCE_IMAGE_PIXEL_LIMIT"
            raise SourceLimitError(message)
        bits = int(mapping.get("/BitsPerComponent", mapping.get("/BPC", 1)))
        colorspace = mapping.get("/ColorSpace", mapping.get("/CS"))
        samples, layout, decoding_state = self._samples(
            raw, mapping, colorspace, width * height, bits
        )
        inline_path = (
            location.stream_source.source_path
            + f"/Operations/{location.operator_index}/Image"
        )
        ref, name, path = (
            resource if resource is not None else (mapping, None, inline_path)
        )
        self.inventory.images.append(
            PdfImageOccurrenceV7(
                locator=location,
                kind="XOBJECT" if resource is not None else "INLINE",
                resource_name=name,
                source=source(ref, path),
                width=width,
                height=height,
                bits_per_component=bits,
                colorspace=value(
                    resolve(colorspace), self.budget, present=colorspace is not None
                ),
                filters=value(
                    mapping.get("/Filter", mapping.get("/F")),
                    self.budget,
                    present="/Filter" in mapping or "/F" in mapping,
                ),
                decode_parameters=value(
                    mapping.get("/DecodeParms", mapping.get("/DP")),
                    self.budget,
                    present="/DecodeParms" in mapping or "/DP" in mapping,
                ),
                image_dictionary=value(
                    stream_dictionary(mapping, ref, self.reader, self.budget),
                    self.budget,
                ),
                encoded=payload(raw),
                decoded_samples=samples,
                sample_layout=layout,
                decoding_state=decoding_state,
                ctm=state.ctm,
                unit_square_corners=corners(state.ctm),
            )
        )

    def _samples(
        self, raw: bytes, mapping: Any, colorspace: Any, pixels: int, bits: int
    ) -> tuple[Any, Any, SourceState]:
        try:
            decoded = decode_stream(raw, mapping, self.budget)
        except SourceReadError as error:
            self.inventory.limitation("images", str(error))
            return None, "UNAVAILABLE", "UNSUPPORTED"
        spaces = {
            "/DeviceRGB": (_RGB_CHANNELS, "RGB"),
            "/RGB": (_RGB_CHANNELS, "RGB"),
            "/DeviceGray": (1, "GRAY"),
            "/G": (1, "GRAY"),
            "/DeviceCMYK": (_CMYK_CHANNELS, "CMYK"),
            "/CMYK": (_CMYK_CHANNELS, "CMYK"),
        }
        if (
            str(colorspace) not in spaces
            or bits != _PIXEL_EIGHT_BITS
            or "/Decode" in mapping
        ):
            self.inventory.limitation(
                "images", "SOURCE_IMAGE_SAMPLE_INTERPRETATION_UNSUPPORTED"
            )
            return payload(decoded), "PACKED_SOURCE_SAMPLES", "UNSUPPORTED"
        channels, layout = spaces[str(colorspace)]
        if len(decoded) != pixels * channels:
            message = "SOURCE_IMAGE_SAMPLE_LENGTH_MISMATCH"
            raise SourceReadError(message)
        return payload(decoded), layout, "COMPLETE"

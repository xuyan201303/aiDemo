"""Private bridge from the unified PDF facade to Canonical Hybrid analysis."""

# ruff: noqa: EM101, TRY003, TRY301

from __future__ import annotations

from inspect import getattr_static
from typing import TYPE_CHECKING, Literal, cast

from pydantic import BaseModel

from document_sdk.core import (
    CloudExecutionPolicy,
    DocumentProcessingError,
    ProviderConfigurationError,
)
from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.pdf._structural_engine.hybrid import (
    CloudDocumentAnalysisArtifact,
    CloudPrivacyPolicy,
    DocumentAnalysisCapability,
    DocumentAnalysisRequest,
    HybridAnalysisMode,
    HybridAnalysisResult,
    HybridCloudStatus,
    HybridFailureCategory,
    HybridLimits,
    HybridOptions,
)
from document_sdk.pdf.unified import (
    UNIFIED_PDF_HYBRID_RESULT_VERSION,
    PdfAnalysisMode,
    UnifiedPdfHybridCapabilityOutcome,
    UnifiedPdfHybridResult,
    UnifiedPdfHybridSummary,
    UnifiedPdfResult,
)
from document_sdk.providers import CredentialResolver, ProviderContext

if TYPE_CHECKING:
    from document_sdk.ocr import AzureDocumentIntelligenceConfig
    from document_sdk.pdf._structural_engine.canonical import CanonicalDocument
    from document_sdk.pdf._structural_engine.hybrid import DocumentAnalysisProvider
    from document_sdk.pdf.models import PdfProcessingLimits

type _PublicSubmissionStatus = Literal["NOT_SUBMITTED", "SUBMITTED", "UNKNOWN"]
type _PublicSubmissionScope = Literal["NOT_APPLICABLE", "FULL_DOCUMENT_BYTES"]
type _PublicAnalysisScope = Literal["NOT_APPLICABLE", "SELECTED_PAGES"]
type _PublicDeletionStatus = Literal[
    "NOT_REQUESTED",
    "SUCCEEDED",
    "FAILED",
    "UNAVAILABLE",
]
type _PublicFailureCategory = Literal[
    "CLOUD_PROVIDER_UNAVAILABLE",
    "CLOUD_CONFIGURATION_ERROR",
    "CLOUD_REQUEST_LIMIT",
    "CLOUD_PROVIDER_TIMEOUT",
    "CLOUD_PROVIDER_REJECTED",
    "CLOUD_RESPONSE_INVALID",
    "CLOUD_RESULT_LIMIT_EXCEEDED",
    "CLOUD_DELETE_FAILED",
    "CLOUD_ANALYSIS_FAILED",
]

_PRIVATE_PROVIDER: Literal["AZURE_DOCUMENT_INTELLIGENCE"] = (
    "AZURE_DOCUMENT_INTELLIGENCE"
)
_PUBLIC_PROVIDER_NAME: Literal["azure-document-intelligence"] = (
    "azure-document-intelligence"
)
_MODEL: Literal["prebuilt-layout"] = "prebuilt-layout"
_API_VERSION: Literal["2024-11-30"] = "2024-11-30"
_NO_EXECUTION_STATUSES = frozenset(
    {
        HybridCloudStatus.NOT_REQUESTED,
        HybridCloudStatus.NOT_EXECUTED_DISABLED,
        HybridCloudStatus.NOT_EXECUTED_PROVIDER_UNAVAILABLE,
        HybridCloudStatus.NOT_EXECUTED_LIMIT,
    }
)


class _AzureHybridProviderBridge:
    """Hold revalidated public configuration until private routing needs Cloud."""

    __slots__ = ("__config", "__resolver")

    def __init__(
        self,
        *,
        config: AzureDocumentIntelligenceConfig,
        resolver: CredentialResolver,
    ) -> None:
        self.__config = config
        self.__resolver = resolver

    def __repr__(self) -> str:
        return "_AzureHybridProviderBridge(configured=True)"

    def build_options(self, *, local_limits: PdfProcessingLimits) -> HybridOptions:
        """Derive one bounded private execution contract without resolving secrets."""
        policy = self.__config.cloud_execution_policy
        return HybridOptions(
            mode=HybridAnalysisMode.HYBRID_AUTO,
            cloud_enabled=True,
            required_capabilities=(
                DocumentAnalysisCapability.LAYOUT,
                DocumentAnalysisCapability.OCR_TEXT,
                DocumentAnalysisCapability.TABLES,
            ),
            privacy_policy=CloudPrivacyPolicy(),
            limits=HybridLimits(
                maximum_cloud_pages=min(
                    policy.max_pages_or_frames,
                    local_limits.max_pages,
                    2_000,
                ),
                maximum_cloud_requests=1,
                maximum_cloud_input_bytes=min(
                    policy.max_input_bytes,
                    self.__config.max_input_bytes,
                    local_limits.max_file_bytes,
                    500_000_000,
                ),
                maximum_elapsed_milliseconds=min(
                    self.__config.polling_timeout_seconds * 1_000,
                    1_800_000,
                ),
            ),
        )

    def analyze(
        self,
        request: DocumentAnalysisRequest,
    ) -> CloudDocumentAnalysisArtifact:
        """Resolve the caller credential only after the private Router calls us."""
        credential = self.__resolver.resolve()
        adapter = _build_private_azure_adapter(
            endpoint=self.__config.endpoint,
            credential=credential,
        )
        return adapter.analyze(request)


def _build_private_azure_adapter(
    *,
    endpoint: str,
    credential: object,
) -> DocumentAnalysisProvider:
    """Lazily construct the existing private adapter at the Cloud boundary."""
    from document_sdk.pdf._structural_engine.hybrid.providers import (
        AzureDocumentIntelligenceAdapter,
    )

    return AzureDocumentIntelligenceAdapter(
        endpoint=endpoint,
        credential=credential,
    )


def _validate_hybrid_provider(provider: object) -> _AzureHybridProviderBridge:
    """Validate the exact supported public Provider before any source access."""
    from document_sdk.ocr import (
        AzureDocumentIntelligenceConfig,
        AzureDocumentIntelligenceProvider,
    )

    if type(provider) is not AzureDocumentIntelligenceProvider:
        raise ProviderConfigurationError(
            "ADVANCED_HYBRID requires the exact supported Azure Provider"
        )
    try:
        exact_provider = provider
        rebound = AzureDocumentIntelligenceProvider(context=exact_provider.context)
        context = rebound.context
        if type(context) is not ProviderContext:
            raise TypeError
        config = context.config
        resolver = context.credential_resolver
        if type(config) is not AzureDocumentIntelligenceConfig:
            raise TypeError
        if not callable(getattr_static(resolver, "resolve", None)) or not isinstance(
            resolver,
            CredentialResolver,
        ):
            raise TypeError
        exact_config = config
        policy = exact_config.cloud_execution_policy
        if type(policy) is not CloudExecutionPolicy:
            raise TypeError
        if (
            exact_config.model_id != _MODEL
            or exact_config.api_version != _API_VERSION
            or exact_config.transport_retry_total != 0
            or not policy.allow_cloud_execution
            or not policy.allow_cloud_fallback
            or policy.max_logical_cloud_operations < 1
            or policy.max_submitted_operations < 1
            or policy.max_paid_or_possibly_paid_operations < 1
            or policy.max_pages_or_frames < 1
            or policy.max_input_bytes < 1
        ):
            raise ValueError
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception as error:  # noqa: BLE001 - untrusted public Provider boundary.
        _raise_redacted_translation(
            error,
            ProviderConfigurationError("Hybrid Provider configuration is invalid"),
        )
    return _AzureHybridProviderBridge(config=exact_config, resolver=resolver)


def _run_prepared_hybrid(
    local_document: CanonicalDocument,
    document_bytes: bytes,
    *,
    bridge: _AzureHybridProviderBridge,
    options: HybridOptions,
) -> HybridAnalysisResult:
    """Run the existing private Canonical Hybrid engine on one byte snapshot."""
    from document_sdk.pdf._structural_engine.hybrid.runtime import (
        run_hybrid_document_analysis,
    )

    return run_hybrid_document_analysis(
        local_document,
        document_bytes,
        options=options,
        document_provider=bridge,
    )


def _project_hybrid_summary(result: HybridAnalysisResult) -> UnifiedPdfHybridSummary:
    """Project only fixed, bounded operational evidence from a private result."""
    if result.failure_category is HybridFailureCategory.HYBRID_INTERNAL_FAILURE:
        raise DocumentProcessingError("Hybrid analysis failed internally")

    status = result.cloud_status
    artifact = result.cloud_artifact
    requested_pages = result.routing_plan.cloud_page_numbers
    report = result.merge_report
    if status in _NO_EXECUTION_STATUSES:
        if artifact is not None:
            raise DocumentProcessingError("Hybrid submission evidence is contradictory")
        submission_status: _PublicSubmissionStatus = "NOT_SUBMITTED"
        submission_payload_scope: _PublicSubmissionScope = "NOT_APPLICABLE"
        analysis_selection_scope: _PublicAnalysisScope = "NOT_APPLICABLE"
        returned_pages: tuple[int, ...] = ()
        model_id: Literal["prebuilt-layout"] | None = None
        api_version: Literal["2024-11-30"] | None = None
        deletion_status: _PublicDeletionStatus = "NOT_REQUESTED"
    elif artifact is not None:
        if (
            artifact.provider != _PRIVATE_PROVIDER
            or artifact.model_id != _MODEL
            or artifact.api_version != _API_VERSION
            or artifact.submission_scope != "FULL_DOCUMENT_BYTES"
            or artifact.analysis_page_scope != "SELECTED_PAGES"
        ):
            raise DocumentProcessingError("Hybrid Provider evidence is unsupported")
        submission_status = "SUBMITTED"
        submission_payload_scope = "FULL_DOCUMENT_BYTES"
        analysis_selection_scope = "SELECTED_PAGES"
        returned_pages = tuple(page.page_index + 1 for page in artifact.pages)
        model_id = _MODEL
        api_version = _API_VERSION
        deletion_status = artifact.deletion_status.value
    elif status is HybridCloudStatus.FAILED_CONTROLLED:
        submission_status = "UNKNOWN"
        submission_payload_scope = "FULL_DOCUMENT_BYTES"
        analysis_selection_scope = "SELECTED_PAGES"
        returned_pages = ()
        model_id = None
        api_version = None
        deletion_status = "UNAVAILABLE"
    else:
        raise DocumentProcessingError("Hybrid submission evidence is incomplete")

    outcomes = tuple(
        UnifiedPdfHybridCapabilityOutcome(
            page_number=outcome.page_index + 1,
            capability=outcome.capability.value,
            state=outcome.state.value,
            reason_codes=outcome.reason_codes,
        )
        for outcome in report.effective_capability_outcomes
    )
    applied_pages = tuple(
        sorted(
            {
                outcome.page_index + 1
                for outcome in report.effective_capability_outcomes
                if outcome.applied_item_count > 0
            }
        )
    )
    failure_category = cast(
        "_PublicFailureCategory | None",
        None if result.failure_category is None else result.failure_category.value,
    )
    return UnifiedPdfHybridSummary(
        cloud_status=status.value,
        submission_status=submission_status,
        submission_payload_scope=submission_payload_scope,
        analysis_selection_scope=analysis_selection_scope,
        provider_name=_PUBLIC_PROVIDER_NAME,
        model_id=model_id,
        api_version=api_version,
        requested_page_numbers=requested_pages,
        returned_page_numbers=returned_pages,
        applied_page_numbers=applied_pages,
        effective_capability_outcomes=outcomes,
        local_preserved_text_count=report.local_preserved_text_count,
        cloud_filled_text_count=report.cloud_filled_text_count,
        local_preserved_table_count=report.local_preserved_table_count,
        cloud_filled_table_count=report.cloud_filled_table_count,
        conflict_count=report.conflict_count,
        continuity_unavailable_count=report.continuity_unavailable_count,
        review_required=report.review_required,
        deletion_status=deletion_status,
        failure_category=failure_category,
        warnings=report.warnings,
        limitations=report.limitations,
    )


def _build_hybrid_public_result(
    base: UnifiedPdfResult,
    result: HybridAnalysisResult,
) -> UnifiedPdfHybridResult:
    """Bind an existing public Canonical projection to its Hybrid summary."""
    if (
        base.document_id != result.canonical_document.canonical_document_id
        or base.source_sha256 != result.canonical_document.provenance.source_sha256
    ):
        raise DocumentProcessingError("Hybrid public result authority is inconsistent")
    values = BaseModel.model_dump(
        base,
        mode="python",
        round_trip=True,
        warnings="error",
    )
    values.update(
        {
            "schema_version": UNIFIED_PDF_HYBRID_RESULT_VERSION,
            "processing_mode": PdfAnalysisMode.ADVANCED_HYBRID,
            "hybrid": _project_hybrid_summary(result),
        }
    )
    return UnifiedPdfHybridResult.model_validate(values)


__all__: list[str] = []

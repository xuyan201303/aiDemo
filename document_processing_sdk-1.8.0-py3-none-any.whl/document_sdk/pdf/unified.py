"""Versioned, default-off unified PDF analysis API."""

# ruff: noqa: EM101, EM102, TRY003, TRY300, TRY301

from __future__ import annotations

import json
import math
import re
from collections.abc import Mapping
from enum import StrEnum
from importlib import import_module
from pathlib import Path
from typing import TYPE_CHECKING, Literal

from pydantic import (
    ConfigDict,
    Field,
    JsonValue,
    ValidationError,
    field_serializer,
    field_validator,
    model_validator,
)

from document_sdk.core import (
    DependencyNotInstalledError,
    DocumentProcessingError,
    DocumentSdkError,
    InvalidSourceReferenceError,
    ProviderConfigurationError,
    UnsupportedFileError,
)
from document_sdk.core._metadata import freeze_json_mapping, thaw_json_mapping
from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.core.models import SdkModel
from document_sdk.pdf._dependencies import PDF_DEPENDENCY_MESSAGE
from document_sdk.pdf.errors import PdfLimitExceededError
from document_sdk.pdf.local_evidence import (
    PdfLocalEvidence,
    PdfLocalPageEvidence,
)
from document_sdk.pdf.local_evidence_members import (
    PdfLocalCellMemberLink,
    PdfLocalEvidenceV2,
    PdfLocalEvidenceV3,
    PdfLocalPageEvidenceV2,
    _project_local_member_evidence,
)
from document_sdk.pdf.models import PdfProcessingLimits

if TYPE_CHECKING:
    from os import PathLike

    from document_sdk.ocr import AzureDocumentIntelligenceProvider
    from document_sdk.pdf._structural_engine.canonical import CanonicalDocument

UNIFIED_PDF_RESULT_VERSION: Literal["document_sdk.pdf.unified_result.v4"] = (
    "document_sdk.pdf.unified_result.v4"
)
UNIFIED_PDF_HYBRID_RESULT_VERSION: Literal[
    "document_sdk.pdf.unified_hybrid_result.v4"
] = "document_sdk.pdf.unified_hybrid_result.v4"
_ADVANCED_INTERNAL_LIMITS_PROFILE: Literal["bounded-private-defaults"] = (
    "bounded-private-defaults"
)
_ADVANCED_INTERNAL_LIMITS_PROFILE_VERSION: Literal[
    "document_sdk.pdf.advanced_local_limits.v1"
] = "document_sdk.pdf.advanced_local_limits.v1"
_ADVANCED_PDF_DEPENDENCIES = (
    "pypdfium2",
    "PIL",
    "pdfplumber",
    "pdfminer",
    "pypdf",
)
_NON_CAPABILITY_LIMITATIONS = frozenset(
    {
        "FAMILY_DEFERRED",
        "OCR_NOT_EXECUTED",
    }
)
_MAX_HYBRID_PAGES = 2_000
_MAX_HYBRID_CAPABILITY_OUTCOMES = _MAX_HYBRID_PAGES * 3
_MAX_HYBRID_CAPABILITY_REASON_CODES = 32
_MAX_HYBRID_METADATA_CODES = 512
_MAX_HYBRID_ITEM_COUNT = 2_000_000
_SAFE_HYBRID_METADATA_CODE = re.compile(
    r"[A-Z][A-Z0-9_.:-]{0,127}",
    flags=re.ASCII,
)
_HYBRID_CAPABILITY_REASON_CODES = frozenset(
    {
        "CLOUD_OCR_TEXT_NOT_OBSERVED",
        "CLOUD_TABLES_NOT_OBSERVED",
        "CLOUD_TABLES_PARTIAL",
        "HYBRID_CLOUD_LAYOUT_NOT_EFFECTIVELY_PROJECTED",
        "HYBRID_CLOUD_OCR_TEXT_NOT_APPLIED",
        "HYBRID_CLOUD_OCR_TEXT_PARTIAL",
        "HYBRID_CLOUD_PAGE_NOT_RETURNED",
        "HYBRID_CLOUD_TABLE_NOT_APPLIED",
        "HYBRID_CLOUD_TABLE_PARTIAL",
        "LOCAL_CLOUD_TABLE_CONFLICT",
    }
)
_HYBRID_WARNING_CODES = frozenset(
    {
        "CLOUD_TEXT_IGNORED_LOCAL_PROVEN",
        "LOCAL_CLOUD_TABLE_CONFLICT",
    }
)
_HYBRID_LIMITATION_CODES = frozenset(
    {
        "AZURE_MISSING_REQUESTED_PAGES",
        "AZURE_MULTIPLE_BOUNDING_REGIONS_UNSUPPORTED",
        "AZURE_PAGE_UNIT_UNAVAILABLE",
        "CLOUD_ANALYSIS_FAILED",
        "CLOUD_CONFIGURATION_ERROR",
        "CLOUD_DELETE_FAILED",
        "CLOUD_DISABLED",
        "CLOUD_LIMIT_EXCEEDED",
        "CLOUD_PROVIDER_REJECTED",
        "CLOUD_PROVIDER_TIMEOUT",
        "CLOUD_PROVIDER_UNAVAILABLE",
        "CLOUD_REQUEST_LIMIT",
        "CLOUD_RESPONSE_INVALID",
        "CLOUD_RESULT_LIMIT_EXCEEDED",
        "CLOUD_TABLE_AVAILABLE_LOCAL_PARTIAL",
        "HYBRID_CLOUD_TABLE_NO_LOCAL_DT_AUTHORITY",
        "HYBRID_INTERNAL_FAILURE",
        "PROVIDER_UNAVAILABLE",
    }
)


class PdfAnalysisMode(StrEnum):
    """Small public mode set; every advanced capability is opt-in."""

    STANDARD = "STANDARD"
    ADVANCED_LOCAL = "ADVANCED_LOCAL"
    ADVANCED_HYBRID = "ADVANCED_HYBRID"


class UnifiedPdfAnalysisOptions(SdkModel):
    """Aggregate public options without exposing private pipeline flags."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)
    mode: PdfAnalysisMode = PdfAnalysisMode.STANDARD
    limits: PdfProcessingLimits = Field(default_factory=PdfProcessingLimits)


class _UnifiedPdfProvenance(SdkModel):
    """Deeply immutable public provenance object with the existing JSON shape."""

    advanced_internal_limits_profile: Literal["bounded-private-defaults"]
    advanced_internal_limits_profile_version: Literal[
        "document_sdk.pdf.advanced_local_limits.v1"
    ]
    canonical_schema_version: str
    canonical_projection_version: str
    source_parser: str


class UnifiedPdfPage(SdkModel):
    """Stable public page projection."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)
    page_number: int = Field(ge=1)
    width_points: float = Field(gt=0)
    height_points: float = Field(gt=0)
    rotation: Literal[0, 90, 180, 270]
    text: str
    table_ids: tuple[str, ...] = ()
    availability: Literal[
        "AVAILABLE",
        "PARTIAL",
        "UNAVAILABLE",
        "UNSUPPORTED",
        "LIMITED_EVIDENCE",
    ]
    limitations: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_page_inventory(self) -> UnifiedPdfPage:
        """Reject repeated identities and noncanonical limitation inventories."""
        if len(set(self.table_ids)) != len(self.table_ids) or any(
            re.fullmatch(r"P3CE1-table-[0-9a-f]{64}", value) is None
            for value in self.table_ids
        ):
            raise ValueError("page table identity inventory is invalid")
        if self.limitations != tuple(sorted(set(self.limitations))):
            raise ValueError("page limitations must be sorted and unique")
        if self.availability == "AVAILABLE" and self.limitations:
            raise ValueError("page availability and limitations disagree")
        return self


class UnifiedPdfTableSourceIdentity(SdkModel):
    """Same-invocation Canonical authority, separate from local cell links.

    The retained SDK Canonical payload is replayed with its authoritative model;
    this is not an external parser/provider response or a new hash algorithm.
    """

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)
    canonical_table: dict[str, JsonValue]
    canonical_page_identity: dict[str, JsonValue]

    @field_validator("canonical_table", "canonical_page_identity", mode="before")
    @classmethod
    def copy_source_identity_mapping(cls, value: object) -> object:
        """Accept this model's immutable mappings during trusted revalidation."""
        return dict(value) if isinstance(value, Mapping) else value

    @model_validator(mode="after")
    def freeze_source_identity(self) -> UnifiedPdfTableSourceIdentity:
        """Detach aliases and recursively freeze retained Canonical evidence."""
        object.__setattr__(
            self, "canonical_table", freeze_json_mapping(self.canonical_table)
        )
        object.__setattr__(
            self,
            "canonical_page_identity",
            freeze_json_mapping(self.canonical_page_identity),
        )
        return self

    @field_serializer("canonical_table", "canonical_page_identity")
    def serialize_source_identity(
        self, value: dict[str, JsonValue]
    ) -> dict[str, JsonValue]:
        """Emit ordinary JSON containers from immutable retained evidence."""
        return thaw_json_mapping(value)


class UnifiedPdfTableCell(SdkModel):
    """Stable public table-cell projection."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)
    row_index: int = Field(ge=0)
    column_index: int = Field(ge=0)
    row_span: int = Field(ge=1)
    column_span: int = Field(ge=1)
    text: str | None
    availability: Literal[
        "AVAILABLE",
        "PARTIAL",
        "UNAVAILABLE",
        "UNSUPPORTED",
        "LIMITED_EVIDENCE",
    ]

    @model_validator(mode="after")
    def validate_text_availability(self) -> UnifiedPdfTableCell:
        """Preserve the distinction between empty and unavailable cell text."""
        if self.availability == "AVAILABLE" and self.text is None:
            raise ValueError("available table cell requires text authority")
        if (
            self.availability in {"UNAVAILABLE", "UNSUPPORTED"}
            and self.text is not None
        ):
            raise ValueError("unavailable table cell cannot contain text authority")
        return self


class UnifiedPdfTable(SdkModel):
    """Stable public page-table projection."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)
    source_identity: UnifiedPdfTableSourceIdentity | None = None
    table_id: str = Field(pattern=r"^P3CE1-table-[0-9a-f]{64}$")
    page_number: int = Field(ge=1)
    row_count: int = Field(ge=1)
    column_count: int = Field(ge=1)
    cells: tuple[UnifiedPdfTableCell, ...]
    document_table_ids: tuple[str, ...] = ()
    availability: Literal[
        "AVAILABLE",
        "PARTIAL",
        "UNAVAILABLE",
        "UNSUPPORTED",
        "LIMITED_EVIDENCE",
    ]
    limitations: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_table_inventory(self) -> UnifiedPdfTable:
        """Bind cells and document-table identities to declared table bounds."""
        anchors = tuple((cell.row_index, cell.column_index) for cell in self.cells)
        if len(set(anchors)) != len(anchors) or any(
            cell.row_index + cell.row_span > self.row_count
            or cell.column_index + cell.column_span > self.column_count
            for cell in self.cells
        ):
            raise ValueError("table cell inventory exceeds declared bounds")
        if len(set(self.document_table_ids)) != len(self.document_table_ids) or any(
            re.fullmatch(r"P3CE1-document-table-[0-9a-f]{64}", value) is None
            for value in self.document_table_ids
        ):
            raise ValueError("document table identity inventory is invalid")
        if self.limitations != tuple(sorted(set(self.limitations))):
            raise ValueError("table limitations must be sorted and unique")
        if self.availability == "AVAILABLE" and (
            self.limitations
            or any(cell.availability != "AVAILABLE" for cell in self.cells)
        ):
            raise ValueError("available table contains limited cell evidence")
        if self.availability in {"PARTIAL", "LIMITED_EVIDENCE"} and not (
            self.limitations
            or any(cell.availability != "AVAILABLE" for cell in self.cells)
        ):
            raise ValueError("limited table lacks limitation evidence")
        if self.availability in {"UNAVAILABLE", "UNSUPPORTED"} and not self.limitations:
            raise ValueError("unavailable table lacks limitation evidence")
        return self


def _validate_hybrid_codes(
    values: tuple[str, ...],
    *,
    label: str,
    maximum_items: int,
    allowed: frozenset[str],
) -> None:
    if len(values) > maximum_items:
        raise ValueError(f"{label} exceeds its fixed inventory bound")
    if values != tuple(sorted(set(values))):
        raise ValueError(f"{label} must be sorted and unique")
    if any(
        not value.isascii()
        or not value.isprintable()
        or _SAFE_HYBRID_METADATA_CODE.fullmatch(value) is None
        or value not in allowed
        for value in values
    ):
        raise ValueError(f"{label} contains an unsupported code")


class UnifiedPdfHybridCapabilityOutcome(SdkModel):
    """Stable content-safe projection of one effective Hybrid capability."""

    page_number: int = Field(ge=1, le=_MAX_HYBRID_PAGES)
    capability: Literal["OCR_TEXT", "LAYOUT", "TABLES"]
    state: Literal[
        "FULFILLED",
        "PARTIAL",
        "NOT_APPLIED",
        "UNAVAILABLE",
        "CONFLICT",
    ]
    reason_codes: tuple[str, ...] = Field(
        default=(),
        max_length=_MAX_HYBRID_CAPABILITY_REASON_CODES,
    )

    @model_validator(mode="after")
    def validate_outcome(self) -> UnifiedPdfHybridCapabilityOutcome:
        """Bind application state to canonical fixed public reason codes."""
        _validate_hybrid_codes(
            self.reason_codes,
            label="Hybrid capability reasons",
            maximum_items=_MAX_HYBRID_CAPABILITY_REASON_CODES,
            allowed=_HYBRID_CAPABILITY_REASON_CODES,
        )
        if self.state == "FULFILLED":
            if self.reason_codes:
                raise ValueError("fulfilled Hybrid capability cannot carry reasons")
        elif not self.reason_codes:
            raise ValueError("unfulfilled Hybrid capability requires a reason")
        if self.state == "CONFLICT" and self.capability != "TABLES":
            raise ValueError("only table authority can carry a Hybrid conflict")
        return self


class UnifiedPdfHybridSummary(SdkModel):
    """Bounded public operational summary for private Canonical Hybrid analysis."""

    cloud_status: Literal[
        "NOT_REQUESTED",
        "NOT_EXECUTED_DISABLED",
        "NOT_EXECUTED_PROVIDER_UNAVAILABLE",
        "NOT_EXECUTED_LIMIT",
        "COMPLETED",
        "COMPLETED_PARTIAL",
        "FAILED_CONTROLLED",
    ]
    submission_status: Literal["NOT_SUBMITTED", "SUBMITTED", "UNKNOWN"]
    submission_payload_scope: Literal["NOT_APPLICABLE", "FULL_DOCUMENT_BYTES"]
    analysis_selection_scope: Literal["NOT_APPLICABLE", "SELECTED_PAGES"]
    provider_name: Literal["azure-document-intelligence"] = (
        "azure-document-intelligence"
    )
    model_id: Literal["prebuilt-layout"] | None = None
    api_version: Literal["2024-11-30"] | None = None
    requested_page_numbers: tuple[int, ...] = Field(
        default=(),
        max_length=_MAX_HYBRID_PAGES,
    )
    returned_page_numbers: tuple[int, ...] = Field(
        default=(),
        max_length=_MAX_HYBRID_PAGES,
    )
    applied_page_numbers: tuple[int, ...] = Field(
        default=(),
        max_length=_MAX_HYBRID_PAGES,
    )
    effective_capability_outcomes: tuple[
        UnifiedPdfHybridCapabilityOutcome,
        ...,
    ] = Field(default=(), max_length=_MAX_HYBRID_CAPABILITY_OUTCOMES)
    local_preserved_text_count: int = Field(ge=0, le=_MAX_HYBRID_ITEM_COUNT)
    cloud_filled_text_count: int = Field(ge=0, le=_MAX_HYBRID_ITEM_COUNT)
    local_preserved_table_count: int = Field(ge=0, le=_MAX_HYBRID_ITEM_COUNT)
    cloud_filled_table_count: int = Field(ge=0, le=_MAX_HYBRID_ITEM_COUNT)
    conflict_count: int = Field(ge=0, le=_MAX_HYBRID_ITEM_COUNT)
    continuity_unavailable_count: int = Field(ge=0, le=_MAX_HYBRID_ITEM_COUNT)
    review_required: bool
    deletion_status: Literal[
        "NOT_REQUESTED",
        "SUCCEEDED",
        "FAILED",
        "UNAVAILABLE",
    ]
    failure_category: (
        Literal[
            "CLOUD_PROVIDER_UNAVAILABLE",
            "CLOUD_CONFIGURATION_ERROR",
            "CLOUD_REQUEST_LIMIT",
            "CLOUD_PROVIDER_TIMEOUT",
            "CLOUD_PROVIDER_REJECTED",
            "CLOUD_RESPONSE_INVALID",
            "CLOUD_RESULT_LIMIT_EXCEEDED",
            "CLOUD_DELETE_FAILED",
            "CLOUD_ANALYSIS_FAILED",
        ]
        | None
    ) = None
    warnings: tuple[str, ...] = Field(
        default=(),
        max_length=_MAX_HYBRID_METADATA_CODES,
    )
    limitations: tuple[str, ...] = Field(
        default=(),
        max_length=_MAX_HYBRID_METADATA_CODES,
    )

    @model_validator(mode="after")
    def validate_summary(  # noqa: C901, PLR0912, PLR0915
        self,
    ) -> UnifiedPdfHybridSummary:
        """Reject noncanonical inventories and contradictory lifecycle claims."""
        for label, values in (
            ("requested Hybrid pages", self.requested_page_numbers),
            ("returned Hybrid pages", self.returned_page_numbers),
            ("applied Hybrid pages", self.applied_page_numbers),
        ):
            if values != tuple(sorted(set(values))) or any(
                not 1 <= value <= _MAX_HYBRID_PAGES for value in values
            ):
                raise ValueError(f"{label} must be positive, sorted, and unique")
        if not set(self.returned_page_numbers) <= set(self.requested_page_numbers):
            raise ValueError("returned Hybrid pages exceed the requested inventory")
        if not set(self.applied_page_numbers) <= set(self.returned_page_numbers):
            raise ValueError("applied Hybrid pages exceed the returned inventory")

        rebuilt_outcomes: list[UnifiedPdfHybridCapabilityOutcome] = []
        expected_fields = set(UnifiedPdfHybridCapabilityOutcome.model_fields)
        for outcome in self.effective_capability_outcomes:
            if (
                type(outcome) is not UnifiedPdfHybridCapabilityOutcome
                or set(outcome.__dict__) != expected_fields
                or outcome.__pydantic_extra__
            ):
                raise ValueError("Hybrid capability outcome is invalid")
            rebuilt_outcomes.append(
                UnifiedPdfHybridCapabilityOutcome.model_validate(
                    {
                        field_name: outcome.__dict__[field_name]
                        for field_name in UnifiedPdfHybridCapabilityOutcome.model_fields
                    }
                )
            )
        outcomes = tuple(rebuilt_outcomes)
        object.__setattr__(self, "effective_capability_outcomes", outcomes)
        outcome_keys = tuple(
            (outcome.page_number, outcome.capability) for outcome in outcomes
        )
        if outcome_keys != tuple(sorted(set(outcome_keys))):
            raise ValueError("Hybrid capability outcomes must be canonical")
        if any(
            outcome.page_number not in self.requested_page_numbers
            for outcome in outcomes
        ):
            raise ValueError("Hybrid capability outcome references an unrequested page")
        fulfilled_pages = {
            outcome.page_number for outcome in outcomes if outcome.state == "FULFILLED"
        }
        potentially_applied_pages = {
            outcome.page_number
            for outcome in outcomes
            if outcome.state in {"FULFILLED", "PARTIAL"}
        }
        applied_pages = set(self.applied_page_numbers)
        if not fulfilled_pages <= applied_pages <= potentially_applied_pages:
            raise ValueError("Hybrid applied-page accounting is inconsistent")
        if self.conflict_count != sum(
            outcome.capability == "TABLES" and outcome.state == "CONFLICT"
            for outcome in outcomes
        ):
            raise ValueError("Hybrid conflict accounting is inconsistent")
        if self.conflict_count and not self.review_required:
            raise ValueError("Hybrid conflict requires review")

        _validate_hybrid_codes(
            self.warnings,
            label="Hybrid warnings",
            maximum_items=_MAX_HYBRID_METADATA_CODES,
            allowed=_HYBRID_WARNING_CODES,
        )
        _validate_hybrid_codes(
            self.limitations,
            label="Hybrid limitations",
            maximum_items=_MAX_HYBRID_METADATA_CODES,
            allowed=_HYBRID_LIMITATION_CODES,
        )
        if (self.limitations or self.continuity_unavailable_count) and not (
            self.review_required
        ):
            raise ValueError("Hybrid limitations require review")

        no_execution_statuses = {
            "NOT_REQUESTED",
            "NOT_EXECUTED_DISABLED",
            "NOT_EXECUTED_PROVIDER_UNAVAILABLE",
            "NOT_EXECUTED_LIMIT",
        }
        if self.cloud_status in no_execution_statuses:
            if (
                self.submission_status != "NOT_SUBMITTED"
                or self.submission_payload_scope != "NOT_APPLICABLE"
                or self.analysis_selection_scope != "NOT_APPLICABLE"
                or self.returned_page_numbers
                or self.applied_page_numbers
                or outcomes
                or self.cloud_filled_text_count
                or self.cloud_filled_table_count
                or self.conflict_count
                or self.continuity_unavailable_count
                or self.model_id is not None
                or self.api_version is not None
                or self.deletion_status != "NOT_REQUESTED"
            ):
                raise ValueError("non-executed Hybrid status carries Cloud evidence")
        elif self.cloud_status in {"COMPLETED", "COMPLETED_PARTIAL"}:
            if (
                self.submission_status != "SUBMITTED"
                or self.submission_payload_scope != "FULL_DOCUMENT_BYTES"
                or self.analysis_selection_scope != "SELECTED_PAGES"
                or self.model_id != "prebuilt-layout"
                or self.api_version != "2024-11-30"
                or self.deletion_status == "NOT_REQUESTED"
                or not self.requested_page_numbers
            ):
                raise ValueError("completed Hybrid status lacks submitted evidence")
            if {outcome.page_number for outcome in outcomes} != set(
                self.requested_page_numbers
            ):
                raise ValueError(
                    "completed Hybrid status lacks requested-page outcomes"
                )
            if self.deletion_status in {"FAILED", "UNAVAILABLE"} and (
                self.cloud_status != "COMPLETED_PARTIAL"
                or "CLOUD_DELETE_FAILED" not in self.limitations
                or not self.review_required
            ):
                raise ValueError("Hybrid deletion failure evidence is incomplete")
        else:
            retained_artifact = self.submission_status == "SUBMITTED"
            if (
                self.submission_payload_scope != "FULL_DOCUMENT_BYTES"
                or self.analysis_selection_scope != "SELECTED_PAGES"
                or self.applied_page_numbers
                or outcomes
                or self.cloud_filled_text_count
                or self.cloud_filled_table_count
                or self.conflict_count
            ):
                raise ValueError("controlled Hybrid failure has contradictory evidence")
            if retained_artifact:
                if (
                    self.model_id != "prebuilt-layout"
                    or self.api_version != "2024-11-30"
                    or self.failure_category != "CLOUD_DELETE_FAILED"
                    or self.deletion_status not in {"FAILED", "UNAVAILABLE"}
                    or "CLOUD_DELETE_FAILED" not in self.limitations
                    or not self.review_required
                ):
                    raise ValueError("retained Cloud artifact evidence is incomplete")
            elif (
                self.submission_status != "UNKNOWN"
                or self.model_id is not None
                or self.api_version is not None
                or self.returned_page_numbers
                or self.deletion_status != "UNAVAILABLE"
            ):
                raise ValueError("ambiguous Hybrid submission evidence is inconsistent")
        if "CLOUD_DELETE_FAILED" in self.limitations and self.deletion_status not in {
            "FAILED",
            "UNAVAILABLE",
        }:
            raise ValueError("Hybrid deletion limitation contradicts its status")

        if self.cloud_status == "NOT_REQUESTED" and (
            self.requested_page_numbers
            or self.failure_category is not None
            or self.review_required
        ):
            raise ValueError("unrequested Hybrid status carries routing evidence")
        expected_no_execution_failure = {
            "NOT_EXECUTED_PROVIDER_UNAVAILABLE": "CLOUD_PROVIDER_UNAVAILABLE",
            "NOT_EXECUTED_LIMIT": "CLOUD_REQUEST_LIMIT",
        }.get(self.cloud_status)
        if self.cloud_status in no_execution_statuses - {"NOT_REQUESTED"} and (
            self.failure_category != expected_no_execution_failure
            or not self.review_required
        ):
            raise ValueError("non-executed Hybrid failure category is inconsistent")
        if self.cloud_status == "COMPLETED" and (
            self.returned_page_numbers != self.requested_page_numbers
            or self.review_required
            or self.conflict_count
            or any(outcome.state != "FULFILLED" for outcome in outcomes)
            or self.deletion_status != "SUCCEEDED"
            or self.failure_category is not None
        ):
            raise ValueError("completed Hybrid status is not exact")
        if self.cloud_status == "COMPLETED_PARTIAL" and not (
            self.returned_page_numbers != self.requested_page_numbers
            or self.review_required
            or self.conflict_count
            or any(outcome.state != "FULFILLED" for outcome in outcomes)
        ):
            raise ValueError("partial Hybrid status lacks partial evidence")
        if self.cloud_status == "FAILED_CONTROLLED":
            if (
                self.failure_category is None
                or not self.requested_page_numbers
                or not self.review_required
                or self.continuity_unavailable_count
            ):
                raise ValueError("controlled Hybrid failure lacks a fixed category")
        elif (
            self.cloud_status
            not in {
                "NOT_EXECUTED_PROVIDER_UNAVAILABLE",
                "NOT_EXECUTED_LIMIT",
            }
            and self.failure_category is not None
        ):
            raise ValueError("Hybrid failure category is inconsistent with status")
        return self


def _validate_member_link_overflow_contract(
    link: PdfLocalCellMemberLink,
    table: UnifiedPdfTable | None,
    *,
    result_availability: Literal["AVAILABLE", "PARTIAL", "UNAVAILABLE"],
) -> None:
    """Preserve source-anchored overflow evidence instead of recasting it as strict."""
    text_parts = link.text_parts
    has_overflow = any(
        part.source_anchored_overflow_id is not None for part in text_parts
    )
    requires_overflow = (
        table is not None
        and "source_anchored_grid_contains_actual_overflow" in table.limitations
    )
    if requires_overflow != has_overflow:
        raise ValueError("public table overflow provenance was removed or invented")
    if has_overflow and (
        table is None
        or table.availability == "AVAILABLE"
        or result_availability == "AVAILABLE"
    ):
        raise ValueError("public table cannot promote source overflow evidence")


def _validate_complete_member_link_inventory(
    evidence: PdfLocalEvidenceV2 | PdfLocalEvidenceV3,
    cells: dict[tuple[str, int, int, int, int], tuple[int, str | None]],
) -> None:
    """Untruncated public evidence must account for every public table cell."""
    for page in evidence.pages:
        if page.projection_truncated:
            continue
        expected_links = {
            key
            for key, (page_number, _text) in cells.items()
            if page_number == page.page_number
        }
        observed_links = {
            (
                link.table_id,
                link.row_index,
                link.column_index,
                link.row_span,
                link.column_span,
            )
            for link in page.cell_member_links
        }
        if observed_links != expected_links:
            raise ValueError(
                "complete local member evidence must cover every public table cell"
            )


class UnifiedPdfResult(SdkModel):
    """Stable public projection of private Canonical evidence."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)
    schema_version: Literal["document_sdk.pdf.unified_result.v4"] = (
        UNIFIED_PDF_RESULT_VERSION
    )
    document_id: str = Field(pattern=r"^P3CE1-document-[0-9a-f]{64}$")
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    status: Literal["COMPLETED"]
    availability: Literal["AVAILABLE", "PARTIAL", "UNAVAILABLE"]
    page_count: int = Field(ge=0)
    pages: tuple[UnifiedPdfPage, ...]
    text: str
    tables: tuple[UnifiedPdfTable, ...]
    document_table_count: int = Field(ge=0)
    transition_count: int = Field(ge=0)
    warnings: tuple[str, ...] = ()
    limitations: tuple[str, ...] = ()
    provenance: _UnifiedPdfProvenance
    family: None = None
    family_status: Literal["REVIEW_REQUIRED"] = "REVIEW_REQUIRED"
    family_auto_assignment: bool = False
    processing_mode: PdfAnalysisMode
    local_evidence: (
        PdfLocalEvidence | PdfLocalEvidenceV2 | PdfLocalEvidenceV3 | None
    ) = None

    @model_validator(mode="after")
    def validate_public_contract(self) -> UnifiedPdfResult:
        """Keep Family deferred and page-table membership self-consistent."""
        if self.family is not None or self.family_auto_assignment:
            raise ValueError("automatic Family assignment is unavailable")
        if self.processing_mode is PdfAnalysisMode.STANDARD:
            raise ValueError("unified result requires an advanced processing mode")
        if (self.processing_mode is PdfAnalysisMode.ADVANCED_HYBRID) != (
            str(self.schema_version) == UNIFIED_PDF_HYBRID_RESULT_VERSION
        ):
            raise ValueError("Hybrid mode requires the distinct Hybrid result schema")
        if self.page_count != len(self.pages) or tuple(
            page.page_number for page in self.pages
        ) != tuple(range(1, self.page_count + 1)):
            raise ValueError("public page inventory accounting mismatch")
        table_ids = tuple(table.table_id for table in self.tables)
        if len(set(table_ids)) != len(table_ids):
            raise ValueError("public table inventory repeats an identity")
        page_numbers = {page.page_number for page in self.pages}
        if any(table.page_number not in page_numbers for table in self.tables):
            raise ValueError("public table references a missing page")
        for page in self.pages:
            expected_table_ids = tuple(
                table.table_id
                for table in self.tables
                if table.page_number == page.page_number
            )
            if page.table_ids != expected_table_ids:
                raise ValueError("public page-table binding mismatch")
        return self

    def _canonical_cell_sources(
        self,
    ) -> dict[tuple[str, int, int, int, int], tuple[str, str]]:
        from document_sdk.pdf._structural_engine.canonical.contracts import (
            CanonicalPageGeometry,
            CanonicalTable,
        )
        from document_sdk.pdf._structural_engine.canonical.identifiers import (
            canonical_identifier,
        )

        identities = {}
        pages = {page.page_number: page for page in self.pages}
        source_pages = (
            {}
            if self.local_evidence is None
            else {page.page_number: page for page in self.local_evidence.pages}
        )
        for table in self.tables:
            witness = table.source_identity
            if witness is None:
                continue
            table_payload = thaw_json_mapping(witness.canonical_table)
            source = CanonicalTable.model_validate_json(json.dumps(table_payload))
            page_payload = thaw_json_mapping(witness.canonical_page_identity)
            if set(page_payload) != {
                "source_page_id",
                "page_index",
                "page_number",
                "geometry",
            }:
                raise ValueError("canonical source identity page fields mismatch")
            geometry = CanonicalPageGeometry.model_validate_json(
                json.dumps(page_payload["geometry"])
            )
            page = pages[table.page_number]
            source_page = source_pages.get(table.page_number)
            if (
                source.table_id != table.table_id
                or source.page_id != canonical_identifier("page", page_payload)
                or page_payload["page_number"] != table.page_number
                or page_payload["page_index"] != table.page_number - 1
                or (
                    geometry.canonical_width,
                    geometry.canonical_height,
                    geometry.rotation,
                )
                != (page.width_points, page.height_points, page.rotation)
                or (
                    source.row_count,
                    source.column_count,
                    source.document_table_ids,
                    source.availability.state,
                    source.limitation_codes,
                )
                != (
                    table.row_count,
                    table.column_count,
                    table.document_table_ids,
                    table.availability,
                    table.limitations,
                )
                or len(source.cells) != len(table.cells)
            ):
                raise ValueError(
                    "canonical source identity table/page projection mismatch"
                )
            if isinstance(source_page, PdfLocalPageEvidenceV2) and (
                page_payload["source_page_id"] != source_page.source_page_id
            ):
                raise ValueError(
                    "canonical source identity belongs to another source page"
                )
            for canonical_cell, cell in zip(source.cells, table.cells, strict=True):
                if (
                    canonical_cell.row_index,
                    canonical_cell.column_index,
                    canonical_cell.row_span,
                    canonical_cell.column_span,
                    canonical_cell.text,
                    canonical_cell.availability.state,
                ) != (
                    cell.row_index,
                    cell.column_index,
                    cell.row_span,
                    cell.column_span,
                    cell.text,
                    cell.availability,
                ):
                    raise ValueError(
                        "canonical source identity cell projection mismatch"
                    )
                identities[
                    (
                        table.table_id,
                        cell.row_index,
                        cell.column_index,
                        cell.row_span,
                        cell.column_span,
                    )
                ] = (source.source_table_id, canonical_cell.source_cell_id)
        return identities

    @model_validator(mode="after")
    def validate_local_evidence_binding(self) -> UnifiedPdfResult:
        """Bind retained evidence to source and pages with one page-set build."""
        canonical_sources = self._canonical_cell_sources()
        if self.local_evidence is not None:
            evidence_page_numbers = {
                evidence.page_number for evidence in self.local_evidence.pages
            }
            if (
                self.local_evidence.source_sha256 != self.source_sha256
                or self.local_evidence.source_page_count < self.page_count
                or (
                    self.local_evidence.extraction_status == "success"
                    and self.local_evidence.source_page_count != self.page_count
                )
                or any(
                    page.page_number not in evidence_page_numbers for page in self.pages
                )
            ):
                raise ValueError("local evidence source binding mismatch")
            if isinstance(
                self.local_evidence, (PdfLocalEvidenceV2, PdfLocalEvidenceV3)
            ):
                cells = {
                    (
                        table.table_id,
                        cell.row_index,
                        cell.column_index,
                        cell.row_span,
                        cell.column_span,
                    ): (table.page_number, cell.text)
                    for table in self.tables
                    for cell in table.cells
                }
                public_tables = {table.table_id: table for table in self.tables}
                _validate_complete_member_link_inventory(self.local_evidence, cells)
                for page in self.local_evidence.pages:
                    for link in page.cell_member_links:
                        observed = cells.get(
                            (
                                link.table_id,
                                link.row_index,
                                link.column_index,
                                link.row_span,
                                link.column_span,
                            )
                        )
                        key = (
                            link.table_id,
                            link.row_index,
                            link.column_index,
                            link.row_span,
                            link.column_span,
                        )
                        if (
                            isinstance(self.local_evidence, PdfLocalEvidenceV3)
                            or key in canonical_sources
                        ) and canonical_sources.get(key) != (
                            link.source_table_id,
                            link.source_cell_id,
                        ):
                            raise ValueError(
                                "local member link canonical source identity mismatch"
                            )
                        table = public_tables.get(link.table_id)
                        _validate_member_link_overflow_contract(
                            link,
                            table,
                            result_availability=self.availability,
                        )
                        if observed != (page.page_number, link.text):
                            raise ValueError(
                                "local member evidence does not bind "
                                "the actual public cell"
                            )
        return self

    @model_validator(mode="after")
    def validate_structural_accounting(self) -> UnifiedPdfResult:
        """Bind aggregate counts and text to the projected structural inventory."""
        page_numbers = {page.page_number for page in self.pages}
        document_table_ids = {
            value for table in self.tables for value in table.document_table_ids
        }
        if self.document_table_count != len(document_table_ids):
            raise ValueError("public document-table accounting mismatch")
        table_count_by_page = dict.fromkeys(page_numbers, 0)
        for table in self.tables:
            table_count_by_page[table.page_number] += 1
        maximum_transitions = sum(
            table_count_by_page[page_number] * table_count_by_page[page_number + 1]
            for page_number in range(1, self.page_count)
        )
        if self.transition_count > maximum_transitions:
            raise ValueError("public transition accounting exceeds bounded inventory")
        if self.text != "\n\n".join(page.text for page in self.pages):
            raise ValueError("public document text does not match page inventory")
        if self.warnings != tuple(sorted(set(self.warnings))) or self.limitations != (
            tuple(sorted(set(self.limitations)))
        ):
            raise ValueError("public code inventories must be sorted and unique")
        return self

    @model_validator(mode="after")
    def validate_availability(self) -> UnifiedPdfResult:
        """Require availability to agree with in-scope limitation evidence."""
        non_available_structural_evidence = any(
            page.availability != "AVAILABLE" for page in self.pages
        ) or any(
            table.availability != "AVAILABLE"
            or any(cell.availability != "AVAILABLE" for cell in table.cells)
            for table in self.tables
        )
        capability_limitations = tuple(
            limitation
            for limitation in self.limitations
            if limitation not in _NON_CAPABILITY_LIMITATIONS
        )
        reasonless_non_available_page = any(
            page.availability != "AVAILABLE" and not page.limitations
            for page in self.pages
        )
        if reasonless_non_available_page and not capability_limitations:
            raise ValueError("non-available page lacks aggregate limitation evidence")
        if self.availability == "AVAILABLE" and (
            capability_limitations or non_available_structural_evidence
        ):
            raise ValueError("available public result contains limited evidence")
        if self.availability == "PARTIAL" and not (
            capability_limitations or non_available_structural_evidence
        ):
            raise ValueError("partial public result lacks limited evidence")
        if self.availability == "UNAVAILABLE" and (
            self.page_count
            or self.pages
            or self.tables
            or self.document_table_count
            or self.transition_count
            or self.text
        ):
            raise ValueError("unavailable public result contains structural evidence")
        return self

    def to_json_dict(self) -> dict[str, object]:
        """Return only JSON-native values under the versioned public schema."""
        payload = self.model_dump(mode="json")
        validated = type(self).model_validate_json(
            json.dumps(
                payload,
                ensure_ascii=False,
                allow_nan=False,
                sort_keys=True,
                separators=(",", ":"),
            )
        )
        return validated.model_dump(mode="json")

    def to_json_bytes(self) -> bytes:
        """Return deterministic finite UTF-8 JSON bytes."""
        return json.dumps(
            self.to_json_dict(),
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")

    def to_v3_json_dict(self) -> dict[str, object]:
        """Return the legacy v3 shape with only v1 local observations.

        Member pools, native events and table ownership proofs are omitted.
        This lossy view does not modify the full v4 result or its limitations.
        """
        payload = self.model_dump(mode="json", exclude={"local_evidence"})
        for table in payload["tables"]:
            table.pop("source_identity", None)
        payload["schema_version"] = (
            "document_sdk.pdf.unified_hybrid_result.v3"
            if self.processing_mode is PdfAnalysisMode.ADVANCED_HYBRID
            else "document_sdk.pdf.unified_result.v3"
        )
        local = self.local_evidence
        if local is None:
            payload["local_evidence"] = None
        elif isinstance(local, PdfLocalEvidence):
            payload["local_evidence"] = local.model_dump(mode="json")
        else:
            legacy = PdfLocalEvidence(
                source_sha256=local.source_sha256,
                source_page_count=local.source_page_count,
                extraction_status=local.extraction_status,
                warnings=local.warnings,
                pages=tuple(
                    PdfLocalPageEvidence.model_validate_json(
                        page.model_dump_json(
                            include=set(PdfLocalPageEvidence.model_fields)
                        )
                    )
                    for page in local.pages
                ),
            )
            payload["local_evidence"] = legacy.model_dump(mode="json")
        return payload

    def to_v3_json_bytes(self) -> bytes:
        """Return deterministic UTF-8 JSON for the explicit v3 downgrade."""
        return json.dumps(
            self.to_v3_json_dict(),
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")

    def to_v2_json_dict(self) -> dict[str, object]:
        """Project the strict v2 shape, intentionally omitting local evidence.

        This explicit compatibility downgrade preserves the original v2
        content fields. Use the default v4 serialization to retain the full
        source-bound local evidence. The result instance is not modified.
        """
        payload = self.model_dump(mode="json", exclude={"local_evidence"})
        for table in payload["tables"]:
            table.pop("source_identity", None)
        payload["schema_version"] = (
            "document_sdk.pdf.unified_hybrid_result.v2"
            if self.processing_mode is PdfAnalysisMode.ADVANCED_HYBRID
            else "document_sdk.pdf.unified_result.v2"
        )
        return payload

    def to_v2_json_bytes(self) -> bytes:
        """Return deterministic UTF-8 JSON for the explicit v2 downgrade."""
        return json.dumps(
            self.to_v2_json_dict(),
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")


class UnifiedPdfHybridResult(UnifiedPdfResult):
    """Unified structural result with a bounded Hybrid execution summary."""

    schema_version: Literal[  # pyright: ignore[reportIncompatibleVariableOverride]
        "document_sdk.pdf.unified_hybrid_result.v4"
    ] = UNIFIED_PDF_HYBRID_RESULT_VERSION  # type: ignore[assignment]
    processing_mode: Literal[  # pyright: ignore[reportIncompatibleVariableOverride]
        PdfAnalysisMode.ADVANCED_HYBRID
    ] = PdfAnalysisMode.ADVANCED_HYBRID
    hybrid: UnifiedPdfHybridSummary

    @model_validator(mode="after")
    def revalidate_hybrid_summary(self) -> UnifiedPdfHybridResult:
        """Do not trust a copied or constructed nested public summary."""
        expected_fields = set(UnifiedPdfHybridSummary.model_fields)
        if (
            type(self.hybrid) is not UnifiedPdfHybridSummary
            or set(self.hybrid.__dict__) != expected_fields
            or self.hybrid.__pydantic_extra__
        ):
            raise ValueError("Hybrid summary is invalid")
        summary = UnifiedPdfHybridSummary.model_validate(
            {
                field_name: self.hybrid.__dict__[field_name]
                for field_name in UnifiedPdfHybridSummary.model_fields
            }
        )
        object.__setattr__(self, "hybrid", summary)
        if any(
            page_number > self.page_count
            for page_number in summary.requested_page_numbers
        ):
            raise ValueError("Hybrid routing references a missing public page")
        if (
            summary.local_preserved_table_count + summary.cloud_filled_table_count
            != len(self.tables)
        ):
            raise ValueError("Hybrid table accounting is inconsistent")
        return self


def _map_canonical_document(
    canonical: CanonicalDocument,
    *,
    mode: PdfAnalysisMode,
    local_evidence: PdfLocalEvidence
    | PdfLocalEvidenceV2
    | PdfLocalEvidenceV3
    | None = None,
) -> UnifiedPdfResult:
    page_number_by_id = {item.page_id: item.page_number for item in canonical.pages}
    pages = tuple(
        UnifiedPdfPage(
            page_number=page.page_number,
            width_points=page.geometry.canonical_width,
            height_points=page.geometry.canonical_height,
            rotation=page.geometry.rotation,
            text="\n".join(block.text for block in page.text_blocks),
            table_ids=page.table_ids,
            availability=page.availability.state,
            limitations=page.limitation_codes,
        )
        for page in canonical.pages
    )
    canonical_pages = {page.page_id: page for page in canonical.pages}
    tables = tuple(
        UnifiedPdfTable(
            source_identity=UnifiedPdfTableSourceIdentity(
                canonical_table=table.model_dump(mode="json"),
                canonical_page_identity=canonical_pages[table.page_id].model_dump(
                    mode="json",
                    include={"source_page_id", "page_index", "page_number", "geometry"},
                ),
            ),
            table_id=table.table_id,
            page_number=page_number_by_id[table.page_id],
            row_count=table.row_count,
            column_count=table.column_count,
            cells=tuple(
                UnifiedPdfTableCell(
                    row_index=cell.row_index,
                    column_index=cell.column_index,
                    row_span=cell.row_span,
                    column_span=cell.column_span,
                    text=cell.text,
                    availability=cell.availability.state,
                )
                for cell in table.cells
            ),
            document_table_ids=table.document_table_ids,
            availability=table.availability.state,
            limitations=table.limitation_codes,
        )
        for table in canonical.tables
    )
    warning_codes = tuple(sorted({warning.code for warning in canonical.warnings}))
    requested_capabilities = {
        "document_table",
        "facts",
        "layout",
        "page_table",
        "reading",
        "transition_fingerprint",
        "transitions",
    }
    capability_states = {
        item.capability: item.availability.state
        for item in canonical.capability_availability
        if item.capability in requested_capabilities
    }
    capability_limitations = tuple(
        limitation
        for limitation in canonical.limitations
        if limitation not in _NON_CAPABILITY_LIMITATIONS
    )
    advanced_availability: Literal["AVAILABLE", "PARTIAL"] = (
        "AVAILABLE"
        if set(capability_states) == requested_capabilities
        and set(capability_states.values()) == {"AVAILABLE"}
        and canonical.availability.state == "AVAILABLE"
        and not capability_limitations
        else "PARTIAL"
    )
    return UnifiedPdfResult(
        document_id=canonical.canonical_document_id,
        source_sha256=canonical.provenance.source_sha256,
        status="COMPLETED",
        availability=advanced_availability,
        page_count=canonical.page_count,
        pages=pages,
        text="\n\n".join(page.text for page in pages),
        tables=tables,
        document_table_count=len(canonical.document_tables),
        transition_count=len(canonical.transitions),
        warnings=warning_codes,
        limitations=canonical.limitations,
        provenance=_UnifiedPdfProvenance(
            advanced_internal_limits_profile=_ADVANCED_INTERNAL_LIMITS_PROFILE,
            advanced_internal_limits_profile_version=(
                _ADVANCED_INTERNAL_LIMITS_PROFILE_VERSION
            ),
            canonical_schema_version=canonical.canonical_version,
            canonical_projection_version=canonical.projection_version,
            source_parser=canonical.provenance.source_parser_name,
        ),
        family=None,
        family_status=canonical.family_status,
        family_auto_assignment=False,
        processing_mode=mode,
        local_evidence=local_evidence,
    )


def _read_source(
    source: bytes | bytearray | memoryview | str | PathLike[str],
    *,
    maximum_bytes: int,
) -> bytes:
    if isinstance(source, bytes):
        content = source
    elif isinstance(source, bytearray):
        if len(source) > maximum_bytes:
            raise PdfLimitExceededError(
                limit_name="file bytes",
                observed=len(source),
                maximum=maximum_bytes,
            )
        content = bytes(source)
    elif isinstance(source, memoryview):
        if source.nbytes > maximum_bytes:
            raise PdfLimitExceededError(
                limit_name="file bytes",
                observed=source.nbytes,
                maximum=maximum_bytes,
            )
        content = bytes(source)
    elif isinstance(source, (str, Path)) or hasattr(source, "__fspath__"):
        path = Path(source)
        if path.suffix.casefold() != ".pdf":
            raise UnsupportedFileError("PDF APIs require a .pdf file")
        with path.open("rb") as stream:
            content = stream.read(maximum_bytes + 1)
    else:
        raise InvalidSourceReferenceError(
            "PDF source must be bytes or a local .pdf path"
        )
    if len(content) > maximum_bytes:
        raise PdfLimitExceededError(
            limit_name="file bytes",
            observed=len(content),
            maximum=maximum_bytes,
        )
    return content


def _revalidate_analysis_options(
    options: UnifiedPdfAnalysisOptions | None,
) -> UnifiedPdfAnalysisOptions:
    if options is None:
        return UnifiedPdfAnalysisOptions()
    try:
        if type(options) is not UnifiedPdfAnalysisOptions:
            raise TypeError
        expected_option_fields = set(UnifiedPdfAnalysisOptions.model_fields)
        if (
            set(options.__dict__) != expected_option_fields
            or options.__pydantic_extra__
        ):
            raise TypeError
        limits = options.__dict__["limits"]
        if type(limits) is not PdfProcessingLimits:
            raise TypeError
        expected_limit_fields = set(PdfProcessingLimits.model_fields)
        if set(limits.__dict__) != expected_limit_fields or limits.__pydantic_extra__:
            raise TypeError
        return UnifiedPdfAnalysisOptions.model_validate(
            {
                "mode": options.__dict__["mode"],
                "limits": {
                    field_name: limits.__dict__[field_name]
                    for field_name in PdfProcessingLimits.model_fields
                },
            }
        )
    except (KeyError, TypeError, ValidationError) as error:
        _raise_redacted_translation(
            error,
            InvalidSourceReferenceError("PDF analysis options are invalid"),
        )


def _effective_advanced_limits(
    requested: PdfProcessingLimits,
) -> PdfProcessingLimits:
    from document_sdk.pdf._structural_engine.runtime.full_pipeline import (
        _effective_full_local_processing_limits,
    )

    return _effective_full_local_processing_limits(requested)


def _require_advanced_pdf_support() -> None:
    """Fail before source access when the complete local PDF stack is absent."""
    try:
        for module_name in _ADVANCED_PDF_DEPENDENCIES:
            import_module(module_name)
    except Exception as error:  # noqa: BLE001 - optional dependency import boundary.
        _raise_redacted_translation(
            error,
            DependencyNotInstalledError(PDF_DEPENDENCY_MESSAGE),
        )


def analyze_pdf(
    source: bytes | bytearray | memoryview | str | PathLike[str],
    *,
    options: UnifiedPdfAnalysisOptions | None = None,
    hybrid_provider: AzureDocumentIntelligenceProvider | None = None,
    password: str | None = None,
) -> UnifiedPdfResult:
    """Analyze a PDF through one explicit advanced public mode."""
    return _analyze_pdf_with_canonical(
        source, options=options, hybrid_provider=hybrid_provider, password=password
    )[0]


def _analyze_pdf_with_canonical(  # noqa: C901 - unchanged legacy analysis boundary.
    source: bytes | bytearray | memoryview | str | PathLike[str],
    *,
    options: UnifiedPdfAnalysisOptions | None = None,
    hybrid_provider: AzureDocumentIntelligenceProvider | None = None,
    password: str | None = None,
) -> tuple[UnifiedPdfResult, CanonicalDocument, bytes]:
    """Retain same-call Canonical evidence without altering the legacy pipeline."""
    selected = _revalidate_analysis_options(options)
    from document_sdk.pdf._validation import _validate_pdf_password

    _validate_pdf_password(password)
    hybrid_mode = selected.mode is PdfAnalysisMode.ADVANCED_HYBRID
    if hybrid_mode and password is not None:
        raise ProviderConfigurationError("PDF passwords require ADVANCED_LOCAL mode")
    if not hybrid_mode and hybrid_provider is not None:
        raise ProviderConfigurationError(
            "Hybrid Provider requires explicit ADVANCED_HYBRID mode"
        )
    if hybrid_mode and hybrid_provider is None:
        raise ProviderConfigurationError(
            "ADVANCED_HYBRID requires an explicit supported Provider"
        )
    if selected.mode is PdfAnalysisMode.STANDARD:
        raise InvalidSourceReferenceError(
            "STANDARD preserves existing PDF APIs; choose an advanced mode"
        )
    hybrid_bridge = None
    if hybrid_mode:
        from document_sdk.pdf._hybrid_public import _validate_hybrid_provider

        hybrid_bridge = _validate_hybrid_provider(hybrid_provider)
    try:
        _require_advanced_pdf_support()
        effective_limits = _effective_advanced_limits(selected.limits)
        hybrid_options = None
        if hybrid_bridge is not None:
            hybrid_options = hybrid_bridge.build_options(local_limits=effective_limits)
        content = _read_source(
            source,
            maximum_bytes=effective_limits.max_file_bytes,
        )
        from document_sdk.pdf._structural_engine.canonical import (
            CanonicalProjectionLimits,
            build_canonical_document,
        )
        from document_sdk.pdf._structural_engine.runtime.full_pipeline import (
            build_full_local_canonical_bundle,
        )

        bundle = (
            build_full_local_canonical_bundle(content, limits=effective_limits)
            if password is None
            else build_full_local_canonical_bundle(
                content, limits=effective_limits, password=password
            )
        )
        canonical = build_canonical_document(
            bundle,
            limits=CanonicalProjectionLimits(),
        )
        if hybrid_bridge is not None and hybrid_options is not None:
            from document_sdk.pdf._hybrid_public import (
                _build_hybrid_public_result,
                _run_prepared_hybrid,
            )

            hybrid_result = _run_prepared_hybrid(
                canonical,
                content,
                bridge=hybrid_bridge,
                options=hybrid_options,
            )
            base_result = _map_canonical_document(
                hybrid_result.canonical_document,
                mode=PdfAnalysisMode.ADVANCED_LOCAL,
            )
            hybrid_public_result = _build_hybrid_public_result(
                base_result,
                hybrid_result,
            )
            if any(
                not math.isfinite(value)
                for page in hybrid_public_result.pages
                for value in (page.width_points, page.height_points)
            ):
                raise ValueError("PDF geometry is non-finite")
            return hybrid_public_result, hybrid_result.canonical_document, content

        result = _map_canonical_document(
            canonical,
            mode=selected.mode,
            local_evidence=_project_local_member_evidence(bundle, canonical),
        )
        if any(
            not math.isfinite(value)
            for page in result.pages
            for value in (page.width_points, page.height_points)
        ):
            raise ValueError("PDF geometry is non-finite")
        return result, canonical, content
    except DocumentSdkError:
        raise
    except Exception as error:  # noqa: BLE001 - one redacted public backend boundary.
        _raise_redacted_translation(
            error,
            DocumentProcessingError(
                "Advanced Hybrid PDF analysis failed"
                if hybrid_mode
                else "Advanced local PDF analysis failed"
            ),
        )

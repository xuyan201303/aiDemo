"""Explicit document-object PDF view with an unchanged same-call v5 base."""

from __future__ import annotations

from hashlib import sha256
from typing import TYPE_CHECKING, Literal, Self

from pydantic import Field, PrivateAttr, ValidationInfo, model_validator

from document_sdk.core import InvalidSourceReferenceError
from document_sdk.core.models import SdkModel
from document_sdk.pdf._document_objects_v6 import (
    PdfDocumentObjects,
    extract_document_objects,
)
from document_sdk.pdf._structural_engine.canonical.identifiers import (
    canonical_payload_bytes,
)
from document_sdk.pdf.semantic_v5 import (
    PdfSemanticContext,
    SemanticVerificationContext,
    UnifiedPdfResultV5,
    _build_v5_result,
    _checked_context,
)
from document_sdk.pdf.unified import (
    PdfAnalysisMode,
    UnifiedPdfAnalysisOptions,
    _analyze_pdf_with_canonical,
    _revalidate_analysis_options,
)

if TYPE_CHECKING:
    from os import PathLike


UNIFIED_PDF_RESULT_V6_VERSION: Literal["document_sdk.pdf.unified_result.v6"] = (
    "document_sdk.pdf.unified_result.v6"
)


class PdfDocumentObjectLossReceipt(SdkModel):
    """Describe object information intentionally omitted by a v5 projection."""

    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    retained_v5_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    document_objects_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    losses: tuple[Literal["document_objects"], ...] = ("document_objects",)


class UnifiedPdfResultV6(SdkModel):
    """Versioned object inventory alongside the complete prior semantic view."""

    schema_version: Literal["document_sdk.pdf.unified_result.v6"] = (
        UNIFIED_PDF_RESULT_V6_VERSION
    )
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    document_id: str
    page_count: int = Field(ge=0)
    status: Literal["COMPLETED"] = "COMPLETED"
    v5_base: UnifiedPdfResultV5
    retained_v5_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    document_objects: PdfDocumentObjects
    _verification: SemanticVerificationContext | None = PrivateAttr(default=None)

    @model_validator(mode="after")
    def validate_binding(self, info: ValidationInfo) -> Self:
        """Bind the new object inventory to the complete retained v5 result."""
        v5_bytes = self.v5_base.to_json_bytes()
        if (
            self.source_sha256 != self.v5_base.source_sha256
            or self.source_sha256 != self.document_objects.source_sha256
            or self.document_id != self.v5_base.document_id
            or self.page_count != self.v5_base.page_count
            or self.status != self.v5_base.status
            or sha256(v5_bytes).hexdigest() != self.retained_v5_sha256
        ):
            message = "v6 document-object or retained v5 source binding differs"
            raise ValueError(message)
        for annotation in self.document_objects.annotations:
            if annotation.page_number > self.page_count:
                message = "annotation page is outside retained document"
                raise ValueError(message)
        verification = info.context
        if verification is not None and not isinstance(
            verification, SemanticVerificationContext
        ):
            message = "v6 verification context is invalid"
            raise ValueError(message)
        self._verification = verification
        return self

    def to_json_bytes(self) -> bytes:
        """Revalidate nested records before deterministic JSON serialization."""
        validated = type(self).model_validate_json(
            self.model_dump_json(), context=self._verification
        )
        return canonical_payload_bytes(validated.model_dump(mode="json"))

    def to_v5_json_bytes(
        self, *, allow_document_object_loss: bool = False
    ) -> tuple[bytes, PdfDocumentObjectLossReceipt]:
        """Require an explicit receipt to discard the new public object inventory."""
        if allow_document_object_loss is not True:
            message = "v5 projection requires explicit object-information loss"
            raise ValueError(message)
        self.to_json_bytes()
        wire = self.v5_base.to_json_bytes()
        return wire, PdfDocumentObjectLossReceipt(
            source_sha256=self.source_sha256,
            retained_v5_sha256=self.retained_v5_sha256,
            document_objects_sha256=sha256(
                canonical_payload_bytes(self.document_objects.model_dump(mode="json"))
            ).hexdigest(),
        )


def analyze_pdf_v6(
    source: bytes | bytearray | memoryview | str | PathLike[str],
    *,
    options: UnifiedPdfAnalysisOptions,
    password: str | None = None,
    semantic_context: PdfSemanticContext | None = None,
) -> UnifiedPdfResultV6:
    """Return versioned local document objects from the original PDF bytes."""
    selected = _revalidate_analysis_options(options)
    if selected.mode is not PdfAnalysisMode.ADVANCED_LOCAL:
        message = "v6 requires explicit ADVANCED_LOCAL options"
        raise InvalidSourceReferenceError(message)
    context = _checked_context(semantic_context)
    base, canonical, content = _analyze_pdf_with_canonical(
        source, options=selected, password=password
    )
    v5 = _build_v5_result(
        (base, canonical, content),
        selected,
        context,
        password_provided=password is not None,
    )
    objects = extract_document_objects(
        content, source_sha256=base.source_sha256, password=password
    )
    verification = SemanticVerificationContext(
        content, selected, context, password is not None
    )
    return UnifiedPdfResultV6.model_validate(
        {
            "source_sha256": base.source_sha256,
            "document_id": base.document_id,
            "page_count": base.page_count,
            "status": base.status,
            "v5_base": v5,
            "retained_v5_sha256": sha256(v5.to_json_bytes()).hexdigest(),
            "document_objects": objects,
        },
        context=verification,
    )

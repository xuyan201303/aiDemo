"""Explicit source-information view retaining the same-call visual v6 contract."""

from __future__ import annotations

from dataclasses import asdict
from hashlib import sha256
from typing import TYPE_CHECKING, Literal, Self

from pydantic import Field, PrivateAttr, ValidationInfo, model_validator

from document_sdk.core import InvalidSourceReferenceError
from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.models import SdkModel
from document_sdk.pdf._document_objects_v6 import extract_document_objects
from document_sdk.pdf._source_objects_v7 import (
    PdfSourceObjectLimitsV7,
    PdfSourceObjectsV7,
    extract_source_objects,
)
from document_sdk.pdf._structural_engine.canonical.identifiers import (
    canonical_payload_bytes,
)
from document_sdk.pdf.semantic_v5 import (
    PdfSemanticContext,
    SemanticVerificationContext,
    _build_v5_result,
    _checked_context,
)
from document_sdk.pdf.semantic_v6 import UnifiedPdfResultV6
from document_sdk.pdf.source_text import PdfSourceText, build_source_text
from document_sdk.pdf.unified import (
    PdfAnalysisMode,
    UnifiedPdfAnalysisOptions,
    _analyze_pdf_with_canonical,
    _revalidate_analysis_options,
)

if TYPE_CHECKING:
    from os import PathLike

    from document_sdk.pdf._xref_keyword_recovery import PdfXrefRecoveryReceipt


UNIFIED_PDF_RESULT_V7_VERSION: Literal["document_sdk.pdf.unified_result.v7"] = (
    "document_sdk.pdf.unified_result.v7"
)


class PdfInputRecoveryReceipt(SdkModel):
    """Original input and exact in-memory xref repair, never a replaced file."""

    original_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    recovered_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    keyword_offset: int = Field(ge=0)
    original_keyword_hex: str = Field(pattern=r"^[0-9a-f]{8}$")
    root_object_number: int = Field(ge=1)
    root_generation: int = Field(ge=0)
    info_object_number: int = Field(ge=1)
    info_generation: int = Field(ge=0)
    entry_count: int = Field(ge=1)
    method: Literal[
        "TERMINAL_STARTXREF_SINGLE_CLASSIC_TABLE_KEYWORD_REPAIR_V1",
        "ORIGINAL_CLASSIC_XREF_TRUNCATED_TRAILER_PARSER_VIEW_V1",
    ]


class PdfSourceInformationLossReceipt(SdkModel):
    """Record explicit loss when projecting the additive source view to v6."""

    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    retained_v6_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    source_text_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    source_objects_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    losses: tuple[Literal["source_text", "source_objects", "input_recovery"], ...] = (
        "source_text",
        "source_objects",
        "input_recovery",
    )


class UnifiedPdfResultV7(SdkModel):
    """Source events and objects alongside unchanged visual reading semantics."""

    schema_version: Literal["document_sdk.pdf.unified_result.v7"] = (
        UNIFIED_PDF_RESULT_V7_VERSION
    )
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    document_id: str
    page_count: int = Field(ge=0)
    status: Literal["COMPLETED"] = "COMPLETED"
    v6_base: UnifiedPdfResultV6
    retained_v6_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    source_text: PdfSourceText
    source_objects: PdfSourceObjectsV7
    input_recovery: tuple[PdfInputRecoveryReceipt, ...] = ()
    _verification: SemanticVerificationContext | None = PrivateAttr(default=None)

    @model_validator(mode="after")
    def validate_source_binding(self, info: ValidationInfo) -> Self:
        """Reconstruct the text projection rather than trusting its own hashes."""
        if (
            self.source_sha256 != self.v6_base.source_sha256
            or self.source_sha256 != self.source_objects.source_sha256
            or self.document_id != self.v6_base.document_id
            or self.page_count != self.v6_base.page_count
            or self.status != self.v6_base.status
            or self.retained_v6_sha256
            != sha256(self.v6_base.to_json_bytes()).hexdigest()
        ):
            message = "v7 retained view or source-information binding differs"
            raise ValueError(message)
        if self.source_text != build_source_text(self.v6_base.v5_base.local_evidence):
            message = "v7 source text differs from retained execution members"
            raise ValueError(message)
        if any(
            receipt.original_sha256 != self.source_sha256
            for receipt in self.input_recovery
        ):
            message = "v7 recovery receipt differs from original input identity"
            raise ValueError(message)
        verification = info.context
        if verification is not None and not isinstance(
            verification, SemanticVerificationContext
        ):
            message = "v7 verification context is invalid"
            raise ValueError(message)
        self._verification = verification
        return self

    def to_json_bytes(self) -> bytes:
        """Revalidate mutable nested fields before deterministic serialization."""
        validated = type(self).model_validate_json(
            self.model_dump_json(), context=self._verification
        )
        return canonical_payload_bytes(validated.model_dump(mode="json"))

    def to_v6_json_bytes(
        self, *, allow_source_information_loss: bool = False
    ) -> tuple[bytes, PdfSourceInformationLossReceipt]:
        """Require explicit acknowledgement to omit the new source information."""
        if allow_source_information_loss is not True:
            message = "v6 projection requires explicit source-information loss"
            raise ValueError(message)
        self.to_json_bytes()
        return self.v6_base.to_json_bytes(), PdfSourceInformationLossReceipt(
            source_sha256=self.source_sha256,
            retained_v6_sha256=self.retained_v6_sha256,
            source_text_sha256=sha256(
                canonical_payload_bytes(self.source_text.model_dump(mode="json"))
            ).hexdigest(),
            source_objects_sha256=sha256(
                canonical_payload_bytes(self.source_objects.model_dump(mode="json"))
            ).hexdigest(),
        )


def analyze_pdf_v7(
    source: bytes | bytearray | memoryview | str | PathLike[str],
    *,
    options: UnifiedPdfAnalysisOptions,
    password: str | None = None,
    semantic_context: PdfSemanticContext | None = None,
    source_limits: PdfSourceObjectLimitsV7 | None = None,
) -> UnifiedPdfResultV7:
    """Read source information explicitly, preserving all earlier default APIs."""
    selected = _revalidate_analysis_options(options)
    checked_source_limits = (
        _revalidate_model_instance_json(
            source_limits, PdfSourceObjectLimitsV7, "v7 source limits are invalid"
        )
        if source_limits is not None
        else PdfSourceObjectLimitsV7()
    )
    if selected.mode is not PdfAnalysisMode.ADVANCED_LOCAL:
        message = "v7 requires explicit ADVANCED_LOCAL options"
        raise InvalidSourceReferenceError(message)
    context = _checked_context(semantic_context)
    base, canonical, content = _analyze_pdf_with_canonical(
        source, options=selected, password=password
    )
    verification = SemanticVerificationContext(
        content, selected, context, password is not None
    )
    v5 = _build_v5_result(
        (base, canonical, content),
        selected,
        context,
        password_provided=password is not None,
    )
    recovery_receipts: list[PdfXrefRecoveryReceipt] = []
    objects = extract_document_objects(
        content,
        source_sha256=base.source_sha256,
        password=password,
        recovery_receipts=recovery_receipts,
    )
    v6 = UnifiedPdfResultV6.model_validate(
        {
            "source_sha256": base.source_sha256,
            "document_id": base.document_id,
            "page_count": base.page_count,
            "status": base.status,
            "v5_base": v5,
            "retained_v5_sha256": sha256(v5.to_json_bytes()).hexdigest(),
            "document_objects": objects,
        },
        context=verification,
    )
    return UnifiedPdfResultV7.model_validate(
        {
            "source_sha256": base.source_sha256,
            "document_id": base.document_id,
            "page_count": base.page_count,
            "status": base.status,
            "v6_base": v6,
            "retained_v6_sha256": sha256(v6.to_json_bytes()).hexdigest(),
            "source_text": build_source_text(v5.local_evidence),
            "source_objects": extract_source_objects(
                content, password, limits=checked_source_limits
            ),
            "input_recovery": tuple(
                PdfInputRecoveryReceipt.model_validate(asdict(receipt))
                for receipt in recovery_receipts
            ),
        },
        context=verification,
    )

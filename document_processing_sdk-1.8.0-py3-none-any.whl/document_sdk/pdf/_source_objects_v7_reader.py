"""Production assembly of the additive, bounded v7 source-output channels."""

from __future__ import annotations

from hashlib import sha256
from io import BytesIO
from typing import TYPE_CHECKING, Literal

from document_sdk.pdf._source_objects_v7 import (
    PdfPageBoxDeclarationV7,
    PdfSourceChannelV7,
    PdfSourceObjectsV7,
    PdfSourcePageBoxesV7,
)
from document_sdk.pdf._source_objects_v7_content import ContentWalker
from document_sdk.pdf._source_objects_v7_history import read_file_history
from document_sdk.pdf._source_objects_v7_values import (
    SourceBudget,
    SourceLimitError,
    SourceReadError,
    box,
    dictionary,
    resolve,
    source,
)

if TYPE_CHECKING:
    from typing import Any

    from pypdf import PdfReader

    from document_sdk.pdf._source_objects_v7 import (
        Box,
        PdfSourceObjectLimitsV7,
        SourceChannelName,
        SourceState,
    )

_CHANNELS: tuple[SourceChannelName, ...] = (
    "page_boxes",
    "images",
    "graphics",
    "text_state",
    "file_history",
)
type BoxName = Literal["MediaBox", "CropBox", "ArtBox", "BleedBox", "TrimBox"]
_BOXES: tuple[BoxName, ...] = ("MediaBox", "CropBox", "ArtBox", "BleedBox", "TrimBox")


def _raw_pages(reader: PdfReader, budget: SourceBudget) -> list[Any]:
    """Snapshot raw leaf dictionaries before the backend flattens inheritance."""
    from pypdf.generic import DictionaryObject

    catalog = dictionary(reader.trailer["/Root"])
    stack = [(catalog.raw_get("/Pages"), 0)]
    result: list[Any] = []
    seen: set[tuple[object, ...]] = set()
    while stack:
        ref, depth = stack.pop()
        budget.object()
        if depth > budget.limits.max_depth:
            message = "SOURCE_PAGE_TREE_DEPTH_LIMIT"
            raise SourceLimitError(message)
        node = dictionary(ref)
        identity = source(ref, "/Pages")
        key = identity.object_number, identity.generation
        if key in seen:
            message = "SOURCE_PAGE_TREE_CYCLE_OR_DUPLICATE"
            raise SourceReadError(message)
        seen.add(key)
        if str(node.get("/Type")) == "/Page":
            result.append(DictionaryObject(dict(node.items())))
        else:
            children = resolve(node.get("/Kids", []))
            stack.extend((child, depth + 1) for child in reversed(children))
    return result


def _inherited(page: Any, key: str, budget: SourceBudget) -> Any:
    from pypdf.generic import NullObject

    current = page
    visited: set[tuple[object, ...]] = set()
    for _ in range(budget.limits.max_depth):
        budget.object()
        mapping = dictionary(current)
        if key in mapping:
            raw = mapping.raw_get(key)
            if not isinstance(resolve(raw), NullObject):
                return raw
        if "/Parent" not in mapping:
            return None
        current = mapping.raw_get("/Parent")
        location = source(current, "/Parent")
        identity = location.object_number, location.generation
        if identity in visited:
            message = "SOURCE_PAGE_INHERITANCE_CYCLE"
            raise SourceReadError(message)
        visited.add(identity)
    message = "SOURCE_PAGE_INHERITANCE_DEPTH_LIMIT"
    raise SourceLimitError(message)


def _box_declaration(
    page: Any,
    name: BoxName,
    number: int,
    defaults: tuple[Box | None, Box | None],
    budget: SourceBudget,
) -> PdfPageBoxDeclarationV7:
    from pypdf.generic import NullObject

    key = "/" + name
    present = key in page
    raw = page.raw_get(key) if present else None
    state: Literal["MISSING", "NULL", "PRESENT", "UNSUPPORTED"] = (
        "MISSING"
        if not present
        else "NULL"
        if isinstance(resolve(raw), NullObject)
        else "PRESENT"
    )
    coordinates = box(raw) if state == "PRESENT" else None
    effective = coordinates
    basis: Literal[
        "DECLARED", "INHERITED", "MEDIA_BOX_DEFAULT", "CROP_BOX_DEFAULT", "UNAVAILABLE"
    ] = "DECLARED" if coordinates is not None else "UNAVAILABLE"
    media, crop = defaults
    if coordinates is None:
        if name == "MediaBox":
            inherited = _inherited(page, key, budget)
            effective = box(inherited) if inherited is not None else None
            basis = "INHERITED" if effective is not None else "UNAVAILABLE"
        elif name == "CropBox":
            inherited = _inherited(page, key, budget)
            effective = box(inherited) if inherited is not None else media
            basis = "INHERITED" if inherited is not None else "MEDIA_BOX_DEFAULT"
        else:
            effective, basis = crop, "CROP_BOX_DEFAULT"
    return PdfPageBoxDeclarationV7(
        name=name,
        source=source(raw if present else page, f"/Pages/{number - 1}/{name}"),
        declaration_state=state,
        raw_coordinates=coordinates,
        effective_coordinates=effective,
        effective_basis=basis,
    )


def _page_boxes(
    raw: Any, page: Any, number: int, budget: SourceBudget
) -> PdfSourcePageBoxesV7:
    media = _box_declaration(raw, "MediaBox", number, (None, None), budget)
    crop = _box_declaration(
        raw, "CropBox", number, (media.effective_coordinates, None), budget
    )
    declarations = [media, crop]
    declarations.extend(
        _box_declaration(
            raw,
            name,
            number,
            (media.effective_coordinates, crop.effective_coordinates),
            budget,
        )
        for name in _BOXES[2:]
    )
    return PdfSourcePageBoxesV7(
        page_number=number,
        page_source=source(page, f"/Pages/{number - 1}"),
        user_unit=float(raw.get("/UserUnit", 1)),
        rotation=int(_inherited(raw, "/Rotate", budget) or 0),
        boxes=tuple(declarations),
    )


def _reader(data: bytes, password: str | None) -> PdfReader:
    from pypdf import PdfReader
    from pypdf.errors import PdfReadError

    try:
        reader = PdfReader(BytesIO(data), strict=False)
    except PdfReadError:
        from document_sdk.pdf._xref_keyword_recovery import recover_source_reader

        reader, _receipt = recover_source_reader(data)
    if reader.is_encrypted and (password is None or not reader.decrypt(password)):
        message = "SOURCE_SECURITY_HANDLER_PASSWORD_REQUIRED_OR_INVALID"
        raise SourceReadError(message)
    return reader


def _failed(data: bytes, reason: str) -> PdfSourceObjectsV7:
    return PdfSourceObjectsV7(
        source_sha256=sha256(data).hexdigest(),
        channels=tuple(
            PdfSourceChannelV7(
                name=name, state="INCOMPLETE", limitation_codes=(reason,)
            )
            for name in _CHANNELS
        ),
    )


def _content_channels(walker: ContentWalker) -> list[PdfSourceChannelV7]:
    counts = {
        "images": len(walker.inventory.images),
        "graphics": len(walker.inventory.paints)
        + len(walker.inventory.clips)
        + len(walker.inventory.forms),
        "text_state": len(walker.inventory.texts) + len(walker.inventory.fonts),
    }
    result: list[PdfSourceChannelV7] = []
    for name in ("images", "graphics", "text_state"):
        reasons = walker.inventory.limitations.get(name, [])
        state: SourceState = (
            "INCOMPLETE" if reasons else "COMPLETE" if counts[name] else "ABSENT"
        )
        if any(reason.endswith("_LIMIT") for reason in reasons):
            state = "LIMITED"
        result.append(
            PdfSourceChannelV7(name=name, state=state, limitation_codes=tuple(reasons))
        )
    return result


def read_source_objects(
    data: bytes, password: str | None, limits: PdfSourceObjectLimitsV7
) -> PdfSourceObjectsV7:
    """Extract each source channel conservatively while retaining partial evidence."""
    from pypdf.errors import PdfReadError

    budget = SourceBudget(limits)
    try:
        reader = _reader(data, password)
    except (PdfReadError, SourceReadError, ValueError, KeyError, TypeError) as error:
        return _failed(data, type(error).__name__ + ":SOURCE_READER_FAILED")
    walker = ContentWalker(reader, budget, data)
    page_boxes: list[PdfSourcePageBoxesV7] = []
    boxes_reasons: list[str] = []
    try:
        raw_pages = _raw_pages(reader, budget)
        for number, page in enumerate(reader.pages, 1):
            budget.object()
            try:
                page_boxes.append(
                    _page_boxes(raw_pages[number - 1], page, number, budget)
                )
            except (SourceReadError, ValueError, TypeError, KeyError) as error:
                boxes_reasons.append(
                    type(error).__name__ + ":SOURCE_PAGE_BOXES_INCOMPLETE"
                )
            try:
                walker.page(page, number)
            except (
                SourceReadError,
                SourceLimitError,
                PdfReadError,
                ValueError,
                TypeError,
                KeyError,
            ) as error:
                for name in _CHANNELS[1:4]:
                    walker.inventory.limitation(
                        name,
                        str(error)
                        if isinstance(error, SourceReadError | SourceLimitError)
                        else type(error).__name__ + ":SOURCE_CONTENT_INCOMPLETE",
                    )
    except (SourceLimitError, PdfReadError, ValueError, KeyError, TypeError) as error:
        boxes_reasons.append(
            str(error)
            if isinstance(error, SourceLimitError)
            else type(error).__name__ + ":SOURCE_PAGES_INCOMPLETE"
        )
        for name in _CHANNELS[1:4]:
            walker.inventory.limitation(name, "SOURCE_PAGE_TRAVERSAL_INCOMPLETE")
    history = None
    history_reasons: tuple[str, ...] = ()
    try:
        history = read_file_history(data, reader, budget)
        history_reasons = history.limitation_codes
    except (
        SourceLimitError,
        SourceReadError,
        PdfReadError,
        ValueError,
        TypeError,
        KeyError,
    ) as error:
        history_reasons = (
            str(error)
            if isinstance(error, SourceReadError | SourceLimitError)
            else type(error).__name__ + ":SOURCE_HISTORY_INCOMPLETE",
        )
    channels = _content_channels(walker)
    channels.insert(
        0,
        PdfSourceChannelV7(
            name="page_boxes",
            state="INCOMPLETE"
            if boxes_reasons
            else "COMPLETE"
            if page_boxes
            else "ABSENT",
            limitation_codes=tuple(boxes_reasons),
        ),
    )
    channels.append(
        PdfSourceChannelV7(
            name="file_history",
            state="INCOMPLETE" if history_reasons else "COMPLETE",
            limitation_codes=history_reasons,
        )
    )
    inventory = walker.inventory
    return PdfSourceObjectsV7(
        source_sha256=sha256(data).hexdigest(),
        channels=tuple(channels),
        page_boxes=tuple(page_boxes),
        images=tuple(inventory.images),
        path_paints=tuple(inventory.paints),
        clips=tuple(inventory.clips),
        text_states=tuple(inventory.texts),
        fonts=tuple(inventory.fonts),
        form_invocations=tuple(inventory.forms),
        content_streams=tuple(inventory.streams),
        file_history=history,
    )

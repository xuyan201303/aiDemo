"""Bounded source-PDF document-object projection for the opt-in v6 result.

This is production extraction from the supplied PDF bytes. It does not read an
oracle, filename, corpus manifest, or another SDK result. PDF source rectangles
are deliberately not advertised as rendered glyph or transformed page boxes.
"""

from __future__ import annotations

import json
import math
import zlib
from base64 import b64decode, b64encode
from binascii import Error as Base64Error
from dataclasses import dataclass
from hashlib import sha256
from io import BytesIO
from typing import TYPE_CHECKING, Literal

from pydantic import Field, model_validator

from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.core.models import SdkModel

if TYPE_CHECKING:
    from typing import Any, Self

    from pypdf import PdfReader
    from pypdf.generic import DictionaryObject

    from document_sdk.pdf._xref_keyword_recovery import PdfXrefRecoveryReceipt

type ChannelState = Literal[
    "COMPLETE", "ABSENT", "INCOMPLETE", "UNSUPPORTED", "LIMITED"
]
type ValueState = Literal["MISSING", "NULL", "PRESENT", "UNSUPPORTED"]
type ChannelName = Literal[
    "annotations",
    "form_fields",
    "outlines",
    "destinations",
    "attachments",
    "metadata",
    "xmp",
    "structure_tree",
]
type AttachmentRelation = Literal[
    "NAME_TREE", "DOCUMENT_AF", "PAGE_AF", "ANNOTATION_FILE_ATTACHMENT"
]

DOCUMENT_OBJECTS_SCHEMA_VERSION: Literal["document_sdk.pdf.document_objects.v1"] = (
    "document_sdk.pdf.document_objects.v1"
)
_CHANNELS: tuple[ChannelName, ...] = (
    "annotations",
    "form_fields",
    "outlines",
    "destinations",
    "attachments",
    "metadata",
    "xmp",
    "structure_tree",
)
_MAX_OBJECTS = 20_000
_MAX_DEPTH = 32
_MAX_TEXT_BYTES = 1_048_576
_MAX_DECODED_BYTES = 32 * 1_048_576
_MAX_ENCODED_BYTES = 32 * 1_048_576
_RECT_COORDINATE_COUNT = 4
_MIN_DESTINATION_OPERANDS = 2


def _validate_encoded_content(
    encoded: str, size: int | None, digest: str | None
) -> None:
    """Validate exact public bytes without treating a digest as the content."""
    try:
        payload = b64decode(encoded, validate=True)
    except (Base64Error, ValueError) as error:
        message = "document-object content base64 is invalid"
        _raise_redacted_translation(error, ValueError(message))
    if size != len(payload) or digest != sha256(payload).hexdigest():
        message = "document-object content size or digest mismatch"
        raise ValueError(message)


class PdfObjectSource(SdkModel):
    """A PDF indirect reference, or a deterministic direct-object source path."""

    source_path: str
    object_number: int | None = Field(default=None, ge=1)
    generation: int | None = Field(default=None, ge=0)

    @model_validator(mode="after")
    def validate_reference(self) -> Self:
        """Require an entire indirect identity or a direct path."""
        if (self.object_number is None) != (self.generation is None):
            message = "PDF object reference is incomplete"
            raise ValueError(message)
        if not self.source_path.startswith("/"):
            message = "PDF source path is invalid"
            raise ValueError(message)
        return self


class PdfObjectValue(SdkModel):
    """Keep absent, PDF null, exact empty text, and unsupported values apart."""

    state: ValueState
    type_name: str | None = None
    text: str | None = None
    bytes_base64: str | None = None

    @model_validator(mode="after")
    def validate_state(self) -> Self:
        """Prevent an absent value from carrying invented source content."""
        if self.state != "PRESENT" and (
            self.text is not None or self.bytes_base64 is not None
        ):
            message = "non-present PDF value carries content"
            raise ValueError(message)
        if self.state == "PRESENT" and self.text is None and self.bytes_base64 is None:
            message = "present PDF value has no content"
            raise ValueError(message)
        return self


class PdfObjectChannel(SdkModel):
    """Evidence state for one complete document-object inventory."""

    name: ChannelName
    state: ChannelState
    limitation_codes: tuple[str, ...] = ()


class PdfObjectRect(SdkModel):
    """Unmodified PDF /Rect numbers in PDF user space."""

    coordinates: tuple[float, float, float, float]
    basis: Literal["PDF_USER_SPACE_UNTRANSFORMED"] = "PDF_USER_SPACE_UNTRANSFORMED"

    @model_validator(mode="after")
    def validate_finite(self) -> Self:
        """Exclude non-finite source coordinates."""
        if not all(math.isfinite(value) for value in self.coordinates):
            message = "PDF rectangle is non-finite"
            raise ValueError(message)
        return self


class PdfAnnotationObject(SdkModel):
    """One page /Annots occurrence; a link remains an annotation subtype."""

    source: PdfObjectSource
    page_number: int = Field(ge=1)
    page_annotation_index: int = Field(ge=0)
    subtype: PdfObjectValue
    rect: PdfObjectRect | None
    uri: PdfObjectValue
    contents: PdfObjectValue
    action_source: PdfObjectSource | None = None
    action_type: PdfObjectValue = PdfObjectValue(state="MISSING")
    destination: PdfObjectValue = PdfObjectValue(state="MISSING")


class PdfWidgetObject(SdkModel):
    """A field's widget, cross-linked to the page annotation occurrence."""

    source: PdfObjectSource
    page_number: int | None = Field(default=None, ge=1)
    rect: PdfObjectRect | None = None


class PdfFormFieldObject(SdkModel):
    """One terminal AcroForm field; widgets are references, not extra fields."""

    source: PdfObjectSource
    fully_qualified_name: PdfObjectValue
    field_type: PdfObjectValue
    value: PdfObjectValue
    widget_sources: tuple[PdfWidgetObject, ...] = ()
    parent_source: PdfObjectSource | None = None


class PdfOutlineObject(SdkModel):
    """One bookmark with explicit parent/order and unresolved target retained."""

    source: PdfObjectSource
    parent_source: PdfObjectSource | None
    depth: int = Field(ge=0)
    order: int = Field(ge=0)
    title: PdfObjectValue
    destination: PdfObjectValue
    action_source: PdfObjectSource | None = None
    action_type: PdfObjectValue = PdfObjectValue(state="MISSING")
    destination_name: str | None = None
    target_page_number: int | None = Field(default=None, ge=1)
    target_page_source: PdfObjectSource | None = None
    target_fit: PdfObjectValue = PdfObjectValue(state="MISSING")
    target_operands: tuple[PdfObjectValue, ...] = ()


class PdfDestinationObject(SdkModel):
    """One named destination and its source page/fit/coordinate operands."""

    source: PdfObjectSource
    name: str
    target_page_number: int | None = Field(default=None, ge=1)
    target_page_source: PdfObjectSource | None = None
    fit: PdfObjectValue
    operands: tuple[PdfObjectValue, ...] = ()


class PdfAttachmentObject(SdkModel):
    """A uniquely resolved Filespec with lossless bounded decoded bytes."""

    source: PdfObjectSource
    filename: PdfObjectValue
    unicode_filename: PdfObjectValue
    stream_source: PdfObjectSource | None
    content_base64: str | None
    content_size: int | None = Field(default=None, ge=0)
    content_sha256: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_content(self) -> Self:
        """A complete attachment must carry bytes, size, and hash together."""
        present = (
            self.content_base64 is not None,
            self.content_size is not None,
            self.content_sha256 is not None,
        )
        if len(set(present)) != 1:
            message = "attachment content fields are incomplete"
            raise ValueError(message)
        if self.content_base64 is not None:
            _validate_encoded_content(
                self.content_base64, self.content_size, self.content_sha256
            )
        return self


class PdfAttachmentReference(SdkModel):
    """Name-tree, document AF, or page AF edge to one Filespec."""

    source_path: str
    relation: AttachmentRelation
    name: str | None = None
    page_number: int | None = Field(default=None, ge=1)
    filespec_source: PdfObjectSource


class PdfInfoEntry(SdkModel):
    """One exact source /Info key and typed PDF value."""

    source: PdfObjectSource
    key: str
    value: PdfObjectValue


class PdfXmpObject(SdkModel):
    """Complete bounded decoded XMP stream, never only a digest."""

    source: PdfObjectSource
    content_base64: str
    content_size: int = Field(ge=0)
    content_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_content(self) -> Self:
        """Check lossless public XMP bytes rather than trusting an attached hash."""
        _validate_encoded_content(
            self.content_base64, self.content_size, self.content_sha256
        )
        return self


class PdfStructureNode(SdkModel):
    """One /StructElem or marked-content child and its actual source links."""

    source: PdfObjectSource
    parent_source: PdfObjectSource | None
    order: int = Field(ge=0)
    role: PdfObjectValue
    page_number: int | None = Field(default=None, ge=1)
    mcid: int | None = Field(default=None, ge=0)
    actual_text: PdfObjectValue
    alt_text: PdfObjectValue
    content_text: PdfObjectValue = PdfObjectValue(state="MISSING")


class PdfMarkedContentObject(SdkModel):
    """Exact supported source text associated with one page-local MCID."""

    source: PdfObjectSource
    page_number: int = Field(ge=1)
    mcid: int = Field(ge=0)
    text: str


class PdfStructureParentLink(SdkModel):
    """One /ParentTree index entry preserved independently of structure nodes."""

    source: PdfObjectSource
    index: int = Field(ge=0)
    target_sources: tuple[PdfObjectSource, ...]


class PdfDocumentObjects(SdkModel):
    """Versioned public document-object inventories from exact PDF source bytes."""

    schema_version: Literal["document_sdk.pdf.document_objects.v1"] = (
        DOCUMENT_OBJECTS_SCHEMA_VERSION
    )
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    channels: tuple[PdfObjectChannel, ...]
    annotations: tuple[PdfAnnotationObject, ...] = ()
    form_fields: tuple[PdfFormFieldObject, ...] = ()
    outlines: tuple[PdfOutlineObject, ...] = ()
    destinations: tuple[PdfDestinationObject, ...] = ()
    attachments: tuple[PdfAttachmentObject, ...] = ()
    attachment_references: tuple[PdfAttachmentReference, ...] = ()
    metadata_entries: tuple[PdfInfoEntry, ...] = ()
    xmp: PdfXmpObject | None = None
    document_language: PdfObjectValue = PdfObjectValue(state="MISSING")
    document_marked: PdfObjectValue = PdfObjectValue(state="MISSING")
    structure_nodes: tuple[PdfStructureNode, ...] = ()
    structure_parent_links: tuple[PdfStructureParentLink, ...] = ()
    marked_content: tuple[PdfMarkedContentObject, ...] = ()

    @model_validator(mode="after")
    def validate_channels(self) -> Self:
        """Require all channels in fixed order, with no false absence claim."""
        if tuple(item.name for item in self.channels) != _CHANNELS:
            message = "document-object channels are incomplete"
            raise ValueError(message)
        inventories = (
            self.annotations,
            self.form_fields,
            self.outlines,
            self.destinations,
            (*self.attachments, *self.attachment_references),
            self.metadata_entries,
            () if self.xmp is None else (self.xmp,),
            (
                *self.structure_nodes,
                *self.structure_parent_links,
                *self.marked_content,
                *(
                    (self.document_language,)
                    if self.document_language.state != "MISSING"
                    else ()
                ),
                *(
                    (self.document_marked,)
                    if self.document_marked.state != "MISSING"
                    else ()
                ),
            ),
        )
        if any(
            channel.state == "ABSENT" and inventory
            for channel, inventory in zip(self.channels, inventories, strict=True)
        ):
            message = "absent document-object channel contains records"
            raise ValueError(message)
        return self


class _ObjectLimitError(Exception):
    """A finite private PDF object/decode budget was exhausted."""


class _UnsupportedObjectError(Exception):
    """A source object exists, but its form is outside this version's profile."""


@dataclass(slots=True)
class _Budget:
    objects: int = 0
    decoded_bytes: int = 0

    def charge_object(self) -> None:
        self.objects += 1
        if self.objects > _MAX_OBJECTS:
            message = "DOCUMENT_OBJECT_COUNT_LIMIT"
            raise _ObjectLimitError(message)

    def charge_bytes(self, amount: int) -> None:
        if amount > _MAX_DECODED_BYTES - self.decoded_bytes:
            message = "DOCUMENT_OBJECT_DECODED_BYTES_LIMIT"
            raise _ObjectLimitError(message)
        self.decoded_bytes += amount


def _resolve(value: Any) -> Any:
    from pypdf.generic import IndirectObject

    return value.get_object() if isinstance(value, IndirectObject) else value


def _dictionary(value: Any) -> DictionaryObject:
    from pypdf.generic import DictionaryObject

    resolved = _resolve(value)
    if not isinstance(resolved, DictionaryObject):
        message = "PDF_OBJECT_DICTIONARY_UNSUPPORTED"
        raise _UnsupportedObjectError(message)
    return resolved


def _source(value: Any, path: str) -> PdfObjectSource:
    from pypdf.generic import IndirectObject

    if isinstance(value, IndirectObject):
        return PdfObjectSource(
            source_path=path,
            object_number=value.idnum,
            generation=value.generation,
        )
    return PdfObjectSource(source_path=path)


def _key(value: Any) -> tuple[int, int] | int:
    from pypdf.generic import IndirectObject

    if isinstance(value, IndirectObject):
        return value.idnum, value.generation
    return id(value)


def _limited_text(value: str, budget: _Budget) -> str:
    raw = value.encode("utf-8", errors="surrogatepass")
    if len(raw) > _MAX_TEXT_BYTES:
        message = "DOCUMENT_OBJECT_TEXT_LIMIT"
        raise _ObjectLimitError(message)
    budget.charge_bytes(len(raw))
    return value


def _value(value: Any, *, present: bool, budget: _Budget) -> PdfObjectValue:
    if not present:
        return PdfObjectValue(state="MISSING")
    return _present_value(value, budget)


def _present_value(value: Any, budget: _Budget) -> PdfObjectValue:
    """Decode a present field without conflating it with PDF null or empty text."""
    from pypdf.generic import (
        ArrayObject,
        BooleanObject,
        ByteStringObject,
        DictionaryObject,
        NullObject,
    )

    resolved = _resolve(value)
    if resolved is None or isinstance(resolved, NullObject):
        return PdfObjectValue(state="NULL", type_name="null")
    if isinstance(resolved, ByteStringObject | bytes):
        raw = bytes(resolved)
        budget.charge_bytes(len(raw))
        return PdfObjectValue(
            state="PRESENT",
            type_name="byte_string",
            bytes_base64=b64encode(raw).decode("ascii"),
        )
    if isinstance(resolved, str):
        return PdfObjectValue(
            state="PRESENT",
            type_name="name" if resolved.startswith("/") else "string",
            text=_limited_text(str(resolved), budget),
        )
    if isinstance(resolved, BooleanObject | bool | int | float):
        if isinstance(resolved, BooleanObject):
            value_type = "boolean"
            value_text = "true" if resolved.value else "false"
        else:
            if isinstance(resolved, float) and not math.isfinite(resolved):
                message = "PDF_OBJECT_NONFINITE_NUMBER"
                raise _UnsupportedObjectError(message)
            value_type = "number" if not isinstance(resolved, bool) else "boolean"
            value_text = str(resolved)
        return PdfObjectValue(
            state="PRESENT",
            type_name=value_type,
            text=value_text,
        )
    if isinstance(resolved, ArrayObject | DictionaryObject):
        structure = _structured_value(resolved, budget=budget, depth=0)
        return PdfObjectValue(
            state="PRESENT",
            type_name="array" if isinstance(resolved, ArrayObject) else "dictionary",
            text=_limited_text(
                json.dumps(structure, sort_keys=True, separators=(",", ":")), budget
            ),
        )
    return PdfObjectValue(state="UNSUPPORTED", type_name=type(resolved).__name__)


def _structured_value(value: Any, *, budget: _Budget, depth: int) -> object:
    """Represent a small PDF value without losing indirect object identity."""
    from pypdf.generic import (
        ArrayObject,
        BooleanObject,
        ByteStringObject,
        DictionaryObject,
        IndirectObject,
        NullObject,
    )

    if depth > _MAX_DEPTH:
        message = "DOCUMENT_OBJECT_DEPTH_LIMIT"
        raise _ObjectLimitError(message)
    if isinstance(value, IndirectObject):
        return {"object_number": value.idnum, "generation": value.generation}
    if isinstance(value, ArrayObject):
        budget.charge_object()
        return [
            _structured_value(item, budget=budget, depth=depth + 1) for item in value
        ]
    if isinstance(value, DictionaryObject):
        budget.charge_object()
        return {
            str(key): _structured_value(item, budget=budget, depth=depth + 1)
            for key, item in sorted(value.items(), key=lambda item: str(item[0]))
        }
    if isinstance(value, ByteStringObject | bytes):
        raw = bytes(value)
        budget.charge_bytes(len(raw))
        return {"bytes_base64": b64encode(raw).decode("ascii")}
    if value is None or isinstance(value, NullObject | str):
        return _limited_text(str(value), budget) if isinstance(value, str) else None
    if isinstance(value, BooleanObject | bool | int | float):
        if isinstance(value, BooleanObject):
            value = value.value
        if isinstance(value, float) and not math.isfinite(value):
            message = "PDF_OBJECT_NONFINITE_NUMBER"
            raise _UnsupportedObjectError(message)
        return value
    message = "PDF_OBJECT_VALUE_UNSUPPORTED"
    raise _UnsupportedObjectError(message)


def _field(mapping: DictionaryObject, key: str, budget: _Budget) -> PdfObjectValue:
    return _value(mapping.get(key), present=key in mapping, budget=budget)


def _array(value: Any) -> list[Any]:
    from pypdf.generic import ArrayObject

    resolved = _resolve(value)
    if not isinstance(resolved, ArrayObject | list):
        message = "PDF_OBJECT_ARRAY_UNSUPPORTED"
        raise _UnsupportedObjectError(message)
    return list(resolved)


def _rect(value: Any) -> PdfObjectRect | None:
    if value is None:
        return None
    coords = _array(value)
    if len(coords) != _RECT_COORDINATE_COUNT:
        message = "PDF_OBJECT_RECT_UNSUPPORTED"
        raise _UnsupportedObjectError(message)
    try:
        values = tuple(float(_resolve(v)) for v in coords)
        return PdfObjectRect(coordinates=(values[0], values[1], values[2], values[3]))
    except (TypeError, ValueError) as error:
        message = "PDF_OBJECT_RECT_UNSUPPORTED"
        _raise_redacted_translation(error, _UnsupportedObjectError(message))


def _stream_bytes(value: Any, budget: _Budget) -> bytes:
    """Decode only raw or Flate streams with a strict output ceiling."""
    from pypdf.generic import StreamObject

    stream = _resolve(value)
    if not isinstance(stream, StreamObject):
        message = "PDF_OBJECT_STREAM_UNSUPPORTED"
        raise _UnsupportedObjectError(message)
    encoded = getattr(stream, "_data", None)
    if not isinstance(encoded, bytes):
        message = "PDF_OBJECT_STREAM_BYTES_UNAVAILABLE"
        raise _UnsupportedObjectError(message)
    if len(encoded) > _MAX_ENCODED_BYTES:
        message = "DOCUMENT_OBJECT_ENCODED_BYTES_LIMIT"
        raise _ObjectLimitError(message)
    filters = stream.get("/Filter")
    if filters is None:
        decoded = encoded
    elif str(filters) == "/FlateDecode":
        if stream.get("/DecodeParms") not in (None, {}):
            message = "PDF_OBJECT_FLATE_PARAMETERS_UNSUPPORTED"
            raise _UnsupportedObjectError(message)
        decoder = zlib.decompressobj()
        remaining = _MAX_DECODED_BYTES - budget.decoded_bytes
        decoded = decoder.decompress(encoded, remaining + 1)
        if len(decoded) > remaining or decoder.unconsumed_tail:
            message = "DOCUMENT_OBJECT_DECODED_BYTES_LIMIT"
            raise _ObjectLimitError(message)
        tail = decoder.flush(remaining - len(decoded) + 1)
        decoded += tail
        if len(decoded) > remaining:
            message = "DOCUMENT_OBJECT_DECODED_BYTES_LIMIT"
            raise _ObjectLimitError(message)
        if not decoder.eof or decoder.unused_data:
            message = "PDF_OBJECT_FLATE_STREAM_INCOMPLETE"
            raise _UnsupportedObjectError(message)
    else:
        message = "PDF_OBJECT_STREAM_FILTER_UNSUPPORTED"
        raise _UnsupportedObjectError(message)
    budget.charge_bytes(len(decoded))
    return decoded


def _catalog(reader: PdfReader) -> DictionaryObject:
    return _dictionary(reader.trailer["/Root"])


def _page_sources(reader: PdfReader) -> dict[tuple[int, int], int]:
    pages: dict[tuple[int, int], int] = {}
    for number, page in enumerate(reader.pages, start=1):
        reference = page.indirect_reference
        if reference is not None:
            pages[(reference.idnum, reference.generation)] = number
    return pages


def _page_number(value: Any, pages: dict[tuple[int, int], int]) -> int | None:
    from pypdf.generic import IndirectObject

    if isinstance(value, IndirectObject):
        return pages.get((value.idnum, value.generation))
    return None


def _annotation_page_sources(
    reader: PdfReader, budget: _Budget
) -> dict[tuple[int, int] | int, int]:
    result: dict[tuple[int, int] | int, int] = {}
    for page_number, page in enumerate(reader.pages, start=1):
        for item in _array(page["/Annots"]) if "/Annots" in page else ():
            budget.charge_object()
            result[_key(item)] = page_number
    return result


def _annotations(reader: PdfReader, budget: _Budget) -> tuple[PdfAnnotationObject, ...]:
    result: list[PdfAnnotationObject] = []
    for page_number, page in enumerate(reader.pages, start=1):
        if "/Annots" not in page:
            continue
        for index, item in enumerate(_array(page["/Annots"])):
            budget.charge_object()
            path = f"/Pages/{page_number - 1}/Annots/{index}"
            annotation = _dictionary(item)
            action_ref = annotation.get("/A")
            action = _dictionary(action_ref) if action_ref is not None else None
            action_type = (
                _field(action, "/S", budget)
                if action is not None
                else PdfObjectValue(state="MISSING")
            )
            destination_ref = annotation.get("/Dest")
            if destination_ref is None and action is not None:
                destination_ref = action.get("/D")
            uri = (
                _field(action, "/URI", budget)
                if action is not None and str(action.get("/S", "")) == "/URI"
                else PdfObjectValue(state="MISSING")
            )
            result.append(
                PdfAnnotationObject(
                    source=_source(item, path),
                    page_number=page_number,
                    page_annotation_index=index,
                    subtype=_field(annotation, "/Subtype", budget),
                    rect=_rect(annotation.get("/Rect")),
                    uri=uri,
                    contents=_field(annotation, "/Contents", budget),
                    action_type=action_type,
                    destination=_value(
                        destination_ref,
                        present=destination_ref is not None,
                        budget=budget,
                    ),
                    action_source=(
                        _source(action_ref, f"{path}/A")
                        if action_ref is not None
                        else None
                    ),
                )
            )
    return tuple(result)


def _forms(reader: PdfReader, budget: _Budget) -> tuple[PdfFormFieldObject, ...]:
    root = _catalog(reader)
    if "/AcroForm" not in root:
        return ()
    form = _dictionary(root["/AcroForm"])
    if "/Fields" not in form:
        return ()
    pages = _page_sources(reader)
    widget_pages = _annotation_page_sources(reader, budget)
    result: list[PdfFormFieldObject] = []
    active: set[tuple[int, int] | int] = set()

    def walk(  # noqa: PLR0913 - PDF field recursion carries source and inherited values.
        reference: Any,
        *,
        path: str,
        names: tuple[str, ...],
        inherited_type: Any,
        inherited_value: Any,
        parent: PdfObjectSource | None,
        depth: int,
    ) -> None:
        if depth > _MAX_DEPTH:
            message = "DOCUMENT_OBJECT_DEPTH_LIMIT"
            raise _ObjectLimitError(message)
        budget.charge_object()
        identity = _key(reference)
        if identity in active:
            message = "PDF_FORM_FIELD_CYCLE"
            raise _UnsupportedObjectError(message)
        active.add(identity)
        try:
            field = _dictionary(reference)
            own_name = _field(field, "/T", budget)
            next_names = (
                (*names, own_name.text)
                if own_name.state == "PRESENT" and own_name.text is not None
                else names
            )
            field_type = field.get("/FT", inherited_type)
            field_value = field.get("/V", inherited_value)
            kids = _array(field["/Kids"]) if "/Kids" in field else []
            is_terminal = not kids or all(
                str(_dictionary(child).get("/Subtype", "")) == "/Widget"
                for child in kids
            )
            if not is_terminal:
                for index, child in enumerate(kids):
                    walk(
                        child,
                        path=f"{path}/Kids/{index}",
                        names=next_names,
                        inherited_type=field_type,
                        inherited_value=field_value,
                        parent=_source(reference, path),
                        depth=depth + 1,
                    )
                return
            widget_refs = kids or (
                [reference] if str(field.get("/Subtype", "")) == "/Widget" else []
            )
            widgets: list[PdfWidgetObject] = []
            for index, widget_ref in enumerate(widget_refs):
                budget.charge_object()
                widget_path = f"{path}/Kids/{index}" if kids else path
                widget = _dictionary(widget_ref)
                widgets.append(
                    PdfWidgetObject(
                        source=_source(widget_ref, widget_path),
                        page_number=(
                            widget_pages.get(_key(widget_ref))
                            or _page_number(widget.get("/P"), pages)
                        ),
                        rect=_rect(widget.get("/Rect")),
                    )
                )
            qualified = (
                PdfObjectValue(
                    state="PRESENT", type_name="string", text=".".join(next_names)
                )
                if next_names
                else PdfObjectValue(state="MISSING")
            )
            result.append(
                PdfFormFieldObject(
                    source=_source(reference, path),
                    fully_qualified_name=qualified,
                    field_type=_value(
                        field_type, present=field_type is not None, budget=budget
                    ),
                    value=_value(
                        field_value,
                        present="/V" in field or inherited_value is not None,
                        budget=budget,
                    ),
                    widget_sources=tuple(widgets),
                    parent_source=parent,
                )
            )
        finally:
            active.remove(identity)

    for index, field in enumerate(_array(form["/Fields"])):
        walk(
            field,
            path=f"/Root/AcroForm/Fields/{index}",
            names=(),
            inherited_type=None,
            inherited_value=None,
            parent=None,
            depth=0,
        )
    return tuple(result)


def _name_tree(
    reference: Any, *, path: str, budget: _Budget
) -> tuple[tuple[Any, Any, str], ...]:
    """Read a bounded PDF name tree, retaining every name/value occurrence."""
    result: list[tuple[Any, Any, str]] = []
    visited: set[tuple[int, int] | int] = set()

    def walk(node_ref: Any, node_path: str, depth: int) -> None:
        if depth > _MAX_DEPTH:
            message = "DOCUMENT_OBJECT_DEPTH_LIMIT"
            raise _ObjectLimitError(message)
        budget.charge_object()
        identity = _key(node_ref)
        if identity in visited:
            message = "PDF_NAME_TREE_CYCLE"
            raise _UnsupportedObjectError(message)
        visited.add(identity)
        node = _dictionary(node_ref)
        if "/Names" in node:
            entries = _array(node["/Names"])
            if len(entries) % 2:
                message = "PDF_NAME_TREE_ODD_ENTRY_COUNT"
                raise _UnsupportedObjectError(message)
            for index in range(0, len(entries), 2):
                budget.charge_object()
                result.append(
                    (
                        entries[index],
                        entries[index + 1],
                        f"{node_path}/Names/{index + 1}",
                    )
                )
        if "/Kids" in node:
            for index, child in enumerate(_array(node["/Kids"])):
                walk(child, f"{node_path}/Kids/{index}", depth + 1)

    walk(reference, path, 0)
    return tuple(result)


def _destination_parts(
    value: Any,
    *,
    path: str,
    pages: dict[tuple[int, int], int],
    budget: _Budget,
) -> tuple[
    int | None, PdfObjectSource | None, PdfObjectValue, tuple[PdfObjectValue, ...]
]:
    target = _resolve(value)
    if isinstance(target, str):
        return None, None, _value(target, present=True, budget=budget), ()
    if isinstance(target, dict) and "/D" in target:
        target = _resolve(target["/D"])
    entries = _array(target)
    if len(entries) < _MIN_DESTINATION_OPERANDS:
        message = "PDF_DESTINATION_TOO_SHORT"
        raise _UnsupportedObjectError(message)
    return (
        _page_number(entries[0], pages),
        _source(entries[0], f"{path}/0"),
        _value(entries[1], present=True, budget=budget),
        tuple(_value(item, present=True, budget=budget) for item in entries[2:]),
    )


def _destinations(
    reader: PdfReader, budget: _Budget
) -> tuple[PdfDestinationObject, ...]:
    root = _catalog(reader)
    pages = _page_sources(reader)
    records: list[PdfDestinationObject] = []
    names = _dictionary(root["/Names"]) if "/Names" in root else None
    if names is not None and "/Dests" in names:
        for name_ref, dest_ref, path in _name_tree(
            names["/Dests"], path="/Root/Names/Dests", budget=budget
        ):
            budget.charge_object()
            name = _value(name_ref, present=True, budget=budget)
            if name.text is None:
                message = "PDF_DESTINATION_NAME_UNSUPPORTED"
                raise _UnsupportedObjectError(message)
            page_number, page_source, fit, operands = _destination_parts(
                dest_ref, path=path, pages=pages, budget=budget
            )
            records.append(
                PdfDestinationObject(
                    source=_source(dest_ref, path),
                    name=name.text,
                    target_page_number=page_number,
                    target_page_source=page_source,
                    fit=fit,
                    operands=operands,
                )
            )
    if "/Dests" in root:
        old_dests = _dictionary(root["/Dests"])
        for key, dest_ref in sorted(old_dests.items(), key=lambda item: str(item[0])):
            budget.charge_object()
            path = f"/Root/Dests/{key}"
            page_number, page_source, fit, operands = _destination_parts(
                dest_ref, path=path, pages=pages, budget=budget
            )
            records.append(
                PdfDestinationObject(
                    source=_source(dest_ref, path),
                    name=str(key),
                    target_page_number=page_number,
                    target_page_source=page_source,
                    fit=fit,
                    operands=operands,
                )
            )
    return tuple(records)


@dataclass(frozen=True, slots=True)
class _OutlineTarget:
    destination: PdfObjectValue
    action_source: PdfObjectSource | None
    action_type: PdfObjectValue
    destination_name: str | None
    page_number: int | None
    page_source: PdfObjectSource | None
    fit: PdfObjectValue
    operands: tuple[PdfObjectValue, ...]
    incomplete: str | None


def _outline_target(
    entry: DictionaryObject,
    *,
    path: str,
    pages: dict[tuple[int, int], int],
    destinations_by_name: dict[str, list[PdfDestinationObject]],
    budget: _Budget,
) -> _OutlineTarget:
    """Resolve a bookmark target without treating unsupported actions as empty."""
    dest = entry.get("/Dest")
    destination_path = f"{path}/Dest"
    action_ref = entry.get("/A")
    action_type = PdfObjectValue(state="MISSING")
    incomplete: str | None = None
    if action_ref is not None:
        action = _dictionary(action_ref)
        action_type = _field(action, "/S", budget)
        if dest is not None:
            incomplete = "PDF_OUTLINE_DESTINATION_ACTION_CONFLICT"
        elif action_type.text == "/GoTo":
            dest = action.get("/D")
            destination_path = f"{path}/A/D"
        else:
            incomplete = "PDF_OUTLINE_ACTION_UNSUPPORTED"
    resolved = _resolve(dest)
    destination_name = str(resolved) if isinstance(resolved, str) else None
    page_number: int | None = None
    page_source: PdfObjectSource | None = None
    fit = PdfObjectValue(state="MISSING")
    operands: tuple[PdfObjectValue, ...] = ()
    if destination_name is not None:
        matches = destinations_by_name.get(destination_name, ())
        if len(matches) == 1 and matches[0].target_page_number is not None:
            named_target = matches[0]
            page_number = named_target.target_page_number
            page_source = named_target.target_page_source
            fit = named_target.fit
            operands = named_target.operands
        else:
            incomplete = "PDF_OUTLINE_NAMED_DESTINATION_UNRESOLVED"
    elif dest is not None:
        page_number, page_source, fit, operands = _destination_parts(
            dest, path=destination_path, pages=pages, budget=budget
        )
        if page_number is None:
            incomplete = "PDF_OUTLINE_DESTINATION_PAGE_UNRESOLVED"
    elif incomplete is None:
        incomplete = "PDF_OUTLINE_DESTINATION_MISSING"
    return _OutlineTarget(
        destination=_value(dest, present=dest is not None, budget=budget),
        action_source=(
            _source(action_ref, f"{path}/A") if action_ref is not None else None
        ),
        action_type=action_type,
        destination_name=destination_name,
        page_number=page_number,
        page_source=page_source,
        fit=fit,
        operands=operands,
        incomplete=incomplete,
    )


def _outlines(
    reader: PdfReader,
    budget: _Budget,
    destinations: tuple[PdfDestinationObject, ...],
) -> tuple[tuple[PdfOutlineObject, ...], str | None]:
    root = _catalog(reader)
    if "/Outlines" not in root:
        return (), None
    outline_root = _dictionary(root["/Outlines"])
    if "/First" not in outline_root:
        return (), None
    result: list[PdfOutlineObject] = []
    visited: set[tuple[int, int] | int] = set()
    pages = _page_sources(reader)
    destinations_by_name: dict[str, list[PdfDestinationObject]] = {}
    for destination in destinations:
        destinations_by_name.setdefault(destination.name, []).append(destination)
    incomplete: str | None = None

    def chain(first: Any, *, parent: PdfObjectSource | None, depth: int) -> None:
        nonlocal incomplete
        if depth > _MAX_DEPTH:
            message = "DOCUMENT_OBJECT_DEPTH_LIMIT"
            raise _ObjectLimitError(message)
        current = first
        sibling_order = 0
        while current is not None:
            budget.charge_object()
            identity = _key(current)
            if identity in visited:
                message = "PDF_OUTLINE_CYCLE"
                raise _UnsupportedObjectError(message)
            visited.add(identity)
            path = (
                f"/Root/Outlines/item/{current.idnum} {current.generation} R"
                if hasattr(current, "idnum") and hasattr(current, "generation")
                else f"/Root/Outlines/direct/{len(result)}"
            )
            entry = _dictionary(current)
            target = _outline_target(
                entry,
                path=path,
                pages=pages,
                destinations_by_name=destinations_by_name,
                budget=budget,
            )
            if target.incomplete is not None:
                incomplete = target.incomplete
            result.append(
                PdfOutlineObject(
                    source=_source(current, path),
                    parent_source=parent,
                    depth=depth,
                    order=sibling_order,
                    title=_field(entry, "/Title", budget),
                    destination=target.destination,
                    action_source=target.action_source,
                    action_type=target.action_type,
                    destination_name=target.destination_name,
                    target_page_number=target.page_number,
                    target_page_source=target.page_source,
                    target_fit=target.fit,
                    target_operands=target.operands,
                )
            )
            if "/First" in entry:
                chain(
                    entry.raw_get("/First"),
                    parent=_source(current, path),
                    depth=depth + 1,
                )
            current = entry.raw_get("/Next") if "/Next" in entry else None
            sibling_order += 1

    chain(outline_root.raw_get("/First"), parent=None, depth=0)
    return tuple(result), incomplete


def _attachments(  # noqa: C901, PLR0912 - four PDF attachment edge types need separate checks.
    reader: PdfReader, budget: _Budget
) -> tuple[
    tuple[PdfAttachmentObject, ...],
    tuple[PdfAttachmentReference, ...],
    bool,
    str | None,
]:
    root = _catalog(reader)
    appearances: list[tuple[Any, AttachmentRelation, str | None, str, int | None]] = []
    names = _dictionary(root["/Names"]) if "/Names" in root else None
    source_present = "/AF" in root or (names is not None and "/EmbeddedFiles" in names)
    incomplete: str | None = None
    if names is not None and "/EmbeddedFiles" in names:
        for name_ref, filespec_ref, path in _name_tree(
            names["/EmbeddedFiles"], path="/Root/Names/EmbeddedFiles", budget=budget
        ):
            name_value = _value(name_ref, present=True, budget=budget)
            appearances.append((filespec_ref, "NAME_TREE", name_value.text, path, None))
    if "/AF" in root:
        for index, item in enumerate(_array(root["/AF"])):
            appearances.append((item, "DOCUMENT_AF", None, f"/Root/AF/{index}", None))
    for page_number, page in enumerate(reader.pages, start=1):
        if "/AF" in page:
            source_present = True
            for index, item in enumerate(_array(page["/AF"])):
                appearances.append(
                    (
                        item,
                        "PAGE_AF",
                        None,
                        f"/Pages/{page_number - 1}/AF/{index}",
                        page_number,
                    )
                )
        if "/Annots" in page:
            for index, annotation_ref in enumerate(_array(page["/Annots"])):
                annotation = _dictionary(annotation_ref)
                if str(annotation.get("/Subtype", "")) == "/FileAttachment":
                    source_present = True
                    if "/FS" not in annotation:
                        incomplete = "PDF_FILE_ATTACHMENT_FILESPEC_MISSING"
                        continue
                    appearances.append(
                        (
                            annotation["/FS"],
                            "ANNOTATION_FILE_ATTACHMENT",
                            None,
                            f"/Pages/{page_number - 1}/Annots/{index}/FS",
                            page_number,
                        )
                    )
    unique: dict[tuple[int, int] | int, PdfAttachmentObject] = {}
    references: list[PdfAttachmentReference] = []
    for ref, relation, name, path, appearance_page_number in appearances:
        budget.charge_object()
        identity = _key(ref)
        if identity not in unique:
            filespec = _dictionary(ref)
            ef = _dictionary(filespec["/EF"]) if "/EF" in filespec else None
            stream_ref = ef.get("/UF", ef.get("/F")) if ef is not None else None
            payload = (
                _stream_bytes(stream_ref, budget) if stream_ref is not None else None
            )
            unique[identity] = PdfAttachmentObject(
                source=_source(ref, path),
                filename=_field(filespec, "/F", budget),
                unicode_filename=_field(filespec, "/UF", budget),
                stream_source=(
                    _source(stream_ref, f"{path}/EF")
                    if stream_ref is not None
                    else None
                ),
                content_base64=(
                    b64encode(payload).decode("ascii") if payload is not None else None
                ),
                content_size=(len(payload) if payload is not None else None),
                content_sha256=(
                    sha256(payload).hexdigest() if payload is not None else None
                ),
            )
        references.append(
            PdfAttachmentReference(
                source_path=path,
                relation=relation,
                name=name,
                page_number=appearance_page_number,
                filespec_source=unique[identity].source,
            )
        )
    return tuple(unique.values()), tuple(references), source_present, incomplete


def _metadata(reader: PdfReader, budget: _Budget) -> tuple[PdfInfoEntry, ...]:
    if "/Info" not in reader.trailer:
        return ()
    info = _dictionary(reader.trailer["/Info"])
    result: list[PdfInfoEntry] = []
    for key, item in sorted(info.items(), key=lambda pair: str(pair[0])):
        budget.charge_object()
        path = f"/Trailer/Info/{str(key).lstrip('/')}"
        result.append(
            PdfInfoEntry(
                source=_source(item, path),
                key=str(key),
                value=_value(item, present=True, budget=budget),
            )
        )
    return tuple(result)


def _xmp(reader: PdfReader, budget: _Budget) -> PdfXmpObject | None:
    root = _catalog(reader)
    if "/Metadata" not in root:
        return None
    budget.charge_object()
    reference = root.raw_get("/Metadata")
    payload = _stream_bytes(reference, budget)
    return PdfXmpObject(
        source=_source(reference, "/Root/Metadata"),
        content_base64=b64encode(payload).decode("ascii"),
        content_size=len(payload),
        content_sha256=sha256(payload).hexdigest(),
    )


def _source_text_operand(value: Any) -> str:
    """Support exact decoded PDF text strings and ASCII byte strings only."""
    from pypdf.generic import ByteStringObject, TextStringObject

    if isinstance(value, TextStringObject):
        return str(value)
    if isinstance(value, ByteStringObject | bytes):
        try:
            return bytes(value).decode("ascii")
        except UnicodeDecodeError as error:
            message = "PDF_MARKED_TEXT_ENCODING_UNSUPPORTED"
            _raise_redacted_translation(error, _UnsupportedObjectError(message))
    message = "PDF_MARKED_TEXT_OPERAND_UNSUPPORTED"
    raise _UnsupportedObjectError(message)


def _active_marked_mcid(stack: list[int | None]) -> int | None:
    """Retain enclosing MCID through an unnumbered nested marked sequence."""
    active: int | None = None
    for item in stack:
        if item is None:
            continue
        if active is not None:
            message = "PDF_MARKED_NESTED_MCID_UNSUPPORTED"
            raise _UnsupportedObjectError(message)
        active = item
    return active


def _marked_content(  # noqa: C901, PLR0912 - bounded PDF content operators require distinct cases.
    reader: PdfReader, budget: _Budget
) -> tuple[PdfMarkedContentObject, ...]:
    """Decode a bounded direct marked-content text subset by page and MCID."""
    from pypdf.generic import ContentStream, DecodedStreamObject, DictionaryObject

    result: list[PdfMarkedContentObject] = []
    for page_number, page in enumerate(reader.pages, start=1):
        if "/Contents" not in page:
            continue
        source_streams = _resolve(page["/Contents"])
        stream_items = (
            source_streams if isinstance(source_streams, list) else [page["/Contents"]]
        )
        content = b"\n".join(_stream_bytes(item, budget) for item in stream_items)
        decoded = DecodedStreamObject()
        decoded.set_data(content)
        operations = ContentStream(decoded, reader).operations
        if len(operations) > _MAX_OBJECTS:
            message = "DOCUMENT_MARKED_OPERATIONS_LIMIT"
            raise _ObjectLimitError(message)
        stack: list[int | None] = []
        text_by_mcid: dict[int, list[str]] = {}
        for operands, operator in operations:
            if operator == b"BDC":
                properties = _resolve(operands[1]) if len(operands) > 1 else None
                if isinstance(properties, DictionaryObject) and "/MCID" in properties:
                    mcid = int(_resolve(properties["/MCID"]))
                    if mcid < 0:
                        message = "PDF_STRUCTURE_MCID_INVALID"
                        raise _UnsupportedObjectError(message)
                    stack.append(mcid)
                    text_by_mcid.setdefault(mcid, [])
                else:
                    stack.append(None)
            elif operator == b"BMC":
                stack.append(None)
            elif operator == b"EMC":
                if not stack:
                    message = "PDF_MARKED_CONTENT_UNBALANCED"
                    raise _UnsupportedObjectError(message)
                stack.pop()
            elif (active_mcid := _active_marked_mcid(stack)) is not None:
                if operator in (b"Tj", b"'", b'"'):
                    value = operands[-1]
                    text_by_mcid[active_mcid].append(_source_text_operand(value))
                elif operator == b"TJ":
                    chunks = _array(operands[0])
                    text_by_mcid[active_mcid].append(
                        "".join(
                            _source_text_operand(item)
                            for item in chunks
                            if not isinstance(item, int | float)
                        )
                    )
                elif operator == b"Do":
                    message = "PDF_MARKED_XOBJECT_CONTENT_UNSUPPORTED"
                    raise _UnsupportedObjectError(message)
        if stack:
            message = "PDF_MARKED_CONTENT_UNBALANCED"
            raise _UnsupportedObjectError(message)
        for mcid, pieces in sorted(text_by_mcid.items()):
            text = _limited_text("".join(pieces), budget)
            result.append(
                PdfMarkedContentObject(
                    source=PdfObjectSource(
                        source_path=f"/Pages/{page_number - 1}/Contents/MCID/{mcid}"
                    ),
                    page_number=page_number,
                    mcid=mcid,
                    text=text,
                )
            )
    return tuple(result)


def _structure(  # noqa: C901, PLR0915 - source tree and parent tree share cycle/budget state.
    reader: PdfReader, budget: _Budget
) -> tuple[
    tuple[PdfStructureNode, ...],
    tuple[PdfStructureParentLink, ...],
    tuple[PdfMarkedContentObject, ...],
    PdfObjectValue,
    PdfObjectValue,
    bool,
]:
    root = _catalog(reader)
    mark_info = _dictionary(root["/MarkInfo"]) if "/MarkInfo" in root else None
    marked = (
        _field(mark_info, "/Marked", budget)
        if mark_info is not None
        else PdfObjectValue(state="MISSING")
    )
    language = _field(root, "/Lang", budget)
    if "/StructTreeRoot" not in root:
        return (), (), (), language, marked, False
    tree = _dictionary(root["/StructTreeRoot"])
    marked_records = _marked_content(reader, budget)
    marked_by_key = {
        (record.page_number, record.mcid): record.text for record in marked_records
    }
    pages = _page_sources(reader)
    nodes: list[PdfStructureNode] = []
    parent_links: list[PdfStructureParentLink] = []
    visited: set[tuple[int, int] | int] = set()
    has_mcid_without_content = False

    def walk(  # noqa: PLR0913 - structure recursion carries parent/page/source identity.
        value: Any,
        *,
        path: str,
        parent: PdfObjectSource | None,
        page: int | None,
        depth: int,
        order: int,
    ) -> None:
        nonlocal has_mcid_without_content
        if depth > _MAX_DEPTH:
            message = "DOCUMENT_OBJECT_DEPTH_LIMIT"
            raise _ObjectLimitError(message)
        budget.charge_object()
        if isinstance(_resolve(value), int):
            scalar_mcid = int(_resolve(value))
            if scalar_mcid < 0:
                message = "PDF_STRUCTURE_MCID_INVALID"
                raise _UnsupportedObjectError(message)
            nodes.append(
                PdfStructureNode(
                    source=_source(value, path),
                    parent_source=parent,
                    order=order,
                    role=PdfObjectValue(state="MISSING"),
                    page_number=page,
                    mcid=scalar_mcid,
                    actual_text=PdfObjectValue(state="MISSING"),
                    alt_text=PdfObjectValue(state="MISSING"),
                    content_text=(
                        PdfObjectValue(
                            state="PRESENT",
                            type_name="string",
                            text=marked_by_key[(page, scalar_mcid)],
                        )
                        if page is not None and (page, scalar_mcid) in marked_by_key
                        else PdfObjectValue(state="MISSING")
                    ),
                )
            )
            has_mcid_without_content |= (
                page is None or (page, scalar_mcid) not in marked_by_key
            )
            return
        identity = _key(value)
        if identity in visited:
            message = "PDF_STRUCTURE_CYCLE_OR_SHARED_NODE"
            raise _UnsupportedObjectError(message)
        visited.add(identity)
        node = _dictionary(value)
        page_number = _page_number(node.get("/Pg"), pages) or page
        mcid = int(_resolve(node["/MCID"])) if "/MCID" in node else None
        actual_text = _field(node, "/ActualText", budget)
        raw_child = _resolve(node.get("/K"))
        child_mcid = raw_child if isinstance(raw_child, int) else None
        content_mcid = mcid if mcid is not None else child_mcid
        if content_mcid is not None and content_mcid < 0:
            message = "PDF_STRUCTURE_MCID_INVALID"
            raise _UnsupportedObjectError(message)
        content = (
            marked_by_key.get((page_number, content_mcid))
            if page_number is not None and content_mcid is not None
            else None
        )
        if content_mcid is not None and content is None:
            has_mcid_without_content = True
        source = _source(value, path)
        nodes.append(
            PdfStructureNode(
                source=source,
                parent_source=parent,
                order=order,
                role=_field(node, "/S", budget),
                page_number=page_number,
                mcid=content_mcid,
                actual_text=actual_text,
                alt_text=_field(node, "/Alt", budget),
                content_text=(
                    PdfObjectValue(state="PRESENT", type_name="string", text=content)
                    if content is not None
                    else PdfObjectValue(state="MISSING")
                ),
            )
        )
        if "/K" in node:
            children = _resolve(node["/K"])
            if isinstance(children, list):
                for index, child in enumerate(children):
                    walk(
                        child,
                        path=f"{path}/K/{index}",
                        parent=source,
                        page=page_number,
                        depth=depth + 1,
                        order=index,
                    )
            else:
                walk(
                    node["/K"],
                    path=f"{path}/K/0",
                    parent=source,
                    page=page_number,
                    depth=depth + 1,
                    order=0,
                )

    if "/K" in tree:
        children = _resolve(tree["/K"])
        if isinstance(children, list):
            for index, child in enumerate(children):
                walk(
                    child,
                    path=f"/Root/StructTreeRoot/K/{index}",
                    parent=None,
                    page=None,
                    depth=0,
                    order=index,
                )
        else:
            walk(
                tree["/K"],
                path="/Root/StructTreeRoot/K/0",
                parent=None,
                page=None,
                depth=0,
                order=0,
            )
    if "/ParentTree" in tree:
        parent_tree = _dictionary(tree["/ParentTree"])
        if "/Kids" in parent_tree:
            message = "PDF_PARENT_TREE_KIDS_UNSUPPORTED"
            raise _UnsupportedObjectError(message)
        entries = _array(parent_tree["/Nums"]) if "/Nums" in parent_tree else []
        if len(entries) % 2:
            message = "PDF_PARENT_TREE_ODD_ENTRY_COUNT"
            raise _UnsupportedObjectError(message)
        for offset in range(0, len(entries), 2):
            budget.charge_object()
            index = int(_resolve(entries[offset]))
            if index < 0:
                message = "PDF_PARENT_TREE_INDEX_INVALID"
                raise _UnsupportedObjectError(message)
            path = f"/Root/StructTreeRoot/ParentTree/Nums/{offset + 1}"
            targets = _resolve(entries[offset + 1])
            target_items = (
                targets if isinstance(targets, list) else [entries[offset + 1]]
            )
            parent_links.append(
                PdfStructureParentLink(
                    source=_source(entries[offset + 1], path),
                    index=index,
                    target_sources=tuple(
                        _source(item, f"{path}/{position}")
                        for position, item in enumerate(target_items)
                    ),
                )
            )
    return (
        tuple(nodes),
        tuple(parent_links),
        marked_records,
        language,
        marked,
        has_mcid_without_content,
    )


def _channel(
    name: ChannelName,
    *,
    present: bool,
    issue: Exception | None = None,
    incomplete: str | None = None,
) -> PdfObjectChannel:
    if isinstance(issue, _ObjectLimitError):
        return PdfObjectChannel(
            name=name, state="LIMITED", limitation_codes=(str(issue),)
        )
    if isinstance(issue, _UnsupportedObjectError):
        return PdfObjectChannel(
            name=name, state="UNSUPPORTED", limitation_codes=(str(issue),)
        )
    if issue is not None:
        return PdfObjectChannel(
            name=name,
            state="INCOMPLETE",
            limitation_codes=(f"PDF_{name.upper()}_EXTRACTION_FAILED",),
        )
    if incomplete is not None:
        return PdfObjectChannel(
            name=name, state="INCOMPLETE", limitation_codes=(incomplete,)
        )
    return PdfObjectChannel(name=name, state="COMPLETE" if present else "ABSENT")


def _unreadable(source_sha256: str, reason: str) -> PdfDocumentObjects:
    """Keep a parser/password failure distinct from empty source inventories."""
    return PdfDocumentObjects(
        source_sha256=source_sha256,
        channels=tuple(
            PdfObjectChannel(
                name=name,
                state="UNSUPPORTED",
                limitation_codes=(reason,),
            )
            for name in _CHANNELS
        ),
    )


def _initial_reader(
    source_bytes: bytes,
) -> tuple[PdfReader, PdfXrefRecoveryReceipt | None]:
    """Try the original source before the strictly bounded xref repair."""
    from pypdf import PdfReader
    from pypdf.errors import PdfReadError

    from document_sdk.pdf._xref_keyword_recovery import recover_source_reader

    try:
        return PdfReader(BytesIO(source_bytes), strict=False), None
    except PdfReadError:
        return recover_source_reader(source_bytes)


def _recovery_channels(
    channels: list[PdfObjectChannel], recovery: PdfXrefRecoveryReceipt | None
) -> tuple[PdfObjectChannel, ...]:
    """Retain each channel's evidence state and record the actual reader recovery."""
    if recovery is None:
        return tuple(channels)
    return tuple(
        PdfObjectChannel(
            name=channel.name,
            state=channel.state,
            limitation_codes=(
                *channel.limitation_codes,
                "PDF_TRUNCATED_TRAILER_PARSER_VIEW"
                if recovery.method
                == "ORIGINAL_CLASSIC_XREF_TRUNCATED_TRAILER_PARSER_VIEW_V1"
                else "PDF_XREF_KEYWORD_RECOVERED",
            ),
        )
        for channel in channels
    )


def extract_document_objects(  # noqa: C901, PLR0912, PLR0915 - isolate eight source channels.
    source_bytes: bytes,
    *,
    source_sha256: str,
    password: str | None,
    recovery_receipts: list[PdfXrefRecoveryReceipt] | None = None,
) -> PdfDocumentObjects:
    """Extract bounded PDF document objects from the exact authorized source.

    This function never executes actions or links, fetches external resources,
    or reads a source oracle. A limited or unsupported channel is never emitted
    as a completed empty inventory. Password bytes and backend exception text
    are excluded from its public result.
    """
    from document_sdk.pdf._xref_keyword_recovery import XrefKeywordRecoveryError

    if (
        not isinstance(source_bytes, bytes)
        or sha256(source_bytes).hexdigest() != source_sha256
    ):
        message = "PDF document-object source identity mismatch"
        raise ValueError(message)
    try:
        reader, recovery = _initial_reader(source_bytes)
        if reader.is_encrypted:
            if password is None:
                return _unreadable(source_sha256, "PDF_OBJECT_PASSWORD_REQUIRED")
            if not reader.decrypt(password):
                return _unreadable(source_sha256, "PDF_OBJECT_PASSWORD_INVALID")
        root = _catalog(reader)
        if len(reader.pages) > _MAX_OBJECTS:
            return _unreadable(source_sha256, "DOCUMENT_OBJECT_PAGE_COUNT_LIMIT")
    except XrefKeywordRecoveryError as error:
        return _unreadable(source_sha256, str(error))
    except Exception:  # noqa: BLE001 - redacted per-channel backend boundary.
        return _unreadable(source_sha256, "PDF_OBJECT_READER_FAILED")

    if recovery is not None and recovery_receipts is not None:
        recovery_receipts.append(recovery)

    channels: list[PdfObjectChannel] = []
    annotations: tuple[PdfAnnotationObject, ...] = ()
    try:
        annotations = _annotations(reader, _Budget())
        channels.append(
            _channel(
                "annotations",
                present=any("/Annots" in page for page in reader.pages),
            )
        )
    except Exception as error:  # noqa: BLE001 - preserve other object channels.
        channels.append(_channel("annotations", present=False, issue=error))

    form_fields: tuple[PdfFormFieldObject, ...] = ()
    try:
        form_fields = _forms(reader, _Budget())
        form_present = "/AcroForm" in root
        form = _dictionary(root["/AcroForm"]) if form_present else None
        form_incomplete = (
            "PDF_FORM_FIELDS_MISSING"
            if form is not None and "/Fields" not in form
            else None
        )
        if any(
            widget.page_number is None
            for field in form_fields
            for widget in field.widget_sources
        ):
            form_incomplete = "PDF_WIDGET_PAGE_BINDING_UNRESOLVED"
        channels.append(
            _channel("form_fields", present=form_present, incomplete=form_incomplete)
        )
    except Exception as error:  # noqa: BLE001 - preserve other object channels.
        channels.append(_channel("form_fields", present=False, issue=error))

    destinations: tuple[PdfDestinationObject, ...] = ()
    try:
        destinations = _destinations(reader, _Budget())
        names = _dictionary(root["/Names"]) if "/Names" in root else None
        destinations_present = "/Dests" in root or (
            names is not None and "/Dests" in names
        )
        destinations_incomplete = (
            "PDF_DESTINATION_PAGE_BINDING_UNRESOLVED"
            if any(item.target_page_number is None for item in destinations)
            else None
        )
        destinations_channel = _channel(
            "destinations",
            present=destinations_present,
            incomplete=destinations_incomplete,
        )
    except Exception as error:  # noqa: BLE001 - preserve other object channels.
        destinations_channel = _channel("destinations", present=False, issue=error)

    outlines: tuple[PdfOutlineObject, ...] = ()
    try:
        outlines, outlines_incomplete = _outlines(reader, _Budget(), destinations)
        channels.append(
            _channel(
                "outlines",
                present="/Outlines" in root,
                incomplete=outlines_incomplete,
            )
        )
    except Exception as error:  # noqa: BLE001 - preserve other object channels.
        channels.append(_channel("outlines", present=False, issue=error))
    channels.append(destinations_channel)

    attachments: tuple[PdfAttachmentObject, ...] = ()
    attachment_references: tuple[PdfAttachmentReference, ...] = ()
    try:
        (
            attachments,
            attachment_references,
            attachments_present,
            attachment_incomplete,
        ) = _attachments(reader, _Budget())
        incomplete = (
            "PDF_ATTACHMENT_CONTENT_UNAVAILABLE"
            if any(item.content_base64 is None for item in attachments)
            else attachment_incomplete
        )
        channels.append(
            _channel(
                "attachments",
                present=attachments_present,
                incomplete=incomplete,
            )
        )
    except Exception as error:  # noqa: BLE001 - preserve other object channels.
        channels.append(_channel("attachments", present=False, issue=error))

    metadata_entries: tuple[PdfInfoEntry, ...] = ()
    try:
        metadata_entries = _metadata(reader, _Budget())
        channels.append(_channel("metadata", present="/Info" in reader.trailer))
    except Exception as error:  # noqa: BLE001 - preserve other object channels.
        channels.append(_channel("metadata", present=False, issue=error))

    xmp: PdfXmpObject | None = None
    try:
        xmp = _xmp(reader, _Budget())
        channels.append(_channel("xmp", present="/Metadata" in root))
    except Exception as error:  # noqa: BLE001 - preserve other object channels.
        channels.append(_channel("xmp", present=False, issue=error))

    structure_nodes: tuple[PdfStructureNode, ...] = ()
    structure_parent_links: tuple[PdfStructureParentLink, ...] = ()
    marked_content: tuple[PdfMarkedContentObject, ...] = ()
    document_language = PdfObjectValue(state="MISSING")
    document_marked = PdfObjectValue(state="MISSING")
    try:
        (
            structure_nodes,
            structure_parent_links,
            marked_content,
            document_language,
            document_marked,
            incomplete_content,
        ) = _structure(reader, _Budget())
        channels.append(
            _channel(
                "structure_tree",
                present=any(
                    key in root for key in ("/StructTreeRoot", "/Lang", "/MarkInfo")
                ),
                incomplete=(
                    "PDF_STRUCTURE_CONTENT_BINDING_INCOMPLETE"
                    if incomplete_content
                    else None
                ),
            )
        )
    except Exception as error:  # noqa: BLE001 - preserve other object channels.
        channels.append(_channel("structure_tree", present=False, issue=error))

    return PdfDocumentObjects(
        source_sha256=source_sha256,
        channels=_recovery_channels(channels, recovery),
        annotations=annotations,
        form_fields=form_fields,
        outlines=outlines,
        destinations=destinations,
        attachments=attachments,
        attachment_references=attachment_references,
        metadata_entries=metadata_entries,
        xmp=xmp,
        document_language=document_language,
        document_marked=document_marked,
        structure_nodes=structure_nodes,
        structure_parent_links=structure_parent_links,
        marked_content=marked_content,
    )

"""Source execution text, distinct from visual reading and physical ownership."""

from __future__ import annotations

from collections import defaultdict
from typing import TYPE_CHECKING, Literal

from pydantic import Field

from document_sdk.core.models import SdkModel

if TYPE_CHECKING:
    from document_sdk.pdf._structural_engine.facts.native_text_contracts import (
        PdfNativeTextShowEvent,
    )
    from document_sdk.pdf.local_evidence_members import (
        PdfLocalEvidenceV3,
        PdfLocalPageEvidenceV3,
        PdfLocalTextMember,
    )


class PdfSourceTextOccurrence(SdkModel):
    """One decoded render occurrence linked to the retained pre-filter member."""

    member_id: str
    text: str
    event_member_ordinal: int | None = Field(ge=0)
    native_character_ordinal: int | None = Field(ge=0)
    selection_state: Literal["RETAINED", "DEDUPE_SUPPRESSED", "GEOMETRY_REJECTED"]


class PdfSourceTextGap(SdkModel):
    """An unavailable ordinal interval; end is exclusive, not invented text."""

    scope: Literal["EVENT", "EVENT_MEMBER", "UNBOUND_MEMBER", "DECODE"]
    event_ordinal: int | None = Field(ge=0)
    start: int | None = Field(ge=0)
    end: int | None = Field(ge=0)
    reason: str


class PdfSourceTextEvent(SdkModel):
    """Ordered interpreter occurrence; Form invocations remain distinct."""

    native_event_id: str
    native_event_ordinal: int = Field(ge=0)
    invocation_path: tuple[int, ...]
    operator: Literal["Tj", "TJ", "'", '"']
    text: str
    source_member_count: int = Field(ge=0)
    occurrences: tuple[PdfSourceTextOccurrence, ...]


class PdfSourceTextPage(SdkModel):
    """All retained source occurrences, including cropped or rejected geometry."""

    page_number: int = Field(ge=1)
    text: str
    completeness: Literal["COMPLETE", "PARTIAL"]
    source_event_count: int = Field(ge=0)
    source_member_count: int = Field(ge=0)
    events: tuple[PdfSourceTextEvent, ...]
    unbound_occurrences: tuple[PdfSourceTextOccurrence, ...]
    gaps: tuple[PdfSourceTextGap, ...]
    limitation_codes: tuple[str, ...]


class PdfSourceText(SdkModel):
    """Fixed serialization of decoded source text, never a visual-order claim."""

    schema_version: Literal["document_sdk.pdf.source_text.v1"] = (
        "document_sdk.pdf.source_text.v1"
    )
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    order_semantics: Literal["native_text_show_execution_order"] = (
        "native_text_show_execution_order"
    )
    event_separator: Literal["\n"] = "\n"
    page_separator: Literal["\f"] = "\f"
    separators_are_source_characters: Literal[False] = False
    text: str
    completeness: Literal["COMPLETE", "PARTIAL"]
    source_page_count: int = Field(ge=0)
    limitation_codes: tuple[str, ...]
    pages: tuple[PdfSourceTextPage, ...]


def _occurrence(member: PdfLocalTextMember) -> PdfSourceTextOccurrence:
    return PdfSourceTextOccurrence(
        member_id=member.member_id,
        text=member.text,
        event_member_ordinal=member.native_text_event_member_ordinal,
        native_character_ordinal=member.native_character_ordinal,
        selection_state=member.selection_state,
    )


def _ordinal_gaps(
    present: list[int], total: int, event_ordinal: int | None
) -> list[PdfSourceTextGap]:
    cursor = 0
    result = []
    for ordinal in [*present, total]:
        if ordinal > cursor:
            result.append(
                PdfSourceTextGap(
                    scope="EVENT" if event_ordinal is None else "EVENT_MEMBER",
                    event_ordinal=event_ordinal,
                    start=cursor,
                    end=ordinal,
                    reason="SOURCE_OBSERVATION_NOT_RETAINED",
                )
            )
        cursor = ordinal + 1
    return result


def _event(
    record: PdfNativeTextShowEvent, members: list[PdfLocalTextMember]
) -> tuple[PdfSourceTextEvent, list[PdfSourceTextGap]]:
    ordered = sorted(
        members,
        key=lambda member: (
            member.native_text_event_member_ordinal
            if member.native_text_event_member_ordinal is not None
            else -1
        ),
    )
    ordinals = [
        member.native_text_event_member_ordinal
        for member in ordered
        if member.native_text_event_member_ordinal is not None
    ]
    if ordinals != sorted(set(ordinals)) or any(
        ordinal >= record.source_member_count for ordinal in ordinals
    ):
        message = "source text member execution ordinals are inconsistent"
        raise ValueError(message)
    return (
        PdfSourceTextEvent(
            native_event_id=record.source_event_id,
            native_event_ordinal=record.native_event_ordinal,
            invocation_path=record.invocation_path,
            operator=record.operator,
            source_member_count=record.source_member_count,
            text="".join(member.text for member in ordered),
            occurrences=tuple(_occurrence(member) for member in ordered),
        ),
        _ordinal_gaps(
            ordinals, record.source_member_count, record.native_event_ordinal
        ),
    )


def _validate_capture_identity(page: PdfLocalPageEvidenceV3) -> None:
    """Reject contradictory identities independently of projection availability."""
    scope = page.native_text_event_evidence
    records = scope.events if scope is not None else ()
    event_ids = [record.source_event_id for record in records]
    event_ordinals = [record.native_event_ordinal for record in records]
    member_ids = [member.member_id for member in page.text_members]
    character_ordinals = [member.source_character_index for member in page.text_members]
    if (
        len(event_ids) != len(set(event_ids))
        or event_ordinals != sorted(set(event_ordinals))
        or any(
            scope is None or ordinal >= scope.source_event_count
            for ordinal in event_ordinals
        )
        or len(member_ids) != len(set(member_ids))
        or character_ordinals != sorted(set(character_ordinals))
        or any(ordinal >= page.source_member_count for ordinal in character_ordinals)
    ):
        message = "source text capture identities are repeated or unordered"
        raise ValueError(message)
    events = {record.source_event_id: record for record in records}
    bound_native_ordinals = []
    for member in page.text_members:
        record = events.get(str(member.native_text_event_id))
        if record is None:
            continue
        if (
            member.native_text_event_ordinal != record.native_event_ordinal
            or member.native_character_ordinal is None
            or member.native_text_event_member_ordinal is None
            or scope is None
            or member.native_character_ordinal >= scope.source_member_count
        ):
            message = "source text member identity differs from its native event"
            raise ValueError(message)
        bound_native_ordinals.append(member.native_character_ordinal)
    if bound_native_ordinals != sorted(set(bound_native_ordinals)):
        message = "source text native character identities are repeated or unordered"
        raise ValueError(message)


def _page(page: PdfLocalPageEvidenceV3) -> PdfSourceTextPage:
    _validate_capture_identity(page)
    scope = page.native_text_event_evidence
    records = scope.events if scope is not None else ()
    event_ids = {record.source_event_id for record in records}
    by_event: dict[str, list[PdfLocalTextMember]] = defaultdict(list)
    unbound = []
    gaps: list[PdfSourceTextGap] = []
    limitations = set(scope.limitation_codes if scope is not None else ())
    gaps.extend(
        PdfSourceTextGap(
            scope="DECODE",
            event_ordinal=None,
            start=None,
            end=None,
            reason=code,
        )
        for code in limitations
        if "decode" in code
    )
    for member in page.text_members:
        if member.native_text_event_id in event_ids:
            by_event[str(member.native_text_event_id)].append(member)
        else:
            unbound.append(_occurrence(member))
    events = []
    for record in records:
        event, event_gaps = _event(record, by_event[record.source_event_id])
        events.append(event)
        gaps.extend(event_gaps)
        gaps.extend(
            PdfSourceTextGap(
                scope="DECODE",
                event_ordinal=record.native_event_ordinal,
                start=0,
                end=record.source_member_count,
                reason=code,
            )
            for code in record.limitation_codes
            if "decode" in code
        )
    source_events = scope.source_event_count if scope is not None else 0
    source_members = (
        scope.source_member_count if scope is not None else page.source_member_count
    )
    gaps.extend(
        _ordinal_gaps(
            [event.native_event_ordinal for event in events], source_events, None
        )
    )
    if unbound:
        gaps.append(
            PdfSourceTextGap(
                scope="UNBOUND_MEMBER",
                event_ordinal=None,
                start=None,
                end=None,
                reason="NATIVE_EVENT_BINDING_NOT_RETAINED",
            )
        )
    if scope is None or len(events) != source_events:
        limitations.add("SOURCE_EVENT_INVENTORY_INCOMPLETE")
    elif scope.availability != "COMPLETE" and not limitations:
        limitations.add("SOURCE_EVENT_CAPTURE_NOT_COMPLETE")
    if (
        len(page.text_members) != source_members
        or len(page.text_members) != page.source_member_count
    ):
        limitations.add("SOURCE_MEMBER_INVENTORY_INCOMPLETE")
    return PdfSourceTextPage(
        page_number=page.page_number,
        text="\n".join(event.text for event in events),
        completeness="PARTIAL" if gaps or limitations else "COMPLETE",
        source_event_count=source_events,
        source_member_count=source_members,
        events=tuple(events),
        unbound_occurrences=tuple(unbound),
        gaps=tuple(gaps),
        limitation_codes=tuple(sorted(limitations)),
    )


def build_source_text(evidence: PdfLocalEvidenceV3) -> PdfSourceText:
    """Project the same-call member pool without visual selection or deduplication."""
    pages = tuple(_page(page) for page in evidence.pages)
    limitations = (
        ()
        if len(pages) == evidence.source_page_count
        and tuple(page.page_number for page in pages)
        == tuple(range(1, evidence.source_page_count + 1))
        else ("SOURCE_PAGE_INVENTORY_INCOMPLETE",)
    )
    return PdfSourceText(
        source_sha256=evidence.source_sha256,
        text="\f".join(page.text for page in pages),
        completeness=(
            "COMPLETE"
            if not limitations
            and all(page.completeness == "COMPLETE" for page in pages)
            else "PARTIAL"
        ),
        source_page_count=evidence.source_page_count,
        limitation_codes=limitations,
        pages=pages,
    )

"""Explicit private exports for the unwired PDF structural thin adapter."""

from document_sdk.pdf._structural_engine.adapter.contracts import (
    PDF_STRUCTURAL_ADAPTER_EFFECTIVE_LIMITS_SCHEMA_VERSION,
    PDF_STRUCTURAL_ADAPTER_EVIDENCE_SCHEMA_VERSION,
    PDF_STRUCTURAL_ADAPTER_SCHEMA_VERSION,
    PdfStructuralAdapterApplicablePublicLimits,
    PdfStructuralAdapterEffectiveLimits,
    PdfStructuralAdapterErrorCategory,
    PdfStructuralAdapterErrorStage,
    PdfStructuralAdapterEvidence,
    PdfStructuralAdapterLimitName,
    PdfStructuralAdapterMetrics,
    PdfStructuralAdapterRequest,
    PdfStructuralAdapterResult,
    PdfStructuralAdapterRuntimeLimitations,
    PdfStructuralAdapterSourceMetadata,
)
from document_sdk.pdf._structural_engine.adapter.execution import (
    run_pdf_structural_adapter,
)
from document_sdk.pdf._structural_engine.adapter.mapping import (
    PDF_STRUCTURAL_ADAPTER_PUBLIC_LIMIT_MAPPING,
)

__all__ = [
    "PDF_STRUCTURAL_ADAPTER_EFFECTIVE_LIMITS_SCHEMA_VERSION",
    "PDF_STRUCTURAL_ADAPTER_EVIDENCE_SCHEMA_VERSION",
    "PDF_STRUCTURAL_ADAPTER_PUBLIC_LIMIT_MAPPING",
    "PDF_STRUCTURAL_ADAPTER_SCHEMA_VERSION",
    "PdfStructuralAdapterApplicablePublicLimits",
    "PdfStructuralAdapterEffectiveLimits",
    "PdfStructuralAdapterErrorCategory",
    "PdfStructuralAdapterErrorStage",
    "PdfStructuralAdapterEvidence",
    "PdfStructuralAdapterLimitName",
    "PdfStructuralAdapterMetrics",
    "PdfStructuralAdapterRequest",
    "PdfStructuralAdapterResult",
    "PdfStructuralAdapterRuntimeLimitations",
    "PdfStructuralAdapterSourceMetadata",
    "run_pdf_structural_adapter",
]

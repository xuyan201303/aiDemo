"""Private contracts for the unwired PDF structural thin adapter."""

# ruff: noqa: C901, EM101, I001, PLR0912, PLR0915, TC001, TRY003

from __future__ import annotations

from typing import Literal, Self

from pydantic import BaseModel, ConfigDict, Field, model_validator

from document_sdk.core.models import PdfInspection
from document_sdk.pdf._structural_engine.facts.contracts import PdfFactArtifact
from document_sdk.pdf._structural_engine.facts.identifiers import (
    document_identifier,
)
from document_sdk.pdf._structural_engine.facts.limits import (
    PdfExtractionLimits,
    PdfExtractionOptions,
)
from document_sdk.pdf._structural_engine.facts.status import (
    PdfExtractionStatus,
    PdfWarningCode,
)
from document_sdk.pdf._structural_engine.layout.consumer import (
    PdfLayoutConsumerLimitationCode,
    PdfLayoutConsumerReadinessOutcome,
    PdfLayoutGraphConsumerReadiness,
)
from document_sdk.pdf._structural_engine.layout.contracts import (
    PdfLayoutGraphArtifact,
)
from document_sdk.pdf._structural_engine.layout.identifiers import (
    canonical_payload_sha256,
    source_fact_artifact_digest,
)
from document_sdk.pdf._structural_engine.layout.limits import (
    PdfLayoutGraphLimits,
    PdfLayoutGraphOptions,
)
from document_sdk.pdf._structural_engine.layout.strategy import (
    PdfLayoutParserPreflight,
    PdfLayoutParserRoutePlan,
    PdfLayoutParserRoutingPolicy,
    PdfLayoutRoutableParser,
)
from document_sdk.pdf.models import PdfProcessingLimits


PDF_STRUCTURAL_ADAPTER_SCHEMA_VERSION: Literal["pdf_structural_adapter.v1"] = (
    "pdf_structural_adapter.v1"
)
PDF_STRUCTURAL_ADAPTER_EFFECTIVE_LIMITS_SCHEMA_VERSION: Literal[
    "pdf_structural_adapter_effective_limits.v1"
] = "pdf_structural_adapter_effective_limits.v1"
PDF_STRUCTURAL_ADAPTER_EVIDENCE_SCHEMA_VERSION: Literal[
    "pdf_structural_adapter_evidence.v1"
] = "pdf_structural_adapter_evidence.v1"
PdfStructuralAdapterPublicLimitClassification = Literal[
    "APPLICABLE_WHOLE_SOURCE",
    "APPLICABLE_INSPECTION_WHOLE_SOURCE",
    "NOT_APPLICABLE_NO_RENDER",
    "NOT_APPLICABLE_RENDER_OUTPUT",
]
PDF_STRUCTURAL_ADAPTER_PUBLIC_LIMIT_MAPPING: tuple[
    tuple[str, PdfStructuralAdapterPublicLimitClassification], ...
] = (
    ("max_file_bytes", "APPLICABLE_WHOLE_SOURCE"),
    ("max_pages", "APPLICABLE_WHOLE_SOURCE"),
    ("max_page_width_points", "APPLICABLE_INSPECTION_WHOLE_SOURCE"),
    ("max_page_height_points", "APPLICABLE_INSPECTION_WHOLE_SOURCE"),
    ("max_page_area_points", "APPLICABLE_INSPECTION_WHOLE_SOURCE"),
    ("max_native_text_pages", "APPLICABLE_INSPECTION_WHOLE_SOURCE"),
    ("max_native_text_characters", "APPLICABLE_INSPECTION_WHOLE_SOURCE"),
    ("max_render_dpi", "NOT_APPLICABLE_NO_RENDER"),
    ("max_render_width", "NOT_APPLICABLE_NO_RENDER"),
    ("max_render_height", "NOT_APPLICABLE_NO_RENDER"),
    ("max_render_pixels", "NOT_APPLICABLE_NO_RENDER"),
    ("max_output_bytes", "NOT_APPLICABLE_RENDER_OUTPUT"),
)

PdfStructuralAdapterOutcome = Literal["completed", "failed"]
PdfStructuralAdapterErrorCategory = Literal[
    "none",
    "invalid_request",
    "source_identity_mismatch",
    "dependency_unavailable",
    "encrypted",
    "malformed",
    "parser_failure",
    "resource_limit",
    "layout_failure",
    "internal_failure",
]
PdfStructuralAdapterErrorStage = Literal[
    "none",
    "request_binding",
    "public_limit",
    "routing",
    "parser_resolution",
    "fact_extraction",
    "fact_validation",
    "layout_build",
    "layout_validation",
    "consumer_readiness",
    "internal",
]
PdfStructuralAdapterLimitName = Literal[
    "max_file_bytes",
    "max_pages",
    "max_page_width_points",
    "max_page_height_points",
    "max_page_area_points",
    "max_native_text_pages",
    "max_native_text_characters",
    "private_max_file_size_bytes",
    "max_selected_page_count",
]
_BUILDABLE_FACT_STATUSES = frozenset(
    {
        PdfExtractionStatus.NO_TEXT_LAYER,
        PdfExtractionStatus.PARTIAL,
        PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED,
        PdfExtractionStatus.SUCCESS,
    }
)
_BUILDABLE_LAYOUT_STATUSES = frozenset(
    {
        PdfExtractionStatus.PARTIAL,
        PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED,
        PdfExtractionStatus.SUCCESS,
    }
)
_TERMINAL_FACT_CATEGORIES: dict[
    PdfExtractionStatus,
    PdfStructuralAdapterErrorCategory,
] = {
    PdfExtractionStatus.ENCRYPTED: "encrypted",
    PdfExtractionStatus.INTERNAL_ERROR: "internal_failure",
    PdfExtractionStatus.INVALID_REQUEST: "invalid_request",
    PdfExtractionStatus.MALFORMED: "malformed",
    PdfExtractionStatus.PARSER_ERROR: "parser_failure",
    PdfExtractionStatus.PARTIAL: "parser_failure",
    PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED: "resource_limit",
    PdfExtractionStatus.UNSUPPORTED: "parser_failure",
}


def _fact_warning_code_inventory(
    artifact: PdfFactArtifact,
) -> tuple[PdfWarningCode, ...]:
    codes = [warning.code for warning in artifact.warnings]
    for page in artifact.pages:
        codes.extend(warning.code for warning in page.warnings)
        for text_span in page.text_spans:
            codes.extend(warning.code for warning in text_span.warnings)
        for word in page.words:
            codes.extend(warning.code for warning in word.warnings)
        for line in page.line_candidates:
            codes.extend(warning.code for warning in line.warnings)
        for character in page.characters:
            codes.extend(warning.code for warning in character.warnings)
        for drawing in page.drawings:
            codes.extend(warning.code for warning in drawing.warnings)
        for image in page.image_regions:
            codes.extend(warning.code for warning in image.warnings)
    return tuple(codes)


def _layout_warning_code_inventory(
    artifact: PdfLayoutGraphArtifact,
) -> tuple[PdfWarningCode, ...]:
    return tuple(
        warning.code
        for warning in (
            *artifact.warnings,
            *(warning for page in artifact.pages for warning in page.warnings),
        )
    )


class _PdfStructuralAdapterModel(BaseModel):
    """Strict immutable base for private Adapter evidence."""

    model_config = ConfigDict(
        extra="forbid",
        frozen=True,
        hide_input_in_errors=True,
        strict=True,
    )


class PdfStructuralAdapterRequest(_PdfStructuralAdapterModel):
    """Explicit caller authority for one private structural execution."""

    inspection: PdfInspection = Field(repr=False, exclude=True)
    preflight: PdfLayoutParserPreflight
    policy: PdfLayoutParserRoutingPolicy
    extraction_options: PdfExtractionOptions
    layout_options: PdfLayoutGraphOptions
    processing_limits: PdfProcessingLimits


class PdfStructuralAdapterSourceMetadata(_PdfStructuralAdapterModel):
    """Path-free source identity derived only from the immutable bytes."""

    fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    file_id: str = Field(pattern=r"^PDFD-[0-9a-f]{24}$")
    source_size_bytes: int = Field(ge=0)

    @model_validator(mode="after")
    def validate_file_id(self) -> Self:
        """Bind the private document identifier to the source digest."""
        if self.file_id != document_identifier(source_hash=self.fingerprint):
            raise ValueError("source file_id must match the source fingerprint")
        return self


class PdfStructuralAdapterApplicablePublicLimits(_PdfStructuralAdapterModel):
    """The seven public values that apply to non-rendering structural work."""

    max_file_bytes: int = Field(gt=0)
    max_pages: int = Field(gt=0)
    max_page_width_points: float = Field(gt=0)
    max_page_height_points: float = Field(gt=0)
    max_page_area_points: float = Field(gt=0)
    max_native_text_pages: int = Field(gt=0)
    max_native_text_characters: int = Field(gt=0)


class PdfStructuralAdapterEffectiveLimits(_PdfStructuralAdapterModel):
    """Monotone private limits plus their deterministic digest."""

    schema_version: Literal["pdf_structural_adapter_effective_limits.v1"] = (
        PDF_STRUCTURAL_ADAPTER_EFFECTIVE_LIMITS_SCHEMA_VERSION
    )
    applicable_public: PdfStructuralAdapterApplicablePublicLimits
    public_limit_mapping: tuple[
        tuple[str, PdfStructuralAdapterPublicLimitClassification], ...
    ] = PDF_STRUCTURAL_ADAPTER_PUBLIC_LIMIT_MAPPING
    extraction: PdfExtractionLimits
    layout: PdfLayoutGraphLimits
    digest: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_digest(self) -> Self:
        """Reject an effective-limit envelope with a noncanonical digest."""
        expected = canonical_payload_sha256(
            {
                "schema_version": self.schema_version,
                "applicable_public": self.applicable_public.model_dump(mode="json"),
                "public_limit_mapping": self.public_limit_mapping,
                "extraction": self.extraction.model_dump(mode="json"),
                "layout": self.layout.model_dump(mode="json"),
            }
        )
        if self.digest != expected:
            raise ValueError("effective limit digest is inconsistent")
        if self.public_limit_mapping != PDF_STRUCTURAL_ADAPTER_PUBLIC_LIMIT_MAPPING:
            raise ValueError("public limit mapping is inconsistent")
        return self


class PdfStructuralAdapterMetrics(_PdfStructuralAdapterModel):
    """Deterministic count metrics projected from retained typed artifacts."""

    parser_execution_count: int = Field(default=0, ge=0, le=1)
    source_page_count: int = Field(default=0, ge=0)
    requested_page_count: int = Field(default=0, ge=0)
    fact_source_page_count: int = Field(default=0, ge=0)
    fact_pages_attempted: int = Field(default=0, ge=0)
    fact_pages_extracted: int = Field(default=0, ge=0)
    total_fact_count: int = Field(default=0, ge=0)
    fact_warning_count: int = Field(default=0, ge=0)
    fact_suppressed_warning_count: int = Field(default=0, ge=0)
    layout_pages_attempted: int = Field(default=0, ge=0)
    layout_pages_built: int = Field(default=0, ge=0)
    total_node_count: int = Field(default=0, ge=0)
    total_edge_count: int = Field(default=0, ge=0)
    total_separator_candidate_count: int = Field(default=0, ge=0)
    total_candidate_pair_count: int = Field(default=0, ge=0)
    layout_warning_count: int = Field(default=0, ge=0)
    layout_suppressed_warning_count: int = Field(default=0, ge=0)
    ready_page_count: int = Field(default=0, ge=0)
    limited_page_count: int = Field(default=0, ge=0)
    not_ready_page_count: int = Field(default=0, ge=0)
    total_elapsed_milliseconds: float = Field(
        default=0,
        ge=0,
        repr=False,
        exclude=True,
    )
    fact_elapsed_milliseconds: float = Field(
        default=0,
        ge=0,
        repr=False,
        exclude=True,
    )
    layout_elapsed_milliseconds: float = Field(
        default=0,
        ge=0,
        repr=False,
        exclude=True,
    )


class PdfStructuralAdapterRuntimeLimitations(_PdfStructuralAdapterModel):
    """Explicit limitations of this private, in-process, unwired stage."""

    private: Literal[True] = True
    explicit: Literal[True] = True
    in_process: Literal[True] = True
    unwired: Literal[True] = True
    safe_runtime_used: Literal[False] = False
    hard_subprocess_timeout_enabled: Literal[False] = False
    rss_cpu_fd_hard_enforcement_enabled: Literal[False] = False
    fallback_executed: Literal[False] = False
    default_untrusted_backend_eligible: Literal[False] = False


class PdfStructuralAdapterEvidence(_PdfStructuralAdapterModel):
    """Content-free deterministic evidence for one Adapter result."""

    schema_version: Literal["pdf_structural_adapter_evidence.v1"] = (
        PDF_STRUCTURAL_ADAPTER_EVIDENCE_SCHEMA_VERSION
    )
    outcome: PdfStructuralAdapterOutcome
    error_category: PdfStructuralAdapterErrorCategory
    error_stage: PdfStructuralAdapterErrorStage
    limit_name: PdfStructuralAdapterLimitName | None = None
    fallback_executed: Literal[False] = False
    request_authority_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    source_fingerprint: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )
    effective_limit_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    route_initial_parser: PdfLayoutRoutableParser | None = None
    route_fallback_parser: PdfLayoutRoutableParser | None = None
    selected_parser: PdfLayoutRoutableParser | None = None
    fact_status: PdfExtractionStatus | None = None
    fact_artifact_digest: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )
    layout_graph_id: str | None = Field(
        default=None,
        pattern=r"^PDFLG-[0-9a-f]{24}$",
    )
    layout_graph_digest: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )
    layout_status: PdfExtractionStatus | None = None
    readiness_outcome: PdfLayoutConsumerReadinessOutcome | None = None
    readiness_limitation_codes: tuple[PdfLayoutConsumerLimitationCode, ...] = ()
    fact_page_numbers: tuple[int, ...] = ()
    layout_page_numbers: tuple[int, ...] = ()
    fact_warning_codes: tuple[PdfWarningCode, ...] = ()
    layout_warning_codes: tuple[PdfWarningCode, ...] = ()
    deterministic_evidence_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_evidence(self) -> Self:
        """Bind route fields and the canonical evidence digest."""
        route_fields = (
            self.route_initial_parser,
            self.route_fallback_parser,
            self.selected_parser,
        )
        if any(item is None for item in route_fields) != all(
            item is None for item in route_fields
        ):
            raise ValueError("evidence route fields must be present together")
        if (
            self.selected_parser is not None
            and self.selected_parser != self.route_initial_parser
        ):
            raise ValueError("selected parser must equal the initial route")
        if (self.layout_graph_id is None) != (self.layout_graph_digest is None):
            raise ValueError("layout identifiers must be present together")
        if self.layout_graph_id is not None and self.fact_artifact_digest is None:
            raise ValueError("layout evidence requires a Fact digest")
        if (self.fact_artifact_digest is None) != (self.fact_status is None):
            raise ValueError("Fact status must match Fact digest evidence")
        if (self.layout_graph_id is None) != (self.layout_status is None):
            raise ValueError("Layout status must match Layout evidence")
        if (self.layout_graph_id is None) != (self.readiness_outcome is None):
            raise ValueError("readiness outcome must match Layout evidence")
        if self.readiness_outcome is None and self.readiness_limitation_codes:
            raise ValueError("readiness limitations require readiness evidence")
        inventories = (self.fact_page_numbers, self.layout_page_numbers)
        if any(items != tuple(sorted(set(items))) for items in inventories):
            raise ValueError("evidence page inventories must be sorted and unique")
        payload = self.model_dump(
            mode="json",
            exclude={"deterministic_evidence_sha256"},
        )
        expected = canonical_payload_sha256(payload)
        if self.deterministic_evidence_sha256 != expected:
            raise ValueError("deterministic evidence digest is inconsistent")
        return self


class PdfStructuralAdapterResult(_PdfStructuralAdapterModel):
    """Safe private result for exactly one initial-parser execution."""

    schema_version: Literal["pdf_structural_adapter.v1"] = (
        PDF_STRUCTURAL_ADAPTER_SCHEMA_VERSION
    )
    outcome: PdfStructuralAdapterOutcome
    source: PdfStructuralAdapterSourceMetadata | None = None
    route_plan: PdfLayoutParserRoutePlan | None = None
    selected_parser: PdfLayoutRoutableParser | None = None
    fallback_executed: Literal[False] = False
    fact_status: PdfExtractionStatus | None = None
    layout_status: PdfExtractionStatus | None = None
    fact_artifact: PdfFactArtifact | None = Field(
        default=None,
        repr=False,
        exclude=True,
    )
    layout_artifact: PdfLayoutGraphArtifact | None = Field(
        default=None,
        repr=False,
        exclude=True,
    )
    consumer_readiness: PdfLayoutGraphConsumerReadiness | None = None
    effective_limits: PdfStructuralAdapterEffectiveLimits
    metrics: PdfStructuralAdapterMetrics
    evidence: PdfStructuralAdapterEvidence
    limitations: PdfStructuralAdapterRuntimeLimitations = Field(
        default_factory=PdfStructuralAdapterRuntimeLimitations
    )
    error_category: PdfStructuralAdapterErrorCategory = "none"
    error_stage: PdfStructuralAdapterErrorStage = "none"
    limit_name: PdfStructuralAdapterLimitName | None = None

    @model_validator(mode="after")
    def validate_result(self) -> Self:
        """Cross-bind safe projections without serializing payload artifacts."""
        if (self.route_plan is None) != (self.selected_parser is None):
            raise ValueError("route and selected parser must be present together")
        if self.route_plan is not None:
            if self.selected_parser != self.route_plan.initial_parser:
                raise ValueError("selected parser must equal the initial route")
            if (
                self.evidence.route_initial_parser != self.route_plan.initial_parser
                or self.evidence.route_fallback_parser
                != self.route_plan.fallback_parser
                or self.evidence.selected_parser != self.selected_parser
            ):
                raise ValueError("route evidence is inconsistent")
        elif any(
            item is not None
            for item in (
                self.evidence.route_initial_parser,
                self.evidence.route_fallback_parser,
                self.evidence.selected_parser,
            )
        ):
            raise ValueError("route evidence requires a route")
        if self.source is None:
            if self.evidence.source_fingerprint is not None:
                raise ValueError("source evidence requires source metadata")
            if not (
                self.outcome == "failed"
                and self.error_category == "invalid_request"
                and self.error_stage == "request_binding"
                and self.route_plan is None
                and self.fact_artifact is None
                and self.layout_artifact is None
                and self.metrics.parser_execution_count == 0
            ):
                raise ValueError("source may be absent only for a non-bytes failure")
        elif self.evidence.source_fingerprint != self.source.fingerprint:
            raise ValueError("source evidence is inconsistent")
        if self.effective_limits.digest != self.evidence.effective_limit_digest:
            raise ValueError("effective-limit evidence is inconsistent")
        if (
            self.outcome != self.evidence.outcome
            or self.error_category != self.evidence.error_category
            or self.error_stage != self.evidence.error_stage
            or self.limit_name != self.evidence.limit_name
            or self.fallback_executed != self.evidence.fallback_executed
        ):
            raise ValueError("outcome evidence is inconsistent")
        if (self.fact_artifact is None) != (self.fact_status is None):
            raise ValueError("Fact status must match Fact artifact presence")
        if self.fact_artifact is not None:
            if self.fact_status is not self.fact_artifact.extraction_status:
                raise ValueError("Fact status is inconsistent")
            if self.evidence.fact_status is not self.fact_status:
                raise ValueError("Fact status evidence is inconsistent")
            if self.evidence.fact_artifact_digest != source_fact_artifact_digest(
                self.fact_artifact
            ):
                raise ValueError("Fact digest evidence is inconsistent")
            fact_page_numbers = tuple(
                page.page_number for page in self.fact_artifact.pages
            )
            fact_warning_codes = _fact_warning_code_inventory(self.fact_artifact)
            if (
                self.evidence.fact_page_numbers != fact_page_numbers
                or self.evidence.fact_warning_codes != fact_warning_codes
            ):
                raise ValueError("Fact inventory evidence is inconsistent")
            if self.source is not None and (
                self.fact_artifact.source_sha256 != self.source.fingerprint
                or self.fact_artifact.document_id != self.source.file_id
                or self.fact_artifact.resource_usage.source_size_bytes
                != self.source.source_size_bytes
            ):
                raise ValueError("Fact source metadata is inconsistent")
            if (
                self.selected_parser is not None
                and self.fact_artifact.parser_name != self.selected_parser
            ):
                raise ValueError("Fact parser is inconsistent")
            fact_metrics = (
                self.metrics.fact_source_page_count,
                self.metrics.fact_pages_attempted,
                self.metrics.fact_pages_extracted,
                self.metrics.total_fact_count,
                self.metrics.fact_warning_count,
                self.metrics.fact_suppressed_warning_count,
            )
            expected_fact_metrics = (
                self.fact_artifact.page_count,
                self.fact_artifact.resource_usage.pages_attempted,
                self.fact_artifact.extracted_page_count,
                self.fact_artifact.resource_usage.total_facts,
                len(fact_warning_codes),
                self.fact_artifact.warning_suppression.suppressed_warning_count,
            )
            if fact_metrics != expected_fact_metrics:
                raise ValueError("Fact metrics are inconsistent")
            if self.metrics.parser_execution_count != 1:
                raise ValueError("retained Fact requires one parser execution")
        elif self.evidence.fact_artifact_digest is not None:
            raise ValueError("Fact digest requires a Fact artifact")
        elif self.evidence.fact_page_numbers or self.evidence.fact_warning_codes:
            raise ValueError("Fact inventories require a Fact artifact")
        elif any(
            (
                self.metrics.fact_source_page_count,
                self.metrics.fact_pages_attempted,
                self.metrics.fact_pages_extracted,
                self.metrics.total_fact_count,
                self.metrics.fact_warning_count,
                self.metrics.fact_suppressed_warning_count,
            )
        ):
            raise ValueError("Fact metrics require a Fact artifact")
        if (self.layout_artifact is None) != (self.layout_status is None):
            raise ValueError("Layout status must match Layout artifact presence")
        if (self.layout_artifact is None) != (self.consumer_readiness is None):
            raise ValueError("Layout artifact and readiness must be present together")
        if self.layout_artifact is not None:
            if self.layout_status is not self.layout_artifact.build_status:
                raise ValueError("Layout status is inconsistent")
            if self.evidence.layout_status is not self.layout_status:
                raise ValueError("Layout status evidence is inconsistent")
            if (
                self.evidence.layout_graph_id != self.layout_artifact.layout_graph_id
                or self.evidence.layout_graph_digest
                != self.layout_artifact.graph_digest
            ):
                raise ValueError("Layout evidence is inconsistent")
            if (
                self.consumer_readiness is None
                or self.evidence.readiness_outcome != self.consumer_readiness.outcome
                or self.evidence.readiness_limitation_codes
                != self.consumer_readiness.limitation_codes
            ):
                raise ValueError("readiness evidence is inconsistent")
            layout_page_numbers = tuple(
                page.page_number for page in self.layout_artifact.pages
            )
            layout_warning_codes = _layout_warning_code_inventory(self.layout_artifact)
            if (
                self.evidence.layout_page_numbers != layout_page_numbers
                or self.evidence.layout_warning_codes != layout_warning_codes
            ):
                raise ValueError("Layout inventory evidence is inconsistent")
            if self.fact_artifact is None or (
                self.layout_artifact.source_document_id
                != self.fact_artifact.document_id
                or self.layout_artifact.source_parser_name
                != self.fact_artifact.parser_name
                or self.layout_artifact.source_parser_version
                != self.fact_artifact.parser_version
                or self.layout_artifact.source_fact_artifact_sha256
                != source_fact_artifact_digest(self.fact_artifact)
                or self.layout_artifact.source_page_count
                != self.fact_artifact.page_count
                or self.layout_artifact.source_extracted_page_count
                != self.fact_artifact.extracted_page_count
            ):
                raise ValueError("Layout source Fact binding is inconsistent")
            layout_metrics = (
                self.metrics.layout_pages_attempted,
                self.metrics.layout_pages_built,
                self.metrics.total_node_count,
                self.metrics.total_edge_count,
                self.metrics.total_separator_candidate_count,
                self.metrics.total_candidate_pair_count,
                self.metrics.layout_warning_count,
                self.metrics.layout_suppressed_warning_count,
            )
            expected_layout_metrics = (
                self.layout_artifact.resource_usage.pages_attempted,
                self.layout_artifact.graph_page_count,
                self.layout_artifact.total_node_count,
                self.layout_artifact.total_edge_count,
                self.layout_artifact.total_separator_candidate_count,
                self.layout_artifact.resource_usage.total_candidate_pairs,
                len(layout_warning_codes),
                self.layout_artifact.warning_suppression.suppressed_warning_count,
            )
            if layout_metrics != expected_layout_metrics:
                raise ValueError("Layout metrics are inconsistent")
            readiness_metrics = (
                self.metrics.ready_page_count,
                self.metrics.limited_page_count,
                self.metrics.not_ready_page_count,
            )
            expected_readiness_metrics = (
                self.consumer_readiness.ready_page_count,
                self.consumer_readiness.limited_page_count,
                self.consumer_readiness.not_ready_page_count,
            )
            if readiness_metrics != expected_readiness_metrics:
                raise ValueError("readiness metrics are inconsistent")
            if (
                tuple(page.page_number for page in self.consumer_readiness.pages)
                != layout_page_numbers
            ):
                raise ValueError("readiness page inventory is inconsistent")
        elif any(
            item is not None
            for item in (
                self.evidence.layout_graph_id,
                self.evidence.layout_graph_digest,
            )
        ):
            raise ValueError("Layout evidence requires a Layout artifact")
        elif self.evidence.layout_page_numbers or self.evidence.layout_warning_codes:
            raise ValueError("Layout inventories require a Layout artifact")
        elif any(
            (
                self.metrics.layout_pages_attempted,
                self.metrics.layout_pages_built,
                self.metrics.total_node_count,
                self.metrics.total_edge_count,
                self.metrics.total_separator_candidate_count,
                self.metrics.total_candidate_pair_count,
                self.metrics.layout_warning_count,
                self.metrics.layout_suppressed_warning_count,
                self.metrics.ready_page_count,
                self.metrics.limited_page_count,
                self.metrics.not_ready_page_count,
            )
        ):
            raise ValueError("Layout/readiness metrics require a Layout artifact")
        if self.outcome == "completed":
            if any(
                item is None
                for item in (
                    self.source,
                    self.route_plan,
                    self.fact_artifact,
                    self.layout_artifact,
                    self.consumer_readiness,
                )
            ):
                raise ValueError("completed result requires the full artifact chain")
            if self.error_category != "none" or self.error_stage != "none":
                raise ValueError("completed result cannot carry an Adapter error")
            if self.metrics.parser_execution_count != 1:
                raise ValueError("completed result requires one parser execution")
            if (
                self.fact_status not in _BUILDABLE_FACT_STATUSES
                or self.layout_status not in _BUILDABLE_LAYOUT_STATUSES
            ):
                raise ValueError(
                    "completed result requires buildable artifact statuses"
                )
            if self.fact_artifact is not None and (
                self.metrics.source_page_count != self.fact_artifact.page_count
                or self.metrics.requested_page_count
                != self.fact_artifact.extraction_scope_result.requested_page_count
            ):
                raise ValueError("completed source metrics are inconsistent")
        elif self.error_category == "none" or self.error_stage == "none":
            raise ValueError("failed result requires a fixed Adapter error")
        if (
            self.outcome == "failed"
            and self.error_stage == "fact_extraction"
            and self.fact_status is not None
            and _TERMINAL_FACT_CATEGORIES.get(self.fact_status) != self.error_category
        ):
            raise ValueError("terminal Fact status is inconsistent with the error")
        if self.outcome == "failed" and self.layout_artifact is not None:
            raise ValueError("failed result cannot retain Layout or readiness")
        if self.limit_name is not None and self.error_category != "resource_limit":
            raise ValueError("limit name is valid only for resource-limit failures")
        if self.fallback_executed or self.limitations.fallback_executed:
            raise ValueError("FP4 cannot execute fallback")
        return self


__all__ = [
    "PDF_STRUCTURAL_ADAPTER_EFFECTIVE_LIMITS_SCHEMA_VERSION",
    "PDF_STRUCTURAL_ADAPTER_EVIDENCE_SCHEMA_VERSION",
    "PDF_STRUCTURAL_ADAPTER_PUBLIC_LIMIT_MAPPING",
    "PDF_STRUCTURAL_ADAPTER_SCHEMA_VERSION",
    "PdfStructuralAdapterApplicablePublicLimits",
    "PdfStructuralAdapterEffectiveLimits",
    "PdfStructuralAdapterErrorCategory",
    "PdfStructuralAdapterErrorStage",
    "PdfStructuralAdapterEvidence",
    "PdfStructuralAdapterLimitName",
    "PdfStructuralAdapterMetrics",
    "PdfStructuralAdapterOutcome",
    "PdfStructuralAdapterPublicLimitClassification",
    "PdfStructuralAdapterRequest",
    "PdfStructuralAdapterResult",
    "PdfStructuralAdapterRuntimeLimitations",
    "PdfStructuralAdapterSourceMetadata",
]

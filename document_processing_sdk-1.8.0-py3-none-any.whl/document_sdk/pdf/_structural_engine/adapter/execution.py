"""Private execution entry point for the unwired PDF structural thin adapter."""

# ruff: noqa: BLE001, C901, EM101, I001, PLR0911, PLR0912, PLR0913, TC001, TRY003

from __future__ import annotations

from time import perf_counter
from typing import NoReturn

from document_sdk.pdf._structural_engine.adapter.contracts import (
    PDF_STRUCTURAL_ADAPTER_EVIDENCE_SCHEMA_VERSION,
    PdfStructuralAdapterEffectiveLimits,
    PdfStructuralAdapterErrorCategory,
    PdfStructuralAdapterErrorStage,
    PdfStructuralAdapterEvidence,
    PdfStructuralAdapterLimitName,
    PdfStructuralAdapterMetrics,
    PdfStructuralAdapterOutcome,
    PdfStructuralAdapterRequest,
    PdfStructuralAdapterResult,
    PdfStructuralAdapterSourceMetadata,
)
from document_sdk.pdf._structural_engine.adapter.mapping import (
    PdfStructuralAdapterValidationError,
    derive_pdf_structural_effective_limits,
    derive_pdf_structural_source_metadata,
    validate_pdf_structural_adapter_request,
)
from document_sdk.pdf._structural_engine.facts.contracts import (
    PdfDrawingFact,
    PdfFactArtifact,
    PdfImageRegionFact,
    PdfPageFacts,
    PdfTextFact,
)
from document_sdk.pdf._structural_engine.facts.identifiers import (
    fact_identifier,
    page_identifier,
)
from document_sdk.pdf._structural_engine.facts.limits import (
    PdfExtractionScopeMode,
    PdfSource,
)
from document_sdk.pdf._structural_engine.facts.status import (
    PdfExtractionStatus,
    PdfWarningCode,
)
from document_sdk.pdf._structural_engine.layout.builder import PdfLayoutGraphBuilder
from document_sdk.pdf._structural_engine.layout.consumer import (
    PdfLayoutGraphConsumerReadiness,
    evaluate_layout_graph_consumer_readiness,
)
from document_sdk.pdf._structural_engine.layout.contracts import (
    PdfLayoutGraphArtifact,
)
from document_sdk.pdf._structural_engine.layout.identifiers import (
    canonical_payload_sha256,
    layout_graph_identifier,
    layout_page_identifier,
    layout_settings_digest,
    source_fact_artifact_digest,
)
from document_sdk.pdf._structural_engine.layout.strategy import (
    PdfLayoutParserRoutePlan,
    PdfLayoutRoutableParser,
    route_layout_parser,
)
from document_sdk.pdf._structural_engine.parsers import (
    create_pdf_fact_extractor,
    pdf_fact_parser_available,
)


_ALLOWED_PARSERS = frozenset({"pdfplumber", "pypdfium2"})
_OPEN_FAILURE_STATUSES = frozenset(
    {
        PdfExtractionStatus.ENCRYPTED,
        PdfExtractionStatus.MALFORMED,
        PdfExtractionStatus.PARSER_ERROR,
        PdfExtractionStatus.INTERNAL_ERROR,
        PdfExtractionStatus.UNSUPPORTED,
    }
)
_TERMINAL_WARNING_CODES = {
    PdfExtractionStatus.ENCRYPTED: frozenset({PdfWarningCode.ENCRYPTED_DOCUMENT}),
    PdfExtractionStatus.INTERNAL_ERROR: frozenset({PdfWarningCode.PARSER_EXCEPTION}),
    PdfExtractionStatus.INVALID_REQUEST: frozenset(
        {PdfWarningCode.INVALID_EXTRACTION_SCOPE}
    ),
    PdfExtractionStatus.MALFORMED: frozenset({PdfWarningCode.MALFORMED_DOCUMENT}),
    PdfExtractionStatus.PARSER_ERROR: frozenset({PdfWarningCode.PARSER_EXCEPTION}),
    PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED: frozenset(
        {PdfWarningCode.FILE_SIZE_LIMIT_REACHED}
    ),
    PdfExtractionStatus.UNSUPPORTED: frozenset(
        {
            PdfWarningCode.PARSER_CAPABILITY_UNAVAILABLE,
            PdfWarningCode.UNSUPPORTED_SOURCE,
        }
    ),
}
_RESOURCE_SCOPE_WARNING_CODES = frozenset(
    {
        PdfWarningCode.ARTIFACT_SIZE_LIMIT_REACHED,
        PdfWarningCode.EXTRACTION_TIMEOUT,
        PdfWarningCode.PAGE_LIMIT_REACHED,
        PdfWarningCode.PARTIAL_PAGE_FAILURE,
        PdfWarningCode.SELECTED_PAGE_LIMIT_REACHED,
        PdfWarningCode.TOTAL_FACT_LIMIT_REACHED,
    }
)


class _PdfStructuralAdapterExecutionError(ValueError):
    """Fixed internal execution stop that never accepts backend text."""

    def __init__(
        self,
        *,
        category: PdfStructuralAdapterErrorCategory,
        stage: PdfStructuralAdapterErrorStage,
        limit_name: PdfStructuralAdapterLimitName | None = None,
    ) -> None:
        super().__init__(category)
        self.category = category
        self.stage = stage
        self.limit_name = limit_name


def run_pdf_structural_adapter(
    content: bytes,
    *,
    request: PdfStructuralAdapterRequest,
) -> PdfStructuralAdapterResult:
    """Execute one explicit initial-parser Fact, Layout, and readiness chain."""
    started_at = perf_counter()
    effective_limits = derive_pdf_structural_effective_limits(request)
    request_authority_digest = _request_authority_digest(request)

    if type(content) is not bytes:
        return _result(
            request=request,
            request_authority_digest=request_authority_digest,
            effective_limits=effective_limits,
            started_at=started_at,
            outcome="failed",
            category="invalid_request",
            stage="request_binding",
        )

    source = derive_pdf_structural_source_metadata(content)
    try:
        validate_pdf_structural_adapter_request(
            content,
            request=request,
            effective_limits=effective_limits,
        )
    except PdfStructuralAdapterValidationError as error:
        return _result(
            request=request,
            request_authority_digest=request_authority_digest,
            effective_limits=effective_limits,
            started_at=started_at,
            outcome="failed",
            category=error.category,
            stage=error.stage,
            limit_name=error.limit_name,
            source=source,
        )

    try:
        route_plan = route_layout_parser(
            preflight=request.preflight,
            policy=request.policy,
        )
        _validate_route_plan(route_plan)
    except Exception:
        return _result(
            request=request,
            request_authority_digest=request_authority_digest,
            effective_limits=effective_limits,
            started_at=started_at,
            outcome="failed",
            category="internal_failure",
            stage="routing",
            source=source,
        )

    selected_parser = route_plan.initial_parser
    try:
        available = pdf_fact_parser_available(selected_parser)
    except Exception:
        available = False
    if not available:
        return _result(
            request=request,
            request_authority_digest=request_authority_digest,
            effective_limits=effective_limits,
            started_at=started_at,
            outcome="failed",
            category="dependency_unavailable",
            stage="parser_resolution",
            source=source,
            route_plan=route_plan,
            selected_parser=selected_parser,
        )

    try:
        extractor = create_pdf_fact_extractor(selected_parser)
    except (ImportError, RuntimeError):
        return _result(
            request=request,
            request_authority_digest=request_authority_digest,
            effective_limits=effective_limits,
            started_at=started_at,
            outcome="failed",
            category="dependency_unavailable",
            stage="parser_resolution",
            source=source,
            route_plan=route_plan,
            selected_parser=selected_parser,
        )
    except Exception:
        return _result(
            request=request,
            request_authority_digest=request_authority_digest,
            effective_limits=effective_limits,
            started_at=started_at,
            outcome="failed",
            category="internal_failure",
            stage="parser_resolution",
            source=source,
            route_plan=route_plan,
            selected_parser=selected_parser,
        )

    parser_execution_count = 1
    try:
        fact_artifact = extractor.extract(
            PdfSource(content=content),
            limits=effective_limits.extraction,
            options=request.extraction_options,
        )
    except Exception:
        return _result(
            request=request,
            request_authority_digest=request_authority_digest,
            effective_limits=effective_limits,
            started_at=started_at,
            outcome="failed",
            category="parser_failure",
            stage="fact_extraction",
            source=source,
            route_plan=route_plan,
            selected_parser=selected_parser,
            parser_execution_count=parser_execution_count,
        )

    try:
        _validate_fact_artifact(
            fact_artifact,
            request=request,
            source=source,
            effective_limits=effective_limits,
            selected_parser=selected_parser,
            extractor_parser_version=extractor.parser_version,
        )
    except _PdfStructuralAdapterExecutionError as error:
        return _result(
            request=request,
            request_authority_digest=request_authority_digest,
            effective_limits=effective_limits,
            started_at=started_at,
            outcome="failed",
            category=error.category,
            stage=error.stage,
            limit_name=error.limit_name,
            source=source,
            route_plan=route_plan,
            selected_parser=selected_parser,
            parser_execution_count=parser_execution_count,
        )
    except Exception:
        return _result(
            request=request,
            request_authority_digest=request_authority_digest,
            effective_limits=effective_limits,
            started_at=started_at,
            outcome="failed",
            category="internal_failure",
            stage="fact_validation",
            source=source,
            route_plan=route_plan,
            selected_parser=selected_parser,
            parser_execution_count=parser_execution_count,
        )

    terminal_category = _terminal_fact_category(fact_artifact)
    if terminal_category is not None:
        return _result(
            request=request,
            request_authority_digest=request_authority_digest,
            effective_limits=effective_limits,
            started_at=started_at,
            outcome="failed",
            category=terminal_category,
            stage="fact_extraction",
            source=source,
            route_plan=route_plan,
            selected_parser=selected_parser,
            fact_artifact=fact_artifact,
            parser_execution_count=parser_execution_count,
        )

    try:
        builder = PdfLayoutGraphBuilder()
        layout_artifact = builder.build(
            fact_artifact,
            limits=effective_limits.layout,
            options=request.layout_options,
        )
    except Exception:
        return _result(
            request=request,
            request_authority_digest=request_authority_digest,
            effective_limits=effective_limits,
            started_at=started_at,
            outcome="failed",
            category="layout_failure",
            stage="layout_build",
            source=source,
            route_plan=route_plan,
            selected_parser=selected_parser,
            fact_artifact=fact_artifact,
            parser_execution_count=parser_execution_count,
        )

    try:
        _validate_layout_artifact(
            layout_artifact,
            fact_artifact=fact_artifact,
            effective_limits=effective_limits,
            request=request,
            builder=builder,
        )
    except Exception:
        return _result(
            request=request,
            request_authority_digest=request_authority_digest,
            effective_limits=effective_limits,
            started_at=started_at,
            outcome="failed",
            category="layout_failure",
            stage="layout_validation",
            source=source,
            route_plan=route_plan,
            selected_parser=selected_parser,
            fact_artifact=fact_artifact,
            parser_execution_count=parser_execution_count,
        )

    if layout_artifact.build_status is PdfExtractionStatus.INTERNAL_ERROR:
        return _result(
            request=request,
            request_authority_digest=request_authority_digest,
            effective_limits=effective_limits,
            started_at=started_at,
            outcome="failed",
            category="layout_failure",
            stage="layout_build",
            source=source,
            route_plan=route_plan,
            selected_parser=selected_parser,
            fact_artifact=fact_artifact,
            parser_execution_count=parser_execution_count,
        )

    try:
        readiness = evaluate_layout_graph_consumer_readiness(layout_artifact)
        _validate_readiness(readiness, layout_artifact=layout_artifact)
    except Exception:
        return _result(
            request=request,
            request_authority_digest=request_authority_digest,
            effective_limits=effective_limits,
            started_at=started_at,
            outcome="failed",
            category="internal_failure",
            stage="consumer_readiness",
            source=source,
            route_plan=route_plan,
            selected_parser=selected_parser,
            fact_artifact=fact_artifact,
            parser_execution_count=parser_execution_count,
        )

    return _result(
        request=request,
        request_authority_digest=request_authority_digest,
        effective_limits=effective_limits,
        started_at=started_at,
        outcome="completed",
        category="none",
        stage="none",
        source=source,
        route_plan=route_plan,
        selected_parser=selected_parser,
        fact_artifact=fact_artifact,
        layout_artifact=layout_artifact,
        readiness=readiness,
        parser_execution_count=parser_execution_count,
    )


def _validate_route_plan(route_plan: PdfLayoutParserRoutePlan) -> None:
    if (
        route_plan.initial_parser not in _ALLOWED_PARSERS
        or route_plan.fallback_parser not in _ALLOWED_PARSERS
        or route_plan.initial_parser == route_plan.fallback_parser
    ):
        raise ValueError("route plan is outside the fixed Adapter allowlist")


def _validate_fact_artifact(
    artifact: PdfFactArtifact,
    *,
    request: PdfStructuralAdapterRequest,
    source: PdfStructuralAdapterSourceMetadata,
    effective_limits: PdfStructuralAdapterEffectiveLimits,
    selected_parser: PdfLayoutRoutableParser,
    extractor_parser_version: str,
) -> None:
    if (
        artifact.source_sha256 != source.fingerprint
        or artifact.document_id != source.file_id
        or artifact.resource_usage.source_size_bytes != source.source_size_bytes
    ):
        _execution_fail(
            category="source_identity_mismatch",
            stage="fact_validation",
        )
    if (
        artifact.parser_name != selected_parser
        or artifact.parser_version != extractor_parser_version
        or artifact.applied_resource_limits != effective_limits.extraction
        or artifact.extraction_options != request.extraction_options
    ):
        _execution_fail(category="parser_failure", stage="fact_validation")

    page_numbers = tuple(page.page_number for page in artifact.pages)
    if page_numbers != tuple(sorted(set(page_numbers))):
        _execution_fail(category="parser_failure", stage="fact_validation")
    scope_result = artifact.extraction_scope_result
    terminal_open_failure = artifact.extraction_status in _OPEN_FAILURE_STATUSES or (
        artifact.extraction_status
        in {
            PdfExtractionStatus.INVALID_REQUEST,
            PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED,
        }
        and not scope_result.scope_evaluation_available
    )
    if (
        artifact.extraction_status is PdfExtractionStatus.ENCRYPTED
    ) != request.inspection.encrypted:
        _execution_fail(category="parser_failure", stage="fact_validation")
    if terminal_open_failure:
        warning_codes = frozenset(warning.code for warning in artifact.warnings)
        expected_warning_codes = _TERMINAL_WARNING_CODES.get(
            artifact.extraction_status,
            frozenset(),
        )
        if (
            artifact.page_count != 0
            or artifact.pages
            or artifact.extracted_page_count != 0
            or artifact.resource_usage.pages_attempted != 0
            or artifact.resource_usage.pages_extracted != 0
            or artifact.extraction_scope_result.scope_evaluation_available
            or artifact.partial_extraction
            is not (
                artifact.extraction_status
                is PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED
            )
            or not warning_codes.intersection(expected_warning_codes)
        ):
            _execution_fail(category="parser_failure", stage="fact_validation")
    elif artifact.page_count != request.inspection.page_count:
        _execution_fail(
            category="source_identity_mismatch",
            stage="fact_validation",
        )
    if (
        artifact.extraction_status is PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED
        and scope_result.scope_evaluation_available
        and (
            not scope_result.scope_truncated
            or not frozenset(scope_result.scope_warning_codes).intersection(
                _RESOURCE_SCOPE_WARNING_CODES
            )
        )
    ):
        _execution_fail(category="parser_failure", stage="fact_validation")

    scope = request.extraction_options.extraction_scope
    if scope_result.mode is not scope.mode:
        _execution_fail(category="parser_failure", stage="fact_validation")
    if scope.mode is PdfExtractionScopeMode.SELECTED_PAGES:
        expected_requested = scope.requested_page_numbers
        expected_requested_count = len(expected_requested)
    else:
        expected_requested = ()
        expected_requested_count = 0 if terminal_open_failure else artifact.page_count
    if (
        scope_result.requested_page_numbers != expected_requested
        or scope_result.requested_page_count != expected_requested_count
        or scope_result.extracted_requested_page_numbers != page_numbers
        or scope_result.extracted_requested_page_count != len(page_numbers)
    ):
        _execution_fail(category="parser_failure", stage="fact_validation")

    requested_inventory = (
        set(scope.requested_page_numbers)
        if scope.mode is PdfExtractionScopeMode.SELECTED_PAGES
        else set(range(1, request.inspection.page_count + 1))
    )
    if not set(page_numbers) <= requested_inventory:
        _execution_fail(category="parser_failure", stage="fact_validation")
    if artifact.extraction_status in {
        PdfExtractionStatus.SUCCESS,
        PdfExtractionStatus.NO_TEXT_LAYER,
    } and page_numbers != tuple(sorted(requested_inventory)):
        _execution_fail(category="parser_failure", stage="fact_validation")

    for page in artifact.pages:
        expected_page_id = page_identifier(
            source_hash=source.fingerprint,
            parser_name=artifact.parser_name,
            parser_version=artifact.parser_version,
            page_number=page.page_number,
        )
        if page.page_id != expected_page_id:
            _execution_fail(category="parser_failure", stage="fact_validation")
        _validate_fact_ids(page, artifact=artifact, source=source)

    if (
        artifact.resource_usage.pages_extracted != artifact.extracted_page_count
        or artifact.resource_usage.pages_attempted < artifact.extracted_page_count
        or artifact.resource_usage.total_facts != _total_fact_count(artifact)
    ):
        _execution_fail(category="parser_failure", stage="fact_validation")


def _validate_fact_ids(
    page: PdfPageFacts,
    *,
    artifact: PdfFactArtifact,
    source: PdfStructuralAdapterSourceMetadata,
) -> None:
    for facts in (
        page.text_spans,
        page.words,
        page.line_candidates,
        page.characters,
    ):
        for text_fact in facts:
            _validate_fact_id(
                text_fact,
                fact_type=text_fact.granularity,
                text=text_fact.text,
                page=page,
                artifact=artifact,
                source=source,
            )
    for drawing_fact in page.drawings:
        _validate_fact_id(
            drawing_fact,
            fact_type=drawing_fact.kind,
            text=None,
            page=page,
            artifact=artifact,
            source=source,
        )
    for image_fact in page.image_regions:
        _validate_fact_id(
            image_fact,
            fact_type="image_region",
            text=None,
            page=page,
            artifact=artifact,
            source=source,
        )


def _validate_fact_id(
    fact: PdfTextFact | PdfDrawingFact | PdfImageRegionFact,
    *,
    fact_type: str,
    text: str | None,
    page: PdfPageFacts,
    artifact: PdfFactArtifact,
    source: PdfStructuralAdapterSourceMetadata,
) -> None:
    expected = fact_identifier(
        source_hash=source.fingerprint,
        parser_name=artifact.parser_name,
        parser_version=artifact.parser_version,
        page_number=page.page_number,
        fact_type=fact_type,
        source_order=fact.source_order,
        bbox=fact.bbox,
        text=text,
    )
    if fact.fact_id != expected:
        _execution_fail(category="parser_failure", stage="fact_validation")


def _terminal_fact_category(
    artifact: PdfFactArtifact,
) -> PdfStructuralAdapterErrorCategory | None:
    status = artifact.extraction_status
    if status in {PdfExtractionStatus.SUCCESS, PdfExtractionStatus.NO_TEXT_LAYER}:
        return None
    if status is PdfExtractionStatus.PARTIAL:
        return None if artifact.pages else "parser_failure"
    if status is PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED:
        return (
            None
            if artifact.extraction_scope_result.scope_evaluation_available
            else "resource_limit"
        )
    if status is PdfExtractionStatus.ENCRYPTED:
        return "encrypted"
    if status is PdfExtractionStatus.MALFORMED:
        return "malformed"
    if status is PdfExtractionStatus.INVALID_REQUEST:
        return "invalid_request"
    if status in {PdfExtractionStatus.UNSUPPORTED, PdfExtractionStatus.PARSER_ERROR}:
        return "parser_failure"
    return "internal_failure"


def _validate_layout_artifact(
    artifact: PdfLayoutGraphArtifact,
    *,
    fact_artifact: PdfFactArtifact,
    effective_limits: PdfStructuralAdapterEffectiveLimits,
    request: PdfStructuralAdapterRequest,
    builder: PdfLayoutGraphBuilder,
) -> None:
    fact_digest = source_fact_artifact_digest(fact_artifact)
    settings_digest = layout_settings_digest(
        limits=effective_limits.layout,
        options=request.layout_options,
    )
    expected_graph_id = layout_graph_identifier(
        source_fact_digest=fact_digest,
        builder_name=builder.builder_name,
        builder_version=builder.builder_version,
        settings_digest=settings_digest,
    )
    if (
        artifact.source_fact_schema_version != fact_artifact.schema_version
        or artifact.source_document_id != fact_artifact.document_id
        or artifact.source_fact_artifact_sha256 != fact_digest
        or artifact.source_parser_name != fact_artifact.parser_name
        or artifact.source_parser_version != fact_artifact.parser_version
        or artifact.graph_builder_name != builder.builder_name
        or artifact.graph_builder_version != builder.builder_version
        or artifact.layout_graph_id != expected_graph_id
        or artifact.source_page_count != fact_artifact.page_count
        or artifact.source_extracted_page_count != fact_artifact.extracted_page_count
        or artifact.applied_limits != effective_limits.layout
        or artifact.build_options != request.layout_options
    ):
        raise ValueError("Layout source binding is inconsistent")
    expected_source_partial = (
        fact_artifact.partial_extraction
        or not fact_artifact.extraction_scope_result.source_document_fully_extracted
    )
    if artifact.source_document_partial_extraction != expected_source_partial:
        raise ValueError("Layout source partial state is inconsistent")

    fact_pages = {page.page_number: page for page in fact_artifact.pages}
    layout_page_numbers = tuple(page.page_number for page in artifact.pages)
    if layout_page_numbers != tuple(sorted(set(layout_page_numbers))) or not set(
        layout_page_numbers
    ) <= set(fact_pages):
        raise ValueError("Layout page inventory is inconsistent")
    if (
        artifact.build_status is PdfExtractionStatus.SUCCESS
        and layout_page_numbers != tuple(fact_pages)
    ):
        raise ValueError("successful Layout must retain every Fact page")

    for layout_page in artifact.pages:
        fact_page = fact_pages[layout_page.page_number]
        if (
            layout_page.source_page_id != fact_page.page_id
            or layout_page.page_graph_id
            != layout_page_identifier(
                layout_graph_id=artifact.layout_graph_id,
                source_page_id=fact_page.page_id,
            )
        ):
            raise ValueError("Layout page ownership is inconsistent")
        fact_ids = _page_fact_ids(fact_page)
        if any(node.source_fact_id not in fact_ids for node in layout_page.nodes):
            raise ValueError("Layout node does not belong to its Fact page")


def _validate_readiness(
    readiness: PdfLayoutGraphConsumerReadiness,
    *,
    layout_artifact: PdfLayoutGraphArtifact,
) -> None:
    expected_pages = tuple(page.page_number for page in layout_artifact.pages)
    if tuple(page.page_number for page in readiness.pages) != expected_pages:
        raise ValueError("readiness page inventory is inconsistent")
    if (
        readiness.ready_page_count
        + readiness.limited_page_count
        + readiness.not_ready_page_count
        != layout_artifact.graph_page_count
    ):
        raise ValueError("readiness aggregate count is inconsistent")


def _result(
    *,
    request: PdfStructuralAdapterRequest,
    request_authority_digest: str,
    effective_limits: PdfStructuralAdapterEffectiveLimits,
    started_at: float,
    outcome: PdfStructuralAdapterOutcome,
    category: PdfStructuralAdapterErrorCategory,
    stage: PdfStructuralAdapterErrorStage,
    source: PdfStructuralAdapterSourceMetadata | None = None,
    route_plan: PdfLayoutParserRoutePlan | None = None,
    selected_parser: PdfLayoutRoutableParser | None = None,
    fact_artifact: PdfFactArtifact | None = None,
    layout_artifact: PdfLayoutGraphArtifact | None = None,
    readiness: PdfLayoutGraphConsumerReadiness | None = None,
    parser_execution_count: int = 0,
    limit_name: PdfStructuralAdapterLimitName | None = None,
) -> PdfStructuralAdapterResult:
    metrics = _metrics(
        request=request,
        started_at=started_at,
        fact_artifact=fact_artifact,
        layout_artifact=layout_artifact,
        readiness=readiness,
        parser_execution_count=parser_execution_count,
    )
    evidence = _evidence(
        request_authority_digest=request_authority_digest,
        effective_limits=effective_limits,
        outcome=outcome,
        category=category,
        stage=stage,
        limit_name=limit_name,
        source=source,
        route_plan=route_plan,
        selected_parser=selected_parser,
        fact_artifact=fact_artifact,
        layout_artifact=layout_artifact,
        readiness=readiness,
    )
    return PdfStructuralAdapterResult(
        outcome=outcome,
        source=source,
        route_plan=route_plan,
        selected_parser=selected_parser,
        fact_status=(
            fact_artifact.extraction_status if fact_artifact is not None else None
        ),
        layout_status=(
            layout_artifact.build_status if layout_artifact is not None else None
        ),
        fact_artifact=fact_artifact,
        layout_artifact=layout_artifact,
        consumer_readiness=readiness,
        effective_limits=effective_limits,
        metrics=metrics,
        evidence=evidence,
        error_category=category,
        error_stage=stage,
        limit_name=limit_name,
    )


def _metrics(
    *,
    request: PdfStructuralAdapterRequest,
    started_at: float,
    fact_artifact: PdfFactArtifact | None,
    layout_artifact: PdfLayoutGraphArtifact | None,
    readiness: PdfLayoutGraphConsumerReadiness | None,
    parser_execution_count: int,
) -> PdfStructuralAdapterMetrics:
    scope = request.extraction_options.extraction_scope
    requested_page_count = (
        len(scope.requested_page_numbers)
        if scope.mode is PdfExtractionScopeMode.SELECTED_PAGES
        else request.inspection.page_count
    )
    fact_codes = _fact_warning_codes(fact_artifact) if fact_artifact else ()
    layout_codes = _layout_warning_codes(layout_artifact) if layout_artifact else ()
    return PdfStructuralAdapterMetrics(
        parser_execution_count=parser_execution_count,
        source_page_count=request.inspection.page_count,
        requested_page_count=requested_page_count,
        fact_source_page_count=(fact_artifact.page_count if fact_artifact else 0),
        fact_pages_attempted=(
            fact_artifact.resource_usage.pages_attempted if fact_artifact else 0
        ),
        fact_pages_extracted=(
            fact_artifact.extracted_page_count if fact_artifact else 0
        ),
        total_fact_count=(
            fact_artifact.resource_usage.total_facts if fact_artifact else 0
        ),
        fact_warning_count=len(fact_codes),
        fact_suppressed_warning_count=(
            fact_artifact.warning_suppression.suppressed_warning_count
            if fact_artifact
            else 0
        ),
        layout_pages_attempted=(
            layout_artifact.resource_usage.pages_attempted if layout_artifact else 0
        ),
        layout_pages_built=(layout_artifact.graph_page_count if layout_artifact else 0),
        total_node_count=(layout_artifact.total_node_count if layout_artifact else 0),
        total_edge_count=(layout_artifact.total_edge_count if layout_artifact else 0),
        total_separator_candidate_count=(
            layout_artifact.total_separator_candidate_count if layout_artifact else 0
        ),
        total_candidate_pair_count=(
            layout_artifact.resource_usage.total_candidate_pairs
            if layout_artifact
            else 0
        ),
        layout_warning_count=len(layout_codes),
        layout_suppressed_warning_count=(
            layout_artifact.warning_suppression.suppressed_warning_count
            if layout_artifact
            else 0
        ),
        ready_page_count=readiness.ready_page_count if readiness else 0,
        limited_page_count=readiness.limited_page_count if readiness else 0,
        not_ready_page_count=readiness.not_ready_page_count if readiness else 0,
        total_elapsed_milliseconds=max(0.0, (perf_counter() - started_at) * 1_000),
        fact_elapsed_milliseconds=(
            fact_artifact.resource_usage.elapsed_milliseconds if fact_artifact else 0
        ),
        layout_elapsed_milliseconds=(
            layout_artifact.resource_usage.elapsed_milliseconds
            if layout_artifact
            else 0
        ),
    )


def _evidence(
    *,
    request_authority_digest: str,
    effective_limits: PdfStructuralAdapterEffectiveLimits,
    outcome: PdfStructuralAdapterOutcome,
    category: PdfStructuralAdapterErrorCategory,
    stage: PdfStructuralAdapterErrorStage,
    limit_name: PdfStructuralAdapterLimitName | None,
    source: PdfStructuralAdapterSourceMetadata | None,
    route_plan: PdfLayoutParserRoutePlan | None,
    selected_parser: PdfLayoutRoutableParser | None,
    fact_artifact: PdfFactArtifact | None,
    layout_artifact: PdfLayoutGraphArtifact | None,
    readiness: PdfLayoutGraphConsumerReadiness | None,
) -> PdfStructuralAdapterEvidence:
    fact_codes = _fact_warning_codes(fact_artifact) if fact_artifact else ()
    layout_codes = _layout_warning_codes(layout_artifact) if layout_artifact else ()
    fields = {
        "outcome": outcome,
        "error_category": category,
        "error_stage": stage,
        "limit_name": limit_name,
        "fallback_executed": False,
        "request_authority_digest": request_authority_digest,
        "source_fingerprint": source.fingerprint if source else None,
        "effective_limit_digest": effective_limits.digest,
        "route_initial_parser": route_plan.initial_parser if route_plan else None,
        "route_fallback_parser": route_plan.fallback_parser if route_plan else None,
        "selected_parser": selected_parser,
        "fact_status": fact_artifact.extraction_status if fact_artifact else None,
        "fact_artifact_digest": (
            source_fact_artifact_digest(fact_artifact) if fact_artifact else None
        ),
        "layout_graph_id": layout_artifact.layout_graph_id if layout_artifact else None,
        "layout_graph_digest": layout_artifact.graph_digest
        if layout_artifact
        else None,
        "layout_status": layout_artifact.build_status if layout_artifact else None,
        "readiness_outcome": readiness.outcome if readiness else None,
        "readiness_limitation_codes": readiness.limitation_codes if readiness else (),
        "fact_page_numbers": (
            tuple(page.page_number for page in fact_artifact.pages)
            if fact_artifact
            else ()
        ),
        "layout_page_numbers": (
            tuple(page.page_number for page in layout_artifact.pages)
            if layout_artifact
            else ()
        ),
        "fact_warning_codes": fact_codes,
        "layout_warning_codes": layout_codes,
    }
    digest = canonical_payload_sha256(
        {
            "schema_version": PDF_STRUCTURAL_ADAPTER_EVIDENCE_SCHEMA_VERSION,
            **fields,
        }
    )
    return PdfStructuralAdapterEvidence(
        **fields,  # type: ignore[arg-type]
        deterministic_evidence_sha256=digest,
    )


def _request_authority_digest(request: PdfStructuralAdapterRequest) -> str:
    inspection = request.inspection
    inspection_payload = {
        "file_id": inspection.file.file_id,
        "fingerprint": inspection.file.fingerprint.model_dump(mode="json"),
        "size_bytes": inspection.file.size_bytes,
        "page_count": inspection.page_count,
        "encrypted": inspection.encrypted,
        "has_text_layer": inspection.has_text_layer,
        "scanned_pdf_candidate": inspection.scanned_pdf_candidate,
        "native_text_page_numbers": inspection.native_text_page_numbers,
        "ocr_candidate_page_numbers": inspection.ocr_candidate_page_numbers,
        "fully_scanned": inspection.fully_scanned,
        "partially_scanned": inspection.partially_scanned,
        "pages": [
            {
                "page_number": page.page_number,
                "dimensions": page.dimensions.model_dump(mode="json"),
                "has_text_layer": page.has_text_layer,
                "native_text_character_count": page.native_text_character_count,
                "ocr_candidate": page.ocr_candidate,
                "source": page.source.model_dump(mode="json"),
            }
            for page in inspection.pages
        ],
    }
    return canonical_payload_sha256(
        {
            "inspection": inspection_payload,
            "preflight": request.preflight.model_dump(mode="json"),
            "policy": request.policy.model_dump(mode="json"),
            "extraction_options": request.extraction_options.model_dump(mode="json"),
            "layout_options": request.layout_options.model_dump(mode="json"),
            "processing_limits": request.processing_limits.model_dump(mode="json"),
        }
    )


def _fact_warning_codes(artifact: PdfFactArtifact) -> tuple[PdfWarningCode, ...]:
    codes = [warning.code for warning in artifact.warnings]
    for page in artifact.pages:
        codes.extend(warning.code for warning in page.warnings)
        for fact in page.text_spans:
            codes.extend(warning.code for warning in fact.warnings)
        for fact in page.words:
            codes.extend(warning.code for warning in fact.warnings)
        for fact in page.line_candidates:
            codes.extend(warning.code for warning in fact.warnings)
        for fact in page.characters:
            codes.extend(warning.code for warning in fact.warnings)
        for drawing in page.drawings:
            codes.extend(warning.code for warning in drawing.warnings)
        for image in page.image_regions:
            codes.extend(warning.code for warning in image.warnings)
    return tuple(codes)


def _layout_warning_codes(
    artifact: PdfLayoutGraphArtifact,
) -> tuple[PdfWarningCode, ...]:
    return tuple(
        warning.code
        for warning in (
            *artifact.warnings,
            *(warning for page in artifact.pages for warning in page.warnings),
        )
    )


def _total_fact_count(artifact: PdfFactArtifact) -> int:
    return sum(
        page.text_span_count
        + page.word_count
        + page.line_candidate_count
        + page.character_count
        + page.drawing_count
        + page.image_region_count
        for page in artifact.pages
    )


def _page_fact_ids(page: PdfPageFacts) -> set[str]:
    return {
        *(fact.fact_id for fact in page.text_spans),
        *(fact.fact_id for fact in page.words),
        *(fact.fact_id for fact in page.line_candidates),
        *(fact.fact_id for fact in page.characters),
        *(fact.fact_id for fact in page.drawings),
        *(fact.fact_id for fact in page.image_regions),
    }


def _execution_fail(
    *,
    category: PdfStructuralAdapterErrorCategory,
    stage: PdfStructuralAdapterErrorStage,
    limit_name: PdfStructuralAdapterLimitName | None = None,
) -> NoReturn:
    raise _PdfStructuralAdapterExecutionError(
        category=category,
        stage=stage,
        limit_name=limit_name,
    )


__all__ = ["run_pdf_structural_adapter"]

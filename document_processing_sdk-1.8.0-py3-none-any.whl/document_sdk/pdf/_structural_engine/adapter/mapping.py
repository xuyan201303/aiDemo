"""Fail-closed public-to-private limit and source mapping for the Adapter."""

# ruff: noqa: C901, PLR0912, PLR0915

from __future__ import annotations

from typing import NoReturn

from document_sdk.pdf._structural_engine.adapter.contracts import (
    PDF_STRUCTURAL_ADAPTER_EFFECTIVE_LIMITS_SCHEMA_VERSION,
    PDF_STRUCTURAL_ADAPTER_PUBLIC_LIMIT_MAPPING,
    PdfStructuralAdapterApplicablePublicLimits,
    PdfStructuralAdapterEffectiveLimits,
    PdfStructuralAdapterErrorCategory,
    PdfStructuralAdapterErrorStage,
    PdfStructuralAdapterLimitName,
    PdfStructuralAdapterRequest,
    PdfStructuralAdapterSourceMetadata,
)
from document_sdk.pdf._structural_engine.facts.identifiers import (
    document_identifier,
    source_sha256,
)
from document_sdk.pdf._structural_engine.facts.limits import (
    PdfExtractionLimits,
    PdfExtractionScopeMode,
)
from document_sdk.pdf._structural_engine.layout.identifiers import (
    canonical_payload_sha256,
)
from document_sdk.pdf._structural_engine.layout.limits import PdfLayoutGraphLimits


class PdfStructuralAdapterValidationError(ValueError):
    """Internal fixed-category validation stop without caller-controlled text."""

    def __init__(
        self,
        *,
        category: PdfStructuralAdapterErrorCategory,
        stage: PdfStructuralAdapterErrorStage,
        limit_name: PdfStructuralAdapterLimitName | None = None,
    ) -> None:
        super().__init__(category)
        self.category = category
        self.stage = stage
        self.limit_name = limit_name


def derive_pdf_structural_source_metadata(
    content: bytes,
) -> PdfStructuralAdapterSourceMetadata:
    """Derive path-free source metadata from exact immutable bytes."""
    if type(content) is not bytes:
        _fail(category="invalid_request", stage="request_binding")
    fingerprint = source_sha256(content)
    return PdfStructuralAdapterSourceMetadata(
        fingerprint=fingerprint,
        file_id=document_identifier(source_hash=fingerprint),
        source_size_bytes=len(content),
    )


def derive_pdf_structural_effective_limits(
    request: PdfStructuralAdapterRequest,
) -> PdfStructuralAdapterEffectiveLimits:
    """Clamp private defaults monotonically to applicable public authority."""
    extraction_defaults = PdfExtractionLimits()
    public = request.processing_limits
    extraction = PdfExtractionLimits.model_validate(
        {
            **extraction_defaults.model_dump(mode="python"),
            "max_file_size_bytes": min(
                extraction_defaults.max_file_size_bytes,
                public.max_file_bytes,
            ),
            "max_page_count": min(
                extraction_defaults.max_page_count,
                public.max_pages,
                public.max_native_text_pages,
            ),
            "max_selected_page_count": min(
                extraction_defaults.max_selected_page_count,
                public.max_pages,
                public.max_native_text_pages,
            ),
        },
    )
    layout_defaults = PdfLayoutGraphLimits()
    layout = PdfLayoutGraphLimits.model_validate(
        {
            **layout_defaults.model_dump(mode="python"),
            "max_page_build_milliseconds": min(
                layout_defaults.max_page_build_milliseconds,
                request.policy.product_page_build_budget_milliseconds,
            ),
        },
    )
    applicable_public = PdfStructuralAdapterApplicablePublicLimits(
        max_file_bytes=public.max_file_bytes,
        max_pages=public.max_pages,
        max_page_width_points=public.max_page_width_points,
        max_page_height_points=public.max_page_height_points,
        max_page_area_points=public.max_page_area_points,
        max_native_text_pages=public.max_native_text_pages,
        max_native_text_characters=public.max_native_text_characters,
    )
    payload = {
        "schema_version": PDF_STRUCTURAL_ADAPTER_EFFECTIVE_LIMITS_SCHEMA_VERSION,
        "applicable_public": applicable_public.model_dump(mode="json"),
        "public_limit_mapping": PDF_STRUCTURAL_ADAPTER_PUBLIC_LIMIT_MAPPING,
        "extraction": extraction.model_dump(mode="json"),
        "layout": layout.model_dump(mode="json"),
    }
    return PdfStructuralAdapterEffectiveLimits(
        applicable_public=applicable_public,
        extraction=extraction,
        layout=layout,
        digest=canonical_payload_sha256(payload),
    )


def validate_pdf_structural_adapter_request(
    content: bytes,
    *,
    request: PdfStructuralAdapterRequest,
    effective_limits: PdfStructuralAdapterEffectiveLimits,
) -> PdfStructuralAdapterSourceMetadata:
    """Bind bytes, inspection, preflight, scope, and all applicable limits."""
    source = derive_pdf_structural_source_metadata(content)
    inspection = request.inspection
    preflight = request.preflight

    if (
        source.fingerprint != inspection.file.fingerprint.value
        or source.source_size_bytes != inspection.file.size_bytes
        or source.source_size_bytes != preflight.source_size_bytes
        or inspection.file.file_id != inspection.file.fingerprint.value
    ):
        _fail(category="source_identity_mismatch", stage="request_binding")
    if inspection.page_count != len(inspection.pages):
        _fail(category="invalid_request", stage="request_binding")
    if inspection.page_count != preflight.page_count:
        _fail(category="invalid_request", stage="request_binding")

    page_numbers = tuple(page.page_number for page in inspection.pages)
    expected_page_numbers = tuple(range(1, inspection.page_count + 1))
    if page_numbers != expected_page_numbers:
        _fail(category="invalid_request", stage="request_binding")
    if any(
        page.source.file_id != inspection.file.file_id
        or page.source.page_number != page.page_number
        or page.dimensions.unit != "points"
        for page in inspection.pages
    ):
        _fail(category="invalid_request", stage="request_binding")
    if inspection.has_text_layer != any(
        page.has_text_layer for page in inspection.pages
    ):
        _fail(category="invalid_request", stage="request_binding")

    if preflight.rotated_page_count is not None and (
        preflight.rotated_page_count
        != sum(page.dimensions.rotation != 0 for page in inspection.pages)
    ):
        _fail(category="source_identity_mismatch", stage="request_binding")
    if (
        preflight.text_layer_available is not None
        and preflight.text_layer_available
        != any(page.has_text_layer for page in inspection.pages)
    ):
        _fail(category="source_identity_mismatch", stage="request_binding")

    scope = request.extraction_options.extraction_scope
    selected_pages = scope.requested_page_numbers
    if selected_pages != tuple(sorted(set(selected_pages))):
        _fail(category="invalid_request", stage="request_binding")
    if scope.mode is PdfExtractionScopeMode.SELECTED_PAGES:
        if (
            not selected_pages
            or any(
                page_number not in expected_page_numbers
                for page_number in selected_pages
            )
            or len(selected_pages) > effective_limits.extraction.max_selected_page_count
        ):
            if (
                selected_pages
                and all(
                    page_number in expected_page_numbers
                    for page_number in selected_pages
                )
                and len(selected_pages)
                > effective_limits.extraction.max_selected_page_count
            ):
                _fail(
                    category="resource_limit",
                    stage="public_limit",
                    limit_name="max_selected_page_count",
                )
            _fail(category="invalid_request", stage="request_binding")
    elif selected_pages:
        _fail(category="invalid_request", stage="request_binding")

    if (
        request.layout_options.include_drawings
        and not request.extraction_options.include_drawings
    ) or (
        request.layout_options.include_image_regions
        and not request.extraction_options.include_image_regions
    ):
        _fail(category="invalid_request", stage="request_binding")

    public = request.processing_limits
    if inspection.file.size_bytes > public.max_file_bytes:
        _limit("max_file_bytes")
    if inspection.file.size_bytes > effective_limits.extraction.max_file_size_bytes:
        _fail(
            category="resource_limit",
            stage="public_limit",
            limit_name="private_max_file_size_bytes",
        )
    if inspection.page_count > public.max_pages:
        _limit("max_pages")
    if any(
        page.dimensions.width > public.max_page_width_points
        for page in inspection.pages
    ):
        _limit("max_page_width_points")
    if any(
        page.dimensions.height > public.max_page_height_points
        for page in inspection.pages
    ):
        _limit("max_page_height_points")
    if any(
        page.dimensions.width * page.dimensions.height > public.max_page_area_points
        for page in inspection.pages
    ):
        _limit("max_page_area_points")
    if inspection.page_count > public.max_native_text_pages:
        _limit("max_native_text_pages")
    native_text_characters = sum(
        page.native_text_character_count for page in inspection.pages
    )
    if native_text_characters > public.max_native_text_characters:
        _limit("max_native_text_characters")
    return source


def _limit(limit_name: PdfStructuralAdapterLimitName) -> NoReturn:
    _fail(
        category="resource_limit",
        stage="public_limit",
        limit_name=limit_name,
    )


def _fail(
    *,
    category: PdfStructuralAdapterErrorCategory,
    stage: PdfStructuralAdapterErrorStage,
    limit_name: PdfStructuralAdapterLimitName | None = None,
) -> NoReturn:
    raise PdfStructuralAdapterValidationError(
        category=category,
        stage=stage,
        limit_name=limit_name,
    )


__all__ = [
    "PDF_STRUCTURAL_ADAPTER_PUBLIC_LIMIT_MAPPING",
    "PdfStructuralAdapterValidationError",
    "derive_pdf_structural_effective_limits",
    "derive_pdf_structural_source_metadata",
    "validate_pdf_structural_adapter_request",
]

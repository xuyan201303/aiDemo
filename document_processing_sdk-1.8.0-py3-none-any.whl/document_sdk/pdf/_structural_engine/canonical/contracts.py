"""Immutable private contracts for the generic Canonical PDF model."""

# ruff: noqa: C901, EM101, EM102, PLR0912, PLR0915, TRY003

from __future__ import annotations

from typing import Literal, Self

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .identifiers import (
    CANONICAL_IDENTITY_DOMAIN,
    canonical_identifier,
    canonical_model_identifier,
    canonical_payload_sha256,
)

CANONICAL_SCHEMA_VERSION: Literal["document_sdk_pdf_canonical.v2"] = (
    "document_sdk_pdf_canonical.v2"
)
CANONICAL_PROJECTION_VERSION: Literal["document_sdk.pdf.canonical.projection.v3"] = (
    "document_sdk.pdf.canonical.projection.v3"
)
CanonicalAvailabilityState = Literal[
    "AVAILABLE",
    "PARTIAL",
    "UNAVAILABLE",
    "UNSUPPORTED",
    "LIMITED_EVIDENCE",
]
CanonicalWarningSeverity = Literal["info", "warning", "error"]


class _FrozenModel(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        frozen=True,
        hide_input_in_errors=True,
        strict=True,
        allow_inf_nan=False,
    )


def _require_canonical_strings(values: tuple[str, ...], *, label: str) -> None:
    if values != tuple(sorted(set(values))):
        raise ValueError(f"{label} must be sorted and unique")


def _require_identity(model: BaseModel, *, field: str, kind: str) -> None:
    if getattr(model, field) != canonical_model_identifier(
        model,
        identity_field=field,
        kind=kind,
    ):
        raise ValueError(f"canonical {kind} identity mismatch")


class CanonicalProjectionLimits(_FrozenModel):
    """Fail-closed ceilings independent from upstream extraction limits."""

    maximum_pages: int = Field(default=2048, ge=1, le=4096)
    maximum_text_blocks: int = Field(default=200_000, ge=1, le=500_000)
    maximum_text_characters: int = Field(
        default=20_000_000,
        ge=1,
        le=100_000_000,
    )
    maximum_drawings: int = Field(default=200_000, ge=1, le=500_000)
    maximum_tables: int = Field(default=65_536, ge=1, le=100_000)
    maximum_rows: int = Field(default=200_000, ge=1, le=500_000)
    maximum_columns: int = Field(default=200_000, ge=1, le=500_000)
    maximum_cells: int = Field(default=2_000_000, ge=1, le=4_000_000)
    maximum_document_tables: int = Field(default=65_536, ge=1, le=100_000)
    maximum_logical_rows: int = Field(default=200_000, ge=1, le=500_000)
    maximum_logical_cells: int = Field(default=2_000_000, ge=1, le=4_000_000)
    maximum_transitions: int = Field(default=2047, ge=1, le=4095)
    maximum_transition_fingerprints: int = Field(default=2047, ge=1, le=4095)
    maximum_transition_detail_items: int = Field(
        default=2_000_000,
        ge=1,
        le=4_000_000,
    )
    maximum_warnings: int = Field(default=100_000, ge=1, le=500_000)
    maximum_canonical_bytes: int = Field(
        default=128 * 1024 * 1024,
        ge=1024,
        le=512 * 1024 * 1024,
    )

    @property
    def digest(self) -> str:
        """Return the deterministic limit-contract digest."""
        return canonical_payload_sha256(self)


class CanonicalAvailability(_FrozenModel):
    """Explicit state that never conflates missing evidence with empty content."""

    state: CanonicalAvailabilityState
    reason_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_reasons(self) -> Self:
        _require_canonical_strings(self.reason_codes, label="availability reasons")
        if self.state == "AVAILABLE" and self.reason_codes:
            raise ValueError("available capability cannot carry limitation reasons")
        if self.state != "AVAILABLE" and not self.reason_codes:
            raise ValueError("non-available capability requires a reason")
        return self


class CanonicalCapabilityAvailability(_FrozenModel):
    capability: str = Field(min_length=1, max_length=64, pattern=r"^[a-z0-9_]+$")
    availability: CanonicalAvailability


class CanonicalBoundingBox(_FrozenModel):
    coordinate_space: Literal["visual_top_left_canonical_pdf_point"] = (
        "visual_top_left_canonical_pdf_point"
    )
    origin: Literal["top_left"] = "top_left"
    x0: float
    y0: float
    x1: float
    y1: float

    @model_validator(mode="after")
    def validate_bounds(self) -> Self:
        if self.x0 > self.x1 or self.y0 > self.y1:
            raise ValueError("canonical bbox coordinates must be ordered")
        return self


class CanonicalPageBox(_FrozenModel):
    x0: float
    y0: float
    x1: float
    y1: float

    @model_validator(mode="after")
    def validate_bounds(self) -> Self:
        if self.x0 >= self.x1 or self.y0 >= self.y1:
            raise ValueError("canonical page box must have positive area")
        return self


class CanonicalPageGeometry(_FrozenModel):
    coordinate_space: Literal["visual_top_left_canonical_pdf_point"] = (
        "visual_top_left_canonical_pdf_point"
    )
    origin: Literal["top_left"] = "top_left"
    rotation_normalized: Literal[True] = True
    rotation: Literal[0, 90, 180, 270]
    canonical_width: float = Field(gt=0)
    canonical_height: float = Field(gt=0)
    media_box: CanonicalPageBox
    crop_box: CanonicalPageBox
    effective_page_box: CanonicalPageBox
    effective_page_box_basis: Literal[
        "media_box",
        "crop_box",
        "media_crop_intersection",
    ]
    effective_origin_x: float
    effective_origin_y: float
    user_unit: float = Field(ge=1, le=75_000)
    user_unit_authority: Literal["upstream_facts"] = "upstream_facts"


class CanonicalTextSpan(_FrozenModel):
    span_id: str = Field(pattern=r"^P3CE1-text-span-[0-9a-f]{64}$")
    source_fact_id: str
    source_layout_node_id: str | None = None
    span_index: int = Field(ge=0)
    text: str
    bbox: CanonicalBoundingBox
    font_name: str | None = Field(default=None, max_length=256)
    font_size: float | None = Field(default=None, ge=0)
    rotation: float | None = Field(default=None, ge=0, lt=360)
    availability: CanonicalAvailability

    @model_validator(mode="after")
    def validate_identity(self) -> Self:
        _require_identity(self, field="span_id", kind="text-span")
        return self


class CanonicalTextBlock(_FrozenModel):
    text_block_id: str = Field(pattern=r"^P3CE1-text-block-[0-9a-f]{64}$")
    page_id: str = Field(pattern=r"^P3CE1-page-[0-9a-f]{64}$")
    source_block_id: str | None = None
    block_index: int = Field(ge=0)
    text: str
    bbox: CanonicalBoundingBox
    spans: tuple[CanonicalTextSpan, ...]
    role: str = Field(min_length=1, max_length=64)
    role_status: str = Field(min_length=1, max_length=32)
    availability: CanonicalAvailability
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_block(self) -> Self:
        if tuple(item.span_index for item in self.spans) != tuple(
            range(len(self.spans))
        ):
            raise ValueError("canonical text spans must be contiguous and ordered")
        if len({item.span_id for item in self.spans}) != len(self.spans):
            raise ValueError("canonical text block repeats a span identity")
        _require_canonical_strings(
            self.limitation_codes,
            label="text block limitations",
        )
        _require_identity(self, field="text_block_id", kind="text-block")
        return self


class CanonicalDrawing(_FrozenModel):
    drawing_id: str = Field(pattern=r"^P3CE1-drawing-[0-9a-f]{64}$")
    page_id: str = Field(pattern=r"^P3CE1-page-[0-9a-f]{64}$")
    source_drawing_id: str
    drawing_index: int = Field(ge=0)
    kind: Literal["line", "rectangle", "curve"]
    bbox: CanonicalBoundingBox
    path_geometry_complete: bool
    path_segment_count: int = Field(ge=0)
    availability: CanonicalAvailability
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_drawing(self) -> Self:
        _require_canonical_strings(self.limitation_codes, label="drawing limitations")
        _require_identity(self, field="drawing_id", kind="drawing")
        return self


class CanonicalTableCell(_FrozenModel):
    cell_id: str = Field(pattern=r"^P3CE1-table-cell-[0-9a-f]{64}$")
    table_id: str = Field(pattern=r"^P3CE1-table-[0-9a-f]{64}$")
    row_id: str = Field(pattern=r"^P3CE1-table-row-[0-9a-f]{64}$")
    source_cell_id: str
    row_index: int = Field(ge=0)
    column_index: int = Field(ge=0)
    row_span: int = Field(ge=1)
    column_span: int = Field(ge=1)
    text: str | None
    text_available: bool
    bbox: CanonicalBoundingBox
    state: str = Field(min_length=1, max_length=32)
    role: str = Field(min_length=1, max_length=32)
    role_status: str = Field(min_length=1, max_length=32)
    availability: CanonicalAvailability
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_cell(self) -> Self:
        if self.text_available != (self.text is not None):
            raise ValueError("canonical cell text availability is inconsistent")
        _require_canonical_strings(self.limitation_codes, label="cell limitations")
        expected = canonical_identifier(
            "table-cell",
            self.model_dump(mode="json", exclude={"cell_id"}),
        )
        if self.cell_id != expected:
            raise ValueError("canonical table-cell identity mismatch")
        return self


class CanonicalTableRow(_FrozenModel):
    row_id: str = Field(pattern=r"^P3CE1-table-row-[0-9a-f]{64}$")
    table_id: str = Field(pattern=r"^P3CE1-table-[0-9a-f]{64}$")
    source_row_id: str
    row_index: int = Field(ge=0)
    cell_ids: tuple[str, ...]
    bbox: CanonicalBoundingBox
    availability: CanonicalAvailability

    @model_validator(mode="after")
    def validate_row(self) -> Self:
        if len(self.cell_ids) != len(set(self.cell_ids)):
            raise ValueError("canonical table row repeats a cell identity")
        expected = canonical_identifier(
            "table-row",
            {
                "table_id": self.table_id,
                "source_row_id": self.source_row_id,
                "row_index": self.row_index,
                "bbox": self.bbox,
            },
        )
        if self.row_id != expected:
            raise ValueError("canonical table-row identity mismatch")
        return self


class CanonicalTableColumn(_FrozenModel):
    column_id: str = Field(pattern=r"^P3CE1-table-column-[0-9a-f]{64}$")
    table_id: str = Field(pattern=r"^P3CE1-table-[0-9a-f]{64}$")
    source_column_id: str
    column_index: int = Field(ge=0)
    cell_ids: tuple[str, ...]
    bbox: CanonicalBoundingBox
    availability: CanonicalAvailability

    @model_validator(mode="after")
    def validate_column(self) -> Self:
        if len(self.cell_ids) != len(set(self.cell_ids)):
            raise ValueError("canonical table column repeats a cell identity")
        expected = canonical_identifier(
            "table-column",
            {
                "table_id": self.table_id,
                "source_column_id": self.source_column_id,
                "column_index": self.column_index,
                "bbox": self.bbox,
            },
        )
        if self.column_id != expected:
            raise ValueError("canonical table-column identity mismatch")
        return self


class CanonicalTable(_FrozenModel):
    table_id: str = Field(pattern=r"^P3CE1-table-[0-9a-f]{64}$")
    page_id: str = Field(pattern=r"^P3CE1-page-[0-9a-f]{64}$")
    source_table_id: str
    table_ordinal: int = Field(ge=0)
    bbox: CanonicalBoundingBox
    row_count: int = Field(ge=1)
    column_count: int = Field(ge=1)
    rows: tuple[CanonicalTableRow, ...]
    columns: tuple[CanonicalTableColumn, ...]
    cells: tuple[CanonicalTableCell, ...]
    document_table_ids: tuple[str, ...] = ()
    state: str = Field(min_length=1, max_length=32)
    availability: CanonicalAvailability
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_table(self) -> Self:
        if self.row_count != len(self.rows):
            raise ValueError("canonical table row count mismatch")
        if self.column_count != len(self.columns):
            raise ValueError("canonical table column count mismatch")
        if tuple(item.row_index for item in self.rows) != tuple(range(self.row_count)):
            raise ValueError("canonical table rows must be contiguous and ordered")
        if tuple(item.column_index for item in self.columns) != tuple(
            range(self.column_count)
        ):
            raise ValueError("canonical table columns must be contiguous and ordered")
        row_ids = {item.row_id for item in self.rows}
        column_ids = {item.column_id for item in self.columns}
        cell_ids = {item.cell_id for item in self.cells}
        if (
            len(row_ids) != len(self.rows)
            or len(column_ids) != len(self.columns)
            or len(cell_ids) != len(self.cells)
        ):
            raise ValueError("canonical table repeats a row, column, or cell identity")
        if any(item.table_id != self.table_id for item in self.rows) or any(
            item.table_id != self.table_id for item in self.cells
        ):
            raise ValueError("canonical row or cell crosses table identity")
        if any(item.table_id != self.table_id for item in self.columns):
            raise ValueError("canonical column crosses table identity")
        if any(item.row_id not in row_ids for item in self.cells):
            raise ValueError("canonical cell references a missing row")
        if any(set(item.cell_ids) - cell_ids for item in self.rows):
            raise ValueError("canonical row references a missing cell")
        if any(set(item.cell_ids) - cell_ids for item in self.columns):
            raise ValueError("canonical column references a missing cell")
        if any(
            set(row.cell_ids)
            != {cell.cell_id for cell in self.cells if cell.row_id == row.row_id}
            for row in self.rows
        ):
            raise ValueError("canonical row-cell membership mismatch")
        if any(
            set(column.cell_ids)
            != {
                cell.cell_id
                for cell in self.cells
                if cell.column_index == column.column_index
            }
            for column in self.columns
        ):
            raise ValueError("canonical column-cell membership mismatch")
        if any(
            item.row_index + item.row_span > self.row_count
            or item.column_index + item.column_span > self.column_count
            for item in self.cells
        ):
            raise ValueError("canonical cell span exceeds table bounds")
        _require_canonical_strings(
            self.document_table_ids,
            label="document table identities",
        )
        _require_canonical_strings(self.limitation_codes, label="table limitations")
        expected = canonical_identifier(
            "table",
            {
                "page_id": self.page_id,
                "source_table_id": self.source_table_id,
                "table_ordinal": self.table_ordinal,
                "bbox": self.bbox,
                "state": self.state,
            },
        )
        if self.table_id != expected:
            raise ValueError("canonical table identity mismatch")
        return self


class CanonicalLogicalRow(_FrozenModel):
    logical_row_id: str = Field(pattern=r"^P3CE1-logical-row-[0-9a-f]{64}$")
    source_logical_row_id: str
    row_ids: tuple[str, ...]
    cell_ids: tuple[str, ...]
    source_row_ids: tuple[str, ...]
    source_cell_ids: tuple[str, ...]
    source_page_indexes: tuple[int, ...]
    repeated_header_occurrence: bool
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_row(self) -> Self:
        if (
            not self.row_ids
            or not self.cell_ids
            or not self.source_row_ids
            or not self.source_cell_ids
        ):
            raise ValueError("canonical logical row requires source provenance")
        if len(self.row_ids) != len(self.source_row_ids) or len(self.cell_ids) != len(
            self.source_cell_ids
        ):
            raise ValueError("canonical logical row join cardinality mismatch")
        if len(set(self.row_ids)) != len(self.row_ids) or len(
            set(self.cell_ids)
        ) != len(self.cell_ids):
            raise ValueError("canonical logical row repeats a joined identity")
        _require_canonical_strings(
            self.limitation_codes,
            label="logical row limitations",
        )
        _require_identity(self, field="logical_row_id", kind="logical-row")
        return self


class CanonicalDocumentTable(_FrozenModel):
    document_table_id: str = Field(pattern=r"^P3CE1-document-table-[0-9a-f]{64}$")
    source_document_table_id: str
    table_ids: tuple[str, ...]
    transition_ids: tuple[str, ...]
    logical_rows: tuple[CanonicalLogicalRow, ...]
    canonical_header_identity: str | None = None
    repeated_header_identities: tuple[str, ...] = ()
    status: str = Field(min_length=1, max_length=32)
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_document_table(self) -> Self:
        if not self.table_ids or len(set(self.table_ids)) != len(self.table_ids):
            raise ValueError("canonical document table requires unique page tables")
        if len(set(self.transition_ids)) != len(self.transition_ids):
            raise ValueError("canonical document table repeats a transition")
        if len({item.logical_row_id for item in self.logical_rows}) != len(
            self.logical_rows
        ):
            raise ValueError("canonical document table repeats a logical row")
        _require_canonical_strings(
            self.repeated_header_identities,
            label="document table repeated-header identities",
        )
        _require_canonical_strings(
            self.limitation_codes,
            label="document table limitations",
        )
        _require_identity(self, field="document_table_id", kind="document-table")
        return self


class CanonicalTransitionColumnMapping(_FrozenModel):
    left_column_id: str = Field(pattern=r"^P3CE1-table-column-[0-9a-f]{64}$")
    right_column_id: str = Field(pattern=r"^P3CE1-table-column-[0-9a-f]{64}$")
    source_left_column_id: str
    source_right_column_id: str
    left_column_index: int = Field(ge=0)
    right_column_index: int = Field(ge=0)
    normalized_axis_distance: float = Field(ge=0, le=1)
    width_ratio_difference: float = Field(ge=0)
    topology_compatible: bool
    evidence_strength: float = Field(ge=0, le=1)
    conflicting_evidence: tuple[str, ...] = ()
    reason_code: str = Field(min_length=1, max_length=128)


class CanonicalRepeatedHeaderEvidence(_FrozenModel):
    logical_header_identity: str
    left_row_ids: tuple[str, ...]
    right_row_ids: tuple[str, ...]
    left_cell_ids: tuple[str, ...]
    right_cell_ids: tuple[str, ...]
    source_left_row_ids: tuple[str, ...]
    source_right_row_ids: tuple[str, ...]
    source_left_cell_ids: tuple[str, ...]
    source_right_cell_ids: tuple[str, ...]
    occurrence_index: int = Field(ge=1)
    exact_symbolic_repeat: bool
    topology_compatible: bool


class CanonicalSplitRowEvidence(_FrozenModel):
    source_fragment_link_id: str
    left_row_id: str = Field(pattern=r"^P3CE1-table-row-[0-9a-f]{64}$")
    right_row_id: str = Field(pattern=r"^P3CE1-table-row-[0-9a-f]{64}$")
    left_cell_ids: tuple[str, ...]
    right_cell_ids: tuple[str, ...]
    source_left_row_id: str
    source_right_row_id: str
    source_left_cell_ids: tuple[str, ...]
    source_right_cell_ids: tuple[str, ...]
    mapped_column_indexes: tuple[tuple[int, int], ...]
    local_fragment_order: tuple[Literal["LEFT", "RIGHT"], ...]
    physically_incomplete_left: bool
    physically_compatible_right: bool
    conflicting_evidence: tuple[str, ...] = ()


class CanonicalTransitionPagePairGeometry(_FrozenModel):
    orientation_relationship: str
    normalized_table_width_drift: float | None = Field(default=None, ge=0)
    normalized_margin_drift: float | None = Field(default=None, ge=0)
    margin_similarity: float | None = Field(default=None, ge=0, le=1)
    left_lower_boundary_proximity: float | None = Field(default=None, ge=0, le=1)
    right_upper_boundary_proximity: float | None = Field(default=None, ge=0, le=1)
    boundary_proximity: float | None = Field(default=None, ge=0, le=1)
    orientation_similarity: float | None = Field(default=None, ge=0, le=1)
    left_bottom_enclosure: str
    right_top_enclosure: str


class CanonicalTransitionColumnContinuity(_FrozenModel):
    left_column_count: int = Field(ge=0)
    right_column_count: int = Field(ge=0)
    normalized_axis_distances: tuple[float, ...] = ()
    column_width_ratio_drifts: tuple[float, ...] = ()
    inserted_column_count: int = Field(ge=0)
    removed_column_count: int = Field(ge=0)
    empty_spacer_column_continuity: str
    mapping_completeness: float | None = Field(default=None, ge=0, le=1)
    mapping_ambiguous: bool | None
    topology_hard_difference: bool | None


class CanonicalTransitionHeaderContinuity(_FrozenModel):
    repeated_header_present: bool | None
    repeated_header_depth: int | None = Field(default=None, ge=0)
    header_pattern: str
    merged_header_topology_signature: str | None = None
    normalized_header_geometry_signature: tuple[float, ...] | None = None
    header_geometry_signature: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )
    symbolic_repetition: str
    repeated_occurrence_count: int | None = Field(default=None, ge=0)
    body_start_offset: int | None = Field(default=None, ge=0)


class CanonicalTransitionRowCellContinuity(_FrozenModel):
    split_row_present: bool | None
    split_cell_present: bool | None
    open_last_row: bool | None
    open_first_row: bool | None
    fragment_count: int | None = Field(default=None, ge=0)
    mapped_column_fragment_distribution: tuple[int, ...] | None = None
    multiline_continuation: bool | None
    local_text_order_continuous: bool | None
    ambiguous_fragment_count: int | None = Field(default=None, ge=0)


class CanonicalTransitionPairContext(_FrozenModel):
    left_table_count: int = Field(ge=0)
    right_table_count: int = Field(ge=0)
    candidate_pair_count: int = Field(ge=0)
    selected_pair_rank: int | None = Field(default=None, ge=1)
    multiple_table_transition: bool
    predecessor_exclusive: bool
    successor_exclusive: bool
    continuation_outcome: str
    conflicting_evidence_groups: tuple[str, ...] = ()
    typed_downgrade_reason: str | None = None


class CanonicalTransitionSafetyState(_FrozenModel):
    source_capability_state: str
    runtime_truncated: bool | None
    dependency_state: str
    evidence_complete: bool
    safety_score: float | None = Field(default=None, ge=0, le=1)


class CanonicalTransitionFingerprint(_FrozenModel):
    source_fingerprint_id: str = Field(pattern=r"^P3D-XFP-transition-[0-9a-f]{64}$")
    semantic_fingerprint_identity: str = Field(
        pattern=r"^P3D-XFP-semantic-[0-9a-f]{64}$"
    )
    feature_schema_version: str
    state: Literal["AVAILABLE", "PARTIAL", "UNSUPPORTED", "UNAVAILABLE"]
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    source_document_identity: str
    page_table_manifest_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    source_transition_id: str
    left_page_index: int = Field(ge=0)
    right_page_index: int = Field(ge=0)
    left_page_id: str
    right_page_id: str
    left_source_table_id: str
    right_source_table_id: str
    left_table_sidecar_id: str
    right_table_sidecar_id: str
    left_table_sidecar_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    right_table_sidecar_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    left_configuration_identity: str | None = None
    right_configuration_identity: str | None = None
    left_dependency_identity: str | None = None
    right_dependency_identity: str | None = None
    page_pair_geometry: CanonicalTransitionPagePairGeometry
    column_continuity: CanonicalTransitionColumnContinuity
    header_continuity: CanonicalTransitionHeaderContinuity
    row_cell_continuity: CanonicalTransitionRowCellContinuity
    pair_context: CanonicalTransitionPairContext
    safety_state: CanonicalTransitionSafetyState
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_fingerprint(self) -> Self:
        _require_canonical_strings(
            self.limitation_codes,
            label="transition fingerprint limitations",
        )
        return self


class CanonicalTransition(_FrozenModel):
    transition_id: str = Field(pattern=r"^P3CE1-transition-[0-9a-f]{64}$")
    source_transition_id: str
    left_table_id: str = Field(pattern=r"^P3CE1-table-[0-9a-f]{64}$")
    right_table_id: str = Field(pattern=r"^P3CE1-table-[0-9a-f]{64}$")
    outcome: str = Field(min_length=1, max_length=64)
    repeated_header: bool
    split_row: bool
    repeated_header_evidence_ids: tuple[str, ...] = ()
    split_row_evidence_ids: tuple[str, ...] = ()
    column_mappings: tuple[CanonicalTransitionColumnMapping, ...] = ()
    repeated_header_evidence: tuple[CanonicalRepeatedHeaderEvidence, ...] = ()
    split_row_evidence: tuple[CanonicalSplitRowEvidence, ...] = ()
    table_geometry_compatible: bool | None
    topology_compatible: bool | None
    page_boundary_evidence_strength: float | None = Field(ge=0, le=1)
    fingerprint_support_strength: float = Field(ge=0, le=1)
    candidate_pair_count: int = Field(ge=0, le=64)
    algorithm_version: str
    source_fingerprint_id: str | None = Field(
        default=None,
        pattern=r"^P3D-XFP-transition-[0-9a-f]{64}$",
    )
    semantic_fingerprint_identity: str | None = Field(
        default=None,
        pattern=r"^P3D-XFP-semantic-[0-9a-f]{64}$",
    )
    fingerprint_state: (
        Literal[
            "AVAILABLE",
            "PARTIAL",
            "UNSUPPORTED",
            "UNAVAILABLE",
        ]
        | None
    ) = None
    fingerprint_limitation_codes: tuple[str, ...] = ()
    fingerprint: CanonicalTransitionFingerprint | None = None
    availability: CanonicalAvailability
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_transition(self) -> Self:
        if self.left_table_id == self.right_table_id:
            raise ValueError("canonical transition cannot self-reference")
        _require_canonical_strings(
            self.repeated_header_evidence_ids,
            label="repeated-header evidence",
        )
        _require_canonical_strings(
            self.split_row_evidence_ids,
            label="split-row evidence",
        )
        fingerprint_fields = (
            self.source_fingerprint_id,
            self.semantic_fingerprint_identity,
            self.fingerprint_state,
        )
        if any(item is None for item in fingerprint_fields) != all(
            item is None for item in fingerprint_fields
        ):
            raise ValueError("canonical transition fingerprint binding is incomplete")
        if self.fingerprint_state is None and self.fingerprint_limitation_codes:
            raise ValueError("missing fingerprint cannot carry fingerprint limitations")
        _require_canonical_strings(
            self.fingerprint_limitation_codes,
            label="transition fingerprint limitations",
        )
        if self.repeated_header != bool(self.repeated_header_evidence):
            raise ValueError("canonical repeated-header evidence is inconsistent")
        if self.split_row != bool(self.split_row_evidence):
            raise ValueError("canonical split-row evidence is inconsistent")
        if self.repeated_header_evidence_ids != tuple(
            sorted(
                item.logical_header_identity for item in self.repeated_header_evidence
            )
        ):
            raise ValueError("canonical repeated-header identity inventory mismatch")
        if self.split_row_evidence_ids != tuple(
            sorted(item.source_fragment_link_id for item in self.split_row_evidence)
        ):
            raise ValueError("canonical split-row identity inventory mismatch")
        if self.fingerprint is None:
            if any(item is not None for item in fingerprint_fields):
                raise ValueError("canonical transition fingerprint payload is missing")
        elif (
            self.source_fingerprint_id != self.fingerprint.source_fingerprint_id
            or self.semantic_fingerprint_identity
            != self.fingerprint.semantic_fingerprint_identity
            or self.fingerprint_state != self.fingerprint.state
            or self.fingerprint_limitation_codes != self.fingerprint.limitation_codes
            or self.source_transition_id != self.fingerprint.source_transition_id
        ):
            raise ValueError("canonical transition fingerprint summary mismatch")
        _require_canonical_strings(
            self.limitation_codes,
            label="transition limitations",
        )
        _require_identity(self, field="transition_id", kind="transition")
        return self


class CanonicalWarning(_FrozenModel):
    warning_id: str = Field(pattern=r"^P3CE1-warning-[0-9a-f]{64}$")
    code: str = Field(min_length=1, max_length=128)
    severity: CanonicalWarningSeverity
    message: str = Field(min_length=1, max_length=240)
    recoverable: bool
    page_id: str | None = Field(
        default=None,
        pattern=r"^P3CE1-page-[0-9a-f]{64}$",
    )
    source_page_number: int | None = Field(default=None, ge=1)
    source_fact_id: str | None = None
    source_parser_name: str = Field(min_length=1, max_length=64)
    source_scope: str = Field(min_length=1, max_length=64)
    occurrence_index: int = Field(ge=0)

    @model_validator(mode="after")
    def validate_identity(self) -> Self:
        _require_identity(self, field="warning_id", kind="warning")
        return self


class CanonicalWarningSuppression(_FrozenModel):
    source_scope: Literal["facts", "layout"]
    suppressed_warning_count: int = Field(ge=1)
    suppressed_warning_count_by_code: tuple[tuple[str, int], ...]
    suppressed_warning_count_by_scope: tuple[tuple[str, int], ...]
    suppressed_affected_page_count: int = Field(ge=0)
    suppressed_affected_fact_count: int = Field(ge=0)

    @model_validator(mode="after")
    def validate_accounting(self) -> Self:
        for values, label in (
            (self.suppressed_warning_count_by_code, "warning code"),
            (self.suppressed_warning_count_by_scope, "warning scope"),
        ):
            if values != tuple(sorted(values)) or len(
                {item[0] for item in values}
            ) != len(values):
                raise ValueError(
                    f"canonical suppressed {label} counts are noncanonical"
                )
            if sum(item[1] for item in values) != self.suppressed_warning_count:
                raise ValueError(f"canonical suppressed {label} counts do not balance")
        return self


class CanonicalPage(_FrozenModel):
    page_id: str = Field(pattern=r"^P3CE1-page-[0-9a-f]{64}$")
    source_page_id: str
    page_index: int = Field(ge=0)
    page_number: int = Field(ge=1)
    geometry: CanonicalPageGeometry
    text_blocks: tuple[CanonicalTextBlock, ...]
    drawings: tuple[CanonicalDrawing, ...]
    table_ids: tuple[str, ...]
    page_table_outcome: str | None = Field(default=None, max_length=64)
    page_table_availability: CanonicalAvailability
    page_table_negative_evidence_categories: tuple[str, ...] = ()
    warning_ids: tuple[str, ...] = ()
    availability: CanonicalAvailability
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_page(self) -> Self:
        if self.page_index != self.page_number - 1:
            raise ValueError("canonical page index and number are inconsistent")
        if tuple(item.block_index for item in self.text_blocks) != tuple(
            range(len(self.text_blocks))
        ):
            raise ValueError("canonical text blocks must be contiguous and ordered")
        if tuple(item.drawing_index for item in self.drawings) != tuple(
            range(len(self.drawings))
        ):
            raise ValueError("canonical drawings must be contiguous and ordered")
        if any(item.page_id != self.page_id for item in self.text_blocks):
            raise ValueError("canonical text block crosses a page")
        if any(item.page_id != self.page_id for item in self.drawings):
            raise ValueError("canonical drawing crosses a page")
        if len(self.table_ids) != len(set(self.table_ids)):
            raise ValueError("canonical page repeats a table identity")
        if self.page_table_outcome == "NO_TABLE":
            if self.table_ids or not self.page_table_negative_evidence_categories:
                raise ValueError(
                    "canonical NO_TABLE requires explicit negative evidence only"
                )
            if self.page_table_availability.state != "AVAILABLE":
                raise ValueError("canonical NO_TABLE must remain available")
        if self.page_table_outcome is None and (
            self.table_ids
            or self.page_table_availability.state != "UNAVAILABLE"
            or self.page_table_negative_evidence_categories
        ):
            raise ValueError("missing Page Table authority is inconsistent")
        _require_canonical_strings(
            self.page_table_negative_evidence_categories,
            label="page-table negative evidence categories",
        )
        if len(self.warning_ids) != len(set(self.warning_ids)):
            raise ValueError("canonical page repeats a warning identity")
        _require_canonical_strings(self.limitation_codes, label="page limitations")
        expected = canonical_identifier(
            "page",
            {
                "source_page_id": self.source_page_id,
                "page_index": self.page_index,
                "page_number": self.page_number,
                "geometry": self.geometry,
            },
        )
        if self.page_id != expected:
            raise ValueError("canonical page identity mismatch")
        return self


class CanonicalProvenance(_FrozenModel):
    canonical_schema_version: Literal["document_sdk_pdf_canonical.v2"] = (
        CANONICAL_SCHEMA_VERSION
    )
    canonical_projection_version: Literal[
        "document_sdk.pdf.canonical.projection.v2",
        "document_sdk.pdf.canonical.projection.v3",
    ] = CANONICAL_PROJECTION_VERSION
    canonical_identity_domain: Literal["document_sdk.pdf.canonical.identity.v2"] = (
        CANONICAL_IDENTITY_DOMAIN
    )
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    source_document_identity: str
    source_parser_name: str = Field(min_length=1, max_length=64)
    source_parser_version: str = Field(min_length=1, max_length=64)
    upstream_schema_versions: tuple[str, ...]
    upstream_artifact_ids: tuple[str, ...]
    projection_limit_digest: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_inventory(self) -> Self:
        _require_canonical_strings(
            self.upstream_schema_versions,
            label="upstream schema versions",
        )
        _require_canonical_strings(
            self.upstream_artifact_ids,
            label="upstream artifact identities",
        )
        return self


class CanonicalDocument(_FrozenModel):
    canonical_version: Literal["document_sdk_pdf_canonical.v2"] = (
        CANONICAL_SCHEMA_VERSION
    )
    projection_version: Literal[
        "document_sdk.pdf.canonical.projection.v2",
        "document_sdk.pdf.canonical.projection.v3",
    ] = CANONICAL_PROJECTION_VERSION
    canonical_document_id: str = Field(pattern=r"^P3CE1-document-[0-9a-f]{64}$")
    source_document_identity: str
    page_count: int = Field(ge=0)
    projected_page_count: int = Field(ge=0)
    pages: tuple[CanonicalPage, ...]
    tables: tuple[CanonicalTable, ...]
    document_tables: tuple[CanonicalDocumentTable, ...] = ()
    transitions: tuple[CanonicalTransition, ...] = ()
    warnings: tuple[CanonicalWarning, ...] = ()
    warning_suppressions: tuple[CanonicalWarningSuppression, ...] = ()
    limitations: tuple[str, ...] = ()
    provenance: CanonicalProvenance
    availability: CanonicalAvailability
    capability_availability: tuple[CanonicalCapabilityAvailability, ...]
    family: None = None
    family_status: Literal["REVIEW_REQUIRED"] = "REVIEW_REQUIRED"
    family_auto_assignment: Literal[False] = False

    @model_validator(mode="after")
    def validate_document(self) -> Self:
        if self.projected_page_count != len(self.pages):
            raise ValueError("canonical projected-page count mismatch")
        if self.projected_page_count > self.page_count:
            raise ValueError("canonical projected-page count exceeds source count")
        page_ids = {item.page_id for item in self.pages}
        table_ids = {item.table_id for item in self.tables}
        document_table_ids = {item.document_table_id for item in self.document_tables}
        transition_ids = {item.transition_id for item in self.transitions}
        warning_ids = {item.warning_id for item in self.warnings}
        row_ids = {row.row_id for table in self.tables for row in table.rows}
        column_ids = {
            column.column_id for table in self.tables for column in table.columns
        }
        cell_ids = {cell.cell_id for table in self.tables for cell in table.cells}
        logical_row_ids = {
            row.logical_row_id
            for table in self.document_tables
            for row in table.logical_rows
        }
        text_block_ids = {
            block.text_block_id for page in self.pages for block in page.text_blocks
        }
        text_span_ids = {
            span.span_id
            for page in self.pages
            for block in page.text_blocks
            for span in block.spans
        }
        drawing_ids = {
            drawing.drawing_id for page in self.pages for drawing in page.drawings
        }
        inventories = (
            (page_ids, len(self.pages), "page"),
            (table_ids, len(self.tables), "table"),
            (document_table_ids, len(self.document_tables), "document table"),
            (transition_ids, len(self.transitions), "transition"),
            (warning_ids, len(self.warnings), "warning"),
            (
                row_ids,
                sum(len(item.rows) for item in self.tables),
                "table row",
            ),
            (
                column_ids,
                sum(len(item.columns) for item in self.tables),
                "table column",
            ),
            (
                cell_ids,
                sum(len(item.cells) for item in self.tables),
                "table cell",
            ),
            (
                logical_row_ids,
                sum(len(item.logical_rows) for item in self.document_tables),
                "logical row",
            ),
            (
                text_block_ids,
                sum(len(item.text_blocks) for item in self.pages),
                "text block",
            ),
            (
                text_span_ids,
                sum(
                    len(block.spans)
                    for page in self.pages
                    for block in page.text_blocks
                ),
                "text span",
            ),
            (
                drawing_ids,
                sum(len(item.drawings) for item in self.pages),
                "drawing",
            ),
        )
        if any(len(values) != count for values, count, _label in inventories):
            raise ValueError("canonical document repeats an entity identity")
        if tuple(item.page_index for item in self.pages) != tuple(
            sorted(item.page_index for item in self.pages)
        ):
            raise ValueError("canonical pages must use source-page order")
        if any(item.page_id not in page_ids for item in self.tables):
            raise ValueError("canonical table references a missing page")
        if any(
            page.table_ids
            != tuple(
                table.table_id for table in self.tables if table.page_id == page.page_id
            )
            for page in self.pages
        ):
            raise ValueError("canonical page-table membership mismatch")
        if any(set(item.table_ids) - table_ids for item in self.document_tables):
            raise ValueError("canonical document table references a missing table")
        if any(
            set(item.transition_ids) - transition_ids for item in self.document_tables
        ):
            raise ValueError("canonical document table references a missing transition")
        if any(
            table.document_table_ids
            != tuple(
                sorted(
                    document_table.document_table_id
                    for document_table in self.document_tables
                    if table.table_id in document_table.table_ids
                )
            )
            for table in self.tables
        ):
            raise ValueError("canonical table-document membership mismatch")
        table_by_id = {item.table_id: item for item in self.tables}
        transition_by_id = {item.transition_id: item for item in self.transitions}
        page_by_id = {item.page_id: item for item in self.pages}
        row_by_id = {row.row_id: row for table in self.tables for row in table.rows}
        cell_by_id = {
            cell.cell_id: cell for table in self.tables for cell in table.cells
        }
        row_page_index = {
            row.row_id: page_by_id[table.page_id].page_index
            for table in self.tables
            for row in table.rows
        }
        cell_page_index = {
            cell.cell_id: page_by_id[table.page_id].page_index
            for table in self.tables
            for cell in table.cells
        }
        for document_table in self.document_tables:
            table_page_indexes = tuple(
                page_by_id[table_by_id[table_id].page_id].page_index
                for table_id in document_table.table_ids
            )
            if table_page_indexes != tuple(
                range(
                    table_page_indexes[0],
                    table_page_indexes[0] + len(table_page_indexes),
                )
            ):
                raise ValueError(
                    "canonical document table must follow adjacent source pages"
                )
            expected_transition_pairs = tuple(
                zip(
                    document_table.table_ids,
                    document_table.table_ids[1:],
                    strict=False,
                )
            )
            try:
                observed_transition_pairs = tuple(
                    (
                        transition_by_id[transition_id].left_table_id,
                        transition_by_id[transition_id].right_table_id,
                    )
                    for transition_id in document_table.transition_ids
                )
            except KeyError:
                raise ValueError(
                    "canonical document table references a missing transition"
                ) from None
            if observed_transition_pairs != expected_transition_pairs:
                raise ValueError("canonical document-table transition chain mismatch")
            member_rows = {
                row.row_id
                for table_id in document_table.table_ids
                for row in table_by_id[table_id].rows
            }
            member_cells = {
                cell.cell_id
                for table_id in document_table.table_ids
                for cell in table_by_id[table_id].cells
            }
            if any(
                set(row.row_ids) - member_rows or set(row.cell_ids) - member_cells
                for row in document_table.logical_rows
            ):
                raise ValueError(
                    "canonical logical row crosses document-table membership"
                )
            for logical_row in document_table.logical_rows:
                expected_member_cells = {
                    cell_id
                    for row_id in logical_row.row_ids
                    for cell_id in row_by_id[row_id].cell_ids
                }
                if set(logical_row.cell_ids) - expected_member_cells:
                    raise ValueError(
                        "canonical logical row contains a cell from another row"
                    )
                if (
                    tuple(
                        row_by_id[row_id].source_row_id
                        for row_id in logical_row.row_ids
                    )
                    != logical_row.source_row_ids
                    or tuple(
                        cell_by_id[cell_id].source_cell_id
                        for cell_id in logical_row.cell_ids
                    )
                    != logical_row.source_cell_ids
                ):
                    raise ValueError(
                        "canonical logical row source identity join mismatch"
                    )
                expected_page_indexes = tuple(
                    sorted(
                        {
                            *(row_page_index[row_id] for row_id in logical_row.row_ids),
                            *(
                                cell_page_index[cell_id]
                                for cell_id in logical_row.cell_ids
                            ),
                        }
                    )
                )
                if logical_row.source_page_indexes != expected_page_indexes:
                    raise ValueError("canonical logical row page provenance mismatch")
        if any(
            item.left_table_id not in table_ids or item.right_table_id not in table_ids
            for item in self.transitions
        ):
            raise ValueError("canonical transition references a missing table")
        for transition in self.transitions:
            left = table_by_id[transition.left_table_id]
            right = table_by_id[transition.right_table_id]
            left_rows = {item.row_id for item in left.rows}
            right_rows = {item.row_id for item in right.rows}
            left_columns = {item.column_id for item in left.columns}
            right_columns = {item.column_id for item in right.columns}
            left_cells = {item.cell_id for item in left.cells}
            right_cells = {item.cell_id for item in right.cells}
            left_column_by_id = {item.column_id: item for item in left.columns}
            right_column_by_id = {item.column_id: item for item in right.columns}
            mapping_pairs = tuple(
                (item.left_column_id, item.right_column_id)
                for item in transition.column_mappings
            )
            if (
                len(mapping_pairs) != len(set(mapping_pairs))
                or len({item[0] for item in mapping_pairs}) != len(mapping_pairs)
                or len({item[1] for item in mapping_pairs}) != len(mapping_pairs)
            ):
                raise ValueError("canonical transition column mapping is noncanonical")
            for mapping in transition.column_mappings:
                if (
                    mapping.left_column_id not in left_columns
                    or mapping.right_column_id not in right_columns
                ):
                    raise ValueError(
                        "canonical transition column mapping crosses tables"
                    )
                left_column = left_column_by_id[mapping.left_column_id]
                right_column = right_column_by_id[mapping.right_column_id]
                if (
                    mapping.source_left_column_id != left_column.source_column_id
                    or mapping.source_right_column_id != right_column.source_column_id
                    or mapping.left_column_index != left_column.column_index
                    or mapping.right_column_index != right_column.column_index
                ):
                    raise ValueError(
                        "canonical transition column mapping join mismatch"
                    )
            if any(
                set(item.left_row_ids) - left_rows
                or set(item.right_row_ids) - right_rows
                or set(item.left_cell_ids) - left_cells
                or set(item.right_cell_ids) - right_cells
                for item in transition.repeated_header_evidence
            ):
                raise ValueError("canonical repeated-header evidence crosses tables")
            for header_evidence in transition.repeated_header_evidence:
                if (
                    any(
                        cell_by_id[cell_id].row_id not in header_evidence.left_row_ids
                        for cell_id in header_evidence.left_cell_ids
                    )
                    or any(
                        cell_by_id[cell_id].row_id not in header_evidence.right_row_ids
                        for cell_id in header_evidence.right_cell_ids
                    )
                    or tuple(
                        row_by_id[row_id].source_row_id
                        for row_id in header_evidence.left_row_ids
                    )
                    != header_evidence.source_left_row_ids
                    or tuple(
                        row_by_id[row_id].source_row_id
                        for row_id in header_evidence.right_row_ids
                    )
                    != header_evidence.source_right_row_ids
                    or tuple(
                        cell_by_id[cell_id].source_cell_id
                        for cell_id in header_evidence.left_cell_ids
                    )
                    != header_evidence.source_left_cell_ids
                    or tuple(
                        cell_by_id[cell_id].source_cell_id
                        for cell_id in header_evidence.right_cell_ids
                    )
                    != header_evidence.source_right_cell_ids
                ):
                    raise ValueError(
                        "canonical repeated-header source identity join mismatch"
                    )
            if any(
                item.left_row_id not in left_rows
                or item.right_row_id not in right_rows
                or set(item.left_cell_ids) - left_cells
                or set(item.right_cell_ids) - right_cells
                for item in transition.split_row_evidence
            ):
                raise ValueError("canonical split-row evidence crosses tables")
            mapping_index_pairs = {
                (item.left_column_index, item.right_column_index)
                for item in transition.column_mappings
            }
            for split_evidence in transition.split_row_evidence:
                if (
                    not split_evidence.mapped_column_indexes
                    or any(
                        cell_by_id[cell_id].row_id != split_evidence.left_row_id
                        for cell_id in split_evidence.left_cell_ids
                    )
                    or any(
                        cell_by_id[cell_id].row_id != split_evidence.right_row_id
                        for cell_id in split_evidence.right_cell_ids
                    )
                    or row_by_id[split_evidence.left_row_id].source_row_id
                    != split_evidence.source_left_row_id
                    or row_by_id[split_evidence.right_row_id].source_row_id
                    != split_evidence.source_right_row_id
                    or tuple(
                        cell_by_id[cell_id].source_cell_id
                        for cell_id in split_evidence.left_cell_ids
                    )
                    != split_evidence.source_left_cell_ids
                    or tuple(
                        cell_by_id[cell_id].source_cell_id
                        for cell_id in split_evidence.right_cell_ids
                    )
                    != split_evidence.source_right_cell_ids
                ):
                    raise ValueError(
                        "canonical split-row source identity join mismatch"
                    )
                split_pairs = tuple(split_evidence.mapped_column_indexes)
                if len(split_pairs) != len(set(split_pairs)) or (
                    set(split_pairs) - mapping_index_pairs
                ):
                    raise ValueError("canonical split-row column mapping join mismatch")
            fingerprint = transition.fingerprint
            if fingerprint is not None and (
                fingerprint.left_source_table_id != left.source_table_id
                or fingerprint.right_source_table_id != right.source_table_id
                or fingerprint.left_page_index != page_by_id[left.page_id].page_index
                or fingerprint.right_page_index != page_by_id[right.page_id].page_index
                or fingerprint.left_page_id != page_by_id[left.page_id].source_page_id
                or fingerprint.right_page_id != page_by_id[right.page_id].source_page_id
            ):
                raise ValueError("canonical transition fingerprint crosses tables")
        if any(set(item.warning_ids) - warning_ids for item in self.pages):
            raise ValueError("canonical page references a missing warning")
        if any(
            warning.page_id is not None and warning.page_id not in page_ids
            for warning in self.warnings
        ) or any(
            page.warning_ids
            != tuple(
                warning.warning_id
                for warning in self.warnings
                if warning.page_id == page.page_id
            )
            for page in self.pages
        ):
            raise ValueError("canonical page-warning membership mismatch")
        if any(
            warning.page_id is not None
            and page_by_id[warning.page_id].page_number != warning.source_page_number
            for warning in self.warnings
        ):
            raise ValueError("canonical warning page provenance mismatch")
        fingerprint_ids = tuple(
            item.fingerprint.source_fingerprint_id
            for item in self.transitions
            if item.fingerprint is not None
        )
        if len(fingerprint_ids) != len(set(fingerprint_ids)):
            raise ValueError("canonical document repeats a transition fingerprint")
        suppression_scopes = tuple(
            item.source_scope for item in self.warning_suppressions
        )
        if suppression_scopes != tuple(sorted(set(suppression_scopes))):
            raise ValueError("canonical warning suppression inventory is noncanonical")
        capabilities = tuple(item.capability for item in self.capability_availability)
        if capabilities != tuple(sorted(set(capabilities))):
            raise ValueError("canonical capability availability is noncanonical")
        if (
            self.provenance.source_document_identity != self.source_document_identity
            or self.provenance.canonical_schema_version != self.canonical_version
            or self.provenance.canonical_projection_version != self.projection_version
        ):
            raise ValueError("canonical provenance does not bind the document")
        _require_canonical_strings(self.limitations, label="document limitations")
        _require_identity(
            self,
            field="canonical_document_id",
            kind="document",
        )
        return self

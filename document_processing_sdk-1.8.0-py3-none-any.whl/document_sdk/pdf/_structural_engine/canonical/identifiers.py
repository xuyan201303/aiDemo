"""Deterministic private identities for Canonical PDF entities."""

# ruff: noqa: EM101, TRY003

from __future__ import annotations

import json
from enum import Enum
from hashlib import sha256
from typing import Any, Literal

from pydantic import BaseModel

CANONICAL_IDENTITY_DOMAIN: Literal["document_sdk.pdf.canonical.identity.v2"] = (
    "document_sdk.pdf.canonical.identity.v2"
)


def _jsonable(value: object) -> object:
    if isinstance(value, BaseModel):
        return value.model_dump(mode="json")
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, tuple):
        return [_jsonable(item) for item in value]
    if isinstance(value, list):
        return [_jsonable(item) for item in value]
    if isinstance(value, dict):
        return {
            str(key): _jsonable(item)
            for key, item in sorted(value.items(), key=lambda pair: str(pair[0]))
        }
    return value


def canonical_payload_bytes(value: object) -> bytes:
    """Return the namespace-independent canonical JSON encoding of a value."""
    return json.dumps(
        _jsonable(value),
        allow_nan=False,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")


def canonical_payload_sha256(value: object) -> str:
    """Hash one JSON-safe value with deterministic ordering."""
    return sha256(canonical_payload_bytes(value)).hexdigest()


def canonical_identifier(kind: str, payload: object) -> str:
    """Build a namespace-separated, content-derived Canonical identity."""
    if not kind or not kind.replace("-", "").isalnum():
        raise ValueError("canonical identity kind is invalid")
    digest = canonical_payload_sha256(
        {
            "domain": CANONICAL_IDENTITY_DOMAIN,
            "entity_kind": kind,
            "payload": payload,
        }
    )
    return f"P3CE1-{kind}-{digest}"


def canonical_model_identifier(
    model: BaseModel,
    *,
    identity_field: str,
    kind: str,
) -> str:
    """Recompute an identified model's identity from all other fields."""
    payload: dict[str, Any] = model.model_dump(
        mode="json",
        exclude={identity_field},
    )
    return canonical_identifier(kind, payload)

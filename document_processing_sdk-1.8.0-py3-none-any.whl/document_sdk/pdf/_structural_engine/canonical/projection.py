"""Projection from existing immutable PDF artifacts into Canonical form."""

# ruff: noqa: C901, EM101, EM102, PLR0912, PLR0913, PLR0915, TC001, TRY003

from __future__ import annotations

from collections import defaultdict
from itertools import pairwise
from typing import Literal, Self

from pydantic import BaseModel, ConfigDict, Field, ValidationError, model_validator

from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.pdf._structural_engine.facts.contracts import (
    PdfBoundingBox,
    PdfDrawingFact,
    PdfFactArtifact,
    PdfImageRegionFact,
    PdfPageBox,
    PdfPageFacts,
    PdfTextFact,
)
from document_sdk.pdf._structural_engine.facts.status import (
    PdfExtractionStatus,
    PdfFactWarning,
    PdfWarningCode,
    PdfWarningSuppressionSummary,
)
from document_sdk.pdf._structural_engine.layout.contracts import (
    PdfLayoutGeometryQuality,
    PdfLayoutGraphArtifact,
    PdfLayoutNode,
    PdfLayoutNodeType,
    PdfLayoutPageGraph,
)
from document_sdk.pdf._structural_engine.layout.identifiers import (
    canonical_payload_sha256 as layout_payload_sha256,
)
from document_sdk.pdf._structural_engine.layout.identifiers import (
    layout_graph_identifier,
    layout_node_identifier,
    layout_page_identifier,
    layout_settings_digest,
    source_fact_artifact_digest,
)
from document_sdk.pdf._structural_engine.layout.normalization import LayoutSourceFact
from document_sdk.pdf._structural_engine.structure.document_table_contracts import (
    PdfDocumentTable,
    PdfDocumentTableManifest,
    PdfTablePageTransition,
)
from document_sdk.pdf._structural_engine.structure.document_table_fingerprint import (
    PdfTableTransitionFingerprint,
    validate_transition_fingerprint_dependency,
)
from document_sdk.pdf._structural_engine.structure.identity import (
    canonical_json_bytes,
    canonical_sha256,
)
from document_sdk.pdf._structural_engine.structure.reading_contracts import (
    PdfReadingStructuralBlock,
    PdfReadingStructurePageSidecar,
)
from document_sdk.pdf._structural_engine.structure.reading_member_runs import (
    _literal_fact,
    _native_chain,
    _native_inventory,
)
from document_sdk.pdf._structural_engine.structure.table_contracts import (
    PdfTable,
    PdfTableStructurePageSidecar,
)
from document_sdk.pdf._structural_engine.structure.table_document_manifest import (
    PdfTableDocumentManifest,
)
from document_sdk.pdf._structural_engine.structure.table_member_views import (
    validate_member_bindings,
    validate_table_text_projections,
)

from .contracts import (
    CANONICAL_PROJECTION_VERSION,
    CANONICAL_SCHEMA_VERSION,
    CanonicalAvailability,
    CanonicalAvailabilityState,
    CanonicalBoundingBox,
    CanonicalCapabilityAvailability,
    CanonicalDocument,
    CanonicalDocumentTable,
    CanonicalDrawing,
    CanonicalLogicalRow,
    CanonicalPage,
    CanonicalPageBox,
    CanonicalPageGeometry,
    CanonicalProjectionLimits,
    CanonicalProvenance,
    CanonicalRepeatedHeaderEvidence,
    CanonicalSplitRowEvidence,
    CanonicalTable,
    CanonicalTableCell,
    CanonicalTableColumn,
    CanonicalTableRow,
    CanonicalTextBlock,
    CanonicalTextSpan,
    CanonicalTransition,
    CanonicalTransitionColumnContinuity,
    CanonicalTransitionColumnMapping,
    CanonicalTransitionFingerprint,
    CanonicalTransitionHeaderContinuity,
    CanonicalTransitionPagePairGeometry,
    CanonicalTransitionPairContext,
    CanonicalTransitionRowCellContinuity,
    CanonicalTransitionSafetyState,
    CanonicalWarning,
    CanonicalWarningSuppression,
)
from .identifiers import canonical_identifier, canonical_payload_bytes
from .validation import (
    CanonicalJoinError,
    CanonicalLimitExceeded,
    CanonicalProjectionError,
)


class CanonicalArtifactBundle(BaseModel):
    """Typed, path-free input; projection cannot reopen the source PDF."""

    model_config = ConfigDict(
        extra="forbid",
        frozen=True,
        hide_input_in_errors=True,
        strict=True,
    )

    facts: PdfFactArtifact = Field(repr=False)
    layout: PdfLayoutGraphArtifact | None = Field(default=None, repr=False)
    reading_pages: tuple[PdfReadingStructurePageSidecar, ...] = Field(
        default=(),
        repr=False,
    )
    table_pages: tuple[PdfTableStructurePageSidecar, ...] = Field(
        default=(),
        repr=False,
    )
    table_manifest: PdfTableDocumentManifest | None = Field(
        default=None,
        repr=False,
    )
    transitions: tuple[PdfTablePageTransition, ...] = Field(default=(), repr=False)
    document_tables: tuple[PdfDocumentTable, ...] = Field(default=(), repr=False)
    document_table_manifest: PdfDocumentTableManifest | None = Field(
        default=None,
        repr=False,
    )
    transition_fingerprints: tuple[PdfTableTransitionFingerprint, ...] = Field(
        default=(),
        repr=False,
    )

    @model_validator(mode="after")
    def validate_distinct_page_inputs(self) -> Self:
        inventories = (
            tuple(item.page_index for item in self.reading_pages),
            tuple(item.page_index for item in self.table_pages),
        )
        if any(len(values) != len(set(values)) for values in inventories):
            message = "artifact bundle repeats a page-local authority"
            raise ValueError(message)
        identity_inventories = (
            tuple(item.transition_id for item in self.transitions),
            tuple(item.document_table_id for item in self.document_tables),
            tuple(item.fingerprint_id for item in self.transition_fingerprints),
            tuple(item.transition_id for item in self.transition_fingerprints),
        )
        if any(len(values) != len(set(values)) for values in identity_inventories):
            message = "artifact bundle repeats document-table authority"
            raise ValueError(message)
        return self


def _bbox(value: PdfBoundingBox) -> CanonicalBoundingBox:
    return CanonicalBoundingBox(
        x0=value.x0,
        y0=value.y0,
        x1=value.x1,
        y1=value.y1,
    )


def _page_box(value: PdfPageBox) -> CanonicalPageBox:
    return CanonicalPageBox(x0=value.x0, y0=value.y0, x1=value.x1, y1=value.y1)


def _availability(
    state: CanonicalAvailabilityState,
    *reason_codes: str,
) -> CanonicalAvailability:
    reasons = tuple(sorted(set(reason_codes)))
    return CanonicalAvailability(state=state, reason_codes=reasons)


def _extraction_availability(
    status: PdfExtractionStatus,
    *,
    reason_prefix: str = "UPSTREAM",
) -> CanonicalAvailability:
    if status is PdfExtractionStatus.SUCCESS:
        return _availability("AVAILABLE")
    if status is PdfExtractionStatus.NO_TEXT_LAYER:
        return _availability("LIMITED_EVIDENCE", "NO_TEXT_LAYER")
    reason = f"{reason_prefix}_{status.value.upper()}"
    if status in {
        PdfExtractionStatus.PARTIAL,
        PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED,
    }:
        return _availability("PARTIAL", reason)
    if status in {
        PdfExtractionStatus.UNSUPPORTED,
        PdfExtractionStatus.INVALID_REQUEST,
    }:
        return _availability("UNSUPPORTED", reason)
    return _availability("UNAVAILABLE", reason)


def _page_availability(page: PdfPageFacts) -> CanonicalAvailability:
    return _extraction_availability(page.extraction_status)


def _layout_availability(
    layout: PdfLayoutGraphArtifact | None,
) -> CanonicalAvailability:
    if layout is None:
        return _availability("UNAVAILABLE", "LAYOUT_UNAVAILABLE")
    availability = _extraction_availability(
        layout.build_status,
        reason_prefix="UPSTREAM_LAYOUT",
    )
    if not layout.partial_build:
        return availability
    reasons = set(availability.reason_codes)
    reasons.add("LAYOUT_PARTIAL")
    if availability.state == "AVAILABLE":
        return _availability("PARTIAL", *reasons)
    return _availability(availability.state, *reasons)


def _table_availability(state: str) -> CanonicalAvailability:
    if state in {"COMPLETE", "PROVEN", "PROVEN_EMPTY"}:
        return _availability("AVAILABLE")
    if state == "UNAVAILABLE":
        return _availability("UNAVAILABLE", "UPSTREAM_TABLE_VALUE_UNAVAILABLE")
    if state == "UNSUPPORTED":
        return _availability("UNSUPPORTED", "UPSTREAM_TABLE_UNSUPPORTED")
    if state == "AMBIGUOUS":
        return _availability("LIMITED_EVIDENCE", "UPSTREAM_TABLE_AMBIGUOUS")
    return _availability("PARTIAL", "UPSTREAM_TABLE_PARTIAL")


def _with_borderless_intent_ambiguity(
    availability: CanonicalAvailability,
    *,
    ambiguous: bool,
) -> CanonicalAvailability:
    """Add intent uncertainty without weakening a stronger upstream state."""
    if not ambiguous:
        return availability
    reasons = set(availability.reason_codes)
    reasons.add("BORDERLESS_TABLE_INTENT_AMBIGUOUS")
    state = (
        "LIMITED_EVIDENCE" if availability.state == "AVAILABLE" else availability.state
    )
    return _availability(state, *reasons)


def _page_table_availability(
    sidecar: PdfTableStructurePageSidecar | None,
) -> CanonicalAvailability:
    if sidecar is None:
        return _availability("UNAVAILABLE", "PAGE_TABLE_UNAVAILABLE")
    borderless_ambiguous = any(
        "borderless_table_intent_not_independently_proven" in table.limitation_codes
        for table in sidecar.tables
    )
    if sidecar.outcome in {"COMPLETE", "NO_TABLE"}:
        base = _availability("AVAILABLE")
    else:
        reasons = tuple(sidecar.limitation_codes) or (f"PAGE_TABLE_{sidecar.outcome}",)
        if sidecar.outcome in {
            "UNAVAILABLE",
            "IMAGE_ONLY_OCR_REQUIRED",
            "LEGACY_ENCODING_UNRELIABLE",
        }:
            base = _availability("UNAVAILABLE", *reasons)
        else:
            availability_state: Literal[
                "UNSUPPORTED", "LIMITED_EVIDENCE", "PARTIAL"
            ] = "PARTIAL"
            if sidecar.outcome == "UNSUPPORTED":
                availability_state = "UNSUPPORTED"
            elif sidecar.outcome == "AMBIGUOUS":
                availability_state = "LIMITED_EVIDENCE"
            base = _availability(availability_state, *reasons)
    return _with_borderless_intent_ambiguity(
        base,
        ambiguous=borderless_ambiguous,
    )


def _reading_page_availability(
    sidecar: PdfReadingStructurePageSidecar,
) -> CanonicalAvailability:
    reasons = tuple(sidecar.limitation_codes) or (
        f"READING_STRUCTURE_{sidecar.state.upper()}",
    )
    if sidecar.state == "complete":
        return _availability("AVAILABLE")
    if sidecar.state == "partial":
        return _availability("PARTIAL", *reasons)
    if sidecar.state == "review_required":
        return _availability("LIMITED_EVIDENCE", *reasons)
    if sidecar.state == "unsupported":
        return _availability("UNSUPPORTED", *reasons)
    return _availability("UNAVAILABLE", *reasons)


def _aggregate_layer_availability(
    values: tuple[CanonicalAvailability, ...],
    *,
    expected_count: int,
    unavailable_reason: str,
    partial_reason: str,
) -> CanonicalAvailability:
    if not values:
        return _availability("UNAVAILABLE", unavailable_reason)
    reasons = {reason for item in values for reason in item.reason_codes}
    if len(values) != expected_count:
        reasons.add(partial_reason)
        return _availability("PARTIAL", *reasons)
    states: set[CanonicalAvailabilityState] = {item.state for item in values}
    if states == {"AVAILABLE"}:
        return _availability("AVAILABLE")
    if len(states) == 1:
        state: CanonicalAvailabilityState = next(iter(states))
        return _availability(state, *(reasons or {partial_reason}))
    reasons.add(partial_reason)
    return _availability("PARTIAL", *reasons)


def _document_table_status_availability(status: str) -> CanonicalAvailability:
    if status == "COMPLETE":
        return _availability("AVAILABLE")
    reason = f"DOCUMENT_TABLE_{status}"
    if status in {"PARTIAL", "RESOURCE_LIMITED"}:
        return _availability("PARTIAL", reason)
    if status == "AMBIGUOUS":
        return _availability("LIMITED_EVIDENCE", reason)
    return _availability("UNSUPPORTED", reason)


def _manifest_limited_availability(
    availability: CanonicalAvailability,
    manifest: PdfDocumentTableManifest,
) -> CanonicalAvailability:
    reasons = set(availability.reason_codes)
    reasons.update(manifest.limitation_codes)
    if manifest.resource_limited_page_pair_count:
        reasons.add("DOCUMENT_TABLE_RESOURCE_LIMITED")
    if manifest.unavailable_adjacent_page_pair_count:
        reasons.add("DOCUMENT_TABLE_INPUT_UNAVAILABLE")
    if not reasons:
        return availability
    state = "PARTIAL" if availability.state == "AVAILABLE" else availability.state
    return _availability(state, *reasons)


def _document_table_availability(
    bundle: CanonicalArtifactBundle,
) -> CanonicalAvailability:
    manifest = bundle.document_table_manifest
    if manifest is None:
        return _availability("UNAVAILABLE", "DOCUMENT_TABLE_UNAVAILABLE")
    statuses = tuple(
        _document_table_status_availability(item.status)
        for item in bundle.document_tables
    )
    availability = (
        _aggregate_layer_availability(
            statuses,
            expected_count=len(bundle.document_tables),
            unavailable_reason="DOCUMENT_TABLE_UNAVAILABLE",
            partial_reason="DOCUMENT_TABLE_PARTIAL",
        )
        if statuses
        else _availability("AVAILABLE")
    )
    return _manifest_limited_availability(availability, manifest)


def _identified(
    model: type[BaseModel],
    *,
    field: str,
    kind: str,
    values: dict[str, object],
    identity_payload: object | None = None,
) -> BaseModel:
    payload = values if identity_payload is None else identity_payload
    return model.model_validate({field: canonical_identifier(kind, payload), **values})


def _page_geometry(page: PdfPageFacts) -> CanonicalPageGeometry:
    return CanonicalPageGeometry(
        rotation=page.rotation,
        canonical_width=page.canonical_width,
        canonical_height=page.canonical_height,
        media_box=_page_box(page.media_box),
        crop_box=_page_box(page.crop_box),
        effective_page_box=_page_box(page.effective_page_box),
        effective_page_box_basis=page.effective_page_box_basis,
        effective_origin_x=page.effective_origin_x,
        effective_origin_y=page.effective_origin_y,
        user_unit=page.user_unit,
    )


def _page_identity(page: PdfPageFacts) -> str:
    geometry = _page_geometry(page)
    return canonical_identifier(
        "page",
        {
            "source_page_id": page.page_id,
            "page_index": page.page_number - 1,
            "page_number": page.page_number,
            "geometry": geometry,
        },
    )


def _fact_inventory(page: PdfPageFacts) -> dict[str, PdfTextFact]:
    return {
        item.fact_id: item
        for item in (
            *page.text_spans,
            *page.words,
            *page.line_candidates,
            *page.characters,
        )
    }


def _layout_fact_inventory(
    page: PdfPageFacts,
) -> dict[str, tuple[LayoutSourceFact, PdfLayoutNodeType]]:
    result: dict[str, tuple[LayoutSourceFact, PdfLayoutNodeType]] = {}
    for text_span in page.text_spans:
        result[text_span.fact_id] = (text_span, "text_span")
    for word in page.words:
        result[word.fact_id] = (word, "word")
    for line_candidate in page.line_candidates:
        result[line_candidate.fact_id] = (line_candidate, "line_candidate")
    for drawing in page.drawings:
        result[drawing.fact_id] = (drawing, "drawing")
    for image_region in page.image_regions:
        result[image_region.fact_id] = (image_region, "image_region")
    return result


def _layout_geometry_quality(
    fact: LayoutSourceFact,
    *,
    artifact: PdfFactArtifact,
) -> PdfLayoutGeometryQuality:
    if (
        isinstance(fact, PdfTextFact)
        and fact.bbox.x0 == fact.bbox.x1
        and fact.bbox.y0 < fact.bbox.y1
    ):
        # A retained source anchor has no measured glyph width. Derive this
        # limitation from the immutable Fact, never the node's claimed quality
        # or the parser's page-wide capability. Exact binding still requires
        # the unchanged source bbox and unavailable geometry confidence.
        return "unknown"
    if any(
        warning.code is PdfWarningCode.APPROXIMATE_BBOX for warning in fact.warnings
    ):
        return "approximate"
    if isinstance(fact, PdfDrawingFact):
        return fact.bbox_semantics.quality
    if isinstance(fact, PdfImageRegionFact):
        return "precise" if fact.parser_available else "unknown"
    quality_by_capability: dict[str, PdfLayoutGeometryQuality] = {
        "precise": "precise",
        "anchor": "approximate",
    }
    return quality_by_capability.get(
        artifact.parser_capabilities.text_bbox_quality, "unknown"
    )


def _layout_node_exactly_binds_fact(
    node: PdfLayoutNode,
    *,
    fact: LayoutSourceFact,
    expected_node_type: PdfLayoutNodeType,
    artifact: PdfFactArtifact,
    page_graph_id: str,
) -> bool:
    geometry_quality = _layout_geometry_quality(fact, artifact=artifact)
    expected_confidence = {
        "precise": ("available", 1.0),
        "approximate": ("available", 0.75),
        "unknown": ("unavailable", None),
    }[geometry_quality]
    expected_warning_codes = tuple(
        sorted({warning.code for warning in fact.warnings}, key=lambda item: item.value)
    )
    return (
        node.node_id
        == layout_node_identifier(
            page_graph_id=page_graph_id,
            source_fact_id=fact.fact_id,
            node_type=expected_node_type,
        )
        and node.source_page_id == fact.page_id
        and node.source_fact_id == fact.fact_id
        and node.node_type == expected_node_type
        and node.drawing_kind
        == (fact.kind if isinstance(fact, PdfDrawingFact) else None)
        and node.bbox == fact.bbox
        and node.rotation == getattr(fact, "rotation", None)
        and node.source_order == fact.source_order
        and node.geometry_quality == geometry_quality
        and node.parser_name == artifact.parser_name
        and node.parser_version == artifact.parser_version
        and node.source_warning_codes == expected_warning_codes
        and (node.confidence.availability, node.confidence.value) == expected_confidence
    )


def _layout_graph_digest(artifact: PdfLayoutGraphArtifact) -> str:
    deterministic_pages: list[dict[str, object]] = []
    for page in artifact.pages:
        page_payload = page.model_dump(mode="json")
        resource_usage = dict(page_payload["resource_usage"])
        resource_usage.pop("build_elapsed_milliseconds", None)
        resource_usage.pop("stage_timings", None)
        page_payload["resource_usage"] = resource_usage
        deterministic_pages.append(page_payload)
    return layout_payload_sha256(
        {
            "schema_version": artifact.schema_version,
            "layout_graph_id": artifact.layout_graph_id,
            "source_fact_artifact_sha256": artifact.source_fact_artifact_sha256,
            "builder_name": artifact.graph_builder_name,
            "builder_version": artifact.graph_builder_version,
            "status": artifact.build_status.value,
            "limits": artifact.applied_limits.model_dump(mode="json"),
            "options": artifact.build_options.model_dump(mode="json"),
            "warnings": [item.model_dump(mode="json") for item in artifact.warnings],
            "warning_suppression": artifact.warning_suppression.model_dump(mode="json"),
            "pages": deterministic_pages,
        }
    )


def _span(
    fact: PdfTextFact,
    *,
    span_index: int,
    layout_node_id: str | None,
    availability: CanonicalAvailability,
) -> CanonicalTextSpan:
    values: dict[str, object] = {
        "source_fact_id": fact.fact_id,
        "source_layout_node_id": layout_node_id,
        "span_index": span_index,
        "text": fact.text,
        "bbox": _bbox(fact.bbox),
        "font_name": fact.font_name,
        "font_size": fact.font_size,
        "rotation": fact.rotation,
        "availability": availability,
    }
    return CanonicalTextSpan.model_validate(
        _identified(
            CanonicalTextSpan,
            field="span_id",
            kind="text-span",
            values=values,
        )
    )


def _projection_block_has_precise_upright_sources(
    block: PdfReadingStructuralBlock,
    *,
    facts: dict[str, PdfTextFact],
    nodes: dict[str, PdfLayoutNode],
    fact_counts: dict[str, int],
) -> bool:
    """Require the exact existing Fact/Layout links; never infer missing geometry."""
    if not block.fragments:
        return False
    boxes = []
    for fragment in block.fragments:
        fact = facts.get(fragment.fact_id)
        node = nodes.get(fragment.layout_node_id)
        if (
            fact is None
            or node is None
            or fact_counts.get(fragment.fact_id) != 1
            or node.source_fact_id != fragment.fact_id
            or node.source_page_id != fact.page_id
            or node.geometry_quality != "precise"
            or node.rotation != 0
            or fact.rotation != 0
            or node.bbox != fact.bbox
            or fragment.canonical_bbox != fact.bbox
            or fragment.text != fact.text
            or fact.bbox.x0 >= fact.bbox.x1
            or fact.bbox.y0 >= fact.bbox.y1
        ):
            return False
        boxes.append(fact.bbox)
    box = block.canonical_bbox
    return (
        box.x0 == min(item.x0 for item in boxes)
        and box.y0 == min(item.y0 for item in boxes)
        and box.x1 == max(item.x1 for item in boxes)
        and box.y1 == max(item.y1 for item in boxes)
    )


_NATIVE_CANDIDATE_PAIR_SIZE = 2


def _native_candidate_projection_ids(  # noqa: PLR0911
    sidecar: PdfReadingStructurePageSidecar,
    remaining: tuple[str, ...],
    *,
    page: PdfPageFacts,
    layout_page: PdfLayoutPageGraph | None,
) -> tuple[str, ...]:
    """Serialize a candidate header pair using consistent same-event evidence.

    Every event shared by the pair must have a complete, unique, exact and
    admitted projection. Conflicting or interleaved intervals keep the prior
    order. Different events never supply an ordering edge, and the accepted
    Reading graph, block roles and unresolved dispositions remain unchanged.
    """
    if (
        len(remaining) != _NATIVE_CANDIDATE_PAIR_SIZE
        or page.rotation != 0
        or layout_page is None
        or sidecar.page_id != page.page_id
    ):
        return remaining
    inventory = _native_inventory(
        page, sidecar.source_sha256, allow_excluded_source=True
    )
    evidence = page.native_text_event_evidence
    if inventory is None or evidence is None:
        return remaining
    members = {member.member_id: member for member in inventory}
    source_by_event = defaultdict(list)
    for member in inventory:
        source_by_event[member.native_text_event_id].append(member)
    facts = _fact_inventory(page)
    nodes = {node.node_id: node for node in layout_page.nodes}
    groups = {group.source_group_id: group for group in page.text_source_groups}
    if len(groups) != len(page.text_source_groups):
        return remaining
    fact_counts: dict[str, int] = defaultdict(int)
    member_counts: dict[str, int] = defaultdict(int)
    for block in sidecar.blocks:
        for fragment in block.fragments:
            fact_counts[fragment.fact_id] += 1
            fact = facts.get(fragment.fact_id)
            if fact is not None:
                for member_id in fact.member_ids:
                    member_counts[member_id] += 1
    by_id = {block.block_id: block for block in sidecar.blocks}
    projections: list[dict[str, list[str]]] = []
    for block_id in remaining:
        block = by_id[block_id]
        if (
            block.role != "header"
            or block.role_status != "candidate"
            or not _projection_block_has_precise_upright_sources(
                block, facts=facts, nodes=nodes, fact_counts=fact_counts
            )
        ):
            return remaining
        projected: dict[str, list[str]] = defaultdict(list)
        for fragment in block.fragments:
            fact = facts[fragment.fact_id]
            selected = tuple(members[mid] for mid in fact.member_ids if mid in members)
            group = groups.get(fact.source_group_id or "")
            if (
                not selected
                or len(selected) != len(fact.member_ids)
                or not _literal_fact(fact, selected)
                or group is None
                or group.disposition != "ADMITTED"
                or group.parent_fact_id != fact.fact_id
                or group.member_ids != fact.member_ids
                or group.member_projection != fact.member_projection
                or group.text != fact.text
                or any(
                    member.geometry_status != "INSIDE"
                    or member.selection_state != "RETAINED"
                    or member_counts[member.member_id] != 1
                    for member in selected
                )
            ):
                return remaining
            for member in selected:
                if (
                    not member.text.isspace()
                    and member.native_text_event_id is not None
                ):
                    projected[member.native_text_event_id].append(member.member_id)
        for ids in projected.values():
            ordinals = [members[mid].source_character_index for mid in ids]
            if ordinals != sorted(ordinals):
                return remaining
        projections.append(projected)
    left, right = projections
    shared = left.keys() & right.keys()
    directions: set[str] = set()
    for event in evidence.events:
        event_id = event.source_event_id
        if event_id not in shared:
            continue
        source = tuple(source_by_event[event_id])
        projected_ids = (*left[event_id], *right[event_id])
        expected = {m.member_id for m in source if not m.text.isspace()}
        if (
            event.operator != "Tj"
            or event.numeric_adjustment_count
            or set(projected_ids) != expected
            or len(projected_ids) != len(expected)
            or not _native_chain(source, (0.0, 0.0))
            or any(
                m.rotation != 0
                or m.geometry_status != "INSIDE"
                or m.selection_state != "RETAINED"
                for m in source
            )
        ):
            return remaining
        left_bounds = [members[mid].source_character_index for mid in left[event_id]]
        right_bounds = [members[mid].source_character_index for mid in right[event_id]]
        if left_bounds[-1] < right_bounds[0]:
            directions.add("FORWARD")
        elif right_bounds[-1] < left_bounds[0]:
            directions.add("REVERSE")
        else:
            return remaining
    return tuple(reversed(remaining)) if directions == {"REVERSE"} else remaining


def _reading_projection_ids(
    sidecar: PdfReadingStructurePageSidecar,
    *,
    page: PdfPageFacts,
    layout_page: PdfLayoutPageGraph | None,
) -> tuple[tuple[str, ...], dict[str, str]]:
    """Anchor physically separate margins without changing authorized Reading order.

    This is an output serialization position, not a new accepted Reading edge.
    Role, source memberships, incomplete status and unresolved reasons stay intact.
    """
    by_id = {block.block_id: block for block in sidecar.blocks}
    primary = sidecar.reading_order.ordered_block_ids
    remaining = tuple(sorted(set(by_id) - set(primary)))
    remaining = _native_candidate_projection_ids(
        sidecar, remaining, page=page, layout_page=layout_page
    )
    original = (*primary, *remaining)
    dispositions = dict.fromkeys(remaining, "UNANCHORED_ROLE_OR_POSITION")
    if not remaining:
        return original, dispositions
    if not primary or layout_page is None or page.rotation != 0:
        return original, dict.fromkeys(remaining, "NO_UPRIGHT_AUTHORIZED_LAYOUT_ANCHOR")
    if sidecar.reading_order.unresolved_components:
        return original, dict.fromkeys(
            remaining, "READING_COMPONENT_ALREADY_UNRESOLVED"
        )
    facts = _fact_inventory(page)
    nodes = {node.node_id: node for node in layout_page.nodes}
    fact_counts: dict[str, int] = {}
    for block in sidecar.blocks:
        for fragment in block.fragments:
            fact_counts[fragment.fact_id] = fact_counts.get(fragment.fact_id, 0) + 1
    if any(
        not _projection_block_has_precise_upright_sources(
            block, facts=facts, nodes=nodes, fact_counts=fact_counts
        )
        for block in sidecar.blocks
    ):
        return original, dict.fromkeys(
            remaining, "SOURCE_GEOMETRY_OR_MEMBERSHIP_UNPROVED"
        )
    first = by_id[primary[0]].canonical_bbox
    last = by_id[primary[-1]].canonical_bbox
    body_top = min(by_id[block_id].canonical_bbox.y0 for block_id in primary)
    body_bottom = max(by_id[block_id].canonical_bbox.y1 for block_id in primary)
    before: list[str] = []
    after: list[str] = []
    for block_id in remaining:
        block = by_id[block_id]
        box = block.canonical_bbox
        if block.role_status == "rejected":
            dispositions[block_id] = "REJECTED_ROLE_NOT_USED_AS_ANCHOR"
        elif (
            block.role == "header"
            and box.y1 <= body_top
            and max(box.x0, first.x0) < min(box.x1, first.x1)
        ):
            before.append(block_id)
        elif (
            block.role == "footer"
            and box.y0 >= body_bottom
            and max(box.x0, last.x0) < min(box.x1, last.x1)
        ):
            after.append(block_id)
    for selected in (before, after):
        selected.sort(key=lambda block_id: by_id[block_id].canonical_bbox.y0)
        if any(
            by_id[left].canonical_bbox.y1 > by_id[right].canonical_bbox.y0
            for left, right in pairwise(selected)
        ):
            for block_id in selected:
                dispositions[block_id] = "MARGINAL_BLOCKS_OVERLAP_NO_UNIQUE_ORDER"
            selected.clear()
    # A detached or unplaced item above/below the proposed margins prevents a
    # global first/last assertion. Never promote an arbitrary partial anchor.
    if before:
        before_ids = set(before)
        bound = by_id[before[-1]].canonical_bbox.y1
        if any(
            block.canonical_bbox.y0 < bound
            for block in sidecar.blocks
            if block.block_id not in before_ids
        ):
            for block_id in before:
                dispositions[block_id] = "OTHER_CONTENT_PREVENTS_GLOBAL_PREFIX"
            before.clear()
    if after:
        after_ids = set(after)
        bound = by_id[after[0]].canonical_bbox.y0
        if any(
            block.canonical_bbox.y1 > bound
            for block in sidecar.blocks
            if block.block_id not in after_ids
        ):
            for block_id in after:
                dispositions[block_id] = "OTHER_CONTENT_PREVENTS_GLOBAL_SUFFIX"
            after.clear()
    for block_id in before:
        dispositions[block_id] = "PHYSICALLY_SEPARATE_PREFIX_ROLE_UNCHANGED"
    for block_id in after:
        dispositions[block_id] = "PHYSICALLY_SEPARATE_SUFFIX_ROLE_UNCHANGED"
    anchored = set(before) | set(after)
    fallback = tuple(block_id for block_id in remaining if block_id not in anchored)
    return (*before, *primary, *fallback, *after), dispositions


def _reading_blocks(
    sidecar: PdfReadingStructurePageSidecar,
    *,
    page: PdfPageFacts,
    page_id: str,
    layout_page: PdfLayoutPageGraph | None,
) -> tuple[CanonicalTextBlock, ...]:
    by_id = {item.block_id: item for item in sidecar.blocks}
    authorized_order_ids = set(sidecar.reading_order.ordered_block_ids)
    unresolved_block_ids = (set(by_id) - authorized_order_ids) | {
        block_id
        for component in sidecar.reading_order.unresolved_components
        for block_id in component
    }
    ordered_ids, _projection_dispositions = _reading_projection_ids(
        sidecar, page=page, layout_page=layout_page
    )
    fact_by_id = _fact_inventory(page)
    result = []
    for block_index, block_id in enumerate(ordered_ids):
        block = by_id[block_id]
        state_by_upstream: dict[str, CanonicalAvailabilityState] = {
            "complete": "AVAILABLE",
            "partial": "PARTIAL",
            "review_required": "LIMITED_EVIDENCE",
            "unsupported": "UNSUPPORTED",
            "unavailable": "UNAVAILABLE",
        }
        state = state_by_upstream[block.state]
        reasons = set(block.limitation_codes)
        if state == "AVAILABLE" and reasons:
            state = "LIMITED_EVIDENCE"
        if state != "AVAILABLE" and not reasons:
            reasons.add(f"READING_BLOCK_{block.state.upper()}")
        if block_id in unresolved_block_ids:
            reasons.add("READING_ORDER_UNRESOLVED")
            if state == "AVAILABLE":
                state = "LIMITED_EVIDENCE"
        availability = _availability(state, *reasons)
        spans = []
        for span_index, fragment in enumerate(block.fragments):
            try:
                fact = fact_by_id[fragment.fact_id]
            except KeyError:
                raise CanonicalJoinError(
                    "reading fragment references a missing Fact"
                ) from None
            if fragment.text != fact.text or fragment.canonical_bbox != fact.bbox:
                raise CanonicalJoinError(
                    "reading fragment content or geometry mismatches its Fact"
                )
            spans.append(
                _span(
                    fact,
                    span_index=span_index,
                    layout_node_id=fragment.layout_node_id,
                    availability=availability,
                )
            )
        values: dict[str, object] = {
            "page_id": page_id,
            "source_block_id": block.block_id,
            "block_index": block_index,
            "text": block.normalized_text,
            "bbox": _bbox(block.canonical_bbox),
            "spans": tuple(spans),
            "role": block.role,
            "role_status": block.role_status,
            "availability": availability,
            "limitation_codes": tuple(sorted(reasons)),
        }
        result.append(
            CanonicalTextBlock.model_validate(
                _identified(
                    CanonicalTextBlock,
                    field="text_block_id",
                    kind="text-block",
                    values=values,
                )
            )
        )
    return tuple(result)


def _fallback_blocks(
    page: PdfPageFacts,
    *,
    page_id: str,
    layout_page: PdfLayoutPageGraph | None,
) -> tuple[CanonicalTextBlock, ...]:
    if layout_page is None:
        return ()
    fact_by_id = _fact_inventory(page)
    ordered: list[tuple[PdfTextFact, str | None]] = []
    seen: set[str] = set()
    nodes = sorted(
        (
            node
            for node in layout_page.nodes
            if node.node_type in {"text_span", "word", "line_candidate"}
            and node.text_layer_role == "primary"
        ),
        key=lambda node: (node.source_order, node.node_id),
    )
    for node in nodes:
        fact = fact_by_id.get(node.source_fact_id)
        if fact is not None and fact.fact_id not in seen:
            ordered.append((fact, node.node_id))
            seen.add(fact.fact_id)
    availability = _availability(
        "LIMITED_EVIDENCE",
        "READING_STRUCTURE_UNAVAILABLE",
    )
    result = []
    for block_index, (fact, layout_node_id) in enumerate(ordered):
        spans = (
            _span(
                fact,
                span_index=0,
                layout_node_id=layout_node_id,
                availability=availability,
            ),
        )
        values: dict[str, object] = {
            "page_id": page_id,
            "source_block_id": None,
            "block_index": block_index,
            "text": fact.text,
            "bbox": _bbox(fact.bbox),
            "spans": spans,
            "role": "unknown_text",
            "role_status": "review_required",
            "availability": availability,
            "limitation_codes": ("READING_STRUCTURE_UNAVAILABLE",),
        }
        result.append(
            CanonicalTextBlock.model_validate(
                _identified(
                    CanonicalTextBlock,
                    field="text_block_id",
                    kind="text-block",
                    values=values,
                )
            )
        )
    return tuple(result)


def _canonical_tables(
    table_pages: tuple[PdfTableStructurePageSidecar, ...],
    *,
    page_ids: dict[int, str],
) -> tuple[CanonicalTable, ...]:
    result = []
    for sidecar in sorted(table_pages, key=lambda item: item.page_index):
        try:
            page_id = page_ids[sidecar.page_index]
        except KeyError:
            raise CanonicalJoinError(
                "table sidecar references an unavailable canonical page"
            ) from None
        for table in sorted(sidecar.tables, key=lambda item: item.table_index):
            table_bbox = _bbox(table.geometry)
            table_identity_payload = {
                "page_id": page_id,
                "source_table_id": table.table_id,
                "table_ordinal": table.table_index,
                "bbox": table_bbox,
                "state": table.state,
            }
            table_id = canonical_identifier("table", table_identity_payload)
            source_rows = {item.row_index: item for item in table.rows}
            row_ids = {
                row_index: canonical_identifier(
                    "table-row",
                    {
                        "table_id": table_id,
                        "source_row_id": row.row_id,
                        "row_index": row_index,
                        "bbox": _bbox(row.geometry),
                    },
                )
                for row_index, row in source_rows.items()
            }
            source_columns = {item.column_index: item for item in table.columns}
            column_ids = {
                column_index: canonical_identifier(
                    "table-column",
                    {
                        "table_id": table_id,
                        "source_column_id": column.column_id,
                        "column_index": column_index,
                        "bbox": _bbox(column.geometry),
                    },
                )
                for column_index, column in source_columns.items()
            }
            cells = []
            cells_by_row: dict[int, list[str]] = defaultdict(list)
            cells_by_column: dict[int, list[str]] = defaultdict(list)
            for cell in sorted(
                table.cells,
                key=lambda item: (item.row_start, item.column_start, item.cell_id),
            ):
                row_id = row_ids[cell.row_start]
                text_available = cell.state == "PROVEN_EMPTY" or bool(
                    cell.text_fact_ids
                )
                values: dict[str, object] = {
                    "table_id": table_id,
                    "row_id": row_id,
                    "source_cell_id": cell.cell_id,
                    "row_index": cell.row_start,
                    "column_index": cell.column_start,
                    "row_span": cell.row_span,
                    "column_span": cell.column_span,
                    "text": cell.text if text_available else None,
                    "text_available": text_available,
                    "bbox": _bbox(cell.geometry),
                    "state": cell.state,
                    "role": cell.role,
                    "role_status": cell.role_status,
                    "availability": _table_availability(cell.state),
                    "limitation_codes": tuple(sorted(set(cell.limitation_codes))),
                }
                canonical_cell = CanonicalTableCell.model_validate(
                    _identified(
                        CanonicalTableCell,
                        field="cell_id",
                        kind="table-cell",
                        values=values,
                    )
                )
                cells.append(canonical_cell)
                cells_by_row[cell.row_start].append(canonical_cell.cell_id)
                cells_by_column[cell.column_start].append(canonical_cell.cell_id)
            rows = []
            for row_index, row in sorted(source_rows.items()):
                values = {
                    "table_id": table_id,
                    "source_row_id": row.row_id,
                    "row_index": row_index,
                    "cell_ids": tuple(cells_by_row[row_index]),
                    "bbox": _bbox(row.geometry),
                    "availability": _table_availability(table.state),
                }
                rows.append(
                    CanonicalTableRow.model_validate(
                        {
                            "row_id": row_ids[row_index],
                            **values,
                        }
                    )
                )
            columns = []
            for column_index, column in sorted(source_columns.items()):
                columns.append(
                    CanonicalTableColumn(
                        column_id=column_ids[column_index],
                        table_id=table_id,
                        source_column_id=column.column_id,
                        column_index=column_index,
                        cell_ids=tuple(cells_by_column[column_index]),
                        bbox=_bbox(column.geometry),
                        availability=_table_availability(table.state),
                    )
                )
            values = {
                "page_id": page_id,
                "source_table_id": table.table_id,
                "table_ordinal": table.table_index,
                "bbox": table_bbox,
                "row_count": len(table.rows),
                "column_count": len(table.columns),
                "rows": tuple(rows),
                "columns": tuple(columns),
                "cells": tuple(cells),
                "document_table_ids": (),
                "state": table.state,
                "availability": _with_borderless_intent_ambiguity(
                    _table_availability(table.state),
                    ambiguous=(
                        "borderless_table_intent_not_independently_proven"
                        in table.limitation_codes
                    ),
                ),
                "limitation_codes": tuple(sorted(set(table.limitation_codes))),
            }
            result.append(
                CanonicalTable.model_validate({"table_id": table_id, **values})
            )
    return tuple(result)


def _transition_availability(
    transition: PdfTablePageTransition,
) -> CanonicalAvailability:
    if transition.outcome in {
        "CONTINUATION_PROVEN",
        "REPEATED_HEADER_CONTINUATION",
        "SPLIT_ROW_CONTINUATION",
        "NOT_CONTINUOUS",
        "COLUMN_STRUCTURE_CHANGED",
    }:
        return _availability("AVAILABLE")
    reasons = tuple(transition.limitation_codes) or (
        f"TRANSITION_{transition.outcome}",
    )
    if transition.outcome in {"AMBIGUOUS_CONTINUATION", "MULTIPLE_CANDIDATES"}:
        return _availability("LIMITED_EVIDENCE", *reasons)
    if transition.outcome == "UNSUPPORTED_SOURCE":
        return _availability("UNSUPPORTED", *reasons)
    if transition.outcome == "UNAVAILABLE_UPSTREAM":
        return _availability("UNAVAILABLE", *reasons)
    return _availability("PARTIAL", *reasons)


def _canonical_fingerprint(
    fingerprint: PdfTableTransitionFingerprint,
) -> CanonicalTransitionFingerprint:
    return CanonicalTransitionFingerprint(
        source_fingerprint_id=fingerprint.fingerprint_id,
        semantic_fingerprint_identity=fingerprint.semantic_fingerprint_identity,
        feature_schema_version=fingerprint.feature_schema_version,
        state=fingerprint.state,
        source_sha256=fingerprint.source_sha256,
        source_document_identity=fingerprint.document_identity,
        page_table_manifest_sha256=fingerprint.page_table_manifest_sha256,
        source_transition_id=fingerprint.transition_id,
        left_page_index=fingerprint.left_page_index,
        right_page_index=fingerprint.right_page_index,
        left_page_id=fingerprint.left_page_id,
        right_page_id=fingerprint.right_page_id,
        left_source_table_id=fingerprint.left_table_id,
        right_source_table_id=fingerprint.right_table_id,
        left_table_sidecar_id=fingerprint.left_table_sidecar_id,
        right_table_sidecar_id=fingerprint.right_table_sidecar_id,
        left_table_sidecar_sha256=fingerprint.left_table_sidecar_sha256,
        right_table_sidecar_sha256=fingerprint.right_table_sidecar_sha256,
        left_configuration_identity=fingerprint.left_configuration_identity,
        right_configuration_identity=fingerprint.right_configuration_identity,
        left_dependency_identity=fingerprint.left_dependency_identity,
        right_dependency_identity=fingerprint.right_dependency_identity,
        page_pair_geometry=CanonicalTransitionPagePairGeometry.model_validate(
            fingerprint.page_pair_geometry.model_dump(mode="python")
        ),
        column_continuity=CanonicalTransitionColumnContinuity.model_validate(
            fingerprint.column_continuity.model_dump(mode="python")
        ),
        header_continuity=CanonicalTransitionHeaderContinuity.model_validate(
            fingerprint.header_continuity.model_dump(mode="python")
        ),
        row_cell_continuity=CanonicalTransitionRowCellContinuity.model_validate(
            fingerprint.row_cell_continuity.model_dump(mode="python")
        ),
        pair_context=CanonicalTransitionPairContext.model_validate(
            fingerprint.pair_context.model_dump(mode="python")
        ),
        safety_state=CanonicalTransitionSafetyState.model_validate(
            fingerprint.safety_state.model_dump(mode="python")
        ),
        limitation_codes=tuple(fingerprint.limitation_codes),
    )


def _canonical_transitions(
    transitions: tuple[PdfTablePageTransition, ...],
    *,
    table_ids_by_source: dict[tuple[int, str], str],
    row_ids_by_source: dict[tuple[int, str, str], str],
    cell_ids_by_source: dict[tuple[int, str, str], str],
    column_ids_by_source: dict[tuple[int, str, str], str],
    fingerprints_by_transition: dict[str, PdfTableTransitionFingerprint],
) -> tuple[CanonicalTransition, ...]:
    result = []
    for transition in sorted(
        transitions,
        key=lambda item: (
            item.left.page_index,
            item.left.table_id,
            item.right.table_id,
        ),
    ):
        try:
            left_key = (transition.left.page_index, transition.left.table_id)
            right_key = (transition.right.page_index, transition.right.table_id)
            left_table_id = table_ids_by_source[left_key]
            right_table_id = table_ids_by_source[right_key]
            column_mappings = tuple(
                CanonicalTransitionColumnMapping(
                    left_column_id=column_ids_by_source[
                        (*left_key, item.left_column_id)
                    ],
                    right_column_id=column_ids_by_source[
                        (*right_key, item.right_column_id)
                    ],
                    source_left_column_id=item.left_column_id,
                    source_right_column_id=item.right_column_id,
                    left_column_index=item.left_column_index,
                    right_column_index=item.right_column_index,
                    normalized_axis_distance=item.normalized_axis_distance,
                    width_ratio_difference=item.width_ratio_difference,
                    topology_compatible=item.topology_compatible,
                    evidence_strength=item.evidence_strength,
                    conflicting_evidence=item.conflicting_evidence,
                    reason_code=item.reason_code,
                )
                for item in transition.column_mappings
            )
            repeated_header_evidence = tuple(
                CanonicalRepeatedHeaderEvidence(
                    logical_header_identity=item.logical_header_identity,
                    left_row_ids=tuple(
                        row_ids_by_source[(*left_key, value)]
                        for value in item.left_row_ids
                    ),
                    right_row_ids=tuple(
                        row_ids_by_source[(*right_key, value)]
                        for value in item.right_row_ids
                    ),
                    left_cell_ids=tuple(
                        cell_ids_by_source[(*left_key, value)]
                        for value in item.left_cell_ids
                    ),
                    right_cell_ids=tuple(
                        cell_ids_by_source[(*right_key, value)]
                        for value in item.right_cell_ids
                    ),
                    source_left_row_ids=item.left_row_ids,
                    source_right_row_ids=item.right_row_ids,
                    source_left_cell_ids=item.left_cell_ids,
                    source_right_cell_ids=item.right_cell_ids,
                    occurrence_index=item.occurrence_index,
                    exact_symbolic_repeat=item.exact_symbolic_repeat,
                    topology_compatible=item.topology_compatible,
                )
                for item in transition.repeated_header_mappings
            )
            split_row_evidence = tuple(
                CanonicalSplitRowEvidence(
                    source_fragment_link_id=item.fragment_link_id,
                    left_row_id=row_ids_by_source[(*left_key, item.left_row_id)],
                    right_row_id=row_ids_by_source[(*right_key, item.right_row_id)],
                    left_cell_ids=tuple(
                        cell_ids_by_source[(*left_key, value)]
                        for value in item.left_cell_ids
                    ),
                    right_cell_ids=tuple(
                        cell_ids_by_source[(*right_key, value)]
                        for value in item.right_cell_ids
                    ),
                    source_left_row_id=item.left_row_id,
                    source_right_row_id=item.right_row_id,
                    source_left_cell_ids=item.left_cell_ids,
                    source_right_cell_ids=item.right_cell_ids,
                    mapped_column_indexes=item.mapped_column_indexes,
                    local_fragment_order=item.local_fragment_order,
                    physically_incomplete_left=item.physically_incomplete_left,
                    physically_compatible_right=item.physically_compatible_right,
                    conflicting_evidence=item.conflicting_evidence,
                )
                for item in transition.row_fragment_links
            )
        except KeyError:
            raise CanonicalJoinError(
                "transition references missing page-local canonical authority"
            ) from None
        fingerprint = fingerprints_by_transition.get(transition.transition_id)
        values: dict[str, object] = {
            "source_transition_id": transition.transition_id,
            "left_table_id": left_table_id,
            "right_table_id": right_table_id,
            "outcome": transition.outcome,
            "repeated_header": bool(transition.repeated_header_mappings),
            "split_row": bool(transition.row_fragment_links),
            "repeated_header_evidence_ids": tuple(
                sorted(
                    item.logical_header_identity
                    for item in transition.repeated_header_mappings
                )
            ),
            "split_row_evidence_ids": tuple(
                sorted(item.fragment_link_id for item in transition.row_fragment_links)
            ),
            "column_mappings": column_mappings,
            "repeated_header_evidence": repeated_header_evidence,
            "split_row_evidence": split_row_evidence,
            "table_geometry_compatible": transition.table_geometry_compatible,
            "topology_compatible": transition.topology_compatible,
            "page_boundary_evidence_strength": (
                transition.page_boundary_evidence_strength
            ),
            "fingerprint_support_strength": transition.fingerprint_support_strength,
            "candidate_pair_count": transition.candidate_pair_count,
            "algorithm_version": transition.algorithm_version,
            "source_fingerprint_id": (
                fingerprint.fingerprint_id if fingerprint is not None else None
            ),
            "semantic_fingerprint_identity": (
                fingerprint.semantic_fingerprint_identity
                if fingerprint is not None
                else None
            ),
            "fingerprint_state": (
                fingerprint.state if fingerprint is not None else None
            ),
            "fingerprint_limitation_codes": (
                tuple(sorted(set(fingerprint.limitation_codes)))
                if fingerprint is not None
                else ()
            ),
            "fingerprint": (
                _canonical_fingerprint(fingerprint) if fingerprint is not None else None
            ),
            "availability": _transition_availability(transition),
            "limitation_codes": tuple(sorted(set(transition.limitation_codes))),
        }
        result.append(
            CanonicalTransition.model_validate(
                _identified(
                    CanonicalTransition,
                    field="transition_id",
                    kind="transition",
                    values=values,
                )
            )
        )
    return tuple(result)


def _canonical_document_tables(
    document_tables: tuple[PdfDocumentTable, ...],
    *,
    table_ids_by_source: dict[tuple[int, str], str],
    row_ids_by_source: dict[tuple[int, str, str], str],
    cell_ids_by_source: dict[tuple[int, str, str], str],
    transition_ids_by_source: dict[str, str],
) -> tuple[CanonicalDocumentTable, ...]:
    result = []
    for document_table in sorted(
        document_tables,
        key=lambda item: item.document_table_id,
    ):
        try:
            table_ids = tuple(
                table_ids_by_source[(item.page_index, item.table_id)]
                for item in document_table.page_table_references
            )
            transition_ids = tuple(
                transition_ids_by_source[item] for item in document_table.transition_ids
            )
            local_row_ids_by_source = {
                source_row_id: row_ids_by_source[
                    (reference.page_index, reference.table_id, source_row_id)
                ]
                for reference in document_table.page_table_references
                for source_row_id in reference.source_row_ids
            }
            local_cell_ids_by_source = {
                source_cell_id: cell_ids_by_source[
                    (reference.page_index, reference.table_id, source_cell_id)
                ]
                for reference in document_table.page_table_references
                for source_cell_id in reference.source_cell_ids
            }
        except KeyError:
            raise CanonicalJoinError(
                "document table references missing table authority"
            ) from None
        logical_rows = []
        for row in document_table.logical_rows:
            try:
                row_ids = tuple(
                    local_row_ids_by_source[item] for item in row.fragment_row_ids
                )
                cell_ids = tuple(
                    local_cell_ids_by_source[item] for item in row.fragment_cell_ids
                )
            except KeyError:
                raise CanonicalJoinError(
                    "document logical row references missing Page Table authority"
                ) from None
            values: dict[str, object] = {
                "source_logical_row_id": row.logical_row_id,
                "row_ids": row_ids,
                "cell_ids": cell_ids,
                "source_row_ids": row.fragment_row_ids,
                "source_cell_ids": row.fragment_cell_ids,
                "source_page_indexes": row.source_page_indexes,
                "repeated_header_occurrence": row.repeated_header_occurrence,
                "limitation_codes": tuple(sorted(set(row.limitation_codes))),
            }
            logical_rows.append(
                CanonicalLogicalRow.model_validate(
                    _identified(
                        CanonicalLogicalRow,
                        field="logical_row_id",
                        kind="logical-row",
                        values=values,
                    )
                )
            )
        values = {
            "source_document_table_id": document_table.document_table_id,
            "table_ids": table_ids,
            "transition_ids": transition_ids,
            "logical_rows": tuple(logical_rows),
            "canonical_header_identity": document_table.canonical_header_identity,
            "repeated_header_identities": document_table.repeated_header_identities,
            "status": document_table.status,
            "limitation_codes": tuple(sorted(set(document_table.limitation_codes))),
        }
        result.append(
            CanonicalDocumentTable.model_validate(
                _identified(
                    CanonicalDocumentTable,
                    field="document_table_id",
                    kind="document-table",
                    values=values,
                )
            )
        )
    return tuple(result)


def _warning_inventory(
    facts: PdfFactArtifact,
    layout: PdfLayoutGraphArtifact | None,
) -> tuple[tuple[PdfFactWarning, str], ...]:
    items: list[tuple[PdfFactWarning, str]] = [
        (warning, "facts_artifact") for warning in facts.warnings
    ]
    for page in facts.pages:
        items.extend((warning, "facts_page") for warning in page.warnings)
        for entity, scope in (
            (page.text_spans, "facts_text_span"),
            (page.words, "facts_word"),
            (page.line_candidates, "facts_line_candidate"),
            (page.characters, "facts_character"),
            (page.drawings, "facts_drawing"),
            (page.image_regions, "facts_image"),
        ):
            items.extend(
                (warning, scope) for item in entity for warning in item.warnings
            )
    if layout is not None:
        items.extend((warning, "layout_artifact") for warning in layout.warnings)
        for layout_page in layout.pages:
            items.extend((warning, "layout_page") for warning in layout_page.warnings)
    return tuple(
        sorted(
            items,
            key=lambda item: (
                item[0].page_number or 0,
                item[0].fact_id or "",
                item[0].code.value,
                item[0].severity.value,
                item[0].message,
                item[1],
            ),
        )
    )


def _canonical_warnings(
    facts: PdfFactArtifact,
    layout: PdfLayoutGraphArtifact | None,
    *,
    page_ids_by_number: dict[int, str],
) -> tuple[CanonicalWarning, ...]:
    result = []
    for occurrence_index, (warning, scope) in enumerate(
        _warning_inventory(facts, layout)
    ):
        values: dict[str, object] = {
            "code": warning.code.value,
            "severity": warning.severity.value,
            "message": warning.message,
            "recoverable": warning.recoverable,
            "page_id": (
                page_ids_by_number.get(warning.page_number)
                if warning.page_number is not None
                else None
            ),
            "source_page_number": warning.page_number,
            "source_fact_id": warning.fact_id,
            "source_parser_name": warning.parser_name,
            "source_scope": scope,
            "occurrence_index": occurrence_index,
        }
        result.append(
            CanonicalWarning.model_validate(
                _identified(
                    CanonicalWarning,
                    field="warning_id",
                    kind="warning",
                    values=values,
                )
            )
        )
    return tuple(result)


def _canonical_warning_suppressions(
    facts: PdfFactArtifact,
    layout: PdfLayoutGraphArtifact | None,
) -> tuple[CanonicalWarningSuppression, ...]:
    result: list[CanonicalWarningSuppression] = []

    def append_summary(
        scope: Literal["facts", "layout"],
        summary: PdfWarningSuppressionSummary,
    ) -> None:
        if not summary.suppressed_warning_count:
            return
        result.append(
            CanonicalWarningSuppression(
                source_scope=scope,
                suppressed_warning_count=summary.suppressed_warning_count,
                suppressed_warning_count_by_code=tuple(
                    sorted(
                        (code.value, count)
                        for code, count in (
                            summary.suppressed_warning_count_by_code.items()
                        )
                    )
                ),
                suppressed_warning_count_by_scope=tuple(
                    sorted(summary.suppressed_warning_count_by_scope.items())
                ),
                suppressed_affected_page_count=(summary.suppressed_affected_page_count),
                suppressed_affected_fact_count=(summary.suppressed_affected_fact_count),
            )
        )

    append_summary("facts", facts.warning_suppression)
    if layout is not None:
        append_summary("layout", layout.warning_suppression)
    return tuple(result)


def _validate_bundle_joins(bundle: CanonicalArtifactBundle) -> None:
    facts = bundle.facts
    page_by_index = {item.page_number - 1: item for item in facts.pages}
    text_fact_ids_by_page = {
        index: set(_fact_inventory(page)) for index, page in page_by_index.items()
    }
    fact_ids_by_page = {
        index: (
            {
                item.fact_id
                for item in (
                    *page.text_spans,
                    *page.words,
                    *page.line_candidates,
                    *page.characters,
                )
            }
            | {item.fact_id for item in page.drawings}
            | {item.fact_id for item in page.image_regions}
        )
        for index, page in page_by_index.items()
    }
    layout_facts_by_page = {
        index: _layout_fact_inventory(page) for index, page in page_by_index.items()
    }
    layout_node_ids_by_page: dict[int, set[str]] = {}
    layout_nodes_by_page: dict[int, dict[str, PdfLayoutNode]] = {}
    separator_candidate_ids_by_page: dict[int, set[str]] = {}
    if bundle.layout is not None:
        layout = bundle.layout
        expected_source_digest = source_fact_artifact_digest(facts)
        expected_layout_graph_id = layout_graph_identifier(
            source_fact_digest=expected_source_digest,
            builder_name=layout.graph_builder_name,
            builder_version=layout.graph_builder_version,
            settings_digest=layout_settings_digest(
                limits=layout.applied_limits,
                options=layout.build_options,
            ),
        )
        if (
            layout.source_document_id != facts.document_id
            or layout.source_fact_schema_version != facts.schema_version
            or layout.source_fact_artifact_sha256 != expected_source_digest
            or layout.source_parser_name != facts.parser_name
            or layout.source_parser_version != facts.parser_version
            or layout.source_page_count != facts.page_count
            or layout.source_extracted_page_count != facts.extracted_page_count
            or layout.source_document_partial_extraction
            != (
                facts.partial_extraction
                or not facts.extraction_scope_result.source_document_fully_extracted
            )
            or layout.layout_graph_id != expected_layout_graph_id
            or layout.graph_digest != _layout_graph_digest(layout)
        ):
            raise CanonicalJoinError("Layout authority does not bind the Fact artifact")
        if any(
            layout_page.page_number - 1 not in page_by_index
            or layout_page.page_graph_id
            != layout_page_identifier(
                layout_graph_id=layout.layout_graph_id,
                source_page_id=layout_page.source_page_id,
            )
            or layout_page.source_page_id
            != page_by_index[layout_page.page_number - 1].page_id
            or layout_page.canonical_width
            != page_by_index[layout_page.page_number - 1].canonical_width
            or layout_page.canonical_height
            != page_by_index[layout_page.page_number - 1].canonical_height
            or layout_page.rotation
            != page_by_index[layout_page.page_number - 1].rotation
            for layout_page in layout.pages
        ):
            raise CanonicalJoinError("Layout page authority does not bind Facts")
        for layout_page in layout.pages:
            page_index = layout_page.page_number - 1
            for node in layout_page.nodes:
                binding = layout_facts_by_page[page_index].get(node.source_fact_id)
                if binding is None or not _layout_node_exactly_binds_fact(
                    node,
                    fact=binding[0],
                    expected_node_type=binding[1],
                    artifact=facts,
                    page_graph_id=layout_page.page_graph_id,
                ):
                    raise CanonicalJoinError(
                        "Layout node does not exactly bind its source Fact"
                    )
        layout_node_ids_by_page = {
            item.page_number - 1: {node.node_id for node in item.nodes}
            for item in layout.pages
        }
        layout_nodes_by_page = {
            item.page_number - 1: {node.node_id: node for node in item.nodes}
            for item in layout.pages
        }
        separator_candidate_ids_by_page = {
            item.page_number - 1: {
                separator.separator_candidate_id
                for separator in item.separator_candidates
            }
            for item in layout.pages
        }
    fact_page_number_by_id = {
        fact_id: page_by_index[page_index].page_number
        for page_index, fact_ids in fact_ids_by_page.items()
        for fact_id in fact_ids
    }
    for warning, _scope in _warning_inventory(facts, bundle.layout):
        if warning.page_number is not None and warning.page_number > facts.page_count:
            raise CanonicalJoinError(
                "upstream warning references a page outside the source document"
            )
        if warning.fact_id is None:
            continue
        source_page_number = fact_page_number_by_id.get(warning.fact_id)
        if source_page_number is None or warning.page_number != source_page_number:
            raise CanonicalJoinError(
                "upstream warning does not bind its source Fact and page"
            )
    for reading_sidecar in bundle.reading_pages:
        page = page_by_index.get(reading_sidecar.page_index)
        if (
            page is None
            or reading_sidecar.page_id != page.page_id
            or reading_sidecar.source_sha256 != facts.source_sha256
        ):
            raise CanonicalJoinError("Reading authority does not bind Facts")
        if any(
            set(block.source_fact_ids)
            - text_fact_ids_by_page[reading_sidecar.page_index]
            for block in reading_sidecar.blocks
        ):
            raise CanonicalJoinError("Reading authority references a missing Fact")
        if bundle.layout is not None and any(
            set(block.source_node_ids)
            - layout_node_ids_by_page.get(reading_sidecar.page_index, set())
            for block in reading_sidecar.blocks
        ):
            raise CanonicalJoinError(
                "Reading authority references a missing Layout node"
            )
        if bundle.layout is not None and any(
            layout_nodes_by_page[reading_sidecar.page_index][
                fragment.layout_node_id
            ].source_fact_id
            != fragment.fact_id
            for block in reading_sidecar.blocks
            for fragment in block.fragments
        ):
            raise CanonicalJoinError(
                "Reading fragment does not bind its exact Fact and Layout node"
            )
    reading_sidecar_by_id = {item.sidecar_id: item for item in bundle.reading_pages}
    for table_sidecar in bundle.table_pages:
        page = page_by_index.get(table_sidecar.page_index)
        if (
            page is None
            or table_sidecar.page_id != page.page_id
            or table_sidecar.source_sha256 != facts.source_sha256
            or table_sidecar.canonical_width != page.canonical_width
            or table_sidecar.canonical_height != page.canonical_height
        ):
            raise CanonicalJoinError("Page Table authority does not bind Facts")
        try:
            nodes = layout_nodes_by_page.get(table_sidecar.page_index, {})
            validate_member_bindings(
                table_sidecar.member_bindings,
                source_sha256=facts.source_sha256,
                page=page,
                nodes=nodes,
            )
            validate_table_text_projections(table_sidecar, page=page, nodes=nodes)
        except (KeyError, ValueError) as error:
            _raise_redacted_translation(
                error,
                CanonicalJoinError(
                    "Page Table text selection does not bind its exact sources"
                ),
            )
        evidence_inventory = (
            *(table.evidence for table in table_sidecar.tables),
            *(
                boundary.evidence
                for table in table_sidecar.tables
                for boundary in (*table.row_boundaries, *table.column_boundaries)
            ),
            *(row.evidence for table in table_sidecar.tables for row in table.rows),
            *(
                column.evidence
                for table in table_sidecar.tables
                for column in table.columns
            ),
            *(cell.evidence for table in table_sidecar.tables for cell in table.cells),
            *table_sidecar.negative_evidence,
        )
        drawing_fact_ids = {item.fact_id for item in page.drawings}
        if any(
            evidence.source_sha256 != facts.source_sha256
            or evidence.page_id != page.page_id
            or evidence.page_index != table_sidecar.page_index
            or evidence.inherited_page_sidecar_id
            != table_sidecar.inherited_page_sidecar_id
            or evidence.inherited_page_sidecar_sha256
            != table_sidecar.inherited_page_sidecar_sha256
            or evidence.inherited_manifest_id != table_sidecar.inherited_manifest_id
            for evidence in evidence_inventory
        ):
            raise CanonicalJoinError("Page Table evidence crosses authority")
        if any(
            set(evidence.source_fact_ids) - fact_ids_by_page[table_sidecar.page_index]
            for evidence in evidence_inventory
        ):
            raise CanonicalJoinError("Page Table evidence references a missing Fact")
        if any(
            set(evidence.drawing_fact_ids) - drawing_fact_ids
            for evidence in evidence_inventory
        ):
            raise CanonicalJoinError(
                "Page Table evidence references a missing Drawing Fact"
            )
        if bundle.layout is not None:
            if any(
                set(evidence.source_layout_node_ids)
                - layout_node_ids_by_page.get(table_sidecar.page_index, set())
                for evidence in evidence_inventory
            ):
                raise CanonicalJoinError(
                    "Page Table evidence references a missing Layout node"
                )
            if any(
                set(evidence.separator_candidate_ids)
                - separator_candidate_ids_by_page.get(table_sidecar.page_index, set())
                for evidence in evidence_inventory
            ):
                raise CanonicalJoinError(
                    "Page Table evidence references a missing Layout separator"
                )
        if table_sidecar.reading_page_sidecar_id is not None:
            bound_reading_sidecar = reading_sidecar_by_id.get(
                table_sidecar.reading_page_sidecar_id
            )
            if (
                bound_reading_sidecar is None
                or canonical_sha256(bound_reading_sidecar)
                != table_sidecar.reading_page_sidecar_sha256
                or bound_reading_sidecar.page_index != table_sidecar.page_index
                or bound_reading_sidecar.page_id != table_sidecar.page_id
            ):
                raise CanonicalJoinError(
                    "Page Table authority does not bind its Reading sidecar"
                )
    if bundle.table_manifest is not None:
        manifest = bundle.table_manifest
        if manifest.source_sha256 != facts.source_sha256:
            raise CanonicalJoinError("Table manifest crosses source identity")
        sidecars = {item.sidecar_id: item for item in bundle.table_pages}
        if set(sidecars) != {item.sidecar_id for item in manifest.page_references}:
            raise CanonicalJoinError(
                "Table manifest inventory does not match supplied sidecars"
            )
        for manifest_reference in manifest.page_references:
            referenced_sidecar = sidecars.get(manifest_reference.sidecar_id)
            if (
                referenced_sidecar is None
                or canonical_sha256(referenced_sidecar)
                != manifest_reference.sidecar_sha256
                or len(canonical_json_bytes(referenced_sidecar))
                != manifest_reference.sidecar_bytes
                or referenced_sidecar.page_id != manifest_reference.page_id
                or referenced_sidecar.page_index != manifest_reference.page_index
                or referenced_sidecar.outcome != manifest_reference.outcome
                or tuple(item.table_id for item in referenced_sidecar.tables)
                != manifest_reference.table_ids
                or referenced_sidecar.inherited_manifest_id
                != manifest.reading_authority_id
            ):
                raise CanonicalJoinError(
                    "Table manifest references a missing or changed sidecar"
                )
    if (
        bundle.transitions or bundle.document_tables or bundle.transition_fingerprints
    ) and bundle.document_table_manifest is None:
        raise CanonicalJoinError(
            "Document Table authority requires its document manifest"
        )
    if bundle.document_table_manifest is not None:
        document_manifest = bundle.document_table_manifest
        if bundle.table_manifest is None:
            raise CanonicalJoinError(
                "Document Table manifest requires the Page Table manifest"
            )
        if (
            document_manifest.source_sha256 != facts.source_sha256
            or document_manifest.page_table_manifest_id
            != bundle.table_manifest.manifest_id
            or document_manifest.page_table_manifest_sha256
            != bundle.table_manifest.page_table_manifest_sha256
        ):
            raise CanonicalJoinError(
                "Document Table manifest does not bind Page Table authority"
            )
        if set(document_manifest.transition_ids) != {
            item.transition_id for item in bundle.transitions
        } or set(document_manifest.document_table_ids) != {
            item.document_table_id for item in bundle.document_tables
        }:
            raise CanonicalJoinError(
                "Document Table manifest inventory does not match supplied artifacts"
            )
    transition_by_id = {item.transition_id: item for item in bundle.transitions}
    table_sidecar_by_id = {item.sidecar_id: item for item in bundle.table_pages}
    for transition in bundle.transitions:
        if (
            transition.left.source_sha256 != facts.source_sha256
            or transition.right.source_sha256 != facts.source_sha256
            or transition.left.document_identity != transition.right.document_identity
            or transition.left.page_table_manifest_sha256
            != transition.right.page_table_manifest_sha256
        ):
            raise CanonicalJoinError("Document Table transition crosses authority")
        if bundle.document_table_manifest is not None and (
            transition.left.document_identity
            != bundle.document_table_manifest.document_identity
            or transition.left.page_table_manifest_sha256
            != bundle.document_table_manifest.page_table_manifest_sha256
        ):
            raise CanonicalJoinError(
                "Document Table transition does not bind its manifest"
            )
        bound_source_tables: list[PdfTable] = []
        for endpoint in (transition.left, transition.right):
            sidecar = table_sidecar_by_id.get(endpoint.table_sidecar_id)
            source_table = (
                next(
                    (
                        item
                        for item in sidecar.tables
                        if item.table_id == endpoint.table_id
                    ),
                    None,
                )
                if sidecar is not None
                else None
            )
            expected_row_cell_membership = (
                {row.row_id: set(row.anchor_cell_ids) for row in source_table.rows}
                if source_table is not None
                else {}
            )
            observed_row_cell_membership = {
                row_id: set(cell_ids)
                for row_id, cell_ids in endpoint.row_cell_membership
            }
            endpoint_membership_mismatch = any(
                row_id not in expected_row_cell_membership
                or cell_ids != expected_row_cell_membership[row_id]
                for row_id, cell_ids in observed_row_cell_membership.items()
            )
            if (
                sidecar is None
                or source_table is None
                or canonical_sha256(sidecar) != endpoint.table_sidecar_sha256
                or (
                    endpoint.sidecar_bytes is not None
                    and len(canonical_json_bytes(sidecar)) != endpoint.sidecar_bytes
                )
                or sidecar.page_index != endpoint.page_index
                or sidecar.page_id != endpoint.page_id
                or sidecar.configuration_identity != endpoint.configuration_identity
                or sidecar.dependency_identity != endpoint.dependency_identity
                or tuple(item.row_id for item in source_table.rows)
                != endpoint.table_row_ids
                or tuple(item.cell_id for item in source_table.cells)
                != endpoint.table_cell_ids
                or endpoint_membership_mismatch
            ):
                raise CanonicalJoinError(
                    "Document Table transition endpoint is stale or mismatched"
                )
            bound_source_tables.append(source_table)
        left_source_table, right_source_table = bound_source_tables
        left_columns = {item.column_id: item for item in left_source_table.columns}
        right_columns = {item.column_id: item for item in right_source_table.columns}
        mapping_index_pairs = {
            (item.left_column_index, item.right_column_index)
            for item in transition.column_mappings
        }
        if any(
            mapping.left_column_id not in left_columns
            or mapping.right_column_id not in right_columns
            or mapping.left_column_index
            != left_columns[mapping.left_column_id].column_index
            or mapping.right_column_index
            != right_columns[mapping.right_column_id].column_index
            for mapping in transition.column_mappings
        ):
            raise CanonicalJoinError(
                "Document Table transition column mapping is stale or mismatched"
            )
        left_cells_by_row = {
            row.row_id: set(row.anchor_cell_ids) for row in left_source_table.rows
        }
        right_cells_by_row = {
            row.row_id: set(row.anchor_cell_ids) for row in right_source_table.rows
        }
        for header in transition.repeated_header_mappings:
            if set(header.left_cell_ids) - {
                cell_id
                for row_id in header.left_row_ids
                for cell_id in left_cells_by_row[row_id]
            } or set(header.right_cell_ids) - {
                cell_id
                for row_id in header.right_row_ids
                for cell_id in right_cells_by_row[row_id]
            }:
                raise CanonicalJoinError(
                    "Document Table repeated-header evidence crosses row membership"
                )
        for fragment in transition.row_fragment_links:
            mapped_pairs = tuple(fragment.mapped_column_indexes)
            if (
                set(fragment.left_cell_ids) - left_cells_by_row[fragment.left_row_id]
                or set(fragment.right_cell_ids)
                - right_cells_by_row[fragment.right_row_id]
                or not mapped_pairs
                or len(mapped_pairs) != len(set(mapped_pairs))
                or set(mapped_pairs) - mapping_index_pairs
            ):
                raise CanonicalJoinError(
                    "Document Table split-row evidence is stale or mismatched"
                )
    for document_table in bundle.document_tables:
        if (
            document_table.source_sha256 != facts.source_sha256
            or bundle.document_table_manifest is None
            or document_table.document_identity
            != bundle.document_table_manifest.document_identity
            or document_table.page_table_manifest_sha256
            != bundle.document_table_manifest.page_table_manifest_sha256
        ):
            raise CanonicalJoinError("Document Table crosses source identity")
        reference_source_tables: list[PdfTable] = []
        for document_reference in document_table.page_table_references:
            sidecar = table_sidecar_by_id.get(document_reference.table_sidecar_id)
            source_table = (
                next(
                    (
                        item
                        for item in sidecar.tables
                        if item.table_id == document_reference.table_id
                    ),
                    None,
                )
                if sidecar is not None
                else None
            )
            if (
                sidecar is None
                or source_table is None
                or sidecar.page_index != document_reference.page_index
                or sidecar.page_id != document_reference.page_id
                or tuple(item.row_id for item in source_table.rows)
                != document_reference.source_row_ids
                or tuple(item.cell_id for item in source_table.cells)
                != document_reference.source_cell_ids
            ):
                raise CanonicalJoinError(
                    "Document Table page reference is stale or mismatched"
                )
            reference_source_tables.append(source_table)
        try:
            bound_transition_chain = tuple(
                transition_by_id[transition_id]
                for transition_id in document_table.transition_ids
            )
        except KeyError:
            raise CanonicalJoinError(
                "Document Table references a missing transition"
            ) from None
        expected_transition_chain = tuple(
            (
                left.page_index,
                left.table_id,
                right.page_index,
                right.table_id,
            )
            for left, right in zip(
                document_table.page_table_references,
                document_table.page_table_references[1:],
                strict=False,
            )
        )
        observed_transition_chain = tuple(
            (
                transition.left.page_index,
                transition.left.table_id,
                transition.right.page_index,
                transition.right.table_id,
            )
            for transition in bound_transition_chain
        )
        if observed_transition_chain != expected_transition_chain:
            raise CanonicalJoinError(
                "Document Table transition chain does not bind its page references"
            )
        if any(
            current.right != following.left
            for current, following in pairwise(bound_transition_chain)
        ):
            raise CanonicalJoinError(
                "Document Table transition chain has inconsistent shared authority"
            )
        source_row_page_indexes: dict[str, int] = {}
        source_cell_page_indexes: dict[str, int] = {}
        source_row_cells: dict[str, set[str]] = {}
        for reference, source_table in zip(
            document_table.page_table_references,
            reference_source_tables,
            strict=True,
        ):
            for row in source_table.rows:
                source_row_page_indexes[row.row_id] = reference.page_index
                source_row_cells[row.row_id] = set(row.anchor_cell_ids)
            for cell in source_table.cells:
                source_cell_page_indexes[cell.cell_id] = reference.page_index
        for logical_row in document_table.logical_rows:
            member_cells = {
                cell_id
                for row_id in logical_row.fragment_row_ids
                for cell_id in source_row_cells[row_id]
            }
            expected_page_indexes = tuple(
                sorted(
                    {
                        *(
                            source_row_page_indexes[row_id]
                            for row_id in logical_row.fragment_row_ids
                        ),
                        *(
                            source_cell_page_indexes[cell_id]
                            for cell_id in logical_row.fragment_cell_ids
                        ),
                    }
                )
            )
            if (
                set(logical_row.fragment_cell_ids) - member_cells
                or logical_row.source_page_indexes != expected_page_indexes
            ):
                raise CanonicalJoinError(
                    "Document logical row provenance is stale or mismatched"
                )
    for fingerprint in bundle.transition_fingerprints:
        bound_transition = transition_by_id.get(fingerprint.transition_id)
        if bound_transition is None or fingerprint.source_sha256 != facts.source_sha256:
            raise CanonicalJoinError(
                "transition fingerprint references missing transition authority"
            )
        try:
            validate_transition_fingerprint_dependency(fingerprint, bound_transition)
        except ValueError as exc:
            _raise_redacted_translation(
                exc,
                CanonicalJoinError(
                    "transition fingerprint dependency is stale or mismatched"
                ),
            )


def _enforce_limits(
    *,
    limits: CanonicalProjectionLimits,
    page_count: int,
    text_blocks: int,
    text_characters: int,
    drawings: int,
    tables: int,
    rows: int,
    columns: int,
    cells: int,
    document_tables: int,
    logical_rows: int,
    logical_cells: int,
    transitions: int,
    transition_fingerprints: int,
    transition_detail_items: int,
    warnings: int,
) -> None:
    observed = {
        "pages": (page_count, limits.maximum_pages),
        "text_blocks": (text_blocks, limits.maximum_text_blocks),
        "text_characters": (text_characters, limits.maximum_text_characters),
        "drawings": (drawings, limits.maximum_drawings),
        "tables": (tables, limits.maximum_tables),
        "rows": (rows, limits.maximum_rows),
        "columns": (columns, limits.maximum_columns),
        "cells": (cells, limits.maximum_cells),
        "document_tables": (document_tables, limits.maximum_document_tables),
        "logical_rows": (logical_rows, limits.maximum_logical_rows),
        "logical_cells": (logical_cells, limits.maximum_logical_cells),
        "transitions": (transitions, limits.maximum_transitions),
        "transition_fingerprints": (
            transition_fingerprints,
            limits.maximum_transition_fingerprints,
        ),
        "transition_detail_items": (
            transition_detail_items,
            limits.maximum_transition_detail_items,
        ),
        "warnings": (warnings, limits.maximum_warnings),
    }
    for label, (actual, ceiling) in observed.items():
        if actual > ceiling:
            raise CanonicalLimitExceeded(
                f"canonical {label} limit exceeded: {actual} > {ceiling}"
            )


def _build_canonical_document(
    bundle: CanonicalArtifactBundle,
    *,
    limits: CanonicalProjectionLimits | None = None,
) -> CanonicalDocument:
    """Build one deterministic Canonical document from retained artifacts only."""
    effective_limits = limits or CanonicalProjectionLimits()
    _validate_bundle_joins(bundle)
    facts = bundle.facts
    fact_pages = tuple(sorted(facts.pages, key=lambda item: item.page_number))
    page_ids = {item.page_number - 1: _page_identity(item) for item in fact_pages}
    page_ids_by_number = {
        item.page_number: page_ids[item.page_number - 1] for item in fact_pages
    }
    layout_pages = (
        {item.page_number - 1: item for item in bundle.layout.pages}
        if bundle.layout is not None
        else {}
    )
    reading_pages = {item.page_index: item for item in bundle.reading_pages}
    table_pages = {item.page_index: item for item in bundle.table_pages}
    tables = _canonical_tables(bundle.table_pages, page_ids=page_ids)
    page_index_by_id = {page_id: page_index for page_index, page_id in page_ids.items()}
    table_ids_by_source = {
        (page_index_by_id[item.page_id], item.source_table_id): item.table_id
        for item in tables
    }
    row_ids_by_source = {
        (
            page_index_by_id[table.page_id],
            table.source_table_id,
            row.source_row_id,
        ): row.row_id
        for table in tables
        for row in table.rows
    }
    column_ids_by_source = {
        (
            page_index_by_id[table.page_id],
            table.source_table_id,
            column.source_column_id,
        ): column.column_id
        for table in tables
        for column in table.columns
    }
    cell_ids_by_source = {
        (
            page_index_by_id[table.page_id],
            table.source_table_id,
            cell.source_cell_id,
        ): cell.cell_id
        for table in tables
        for cell in table.cells
    }
    fingerprints_by_transition = {
        item.transition_id: item for item in bundle.transition_fingerprints
    }
    transitions = _canonical_transitions(
        bundle.transitions,
        table_ids_by_source=table_ids_by_source,
        row_ids_by_source=row_ids_by_source,
        cell_ids_by_source=cell_ids_by_source,
        column_ids_by_source=column_ids_by_source,
        fingerprints_by_transition=fingerprints_by_transition,
    )
    transition_ids_by_source = {
        item.source_transition_id: item.transition_id for item in transitions
    }
    document_tables = _canonical_document_tables(
        bundle.document_tables,
        table_ids_by_source=table_ids_by_source,
        row_ids_by_source=row_ids_by_source,
        cell_ids_by_source=cell_ids_by_source,
        transition_ids_by_source=transition_ids_by_source,
    )
    memberships: dict[str, list[str]] = defaultdict(list)
    for document_table in document_tables:
        for table_id in document_table.table_ids:
            memberships[table_id].append(document_table.document_table_id)
    tables = tuple(
        CanonicalTable.model_validate(
            item.model_dump(mode="python")
            | {
                "document_table_ids": tuple(sorted(memberships[item.table_id])),
            }
        )
        for item in tables
    )
    tables_by_page: dict[str, list[str]] = defaultdict(list)
    for table in tables:
        tables_by_page[table.page_id].append(table.table_id)
    warnings = _canonical_warnings(
        facts,
        bundle.layout,
        page_ids_by_number=page_ids_by_number,
    )
    warning_suppressions = _canonical_warning_suppressions(facts, bundle.layout)
    warning_ids_by_page: dict[str, list[str]] = defaultdict(list)
    for warning in warnings:
        if warning.page_id is not None:
            warning_ids_by_page[warning.page_id].append(warning.warning_id)
    pages = []
    for fact_page in fact_pages:
        page_index = fact_page.page_number - 1
        page_id = page_ids[page_index]
        reading = reading_pages.get(page_index)
        table_page = table_pages.get(page_index)
        blocks = (
            _reading_blocks(
                reading,
                page=fact_page,
                page_id=page_id,
                layout_page=layout_pages.get(page_index),
            )
            if reading is not None
            else _fallback_blocks(
                fact_page,
                page_id=page_id,
                layout_page=layout_pages.get(page_index),
            )
        )
        canonical_drawings: list[CanonicalDrawing] = []
        for drawing_index, drawing in enumerate(
            sorted(
                fact_page.drawings,
                key=lambda item: (item.source_order, item.fact_id),
            )
        ):
            drawing_limitations = (
                ()
                if drawing.path_geometry_complete
                else ("DRAWING_PATH_GEOMETRY_LIMITED",)
            )
            drawing_values: dict[str, object] = {
                "page_id": page_id,
                "source_drawing_id": drawing.fact_id,
                "drawing_index": drawing_index,
                "kind": drawing.kind,
                "bbox": _bbox(drawing.bbox),
                "path_geometry_complete": drawing.path_geometry_complete,
                "path_segment_count": drawing.path_segment_count,
                "availability": (
                    _availability("AVAILABLE")
                    if drawing.path_geometry_complete
                    else _availability(
                        "LIMITED_EVIDENCE",
                        "DRAWING_PATH_GEOMETRY_LIMITED",
                    )
                ),
                "limitation_codes": drawing_limitations,
            }
            canonical_drawings.append(
                CanonicalDrawing.model_validate(
                    _identified(
                        CanonicalDrawing,
                        field="drawing_id",
                        kind="drawing",
                        values=drawing_values,
                    )
                )
            )
        page_limitations: set[str] = set()
        if reading is None:
            page_limitations.add("READING_STRUCTURE_UNAVAILABLE")
        else:
            page_limitations.update(reading.limitation_codes)
            page_limitations.update(reading.reading_order.limitation_codes)
            page_limitations.update(reading.hierarchy.limitation_codes)
        if table_page is None:
            page_limitations.add("PAGE_TABLE_UNAVAILABLE")
        else:
            page_limitations.update(table_page.limitation_codes)
        if fact_page.extraction_status is not PdfExtractionStatus.SUCCESS:
            page_limitations.add(
                f"UPSTREAM_{fact_page.extraction_status.value.upper()}"
            )
        layout_page = layout_pages.get(page_index)
        page_availability = _aggregate_layer_availability(
            (
                _page_availability(fact_page),
                (
                    _extraction_availability(
                        layout_page.build_status,
                        reason_prefix="UPSTREAM_LAYOUT_PAGE",
                    )
                    if layout_page is not None
                    else _availability("UNAVAILABLE", "LAYOUT_PAGE_UNAVAILABLE")
                ),
                (
                    _reading_page_availability(reading)
                    if reading is not None
                    else _availability(
                        "UNAVAILABLE",
                        "READING_STRUCTURE_UNAVAILABLE",
                    )
                ),
                _page_table_availability(table_page),
            ),
            expected_count=4,
            unavailable_reason="PAGE_AUTHORITY_UNAVAILABLE",
            partial_reason="PAGE_AUTHORITY_PARTIAL",
        )
        page_values = {
            "source_page_id": fact_page.page_id,
            "page_index": page_index,
            "page_number": fact_page.page_number,
            "geometry": _page_geometry(fact_page),
            "text_blocks": blocks,
            "drawings": tuple(canonical_drawings),
            "table_ids": tuple(tables_by_page[page_id]),
            "page_table_outcome": (
                table_page.outcome if table_page is not None else None
            ),
            "page_table_availability": _page_table_availability(table_page),
            "page_table_negative_evidence_categories": (
                tuple(
                    sorted(
                        {
                            category
                            for evidence in table_page.negative_evidence
                            for category in evidence.evidence_categories
                        }
                    )
                )
                if table_page is not None
                else ()
            ),
            "warning_ids": tuple(warning_ids_by_page[page_id]),
            "availability": page_availability,
            "limitation_codes": tuple(sorted(page_limitations)),
        }
        pages.append(CanonicalPage.model_validate({"page_id": page_id, **page_values}))
    page_table_capability = _aggregate_layer_availability(
        tuple(_page_table_availability(item) for item in bundle.table_pages),
        expected_count=len(fact_pages),
        unavailable_reason="PAGE_TABLE_UNAVAILABLE",
        partial_reason="PAGE_TABLE_PARTIAL",
    )
    reading_capability = _aggregate_layer_availability(
        tuple(_reading_page_availability(item) for item in bundle.reading_pages),
        expected_count=len(fact_pages),
        unavailable_reason="READING_STRUCTURE_UNAVAILABLE",
        partial_reason="READING_STRUCTURE_PARTIAL",
    )
    document_table_capability = _document_table_availability(bundle)
    document_manifest = bundle.document_table_manifest
    if not bundle.transitions and document_manifest is not None:
        transition_capability = _manifest_limited_availability(
            _availability("AVAILABLE"),
            document_manifest,
        )
        fingerprint_capability = _manifest_limited_availability(
            _availability("AVAILABLE"),
            document_manifest,
        )
    else:
        transition_capability = _aggregate_layer_availability(
            tuple(item.availability for item in transitions),
            expected_count=len(bundle.transitions),
            unavailable_reason="TRANSITION_AUTHORITY_UNAVAILABLE",
            partial_reason="TRANSITION_AUTHORITY_PARTIAL",
        )
        fingerprint_capability = _aggregate_layer_availability(
            tuple(
                _availability(
                    item.state,
                    *(
                        item.limitation_codes
                        or (f"TRANSITION_FINGERPRINT_{item.state}",)
                    ),
                )
                if item.state != "AVAILABLE"
                else _availability("AVAILABLE")
                for item in bundle.transition_fingerprints
            ),
            expected_count=len(bundle.transitions),
            unavailable_reason="TRANSITION_FINGERPRINT_UNAVAILABLE",
            partial_reason="TRANSITION_FINGERPRINT_PARTIAL",
        )
        if document_manifest is not None:
            transition_capability = _manifest_limited_availability(
                transition_capability,
                document_manifest,
            )
            fingerprint_capability = _manifest_limited_availability(
                fingerprint_capability,
                document_manifest,
            )
    capability_states = {
        "document_table": document_table_capability,
        "family": _availability("UNAVAILABLE", "FAMILY_DEFERRED"),
        "facts": _extraction_availability(facts.extraction_status),
        "layout": _layout_availability(bundle.layout),
        "page_table": page_table_capability,
        "reading": reading_capability,
        "transition_fingerprint": fingerprint_capability,
        "transitions": transition_capability,
    }
    capabilities = tuple(
        CanonicalCapabilityAvailability(
            capability=name,
            availability=availability,
        )
        for name, availability in sorted(capability_states.items())
    )
    document_limitations = {"FAMILY_DEFERRED", "OCR_NOT_EXECUTED"}
    document_limitations.update(
        reason
        for capability in capabilities
        for reason in capability.availability.reason_codes
    )
    document_limitations.update(
        code for page in pages for code in page.limitation_codes
    )
    document_limitations.update(
        code for table in tables for code in table.limitation_codes
    )
    document_limitations.update(
        code
        for page in pages
        for block in page.text_blocks
        for code in block.limitation_codes
    )
    document_limitations.update(
        code
        for page in pages
        for drawing in page.drawings
        for code in drawing.limitation_codes
    )
    document_limitations.update(
        code
        for table in tables
        for cell in table.cells
        for code in cell.limitation_codes
    )
    document_limitations.update(
        code for item in transitions for code in item.limitation_codes
    )
    document_limitations.update(
        code for item in transitions for code in item.fingerprint_limitation_codes
    )
    document_limitations.update(
        code for item in document_tables for code in item.limitation_codes
    )
    document_limitations.update(
        code
        for item in document_tables
        for logical_row in item.logical_rows
        for code in logical_row.limitation_codes
    )
    if bundle.table_manifest is not None:
        document_limitations.update(bundle.table_manifest.limitation_codes)
    if warning_suppressions:
        document_limitations.add("UPSTREAM_WARNINGS_SUPPRESSED")
    text_blocks = sum(len(item.text_blocks) for item in pages)
    text_characters = sum(
        len(block.text) + sum(len(span.text) for span in block.spans)
        for page in pages
        for block in page.text_blocks
    ) + sum(len(cell.text or "") for table in tables for cell in table.cells)
    drawing_count = sum(len(item.drawings) for item in pages)
    row_count = sum(len(item.rows) for item in tables)
    column_count = sum(len(item.columns) for item in tables)
    cell_count = sum(len(item.cells) for item in tables)
    logical_row_count = sum(len(item.logical_rows) for item in document_tables)
    logical_cell_count = sum(
        len(item.cell_ids)
        for document_table in document_tables
        for item in document_table.logical_rows
    )
    transition_fingerprint_count = sum(
        item.fingerprint is not None for item in transitions
    )
    transition_detail_count = sum(
        len(item.column_mappings)
        + len(item.repeated_header_evidence)
        + len(item.split_row_evidence)
        + sum(
            len(evidence.left_row_ids)
            + len(evidence.right_row_ids)
            + len(evidence.left_cell_ids)
            + len(evidence.right_cell_ids)
            for evidence in item.repeated_header_evidence
        )
        + sum(
            len(evidence.left_cell_ids)
            + len(evidence.right_cell_ids)
            + len(evidence.mapped_column_indexes)
            + len(evidence.local_fragment_order)
            for evidence in item.split_row_evidence
        )
        + (
            len(item.fingerprint.column_continuity.normalized_axis_distances)
            + len(item.fingerprint.column_continuity.column_width_ratio_drifts)
            + len(
                item.fingerprint.header_continuity.normalized_header_geometry_signature
                or ()
            )
            + len(
                item.fingerprint.row_cell_continuity.mapped_column_fragment_distribution
                or ()
            )
            + len(item.fingerprint.pair_context.conflicting_evidence_groups)
            + len(item.fingerprint.limitation_codes)
            if item.fingerprint is not None
            else 0
        )
        for item in transitions
    )
    _enforce_limits(
        limits=effective_limits,
        page_count=len(pages),
        text_blocks=text_blocks,
        text_characters=text_characters,
        drawings=drawing_count,
        tables=len(tables),
        rows=row_count,
        columns=column_count,
        cells=cell_count,
        document_tables=len(document_tables),
        logical_rows=logical_row_count,
        logical_cells=logical_cell_count,
        transitions=len(transitions),
        transition_fingerprints=transition_fingerprint_count,
        transition_detail_items=transition_detail_count,
        warnings=len(warnings),
    )
    upstream_versions = {
        facts.schema_version,
        *((bundle.layout.schema_version,) if bundle.layout is not None else ()),
        *(item.schema_version for item in bundle.reading_pages),
        *(item.schema_version for item in bundle.table_pages),
        *(
            (bundle.table_manifest.schema_version,)
            if bundle.table_manifest is not None
            else ()
        ),
        *(item.schema_version for item in bundle.transitions),
        *(item.schema_version for item in bundle.document_tables),
        *(
            (bundle.document_table_manifest.schema_version,)
            if bundle.document_table_manifest is not None
            else ()
        ),
        *(item.schema_version for item in bundle.transition_fingerprints),
    }
    upstream_ids = {
        facts.document_id,
        *((bundle.layout.layout_graph_id,) if bundle.layout is not None else ()),
        *(item.sidecar_id for item in bundle.reading_pages),
        *(item.sidecar_id for item in bundle.table_pages),
        *(
            (bundle.table_manifest.manifest_id,)
            if bundle.table_manifest is not None
            else ()
        ),
        *(item.transition_id for item in bundle.transitions),
        *(item.document_table_id for item in bundle.document_tables),
        *(
            (bundle.document_table_manifest.manifest_id,)
            if bundle.document_table_manifest is not None
            else ()
        ),
        *(item.fingerprint_id for item in bundle.transition_fingerprints),
    }
    provenance = CanonicalProvenance(
        source_sha256=facts.source_sha256,
        source_document_identity=facts.document_id,
        source_parser_name=facts.parser_name,
        source_parser_version=facts.parser_version,
        upstream_schema_versions=tuple(sorted(upstream_versions)),
        upstream_artifact_ids=tuple(sorted(upstream_ids)),
        projection_limit_digest=effective_limits.digest,
    )
    core_availability = _aggregate_layer_availability(
        tuple(
            capability_states[name]
            for name in ("facts", "layout", "reading", "page_table")
        ),
        expected_count=4,
        unavailable_reason="CANONICAL_CORE_UNAVAILABLE",
        partial_reason="CANONICAL_CORE_PARTIAL",
    )
    availability = (
        core_availability
        if core_availability.state == "AVAILABLE"
        else _availability(core_availability.state, *sorted(document_limitations))
    )
    document_values: dict[str, object] = {
        "canonical_version": CANONICAL_SCHEMA_VERSION,
        "projection_version": CANONICAL_PROJECTION_VERSION,
        "source_document_identity": facts.document_id,
        "page_count": facts.page_count,
        "projected_page_count": len(pages),
        "pages": tuple(pages),
        "tables": tables,
        "document_tables": document_tables,
        "transitions": transitions,
        "warnings": warnings,
        "warning_suppressions": warning_suppressions,
        "limitations": tuple(sorted(document_limitations)),
        "provenance": provenance,
        "availability": availability,
        "capability_availability": capabilities,
        "family": None,
        "family_status": "REVIEW_REQUIRED",
        "family_auto_assignment": False,
    }
    document = CanonicalDocument.model_validate(
        _identified(
            CanonicalDocument,
            field="canonical_document_id",
            kind="document",
            values=document_values,
        )
    )
    encoded_size = len(canonical_payload_bytes(document))
    if encoded_size > effective_limits.maximum_canonical_bytes:
        raise CanonicalLimitExceeded(
            "canonical byte limit exceeded: "
            f"{encoded_size} > {effective_limits.maximum_canonical_bytes}"
        )
    return document


def build_canonical_document(
    bundle: CanonicalArtifactBundle,
    *,
    limits: CanonicalProjectionLimits | None = None,
) -> CanonicalDocument:
    """Build one deterministic Canonical document with controlled failures."""
    try:
        return _build_canonical_document(bundle, limits=limits)
    except CanonicalProjectionError:
        raise
    except ValidationError as exc:
        _raise_redacted_translation(
            exc,
            CanonicalProjectionError(
                "canonical projection did not satisfy its private contract"
            ),
        )

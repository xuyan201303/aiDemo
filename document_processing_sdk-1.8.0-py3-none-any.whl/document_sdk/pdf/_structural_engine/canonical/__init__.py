"""Private, default-off, unwired Canonical PDF model."""

from .contracts import (
    CANONICAL_PROJECTION_VERSION,
    CANONICAL_SCHEMA_VERSION,
    CanonicalDocument,
    CanonicalProjectionLimits,
)
from .projection import CanonicalArtifactBundle, build_canonical_document
from .validation import (
    CanonicalJoinError,
    CanonicalLimitExceeded,
    CanonicalProjectionError,
    validate_canonical_document,
)

__all__ = [
    "CANONICAL_PROJECTION_VERSION",
    "CANONICAL_SCHEMA_VERSION",
    "CanonicalArtifactBundle",
    "CanonicalDocument",
    "CanonicalJoinError",
    "CanonicalLimitExceeded",
    "CanonicalProjectionError",
    "CanonicalProjectionLimits",
    "build_canonical_document",
    "validate_canonical_document",
]

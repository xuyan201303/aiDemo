"""Private validation and error semantics for Canonical PDF projection."""

# ruff: noqa: N818

from __future__ import annotations

from pydantic import ValidationError

from document_sdk.core.errors import _raise_redacted_translation

from .contracts import CanonicalDocument


class CanonicalProjectionError(ValueError):
    """Base class for controlled Canonical projection failures."""


class CanonicalLimitExceeded(CanonicalProjectionError):
    """A configured Canonical resource ceiling was exceeded."""


class CanonicalJoinError(CanonicalProjectionError):
    """Upstream artifacts cannot be joined without inventing authority."""


def validate_canonical_document(document: CanonicalDocument) -> None:
    """Strictly reconstruct one Canonical document and re-run all joins."""
    try:
        CanonicalDocument.model_validate(document.model_dump(mode="python"))
    except ValidationError as exc:
        _raise_redacted_translation(
            exc,
            CanonicalJoinError("canonical document validation failed"),
        )

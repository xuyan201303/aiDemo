"""Private contracts for deterministic generic Canonical exports."""

# ruff: noqa: EM101, N818, TRY003

from __future__ import annotations

from hashlib import sha256
from typing import Literal, Self

from pydantic import BaseModel, ConfigDict, Field, model_validator

EXPORT_SCHEMA_VERSION: Literal["document_sdk_pdf_generic_export.v1"] = (
    "document_sdk_pdf_generic_export.v1"
)
JSON_DETERMINISM_CONTRACT: Literal["JSON_BYTE_DETERMINISTIC"] = (
    "JSON_BYTE_DETERMINISTIC"
)
CSV_DETERMINISM_CONTRACT: Literal["CSV_BUNDLE_BYTE_DETERMINISTIC"] = (
    "CSV_BUNDLE_BYTE_DETERMINISTIC"
)
XLSX_DETERMINISM_CONTRACT: Literal["XLSX_SEMANTIC_DETERMINISTIC"] = (
    "XLSX_SEMANTIC_DETERMINISTIC"
)
type RelationalScalar = str | int | float | bool | None


class _FrozenModel(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        frozen=True,
        hide_input_in_errors=True,
        strict=True,
        allow_inf_nan=False,
    )


class ExportSerializationError(ValueError):
    """A controlled export serialization or validation failure."""


class ExportLimitExceeded(ExportSerializationError):
    """A configured export size or row ceiling was exceeded."""


class CanonicalExportLimits(_FrozenModel):
    maximum_json_bytes: int = Field(
        default=128 * 1024 * 1024,
        ge=1,
        le=512 * 1024 * 1024,
    )
    maximum_csv_rows: int = Field(default=2_000_000, ge=1, le=4_000_000)
    maximum_xlsx_rows_per_sheet: int = Field(
        default=1_000_000,
        ge=1,
        le=1_048_575,
    )
    maximum_xlsx_cell_characters: int = Field(default=32_767, ge=1, le=32_767)
    maximum_export_bytes: int = Field(
        default=256 * 1024 * 1024,
        ge=1024,
        le=1024 * 1024 * 1024,
    )


class CanonicalRelationalTable(_FrozenModel):
    name: str = Field(pattern=r"^[a-z][a-z0-9_]*$")
    columns: tuple[str, ...]
    rows: tuple[tuple[RelationalScalar, ...], ...]

    @model_validator(mode="after")
    def validate_shape(self) -> Self:
        if not self.columns or len(set(self.columns)) != len(self.columns):
            raise ValueError("relational columns must be nonempty and unique")
        if any(len(row) != len(self.columns) for row in self.rows):
            raise ValueError("relational row width does not match columns")
        return self


class CanonicalJsonExportArtifact(_FrozenModel):
    schema_version: Literal["document_sdk_pdf_generic_export.v1"] = (
        EXPORT_SCHEMA_VERSION
    )
    canonical_document_id: str = Field(pattern=r"^P3CE1-document-[0-9a-f]{64}$")
    determinism_contract: Literal["JSON_BYTE_DETERMINISTIC"] = JSON_DETERMINISM_CONTRACT
    content: bytes = Field(repr=False)
    content_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_digest(self) -> Self:
        if sha256(self.content).hexdigest() != self.content_sha256:
            raise ValueError("JSON export digest mismatch")
        return self


class CanonicalCsvFile(_FrozenModel):
    filename: str = Field(pattern=r"^[a-z][a-z0-9_]*\.csv$")
    columns: tuple[str, ...]
    row_count: int = Field(ge=0)
    content: bytes = Field(repr=False)
    content_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_file(self) -> Self:
        if self.row_count < 0 or not self.columns:
            raise ValueError("CSV file metadata is invalid")
        if sha256(self.content).hexdigest() != self.content_sha256:
            raise ValueError("CSV file digest mismatch")
        if b"\r" in self.content or not self.content.endswith(b"\n"):
            raise ValueError("CSV content must use a stable LF policy")
        return self


class CanonicalCsvBundle(_FrozenModel):
    schema_version: Literal["document_sdk_pdf_generic_export.v1"] = (
        EXPORT_SCHEMA_VERSION
    )
    canonical_document_id: str = Field(pattern=r"^P3CE1-document-[0-9a-f]{64}$")
    determinism_contract: Literal["CSV_BUNDLE_BYTE_DETERMINISTIC"] = (
        CSV_DETERMINISM_CONTRACT
    )
    files: tuple[CanonicalCsvFile, ...]
    file_sha256_inventory: tuple[tuple[str, str], ...]
    total_bytes: int = Field(ge=0)

    @model_validator(mode="after")
    def validate_bundle(self) -> Self:
        filenames = tuple(item.filename for item in self.files)
        if filenames != tuple(sorted(set(filenames))):
            raise ValueError("CSV file inventory must be sorted and unique")
        expected_inventory = tuple(
            (item.filename, item.content_sha256) for item in self.files
        )
        if self.file_sha256_inventory != expected_inventory:
            raise ValueError("CSV SHA inventory mismatch")
        if self.total_bytes != sum(len(item.content) for item in self.files):
            raise ValueError("CSV byte accounting mismatch")
        return self


class CanonicalXlsxExportArtifact(_FrozenModel):
    schema_version: Literal["document_sdk_pdf_generic_export.v1"] = (
        EXPORT_SCHEMA_VERSION
    )
    canonical_document_id: str = Field(pattern=r"^P3CE1-document-[0-9a-f]{64}$")
    determinism_contract: Literal["XLSX_SEMANTIC_DETERMINISTIC"] = (
        XLSX_DETERMINISM_CONTRACT
    )
    content: bytes = Field(repr=False)
    content_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    semantic_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    sheet_names: tuple[str, ...]

    @model_validator(mode="after")
    def validate_digest(self) -> Self:
        if sha256(self.content).hexdigest() != self.content_sha256:
            raise ValueError("XLSX export byte digest mismatch")
        if self.sheet_names != tuple(dict.fromkeys(self.sheet_names)):
            raise ValueError("XLSX sheet inventory repeats a name")
        return self

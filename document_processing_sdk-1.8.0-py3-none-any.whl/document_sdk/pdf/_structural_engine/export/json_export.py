"""Deterministic UTF-8 JSON export for Canonical documents."""

# ruff: noqa: EM101, EM102, TC001, TRY003

from __future__ import annotations

import json
from hashlib import sha256

from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.pdf._structural_engine.canonical.contracts import CanonicalDocument

from .contracts import (
    CanonicalExportLimits,
    CanonicalJsonExportArtifact,
    ExportLimitExceeded,
    ExportSerializationError,
)


def canonical_document_to_json_bytes(
    document: CanonicalDocument,
    *,
    limits: CanonicalExportLimits | None = None,
) -> bytes:
    """Serialize with sorted keys, compact separators, LF, and no non-finite data."""
    effective_limits = limits or CanonicalExportLimits()
    try:
        content = (
            json.dumps(
                document.model_dump(mode="json"),
                allow_nan=False,
                ensure_ascii=False,
                separators=(",", ":"),
                sort_keys=True,
            )
            + "\n"
        ).encode("utf-8")
    except (TypeError, ValueError) as exc:
        _raise_redacted_translation(
            exc,
            ExportSerializationError("Canonical JSON serialization failed"),
        )
    if len(content) > effective_limits.maximum_json_bytes:
        raise ExportLimitExceeded(
            "JSON byte limit exceeded: "
            f"{len(content)} > {effective_limits.maximum_json_bytes}"
        )
    return content


def build_json_export(
    document: CanonicalDocument,
    *,
    limits: CanonicalExportLimits | None = None,
) -> CanonicalJsonExportArtifact:
    content = canonical_document_to_json_bytes(document, limits=limits)
    return CanonicalJsonExportArtifact(
        canonical_document_id=document.canonical_document_id,
        content=content,
        content_sha256=sha256(content).hexdigest(),
    )


def validate_json_semantic_roundtrip(
    document: CanonicalDocument,
    content: bytes,
) -> None:
    """Prove that parsed generic JSON equals the Canonical JSON projection."""
    try:
        parsed = json.loads(content)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        _raise_redacted_translation(
            exc,
            ExportSerializationError("Canonical JSON is invalid"),
        )
    if parsed != document.model_dump(mode="json"):
        raise ExportSerializationError("Canonical JSON semantic roundtrip mismatch")

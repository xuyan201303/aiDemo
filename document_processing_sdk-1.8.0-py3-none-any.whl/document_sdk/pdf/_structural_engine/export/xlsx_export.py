"""Generic relational XLSX export with an explicit semantic contract."""

# ruff: noqa: EM101, EM102, TC001, TC003, TRY003

from __future__ import annotations

import re
import zipfile
from base64 import b64decode, b64encode
from binascii import Error as BinasciiError
from collections.abc import Callable
from datetime import UTC, datetime
from hashlib import sha256
from io import BytesIO
from itertools import chain
from pathlib import PurePosixPath
from typing import Any

from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.pdf._structural_engine.canonical.contracts import CanonicalDocument
from document_sdk.pdf._structural_engine.canonical.identifiers import (
    canonical_payload_sha256,
)

from .contracts import (
    CanonicalExportLimits,
    CanonicalRelationalTable,
    CanonicalXlsxExportArtifact,
    ExportLimitExceeded,
    ExportSerializationError,
)
from .relational import canonical_relational_tables

_SHEET_NAMES = {
    "document": "Document",
    "provenance": "Provenance",
    "capability_availability": "CapabilityAvailability",
    "pages": "Pages",
    "text_blocks": "TextBlocks",
    "text_spans": "TextSpans",
    "drawings": "Drawings",
    "tables": "Tables",
    "table_rows": "TableRows",
    "table_columns": "TableColumns",
    "table_cells": "TableCells",
    "document_tables": "DocumentTables",
    "logical_rows": "LogicalRows",
    "transitions": "Transitions",
    "transition_column_mappings": "TransitionColumnMappings",
    "transition_repeated_headers": "TransitionRepeatedHeaders",
    "transition_split_rows": "TransitionSplitRows",
    "transition_fingerprints": "TransitionFingerprints",
    "warnings": "Warnings",
    "warning_suppressions": "WarningSuppressions",
    "limitations": "Limitations",
}
_FIXED_WORKBOOK_TIME = datetime(1980, 1, 1, tzinfo=UTC)
_INVALID_XML_TEXT = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")
_EXTERNAL_TARGET_MODE = re.compile(
    rb"\btargetmode\s*=\s*(['\"])\s*external\s*\1",
    re.IGNORECASE,
)
_XLSX_CELL_ESCAPE_PREFIX = "__P3CE1_XLSX_CELL_V1__"
_XLSX_EMPTY_STRING_ENCODING = f"{_XLSX_CELL_ESCAPE_PREFIX}EMPTY"
_XLSX_ESCAPED_PREFIX_ENCODING = f"{_XLSX_CELL_ESCAPE_PREFIX}ESCAPED:"
_XLSX_CONTROL_TEXT_ENCODING_PREFIX = f"{_XLSX_CELL_ESCAPE_PREFIX}CONTROL_BASE64:"
_MAX_XLSX_PACKAGE_MEMBERS = 256
_MAX_XLSX_MEMBER_UNCOMPRESSED_BYTES = 64 * 1024 * 1024
_MAX_XLSX_TOTAL_UNCOMPRESSED_BYTES = 512 * 1024 * 1024
_MAX_XLSX_COMPRESSION_RATIO = 1_000
_MAX_XLSX_EXPANSION_FACTOR = 64
_MAX_XLSX_WORKSHEETS = 64
_MAX_XLSX_COLUMNS = 256


def _require_openpyxl() -> tuple[Callable[..., Any], Callable[..., Any]]:
    try:
        from openpyxl import Workbook, load_workbook
    except ImportError as exc:
        _raise_redacted_translation(
            exc,
            ExportSerializationError(
                "XLSX export requires the existing document-sdk excel extra"
            ),
        )
    return Workbook, load_workbook


def _encode_xlsx_cell_value(value: object) -> object:
    if value == "":
        return _XLSX_EMPTY_STRING_ENCODING
    if isinstance(value, str) and _INVALID_XML_TEXT.search(value):
        encoded = b64encode(value.encode("utf-8")).decode("ascii")
        return f"{_XLSX_CONTROL_TEXT_ENCODING_PREFIX}{encoded}"
    if isinstance(value, str) and value.startswith(_XLSX_CELL_ESCAPE_PREFIX):
        return f"{_XLSX_ESCAPED_PREFIX_ENCODING}{value}"
    return value


def _decode_xlsx_cell_value(value: object) -> object:
    if value == _XLSX_EMPTY_STRING_ENCODING:
        return ""
    if isinstance(value, str) and value.startswith(_XLSX_CONTROL_TEXT_ENCODING_PREFIX):
        encoded = value[len(_XLSX_CONTROL_TEXT_ENCODING_PREFIX) :]
        try:
            return b64decode(encoded, validate=True).decode("utf-8")
        except (BinasciiError, UnicodeDecodeError) as exc:
            _raise_redacted_translation(
                exc,
                ExportSerializationError("XLSX control-text encoding is invalid"),
            )
    escaped_prefix = f"{_XLSX_ESCAPED_PREFIX_ENCODING}{_XLSX_CELL_ESCAPE_PREFIX}"
    if isinstance(value, str) and value.startswith(escaped_prefix):
        return value[len(_XLSX_ESCAPED_PREFIX_ENCODING) :]
    return value


def _validate_member_name(name: str) -> None:
    normalized = name.removesuffix("/")
    if (
        not normalized
        or "\x00" in name
        or "\\" in name
        or name.startswith("/")
        or any(part in {"", ".", ".."} for part in normalized.split("/"))
        or ":" in normalized.split("/", 1)[0]
        or PurePosixPath(normalized).is_absolute()
    ):
        raise ExportSerializationError("XLSX package contains an unsafe member name")


def _preflight_xlsx_archive(
    archive: zipfile.ZipFile,
    *,
    limits: CanonicalExportLimits,
) -> tuple[zipfile.ZipInfo, ...]:
    infos = tuple(archive.infolist())
    if len(infos) > _MAX_XLSX_PACKAGE_MEMBERS:
        raise ExportLimitExceeded(
            "XLSX ZIP member limit exceeded: "
            f"{len(infos)} > {_MAX_XLSX_PACKAGE_MEMBERS}"
        )
    names = tuple(item.filename for item in infos)
    casefolded_names = tuple(item.casefold() for item in names)
    if len(names) != len(set(names)) or len(casefolded_names) != len(
        set(casefolded_names)
    ):
        raise ExportSerializationError("XLSX package contains duplicate member names")
    total_uncompressed_limit = min(
        _MAX_XLSX_TOTAL_UNCOMPRESSED_BYTES,
        limits.maximum_export_bytes * _MAX_XLSX_EXPANSION_FACTOR,
    )
    total_uncompressed = 0
    for info in infos:
        _validate_member_name(info.filename)
        if info.flag_bits & 0x1:
            raise ExportSerializationError("XLSX package contains an encrypted member")
        if not info.is_dir() and info.file_size > _MAX_XLSX_COMPRESSION_RATIO * max(
            info.compress_size, 1
        ):
            raise ExportLimitExceeded("XLSX ZIP compression ratio limit exceeded")
        if info.file_size > _MAX_XLSX_MEMBER_UNCOMPRESSED_BYTES:
            raise ExportLimitExceeded(
                "XLSX ZIP member uncompressed byte limit exceeded"
            )
        total_uncompressed += info.file_size
        if total_uncompressed > total_uncompressed_limit:
            raise ExportLimitExceeded("XLSX ZIP total uncompressed byte limit exceeded")
    return infos


def _validate_xlsx_package_safety(
    archive: zipfile.ZipFile,
    infos: tuple[zipfile.ZipInfo, ...],
) -> None:
    lowered = tuple(item.filename.lower() for item in infos)
    if any(
        "vbaproject" in item or item.startswith("xl/externallinks/") for item in lowered
    ):
        raise ExportSerializationError("XLSX contains macros or external links")
    for info in infos:
        name_casefolded = info.filename.casefold()
        if (
            not name_casefolded.endswith(".rels")
            and name_casefolded != "[content_types].xml"
        ):
            continue
        payload = archive.read(info)
        if _EXTERNAL_TARGET_MODE.search(payload) or re.search(
            rb"macroenabled",
            payload,
            re.IGNORECASE,
        ):
            raise ExportSerializationError(
                "XLSX relationship or content type is unsafe"
            )


def _validate_xlsx_package(
    content: bytes,
    *,
    limits: CanonicalExportLimits,
) -> None:
    if len(content) > limits.maximum_export_bytes:
        raise ExportLimitExceeded(
            f"XLSX byte limit exceeded: {len(content)} > {limits.maximum_export_bytes}"
        )
    try:
        with zipfile.ZipFile(BytesIO(content), "r") as archive:
            infos = _preflight_xlsx_archive(archive, limits=limits)
            _validate_xlsx_package_safety(archive, infos)
    except (ExportLimitExceeded, ExportSerializationError):
        raise
    except (
        AttributeError,
        EOFError,
        IndexError,
        KeyError,
        OSError,
        RuntimeError,
        StopIteration,
        SyntaxError,
        TypeError,
        ValueError,
        zipfile.BadZipFile,
        zipfile.LargeZipFile,
    ) as exc:
        _raise_redacted_translation(
            exc,
            ExportSerializationError("XLSX package is invalid"),
        )


def _semantic_tables(
    document: CanonicalDocument,
) -> tuple[CanonicalRelationalTable, ...]:
    return canonical_relational_tables(document, include_empty=True)


def _expected_workbook_projection(
    relations: tuple[CanonicalRelationalTable, ...],
) -> tuple[tuple[str, tuple[object, ...], tuple[tuple[object, ...], ...]], ...]:
    return tuple(
        (
            _SHEET_NAMES[item.name],
            tuple(item.columns),
            tuple(tuple(value for value in row) for row in item.rows),
        )
        for item in relations
    )


def _validate_relational_text(
    relations: tuple[CanonicalRelationalTable, ...],
    *,
    limits: CanonicalExportLimits,
) -> None:
    for relation in relations:
        for value in chain(relation.columns, chain.from_iterable(relation.rows)):
            if not isinstance(value, str):
                continue
            if len(value) > limits.maximum_xlsx_cell_characters:
                raise ExportLimitExceeded(
                    f"XLSX cell text limit exceeded for {relation.name}: "
                    f"{len(value)} > {limits.maximum_xlsx_cell_characters}"
                )
            encoded_value = _encode_xlsx_cell_value(value)
            if (
                isinstance(encoded_value, str)
                and len(encoded_value) > limits.maximum_xlsx_cell_characters
            ):
                raise ExportLimitExceeded(
                    f"XLSX encoded cell text limit exceeded for {relation.name}: "
                    f"{len(encoded_value)} > "
                    f"{limits.maximum_xlsx_cell_characters}"
                )
            if isinstance(encoded_value, str) and _INVALID_XML_TEXT.search(
                encoded_value
            ):
                raise ExportSerializationError(
                    f"XLSX encoded text is XML-incompatible in {relation.name}"
                )


def _project_xlsx_cells(cells: tuple[Any, ...]) -> tuple[object, ...]:
    values = []
    for cell in cells:
        if cell.data_type == "f" or getattr(cell, "hyperlink", None) is not None:
            raise ExportSerializationError("XLSX contains a formula or hyperlink")
        values.append(_decode_xlsx_cell_value(cell.value))
    return tuple(values)


def _project_xlsx_worksheet(
    worksheet: Any,
    *,
    limits: CanonicalExportLimits,
) -> tuple[str, tuple[object, ...], tuple[tuple[object, ...], ...]]:
    maximum_row = worksheet.max_row or 0
    maximum_column = worksheet.max_column or 0
    if maximum_row > limits.maximum_xlsx_rows_per_sheet + 1:
        raise ExportLimitExceeded("XLSX worksheet row limit exceeded")
    if maximum_column > _MAX_XLSX_COLUMNS:
        raise ExportLimitExceeded("XLSX worksheet column limit exceeded")
    worksheet_rows = iter(worksheet.iter_rows())
    headers = _project_xlsx_cells(tuple(next(worksheet_rows, ())))
    if len(headers) > _MAX_XLSX_COLUMNS:
        raise ExportLimitExceeded("XLSX worksheet column limit exceeded")
    rows = []
    for row_index, worksheet_row in enumerate(worksheet_rows, start=1):
        if row_index > limits.maximum_xlsx_rows_per_sheet:
            raise ExportLimitExceeded("XLSX worksheet row limit exceeded")
        values = _project_xlsx_cells(tuple(worksheet_row))
        if len(values) > _MAX_XLSX_COLUMNS:
            raise ExportLimitExceeded("XLSX worksheet column limit exceeded")
        rows.append(values)
    return worksheet.title, headers, tuple(rows)


def _project_xlsx_workbook(
    workbook: Any,
    *,
    limits: CanonicalExportLimits,
) -> tuple[tuple[str, tuple[object, ...], tuple[tuple[object, ...], ...]], ...]:
    if len(workbook.worksheets) > _MAX_XLSX_WORKSHEETS:
        raise ExportLimitExceeded("XLSX worksheet count limit exceeded")
    return tuple(
        _project_xlsx_worksheet(worksheet, limits=limits)
        for worksheet in workbook.worksheets
    )


def canonical_workbook_projection(
    content: bytes,
    *,
    limits: CanonicalExportLimits | None = None,
) -> tuple[tuple[str, tuple[object, ...], tuple[tuple[object, ...], ...]], ...]:
    """Reopen an XLSX and project stable sheet/header/row semantics."""
    effective_limits = limits or CanonicalExportLimits()
    _validate_xlsx_package(content, limits=effective_limits)
    _workbook_type, load_workbook = _require_openpyxl()
    try:
        workbook = load_workbook(
            BytesIO(content),
            read_only=True,
            data_only=False,
            keep_links=False,
        )
        try:
            return _project_xlsx_workbook(workbook, limits=effective_limits)
        finally:
            workbook.close()
    except (ExportLimitExceeded, ExportSerializationError):
        raise
    except (
        AttributeError,
        EOFError,
        IndexError,
        KeyError,
        OSError,
        RuntimeError,
        StopIteration,
        SyntaxError,
        TypeError,
        ValueError,
        zipfile.BadZipFile,
        zipfile.LargeZipFile,
    ) as exc:
        _raise_redacted_translation(
            exc,
            ExportSerializationError("XLSX workbook parsing failed"),
        )


def canonical_document_to_xlsx(
    document: CanonicalDocument,
    *,
    limits: CanonicalExportLimits | None = None,
) -> CanonicalXlsxExportArtifact:
    """Write fixed relational sheets; byte identity is intentionally not claimed."""
    effective_limits = limits or CanonicalExportLimits()
    relations = _semantic_tables(document)
    for relation in relations:
        if len(relation.rows) > effective_limits.maximum_xlsx_rows_per_sheet:
            raise ExportLimitExceeded(
                f"XLSX row limit exceeded for {relation.name}: "
                f"{len(relation.rows)} > "
                f"{effective_limits.maximum_xlsx_rows_per_sheet}"
            )
    _validate_relational_text(relations, limits=effective_limits)
    workbook_type, _load_workbook = _require_openpyxl()
    workbook = workbook_type()
    workbook.remove(workbook.active)
    workbook.properties.creator = "document_sdk"
    workbook.properties.lastModifiedBy = "document_sdk"
    workbook.properties.title = "Canonical Document Export"
    workbook.properties.created = _FIXED_WORKBOOK_TIME
    workbook.properties.modified = _FIXED_WORKBOOK_TIME
    for relation in relations:
        worksheet = workbook.create_sheet(_SHEET_NAMES[relation.name])
        for column_index, header_value in enumerate(relation.columns, start=1):
            cell = worksheet.cell(
                row=1,
                column=column_index,
                value=_encode_xlsx_cell_value(header_value),
            )
            cell.data_type = "s"
        for row_index, row in enumerate(relation.rows, start=2):
            for column_index, cell_value in enumerate(row, start=1):
                encoded_value = _encode_xlsx_cell_value(cell_value)
                cell = worksheet.cell(
                    row=row_index,
                    column=column_index,
                    value=encoded_value,
                )
                if isinstance(encoded_value, str):
                    cell.data_type = "s"
    output = BytesIO()
    workbook.save(output)
    workbook.close()
    content = output.getvalue()
    if len(content) > effective_limits.maximum_export_bytes:
        raise ExportLimitExceeded(
            "XLSX byte limit exceeded: "
            f"{len(content)} > {effective_limits.maximum_export_bytes}"
        )
    projection = canonical_workbook_projection(content, limits=effective_limits)
    expected_projection = _expected_workbook_projection(relations)
    if projection != expected_projection:
        raise ExportSerializationError("XLSX semantic roundtrip mismatch")
    sheet_names = tuple(item[0] for item in projection)
    return CanonicalXlsxExportArtifact(
        canonical_document_id=document.canonical_document_id,
        content=content,
        content_sha256=sha256(content).hexdigest(),
        semantic_sha256=canonical_payload_sha256(projection),
        sheet_names=sheet_names,
    )


def validate_xlsx_semantic_roundtrip(
    document: CanonicalDocument,
    artifact: CanonicalXlsxExportArtifact,
    *,
    limits: CanonicalExportLimits | None = None,
) -> None:
    """Compare reopened workbook semantics with the relational source."""
    observed = canonical_workbook_projection(artifact.content, limits=limits)
    expected = _expected_workbook_projection(_semantic_tables(document))
    if observed != expected:
        raise ExportSerializationError("XLSX semantic roundtrip mismatch")
    if artifact.semantic_sha256 != canonical_payload_sha256(observed):
        raise ExportSerializationError("XLSX semantic digest mismatch")

"""Deterministic RFC4180-compatible relational CSV bundle export."""

# ruff: noqa: C901, EM101, EM102, PLR0912, PLR0913, PLR0915, PLR2004, TC001, TRY003

from __future__ import annotations

import csv
import json
from hashlib import sha256
from io import StringIO
from typing import Any

from pydantic import ValidationError

from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.pdf._structural_engine.canonical.contracts import CanonicalDocument

from .contracts import (
    CanonicalCsvBundle,
    CanonicalCsvFile,
    CanonicalExportLimits,
    CanonicalRelationalTable,
    ExportLimitExceeded,
    ExportSerializationError,
)
from .relational import (
    CANONICAL_RELATIONAL_TABLE_SCHEMAS,
    canonical_relational_tables,
)

_EXPECTED_CSV_SCHEMAS = {
    f"{name}.csv": columns
    for name, columns in CANONICAL_RELATIONAL_TABLE_SCHEMAS.items()
}
_CANONICAL_AVAILABILITY_STATES = frozenset(
    {"AVAILABLE", "PARTIAL", "UNAVAILABLE", "UNSUPPORTED", "LIMITED_EVIDENCE"}
)


def _canonical_json_value(raw_value: str) -> Any:
    try:
        value = json.loads(raw_value)
        canonical = json.dumps(
            value,
            allow_nan=False,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        )
    except (json.JSONDecodeError, TypeError, ValueError) as exc:
        _raise_redacted_translation(
            exc,
            ExportSerializationError("CSV relationship JSON is invalid"),
        )
    if raw_value != canonical:
        raise ExportSerializationError("CSV relationship JSON is noncanonical")
    return value


def _string_identity_tuple(
    row: dict[str, str],
    column: str,
    *,
    unique: bool = True,
) -> tuple[str, ...]:
    value = _canonical_json_value(row[column])
    if not isinstance(value, list) or any(
        not isinstance(item, str) or not item for item in value
    ):
        raise ExportSerializationError("CSV relationship identity list is invalid")
    result = tuple(value)
    if unique and len(set(result)) != len(result):
        raise ExportSerializationError("CSV relationship identity list repeats a value")
    return result


def _identity_index(
    rows: list[dict[str, str]],
    column: str,
) -> dict[str, dict[str, str]]:
    values = tuple(row[column] for row in rows)
    if any(not value for value in values):
        raise ExportSerializationError("CSV entity identity is missing")
    if len(set(values)) != len(values):
        raise ExportSerializationError("CSV bundle repeats an entity identity")
    return dict(zip(values, rows, strict=True))


def _require_unique_composite(
    rows: list[dict[str, str]],
    *columns: str,
) -> None:
    values = tuple(tuple(row[column] for column in columns) for row in rows)
    if len(set(values)) != len(values):
        raise ExportSerializationError("CSV bundle repeats a composite identity")


def _integer(row: dict[str, str], column: str) -> int:
    try:
        return int(row[column])
    except (TypeError, ValueError) as exc:
        _raise_redacted_translation(
            exc,
            ExportSerializationError("CSV integer evidence is invalid"),
        )


def _csv_bytes(table: CanonicalRelationalTable) -> bytes:
    stream = StringIO(newline="")
    writer = csv.writer(stream, dialect="excel", lineterminator="\n")
    writer.writerow(table.columns)
    writer.writerows(table.rows)
    return stream.getvalue().encode("utf-8")


def canonical_document_to_csv_bundle(
    document: CanonicalDocument,
    *,
    limits: CanonicalExportLimits | None = None,
) -> CanonicalCsvBundle:
    """Export joinable entity tables; nested structure is never flattened lossy."""
    effective_limits = limits or CanonicalExportLimits()
    relations = canonical_relational_tables(document, include_empty=True)
    row_count = sum(len(item.rows) for item in relations)
    if row_count > effective_limits.maximum_csv_rows:
        raise ExportLimitExceeded(
            f"CSV row limit exceeded: {row_count} > {effective_limits.maximum_csv_rows}"
        )
    files = []
    for table in relations:
        content = _csv_bytes(table)
        files.append(
            CanonicalCsvFile(
                filename=f"{table.name}.csv",
                columns=table.columns,
                row_count=len(table.rows),
                content=content,
                content_sha256=sha256(content).hexdigest(),
            )
        )
    files_tuple = tuple(sorted(files, key=lambda item: item.filename))
    total_bytes = sum(len(item.content) for item in files_tuple)
    if total_bytes > effective_limits.maximum_export_bytes:
        raise ExportLimitExceeded(
            "CSV bundle byte limit exceeded: "
            f"{total_bytes} > {effective_limits.maximum_export_bytes}"
        )
    return CanonicalCsvBundle(
        canonical_document_id=document.canonical_document_id,
        files=files_tuple,
        file_sha256_inventory=tuple(
            (item.filename, item.content_sha256) for item in files_tuple
        ),
        total_bytes=total_bytes,
    )


def _decode_csv_bundle(
    bundle: CanonicalCsvBundle,
) -> tuple[CanonicalCsvBundle, dict[str, list[dict[str, str]]]]:
    try:
        checked_bundle = CanonicalCsvBundle.model_validate(
            bundle.model_dump(mode="python")
        )
    except (AttributeError, TypeError, ValueError, ValidationError) as exc:
        _raise_redacted_translation(
            exc,
            ExportSerializationError("CSV bundle metadata validation failed"),
        )
    expected_filenames = tuple(sorted(_EXPECTED_CSV_SCHEMAS))
    observed_filenames = tuple(item.filename for item in checked_bundle.files)
    if observed_filenames != expected_filenames:
        raise ExportSerializationError("CSV required file inventory mismatch")

    decoded: dict[str, list[dict[str, str]]] = {}
    for item in checked_bundle.files:
        expected_columns = _EXPECTED_CSV_SCHEMAS[item.filename]
        if item.columns != expected_columns:
            raise ExportSerializationError("CSV exact schema inventory mismatch")
        try:
            reader = csv.DictReader(
                StringIO(item.content.decode("utf-8")),
                dialect="excel",
                strict=True,
            )
            parsed_rows = list(reader)
        except (UnicodeDecodeError, csv.Error) as exc:
            _raise_redacted_translation(
                exc,
                ExportSerializationError("CSV bundle parsing failed"),
            )
        if tuple(reader.fieldnames or ()) != expected_columns:
            raise ExportSerializationError("CSV column inventory mismatch")
        if len(parsed_rows) != item.row_count:
            raise ExportSerializationError("CSV row accounting mismatch")
        if any(
            None in row or any(value is None for value in row.values())
            for row in parsed_rows
        ):
            raise ExportSerializationError("CSV row width does not match schema")
        decoded[item.filename] = [
            {str(key): str(value) for key, value in row.items()} for row in parsed_rows
        ]

    for filename, rows in decoded.items():
        for column in _EXPECTED_CSV_SCHEMAS[filename]:
            if not column.endswith("_json"):
                continue
            for row in rows:
                _canonical_json_value(row[column])
    return checked_bundle, decoded


def _validate_availability_columns(
    decoded: dict[str, list[dict[str, str]]],
) -> None:
    for filename, columns in _EXPECTED_CSV_SCHEMAS.items():
        availability_columns = tuple(
            column
            for column in columns
            if column == "availability" or column.endswith("_availability")
        )
        for availability_column in availability_columns:
            reason_column = f"{availability_column}_reason_codes_json"
            if reason_column not in columns:
                raise ExportSerializationError(
                    "CSV availability schema omits reason codes"
                )
            for row in decoded[filename]:
                state = row[availability_column]
                reasons = _string_identity_tuple(row, reason_column)
                if state not in _CANONICAL_AVAILABILITY_STATES:
                    raise ExportSerializationError("CSV availability state is invalid")
                if (state == "AVAILABLE") != (not reasons):
                    raise ExportSerializationError(
                        "CSV availability reason evidence is inconsistent"
                    )
                if reasons != tuple(sorted(reasons)):
                    raise ExportSerializationError(
                        "CSV availability reasons are noncanonical"
                    )


def _validate_csv_relations(
    bundle: CanonicalCsvBundle,
    decoded: dict[str, list[dict[str, str]]],
) -> None:
    document_rows = decoded["document.csv"]
    if len(document_rows) != 1:
        raise ExportSerializationError("CSV document inventory must contain one row")
    documents = _identity_index(document_rows, "canonical_document_id")
    if set(documents) != {bundle.canonical_document_id}:
        raise ExportSerializationError("CSV document identity mismatch")
    if any(
        row["canonical_document_id"] not in documents
        for filename_rows in decoded.values()
        for row in filename_rows
    ):
        raise ExportSerializationError("CSV entity crosses document identity")

    provenance = _identity_index(decoded["provenance.csv"], "canonical_document_id")
    if set(provenance) != set(documents):
        raise ExportSerializationError("CSV provenance identity mismatch")
    document_row = document_rows[0]
    provenance_row = next(iter(provenance.values()))
    if (
        provenance_row["canonical_schema_version"] != document_row["canonical_version"]
        or provenance_row["canonical_projection_version"]
        != document_row["projection_version"]
        or provenance_row["source_document_identity"]
        != document_row["source_document_identity"]
    ):
        raise ExportSerializationError("CSV provenance projection mismatch")
    for column in ("upstream_schema_versions_json", "upstream_artifact_ids_json"):
        values = _string_identity_tuple(provenance_row, column)
        if values != tuple(sorted(values)):
            raise ExportSerializationError("CSV provenance inventory is noncanonical")

    capabilities = _identity_index(decoded["capability_availability.csv"], "capability")
    if tuple(capabilities) != tuple(sorted(capabilities)):
        raise ExportSerializationError("CSV capability inventory is noncanonical")

    pages = _identity_index(decoded["pages.csv"], "page_id")
    blocks = _identity_index(decoded["text_blocks.csv"], "text_block_id")
    spans = _identity_index(decoded["text_spans.csv"], "span_id")
    drawings = _identity_index(decoded["drawings.csv"], "drawing_id")
    tables = _identity_index(decoded["tables.csv"], "table_id")
    table_rows = _identity_index(decoded["table_rows.csv"], "row_id")
    table_columns = _identity_index(decoded["table_columns.csv"], "column_id")
    cells = _identity_index(decoded["table_cells.csv"], "cell_id")
    document_tables = _identity_index(
        decoded["document_tables.csv"], "document_table_id"
    )
    logical_rows = _identity_index(decoded["logical_rows.csv"], "logical_row_id")
    transitions = _identity_index(decoded["transitions.csv"], "transition_id")
    warnings = _identity_index(decoded["warnings.csv"], "warning_id")
    warning_suppressions = _identity_index(
        decoded["warning_suppressions.csv"], "source_scope"
    )
    del spans, drawings, logical_rows, warning_suppressions

    if _integer(document_row, "projected_page_count") != len(pages):
        raise ExportSerializationError("CSV projected page count mismatch")
    page_indexes = {_integer(row, "page_index"): row for row in pages.values()}
    if len(page_indexes) != len(pages):
        raise ExportSerializationError("CSV bundle repeats a page index")

    for row in blocks.values():
        if row["page_id"] not in pages:
            raise ExportSerializationError("CSV text block references a missing page")
    for row in decoded["text_spans.csv"]:
        block = blocks.get(row["text_block_id"])
        if block is None or row["page_id"] != block["page_id"]:
            raise ExportSerializationError(
                "CSV span references a missing or cross-page text block"
            )
    for row in decoded["drawings.csv"]:
        if row["page_id"] not in pages:
            raise ExportSerializationError("CSV drawing references a missing page")

    for table_record in tables.values():
        if table_record["page_id"] not in pages:
            raise ExportSerializationError("CSV table references a missing page")
    for row in table_rows.values():
        parent_table = tables.get(row["table_id"])
        if parent_table is None or row["page_id"] != parent_table["page_id"]:
            raise ExportSerializationError(
                "CSV row references a missing or cross-page table"
            )
    for table_column_record in table_columns.values():
        parent_table = tables.get(table_column_record["table_id"])
        if (
            parent_table is None
            or table_column_record["page_id"] != parent_table["page_id"]
        ):
            raise ExportSerializationError(
                "CSV column references a missing or cross-page table"
            )
    for cell in cells.values():
        parent_table = tables.get(cell["table_id"])
        table_row = table_rows.get(cell["row_id"])
        table_column = table_columns.get(cell["column_id"])
        if (
            parent_table is None
            or table_row is None
            or table_column is None
            or cell["page_id"] != parent_table["page_id"]
            or table_row["table_id"] != cell["table_id"]
            or table_column["table_id"] != cell["table_id"]
            or _integer(table_row, "row_index") != _integer(cell, "row_index")
            or _integer(table_column, "column_index") != _integer(cell, "column_index")
        ):
            raise ExportSerializationError(
                "CSV cell references a missing or cross-table row or column"
            )

    cells_by_row: dict[str, set[str]] = {}
    cells_by_column: dict[str, set[str]] = {}
    for cell in cells.values():
        cells_by_row.setdefault(cell["row_id"], set()).add(cell["cell_id"])
        cells_by_column.setdefault(cell["column_id"], set()).add(cell["cell_id"])
    for row_id, row in table_rows.items():
        if set(_string_identity_tuple(row, "cell_ids_json")) != cells_by_row.get(
            row_id, set()
        ):
            raise ExportSerializationError("CSV row-cell membership mismatch")
    for column_id, table_column_record in table_columns.items():
        if set(
            _string_identity_tuple(table_column_record, "cell_ids_json")
        ) != cells_by_column.get(column_id, set()):
            raise ExportSerializationError("CSV column-cell membership mismatch")
    for table_id, table_record in tables.items():
        observed_rows = sum(row["table_id"] == table_id for row in table_rows.values())
        observed_columns = sum(
            column["table_id"] == table_id for column in table_columns.values()
        )
        if (
            _integer(table_record, "row_count") != observed_rows
            or _integer(table_record, "column_count") != observed_columns
        ):
            raise ExportSerializationError("CSV table cardinality mismatch")

    for page_id, page in pages.items():
        expected_tables = {
            table_id
            for table_id, table in tables.items()
            if table["page_id"] == page_id
        }
        expected_warnings = {
            warning_id
            for warning_id, warning in warnings.items()
            if warning["page_id"] == page_id
        }
        if set(_string_identity_tuple(page, "table_ids_json")) != expected_tables:
            raise ExportSerializationError("CSV page-table membership mismatch")
        if set(_string_identity_tuple(page, "warning_ids_json")) != expected_warnings:
            raise ExportSerializationError("CSV page-warning membership mismatch")
    if any(
        warning["page_id"] and warning["page_id"] not in pages
        for warning in warnings.values()
    ):
        raise ExportSerializationError("CSV warning references a missing page")
    if any(
        warning["page_id"]
        and _integer(warning, "source_page_number")
        != _integer(pages[warning["page_id"]], "page_number")
        for warning in warnings.values()
    ):
        raise ExportSerializationError("CSV warning page provenance mismatch")
    if any(not warning["source_parser_name"] for warning in warnings.values()):
        raise ExportSerializationError("CSV warning parser provenance is missing")

    transition_endpoints: dict[str, tuple[str, str]] = {}
    for transition_id, transition in transitions.items():
        left_table_id = transition["left_table_id"]
        right_table_id = transition["right_table_id"]
        if left_table_id not in tables or right_table_id not in tables:
            raise ExportSerializationError("CSV transition references a missing table")
        transition_endpoints[transition_id] = (left_table_id, right_table_id)

    document_table_memberships: dict[str, set[str]] = {
        table_id: set() for table_id in tables
    }
    document_table_links: dict[str, set[str]] = {}
    for document_table_id, document_table in document_tables.items():
        table_ids = set(_string_identity_tuple(document_table, "table_ids_json"))
        transition_ids = set(
            _string_identity_tuple(document_table, "transition_ids_json")
        )
        if table_ids - set(tables) or transition_ids - set(transitions):
            raise ExportSerializationError(
                "CSV document table references missing canonical authority"
            )
        if any(
            set(transition_endpoints[transition_id]) - table_ids
            for transition_id in transition_ids
        ):
            raise ExportSerializationError(
                "CSV document table transition crosses its table inventory"
            )
        document_table_links[document_table_id] = table_ids
        for table_id in table_ids:
            document_table_memberships[table_id].add(document_table_id)
    for table_id, table_record in tables.items():
        if (
            set(_string_identity_tuple(table_record, "document_table_ids_json"))
            != document_table_memberships[table_id]
        ):
            raise ExportSerializationError(
                "CSV table-document-table membership mismatch"
            )

    for logical_row in decoded["logical_rows.csv"]:
        document_table_id = logical_row["document_table_id"]
        linked_table_ids = document_table_links.get(document_table_id)
        if linked_table_ids is None:
            raise ExportSerializationError(
                "CSV logical row references a missing document table"
            )
        joined_row_ids = _string_identity_tuple(logical_row, "row_ids_json")
        joined_cell_ids = _string_identity_tuple(logical_row, "cell_ids_json")
        source_row_ids = _string_identity_tuple(
            logical_row, "source_row_ids_json", unique=False
        )
        source_cell_ids = _string_identity_tuple(
            logical_row, "source_cell_ids_json", unique=False
        )
        if len(joined_row_ids) != len(source_row_ids) or len(joined_cell_ids) != len(
            source_cell_ids
        ):
            raise ExportSerializationError("CSV logical row join cardinality mismatch")
        if set(joined_row_ids) - set(table_rows) or set(joined_cell_ids) - set(cells):
            raise ExportSerializationError(
                "CSV logical row references missing canonical row or cell"
            )
        if any(
            table_rows[row_id]["table_id"] not in linked_table_ids
            for row_id in joined_row_ids
        ):
            raise ExportSerializationError("CSV logical row crosses a document table")
        if any(
            cells[cell_id]["table_id"] not in linked_table_ids
            for cell_id in joined_cell_ids
        ):
            raise ExportSerializationError("CSV logical cell crosses a document table")
        source_page_indexes = _canonical_json_value(
            logical_row["source_page_indexes_json"]
        )
        if not isinstance(source_page_indexes, list) or any(
            not isinstance(item, int) or item not in page_indexes
            for item in source_page_indexes
        ):
            raise ExportSerializationError("CSV logical row page evidence is invalid")

    _validate_transition_relations(
        decoded=decoded,
        provenance_row=provenance_row,
        pages=pages,
        tables=tables,
        rows=table_rows,
        columns=table_columns,
        cells=cells,
        transitions=transitions,
        transition_endpoints=transition_endpoints,
    )
    _validate_warning_suppressions(decoded["warning_suppressions.csv"])

    _require_unique_composite(decoded["limitations.csv"], "scope", "entity_id", "code")
    if any(
        row["scope"] != "document" or row["entity_id"] != bundle.canonical_document_id
        for row in decoded["limitations.csv"]
    ):
        raise ExportSerializationError("CSV limitation scope is invalid")


def _validate_transition_relations(
    *,
    decoded: dict[str, list[dict[str, str]]],
    provenance_row: dict[str, str],
    pages: dict[str, dict[str, str]],
    tables: dict[str, dict[str, str]],
    rows: dict[str, dict[str, str]],
    columns: dict[str, dict[str, str]],
    cells: dict[str, dict[str, str]],
    transitions: dict[str, dict[str, str]],
    transition_endpoints: dict[str, tuple[str, str]],
) -> None:
    mapping_rows = decoded["transition_column_mappings.csv"]
    _require_unique_composite(mapping_rows, "transition_id", "mapping_index")
    for mapping in mapping_rows:
        endpoints = transition_endpoints.get(mapping["transition_id"])
        left_column = columns.get(mapping["left_column_id"])
        right_column = columns.get(mapping["right_column_id"])
        if (
            endpoints is None
            or left_column is None
            or right_column is None
            or left_column["table_id"] != endpoints[0]
            or right_column["table_id"] != endpoints[1]
            or _integer(left_column, "column_index")
            != _integer(mapping, "left_column_index")
            or _integer(right_column, "column_index")
            != _integer(mapping, "right_column_index")
        ):
            raise ExportSerializationError(
                "CSV transition column mapping crosses its endpoint tables"
            )

    repeated_rows = decoded["transition_repeated_headers.csv"]
    _require_unique_composite(repeated_rows, "transition_id", "evidence_index")
    repeated_identities: dict[str, list[str]] = {}
    for evidence in repeated_rows:
        endpoints = transition_endpoints.get(evidence["transition_id"])
        if endpoints is None:
            raise ExportSerializationError(
                "CSV repeated-header evidence references a missing transition"
            )
        left_row_ids = _string_identity_tuple(evidence, "left_row_ids_json")
        right_row_ids = _string_identity_tuple(evidence, "right_row_ids_json")
        left_cell_ids = _string_identity_tuple(evidence, "left_cell_ids_json")
        right_cell_ids = _string_identity_tuple(evidence, "right_cell_ids_json")
        source_left_rows = _string_identity_tuple(
            evidence, "source_left_row_ids_json", unique=False
        )
        source_right_rows = _string_identity_tuple(
            evidence, "source_right_row_ids_json", unique=False
        )
        source_left_cells = _string_identity_tuple(
            evidence, "source_left_cell_ids_json", unique=False
        )
        source_right_cells = _string_identity_tuple(
            evidence, "source_right_cell_ids_json", unique=False
        )
        if (
            len(left_row_ids) != len(source_left_rows)
            or len(right_row_ids) != len(source_right_rows)
            or len(left_cell_ids) != len(source_left_cells)
            or len(right_cell_ids) != len(source_right_cells)
        ):
            raise ExportSerializationError(
                "CSV repeated-header source join cardinality mismatch"
            )
        if any(
            row_id not in rows or rows[row_id]["table_id"] != endpoints[0]
            for row_id in left_row_ids
        ) or any(
            row_id not in rows or rows[row_id]["table_id"] != endpoints[1]
            for row_id in right_row_ids
        ):
            raise ExportSerializationError(
                "CSV repeated-header row crosses an endpoint table"
            )
        if any(
            cell_id not in cells or cells[cell_id]["table_id"] != endpoints[0]
            for cell_id in left_cell_ids
        ) or any(
            cell_id not in cells or cells[cell_id]["table_id"] != endpoints[1]
            for cell_id in right_cell_ids
        ):
            raise ExportSerializationError(
                "CSV repeated-header cell crosses an endpoint table"
            )
        repeated_identities.setdefault(evidence["transition_id"], []).append(
            evidence["logical_header_identity"]
        )

    split_rows = decoded["transition_split_rows.csv"]
    _require_unique_composite(split_rows, "transition_id", "evidence_index")
    split_identities: dict[str, list[str]] = {}
    for evidence in split_rows:
        endpoints = transition_endpoints.get(evidence["transition_id"])
        left_row = rows.get(evidence["left_row_id"])
        right_row = rows.get(evidence["right_row_id"])
        left_cell_ids = _string_identity_tuple(evidence, "left_cell_ids_json")
        right_cell_ids = _string_identity_tuple(evidence, "right_cell_ids_json")
        source_left_cells = _string_identity_tuple(
            evidence, "source_left_cell_ids_json", unique=False
        )
        source_right_cells = _string_identity_tuple(
            evidence, "source_right_cell_ids_json", unique=False
        )
        if (
            endpoints is None
            or left_row is None
            or right_row is None
            or left_row["table_id"] != endpoints[0]
            or right_row["table_id"] != endpoints[1]
            or len(left_cell_ids) != len(source_left_cells)
            or len(right_cell_ids) != len(source_right_cells)
        ):
            raise ExportSerializationError(
                "CSV split-row evidence crosses its endpoint rows"
            )
        if any(
            cell_id not in cells or cells[cell_id]["table_id"] != endpoints[0]
            for cell_id in left_cell_ids
        ) or any(
            cell_id not in cells or cells[cell_id]["table_id"] != endpoints[1]
            for cell_id in right_cell_ids
        ):
            raise ExportSerializationError(
                "CSV split-row cell crosses an endpoint table"
            )
        mapped_indexes = _canonical_json_value(evidence["mapped_column_indexes_json"])
        local_order = _canonical_json_value(evidence["local_fragment_order_json"])
        if not isinstance(mapped_indexes, list) or any(
            not isinstance(pair, list)
            or len(pair) != 2
            or any(not isinstance(index, int) for index in pair)
            for pair in mapped_indexes
        ):
            raise ExportSerializationError(
                "CSV split-row column mapping evidence is invalid"
            )
        if not isinstance(local_order, list) or any(
            item not in {"LEFT", "RIGHT"} for item in local_order
        ):
            raise ExportSerializationError("CSV split-row local order is invalid")
        split_identities.setdefault(evidence["transition_id"], []).append(
            evidence["source_fragment_link_id"]
        )

    for transition_id, transition in transitions.items():
        if tuple(sorted(repeated_identities.get(transition_id, []))) != tuple(
            sorted(
                _string_identity_tuple(transition, "repeated_header_evidence_ids_json")
            )
        ):
            raise ExportSerializationError(
                "CSV repeated-header identity inventory mismatch"
            )
        if tuple(sorted(split_identities.get(transition_id, []))) != tuple(
            sorted(_string_identity_tuple(transition, "split_row_evidence_ids_json"))
        ):
            raise ExportSerializationError("CSV split-row identity inventory mismatch")

    fingerprint_rows = _identity_index(
        decoded["transition_fingerprints.csv"], "transition_id"
    )
    for transition_id, transition in transitions.items():
        fingerprint = fingerprint_rows.get(transition_id)
        summary_present = bool(transition["source_fingerprint_id"])
        if summary_present != (fingerprint is not None):
            raise ExportSerializationError(
                "CSV transition fingerprint payload mismatch"
            )
        if fingerprint is None:
            continue
        left_table_id, right_table_id = transition_endpoints[transition_id]
        left_table = tables[left_table_id]
        right_table = tables[right_table_id]
        left_page = pages[left_table["page_id"]]
        right_page = pages[right_table["page_id"]]
        if (
            fingerprint["source_fingerprint_id"] != transition["source_fingerprint_id"]
            or fingerprint["semantic_fingerprint_identity"]
            != transition["semantic_fingerprint_identity"]
            or fingerprint["state"] != transition["fingerprint_state"]
            or _string_identity_tuple(fingerprint, "limitation_codes_json")
            != _string_identity_tuple(transition, "fingerprint_limitation_codes_json")
            or fingerprint["source_transition_id"] != transition["source_transition_id"]
            or fingerprint["source_sha256"] != provenance_row["source_sha256"]
            or fingerprint["left_source_table_id"] != left_table["source_table_id"]
            or fingerprint["right_source_table_id"] != right_table["source_table_id"]
            or fingerprint["left_page_id"] != left_page["source_page_id"]
            or fingerprint["right_page_id"] != right_page["source_page_id"]
            or _integer(fingerprint, "left_page_index")
            != _integer(left_page, "page_index")
            or _integer(fingerprint, "right_page_index")
            != _integer(right_page, "page_index")
        ):
            raise ExportSerializationError("CSV transition fingerprint join mismatch")


def _validate_warning_suppressions(rows: list[dict[str, str]]) -> None:
    _identity_index(rows, "source_scope")
    for row in rows:
        if row["source_scope"] not in {"facts", "layout"}:
            raise ExportSerializationError("CSV warning suppression scope is invalid")
        total = _integer(row, "suppressed_warning_count")
        if total < 1:
            raise ExportSerializationError("CSV warning suppression count is invalid")
        for column in (
            "suppressed_warning_count_by_code_json",
            "suppressed_warning_count_by_scope_json",
        ):
            value = _canonical_json_value(row[column])
            if not isinstance(value, list) or any(
                not isinstance(item, list)
                or len(item) != 2
                or not isinstance(item[0], str)
                or not isinstance(item[1], int)
                or isinstance(item[1], bool)
                for item in value
            ):
                raise ExportSerializationError(
                    "CSV warning suppression accounting is invalid"
                )
            pairs = tuple((item[0], item[1]) for item in value)
            if (
                pairs != tuple(sorted(pairs))
                or len({item[0] for item in pairs}) != len(pairs)
                or sum(item[1] for item in pairs) != total
            ):
                raise ExportSerializationError(
                    "CSV warning suppression accounting does not balance"
                )


def validate_csv_join_integrity(bundle: CanonicalCsvBundle) -> None:
    """Verify exact schemas plus every Canonical relational foreign key."""
    try:
        checked_bundle, decoded = _decode_csv_bundle(bundle)
        _validate_availability_columns(decoded)
        _validate_csv_relations(checked_bundle, decoded)
    except KeyError as exc:
        _raise_redacted_translation(
            exc,
            ExportSerializationError("CSV required column is missing"),
        )

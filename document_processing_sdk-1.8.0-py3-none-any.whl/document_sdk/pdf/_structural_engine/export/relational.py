"""Deterministic relational flattening shared by CSV and XLSX."""

# ruff: noqa: C901, EM101, PERF401, PLR0912, PLR0915, TC001, TC003, TRY003

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from types import MappingProxyType

from document_sdk.pdf._structural_engine.canonical.contracts import (
    CanonicalAvailability,
    CanonicalBoundingBox,
    CanonicalDocument,
    CanonicalPageBox,
)

from .contracts import CanonicalRelationalTable, RelationalScalar

CANONICAL_RELATIONAL_TABLE_SCHEMAS: Mapping[str, tuple[str, ...]] = MappingProxyType(
    {
        "document": (
            "canonical_document_id",
            "canonical_version",
            "projection_version",
            "source_document_identity",
            "page_count",
            "projected_page_count",
            "availability",
            "availability_reason_codes_json",
            "family",
            "family_status",
            "family_auto_assignment",
            "limitations_json",
        ),
        "provenance": (
            "canonical_document_id",
            "canonical_schema_version",
            "canonical_projection_version",
            "canonical_identity_domain",
            "source_sha256",
            "source_document_identity",
            "source_parser_name",
            "source_parser_version",
            "upstream_schema_versions_json",
            "upstream_artifact_ids_json",
            "projection_limit_digest",
        ),
        "capability_availability": (
            "canonical_document_id",
            "capability",
            "availability",
            "availability_reason_codes_json",
        ),
        "pages": (
            "canonical_document_id",
            "page_id",
            "source_page_id",
            "page_index",
            "page_number",
            "rotation",
            "canonical_width",
            "canonical_height",
            "coordinate_space",
            "origin",
            "rotation_normalized",
            "media_box_json",
            "crop_box_json",
            "effective_page_box_json",
            "effective_page_box_basis",
            "effective_origin_x",
            "effective_origin_y",
            "user_unit",
            "user_unit_authority",
            "table_ids_json",
            "page_table_outcome",
            "page_table_availability",
            "page_table_availability_reason_codes_json",
            "page_table_negative_evidence_categories_json",
            "warning_ids_json",
            "availability",
            "availability_reason_codes_json",
            "limitations_json",
        ),
        "text_blocks": (
            "canonical_document_id",
            "page_id",
            "text_block_id",
            "source_block_id",
            "block_index",
            "text",
            "bbox_json",
            "role",
            "role_status",
            "availability",
            "availability_reason_codes_json",
            "limitations_json",
        ),
        "text_spans": (
            "canonical_document_id",
            "page_id",
            "text_block_id",
            "span_id",
            "source_fact_id",
            "source_layout_node_id",
            "span_index",
            "text",
            "bbox_json",
            "font_name",
            "font_size",
            "rotation",
            "availability",
            "availability_reason_codes_json",
        ),
        "drawings": (
            "canonical_document_id",
            "page_id",
            "drawing_id",
            "source_drawing_id",
            "drawing_index",
            "kind",
            "bbox_json",
            "path_geometry_complete",
            "path_segment_count",
            "availability",
            "availability_reason_codes_json",
            "limitations_json",
        ),
        "tables": (
            "canonical_document_id",
            "page_id",
            "table_id",
            "source_table_id",
            "table_ordinal",
            "bbox_json",
            "row_count",
            "column_count",
            "state",
            "availability",
            "availability_reason_codes_json",
            "document_table_ids_json",
            "limitations_json",
        ),
        "table_rows": (
            "canonical_document_id",
            "page_id",
            "table_id",
            "row_id",
            "source_row_id",
            "row_index",
            "cell_ids_json",
            "bbox_json",
            "availability",
            "availability_reason_codes_json",
        ),
        "table_columns": (
            "canonical_document_id",
            "page_id",
            "table_id",
            "column_id",
            "source_column_id",
            "column_index",
            "cell_ids_json",
            "bbox_json",
            "availability",
            "availability_reason_codes_json",
        ),
        "table_cells": (
            "canonical_document_id",
            "page_id",
            "table_id",
            "row_id",
            "column_id",
            "cell_id",
            "source_cell_id",
            "row_index",
            "column_index",
            "row_span",
            "column_span",
            "text",
            "text_available",
            "bbox_json",
            "state",
            "role",
            "role_status",
            "availability",
            "availability_reason_codes_json",
            "limitations_json",
        ),
        "document_tables": (
            "canonical_document_id",
            "document_table_id",
            "source_document_table_id",
            "canonical_header_identity",
            "repeated_header_identities_json",
            "status",
            "table_ids_json",
            "transition_ids_json",
            "limitations_json",
        ),
        "logical_rows": (
            "canonical_document_id",
            "document_table_id",
            "logical_row_id",
            "source_logical_row_id",
            "row_ids_json",
            "cell_ids_json",
            "source_row_ids_json",
            "source_cell_ids_json",
            "source_page_indexes_json",
            "repeated_header_occurrence",
            "limitations_json",
        ),
        "transitions": (
            "canonical_document_id",
            "transition_id",
            "source_transition_id",
            "left_table_id",
            "right_table_id",
            "outcome",
            "repeated_header",
            "split_row",
            "repeated_header_evidence_ids_json",
            "split_row_evidence_ids_json",
            "table_geometry_compatible",
            "topology_compatible",
            "page_boundary_evidence_strength",
            "fingerprint_support_strength",
            "candidate_pair_count",
            "algorithm_version",
            "source_fingerprint_id",
            "semantic_fingerprint_identity",
            "fingerprint_state",
            "fingerprint_limitation_codes_json",
            "availability",
            "availability_reason_codes_json",
            "limitations_json",
        ),
        "transition_column_mappings": (
            "canonical_document_id",
            "transition_id",
            "mapping_index",
            "left_column_id",
            "right_column_id",
            "source_left_column_id",
            "source_right_column_id",
            "left_column_index",
            "right_column_index",
            "normalized_axis_distance",
            "width_ratio_difference",
            "topology_compatible",
            "evidence_strength",
            "conflicting_evidence_json",
            "reason_code",
        ),
        "transition_repeated_headers": (
            "canonical_document_id",
            "transition_id",
            "evidence_index",
            "logical_header_identity",
            "left_row_ids_json",
            "right_row_ids_json",
            "left_cell_ids_json",
            "right_cell_ids_json",
            "source_left_row_ids_json",
            "source_right_row_ids_json",
            "source_left_cell_ids_json",
            "source_right_cell_ids_json",
            "occurrence_index",
            "exact_symbolic_repeat",
            "topology_compatible",
        ),
        "transition_split_rows": (
            "canonical_document_id",
            "transition_id",
            "evidence_index",
            "source_fragment_link_id",
            "left_row_id",
            "right_row_id",
            "left_cell_ids_json",
            "right_cell_ids_json",
            "source_left_row_id",
            "source_right_row_id",
            "source_left_cell_ids_json",
            "source_right_cell_ids_json",
            "mapped_column_indexes_json",
            "local_fragment_order_json",
            "physically_incomplete_left",
            "physically_compatible_right",
            "conflicting_evidence_json",
        ),
        "transition_fingerprints": (
            "canonical_document_id",
            "transition_id",
            "source_fingerprint_id",
            "semantic_fingerprint_identity",
            "feature_schema_version",
            "state",
            "source_sha256",
            "source_document_identity",
            "page_table_manifest_sha256",
            "source_transition_id",
            "left_page_index",
            "right_page_index",
            "left_page_id",
            "right_page_id",
            "left_source_table_id",
            "right_source_table_id",
            "left_table_sidecar_id",
            "right_table_sidecar_id",
            "left_table_sidecar_sha256",
            "right_table_sidecar_sha256",
            "left_configuration_identity",
            "right_configuration_identity",
            "left_dependency_identity",
            "right_dependency_identity",
            "page_pair_geometry_json",
            "column_continuity_json",
            "header_continuity_json",
            "row_cell_continuity_json",
            "pair_context_json",
            "safety_state_json",
            "limitation_codes_json",
        ),
        "warnings": (
            "canonical_document_id",
            "warning_id",
            "page_id",
            "source_page_number",
            "code",
            "severity",
            "message",
            "recoverable",
            "source_fact_id",
            "source_parser_name",
            "source_scope",
            "occurrence_index",
        ),
        "warning_suppressions": (
            "canonical_document_id",
            "source_scope",
            "suppressed_warning_count",
            "suppressed_warning_count_by_code_json",
            "suppressed_warning_count_by_scope_json",
            "suppressed_affected_page_count",
            "suppressed_affected_fact_count",
        ),
        "limitations": (
            "canonical_document_id",
            "scope",
            "entity_id",
            "code",
        ),
    }
)


def _json_cell(value: object) -> str:
    return json.dumps(
        value,
        allow_nan=False,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    )


def _model_json(value: CanonicalBoundingBox | CanonicalPageBox) -> str:
    return _json_cell(value.model_dump(mode="json"))


def _state(value: CanonicalAvailability) -> str:
    return str(value.state)


def _reason_codes(value: CanonicalAvailability) -> str:
    return _json_cell(value.reason_codes)


def _table(
    name: str,
    columns: tuple[str, ...],
    rows: Sequence[tuple[RelationalScalar, ...]],
) -> CanonicalRelationalTable:
    if CANONICAL_RELATIONAL_TABLE_SCHEMAS.get(name) != columns:
        raise ValueError("relational table schema does not match the fixed inventory")
    return CanonicalRelationalTable(name=name, columns=columns, rows=tuple(rows))


def canonical_relational_tables(
    document: CanonicalDocument,
    *,
    include_empty: bool = False,
) -> tuple[CanonicalRelationalTable, ...]:
    """Flatten Canonical entities without recomputing document structure."""
    document_id = document.canonical_document_id
    tables: list[CanonicalRelationalTable] = []
    tables.append(
        _table(
            "document",
            (
                "canonical_document_id",
                "canonical_version",
                "projection_version",
                "source_document_identity",
                "page_count",
                "projected_page_count",
                "availability",
                "availability_reason_codes_json",
                "family",
                "family_status",
                "family_auto_assignment",
                "limitations_json",
            ),
            [
                (
                    document_id,
                    document.canonical_version,
                    document.projection_version,
                    document.source_document_identity,
                    document.page_count,
                    document.projected_page_count,
                    _state(document.availability),
                    _reason_codes(document.availability),
                    document.family,
                    document.family_status,
                    document.family_auto_assignment,
                    _json_cell(document.limitations),
                )
            ],
        )
    )
    provenance = document.provenance
    tables.append(
        _table(
            "provenance",
            (
                "canonical_document_id",
                "canonical_schema_version",
                "canonical_projection_version",
                "canonical_identity_domain",
                "source_sha256",
                "source_document_identity",
                "source_parser_name",
                "source_parser_version",
                "upstream_schema_versions_json",
                "upstream_artifact_ids_json",
                "projection_limit_digest",
            ),
            [
                (
                    document_id,
                    provenance.canonical_schema_version,
                    provenance.canonical_projection_version,
                    provenance.canonical_identity_domain,
                    provenance.source_sha256,
                    provenance.source_document_identity,
                    provenance.source_parser_name,
                    provenance.source_parser_version,
                    _json_cell(provenance.upstream_schema_versions),
                    _json_cell(provenance.upstream_artifact_ids),
                    provenance.projection_limit_digest,
                )
            ],
        )
    )
    tables.append(
        _table(
            "capability_availability",
            (
                "canonical_document_id",
                "capability",
                "availability",
                "availability_reason_codes_json",
            ),
            [
                (
                    document_id,
                    item.capability,
                    _state(item.availability),
                    _reason_codes(item.availability),
                )
                for item in document.capability_availability
            ],
        )
    )
    page_rows: list[tuple[RelationalScalar, ...]] = []
    block_rows: list[tuple[RelationalScalar, ...]] = []
    span_rows: list[tuple[RelationalScalar, ...]] = []
    drawing_rows: list[tuple[RelationalScalar, ...]] = []
    for page in document.pages:
        geometry = page.geometry
        page_rows.append(
            (
                document_id,
                page.page_id,
                page.source_page_id,
                page.page_index,
                page.page_number,
                geometry.rotation,
                geometry.canonical_width,
                geometry.canonical_height,
                geometry.coordinate_space,
                geometry.origin,
                geometry.rotation_normalized,
                _model_json(geometry.media_box),
                _model_json(geometry.crop_box),
                _model_json(geometry.effective_page_box),
                geometry.effective_page_box_basis,
                geometry.effective_origin_x,
                geometry.effective_origin_y,
                geometry.user_unit,
                geometry.user_unit_authority,
                _json_cell(page.table_ids),
                page.page_table_outcome,
                _state(page.page_table_availability),
                _reason_codes(page.page_table_availability),
                _json_cell(page.page_table_negative_evidence_categories),
                _json_cell(page.warning_ids),
                _state(page.availability),
                _reason_codes(page.availability),
                _json_cell(page.limitation_codes),
            )
        )
        for block in page.text_blocks:
            block_rows.append(
                (
                    document_id,
                    page.page_id,
                    block.text_block_id,
                    block.source_block_id,
                    block.block_index,
                    block.text,
                    _model_json(block.bbox),
                    block.role,
                    block.role_status,
                    _state(block.availability),
                    _reason_codes(block.availability),
                    _json_cell(block.limitation_codes),
                )
            )
            for span in block.spans:
                span_rows.append(
                    (
                        document_id,
                        page.page_id,
                        block.text_block_id,
                        span.span_id,
                        span.source_fact_id,
                        span.source_layout_node_id,
                        span.span_index,
                        span.text,
                        _model_json(span.bbox),
                        span.font_name,
                        span.font_size,
                        span.rotation,
                        _state(span.availability),
                        _reason_codes(span.availability),
                    )
                )
        for drawing in page.drawings:
            drawing_rows.append(
                (
                    document_id,
                    page.page_id,
                    drawing.drawing_id,
                    drawing.source_drawing_id,
                    drawing.drawing_index,
                    drawing.kind,
                    _model_json(drawing.bbox),
                    drawing.path_geometry_complete,
                    drawing.path_segment_count,
                    _state(drawing.availability),
                    _reason_codes(drawing.availability),
                    _json_cell(drawing.limitation_codes),
                )
            )
    tables.append(
        _table(
            "pages",
            (
                "canonical_document_id",
                "page_id",
                "source_page_id",
                "page_index",
                "page_number",
                "rotation",
                "canonical_width",
                "canonical_height",
                "coordinate_space",
                "origin",
                "rotation_normalized",
                "media_box_json",
                "crop_box_json",
                "effective_page_box_json",
                "effective_page_box_basis",
                "effective_origin_x",
                "effective_origin_y",
                "user_unit",
                "user_unit_authority",
                "table_ids_json",
                "page_table_outcome",
                "page_table_availability",
                "page_table_availability_reason_codes_json",
                "page_table_negative_evidence_categories_json",
                "warning_ids_json",
                "availability",
                "availability_reason_codes_json",
                "limitations_json",
            ),
            page_rows,
        )
    )
    entity_tables = (
        _table(
            "text_blocks",
            (
                "canonical_document_id",
                "page_id",
                "text_block_id",
                "source_block_id",
                "block_index",
                "text",
                "bbox_json",
                "role",
                "role_status",
                "availability",
                "availability_reason_codes_json",
                "limitations_json",
            ),
            block_rows,
        ),
        _table(
            "text_spans",
            (
                "canonical_document_id",
                "page_id",
                "text_block_id",
                "span_id",
                "source_fact_id",
                "source_layout_node_id",
                "span_index",
                "text",
                "bbox_json",
                "font_name",
                "font_size",
                "rotation",
                "availability",
                "availability_reason_codes_json",
            ),
            span_rows,
        ),
        _table(
            "drawings",
            (
                "canonical_document_id",
                "page_id",
                "drawing_id",
                "source_drawing_id",
                "drawing_index",
                "kind",
                "bbox_json",
                "path_geometry_complete",
                "path_segment_count",
                "availability",
                "availability_reason_codes_json",
                "limitations_json",
            ),
            drawing_rows,
        ),
    )
    tables.extend(item for item in entity_tables if include_empty or item.rows)
    table_rows: list[tuple[RelationalScalar, ...]] = []
    row_rows: list[tuple[RelationalScalar, ...]] = []
    column_rows: list[tuple[RelationalScalar, ...]] = []
    cell_rows: list[tuple[RelationalScalar, ...]] = []
    for table in document.tables:
        column_ids_by_index = {
            item.column_index: item.column_id for item in table.columns
        }
        table_rows.append(
            (
                document_id,
                table.page_id,
                table.table_id,
                table.source_table_id,
                table.table_ordinal,
                _model_json(table.bbox),
                table.row_count,
                table.column_count,
                table.state,
                _state(table.availability),
                _reason_codes(table.availability),
                _json_cell(table.document_table_ids),
                _json_cell(table.limitation_codes),
            )
        )
        for table_row in table.rows:
            row_rows.append(
                (
                    document_id,
                    table.page_id,
                    table.table_id,
                    table_row.row_id,
                    table_row.source_row_id,
                    table_row.row_index,
                    _json_cell(table_row.cell_ids),
                    _model_json(table_row.bbox),
                    _state(table_row.availability),
                    _reason_codes(table_row.availability),
                )
            )
        for table_column in table.columns:
            column_rows.append(
                (
                    document_id,
                    table.page_id,
                    table.table_id,
                    table_column.column_id,
                    table_column.source_column_id,
                    table_column.column_index,
                    _json_cell(table_column.cell_ids),
                    _model_json(table_column.bbox),
                    _state(table_column.availability),
                    _reason_codes(table_column.availability),
                )
            )
        for cell in table.cells:
            cell_rows.append(
                (
                    document_id,
                    table.page_id,
                    table.table_id,
                    cell.row_id,
                    column_ids_by_index[cell.column_index],
                    cell.cell_id,
                    cell.source_cell_id,
                    cell.row_index,
                    cell.column_index,
                    cell.row_span,
                    cell.column_span,
                    cell.text,
                    cell.text_available,
                    _model_json(cell.bbox),
                    cell.state,
                    cell.role,
                    cell.role_status,
                    _state(cell.availability),
                    _reason_codes(cell.availability),
                    _json_cell(cell.limitation_codes),
                )
            )
    structural_tables = (
        _table(
            "tables",
            (
                "canonical_document_id",
                "page_id",
                "table_id",
                "source_table_id",
                "table_ordinal",
                "bbox_json",
                "row_count",
                "column_count",
                "state",
                "availability",
                "availability_reason_codes_json",
                "document_table_ids_json",
                "limitations_json",
            ),
            table_rows,
        ),
        _table(
            "table_rows",
            (
                "canonical_document_id",
                "page_id",
                "table_id",
                "row_id",
                "source_row_id",
                "row_index",
                "cell_ids_json",
                "bbox_json",
                "availability",
                "availability_reason_codes_json",
            ),
            row_rows,
        ),
        _table(
            "table_columns",
            (
                "canonical_document_id",
                "page_id",
                "table_id",
                "column_id",
                "source_column_id",
                "column_index",
                "cell_ids_json",
                "bbox_json",
                "availability",
                "availability_reason_codes_json",
            ),
            column_rows,
        ),
        _table(
            "table_cells",
            (
                "canonical_document_id",
                "page_id",
                "table_id",
                "row_id",
                "column_id",
                "cell_id",
                "source_cell_id",
                "row_index",
                "column_index",
                "row_span",
                "column_span",
                "text",
                "text_available",
                "bbox_json",
                "state",
                "role",
                "role_status",
                "availability",
                "availability_reason_codes_json",
                "limitations_json",
            ),
            cell_rows,
        ),
    )
    tables.extend(item for item in structural_tables if include_empty or item.rows)
    document_table_rows: list[tuple[RelationalScalar, ...]] = []
    logical_row_rows: list[tuple[RelationalScalar, ...]] = []
    for document_table in document.document_tables:
        document_table_rows.append(
            (
                document_id,
                document_table.document_table_id,
                document_table.source_document_table_id,
                document_table.canonical_header_identity,
                _json_cell(document_table.repeated_header_identities),
                document_table.status,
                _json_cell(document_table.table_ids),
                _json_cell(document_table.transition_ids),
                _json_cell(document_table.limitation_codes),
            )
        )
        for logical_row in document_table.logical_rows:
            logical_row_rows.append(
                (
                    document_id,
                    document_table.document_table_id,
                    logical_row.logical_row_id,
                    logical_row.source_logical_row_id,
                    _json_cell(logical_row.row_ids),
                    _json_cell(logical_row.cell_ids),
                    _json_cell(logical_row.source_row_ids),
                    _json_cell(logical_row.source_cell_ids),
                    _json_cell(logical_row.source_page_indexes),
                    logical_row.repeated_header_occurrence,
                    _json_cell(logical_row.limitation_codes),
                )
            )
    continuation_tables = (
        _table(
            "document_tables",
            (
                "canonical_document_id",
                "document_table_id",
                "source_document_table_id",
                "canonical_header_identity",
                "repeated_header_identities_json",
                "status",
                "table_ids_json",
                "transition_ids_json",
                "limitations_json",
            ),
            document_table_rows,
        ),
        _table(
            "logical_rows",
            (
                "canonical_document_id",
                "document_table_id",
                "logical_row_id",
                "source_logical_row_id",
                "row_ids_json",
                "cell_ids_json",
                "source_row_ids_json",
                "source_cell_ids_json",
                "source_page_indexes_json",
                "repeated_header_occurrence",
                "limitations_json",
            ),
            logical_row_rows,
        ),
    )
    tables.extend(item for item in continuation_tables if include_empty or item.rows)
    transition_rows: list[tuple[RelationalScalar, ...]] = []
    transition_column_mapping_rows: list[tuple[RelationalScalar, ...]] = []
    transition_repeated_header_rows: list[tuple[RelationalScalar, ...]] = []
    transition_split_row_rows: list[tuple[RelationalScalar, ...]] = []
    transition_fingerprint_rows: list[tuple[RelationalScalar, ...]] = []
    for item in document.transitions:
        transition_rows.append(
            (
                document_id,
                item.transition_id,
                item.source_transition_id,
                item.left_table_id,
                item.right_table_id,
                item.outcome,
                item.repeated_header,
                item.split_row,
                _json_cell(item.repeated_header_evidence_ids),
                _json_cell(item.split_row_evidence_ids),
                item.table_geometry_compatible,
                item.topology_compatible,
                item.page_boundary_evidence_strength,
                item.fingerprint_support_strength,
                item.candidate_pair_count,
                item.algorithm_version,
                item.source_fingerprint_id,
                item.semantic_fingerprint_identity,
                item.fingerprint_state,
                _json_cell(item.fingerprint_limitation_codes),
                _state(item.availability),
                _reason_codes(item.availability),
                _json_cell(item.limitation_codes),
            )
        )
        for mapping_index, mapping in enumerate(item.column_mappings):
            transition_column_mapping_rows.append(
                (
                    document_id,
                    item.transition_id,
                    mapping_index,
                    mapping.left_column_id,
                    mapping.right_column_id,
                    mapping.source_left_column_id,
                    mapping.source_right_column_id,
                    mapping.left_column_index,
                    mapping.right_column_index,
                    mapping.normalized_axis_distance,
                    mapping.width_ratio_difference,
                    mapping.topology_compatible,
                    mapping.evidence_strength,
                    _json_cell(mapping.conflicting_evidence),
                    mapping.reason_code,
                )
            )
        for evidence_index, repeated_evidence in enumerate(
            item.repeated_header_evidence
        ):
            transition_repeated_header_rows.append(
                (
                    document_id,
                    item.transition_id,
                    evidence_index,
                    repeated_evidence.logical_header_identity,
                    _json_cell(repeated_evidence.left_row_ids),
                    _json_cell(repeated_evidence.right_row_ids),
                    _json_cell(repeated_evidence.left_cell_ids),
                    _json_cell(repeated_evidence.right_cell_ids),
                    _json_cell(repeated_evidence.source_left_row_ids),
                    _json_cell(repeated_evidence.source_right_row_ids),
                    _json_cell(repeated_evidence.source_left_cell_ids),
                    _json_cell(repeated_evidence.source_right_cell_ids),
                    repeated_evidence.occurrence_index,
                    repeated_evidence.exact_symbolic_repeat,
                    repeated_evidence.topology_compatible,
                )
            )
        for evidence_index, split_evidence in enumerate(item.split_row_evidence):
            transition_split_row_rows.append(
                (
                    document_id,
                    item.transition_id,
                    evidence_index,
                    split_evidence.source_fragment_link_id,
                    split_evidence.left_row_id,
                    split_evidence.right_row_id,
                    _json_cell(split_evidence.left_cell_ids),
                    _json_cell(split_evidence.right_cell_ids),
                    split_evidence.source_left_row_id,
                    split_evidence.source_right_row_id,
                    _json_cell(split_evidence.source_left_cell_ids),
                    _json_cell(split_evidence.source_right_cell_ids),
                    _json_cell(split_evidence.mapped_column_indexes),
                    _json_cell(split_evidence.local_fragment_order),
                    split_evidence.physically_incomplete_left,
                    split_evidence.physically_compatible_right,
                    _json_cell(split_evidence.conflicting_evidence),
                )
            )
        fingerprint = item.fingerprint
        if fingerprint is not None:
            transition_fingerprint_rows.append(
                (
                    document_id,
                    item.transition_id,
                    fingerprint.source_fingerprint_id,
                    fingerprint.semantic_fingerprint_identity,
                    fingerprint.feature_schema_version,
                    fingerprint.state,
                    fingerprint.source_sha256,
                    fingerprint.source_document_identity,
                    fingerprint.page_table_manifest_sha256,
                    fingerprint.source_transition_id,
                    fingerprint.left_page_index,
                    fingerprint.right_page_index,
                    fingerprint.left_page_id,
                    fingerprint.right_page_id,
                    fingerprint.left_source_table_id,
                    fingerprint.right_source_table_id,
                    fingerprint.left_table_sidecar_id,
                    fingerprint.right_table_sidecar_id,
                    fingerprint.left_table_sidecar_sha256,
                    fingerprint.right_table_sidecar_sha256,
                    fingerprint.left_configuration_identity,
                    fingerprint.right_configuration_identity,
                    fingerprint.left_dependency_identity,
                    fingerprint.right_dependency_identity,
                    _json_cell(fingerprint.page_pair_geometry.model_dump(mode="json")),
                    _json_cell(fingerprint.column_continuity.model_dump(mode="json")),
                    _json_cell(fingerprint.header_continuity.model_dump(mode="json")),
                    _json_cell(fingerprint.row_cell_continuity.model_dump(mode="json")),
                    _json_cell(fingerprint.pair_context.model_dump(mode="json")),
                    _json_cell(fingerprint.safety_state.model_dump(mode="json")),
                    _json_cell(fingerprint.limitation_codes),
                )
            )
    warning_rows = [
        (
            document_id,
            item.warning_id,
            item.page_id,
            item.source_page_number,
            item.code,
            item.severity,
            item.message,
            item.recoverable,
            item.source_fact_id,
            item.source_parser_name,
            item.source_scope,
            item.occurrence_index,
        )
        for item in document.warnings
    ]
    warning_suppression_rows = [
        (
            document_id,
            item.source_scope,
            item.suppressed_warning_count,
            _json_cell(item.suppressed_warning_count_by_code),
            _json_cell(item.suppressed_warning_count_by_scope),
            item.suppressed_affected_page_count,
            item.suppressed_affected_fact_count,
        )
        for item in document.warning_suppressions
    ]
    final_tables = (
        _table(
            "transitions",
            (
                "canonical_document_id",
                "transition_id",
                "source_transition_id",
                "left_table_id",
                "right_table_id",
                "outcome",
                "repeated_header",
                "split_row",
                "repeated_header_evidence_ids_json",
                "split_row_evidence_ids_json",
                "table_geometry_compatible",
                "topology_compatible",
                "page_boundary_evidence_strength",
                "fingerprint_support_strength",
                "candidate_pair_count",
                "algorithm_version",
                "source_fingerprint_id",
                "semantic_fingerprint_identity",
                "fingerprint_state",
                "fingerprint_limitation_codes_json",
                "availability",
                "availability_reason_codes_json",
                "limitations_json",
            ),
            transition_rows,
        ),
        _table(
            "transition_column_mappings",
            (
                "canonical_document_id",
                "transition_id",
                "mapping_index",
                "left_column_id",
                "right_column_id",
                "source_left_column_id",
                "source_right_column_id",
                "left_column_index",
                "right_column_index",
                "normalized_axis_distance",
                "width_ratio_difference",
                "topology_compatible",
                "evidence_strength",
                "conflicting_evidence_json",
                "reason_code",
            ),
            transition_column_mapping_rows,
        ),
        _table(
            "transition_repeated_headers",
            (
                "canonical_document_id",
                "transition_id",
                "evidence_index",
                "logical_header_identity",
                "left_row_ids_json",
                "right_row_ids_json",
                "left_cell_ids_json",
                "right_cell_ids_json",
                "source_left_row_ids_json",
                "source_right_row_ids_json",
                "source_left_cell_ids_json",
                "source_right_cell_ids_json",
                "occurrence_index",
                "exact_symbolic_repeat",
                "topology_compatible",
            ),
            transition_repeated_header_rows,
        ),
        _table(
            "transition_split_rows",
            (
                "canonical_document_id",
                "transition_id",
                "evidence_index",
                "source_fragment_link_id",
                "left_row_id",
                "right_row_id",
                "left_cell_ids_json",
                "right_cell_ids_json",
                "source_left_row_id",
                "source_right_row_id",
                "source_left_cell_ids_json",
                "source_right_cell_ids_json",
                "mapped_column_indexes_json",
                "local_fragment_order_json",
                "physically_incomplete_left",
                "physically_compatible_right",
                "conflicting_evidence_json",
            ),
            transition_split_row_rows,
        ),
        _table(
            "transition_fingerprints",
            (
                "canonical_document_id",
                "transition_id",
                "source_fingerprint_id",
                "semantic_fingerprint_identity",
                "feature_schema_version",
                "state",
                "source_sha256",
                "source_document_identity",
                "page_table_manifest_sha256",
                "source_transition_id",
                "left_page_index",
                "right_page_index",
                "left_page_id",
                "right_page_id",
                "left_source_table_id",
                "right_source_table_id",
                "left_table_sidecar_id",
                "right_table_sidecar_id",
                "left_table_sidecar_sha256",
                "right_table_sidecar_sha256",
                "left_configuration_identity",
                "right_configuration_identity",
                "left_dependency_identity",
                "right_dependency_identity",
                "page_pair_geometry_json",
                "column_continuity_json",
                "header_continuity_json",
                "row_cell_continuity_json",
                "pair_context_json",
                "safety_state_json",
                "limitation_codes_json",
            ),
            transition_fingerprint_rows,
        ),
        _table(
            "warnings",
            (
                "canonical_document_id",
                "warning_id",
                "page_id",
                "source_page_number",
                "code",
                "severity",
                "message",
                "recoverable",
                "source_fact_id",
                "source_parser_name",
                "source_scope",
                "occurrence_index",
            ),
            warning_rows,
        ),
        _table(
            "warning_suppressions",
            (
                "canonical_document_id",
                "source_scope",
                "suppressed_warning_count",
                "suppressed_warning_count_by_code_json",
                "suppressed_warning_count_by_scope_json",
                "suppressed_affected_page_count",
                "suppressed_affected_fact_count",
            ),
            warning_suppression_rows,
        ),
        _table(
            "limitations",
            ("canonical_document_id", "scope", "entity_id", "code"),
            [
                (document_id, "document", document_id, code)
                for code in document.limitations
            ],
        ),
    )
    tables.extend(item for item in final_tables if include_empty or item.rows)
    return tuple(tables)

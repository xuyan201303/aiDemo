# ruff: noqa: EM101, EM102, I001, TRY003, UP042

"""CTIF-0 immutable, parser-free evidence contracts."""

from __future__ import annotations
from enum import Enum
from hashlib import sha256
import json
from typing import Literal, Self
from pydantic import BaseModel, ConfigDict, Field, model_validator

CANONICAL_IDENTITY_CONTRACT_VERSION = "canonical_text_identity.v1"


class CanonicalAuthorityMode(str, Enum):
    OFF = "off"
    VALIDATION_ONLY = "validation_only"
    ON_DEMAND = "on_demand"
    PRODUCT_STRICT = "product_strict"


class MappingShape(str, Enum):
    ONE_TO_ONE = "one_to_one"
    ONE_TO_MANY = "one_to_many"
    MANY_TO_ONE = "many_to_one"
    SUBSPAN = "subspan"
    UNMAPPED = "unmapped"
    AMBIGUOUS = "ambiguous"
    LOSSY = "lossy"
    RESOURCE_EXCEEDED = "resource_exceeded"
    UNSUPPORTED = "unsupported"


class _Frozen(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


def _digest_payload(payload: object) -> str:
    encoded = json.dumps(
        payload, ensure_ascii=True, separators=(",", ":"), sort_keys=True
    )
    return sha256(encoded.encode("utf-8")).hexdigest()


class CanonicalTextAuthorityIdentity(_Frozen):
    contract_version: Literal["canonical_text_identity.v1"] = (
        CANONICAL_IDENTITY_CONTRACT_VERSION  # type: ignore[assignment]
    )
    authority_version: str = Field(pattern=r"^[a-z0-9][a-z0-9._-]{0,63}$")
    source_artifact_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    document_identity: str = Field(min_length=1, max_length=256)
    original_page_number: int = Field(gt=0)
    page_identity: str = Field(min_length=1, max_length=256)
    source_snapshot_identity: str = Field(min_length=1, max_length=256)
    generation_mode: CanonicalAuthorityMode = CanonicalAuthorityMode.OFF
    generator_identity: str = Field(min_length=1, max_length=256)
    extraction_configuration_identity: str = Field(min_length=1, max_length=256)
    resource_policy_identity: str = Field(min_length=1, max_length=256)
    normalization_policy_identity: str = Field(min_length=1, max_length=256)
    decoding_policy_identity: str = Field(min_length=1, max_length=256)
    created_from_source_identity: str = Field(min_length=1, max_length=256)


class CanonicalContentPath(_Frozen):
    content_stream_object_identity: str | None = Field(default=None, max_length=256)
    object_generation: int | None = Field(default=None, ge=0)
    content_stream_ordinal: int = Field(ge=0)
    form_xobject_path: tuple[str, ...] = ()
    recursion_depth: int = Field(default=0, ge=0)
    bt_block_ordinal: int | None = Field(default=None, ge=0)
    text_show_operation_ordinal: int | None = Field(default=None, ge=0)
    marked_content_path: tuple[str, ...] = ()
    mcid: int | None = Field(default=None, ge=0)
    resource_dictionary_path: tuple[str, ...] = ()
    font_resource_identity: str | None = Field(default=None, max_length=256)
    availability: Literal[
        "available",
        "unknown",
        "unavailable",
        "unsupported",
        "malformed",
        "resource_bound_exceeded",
    ] = "available"

    @model_validator(mode="after")
    def validate_path(self) -> Self:
        if (
            self.availability == "available"
            and self.text_show_operation_ordinal is None
        ):
            raise ValueError("available content path requires a text-show ordinal")
        if (
            self.object_generation is not None
            and self.content_stream_object_identity is None
        ):
            raise ValueError("object generation requires an object identity")
        return self


class CanonicalGlyphEvidence(_Frozen):
    content_path: CanonicalContentPath
    raw_operand_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    raw_glyph_code_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    decoded_text_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    font_identity: str | None = Field(default=None, max_length=256)
    encoding_identity: str | None = Field(default=None, max_length=256)
    cmap_identity: str | None = Field(default=None, max_length=256)
    text_matrix_digest: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    ctm_digest: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    rendering_mode: str | None = Field(default=None, max_length=64)
    visibility: Literal["visible", "hidden", "unknown"] = "unknown"
    rotation_degrees: float | None = Field(default=None, ge=0, lt=360)
    vertical_writing: bool | None = None
    reversible: bool = False
    lossy: bool = False
    unmapped: bool = False
    warning_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_loss(self) -> Self:
        if self.unmapped and self.reversible:
            raise ValueError("unmapped evidence cannot be reversible")
        if self.lossy and self.reversible:
            raise ValueError("lossy evidence cannot be reversible")
        return self


class CanonicalCharacterInterval(_Frozen):
    unit: Literal["unicode_scalar"] = "unicode_scalar"
    canonical_start: int = Field(ge=0)
    canonical_end_exclusive: int = Field(ge=0)
    canonical_length: int = Field(ge=0)
    canonical_text_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    native_segment_identities: tuple[str, ...] = ()
    mapping_completeness: Literal["complete", "partial", "unavailable"] = "unavailable"
    gap_count: int = Field(default=0, ge=0)
    lossy_segment_count: int = Field(default=0, ge=0)
    unmapped_segment_count: int = Field(default=0, ge=0)
    occurrence_ordinal: int | None = Field(default=None, ge=0)
    context_anchor_digest: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    competing_occurrence_count: int = Field(default=0, ge=0)

    @model_validator(mode="after")
    def validate_interval(self) -> Self:
        if self.canonical_end_exclusive < self.canonical_start:
            raise ValueError("canonical interval must be ordered")
        if self.canonical_end_exclusive - self.canonical_start != self.canonical_length:
            raise ValueError("canonical length mismatch")
        if self.canonical_length == 0 and self.mapping_completeness == "complete":
            raise ValueError("complete evidence cannot be empty")
        if self.mapping_completeness == "complete" and (
            self.gap_count or self.lossy_segment_count or self.unmapped_segment_count
        ):
            raise ValueError("complete mapping cannot contain gaps or loss")
        if (
            self.competing_occurrence_count > 1
            and self.mapping_completeness == "complete"
        ):
            raise ValueError("ambiguous occurrence cannot be complete")
        return self


class ParserLineageEvidence(_Frozen):
    parser_name: str = Field(min_length=1, max_length=64)
    parser_version: str = Field(min_length=1, max_length=128)
    parser_configuration_identity: str = Field(min_length=1, max_length=256)
    parser_page_identity: str = Field(min_length=1, max_length=256)
    parser_fact_id: str = Field(min_length=1, max_length=256)
    parser_fact_kind: str = Field(min_length=1, max_length=64)
    parser_native_interval: tuple[int, int] | None = None
    parent_span_or_object_identity: str | None = Field(default=None, max_length=256)
    source_order: int | None = Field(default=None, ge=0)
    text_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    geometry_digest: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    canonical_interval: CanonicalCharacterInterval | None = None
    mapping_shape: MappingShape
    provenance_method: str = Field(min_length=1, max_length=128)
    completeness: Literal["complete", "partial", "unavailable"] = "unavailable"
    ambiguity_count: int = Field(default=0, ge=0)
    rejection_reason: str | None = Field(default=None, max_length=256)

    @model_validator(mode="after")
    def validate_lineage(self) -> Self:
        if self.parser_native_interval is not None:
            start, end = self.parser_native_interval
            if start < 0 or end < start:
                raise ValueError("native interval must be ordered")
        if (
            self.mapping_shape is MappingShape.ONE_TO_ONE
            and self.canonical_interval is None
        ):
            raise ValueError("one-to-one lineage requires canonical interval")
        return self


class CrossParserMappingEvidence(_Frozen):
    source_lineage_identities: tuple[str, ...] = ()
    selected_lineage_identities: tuple[str, ...] = ()
    canonical_interval_identities: tuple[str, ...] = ()
    mapping_shape: MappingShape
    contiguous_coverage: bool = False
    gap_count: int = Field(default=0, ge=0)
    extra_character_count: int = Field(default=0, ge=0)
    candidate_count: int = Field(default=0, ge=0)
    qualified_candidate_count: int = Field(default=0, ge=0)
    ambiguity_count: int = Field(default=0, ge=0)
    proof_method: str = Field(min_length=1, max_length=128)
    proof_completeness: Literal["complete", "partial", "unavailable"] = "unavailable"
    geometry_consistent: bool | None = None
    failure_reason: str | None = Field(default=None, max_length=256)

    @property
    def proven(self) -> bool:
        return (
            self.mapping_shape
            in {
                MappingShape.ONE_TO_ONE,
                MappingShape.ONE_TO_MANY,
                MappingShape.MANY_TO_ONE,
                MappingShape.SUBSPAN,
            }
            and self.proof_completeness == "complete"
            and self.contiguous_coverage
            and self.gap_count == 0
            and self.extra_character_count == 0
            and self.qualified_candidate_count == 1
            and self.ambiguity_count == 0
            and bool(self.source_lineage_identities)
            and bool(self.selected_lineage_identities)
            and bool(self.canonical_interval_identities)
        )


class ResourcePolicy(_Frozen):
    experimental: bool = True
    max_content_streams_per_page: int = Field(default=64, ge=1)
    max_operations_per_page: int = Field(default=100_000, ge=1)
    max_text_show_operations_per_page: int = Field(default=25_000, ge=1)
    max_form_xobject_recursion_depth: int = Field(default=16, ge=0)
    max_glyphs_per_page: int = Field(default=1_000_000, ge=1)
    max_canonical_characters_per_page: int = Field(default=1_000_000, ge=1)
    max_mapping_segments_per_page: int = Field(default=250_000, ge=1)
    max_parser_lineage_items_per_page: int = Field(default=250_000, ge=1)
    max_alignment_candidates_per_fact: int = Field(default=1_024, ge=1)
    max_competing_occurrences: int = Field(default=256, ge=1)
    max_context_characters: int = Field(default=512, ge=1)
    max_serialized_bundle_bytes: int = Field(default=64 * 1024 * 1024, ge=1)
    max_page_elapsed_ms: int = Field(default=10_000, ge=1)
    max_page_peak_rss_bytes: int = Field(default=2_000_000_000, ge=1)


class CanonicalEvidenceBundle(_Frozen):
    authority_identity: CanonicalTextAuthorityIdentity
    content_paths: tuple[CanonicalContentPath, ...] = ()
    glyph_evidence: tuple[CanonicalGlyphEvidence, ...] = ()
    canonical_stream_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    mapping_segments: tuple[CrossParserMappingEvidence, ...] = ()
    parser_lineage: tuple[ParserLineageEvidence, ...] = ()
    limitation_codes: tuple[str, ...] = ()
    resource_policy: ResourcePolicy
    generation_completeness: Literal["complete", "partial", "unavailable"] = (
        "unavailable"
    )
    bundle_digest: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_bundle(self) -> Self:
        if self.generation_completeness == "complete" and self.limitation_codes:
            raise ValueError("complete bundle cannot carry limitations")
        if (
            self.authority_identity.generation_mode is CanonicalAuthorityMode.OFF
            and self.generation_completeness != "unavailable"
        ):
            raise ValueError("OFF mode cannot contain generated evidence")
        return self


def canonical_identity_digest(identity: CanonicalTextAuthorityIdentity) -> str:
    return _digest_payload(identity.model_dump(mode="json"))


def validate_compatibility(
    *, expected: CanonicalTextAuthorityIdentity, actual: CanonicalTextAuthorityIdentity
) -> None:
    fields = (
        "contract_version",
        "authority_version",
        "source_artifact_sha256",
        "document_identity",
        "original_page_number",
        "page_identity",
        "source_snapshot_identity",
        "generator_identity",
        "extraction_configuration_identity",
        "resource_policy_identity",
        "normalization_policy_identity",
        "decoding_policy_identity",
        "created_from_source_identity",
    )
    for field in fields:
        if getattr(expected, field) != getattr(actual, field):
            raise ValueError(f"canonical evidence identity mismatch: {field}")

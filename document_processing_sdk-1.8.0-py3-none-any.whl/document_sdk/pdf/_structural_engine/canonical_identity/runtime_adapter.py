# ruff: noqa: D202, E501, EM101, PLR0911, PLR0913, PLR2004, TC001, TC006, TRY003, UP047
"""Private fixed-operation JSON/NDJSON adapter for CTIF A2.

This module is an implementation draft.  It intentionally imports the current
private subprocess lifecycle primitive and never modifies or re-exports the
current Runtime protocol.  Historical source wrappers must import the
operation-specific ``run_*`` functions lazily inside their public-private
wrapper functions to avoid a module cycle.
"""

from __future__ import annotations

import base64
import binascii
import signal
import sys
from dataclasses import dataclass
from enum import Enum
from hashlib import sha256
from typing import TYPE_CHECKING, Literal, TypeVar, cast

from pydantic import BaseModel, ConfigDict, Field, TypeAdapter, model_validator

from document_sdk.pdf._structural_engine.canonical_identity.contracts import (
    CanonicalEvidenceBundle,
    ResourcePolicy,
)
from document_sdk.pdf._structural_engine.canonical_identity.decoder_limits import (
    DecoderResourcePolicy,
)
from document_sdk.pdf._structural_engine.canonical_identity.evidence import (
    RawAuthorityResult,
)
from document_sdk.pdf._structural_engine.canonical_identity.serialization import (
    canonical_sha256,
)
from document_sdk.pdf._structural_engine.runtime.process import (
    _ProcessOutcome,
    _run_bounded_process,
)

if TYPE_CHECKING:
    from document_sdk.pdf._structural_engine.canonical_identity.decoder import (
        StrictDecoderResult,
    )
    from document_sdk.pdf._structural_engine.canonical_identity.decoder_contracts import (
        DecoderEvidenceInventory,
    )
    from document_sdk.pdf._structural_engine.canonical_identity.operation_provenance import (
        OperationProvenanceBundle,
        OperationProvenanceResult,
    )
    from document_sdk.pdf._structural_engine.canonical_identity.pdfium_lineage import (
        PdfiumLineageResult,
    )
    from document_sdk.pdf._structural_engine.canonical_identity.source_lineage import (
        SourceLineageResult,
    )


class _DependencyUnavailablePayload(BaseModel):
    """Closed placeholder used only when an optional PDF dependency is absent."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)


if not TYPE_CHECKING:
    try:
        from document_sdk.pdf._structural_engine.canonical_identity.decoder import (
            StrictDecoderResult,
        )
    except Exception:  # noqa: BLE001

        class StrictDecoderResult(_DependencyUnavailablePayload):
            pass

    try:
        from document_sdk.pdf._structural_engine.canonical_identity.operation_provenance import (
            OperationProvenanceResult,
        )
    except Exception:  # noqa: BLE001

        class OperationProvenanceResult(_DependencyUnavailablePayload):
            pass

    try:
        from document_sdk.pdf._structural_engine.canonical_identity.pdfium_lineage import (
            PdfiumLineageResult,
        )
    except Exception:  # noqa: BLE001

        class PdfiumLineageResult(_DependencyUnavailablePayload):
            pass

    try:
        from document_sdk.pdf._structural_engine.canonical_identity.source_lineage import (
            SourceLineageResult,
        )
    except Exception:  # noqa: BLE001

        class SourceLineageResult(_DependencyUnavailablePayload):
            pass


CTIF_FIXED_OPERATION_PROTOCOL_VERSION: Literal[
    "document_sdk.pdf.ctif.fixed_operation.v1"
] = "document_sdk.pdf.ctif.fixed_operation.v1"

CtifFixedOperation = Literal[
    "raw_authority",
    "strict_decoder",
    "operation_provenance",
    "pdfium_lineage",
    "source_lineage",
]
CtifRuntimeOutcome = Literal[
    "completed",
    "invalid_request",
    "timeout",
    "resource_exceeded",
    "dependency_unavailable",
    "worker_failed",
    "runtime_unavailable",
    "protocol_error",
]
CtifRuntimeLimitationCode = Literal[
    "ctif_runtime_invalid_request",
    "ctif_runtime_timeout",
    "ctif_runtime_resource_exceeded",
    "ctif_runtime_dependency_unavailable",
    "ctif_runtime_worker_failed",
    "ctif_runtime_unavailable",
    "ctif_runtime_protocol_error",
]

CTIF_FIXED_OPERATIONS: tuple[CtifFixedOperation, ...] = (
    "raw_authority",
    "strict_decoder",
    "operation_provenance",
    "pdfium_lineage",
    "source_lineage",
)

_WORKER_MODULE = "document_sdk.pdf._structural_engine.canonical_identity.worker"
_MAX_SOURCE_BYTES = 128 * 1024 * 1024
_MAX_REQUEST_BYTES = 256 * 1024 * 1024
_MAX_RESPONSE_BYTES = 128 * 1024 * 1024
_MAX_STDERR_BYTES = 16 * 1024
_MAX_RUNTIME_SECONDS = 300.0
_TERMINATE_GRACE_SECONDS = 0.25
_MAX_SAFE_INTEGER = 2**63 - 1
_HASH_PATTERN = r"^[0-9a-f]{64}$"
_IDENTITY_MAX_LENGTH = 512
_NONDETERMINISTIC_METRIC_FIELDS = frozenset({"elapsed_ms", "peak_rss_bytes"})
_RAW_AUTHORITY_VERSION = "ctif_raw_pdf_authority.v1"
_RAW_DECODING_POLICY = "ctif_raw_decoding.experimental.v1"
_RAW_NORMALIZATION_POLICY = "ctif_raw_operation_order.v1"
_RAW_RESOURCE_POLICY = "ctif1_sentinel_resource_policy.experimental.v1"
_OPERATION_PROVENANCE_VERSION = "ctif_operation_provenance.v1m"
_OPERATION_PROVENANCE_POLICY = "ctif_operation_execution.experimental.v1"
_TEXT_LINEAGE_OPERATION_PROVENANCE_POLICY = (
    "ctif_operation_execution.text_lineage_only.v1"
)
_PDFIUM_LINEAGE_VERSION = "ctif_pdfium_lineage.v1"
_PDFIUM_LINEAGE_POLICY = "ctif_pdfium_lineage.experimental.v1"
_SOURCE_LINEAGE_VERSION = "ctif_source_lineage.v1"
_SOURCE_LINEAGE_POLICY = "ctif_source_lineage.experimental.v1"
_TEXT_SHOW_OPERATORS = frozenset({"Tj", "TJ", "'", '"'})

_OUTCOME_LIMITATION: dict[CtifRuntimeOutcome, CtifRuntimeLimitationCode | None] = {
    "completed": None,
    "invalid_request": "ctif_runtime_invalid_request",
    "timeout": "ctif_runtime_timeout",
    "resource_exceeded": "ctif_runtime_resource_exceeded",
    "dependency_unavailable": "ctif_runtime_dependency_unavailable",
    "worker_failed": "ctif_runtime_worker_failed",
    "runtime_unavailable": "ctif_runtime_unavailable",
    "protocol_error": "ctif_runtime_protocol_error",
}


class CtifRuntimeRequestError(ValueError):
    """Fixed, content-free private request rejection."""


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)


class _CtifRequestBase(_FrozenModel):
    protocol_version: Literal["document_sdk.pdf.ctif.fixed_operation.v1"] = (
        CTIF_FIXED_OPERATION_PROTOCOL_VERSION
    )
    source_bytes_base64: str = Field(max_length=(_MAX_SOURCE_BYTES * 4 // 3) + 8)
    source_sha256: str = Field(pattern=_HASH_PATTERN)
    source_size_bytes: int = Field(ge=0, le=_MAX_SOURCE_BYTES)
    expected_source_sha256: str = Field(pattern=_HASH_PATTERN)
    options_policy_digest: str = Field(pattern=_HASH_PATTERN)
    request_digest: str = Field(pattern=_HASH_PATTERN)

    @model_validator(mode="after")
    def validate_opaque_identities(self) -> _CtifRequestBase:
        """Reject path-like caller identities without rejecting PDF resource names."""

        def unsafe(value: str) -> bool:
            return (
                "/" in value
                or "\\" in value
                or "://" in value
                or value.lower().startswith("file:")
                or any(
                    ord(character) < 32 or ord(character) == 127 for character in value
                )
            )

        values: list[str] = []
        if isinstance(self, CtifRawAuthorityRequest):
            values.extend(
                (
                    self.document_identity,
                    self.page_identity,
                    self.source_snapshot_identity,
                    self.extraction_configuration_identity,
                )
            )
        elif isinstance(
            self, (CtifStrictDecoderRequest, CtifOperationProvenanceRequest)
        ):
            raw_bundle = self.raw_authority_result.bundle
            if raw_bundle is not None:
                raw_identity = raw_bundle.authority_identity
                values.extend(
                    (
                        raw_identity.document_identity,
                        raw_identity.page_identity,
                        raw_identity.source_snapshot_identity,
                        raw_identity.extraction_configuration_identity,
                    )
                )
        elif isinstance(self, CtifPdfiumLineageRequest):
            values.extend(
                (
                    self.document_identity,
                    self.page_identity,
                    self.parser_configuration_identity,
                )
            )
        elif isinstance(self, CtifSourceLineageRequest):
            values.append(self.parser_configuration_identity)
            provenance_bundle = self.operation_provenance_result.bundle
            if provenance_bundle is not None:
                values.extend(
                    (
                        provenance_bundle.document_identity,
                        provenance_bundle.page_identity,
                    )
                )
        if any(unsafe(value) for value in values):
            raise ValueError("identity fields must be opaque and path-free")
        return self


class CtifRawAuthorityRequest(_CtifRequestBase):
    operation: Literal["raw_authority"] = "raw_authority"
    original_page_number: int = Field(ge=1, le=2**31 - 1)
    document_identity: str = Field(min_length=1, max_length=_IDENTITY_MAX_LENGTH)
    page_identity: str = Field(min_length=1, max_length=_IDENTITY_MAX_LENGTH)
    source_snapshot_identity: str = Field(min_length=1, max_length=_IDENTITY_MAX_LENGTH)
    extraction_configuration_identity: str = Field(
        min_length=1, max_length=_IDENTITY_MAX_LENGTH
    )
    resource_policy: ResourcePolicy


class CtifStrictDecoderRequest(_CtifRequestBase):
    operation: Literal["strict_decoder"] = "strict_decoder"
    original_page_number: int = Field(ge=1, le=2**31 - 1)
    raw_authority_result: RawAuthorityResult
    decoder_policy: DecoderResourcePolicy


class CtifOperationProvenanceRequest(_CtifRequestBase):
    operation: Literal["operation_provenance"] = "operation_provenance"
    original_page_number: int = Field(ge=1, le=2**31 - 1)
    raw_authority_result: RawAuthorityResult
    decoder_result: StrictDecoderResult
    decoder_policy: DecoderResourcePolicy
    text_lineage_only: bool = False


class CtifPdfiumLineageRequest(_CtifRequestBase):
    operation: Literal["pdfium_lineage"] = "pdfium_lineage"
    document_identity: str = Field(min_length=1, max_length=_IDENTITY_MAX_LENGTH)
    original_page_number: int = Field(ge=1, le=2**31 - 1)
    page_identity: str = Field(min_length=1, max_length=_IDENTITY_MAX_LENGTH)
    parser_configuration_identity: str = Field(
        default="pdfium-native-lineage.default.v1",
        min_length=1,
        max_length=_IDENTITY_MAX_LENGTH,
    )
    max_text_objects: int = Field(default=20_000, ge=1, le=20_000)
    max_characters: int = Field(default=200_000, ge=1, le=200_000)


class CtifSourceLineageRequest(_CtifRequestBase):
    operation: Literal["source_lineage"] = "source_lineage"
    original_page_number: int = Field(ge=1, le=2**31 - 1)
    operation_provenance_result: OperationProvenanceResult
    decoder_result: StrictDecoderResult
    parser_configuration_identity: str = Field(
        default="pdfminer.layout.default.v1",
        min_length=1,
        max_length=_IDENTITY_MAX_LENGTH,
    )


CtifRequest = (
    CtifRawAuthorityRequest
    | CtifStrictDecoderRequest
    | CtifOperationProvenanceRequest
    | CtifPdfiumLineageRequest
    | CtifSourceLineageRequest
)


class CtifRuntimeMetrics(_FrozenModel):
    elapsed_milliseconds: float = Field(ge=0, le=3_600_000)
    parent_observed_peak_rss_bytes: int | None = Field(
        default=None, ge=0, le=_MAX_SAFE_INTEGER
    )
    parent_rss_measurement: Literal[
        "unavailable", "time_aligned_process_tree_ps_rss_snapshot"
    ] = "unavailable"
    rss_sample_count: int = Field(default=0, ge=0, le=10_000_000)
    exit_code: int | None = Field(default=None, ge=-(2**31), le=2**31 - 1)
    timed_out: bool = False
    killed: bool = False
    captured_stdout_bytes: int = Field(default=0, ge=0, le=_MAX_SAFE_INTEGER)
    stdout_truncated: bool = False
    captured_stderr_bytes: int = Field(default=0, ge=0, le=_MAX_SAFE_INTEGER)
    stderr_truncated: bool = False


class _CtifResponseBase(_FrozenModel):
    protocol_version: Literal["document_sdk.pdf.ctif.fixed_operation.v1"] = (
        CTIF_FIXED_OPERATION_PROTOCOL_VERSION
    )
    source_sha256: str = Field(pattern=_HASH_PATTERN)
    source_size_bytes: int = Field(ge=0, le=_MAX_SOURCE_BYTES)
    options_policy_digest: str = Field(pattern=_HASH_PATTERN)
    request_digest: str = Field(pattern=_HASH_PATTERN)
    outcome: CtifRuntimeOutcome
    limitation_code: CtifRuntimeLimitationCode | None
    metrics: CtifRuntimeMetrics
    result_digest: str = Field(pattern=_HASH_PATTERN)

    @property
    def value(self) -> object | None:
        """Read-only compatibility alias used by the historical wrappers."""

        return self.__dict__.get("payload")

    @property
    def elapsed_milliseconds(self) -> float:
        """Read-only compatibility alias for the bounded parent metric."""

        return self.metrics.elapsed_milliseconds

    @model_validator(mode="after")
    def validate_outcome_contract(self) -> _CtifResponseBase:
        expected = _OUTCOME_LIMITATION[self.outcome]
        payload = self.__dict__.get("payload")
        if self.limitation_code != expected:
            raise ValueError("runtime outcome and limitation code are inconsistent")
        if self.outcome == "completed" and payload is None:
            raise ValueError("completed runtime response requires a payload")
        if self.outcome != "completed" and payload is not None:
            raise ValueError("failed runtime response cannot contain a payload")
        return self


class CtifRawAuthorityResponse(_CtifResponseBase):
    operation: Literal["raw_authority"] = "raw_authority"
    payload: RawAuthorityResult | None


class CtifStrictDecoderResponse(_CtifResponseBase):
    operation: Literal["strict_decoder"] = "strict_decoder"
    payload: StrictDecoderResult | None


class CtifOperationProvenanceResponse(_CtifResponseBase):
    operation: Literal["operation_provenance"] = "operation_provenance"
    payload: OperationProvenanceResult | None


class CtifPdfiumLineageResponse(_CtifResponseBase):
    operation: Literal["pdfium_lineage"] = "pdfium_lineage"
    payload: PdfiumLineageResult | None


class CtifSourceLineageResponse(_CtifResponseBase):
    operation: Literal["source_lineage"] = "source_lineage"
    payload: SourceLineageResult | None


CtifResponse = (
    CtifRawAuthorityResponse
    | CtifStrictDecoderResponse
    | CtifOperationProvenanceResponse
    | CtifPdfiumLineageResponse
    | CtifSourceLineageResponse
)
RequestT = TypeVar(
    "RequestT",
    CtifRawAuthorityRequest,
    CtifStrictDecoderRequest,
    CtifOperationProvenanceRequest,
    CtifPdfiumLineageRequest,
    CtifSourceLineageRequest,
)

_STRICT_DECODER_RESULT_ADAPTER = TypeAdapter(StrictDecoderResult)

_OPERATION_ARGUMENT_FIELDS: dict[CtifFixedOperation, tuple[str, ...]] = {
    "raw_authority": (
        "expected_source_sha256",
        "original_page_number",
        "document_identity",
        "page_identity",
        "source_snapshot_identity",
        "extraction_configuration_identity",
        "resource_policy",
    ),
    "strict_decoder": (
        "expected_source_sha256",
        "original_page_number",
        "raw_authority_result",
        "decoder_policy",
    ),
    "operation_provenance": (
        "expected_source_sha256",
        "original_page_number",
        "raw_authority_result",
        "decoder_result",
        "decoder_policy",
        "text_lineage_only",
    ),
    "pdfium_lineage": (
        "expected_source_sha256",
        "document_identity",
        "original_page_number",
        "page_identity",
        "parser_configuration_identity",
        "max_text_objects",
        "max_characters",
    ),
    "source_lineage": (
        "expected_source_sha256",
        "original_page_number",
        "operation_provenance_result",
        "decoder_result",
        "parser_configuration_identity",
    ),
}


@dataclass(frozen=True)
class _ProcessConfiguration:
    hard_timeout_seconds: float
    max_stdout_bytes: int


def _deterministic_projection(value: object) -> object:
    if type(value) is dict:
        mapping = cast(dict[str, object], value)
        result: dict[str, object] = {}
        for key, item in mapping.items():
            if key == "metrics" and type(item) is dict:
                metrics = cast(dict[str, object], item)
                result[key] = {
                    metric_key: _deterministic_projection(metric_value)
                    for metric_key, metric_value in metrics.items()
                    if metric_key not in _NONDETERMINISTIC_METRIC_FIELDS
                }
            else:
                result[key] = _deterministic_projection(item)
        return result
    if type(value) is list:
        return [_deterministic_projection(item) for item in cast(list[object], value)]
    if type(value) is tuple:
        return tuple(
            _deterministic_projection(item) for item in cast(tuple[object, ...], value)
        )
    return value


def _operation_options_projection(request: CtifRequest) -> dict[str, object]:
    dumped = request.model_dump(mode="json")
    return cast(
        dict[str, object],
        _deterministic_projection(
            {
                name: dumped[name]
                for name in _OPERATION_ARGUMENT_FIELDS[request.operation]
            }
        ),
    )


def _expected_options_policy_digest(request: CtifRequest) -> str:
    return canonical_sha256(_operation_options_projection(request))


def _request_digest(
    *,
    operation: CtifFixedOperation,
    source_sha256: str,
    source_size_bytes: int,
    options_policy_digest: str,
) -> str:
    return canonical_sha256(
        {
            "protocol_version": CTIF_FIXED_OPERATION_PROTOCOL_VERSION,
            "operation": operation,
            "source_sha256": source_sha256,
            "source_size_bytes": source_size_bytes,
            "options_policy_digest": options_policy_digest,
        }
    )


def _source_base_fields(
    source_bytes: bytes,
    *,
    expected_source_sha256: str,
) -> dict[str, object]:
    if type(source_bytes) is not bytes:
        raise CtifRuntimeRequestError("CTIF runtime accepts immutable bytes only")
    if len(source_bytes) > _MAX_SOURCE_BYTES:
        raise CtifRuntimeRequestError("CTIF runtime source bound exceeded")
    actual_source_sha256 = sha256(source_bytes).hexdigest()
    return {
        "protocol_version": CTIF_FIXED_OPERATION_PROTOCOL_VERSION,
        "source_bytes_base64": base64.b64encode(source_bytes).decode("ascii"),
        "source_sha256": actual_source_sha256,
        "source_size_bytes": len(source_bytes),
        "expected_source_sha256": expected_source_sha256,
    }


def _finalize_request(
    request_type: type[RequestT], values: dict[str, object]
) -> RequestT:
    try:
        provisional = request_type.model_validate(
            {
                **values,
                "options_policy_digest": "0" * 64,
                "request_digest": "0" * 64,
            }
        )
        options_policy_digest = _expected_options_policy_digest(provisional)
        request_digest = _request_digest(
            operation=provisional.operation,
            source_sha256=provisional.source_sha256,
            source_size_bytes=provisional.source_size_bytes,
            options_policy_digest=options_policy_digest,
        )
        return request_type.model_validate(
            {
                **values,
                "options_policy_digest": options_policy_digest,
                "request_digest": request_digest,
            }
        )
    except Exception:  # noqa: BLE001
        raise CtifRuntimeRequestError("Invalid CTIF runtime request") from None


def _decode_and_validate_source(request: CtifRequest) -> bytes:
    try:
        source_bytes = base64.b64decode(request.source_bytes_base64, validate=True)
    except (binascii.Error, ValueError):
        raise CtifRuntimeRequestError("Invalid CTIF runtime request") from None
    if base64.b64encode(source_bytes).decode("ascii") != request.source_bytes_base64:
        raise CtifRuntimeRequestError("Invalid CTIF runtime request")
    if type(source_bytes) is not bytes:
        raise CtifRuntimeRequestError("Invalid CTIF runtime request")
    if len(source_bytes) != request.source_size_bytes:
        raise CtifRuntimeRequestError("Invalid CTIF runtime request")
    if sha256(source_bytes).hexdigest() != request.source_sha256:
        raise CtifRuntimeRequestError("Invalid CTIF runtime request")
    if _expected_options_policy_digest(request) != request.options_policy_digest:
        raise CtifRuntimeRequestError("Invalid CTIF runtime request")
    expected_request_digest = _request_digest(
        operation=request.operation,
        source_sha256=request.source_sha256,
        source_size_bytes=request.source_size_bytes,
        options_policy_digest=request.options_policy_digest,
    )
    if expected_request_digest != request.request_digest:
        raise CtifRuntimeRequestError("Invalid CTIF runtime request")
    if not _request_inputs_are_bound(request):
        raise CtifRuntimeRequestError("Invalid CTIF runtime request")
    return source_bytes


def _payload_projection(payload: object) -> object:
    if type(payload) is StrictDecoderResult:
        dumped = _STRICT_DECODER_RESULT_ADAPTER.dump_python(payload, mode="json")
    elif isinstance(payload, BaseModel):
        dumped = payload.model_dump(mode="json")
    else:
        raise TypeError("Unsupported CTIF runtime payload")
    return _deterministic_projection(dumped)


def _result_digest(
    *,
    request: CtifRequest,
    outcome: CtifRuntimeOutcome,
    limitation_code: CtifRuntimeLimitationCode | None,
    payload: object | None,
) -> str:
    return canonical_sha256(
        {
            "protocol_version": CTIF_FIXED_OPERATION_PROTOCOL_VERSION,
            "operation": request.operation,
            "source_sha256": request.source_sha256,
            "source_size_bytes": request.source_size_bytes,
            "options_policy_digest": request.options_policy_digest,
            "request_digest": request.request_digest,
            "outcome": outcome,
            "limitation_code": limitation_code,
            "payload": None if payload is None else _payload_projection(payload),
        }
    )


def _neutral_metrics() -> CtifRuntimeMetrics:
    return CtifRuntimeMetrics(elapsed_milliseconds=0)


def _response_type_for_request(
    request: CtifRequest,
) -> type[
    CtifRawAuthorityResponse
    | CtifStrictDecoderResponse
    | CtifOperationProvenanceResponse
    | CtifPdfiumLineageResponse
    | CtifSourceLineageResponse
]:
    if type(request) is CtifRawAuthorityRequest:
        return CtifRawAuthorityResponse
    if type(request) is CtifStrictDecoderRequest:
        return CtifStrictDecoderResponse
    if type(request) is CtifOperationProvenanceRequest:
        return CtifOperationProvenanceResponse
    if type(request) is CtifPdfiumLineageRequest:
        return CtifPdfiumLineageResponse
    if type(request) is CtifSourceLineageRequest:
        return CtifSourceLineageResponse
    raise TypeError("Unsupported CTIF runtime request")


def _build_response(
    request: CtifRequest,
    *,
    outcome: CtifRuntimeOutcome,
    payload: object | None,
    metrics: CtifRuntimeMetrics,
) -> CtifResponse:
    limitation_code = _OUTCOME_LIMITATION[outcome]
    response_type = _response_type_for_request(request)
    return response_type.model_validate(
        {
            "protocol_version": CTIF_FIXED_OPERATION_PROTOCOL_VERSION,
            "operation": request.operation,
            "source_sha256": request.source_sha256,
            "source_size_bytes": request.source_size_bytes,
            "options_policy_digest": request.options_policy_digest,
            "request_digest": request.request_digest,
            "outcome": outcome,
            "limitation_code": limitation_code,
            "payload": payload,
            "metrics": metrics,
            "result_digest": _result_digest(
                request=request,
                outcome=outcome,
                limitation_code=limitation_code,
                payload=payload,
            ),
        }
    )


def _completed_response(request: CtifRequest, payload: object) -> CtifResponse:
    return _build_response(
        request,
        outcome="completed",
        payload=payload,
        metrics=_neutral_metrics(),
    )


def _failure_response(
    request: CtifRequest,
    outcome: CtifRuntimeOutcome,
    *,
    metrics: CtifRuntimeMetrics | None = None,
) -> CtifResponse:
    if outcome == "completed":
        raise ValueError("failure response requires a failed outcome")
    return _build_response(
        request,
        outcome=outcome,
        payload=None,
        metrics=metrics or _neutral_metrics(),
    )


def _process_configuration(request: CtifRequest) -> _ProcessConfiguration:
    if type(request) is CtifRawAuthorityRequest:
        seconds = request.resource_policy.max_page_elapsed_ms / 1_000
        response_bytes = max(
            request.resource_policy.max_serialized_bundle_bytes + 16 * 1024 * 1024,
            32 * 1024 * 1024,
        )
    elif type(request) is CtifStrictDecoderRequest:
        seconds = request.decoder_policy.max_decoder_elapsed_ms_per_page / 1_000
        response_bytes = max(
            request.decoder_policy.max_decoder_inventory_bytes * 2,
            32 * 1024 * 1024,
        )
    elif type(request) is CtifOperationProvenanceRequest:
        seconds = request.decoder_policy.max_decoder_elapsed_ms_per_page / 1_000
        response_bytes = max(
            request.decoder_policy.max_decoder_inventory_bytes * 4,
            64 * 1024 * 1024,
        )
    elif type(request) in (CtifPdfiumLineageRequest, CtifSourceLineageRequest):
        seconds = 30.0
        response_bytes = _MAX_RESPONSE_BYTES
    else:
        raise TypeError("Unsupported CTIF runtime request")
    return _ProcessConfiguration(
        hard_timeout_seconds=max(0.001, min(seconds, _MAX_RUNTIME_SECONDS)),
        max_stdout_bytes=min(response_bytes, _MAX_RESPONSE_BYTES) + 64 * 1024,
    )


def _request_memory_limit_bytes(request: CtifRequest) -> int:
    if type(request) is CtifRawAuthorityRequest:
        return min(request.resource_policy.max_page_peak_rss_bytes, 2_000_000_000)
    if type(request) is CtifStrictDecoderRequest:
        return min(request.decoder_policy.max_decoder_peak_rss_bytes, 2_000_000_000)
    if type(request) is CtifOperationProvenanceRequest:
        return min(request.decoder_policy.max_decoder_peak_rss_bytes, 2_000_000_000)
    if type(request) in (CtifPdfiumLineageRequest, CtifSourceLineageRequest):
        return 512 * 1024 * 1024
    raise TypeError("Unsupported CTIF runtime request")


def _worker_response_limit_bytes(request: CtifRequest) -> int:
    return _process_configuration(request).max_stdout_bytes - 64 * 1024


def _metrics_from_process(outcome: _ProcessOutcome) -> CtifRuntimeMetrics:
    elapsed = min(max(outcome.elapsed_milliseconds, 0.0), 3_600_000.0)
    peak = outcome.parent_observed_peak_rss_bytes
    if peak is not None:
        peak = min(max(peak, 0), _MAX_SAFE_INTEGER)
    measurement: Literal["unavailable", "time_aligned_process_tree_ps_rss_snapshot"] = (
        "time_aligned_process_tree_ps_rss_snapshot"
        if outcome.parent_rss_measurement == "time_aligned_process_tree_ps_rss_snapshot"
        else "unavailable"
    )
    return CtifRuntimeMetrics(
        elapsed_milliseconds=elapsed,
        parent_observed_peak_rss_bytes=peak,
        parent_rss_measurement=measurement,
        rss_sample_count=min(max(outcome.rss_sample_count, 0), 10_000_000),
        exit_code=outcome.exit_code,
        timed_out=outcome.timed_out,
        killed=outcome.killed,
        captured_stdout_bytes=len(outcome.stdout),
        stdout_truncated=outcome.stdout_truncated,
        captured_stderr_bytes=len(outcome.stderr),
        stderr_truncated=outcome.stderr_truncated,
    )


def _worker_metrics_are_neutral(metrics: CtifRuntimeMetrics) -> bool:
    return metrics == _neutral_metrics()


def _status_value(value: object) -> str:
    status = value.value if isinstance(value, Enum) else value
    return status if isinstance(status, str) else ""


def _limitations_are_closed(values: tuple[str, ...]) -> bool:
    return bool(values) and tuple(sorted(set(values))) == values


def _zeroed_bundle_digest(bundle: BaseModel, digest_field: str) -> str:
    dumped = bundle.model_dump(mode="json")
    dumped[digest_field] = "0" * 64
    return canonical_sha256(dumped)


def _raw_bundle_digest(bundle: CanonicalEvidenceBundle) -> str:
    return canonical_sha256(
        {
            "authority": bundle.authority_identity.model_dump(mode="json"),
            "paths": [item.model_dump(mode="json") for item in bundle.content_paths],
            "glyphs": [item.model_dump(mode="json") for item in bundle.glyph_evidence],
            "stream": bundle.canonical_stream_digest,
            "limitations": bundle.limitation_codes,
            "policy": bundle.resource_policy.model_dump(mode="json"),
            "completeness": bundle.generation_completeness,
        }
    )


def _raw_result_integrity(payload: RawAuthorityResult) -> bool:
    bundle = payload.bundle
    metrics = payload.metrics
    if bundle is None:
        return (
            payload.status == "unavailable"
            and not payload.operations
            and not payload.fonts
            and not payload.mappings
            and _limitations_are_closed(payload.limitations)
            and metrics.operation_count == 0
            and metrics.font_count == 0
            and metrics.glyph_or_code_count == 0
            and metrics.mapping_segment_count == 0
            and metrics.limitation_count == len(payload.limitations)
        )
    expected_statuses = (
        {"complete"}
        if bundle.generation_completeness == "complete"
        else {"partial", "resource_bound_exceeded"}
    )
    return (
        payload.status in expected_statuses
        and payload.limitations == bundle.limitation_codes
        and tuple(sorted(set(payload.limitations))) == payload.limitations
        and not bundle.mapping_segments
        and not bundle.parser_lineage
        and bundle.bundle_digest == _raw_bundle_digest(bundle)
        and metrics.operation_count == len(payload.operations)
        and metrics.font_count == len(payload.fonts)
        and metrics.mapping_segment_count == len(payload.mappings)
        and metrics.limitation_count == len(payload.limitations)
    )


def _raw_input_is_bound(
    payload: RawAuthorityResult,
    *,
    source_sha256: str,
    original_page_number: int,
) -> bool:
    if not _raw_result_integrity(payload):
        return False
    bundle = payload.bundle
    return bundle is None or (
        bundle.authority_identity.source_artifact_sha256 == source_sha256
        and bundle.authority_identity.original_page_number == original_page_number
        and bundle.authority_identity.created_from_source_identity == source_sha256
    )


def _strict_result_integrity(
    payload: StrictDecoderResult,
    *,
    raw_authority_result: RawAuthorityResult,
    source_sha256: str,
    original_page_number: int,
) -> bool:
    inventory = payload.inventory
    bundle_v2 = payload.bundle_v2
    status = _status_value(payload.status)
    if inventory is None or bundle_v2 is None:
        return (
            inventory is None
            and bundle_v2 is None
            and status in {"unavailable", "unsafe"}
            and _limitations_are_closed(payload.limitations)
            and payload.metrics.code_unit_count == 0
            and payload.metrics.mapping_step_count == 0
            and payload.metrics.conflict_count == 0
        )
    raw_bundle = raw_authority_result.bundle
    if raw_bundle is None:
        return False
    code_units = inventory.code_units
    mapping_steps = inventory.mapping_steps
    return (
        status == _status_value(inventory.completeness)
        and status == _status_value(bundle_v2.decoder_provenance_completeness)
        and bundle_v2.authority_identity == raw_bundle.authority_identity
        and bundle_v2.content_paths == raw_bundle.content_paths
        and bundle_v2.glyph_evidence == raw_bundle.glyph_evidence
        and bundle_v2.canonical_stream_digest == raw_bundle.canonical_stream_digest
        and bundle_v2.mapping_segments == raw_bundle.mapping_segments
        and bundle_v2.parser_lineage == raw_bundle.parser_lineage
        and bundle_v2.limitation_codes == raw_bundle.limitation_codes
        and bundle_v2.resource_policy == raw_bundle.resource_policy
        and bundle_v2.generation_completeness == raw_bundle.generation_completeness
        and bundle_v2.decoder_evidence == inventory
        and bundle_v2.decoder_evidence_digest == inventory.inventory_digest
        and bundle_v2.v1_compatibility_reference == raw_bundle.bundle_digest
        and bundle_v2.authority_identity.source_artifact_sha256 == source_sha256
        and bundle_v2.authority_identity.original_page_number == original_page_number
        and all(
            item.source_artifact_sha256 == source_sha256
            and item.original_page_number == original_page_number
            for item in code_units
        )
        and all(
            item.source_artifact_sha256 == source_sha256
            and item.original_page_number == original_page_number
            for item in mapping_steps
        )
        and payload.metrics.code_unit_count == len(code_units)
        and payload.metrics.codespace_count == len(inventory.codespaces)
        and payload.metrics.cid_mapping_count == len(inventory.cid_mappings)
        and payload.metrics.gid_mapping_count == len(inventory.gid_mappings)
        and payload.metrics.unicode_evidence_count == len(inventory.unicode_sequences)
        and payload.metrics.actualtext_substitution_count
        == len(inventory.actualtext_substitutions)
        and payload.metrics.conflict_count == len(inventory.conflicts)
        and payload.metrics.mapping_step_count == len(mapping_steps)
        and payload.metrics.serialized_inventory_bytes
        == inventory.resource_usage.serialized_bytes
    )


def _source_lineage_decoder_references_are_bound(
    provenance: OperationProvenanceBundle | None,
    inventory: DecoderEvidenceInventory | None,
) -> bool:
    if provenance is None:
        return True
    if inventory is None:
        return not provenance.code_execution
    inventory_code_identities = tuple(
        item.evidence_identity for item in inventory.code_units
    )
    if len(set(inventory_code_identities)) != len(inventory_code_identities):
        return False
    referenced_code_identities = tuple(
        item.decoder_code_identity for item in provenance.code_execution
    )
    return set(referenced_code_identities) <= set(inventory_code_identities)


def _request_inputs_are_bound(request: CtifRequest) -> bool:
    if type(request) in (CtifRawAuthorityRequest, CtifPdfiumLineageRequest):
        return True
    if type(request) is CtifStrictDecoderRequest:
        return _raw_input_is_bound(
            request.raw_authority_result,
            source_sha256=request.source_sha256,
            original_page_number=request.original_page_number,
        )
    if type(request) is CtifOperationProvenanceRequest:
        return _raw_input_is_bound(
            request.raw_authority_result,
            source_sha256=request.source_sha256,
            original_page_number=request.original_page_number,
        ) and _strict_result_integrity(
            request.decoder_result,
            raw_authority_result=request.raw_authority_result,
            source_sha256=request.source_sha256,
            original_page_number=request.original_page_number,
        )
    if type(request) is CtifSourceLineageRequest:
        provenance = request.operation_provenance_result.bundle
        inventory = request.decoder_result.inventory
        bundle_v2 = request.decoder_result.bundle_v2
        return (
            (
                provenance is None
                or (
                    provenance.source_artifact_sha256 == request.source_sha256
                    and provenance.original_page_number == request.original_page_number
                    and provenance.bundle_digest
                    == _zeroed_bundle_digest(provenance, "bundle_digest")
                )
            )
            and (
                inventory is None
                or all(
                    item.source_artifact_sha256 == request.source_sha256
                    and item.original_page_number == request.original_page_number
                    for item in inventory.code_units
                )
            )
            and (bundle_v2 is None or bundle_v2.decoder_evidence == inventory)
            and _source_lineage_decoder_references_are_bound(provenance, inventory)
        )
    return False


def _raw_payload_matches_request(
    request: CtifRawAuthorityRequest, payload: RawAuthorityResult
) -> bool:
    from .authority import _CTIF_RAW_AUTHORITY_GENERATOR_IDENTITY

    if not _raw_result_integrity(payload):
        return False
    bundle = payload.bundle
    if request.expected_source_sha256 != request.source_sha256:
        return bundle is None and payload.status == "unavailable"
    if bundle is None:
        return True
    identity = bundle.authority_identity
    return (
        identity.authority_version == _RAW_AUTHORITY_VERSION
        and identity.source_artifact_sha256 == request.source_sha256
        and identity.document_identity == request.document_identity
        and identity.original_page_number == request.original_page_number
        and identity.page_identity == request.page_identity
        and identity.source_snapshot_identity == request.source_snapshot_identity
        and _status_value(identity.generation_mode) == "validation_only"
        and identity.generator_identity == _CTIF_RAW_AUTHORITY_GENERATOR_IDENTITY
        and identity.extraction_configuration_identity
        == request.extraction_configuration_identity
        and identity.resource_policy_identity == _RAW_RESOURCE_POLICY
        and identity.normalization_policy_identity == _RAW_NORMALIZATION_POLICY
        and identity.decoding_policy_identity == _RAW_DECODING_POLICY
        and identity.created_from_source_identity == request.source_sha256
        and bundle.resource_policy == request.resource_policy
    )


def _strict_payload_matches_request(
    request: CtifStrictDecoderRequest, payload: StrictDecoderResult
) -> bool:
    if not _strict_result_integrity(
        payload,
        raw_authority_result=request.raw_authority_result,
        source_sha256=request.source_sha256,
        original_page_number=request.original_page_number,
    ):
        return False
    if request.expected_source_sha256 != request.source_sha256:
        return payload.inventory is None and payload.bundle_v2 is None
    inventory = payload.inventory
    if inventory is None:
        return True
    usage = inventory.resource_usage
    return (
        len(inventory.mapping_steps) <= request.decoder_policy.max_mapping_steps
        and len(inventory.conflicts) <= request.decoder_policy.max_mapping_conflicts
        and usage.serialized_bytes <= request.decoder_policy.max_decoder_inventory_bytes
    )


def _operation_payload_matches_request(
    request: CtifOperationProvenanceRequest,
    payload: OperationProvenanceResult,
) -> bool:
    bundle = payload.bundle
    if bundle is None:
        return payload.status == "unavailable" and _limitations_are_closed(
            payload.limitation_codes
        )
    if request.expected_source_sha256 != request.source_sha256:
        return False
    raw_bundle = request.raw_authority_result.bundle
    inventory = request.decoder_result.inventory
    if raw_bundle is None or inventory is None:
        return False
    operation_identities = {item.operation_identity for item in bundle.operations}
    decoder_units = {item.evidence_identity: item for item in inventory.code_units}
    expected_policy = (
        _TEXT_LINEAGE_OPERATION_PROVENANCE_POLICY
        if request.text_lineage_only
        else _OPERATION_PROVENANCE_POLICY
    )
    return (
        payload.status == bundle.completeness
        and payload.limitation_codes == bundle.limitation_codes
        and tuple(sorted(set(payload.limitation_codes))) == payload.limitation_codes
        and bundle.bundle_version == _OPERATION_PROVENANCE_VERSION
        and bundle.source_artifact_sha256 == request.source_sha256
        and bundle.document_identity == raw_bundle.authority_identity.document_identity
        and bundle.original_page_number == request.original_page_number
        and bundle.page_identity == raw_bundle.authority_identity.page_identity
        and bundle.raw_authority_bundle_digest == raw_bundle.bundle_digest
        and bundle.decoder_inventory_digest == inventory.inventory_digest
        and bundle.policy_identity == expected_policy
        and bundle.bundle_digest == _zeroed_bundle_digest(bundle, "bundle_digest")
        and all(
            item.source_artifact_sha256 == request.source_sha256
            and item.original_page_number == request.original_page_number
            for item in bundle.operations
        )
        and all(
            item.operation_identity in operation_identities
            and item.decoder_code_identity in decoder_units
            and item.raw_code_start
            == decoder_units[item.decoder_code_identity].raw_code_start
            and item.raw_code_end_exclusive
            == decoder_units[item.decoder_code_identity].raw_code_end_exclusive
            and item.deterministic_ordinal
            == decoder_units[item.decoder_code_identity].deterministic_ordinal
            for item in bundle.code_execution
        )
        and bundle.metrics.operation_count == len(bundle.operations)
        and bundle.metrics.text_show_operation_count
        == sum(item.operator in _TEXT_SHOW_OPERATORS for item in bundle.operations)
        and bundle.metrics.form_invocation_count == len(bundle.form_invocations)
        and bundle.metrics.code_unit_count == len(bundle.code_execution)
        and bundle.metrics.operation_span_count == len(bundle.operations)
        and bundle.metrics.operand_span_count == len(bundle.operations)
        and bundle.metrics.ctm_count == len(bundle.operations)
    )


def _pdfium_payload_matches_request(
    request: CtifPdfiumLineageRequest,
    payload: PdfiumLineageResult,
) -> bool:
    bundle = payload.bundle
    if bundle is None:
        return payload.status == "unavailable" and _limitations_are_closed(
            payload.limitation_codes
        )
    if request.expected_source_sha256 != request.source_sha256:
        return False
    object_identities = {item.object_identity for item in bundle.text_objects}
    return (
        payload.status == bundle.completeness
        and payload.limitation_codes == bundle.limitation_codes
        and tuple(sorted(set(payload.limitation_codes))) == payload.limitation_codes
        and bundle.bundle_version == _PDFIUM_LINEAGE_VERSION
        and bundle.source_artifact_sha256 == request.source_sha256
        and bundle.document_identity == request.document_identity
        and bundle.original_page_number == request.original_page_number
        and bundle.page_identity == request.page_identity
        and bundle.parser_configuration_identity
        == request.parser_configuration_identity
        and bundle.policy_identity == _PDFIUM_LINEAGE_POLICY
        and len(bundle.text_objects) <= request.max_text_objects
        and len(bundle.characters) <= request.max_characters
        and tuple(item.object_ordinal for item in bundle.text_objects)
        == tuple(range(len(bundle.text_objects)))
        and tuple(item.character_index for item in bundle.characters)
        == tuple(range(len(bundle.characters)))
        and all(
            item.parent_text_object_identity is None
            or item.parent_text_object_identity in object_identities
            for item in bundle.characters
        )
        and bundle.metrics.text_object_count == len(bundle.text_objects)
        and bundle.metrics.character_count == len(bundle.characters)
        and bundle.metrics.parent_bound_character_count
        == sum(
            item.parent_text_object_identity is not None for item in bundle.characters
        )
        and bundle.metrics.parser_inserted_character_count
        == sum(
            item.character_role == "parser_inserted_separator"
            for item in bundle.characters
        )
        and bundle.metrics.unbound_character_count
        == sum(item.character_role == "unbound" for item in bundle.characters)
        and bundle.metrics.invalid_bbox_count
        == sum(item.bbox is None for item in bundle.characters)
        and bundle.metrics.resource_limited
        == any(code.endswith("bound_exceeded") for code in bundle.limitation_codes)
        and bundle.bundle_digest == _zeroed_bundle_digest(bundle, "bundle_digest")
    )


def _source_payload_matches_request(
    request: CtifSourceLineageRequest,
    payload: SourceLineageResult,
) -> bool:
    bundle = payload.bundle
    if bundle is None:
        return payload.status == "unavailable" and _limitations_are_closed(
            payload.limitation_codes
        )
    if request.expected_source_sha256 != request.source_sha256:
        return False
    provenance = request.operation_provenance_result.bundle
    inventory = request.decoder_result.inventory
    operation_identities = (
        {item.operation_identity for item in provenance.operations}
        if provenance is not None
        else set()
    )
    decoder_identities = (
        {item.evidence_identity for item in inventory.code_units}
        if inventory is not None
        else set()
    )
    event_identities = {item.event_identity for item in bundle.events}
    character_identities = {item.character_identity for item in bundle.characters}
    return (
        payload.status == bundle.completeness
        and payload.limitation_codes == bundle.limitation_codes
        and tuple(sorted(set(payload.limitation_codes))) == payload.limitation_codes
        and bundle.bundle_version == _SOURCE_LINEAGE_VERSION
        and bundle.source_artifact_sha256 == request.source_sha256
        and bundle.original_page_number == request.original_page_number
        and bundle.parser_configuration_identity
        == request.parser_configuration_identity
        and bundle.policy_identity == _SOURCE_LINEAGE_POLICY
        and bundle.operation_provenance_digest
        == (provenance.bundle_digest if provenance is not None else None)
        and all(
            item.event_identity in event_identities
            and (
                item.operation_identity is None
                or item.operation_identity in operation_identities
            )
            and all(
                identity in decoder_identities
                for identity in item.decoder_code_identities
            )
            for item in bundle.characters
        )
        and all(
            item.layout_kind == kind
            and all(
                identity in character_identities
                for identity in item.child_character_identities
            )
            for kind, items in (("word", bundle.words), ("line", bundle.lines))
            for item in items
        )
        and bundle.metrics.native_event_count == len(bundle.events)
        and bundle.metrics.source_character_count == len(bundle.characters)
        and bundle.metrics.exact_operation_linked_characters
        == sum(item.operation_identity is not None for item in bundle.characters)
        and bundle.metrics.exact_decoder_code_linked_characters
        == sum(item.decoder_code_identity is not None for item in bundle.characters)
        and bundle.metrics.unmapped_characters
        == sum(item.proof_method == "UNPROVEN" for item in bundle.characters)
        and bundle.bundle_digest == _zeroed_bundle_digest(bundle, "bundle_digest")
    )


def _payload_matches_request(request: CtifRequest, payload: object) -> bool:
    if isinstance(payload, _DependencyUnavailablePayload):
        return False
    if type(request) is CtifRawAuthorityRequest and type(payload) is RawAuthorityResult:
        return _raw_payload_matches_request(request, payload)
    if (
        type(request) is CtifStrictDecoderRequest
        and type(payload) is StrictDecoderResult
    ):
        return _strict_payload_matches_request(request, payload)
    if (
        type(request) is CtifOperationProvenanceRequest
        and type(payload) is OperationProvenanceResult
    ):
        return _operation_payload_matches_request(request, payload)
    if (
        type(request) is CtifPdfiumLineageRequest
        and type(payload) is PdfiumLineageResult
    ):
        return _pdfium_payload_matches_request(request, payload)
    if (
        type(request) is CtifSourceLineageRequest
        and type(payload) is SourceLineageResult
    ):
        return _source_payload_matches_request(request, payload)
    return False


def _response_matches_request(request: CtifRequest, response: CtifResponse) -> bool:
    if (
        response.protocol_version != request.protocol_version
        or response.operation != request.operation
        or response.source_sha256 != request.source_sha256
        or response.source_size_bytes != request.source_size_bytes
        or response.options_policy_digest != request.options_policy_digest
        or response.request_digest != request.request_digest
        or not _worker_metrics_are_neutral(response.metrics)
    ):
        return False
    expected_digest = _result_digest(
        request=request,
        outcome=response.outcome,
        limitation_code=response.limitation_code,
        payload=response.payload,
    )
    if response.result_digest != expected_digest:
        return False
    return response.payload is None or _payload_matches_request(
        request, response.payload
    )


def _parse_worker_response(
    request: CtifRequest,
    output: bytes,
) -> CtifResponse | None:
    lines = output.splitlines()
    if len(lines) != 1 or output not in {lines[0], lines[0] + b"\n"}:
        return None
    response_type = _response_type_for_request(request)
    try:
        response = response_type.model_validate_json(lines[0], strict=True)
        matches = _response_matches_request(request, response)
    except Exception:  # noqa: BLE001
        return None
    return response if matches else None


def _execute_request(request: CtifRequest) -> CtifResponse:
    try:
        _decode_and_validate_source(request)
    except CtifRuntimeRequestError:
        return _failure_response(request, "invalid_request")
    request_payload = request.model_dump_json().encode("utf-8") + b"\n"
    if len(request_payload) > _MAX_REQUEST_BYTES:
        return _failure_response(request, "resource_exceeded")
    configuration = _process_configuration(request)
    try:
        outcome = _run_bounded_process(
            [sys.executable, "-m", _WORKER_MODULE],
            stdin_payload=request_payload,
            hard_timeout_seconds=configuration.hard_timeout_seconds,
            terminate_grace_seconds=_TERMINATE_GRACE_SECONDS,
            max_stdout_bytes=configuration.max_stdout_bytes,
            max_stderr_bytes=_MAX_STDERR_BYTES,
        )
    except Exception:  # noqa: BLE001
        return _failure_response(request, "runtime_unavailable")
    metrics = _metrics_from_process(outcome)
    if outcome.process_id is None:
        return _failure_response(request, "runtime_unavailable", metrics=metrics)
    if outcome.timed_out:
        return _failure_response(request, "timeout", metrics=metrics)
    if _is_probable_resource_exit(outcome.exit_code):
        return _failure_response(request, "resource_exceeded", metrics=metrics)
    if outcome.exit_code != 0:
        return _failure_response(request, "worker_failed", metrics=metrics)
    if outcome.stdout_truncated or outcome.stderr_truncated or bool(outcome.stderr):
        return _failure_response(request, "protocol_error", metrics=metrics)
    response = _parse_worker_response(request, outcome.stdout)
    if response is None:
        return _failure_response(request, "protocol_error", metrics=metrics)
    return response.model_copy(update={"metrics": metrics})


def run_raw_authority(
    *,
    source_bytes: bytes,
    expected_source_sha256: str,
    original_page_number: int,
    document_identity: str,
    page_identity: str,
    source_snapshot_identity: str,
    extraction_configuration_identity: str,
    resource_policy: ResourcePolicy,
) -> CtifRawAuthorityResponse:
    values = {
        **_source_base_fields(
            source_bytes, expected_source_sha256=expected_source_sha256
        ),
        "operation": "raw_authority",
        "original_page_number": original_page_number,
        "document_identity": document_identity,
        "page_identity": page_identity,
        "source_snapshot_identity": source_snapshot_identity,
        "extraction_configuration_identity": extraction_configuration_identity,
        "resource_policy": resource_policy,
    }
    request = _finalize_request(CtifRawAuthorityRequest, values)
    return cast(CtifRawAuthorityResponse, _execute_request(request))


def run_strict_decoder(
    *,
    source_bytes: bytes,
    expected_source_sha256: str,
    original_page_number: int,
    raw_authority_result: RawAuthorityResult,
    decoder_policy: DecoderResourcePolicy,
) -> CtifStrictDecoderResponse:
    values = {
        **_source_base_fields(
            source_bytes, expected_source_sha256=expected_source_sha256
        ),
        "operation": "strict_decoder",
        "original_page_number": original_page_number,
        "raw_authority_result": raw_authority_result,
        "decoder_policy": decoder_policy,
    }
    request = _finalize_request(CtifStrictDecoderRequest, values)
    return cast(CtifStrictDecoderResponse, _execute_request(request))


def run_operation_provenance(
    *,
    source_bytes: bytes,
    expected_source_sha256: str,
    original_page_number: int,
    raw_authority_result: RawAuthorityResult,
    decoder_result: StrictDecoderResult,
    decoder_policy: DecoderResourcePolicy,
    text_lineage_only: bool = False,
) -> CtifOperationProvenanceResponse:
    values = {
        **_source_base_fields(
            source_bytes, expected_source_sha256=expected_source_sha256
        ),
        "operation": "operation_provenance",
        "original_page_number": original_page_number,
        "raw_authority_result": raw_authority_result,
        "decoder_result": decoder_result,
        "decoder_policy": decoder_policy,
        "text_lineage_only": text_lineage_only,
    }
    request = _finalize_request(CtifOperationProvenanceRequest, values)
    return cast(CtifOperationProvenanceResponse, _execute_request(request))


def run_pdfium_lineage(
    *,
    source_bytes: bytes,
    expected_source_sha256: str,
    document_identity: str,
    original_page_number: int,
    page_identity: str,
    parser_configuration_identity: str,
    max_text_objects: int = 20_000,
    max_characters: int = 200_000,
) -> CtifPdfiumLineageResponse:
    values = {
        **_source_base_fields(
            source_bytes, expected_source_sha256=expected_source_sha256
        ),
        "operation": "pdfium_lineage",
        "document_identity": document_identity,
        "original_page_number": original_page_number,
        "page_identity": page_identity,
        "parser_configuration_identity": parser_configuration_identity,
        "max_text_objects": max_text_objects,
        "max_characters": max_characters,
    }
    request = _finalize_request(CtifPdfiumLineageRequest, values)
    return cast(CtifPdfiumLineageResponse, _execute_request(request))


def run_source_lineage(
    *,
    source_bytes: bytes,
    expected_source_sha256: str,
    original_page_number: int,
    operation_provenance_result: OperationProvenanceResult,
    decoder_result: StrictDecoderResult,
    parser_configuration_identity: str,
) -> CtifSourceLineageResponse:
    values = {
        **_source_base_fields(
            source_bytes, expected_source_sha256=expected_source_sha256
        ),
        "operation": "source_lineage",
        "original_page_number": original_page_number,
        "operation_provenance_result": operation_provenance_result,
        "decoder_result": decoder_result,
        "parser_configuration_identity": parser_configuration_identity,
    }
    request = _finalize_request(CtifSourceLineageRequest, values)
    return cast(CtifSourceLineageResponse, _execute_request(request))


def _is_probable_resource_exit(exit_code: int | None) -> bool:
    """Classify only the worker's dedicated code; never guess from SIGKILL."""

    return exit_code == 120 or (
        exit_code is not None and exit_code == -getattr(signal, "SIGXCPU", 2**31 - 1)
    )

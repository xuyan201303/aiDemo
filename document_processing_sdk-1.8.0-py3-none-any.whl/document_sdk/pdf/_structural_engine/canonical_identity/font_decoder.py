# ruff: noqa: BLE001, C901, EM101, PLR0911, PLR0912, PLR0913, PLR0915, PLR2004, TRY301
"""Strict font, encoding, CID and Unicode resolution for CTIF-1B."""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from typing import Any

import pypdf
from pypdf import _codecs
from pypdf.generic import (
    DictionaryObject,
    IndirectObject,
    NameObject,
)

from .cmap_decoder import CMapCodeSpaceRange, ParsedCMap, parse_cmap
from .decoder_limits import EXPERIMENTAL_CTIF1B_DECODER_POLICY, DecoderResourcePolicy
from .pdf_object_identity import PdfObjectIdentityContext, canonical_pdf_object_digest
from .raw_pdf import object_identity
from .serialization import canonical_sha256


class FontDecodeError(ValueError):
    """Typed fail-closed font resolution error."""


@dataclass(frozen=True)
class ResolvedFont:
    resource_name: str
    font_identity: str
    subtype: str
    base_font: str | None
    object_identity: str | None
    encoding_identity: str | None
    writing_mode: str
    codespaces: tuple[CMapCodeSpaceRange, ...]
    to_unicode: ParsedCMap | None
    encoding_cmap: ParsedCMap | None
    simple_unicode: tuple[tuple[int, tuple[int, ...]], ...]
    differences_identities: tuple[tuple[int, str], ...]
    cid_system_info_identity: str | None
    cid_to_gid_identity: str | None
    cid_to_gid_bytes: bytes | None
    complete: bool
    limitation_codes: tuple[str, ...]

    @property
    def simple_map(self) -> dict[int, tuple[int, ...]]:
        return dict(self.simple_unicode)


def _object_digest(value: Any, *, context: PdfObjectIdentityContext) -> str:
    return canonical_pdf_object_digest(value, context=context)


def _glyph_scalars(name: str) -> tuple[int, ...] | None:
    if name in {"/.notdef", ".notdef"}:
        return None
    if not name.startswith("/"):
        return tuple(ord(character) for character in name) if name else None
    normalized = name if name.startswith("/") else "/" + name
    mapped = _codecs.adobe_glyphs.get(normalized)
    if mapped is not None:
        return tuple(ord(character) for character in mapped)
    raw = normalized[1:]
    try:
        if raw.startswith("uni") and len(raw) > 3 and len(raw[3:]) % 4 == 0:
            return tuple(
                int(raw[index : index + 4], 16) for index in range(3, len(raw), 4)
            )
        if raw.startswith("u") and 5 <= len(raw) <= 7:
            return (int(raw[1:], 16),)
    except ValueError:
        return None
    return None


def _base_encoding(name: str) -> list[str] | None:
    values = _codecs.charset_encoding.get(name)
    return list(values) if isinstance(values, list) and len(values) == 256 else None


def _simple_mapping(
    font: DictionaryObject, subtype: str
) -> tuple[
    tuple[tuple[int, tuple[int, ...]], ...],
    tuple[tuple[int, str], ...],
    tuple[str, ...],
]:
    limitations: set[str] = set()
    differences: list[tuple[int, str]] = []
    encoding = font.get("/Encoding")
    if isinstance(encoding, IndirectObject):
        encoding = encoding.get_object()
    if isinstance(encoding, (NameObject, str)):
        names = _base_encoding(str(encoding))
        if names is None:
            limitations.add("unsupported_simple_encoding")
            names = ["/.notdef"] * 256
    elif isinstance(encoding, (DictionaryObject, dict)):
        names = (
            _base_encoding(str(encoding.get("/BaseEncoding") or "/StandardEncoding"))
            or ["/.notdef"] * 256
        )
        raw_differences = encoding.get("/Differences") or []
        current = None
        assigned: set[int] = set()
        for item in raw_differences:
            if isinstance(item, (int, float)):
                current = int(item)
                continue
            if current is None or not 0 <= current <= 255:
                limitations.add("malformed_differences")
                continue
            if current in assigned:
                limitations.add("differences_duplicate_assignment")
            assigned.add(current)
            glyph = str(item)
            names[current] = glyph
            differences.append(
                (current, canonical_sha256({"code": current, "glyph": glyph}))
            )
            current += 1
    elif encoding is None and subtype in {"/Type1", "/Type3"}:
        names = _base_encoding("/StandardEncoding") or ["/.notdef"] * 256
    else:
        limitations.add("simple_encoding_unavailable")
        names = ["/.notdef"] * 256
    mapping = []
    for code, glyph in enumerate(names):
        scalars = _glyph_scalars(str(glyph))
        if scalars is not None and all(
            0 <= scalar <= 0x10FFFF and not 0xD800 <= scalar <= 0xDFFF
            for scalar in scalars
        ):
            mapping.append((code, scalars))
    if not mapping:
        limitations.add("simple_unicode_mapping_unavailable")
    return tuple(mapping), tuple(sorted(differences)), tuple(sorted(limitations))


def resolve_font(
    resources: Any,
    resource_name: str,
    *,
    source_artifact_sha256: str,
    document_identity: str,
    original_page_number: int,
    content_path_identity: str,
    policy: DecoderResourcePolicy = EXPERIMENTAL_CTIF1B_DECODER_POLICY,
) -> ResolvedFont:
    try:
        font_map = (resources or {}).get("/Font") or {}
        raw = font_map.get(resource_name)
        font = raw.get_object() if raw is not None else None
    except Exception:
        raise FontDecodeError("font_resource_unavailable") from None
    if not isinstance(font, (DictionaryObject, dict)):
        raise FontDecodeError("font_resource_unavailable")
    subtype = str(font.get("/Subtype") or "")
    base = str(font.get("/BaseFont") or "") or None
    limitations: set[str] = set()
    to_unicode = None
    encoding_cmap = None
    codespaces = ()
    simple = ()
    differences = ()
    tounicode_raw = font.get("/ToUnicode")
    if tounicode_raw is not None:
        try:
            stream = tounicode_raw.get_object()
            data = stream.get_data()
            if len(data) > policy.max_tounicode_bytes:
                raise FontDecodeError("tounicode_byte_bound_exceeded")
            to_unicode = parse_cmap(data, kind="tounicode", policy=policy)
            codespaces = to_unicode.codespaces  # type: ignore[assignment]
            limitations.update(to_unicode.limitation_codes)
        except (FontDecodeError, Exception) as error:
            limitations.add(
                str(error)
                if isinstance(error, FontDecodeError)
                else "malformed_tounicode"
            )
    encoding = font.get("/Encoding")
    encoding_name = str(encoding) if isinstance(encoding, (NameObject, str)) else None
    writing = (
        "vertical" if encoding_name and encoding_name.endswith("-V") else "horizontal"
    )
    if subtype == "/Type0":
        if encoding_name in {"/Identity-H", "/Identity-V"}:
            codespaces = codespaces or (  # type: ignore[assignment]
                CMapCodeSpaceRange(b"\x00\x00", b"\xff\xff", 0),
            )
        elif encoding is not None:
            try:
                encoding_obj = encoding.get_object()  # pyright: ignore[reportAttributeAccessIssue]
                encoding_cmap = parse_cmap(
                    encoding_obj.get_data(),  # pyright: ignore[reportAttributeAccessIssue, reportOptionalMemberAccess]
                    kind="encoding",
                    policy=policy,
                )
                limitations.update(encoding_cmap.limitation_codes)
                if not codespaces:
                    codespaces = encoding_cmap.codespaces  # type: ignore[assignment]
            except Exception:
                limitations.add("encoding_cmap_unavailable")
    elif subtype in {"/Type1", "/TrueType", "/Type3"}:
        simple, differences, simple_limits = _simple_mapping(font, subtype)  # type: ignore[arg-type, assignment]
        limitations.update(simple_limits)
        # PDF simple-font character codes are always one byte.  A malformed or
        # producer-specific ToUnicode codespace must not merge adjacent source
        # bytes into a synthetic multi-byte font code.
        if codespaces and any(  # type: ignore[unreachable]
            len(item.lower) != 1 or len(item.upper) != 1 for item in codespaces
        ):
            limitations.add("simple_font_tounicode_codespace_ignored")  # type: ignore[unreachable]
        codespaces = (CMapCodeSpaceRange(b"\x00", b"\xff", 0),)  # type: ignore[assignment]
    else:
        limitations.add("unsupported_font_subtype")
    descendants = font.get("/DescendantFonts") or []
    descendant = descendants[0].get_object() if descendants else None
    context = PdfObjectIdentityContext(
        source_artifact_sha256=source_artifact_sha256,
        document_identity=document_identity,
        original_page_number=original_page_number,
        content_path_identity=content_path_identity,
    )
    cid_system = None
    cid_to_gid_identity = None
    cid_to_gid_bytes = None
    if isinstance(descendant, (DictionaryObject, dict)):
        cid_system = _object_digest(descendant.get("/CIDSystemInfo"), context=context)
        cid_to_gid = descendant.get("/CIDToGIDMap")
        if isinstance(cid_to_gid, (NameObject, str)) and str(cid_to_gid) == "/Identity":
            cid_to_gid_identity = "identity"
        elif cid_to_gid is not None:
            try:
                cid_to_gid_obj = cid_to_gid.get_object()  # pyright: ignore[reportAttributeAccessIssue]
                cid_to_gid_bytes = cid_to_gid_obj.get_data()  # pyright: ignore[reportAttributeAccessIssue, reportOptionalMemberAccess]
                cid_to_gid_identity = sha256(cid_to_gid_bytes).hexdigest()
            except Exception:
                limitations.add("malformed_cid_to_gid_map")
        else:
            limitations.add("cid_to_gid_map_unavailable")
    font_payload = {
        "pypdf": pypdf.__version__,
        "source": source_artifact_sha256,
        "document": document_identity,
        "page": original_page_number,
        "content_path": content_path_identity,
        "resource": resource_name,
        "object": object_identity(raw),
        "digest": _object_digest(font, context=context),
        "subtype": subtype,
        "base": base,
        "encoding": encoding_name,
        "tounicode": to_unicode.cmap_identity if to_unicode else None,
        "encoding_cmap": encoding_cmap.cmap_identity if encoding_cmap else None,
        "cid_system": cid_system,
        "cid_to_gid": cid_to_gid_identity,
    }
    identity = canonical_sha256(font_payload)
    complete = (
        not limitations
        and bool(codespaces)
        and (bool(simple) or to_unicode is not None)
    )
    return ResolvedFont(
        resource_name,
        identity,
        subtype,
        base,
        object_identity(raw),
        encoding_name,
        writing,
        tuple(codespaces),
        to_unicode,
        encoding_cmap,
        simple,
        differences,
        cid_system,
        cid_to_gid_identity,
        cid_to_gid_bytes,
        complete,
        tuple(sorted(limitations)),
    )


def decode_actualtext_bytes(value: bytes) -> tuple[int, ...]:
    try:
        if value.startswith(b"\xfe\xff"):
            text = value[2:].decode("utf-16-be", errors="strict")
        else:
            table = _codecs.charset_encoding.get("/PDFDocEncoding")
            if not isinstance(table, list) or len(table) != 256:
                raise FontDecodeError("pdfdoc_encoding_unavailable")
            text = "".join(table[byte] for byte in value)
    except (UnicodeError, FontDecodeError):
        raise FontDecodeError("actualtext_decode_failed") from None
    scalars = tuple(ord(character) for character in text)
    if any(0xD800 <= value <= 0xDFFF for value in scalars):
        raise FontDecodeError("actualtext_invalid_scalar")
    return scalars

# ruff: noqa: C901, EM101, I001, PERF401, PLR0912, PLR0915, PLR2004

"""Strict bounded ToUnicode and encoding-CMap parsing for CTIF-1B."""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import re
from typing import Literal

from .decoder_limits import DecoderResourcePolicy, EXPERIMENTAL_CTIF1B_DECODER_POLICY
from .serialization import canonical_sha256

_TOKEN = re.compile(
    rb"%[^\r\n]*|<([0-9A-Fa-f\s]*)>|\[|\]|/[!#-'*-.0-;=?-Z\\^-z|~]+|[^\x00\x09\x0a\x0c\x0d\x20<>\[\]]+"
)


class CMapError(ValueError):
    """Typed fail-closed CMap error."""


@dataclass(frozen=True)
class CMapCodeSpaceRange:
    lower: bytes
    upper: bytes
    ordinal: int

    @property
    def identity(self) -> str:
        return canonical_sha256(
            {
                "lower": self.lower.hex().upper(),
                "upper": self.upper.hex().upper(),
                "ordinal": self.ordinal,
            }
        )


@dataclass(frozen=True)
class CMapMapping:
    source: bytes
    unicode_scalars: tuple[int, ...] | None
    cid: int | None
    method: str
    ordinal: int
    entry_identity: str


@dataclass(frozen=True)
class CMapConflict:
    conflict_type: str
    source_hex: str
    competing_identities: tuple[str, ...]


@dataclass(frozen=True)
class ParsedCMap:
    cmap_identity: str
    kind: Literal["tounicode", "encoding"]
    codespaces: tuple[CMapCodeSpaceRange, ...]
    mappings: tuple[CMapMapping, ...]
    conflicts: tuple[CMapConflict, ...]
    usecmap_names: tuple[str, ...]
    cmap_name: str | None
    wmode: int
    complete: bool
    limitation_codes: tuple[str, ...]


def _tokens(data: bytes, policy: DecoderResourcePolicy) -> list[bytes]:
    if len(data) > max(policy.max_cmap_bytes, policy.max_tounicode_bytes):
        raise CMapError("cmap_byte_bound_exceeded")
    result: list[bytes] = []
    for match in _TOKEN.finditer(data):
        raw = match.group(0)
        if raw.startswith(b"%"):
            continue
        if raw.startswith(b"<"):
            value = re.sub(rb"\s+", b"", match.group(1) or b"")
            if len(value) % 2 or re.search(rb"[^0-9A-Fa-f]", value):
                raise CMapError("invalid_hex_token")
            result.append(b"<" + value.upper() + b">")
        else:
            result.append(raw)
    return result


def _hex(token: bytes) -> bytes:
    if not token.startswith(b"<") or not token.endswith(b">"):
        raise CMapError("expected_hex_token")
    return bytes.fromhex(token[1:-1].decode("ascii"))


def _unicode_scalars(value: bytes) -> tuple[int, ...]:
    if len(value) % 2:
        raise CMapError("invalid_utf16be_length")
    try:
        text = value.decode("utf-16-be", errors="strict")
    except UnicodeDecodeError:
        raise CMapError("invalid_utf16be") from None
    scalars = tuple(ord(character) for character in text)
    if any(0xD800 <= scalar <= 0xDFFF for scalar in scalars):
        raise CMapError("invalid_unicode_scalar")
    return scalars


def _increment_unicode(value: bytes, offset: int) -> tuple[int, ...]:
    number = int.from_bytes(value, "big") + offset
    if number >= 1 << (8 * len(value)):
        raise CMapError("bfrange_destination_overflow")
    return _unicode_scalars(number.to_bytes(len(value), "big"))


def parse_cmap(
    data: bytes,
    *,
    kind: Literal["tounicode", "encoding"],
    policy: DecoderResourcePolicy = EXPERIMENTAL_CTIF1B_DECODER_POLICY,
) -> ParsedCMap:
    tokens = _tokens(data, policy)
    cmap_identity = sha256(data).hexdigest()
    codespaces: list[CMapCodeSpaceRange] = []
    mappings: list[CMapMapping] = []
    conflicts: list[CMapConflict] = []
    limitations: set[str] = set()
    usecmap: list[str] = []
    cmap_name: str | None = None
    wmode = 0
    mapping_by_source: dict[bytes, list[CMapMapping]] = {}
    index = 0
    while index < len(tokens):
        token = tokens[index]
        if token == b"/CMapName" and index + 1 < len(tokens):
            cmap_name = tokens[index + 1].decode("latin-1")[:128]
            index += 2
            continue
        if token == b"/WMode" and index + 1 < len(tokens):
            try:
                wmode = int(tokens[index + 1])
            except ValueError:
                raise CMapError("invalid_wmode") from None
            index += 2
            continue
        if token == b"usecmap" and index:
            name = tokens[index - 1].decode("latin-1")[:128]
            usecmap.append(name)
            limitations.add("usecmap_unresolved")
            index += 1
            continue
        if token in {
            b"begincodespacerange",
            b"beginbfchar",
            b"beginbfrange",
            b"begincidchar",
            b"begincidrange",
        }:
            if index == 0:
                raise CMapError("missing_section_count")
            try:
                count = int(tokens[index - 1])
            except ValueError:
                raise CMapError("malformed_section_count") from None
            if count < 0:
                raise CMapError("negative_section_count")
            cursor = index + 1
            if token == b"begincodespacerange":
                if count + len(codespaces) > policy.max_codespace_ranges:
                    raise CMapError("codespace_bound_exceeded")
                for _ in range(count):
                    if cursor + 1 >= len(tokens):
                        raise CMapError("missing_codespace_end")
                    lower, upper = _hex(tokens[cursor]), _hex(tokens[cursor + 1])
                    cursor += 2
                    if (
                        len(lower) != len(upper)
                        or not lower
                        or len(lower) > policy.max_code_bytes
                        or int.from_bytes(lower, "big") > int.from_bytes(upper, "big")
                    ):
                        raise CMapError("invalid_codespace_range")
                    codespaces.append(CMapCodeSpaceRange(lower, upper, len(codespaces)))
                end_token = b"endcodespacerange"
            elif token in {b"beginbfchar", b"begincidchar"}:
                bound = policy.max_bfchar_entries
                if count + len(mappings) > bound:
                    raise CMapError("mapping_entry_bound_exceeded")
                for _ in range(count):
                    if cursor + 1 >= len(tokens):
                        raise CMapError("missing_mapping_end")
                    source = _hex(tokens[cursor])
                    destination = tokens[cursor + 1]
                    cursor += 2
                    if not source or len(source) > policy.max_code_bytes:
                        raise CMapError("invalid_source_code")
                    if token == b"beginbfchar":
                        scalars, cid, method = (
                            _unicode_scalars(_hex(destination)),
                            None,
                            "bfchar",
                        )
                    else:
                        try:
                            cid = int(destination)
                        except ValueError:
                            raise CMapError("invalid_cid") from None
                        scalars, method = None, "cidchar"
                    entry = CMapMapping(
                        source,
                        scalars,
                        cid,
                        method,
                        len(mappings),
                        canonical_sha256(
                            {
                                "cmap": cmap_identity,
                                "source": source.hex().upper(),
                                "destination": destination.decode("latin-1"),
                                "method": method,
                                "ordinal": len(mappings),
                            }
                        ),
                    )
                    mappings.append(entry)
                    mapping_by_source.setdefault(source, []).append(entry)
                end_token = b"endbfchar" if token == b"beginbfchar" else b"endcidchar"
            else:
                if (
                    count + len(mappings)
                    > policy.max_bfrange_entries + policy.max_range_expansion
                ):
                    raise CMapError("mapping_entry_bound_exceeded")
                expansion = 0
                for _ in range(count):
                    if cursor + 2 >= len(tokens):
                        raise CMapError("missing_range_end")
                    lower, upper = _hex(tokens[cursor]), _hex(tokens[cursor + 1])
                    destination = tokens[cursor + 2]
                    cursor += 3
                    if (
                        len(lower) != len(upper)
                        or not lower
                        or int.from_bytes(lower, "big") > int.from_bytes(upper, "big")
                    ):
                        raise CMapError("invalid_mapping_range")
                    range_size = (
                        int.from_bytes(upper, "big") - int.from_bytes(lower, "big") + 1
                    )
                    expansion += range_size
                    if expansion > policy.max_range_expansion:
                        raise CMapError("range_expansion_bound_exceeded")
                    destinations: list[bytes | int]
                    if destination == b"[":
                        destinations = []
                        while cursor < len(tokens) and tokens[cursor] != b"]":
                            destinations.append(_hex(tokens[cursor]))
                            cursor += 1
                        if cursor >= len(tokens):
                            raise CMapError("unclosed_bfrange_array")
                        cursor += 1
                        if len(destinations) != range_size:
                            raise CMapError("bfrange_array_length_mismatch")
                    elif token == b"begincidrange":
                        try:
                            destinations = [
                                int(destination) + offset
                                for offset in range(range_size)
                            ]
                        except ValueError:
                            raise CMapError("invalid_cidrange_destination") from None
                    else:
                        base = _hex(destination)
                        destinations = [base for _ in range(range_size)]
                    for offset in range(range_size):
                        source = (int.from_bytes(lower, "big") + offset).to_bytes(
                            len(lower), "big"
                        )
                        if token == b"beginbfrange":
                            scalars = (
                                _unicode_scalars(destinations[offset])  # type: ignore[arg-type]
                                if destination == b"["
                                else _increment_unicode(destinations[offset], offset)  # type: ignore[arg-type]
                            )
                            cid = None
                            method = (
                                "bfrange_array"
                                if destination == b"["
                                else "bfrange_scalar"
                            )
                        else:
                            scalars = None
                            cid = int(destinations[offset])
                            method = "cidrange"
                        entry = CMapMapping(
                            source,
                            scalars,
                            cid,
                            method,
                            len(mappings),
                            canonical_sha256(
                                {
                                    "cmap": cmap_identity,
                                    "source": source.hex().upper(),
                                    "output": scalars if scalars is not None else cid,
                                    "method": method,
                                    "ordinal": len(mappings),
                                }
                            ),
                        )
                        mappings.append(entry)
                        mapping_by_source.setdefault(source, []).append(entry)
                end_token = (
                    b"endbfrange" if token == b"beginbfrange" else b"endcidrange"
                )
            if cursor >= len(tokens) or tokens[cursor] != end_token:
                raise CMapError("missing_section_end_marker")
            index = cursor + 1
            continue
        index += 1
    ordered_ranges = tuple(
        sorted(
            codespaces,
            key=lambda item: (len(item.lower), item.lower, item.upper, item.ordinal),
        )
    )
    for left_index, left in enumerate(ordered_ranges):
        for right in ordered_ranges[left_index + 1 :]:
            if (
                len(left.lower) == len(right.lower)
                and int.from_bytes(left.lower, "big")
                <= int.from_bytes(right.upper, "big")
                and int.from_bytes(right.lower, "big")
                <= int.from_bytes(left.upper, "big")
            ):
                conflicts.append(
                    CMapConflict(
                        "overlapping_codespace",
                        left.lower.hex().upper(),
                        (left.identity, right.identity),
                    )
                )
    for source, items in sorted(mapping_by_source.items()):
        outputs = {(item.unicode_scalars, item.cid) for item in items}
        if len(items) > 1:
            conflicts.append(
                CMapConflict(
                    "duplicate_source_mapping"
                    if len(outputs) == 1
                    else "conflicting_source_mapping",
                    source.hex().upper(),
                    tuple(item.entry_identity for item in items),
                )
            )
    if conflicts:
        limitations.add("cmap_conflict")
    if not codespaces:
        limitations.add("codespace_unavailable")
    complete = not limitations and not conflicts
    return ParsedCMap(
        cmap_identity,
        kind,
        ordered_ranges,
        tuple(mappings),
        tuple(
            sorted(conflicts, key=lambda item: (item.conflict_type, item.source_hex))
        ),
        tuple(sorted(set(usecmap))),
        cmap_name,
        wmode,
        complete,
        tuple(sorted(limitations)),
    )


def segment_codes(
    data: bytes, codespaces: tuple[CMapCodeSpaceRange, ...], *, max_code_bytes: int = 8
) -> tuple[tuple[int, int, bytes], ...]:
    """Return unique end-exclusive byte segments or fail closed on ambiguity."""
    if not codespaces:
        raise CMapError("codespace_unavailable")
    result: list[tuple[int, int, bytes]] = []
    offset = 0
    while offset < len(data):
        candidates = []
        for item in codespaces:
            width = len(item.lower)
            if width > max_code_bytes or offset + width > len(data):
                continue
            value = data[offset : offset + width]
            if item.lower <= value <= item.upper:
                candidates.append(value)
        unique = sorted(set(candidates), key=lambda value: (len(value), value))
        if len(unique) != 1:
            raise CMapError(
                "ambiguous_code_segmentation"
                if unique
                else "incomplete_or_unmapped_code"
            )
        value = unique[0]
        result.append((offset, offset + len(value), value))
        offset += len(value)
    return tuple(result)

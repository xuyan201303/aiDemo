# ruff: noqa: BLE001, C416, C901, EM101, PLR0912, PLR0913, PLR0915, S110, TRY003
"""CTIF-3 default-OFF PDFium native character/text-object lineage."""

from __future__ import annotations

from ctypes import c_void_p, cast
from hashlib import sha256
from importlib.metadata import version
from typing import Any, Literal

import pypdfium2 as pdfium
import pypdfium2.raw as pdfium_raw
from pydantic import BaseModel, ConfigDict, Field

from document_sdk.pdf._xref_keyword_recovery import verified_parser_view

from .serialization import canonical_float, canonical_sha256

PDFIUM_LINEAGE_VERSION = "ctif_pdfium_lineage.v1"
PDFIUM_LINEAGE_POLICY = "ctif_pdfium_lineage.experimental.v1"


class _Frozen(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class PdfiumTextObjectEvidence(_Frozen):
    object_ordinal: int = Field(ge=0)
    text_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    unicode_scalar_count: int = Field(ge=0)
    matrix: tuple[str, str, str, str, str, str]
    bbox: tuple[str, str, str, str]
    font_name_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    font_size: str
    object_identity: str = Field(pattern=r"^[0-9a-f]{64}$")


class PdfiumCharacterEvidence(_Frozen):
    character_index: int = Field(ge=0)
    text_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    unicode_scalar_count: int = Field(ge=0)
    bbox: tuple[str, str, str, str] | None = None
    rotation_degrees: str | None = None
    parent_text_object_ordinal: int | None = Field(default=None, ge=0)
    parent_text_object_identity: str | None = Field(
        default=None, pattern=r"^[0-9a-f]{64}$"
    )
    character_role: Literal["native_text", "parser_inserted_separator", "unbound"]
    limitation_codes: tuple[str, ...] = ()
    character_identity: str = Field(pattern=r"^[0-9a-f]{64}$")


class PdfiumSubspanEvidence(_Frozen):
    parent_text_object_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    start_character_index: int = Field(ge=0)
    end_character_index_exclusive: int = Field(gt=0)
    child_character_identities: tuple[str, ...]
    text_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    bbox_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    subspan_identity: str = Field(pattern=r"^[0-9a-f]{64}$")


class PdfiumFactLineageEvidence(_Frozen):
    fact_id: str = Field(min_length=1)
    page_id: str = Field(min_length=1)
    fact_kind: Literal["character", "derived_subspan"]
    character_start: int = Field(ge=0)
    character_end_exclusive: int = Field(gt=0)
    character_identities: tuple[str, ...]
    parent_text_object_identities: tuple[str, ...]
    proof_method: Literal[
        "exact_native_character_index", "deterministic_parent_subspan"
    ]
    completeness: Literal["proven"] = "proven"
    lineage_identity: str = Field(pattern=r"^[0-9a-f]{64}$")


class PdfiumLineageMetrics(_Frozen):
    text_object_count: int = Field(ge=0)
    character_count: int = Field(ge=0)
    parent_bound_character_count: int = Field(ge=0)
    parser_inserted_character_count: int = Field(ge=0)
    unbound_character_count: int = Field(ge=0)
    invalid_bbox_count: int = Field(ge=0)
    resource_limited: bool


class PdfiumLineageBundle(_Frozen):
    bundle_version: str = PDFIUM_LINEAGE_VERSION
    source_artifact_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    document_identity: str = Field(min_length=1)
    original_page_number: int = Field(gt=0)
    page_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    parser_identity: str
    parser_configuration_identity: str
    policy_identity: str = PDFIUM_LINEAGE_POLICY
    text_objects: tuple[PdfiumTextObjectEvidence, ...]
    characters: tuple[PdfiumCharacterEvidence, ...]
    limitation_codes: tuple[str, ...]
    completeness: Literal["complete", "partial", "unsafe"]
    metrics: PdfiumLineageMetrics
    bundle_digest: str = Field(pattern=r"^[0-9a-f]{64}$")


class PdfiumLineageResult(_Frozen):
    status: Literal["complete", "partial", "unsafe", "unavailable"]
    bundle: PdfiumLineageBundle | None
    limitation_codes: tuple[str, ...]


def _empty(code: str) -> PdfiumLineageResult:
    return PdfiumLineageResult(
        status="unavailable", bundle=None, limitation_codes=(code,)
    )


def _box(value: Any) -> tuple[str, str, str, str]:
    return tuple(canonical_float(item) for item in value)  # type: ignore[return-value]


def _matrix(value: Any) -> tuple[str, str, str, str, str, str]:
    return tuple(canonical_float(item) for item in value.get())  # type: ignore[return-value]


def _handle(value: Any) -> int | None:
    # PDFium returns a fresh ctypes pointer wrapper for the same native text
    # object.  The address is used only inside this isolated invocation to join
    # characters to the enumerated object; it is never serialized or hashed.
    try:
        return cast(value.raw, c_void_p).value
    except Exception:
        return None


def _build_pdfium_lineage_unisolated(
    *,
    source_bytes: bytes,
    expected_source_sha256: str,
    document_identity: str,
    original_page_number: int,
    page_identity: str,
    parser_configuration_identity: str = "pdfium-native-lineage.default.v1",
    max_text_objects: int = 20000,
    max_characters: int = 200000,
) -> PdfiumLineageResult:
    actual = sha256(source_bytes).hexdigest()
    if actual != expected_source_sha256:
        return _empty("source_identity_mismatch")
    document = page = textpage = None
    try:
        document = pdfium.PdfDocument(verified_parser_view(source_bytes))
        page = document[original_page_number - 1]
        textpage = page.get_textpage()
        native_objects = [
            item
            for item in page.get_objects(
                filter=[pdfium_raw.FPDF_PAGEOBJ_TEXT], textpage=textpage
            )
        ]
        limited_objects = native_objects[:max_text_objects]
        limitations = set()
        if len(native_objects) > max_text_objects:
            limitations.add("pdfium_text_object_bound_exceeded")
        object_models = []
        by_handle = {}
        for ordinal, item in enumerate(limited_objects):
            try:
                text = item.extract()  # pyright: ignore[reportAttributeAccessIssue]
            except Exception:
                text = ""
                limitations.add("pdfium_text_object_text_unavailable")
            try:
                font = item.get_font()  # pyright: ignore[reportAttributeAccessIssue]
                try:
                    font_name = str(font.get_base_name())
                finally:
                    font.close()
            except Exception:
                font_name = ""
                limitations.add("pdfium_font_identity_unavailable")
            values = {
                "object_ordinal": ordinal,
                "text_digest": sha256(text.encode()).hexdigest(),
                "unicode_scalar_count": len(text),
                "matrix": _matrix(item.get_matrix()),
                "bbox": _box(item.get_bounds()),
                "font_name_digest": sha256(font_name.encode()).hexdigest(),
                "font_size": canonical_float(item.get_font_size()),  # pyright: ignore[reportAttributeAccessIssue]
            }
            model = PdfiumTextObjectEvidence(
                **values,  # type: ignore[arg-type]
                object_identity=canonical_sha256(
                    {
                        "version": PDFIUM_LINEAGE_VERSION,
                        "source": actual,
                        "document": document_identity,
                        "page": original_page_number,
                        "page_identity": page_identity,
                        **values,
                    }
                ),
            )
            object_models.append(model)
            handle = _handle(item)
            if handle is not None:
                by_handle[handle] = model
        count = textpage.count_chars()
        limited_count = min(count, max_characters)
        if count > max_characters:
            limitations.add("pdfium_character_bound_exceeded")
        character_models = []
        invalid = 0
        for index in range(limited_count):
            text = textpage.get_text_range(index, 1)
            bbox = None
            rotation = None
            parent = None
            char_limits = []
            try:
                bbox = _box(textpage.get_charbox(index))
            except Exception:
                invalid += 1
                char_limits.append("pdfium_character_bbox_unavailable")
            try:
                rotation = canonical_float(
                    float(pdfium_raw.FPDFText_GetCharAngle(textpage.raw, index))
                    * 180
                    / 3.141592653589793
                )
            except Exception:
                char_limits.append("pdfium_character_rotation_unavailable")
            try:
                parent = by_handle.get(_handle(textpage.get_textobj(index)))  # type: ignore[arg-type]
            except Exception:
                parent = None
            role = (
                "native_text"
                if parent is not None
                else "parser_inserted_separator"
                if text and text.isspace()
                else "unbound"
            )
            if role == "unbound":
                char_limits.append("pdfium_parent_text_object_unavailable")
            values = {
                "character_index": index,
                "text_digest": sha256(text.encode()).hexdigest(),
                "unicode_scalar_count": len(text),
                "bbox": bbox,
                "rotation_degrees": rotation,
                "parent_text_object_ordinal": parent.object_ordinal if parent else None,
                "parent_text_object_identity": parent.object_identity
                if parent
                else None,
                "character_role": role,
                "limitation_codes": tuple(sorted(char_limits)),
            }
            character_models.append(
                PdfiumCharacterEvidence(
                    **values,  # type: ignore[arg-type]
                    character_identity=canonical_sha256(
                        {
                            "version": PDFIUM_LINEAGE_VERSION,
                            "source": actual,
                            "document": document_identity,
                            "page": original_page_number,
                            "page_identity": page_identity,
                            **values,
                        }
                    ),
                )
            )
        for item in character_models:
            limitations.update(item.limitation_codes)
        resource = any(value.endswith("bound_exceeded") for value in limitations)
        completeness = "partial" if limitations else "complete"
        metrics = PdfiumLineageMetrics(
            text_object_count=len(object_models),
            character_count=len(character_models),
            parent_bound_character_count=sum(
                item.parent_text_object_identity is not None
                for item in character_models
            ),
            parser_inserted_character_count=sum(
                item.character_role == "parser_inserted_separator"
                for item in character_models
            ),
            unbound_character_count=sum(
                item.character_role == "unbound" for item in character_models
            ),
            invalid_bbox_count=invalid,
            resource_limited=resource,
        )
        values = {
            "source_artifact_sha256": actual,
            "document_identity": document_identity,
            "original_page_number": original_page_number,
            "page_identity": page_identity,
            "parser_identity": f"pypdfium2:{version('pypdfium2')}",
            "parser_configuration_identity": parser_configuration_identity,
            "text_objects": tuple(object_models),
            "characters": tuple(character_models),
            "limitation_codes": tuple(sorted(limitations)),
            "completeness": completeness,
            "metrics": metrics,
        }
        provisional = PdfiumLineageBundle.model_construct(
            **values,  # type: ignore[arg-type]
            bundle_version=PDFIUM_LINEAGE_VERSION,
            policy_identity=PDFIUM_LINEAGE_POLICY,
            bundle_digest="0" * 64,
        )
        bundle = PdfiumLineageBundle(
            **values,  # type: ignore[arg-type]
            bundle_digest=canonical_sha256(provisional.model_dump(mode="json")),
        )
        return PdfiumLineageResult(
            status=completeness,  # type: ignore[arg-type]
            bundle=bundle,
            limitation_codes=bundle.limitation_codes,
        )
    except Exception:
        return _empty("pdfium_native_lineage_unavailable")
    finally:
        for item in (textpage, page, document):
            try:
                if item is not None:
                    item.close()
            except Exception:
                pass


def build_pdfium_lineage(
    *,
    source_bytes: bytes,
    expected_source_sha256: str,
    document_identity: str,
    original_page_number: int,
    page_identity: str,
    parser_configuration_identity: str = "pdfium-native-lineage.default.v1",
) -> PdfiumLineageResult:
    from .runtime_adapter import run_pdfium_lineage

    outcome = run_pdfium_lineage(
        source_bytes=source_bytes,
        expected_source_sha256=expected_source_sha256,
        document_identity=document_identity,
        original_page_number=original_page_number,
        page_identity=page_identity,
        parser_configuration_identity=parser_configuration_identity,
    )
    if outcome.outcome == "completed" and isinstance(
        outcome.value, PdfiumLineageResult
    ):
        return outcome.value
    return _empty(outcome.limitation_code or "ctif_runtime_worker_failed")


def derive_pdfium_subspan(
    bundle: PdfiumLineageBundle,
    *,
    parent_text_object_identity: str,
    start_character_index: int,
    end_character_index_exclusive: int,
) -> PdfiumSubspanEvidence:
    chars = tuple(
        item
        for item in bundle.characters
        if start_character_index <= item.character_index < end_character_index_exclusive
        and item.parent_text_object_identity == parent_text_object_identity
    )
    if (
        not chars
        or chars[0].character_index != start_character_index
        or chars[-1].character_index + 1 != end_character_index_exclusive
    ):
        raise ValueError("subspan must be contiguous and parent-bound")
    values = {
        "parent_text_object_identity": parent_text_object_identity,
        "start_character_index": start_character_index,
        "end_character_index_exclusive": end_character_index_exclusive,
        "child_character_identities": tuple(item.character_identity for item in chars),
        "text_digest": canonical_sha256([item.text_digest for item in chars]),
        "bbox_digest": canonical_sha256([item.bbox for item in chars]),
    }
    return PdfiumSubspanEvidence(
        **values,  # type: ignore[arg-type]
        subspan_identity=canonical_sha256(
            {
                "version": PDFIUM_LINEAGE_VERSION,
                "source": bundle.source_artifact_sha256,
                "document": bundle.document_identity,
                "page": bundle.original_page_number,
                "page_identity": bundle.page_identity,
                **values,
            }
        ),
    )


def bind_pdfium_character_fact(
    bundle: PdfiumLineageBundle,
    *,
    fact_id: str,
    page_id: str,
    character_index: int,
    text_digest: str,
) -> PdfiumFactLineageEvidence:
    matches = [
        item for item in bundle.characters if item.character_index == character_index
    ]
    if len(matches) != 1 or matches[0].text_digest != text_digest:
        raise ValueError(
            "character fact does not match exact PDFium native index evidence"
        )
    character = matches[0]
    if (
        character.character_role != "native_text"
        or character.parent_text_object_identity is None
    ):
        raise ValueError(
            "parser-inserted or unbound character cannot prove a native Fact"
        )
    values = {
        "fact_id": fact_id,
        "page_id": page_id,
        "fact_kind": "character",
        "character_start": character_index,
        "character_end_exclusive": character_index + 1,
        "character_identities": (character.character_identity,),
        "parent_text_object_identities": (character.parent_text_object_identity,),
        "proof_method": "exact_native_character_index",
    }
    return PdfiumFactLineageEvidence(
        **values,  # type: ignore[arg-type]
        lineage_identity=canonical_sha256(
            {
                "version": PDFIUM_LINEAGE_VERSION,
                "source": bundle.source_artifact_sha256,
                "document": bundle.document_identity,
                "page": bundle.original_page_number,
                "page_identity": bundle.page_identity,
                "parser": bundle.parser_identity,
                "configuration": bundle.parser_configuration_identity,
                **values,
            }
        ),
    )

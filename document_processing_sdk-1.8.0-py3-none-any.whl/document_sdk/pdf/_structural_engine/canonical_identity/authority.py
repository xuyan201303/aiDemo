# ruff: noqa: BLE001, PLR0913, PLR2004
"""Public bounded CTIF-1 raw authority API."""

from __future__ import annotations

import resource
from hashlib import sha256
from time import perf_counter
from typing import Final

from pypdf.generic import ArrayObject

from .contracts import (
    CanonicalAuthorityMode,
    CanonicalEvidenceBundle,
    CanonicalTextAuthorityIdentity,
    ResourcePolicy,
)
from .evidence import RawAuthorityMetrics, RawAuthorityResult
from .raw_pdf import Traversal, traverse_streams
from .safe_reader import CtifEncryptedSourceUnsupported, open_ctif_pdf_reader
from .serialization import canonical_json_bytes, canonical_sha256

CTIF1_AUTHORITY_VERSION = "ctif_raw_pdf_authority.v1"
CTIF1_DECODING_POLICY = "ctif_raw_decoding.experimental.v1"
CTIF1_NORMALIZATION_POLICY = "ctif_raw_operation_order.v1"
CTIF1_RESOURCE_POLICY = "ctif1_sentinel_resource_policy.experimental.v1"
_CTIF_RAW_AUTHORITY_GENERATOR_IDENTITY: Final = (
    "document_sdk.pdf.ctif.raw_pdf_authority"
)


def _peak_rss_bytes() -> int | None:
    try:
        value = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        return value if value > 10_000_000 else value * 1024
    except Exception:
        return None


def _empty_metrics(
    *, limitation_count: int = 1, elapsed_ms: float = 0
) -> RawAuthorityMetrics:
    return RawAuthorityMetrics(
        content_stream_count=0,
        form_xobject_count=0,
        max_recursion_depth=0,
        operation_count=0,
        text_show_operation_count=0,
        font_count=0,
        glyph_or_code_count=0,
        decoded_code_point_count=0,
        unmapped_count=0,
        lossy_count=0,
        malformed_count=0,
        canonical_character_count=0,
        mapping_segment_count=0,
        limitation_count=limitation_count,
        elapsed_ms=elapsed_ms,
        serialized_bundle_bytes=0,
    )


def _build_raw_canonical_authority_unisolated(
    *,
    source_bytes: bytes,
    original_page_number: int,
    expected_source_sha256: str,
    document_identity: str,
    page_identity: str,
    source_snapshot_identity: str,
    extraction_configuration_identity: str,
    policy: ResourcePolicy | None = None,
) -> RawAuthorityResult:
    started = perf_counter()
    policy = policy or ResourcePolicy()
    actual_sha = sha256(source_bytes).hexdigest()
    empty_metrics = _empty_metrics()
    if actual_sha != expected_source_sha256:
        return RawAuthorityResult(
            status="unavailable",
            bundle=None,
            limitations=("source_sha_mismatch",),
            metrics=empty_metrics,
        )
    try:
        reader, empty_password_decryption = open_ctif_pdf_reader(source_bytes)
    except CtifEncryptedSourceUnsupported:
        return RawAuthorityResult(
            status="unavailable",
            bundle=None,
            limitations=("encrypted_source_unsupported",),
            metrics=empty_metrics,
        )
    except Exception:
        return RawAuthorityResult(
            status="unavailable",
            bundle=None,
            limitations=("malformed_pdf",),
            metrics=empty_metrics,
        )
    if original_page_number <= 0 or original_page_number > len(reader.pages):
        return RawAuthorityResult(
            status="unavailable",
            bundle=None,
            limitations=("page_out_of_range",),
            metrics=empty_metrics,
        )
    page = reader.pages[original_page_number - 1]
    contents = page.get("/Contents")
    resources = page.get("/Resources") or {}
    streams = (
        list(contents)
        if isinstance(contents, ArrayObject)
        else [contents]
        if contents is not None
        else []
    )
    traversal = Traversal(policy=policy)
    if empty_password_decryption:
        traversal.limitations.add("empty_password_decryption_applied")
    if not streams:
        traversal.limitations.add("missing_or_empty_contents")
    else:
        traverse_streams(
            reader=reader, streams=streams, resources=resources, traversal=traversal
        )
    canonical_text = "".join(traversal.canonical_chars)
    stream_digest = sha256(canonical_text.encode("utf-8")).hexdigest()
    identity = CanonicalTextAuthorityIdentity(
        authority_version=CTIF1_AUTHORITY_VERSION,
        source_artifact_sha256=actual_sha,
        document_identity=document_identity,
        original_page_number=original_page_number,
        page_identity=page_identity,
        source_snapshot_identity=source_snapshot_identity,
        generation_mode=CanonicalAuthorityMode.VALIDATION_ONLY,
        generator_identity=_CTIF_RAW_AUTHORITY_GENERATOR_IDENTITY,
        extraction_configuration_identity=extraction_configuration_identity,
        resource_policy_identity=CTIF1_RESOURCE_POLICY,
        normalization_policy_identity=CTIF1_NORMALIZATION_POLICY,
        decoding_policy_identity=CTIF1_DECODING_POLICY,
        created_from_source_identity=actual_sha,
    )
    limitations = tuple(sorted(traversal.limitations))
    completeness = (
        "partial" if limitations or traversal.resource_exceeded else "complete"
    )
    bundle_payload = {
        "authority": identity.model_dump(mode="json"),
        "paths": [x.model_dump(mode="json") for x in traversal.content_paths],
        "glyphs": [x.model_dump(mode="json") for x in traversal.glyphs],
        "stream": stream_digest,
        "limitations": limitations,
        "policy": policy.model_dump(mode="json"),
        "completeness": completeness,
    }
    bundle_digest = canonical_sha256(bundle_payload)
    bundle = CanonicalEvidenceBundle(
        authority_identity=identity,
        content_paths=tuple(traversal.content_paths),
        glyph_evidence=tuple(traversal.glyphs),
        canonical_stream_digest=stream_digest,
        limitation_codes=limitations,
        resource_policy=policy,
        generation_completeness=completeness,  # type: ignore[arg-type]
        bundle_digest=bundle_digest,
    )
    serialized = len(canonical_json_bytes(bundle.model_dump(mode="json")))
    if serialized > policy.max_serialized_bundle_bytes:
        limitations = tuple(
            sorted(set(limitations) | {"serialized_bundle_bound_exceeded"})
        )
        completeness = "partial"
        bundle_payload["limitations"] = limitations
        bundle_payload["completeness"] = completeness
        bundle_digest = canonical_sha256(bundle_payload)
        bundle = bundle.model_copy(
            update={
                "limitation_codes": limitations,
                "generation_completeness": "partial",
                "bundle_digest": bundle_digest,
            }
        )
        traversal.resource_exceeded = True
    elapsed = (perf_counter() - started) * 1000
    if elapsed > policy.max_page_elapsed_ms:
        limitations = tuple(sorted(set(limitations) | {"page_elapsed_bound_exceeded"}))
        traversal.resource_exceeded = True
        bundle_payload["limitations"] = limitations
        bundle_payload["completeness"] = "partial"
        bundle = bundle.model_copy(
            update={
                "limitation_codes": limitations,
                "generation_completeness": "partial",
                "bundle_digest": canonical_sha256(bundle_payload),
            }
        )
    metrics = RawAuthorityMetrics(
        content_stream_count=len(streams),
        form_xobject_count=traversal.form_count,
        max_recursion_depth=traversal.max_depth,
        operation_count=traversal.operation_count,
        text_show_operation_count=traversal.text_show_count,
        font_count=len(traversal.fonts),
        glyph_or_code_count=traversal.glyph_count,
        decoded_code_point_count=len(canonical_text),
        unmapped_count=traversal.unmapped_count,
        lossy_count=traversal.lossy_count,
        malformed_count=traversal.malformed_count,
        canonical_character_count=len(canonical_text),
        mapping_segment_count=len(traversal.mappings),
        limitation_count=len(limitations),
        elapsed_ms=elapsed,
        peak_rss_bytes=_peak_rss_bytes(),
        serialized_bundle_bytes=serialized,
    )
    status = "resource_bound_exceeded" if traversal.resource_exceeded else completeness
    return RawAuthorityResult(
        status=status,  # type: ignore[arg-type]
        bundle=bundle,
        operations=tuple(traversal.operations),
        fonts=tuple(sorted(traversal.fonts.values(), key=lambda x: x.resource_name)),
        mappings=tuple(traversal.mappings),
        limitations=limitations,
        metrics=metrics,
    )


def build_raw_canonical_authority(
    *,
    source_bytes: bytes,
    original_page_number: int,
    expected_source_sha256: str,
    document_identity: str,
    page_identity: str,
    source_snapshot_identity: str,
    extraction_configuration_identity: str,
    policy: ResourcePolicy | None = None,
) -> RawAuthorityResult:
    """Build evidence in an isolated process with preventive resource limits."""
    from .runtime_adapter import run_raw_authority

    policy = policy or ResourcePolicy()
    outcome = run_raw_authority(
        source_bytes=source_bytes,
        original_page_number=original_page_number,
        expected_source_sha256=expected_source_sha256,
        document_identity=document_identity,
        page_identity=page_identity,
        source_snapshot_identity=source_snapshot_identity,
        extraction_configuration_identity=extraction_configuration_identity,
        resource_policy=policy,
    )
    if outcome.outcome == "completed" and isinstance(outcome.value, RawAuthorityResult):
        return outcome.value
    limitation = outcome.limitation_code or "ctif_runtime_worker_failed"
    return RawAuthorityResult(
        status="unavailable",
        bundle=None,
        limitations=(limitation,),
        metrics=_empty_metrics(elapsed_ms=outcome.elapsed_milliseconds),
    )


def build_raw_canonical_authority_bundle(
    *,
    source_bytes: bytes,
    original_page_number: int,
    expected_source_sha256: str,
    document_identity: str,
    page_identity: str,
    source_snapshot_identity: str,
    extraction_configuration_identity: str,
    policy: ResourcePolicy | None = None,
) -> CanonicalEvidenceBundle | None:
    """Return the exact sealed CTIF bundle without transporting raw operations."""
    from .runtime_adapter import run_raw_authority

    policy = policy or ResourcePolicy()
    outcome = run_raw_authority(
        source_bytes=source_bytes,
        original_page_number=original_page_number,
        expected_source_sha256=expected_source_sha256,
        document_identity=document_identity,
        page_identity=page_identity,
        source_snapshot_identity=source_snapshot_identity,
        extraction_configuration_identity=extraction_configuration_identity,
        resource_policy=policy,
    )
    value = outcome.value
    return (
        value.bundle
        if outcome.outcome == "completed" and isinstance(value, RawAuthorityResult)
        else None
    )

# ruff: noqa: EM101, I001, TC001, TRY003

"""CTIF-1 raw-authority evidence models without Product integration."""

from __future__ import annotations
from typing import Literal, Self
from pydantic import BaseModel, ConfigDict, Field, model_validator
from .contracts import CanonicalEvidenceBundle


class _Frozen(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class RawOperationEvidence(_Frozen):
    global_ordinal: int = Field(ge=0)
    local_ordinal: int = Field(ge=0)
    operator: str = Field(min_length=1, max_length=8)
    operand_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    content_path_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    graphics_state_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    text_state_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    malformed: bool = False
    unsupported: bool = False


class FontEvidence(_Frozen):
    resource_name: str = Field(min_length=1, max_length=128)
    object_identity: str | None = Field(default=None, max_length=128)
    subtype: str | None = Field(default=None, max_length=64)
    base_font: str | None = Field(default=None, max_length=256)
    encoding_identity: str | None = Field(default=None, max_length=256)
    to_unicode_identity: str | None = Field(default=None, max_length=128)
    descendant_font_identity: str | None = Field(default=None, max_length=128)
    writing_mode: Literal["horizontal", "vertical", "unknown"] = "unknown"
    malformed: bool = False
    unsupported: bool = False
    evidence_digest: str = Field(pattern=r"^[0-9a-f]{64}$")


class NativeCanonicalMappingSegment(_Frozen):
    native_start: int = Field(ge=0)
    native_end_exclusive: int = Field(ge=0)
    canonical_start: int = Field(ge=0)
    canonical_end_exclusive: int = Field(ge=0)
    transformation: Literal[
        "identity",
        "multibyte_decode",
        "one_glyph_to_multi_codepoint",
        "multi_glyph_to_one_sequence",
        "actualtext_substitution",
        "normalized_line_break",
        "inserted_separator",
        "excluded_control",
        "unmapped_code",
        "lossy_replacement",
        "unsupported_font",
        "malformed_operand",
    ]
    reversible: bool
    lossy: bool
    unmapped: bool
    inserted: bool = False
    excluded: bool = False
    source_operation_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    font_identity: str | None = Field(default=None, max_length=128)
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_ranges(self) -> Self:
        if (
            self.native_end_exclusive < self.native_start
            or self.canonical_end_exclusive < self.canonical_start
        ):
            raise ValueError("mapping ranges must be ordered")
        if self.lossy and self.reversible:
            raise ValueError("lossy mapping cannot be reversible")
        return self


class RawAuthorityMetrics(_Frozen):
    content_stream_count: int = Field(ge=0)
    form_xobject_count: int = Field(ge=0)
    max_recursion_depth: int = Field(ge=0)
    operation_count: int = Field(ge=0)
    text_show_operation_count: int = Field(ge=0)
    font_count: int = Field(ge=0)
    glyph_or_code_count: int = Field(ge=0)
    decoded_code_point_count: int = Field(ge=0)
    unmapped_count: int = Field(ge=0)
    lossy_count: int = Field(ge=0)
    malformed_count: int = Field(ge=0)
    canonical_character_count: int = Field(ge=0)
    mapping_segment_count: int = Field(ge=0)
    limitation_count: int = Field(ge=0)
    elapsed_ms: float = Field(ge=0)
    peak_rss_bytes: int | None = Field(default=None, ge=0)
    serialized_bundle_bytes: int = Field(ge=0)


class RawAuthorityResult(_Frozen):
    status: Literal["complete", "partial", "unavailable", "resource_bound_exceeded"]
    bundle: CanonicalEvidenceBundle | None
    operations: tuple[RawOperationEvidence, ...] = ()
    fonts: tuple[FontEvidence, ...] = ()
    mappings: tuple[NativeCanonicalMappingSegment, ...] = ()
    limitations: tuple[str, ...] = ()
    metrics: RawAuthorityMetrics

    @model_validator(mode="after")
    def validate_result(self) -> Self:
        if self.status == "unavailable" and self.bundle is not None:
            raise ValueError("unavailable authority cannot carry a bundle")
        if self.status != "unavailable" and self.bundle is None:
            raise ValueError("available authority result requires a bundle")
        if tuple(sorted(set(self.limitations))) != self.limitations:
            raise ValueError("limitations must be unique and sorted")
        return self

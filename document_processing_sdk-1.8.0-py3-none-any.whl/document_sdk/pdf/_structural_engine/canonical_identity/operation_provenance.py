# ruff: noqa: ANN202, BLE001, C408, C901, E731, E741, EM101, PLR0912, PLR0913, PLR0915, PLR0917, PLR2004, RUF005, TC001, TC002, TRY003, UP037
"""CTIF-1M deterministic PDF operation execution provenance.

The bundle is append-only and independent from the frozen CTIF v1/v2 bundles.
It records raw-operation order and state facts; it never claims reading order or
font-outline geometry.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from hashlib import sha256
from time import perf_counter
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator
from pypdf import PdfReader
from pypdf.generic import ArrayObject, ContentStream, DictionaryObject, NameObject

from .contracts import CanonicalContentPath
from .decoder import StrictDecoderResult
from .decoder_limits import EXPERIMENTAL_CTIF1B_DECODER_POLICY, DecoderResourcePolicy
from .evidence import RawAuthorityResult
from .raw_pdf import TEXT_SHOW, _safe_operand, object_identity
from .raw_string_lexer import RawLexerError, lex_content_stream
from .serialization import canonical_float, canonical_json_bytes, canonical_sha256

OPERATION_PROVENANCE_VERSION = "ctif_operation_provenance.v1m"
OPERATION_PROVENANCE_POLICY = "ctif_operation_execution.experimental.v1"
TEXT_LINEAGE_OPERATION_PROVENANCE_POLICY = (
    "ctif_operation_execution.text_lineage_only.v1"
)
_TEXT_LINEAGE_OPERATORS = frozenset(
    {
        b"q",
        b"Q",
        b"cm",
        b"BT",
        b"ET",
        b"Tf",
        b"Tc",
        b"Tw",
        b"Tz",
        b"TL",
        b"Ts",
        b"Tr",
        b"Tm",
        b"Td",
        b"TD",
        b"T*",
        b"BMC",
        b"BDC",
        b"EMC",
        b"'",
        b'"',
        b"Tj",
        b"TJ",
        b"Do",
    }
)
Matrix = tuple[str, str, str, str, str, str]
IDENTITY_MATRIX: Matrix = (
    "1.000000000",
    "0.000000000",
    "0.000000000",
    "1.000000000",
    "0.000000000",
    "0.000000000",
)


class _Frozen(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class OperationByteSpan(_Frozen):
    decoded_stream_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    operator_start: int = Field(ge=0)
    operator_end_exclusive: int = Field(ge=0)
    operand_start: int = Field(ge=0)
    operand_end_exclusive: int = Field(ge=0)
    operand_component_spans: tuple[tuple[int, int], ...] = ()

    @model_validator(mode="after")
    def ordered(self):  # type: ignore[no-untyped-def]
        if (
            self.operator_end_exclusive < self.operator_start
            or self.operand_end_exclusive < self.operand_start
        ):
            raise ValueError("operation byte spans must be ordered")
        return self


class OperationStateEvidence(_Frozen):
    ctm: Matrix
    text_matrix: Matrix | None = None
    text_line_matrix: Matrix | None = None
    font_resource_name: str | None = Field(default=None, max_length=128)
    font_resource_identity: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    font_size: str | None = None
    character_spacing: str = "0.000000000"
    word_spacing: str = "0.000000000"
    horizontal_scaling: str = "100.000000000"
    leading: str = "0.000000000"
    rise: str = "0.000000000"
    rendering_mode: int = 0
    text_object_ordinal: int | None = Field(default=None, ge=0)
    marked_content_path: tuple[str, ...] = ()
    mcid_path: tuple[int | None, ...] = ()
    state_digest: str = Field(pattern=r"^[0-9a-f]{64}$")


class CanonicalOperationExecution(_Frozen):
    source_artifact_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    original_page_number: int = Field(gt=0)
    content_path: CanonicalContentPath
    invocation_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    global_ordinal: int = Field(ge=0)
    local_ordinal: int = Field(ge=0)
    operator: str = Field(min_length=1, max_length=16)
    operand_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    byte_span: OperationByteSpan
    state_before: OperationStateEvidence
    state_after: OperationStateEvidence
    effective_text_matrix: Matrix | None = None
    operation_origin: tuple[str, str] | None = None
    baseline_vector: tuple[str, str] | None = None
    tj_adjustments: tuple[str, ...] = ()
    text_show_segment_count: int = Field(default=0, ge=0)
    writing_direction: Literal["horizontal", "vertical", "unknown"] = "unknown"
    visibility: Literal["visible", "invisible", "clipping_only", "unknown"] = "unknown"
    limitation_codes: tuple[str, ...] = ()
    operation_identity: str = Field(pattern=r"^[0-9a-f]{64}$")


class CodeExecutionProvenance(_Frozen):
    decoder_code_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    operation_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    raw_code_start: int = Field(ge=0)
    raw_code_end_exclusive: int = Field(ge=0)
    deterministic_ordinal: int = Field(ge=0)
    canonical_unicode_evidence_identities: tuple[str, ...] = ()
    glyph_origin: tuple[str, str] | None = None
    glyph_advance: tuple[str, str] | None = None
    limitation_codes: tuple[str, ...] = ()
    provenance_identity: str = Field(pattern=r"^[0-9a-f]{64}$")


class FormInvocationEvidence(_Frozen):
    definition_identity: str
    invocation_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    parent_invocation_identity: str | None = Field(
        default=None, pattern=r"^[0-9a-f]{64}$"
    )
    resource_name: str
    invocation_ordinal: int = Field(ge=0)
    depth: int = Field(ge=0)
    inherited_resource_context: bool
    parent_ctm: Matrix
    form_matrix: Matrix
    effective_ctm: Matrix
    limitation_codes: tuple[str, ...] = ()


class OperationProvenanceMetrics(_Frozen):
    stream_count: int = Field(ge=0)
    operation_count: int = Field(ge=0)
    text_show_operation_count: int = Field(ge=0)
    form_invocation_count: int = Field(ge=0)
    code_unit_count: int = Field(ge=0)
    operation_span_count: int = Field(ge=0)
    operand_span_count: int = Field(ge=0)
    ctm_count: int = Field(ge=0)
    text_matrix_count: int = Field(ge=0)
    effective_matrix_count: int = Field(ge=0)
    font_binding_count: int = Field(ge=0)
    operation_origin_count: int = Field(ge=0)
    glyph_advance_count: int = Field(ge=0)
    mcid_operation_count: int = Field(ge=0)
    serialized_bytes: int = Field(ge=0)


class OperationProvenanceBundle(_Frozen):
    bundle_version: str = OPERATION_PROVENANCE_VERSION
    source_artifact_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    document_identity: str
    original_page_number: int = Field(gt=0)
    page_identity: str
    page_rotation_degrees: int
    media_box: tuple[str, str, str, str]
    crop_box: tuple[str, str, str, str]
    raw_authority_bundle_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    decoder_inventory_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    policy_identity: str = OPERATION_PROVENANCE_POLICY
    operations: tuple[CanonicalOperationExecution, ...]
    code_execution: tuple[CodeExecutionProvenance, ...]
    form_invocations: tuple[FormInvocationEvidence, ...]
    limitation_codes: tuple[str, ...]
    completeness: Literal["complete", "partial", "unsafe"]
    metrics: OperationProvenanceMetrics
    bundle_digest: str = Field(pattern=r"^[0-9a-f]{64}$")


class OperationProvenanceResult(_Frozen):
    status: Literal["complete", "partial", "unsafe", "unavailable"]
    bundle: OperationProvenanceBundle | None
    limitation_codes: tuple[str, ...]


def _d(value: Any) -> Decimal:
    return Decimal(canonical_float(value))


def _m(values: Any) -> Matrix:
    return tuple(canonical_float(item) for item in values)  # type: ignore[return-value]


def _mul(left: Matrix, right: Matrix) -> Matrix:
    a, b, c, d, e, f = map(Decimal, left)
    g, h, i, j, k, l = map(Decimal, right)
    return _m(
        (
            a * g + c * h,
            b * g + d * h,
            a * i + c * j,
            b * i + d * j,
            a * k + c * l + e,
            b * k + d * l + f,
        )
    )


def _translate(matrix: Matrix, tx: Any, ty: Any) -> Matrix:
    return _mul(matrix, _m((1, 0, 0, 1, tx, ty)))


def _point(matrix: Matrix, x: Any, y: Any) -> tuple[str, str]:
    a, b, c, d, e, f = map(Decimal, matrix)
    x, y = _d(x), _d(y)
    return canonical_float(a * x + c * y + e), canonical_float(b * x + d * y + f)


@dataclass
class _ExecutionState:
    ctm: Matrix = IDENTITY_MATRIX
    text_matrix: Matrix | None = None
    text_line_matrix: Matrix | None = None
    font_name: str | None = None
    font_identity: str | None = None
    font_size: str | None = None
    char_space: str = "0.000000000"
    word_space: str = "0.000000000"
    scale: str = "100.000000000"
    leading: str = "0.000000000"
    rise: str = "0.000000000"
    render_mode: int = 0
    text_object_ordinal: int | None = None
    marked: list[tuple[str, int | None]] = field(default_factory=list)

    def clone(self) -> "_ExecutionState":
        return _ExecutionState(
            self.ctm,
            self.text_matrix,
            self.text_line_matrix,
            self.font_name,
            self.font_identity,
            self.font_size,
            self.char_space,
            self.word_space,
            self.scale,
            self.leading,
            self.rise,
            self.render_mode,
            self.text_object_ordinal,
            list(self.marked),
        )


def _state_model(state: _ExecutionState) -> OperationStateEvidence:
    values = dict(
        ctm=state.ctm,
        text_matrix=state.text_matrix,
        text_line_matrix=state.text_line_matrix,
        font_resource_name=state.font_name,
        font_resource_identity=state.font_identity,
        font_size=state.font_size,
        character_spacing=state.char_space,
        word_spacing=state.word_space,
        horizontal_scaling=state.scale,
        leading=state.leading,
        rise=state.rise,
        rendering_mode=state.render_mode,
        text_object_ordinal=state.text_object_ordinal,
        marked_content_path=tuple(item[0] for item in state.marked),
        mcid_path=tuple(item[1] for item in state.marked),
    )
    return OperationStateEvidence(**values, state_digest=canonical_sha256(values))  # type: ignore[arg-type]


def _font_identity(resources: Any, name: str, source: str, page: int, path: str) -> str:
    try:
        raw = (resources or {}).get("/Font", {}).get(name)
        ref = object_identity(raw)
    except Exception:
        ref = None
    return canonical_sha256(
        {
            "source": source,
            "page": page,
            "path": path,
            "resource": name,
            "object": ref or "direct_or_unavailable",
        }
    )


@dataclass
class _Trace:
    source: str
    page: int
    raw: RawAuthorityResult
    decoded: StrictDecoderResult
    policy: DecoderResourcePolicy
    started: float
    operations: list[CanonicalOperationExecution] = field(default_factory=list)
    forms: list[FormInvocationEvidence] = field(default_factory=list)
    limitations: set[str] = field(default_factory=set)
    active_forms: set[str] = field(default_factory=set)
    global_ordinal: int = 0
    text_show_ordinal: int = 0
    text_object_counter: int = 0
    stream_count: int = 0
    text_lineage_only: bool = False


def _apply(
    state: _ExecutionState,
    op: bytes,
    operands: list[Any],
    resources: Any,
    path_id: str,
    stack: list[_ExecutionState],
    trace: _Trace,
) -> None:
    try:
        if op == b"q":
            stack.append(state.clone())
        elif op == b"Q":
            if stack:
                restored = stack.pop()
                state.__dict__.update(restored.__dict__)
            else:
                trace.limitations.add("unbalanced_graphics_restore")
        elif op == b"cm" and len(operands) >= 6:
            state.ctm = _mul(_m(operands[:6]), state.ctm)
        elif op == b"BT":
            state.text_matrix = IDENTITY_MATRIX
            state.text_line_matrix = IDENTITY_MATRIX
            state.text_object_ordinal = trace.text_object_counter
            trace.text_object_counter += 1
        elif op == b"ET":
            state.text_matrix = None
            state.text_line_matrix = None
            state.text_object_ordinal = None
        elif op == b"Tf" and len(operands) >= 2:
            state.font_name = str(operands[0])
            state.font_size = canonical_float(operands[1])
            state.font_identity = _font_identity(
                resources, state.font_name, trace.source, trace.page, path_id
            )
        elif op == b"Tc" and operands:
            state.char_space = canonical_float(operands[0])
        elif op == b"Tw" and operands:
            state.word_space = canonical_float(operands[0])
        elif op == b"Tz" and operands:
            state.scale = canonical_float(operands[0])
        elif op == b"TL" and operands:
            state.leading = canonical_float(operands[0])
        elif op == b"Ts" and operands:
            state.rise = canonical_float(operands[0])
        elif op == b"Tr" and operands:
            state.render_mode = int(operands[0])
        elif op == b"Tm":
            if len(operands) < 6:
                trace.limitations.add("invalid_operation_state_operand")
            else:
                state.text_matrix = _m(operands[:6])
                state.text_line_matrix = state.text_matrix
        elif op in {b"Td", b"TD"} and len(operands) >= 2:
            if state.text_line_matrix is None:
                trace.limitations.add("text_position_outside_text_object")
            else:
                if op == b"TD":
                    state.leading = canonical_float(-float(operands[1]))
                state.text_line_matrix = _translate(
                    state.text_line_matrix, operands[0], operands[1]
                )
                state.text_matrix = state.text_line_matrix
        elif op == b"T*":
            if state.text_line_matrix is None:
                trace.limitations.add("text_position_outside_text_object")
            else:
                state.text_line_matrix = _translate(
                    state.text_line_matrix, 0, -float(state.leading)
                )
                state.text_matrix = state.text_line_matrix
        elif op in {b"BMC", b"BDC"}:
            tag = str(operands[0]) if operands else "/unknown"
            mcid = None
            if op == b"BDC" and len(operands) > 1:
                prop = operands[1]
                if isinstance(prop, (NameObject, str)):
                    try:
                        prop = (resources or {}).get("/Properties", {}).get(str(prop))
                        prop = prop.get_object() if prop else None
                    except Exception:
                        prop = None
                if isinstance(prop, (DictionaryObject, dict)) and isinstance(
                    prop.get("/MCID"), int
                ):
                    mcid = int(prop["/MCID"])  # pyright: ignore[reportArgumentType]
            state.marked.append((tag, mcid))
        elif op == b"EMC":
            if state.marked:
                state.marked.pop()
            else:
                trace.limitations.add("unbalanced_marked_content_end")
        elif op in {b"'", b'"'}:
            if op == b'"' and len(operands) >= 3:
                state.word_space = canonical_float(operands[0])
                state.char_space = canonical_float(operands[1])
            if state.text_line_matrix is None:
                trace.limitations.add("text_position_outside_text_object")
            else:
                state.text_line_matrix = _translate(
                    state.text_line_matrix, 0, -float(state.leading)
                )
                state.text_matrix = state.text_line_matrix
            trace.limitations.add("glyph_advance_requires_font_metrics")
        elif op in {b"Tj", b"TJ"}:
            trace.limitations.add("glyph_advance_requires_font_metrics")
    except (ValueError, TypeError, ArithmeticError):
        trace.limitations.add("invalid_operation_state_operand")


def _trace_streams(
    *,
    reader: PdfReader,
    streams: list[Any],
    resources: Any,
    trace: _Trace,
    state: _ExecutionState,
    form_path: tuple[str, ...] = (),
    depth: int = 0,
    parent_invocation: str | None = None,
    root_stream_ordinal: int = 0,
) -> None:
    if depth > 16:
        trace.limitations.add("form_recursion_bound_exceeded")
        return
    stack: list[_ExecutionState] = []
    for stream_index, stream_ref in enumerate(streams):
        trace.stream_count += 1
        try:
            content = ContentStream(stream_ref, reader)
            data = content.get_data()
            lexed = lex_content_stream(data, policy=trace.policy)
        except (Exception, RawLexerError):
            trace.limitations.add("operation_stream_unavailable")
            continue
        if len(lexed.operations) != len(content.operations):
            trace.limitations.add("operation_correlation_ambiguous")
            continue
        previous_end = 0
        stream_sha = sha256(data).hexdigest()
        for local, ((operands, operator), rawlex) in enumerate(
            zip(content.operations, lexed.operations, strict=True)
        ):
            if (
                trace.global_ordinal
                >= trace.raw.bundle.resource_policy.max_operations_per_page  # type: ignore[union-attr]
            ):
                trace.limitations.add("operation_provenance_bound_exceeded")
                return
            op = bytes(operator)
            path = CanonicalContentPath(
                content_stream_object_identity=object_identity(stream_ref),
                content_stream_ordinal=root_stream_ordinal + stream_index,
                form_xobject_path=form_path,
                recursion_depth=depth,
                text_show_operation_ordinal=trace.text_show_ordinal
                if op in TEXT_SHOW
                else None,
                availability="available" if op in TEXT_SHOW else "unknown",
            )
            path_id = canonical_sha256(path.model_dump(mode="json"))
            operand_digest = canonical_sha256(_safe_operand(list(operands)))
            invocation = parent_invocation or canonical_sha256(
                {"source": trace.source, "page": trace.page, "root": stream_index}
            )
            operand_start = previous_end
            while (
                operand_start < rawlex.operator_start
                and data[operand_start] in b"\x00\x09\x0a\x0c\x0d\x20"
            ):
                operand_start += 1
            span = OperationByteSpan(
                decoded_stream_sha256=stream_sha,
                operator_start=rawlex.operator_start,
                operator_end_exclusive=rawlex.operator_end_exclusive,
                operand_start=operand_start,
                operand_end_exclusive=rawlex.operator_start,
                operand_component_spans=tuple(
                    (item.raw_stream_start, item.raw_stream_end_exclusive)
                    for item in rawlex.string_tokens
                ),
            )
            retained = not trace.text_lineage_only or op in _TEXT_LINEAGE_OPERATORS
            before = _state_model(state) if retained else None
            effective = (
                _mul(state.text_matrix, state.ctm)
                if retained and state.text_matrix
                else None
            )
            origin = _point(effective, 0, float(state.rise)) if effective else None
            baseline = None
            if effective and origin:
                p1 = _point(effective, 1, float(state.rise))
                baseline = (
                    canonical_float(Decimal(p1[0]) - Decimal(origin[0])),
                    canonical_float(Decimal(p1[1]) - Decimal(origin[1])),
                )
            limits = []
            if op in TEXT_SHOW:
                if state.text_matrix is None:
                    limits.append("text_show_outside_text_object")
                if state.font_identity is None:
                    limits.append("font_binding_unavailable")
                limits.extend(
                    (
                        "glyph_advance_requires_font_metrics",
                        "glyph_envelope_unavailable",
                    )
                )
            identity = (
                canonical_sha256(
                    {
                        "version": OPERATION_PROVENANCE_VERSION,
                        "source": trace.source,
                        "page": trace.page,
                        "path": path_id,
                        "invocation": invocation,
                        "global": trace.global_ordinal,
                        "local": local,
                        "operator": rawlex.operator,
                        "span": span.model_dump(mode="json"),
                        "operand": operand_digest,
                        "state": before.state_digest,
                    }
                )
                if before is not None
                else None
            )
            _apply(state, op, list(operands), resources, path_id, stack, trace)
            after = _state_model(state) if retained else None
            target = operands[0] if operands else None
            adjustments = (
                tuple(
                    canonical_float(item)
                    for item in target
                    if isinstance(item, (int, float))
                )
                if op == b"TJ" and isinstance(target, (list, ArrayObject))
                else ()
            )
            visibility = (
                "invisible"
                if before is not None and before.rendering_mode == 3
                else "clipping_only"
                if before is not None and before.rendering_mode == 7
                else "visible"
                if op in TEXT_SHOW
                else "unknown"
            )
            if (
                retained
                and before is not None
                and after is not None
                and identity is not None
            ):
                trace.operations.append(
                    CanonicalOperationExecution(
                        source_artifact_sha256=trace.source,
                        original_page_number=trace.page,
                        content_path=path,
                        invocation_identity=invocation,
                        global_ordinal=trace.global_ordinal,
                        local_ordinal=local,
                        operator=rawlex.operator,
                        operand_digest=operand_digest,
                        byte_span=span,
                        state_before=before,
                        state_after=after,
                        effective_text_matrix=effective,
                        operation_origin=origin,
                        baseline_vector=baseline,
                        tj_adjustments=adjustments,
                        text_show_segment_count=len(rawlex.string_tokens),
                        writing_direction="unknown",
                        visibility=visibility,  # type: ignore[arg-type]
                        limitation_codes=tuple(sorted(set(limits))),
                        operation_identity=identity,
                    )
                )
            trace.global_ordinal += 1
            previous_end = rawlex.operator_end_exclusive
            if op in TEXT_SHOW:
                trace.text_show_ordinal += 1
            if op == b"Do" and operands:
                name = str(operands[0])
                try:
                    xref = (resources or {}).get("/XObject", {}).get(name)
                    xobj = xref.get_object() if xref else None
                except Exception:
                    xref = xobj = None
                if xobj is None or str(xobj.get("/Subtype") or "") != "/Form":
                    continue
                definition = object_identity(xref) or canonical_sha256(
                    {"direct_form": name, "path": path_id}
                )
                invocation_id = canonical_sha256(
                    {
                        "parent": invocation,
                        "operation": identity,
                        "definition": definition,
                        "ordinal": len(trace.forms),
                    }
                )
                form_matrix = _m(xobj.get("/Matrix") or (1, 0, 0, 1, 0, 0))
                effective_ctm = _mul(form_matrix, state.ctm)
                trace.forms.append(
                    FormInvocationEvidence(
                        definition_identity=definition,
                        invocation_identity=invocation_id,
                        parent_invocation_identity=parent_invocation,
                        resource_name=name,
                        invocation_ordinal=len(trace.forms),
                        depth=depth + 1,
                        inherited_resource_context=xobj.get("/Resources") is None,
                        parent_ctm=state.ctm,
                        form_matrix=form_matrix,
                        effective_ctm=effective_ctm,
                    )
                )
                if definition in trace.active_forms:
                    trace.limitations.add("recursive_xobject")
                    continue
                trace.active_forms.add(definition)
                child = state.clone()
                child.ctm = effective_ctm
                _trace_streams(
                    reader=reader,
                    streams=[xref],
                    resources=xobj.get("/Resources") or resources,
                    trace=trace,
                    state=child,
                    form_path=form_path
                    + (f"{name}@{trace.global_ordinal - 1}:{definition}",),
                    depth=depth + 1,
                    parent_invocation=invocation_id,
                    root_stream_ordinal=root_stream_ordinal + stream_index,
                )
                trace.active_forms.discard(definition)


def _empty_result(code: str) -> OperationProvenanceResult:
    return OperationProvenanceResult(
        status="unavailable", bundle=None, limitation_codes=(code,)
    )


def _build_operation_provenance_unisolated(
    *,
    source_bytes: bytes,
    expected_source_sha256: str,
    original_page_number: int,
    raw_authority_result: RawAuthorityResult,
    decoder_result: StrictDecoderResult,
    policy: DecoderResourcePolicy = EXPERIMENTAL_CTIF1B_DECODER_POLICY,
    text_lineage_only: bool = False,
) -> OperationProvenanceResult:
    started = perf_counter()
    actual = sha256(source_bytes).hexdigest()
    if (
        actual != expected_source_sha256
        or raw_authority_result.bundle is None
        or decoder_result.inventory is None
    ):
        return _empty_result("source_raw_or_decoder_unavailable")
    try:
        from .safe_reader import open_ctif_pdf_reader

        reader, empty_password_decryption = open_ctif_pdf_reader(source_bytes)
        page = reader.pages[original_page_number - 1]
    except Exception:
        return _empty_result("pdf_or_page_unavailable")
    contents = page.get("/Contents")
    streams = (
        list(contents)
        if isinstance(contents, ArrayObject)
        else [contents]
        if contents is not None
        else []
    )
    trace = _Trace(
        actual,
        original_page_number,
        raw_authority_result,
        decoder_result,
        policy,
        started,
        text_lineage_only=text_lineage_only,
    )
    state = _ExecutionState()
    if empty_password_decryption:
        trace.limitations.add("empty_password_decryption_applied")
    trace.limitations.update(
        {
            "compressed_stream_byte_range_unavailable",
            "clipping_state_digest_unavailable",
            "optional_content_context_unavailable",
            "font_outline_envelope_unavailable",
        }
    )
    if text_lineage_only:
        trace.limitations.add("non_text_operation_execution_evidence_elided")
    _trace_streams(
        reader=reader,
        streams=streams,
        resources=page.get("/Resources") or {},
        trace=trace,
        state=state,
    )
    by_decoder_operation: dict[str, CanonicalOperationExecution] = {}
    for operation in trace.operations:
        legacy = canonical_sha256(
            {
                "path": canonical_sha256(
                    operation.content_path.model_dump(mode="json")
                ),
                "operand": operation.operand_digest,
            }
        )
        by_decoder_operation[legacy] = operation
    step_outputs: dict[str, list[tuple[str, str]]] = {}
    for step in decoder_result.inventory.mapping_steps:
        step_outputs.setdefault(step.input_identity, []).append(
            (step.output_identity, step.output_type.value)
        )

    def unicode_outputs(identity: str) -> tuple[str, ...]:
        pending = [identity]
        seen = set()  # type: ignore[var-annotated]
        found = set()
        while pending and len(seen) < 16:
            current = pending.pop(0)
            if current in seen:
                continue
            seen.add(current)
            for output, kind in step_outputs.get(current, ()):
                if kind == "unicode_sequence":
                    found.add(output)
                else:
                    pending.append(output)
        return tuple(sorted(found))

    links = []
    for unit in decoder_result.inventory.code_units:
        operation = by_decoder_operation.get(unit.text_show_operation_identity)  # type: ignore[assignment]
        if operation is None:
            trace.limitations.add("decoder_operation_link_unavailable")  # type: ignore[unreachable]
            continue
        limitations = (
            "glyph_origin_requires_advance_metrics",
            "canonical_interval_not_materialized",
        )
        values = {
            "decoder_code_identity": unit.evidence_identity,
            "operation_identity": operation.operation_identity,
            "raw_code_start": unit.raw_code_start,
            "raw_code_end_exclusive": unit.raw_code_end_exclusive,
            "deterministic_ordinal": unit.deterministic_ordinal,
            "canonical_unicode_evidence_identities": unicode_outputs(
                unit.evidence_identity
            ),
            "glyph_origin": None,
            "glyph_advance": None,
            "limitation_codes": limitations,
        }
        links.append(
            CodeExecutionProvenance(
                **values,  # type: ignore[arg-type]
                provenance_identity=canonical_sha256(values),
            )
        )
    operations = tuple(trace.operations)
    text_ops = [
        item for item in operations if item.operator.encode("latin-1") in TEXT_SHOW
    ]
    serialized_base = {
        "operations": [item.model_dump(mode="json") for item in operations],
        "links": [item.model_dump(mode="json") for item in links],
        "forms": [item.model_dump(mode="json") for item in trace.forms],
    }
    metrics = OperationProvenanceMetrics(
        stream_count=trace.stream_count,
        operation_count=len(operations),
        text_show_operation_count=len(text_ops),
        form_invocation_count=len(trace.forms),
        code_unit_count=len(links),
        operation_span_count=len(operations),
        operand_span_count=len(operations),
        ctm_count=len(operations),
        text_matrix_count=sum(
            item.state_before.text_matrix is not None for item in text_ops
        ),
        effective_matrix_count=sum(
            item.effective_text_matrix is not None for item in text_ops
        ),
        font_binding_count=sum(
            item.state_before.font_resource_identity is not None for item in text_ops
        ),
        operation_origin_count=sum(
            item.operation_origin is not None for item in text_ops
        ),
        glyph_advance_count=0,
        mcid_operation_count=sum(
            any(value is not None for value in item.state_before.mcid_path)
            for item in operations
        ),
        serialized_bytes=len(canonical_json_bytes(serialized_base)),
    )
    limitations = set(trace.limitations)  # type: ignore[assignment]
    for item in operations:
        limitations.update(item.limitation_codes)  # type: ignore[attr-defined]
    for item in links:  # type: ignore[assignment]
        limitations.update(item.limitation_codes)  # type: ignore[attr-defined]
    completeness = (
        "unsafe"
        if "operation_correlation_ambiguous" in limitations
        else "partial"
        if limitations
        else "complete"
    )
    identity = raw_authority_result.bundle.authority_identity
    box = lambda value: (
        tuple(canonical_float(item) for item in value)
        if value is not None and len(value) == 4
        else ("0.000000000",) * 4
    )
    values = {
        "source_artifact_sha256": actual,
        "document_identity": identity.document_identity,
        "original_page_number": original_page_number,
        "page_identity": identity.page_identity,
        "page_rotation_degrees": int(page.get("/Rotate") or 0) % 360,
        "media_box": box(page.mediabox),  # type: ignore[no-untyped-call]
        "crop_box": box(page.cropbox),  # type: ignore[no-untyped-call]
        "raw_authority_bundle_digest": raw_authority_result.bundle.bundle_digest,
        "decoder_inventory_digest": decoder_result.inventory.inventory_digest,
        "operations": operations,
        "code_execution": tuple(links),
        "form_invocations": tuple(trace.forms),
        "limitation_codes": tuple(sorted(limitations)),
        "completeness": completeness,
        "metrics": metrics,
    }
    policy_identity = (
        TEXT_LINEAGE_OPERATION_PROVENANCE_POLICY
        if text_lineage_only
        else OPERATION_PROVENANCE_POLICY
    )
    provisional = OperationProvenanceBundle.model_construct(
        **values,  # type: ignore[arg-type]
        bundle_version=OPERATION_PROVENANCE_VERSION,
        policy_identity=policy_identity,
        bundle_digest="0" * 64,
    )
    bundle = OperationProvenanceBundle(
        **values,  # type: ignore[arg-type]
        policy_identity=policy_identity,
        bundle_digest=canonical_sha256(provisional.model_dump(mode="json")),
    )
    return OperationProvenanceResult(
        status=completeness,  # type: ignore[arg-type]
        bundle=bundle,
        limitation_codes=bundle.limitation_codes,
    )


def build_operation_provenance(
    *,
    source_bytes: bytes,
    expected_source_sha256: str,
    original_page_number: int,
    raw_authority_result: RawAuthorityResult,
    decoder_result: StrictDecoderResult,
    policy: DecoderResourcePolicy = EXPERIMENTAL_CTIF1B_DECODER_POLICY,
) -> OperationProvenanceResult:
    from .runtime_adapter import run_operation_provenance

    outcome = run_operation_provenance(
        source_bytes=source_bytes,
        expected_source_sha256=expected_source_sha256,
        original_page_number=original_page_number,
        raw_authority_result=raw_authority_result,
        decoder_result=decoder_result,
        decoder_policy=policy,
        text_lineage_only=False,
    )
    if outcome.outcome == "completed" and isinstance(
        outcome.value, OperationProvenanceResult
    ):
        return outcome.value
    return _empty_result(outcome.limitation_code or "ctif_runtime_worker_failed")


def build_text_lineage_operation_provenance(
    *,
    source_bytes: bytes,
    expected_source_sha256: str,
    original_page_number: int,
    raw_authority_result: RawAuthorityResult,
    decoder_result: StrictDecoderResult,
    policy: DecoderResourcePolicy = EXPERIMENTAL_CTIF1B_DECODER_POLICY,
) -> OperationProvenanceResult:
    from .runtime_adapter import run_operation_provenance

    outcome = run_operation_provenance(
        source_bytes=source_bytes,
        expected_source_sha256=expected_source_sha256,
        original_page_number=original_page_number,
        raw_authority_result=raw_authority_result,
        decoder_result=decoder_result,
        decoder_policy=policy,
        text_lineage_only=True,
    )
    if outcome.outcome == "completed" and isinstance(
        outcome.value, OperationProvenanceResult
    ):
        return outcome.value
    return _empty_result(outcome.limitation_code or "ctif_runtime_worker_failed")

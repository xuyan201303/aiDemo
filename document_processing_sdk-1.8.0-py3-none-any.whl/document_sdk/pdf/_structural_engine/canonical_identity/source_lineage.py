# ruff: noqa: ANN001, ANN202, B007, BLE001, C901, E501, EM101, N802, PLR0912, PLR0913, PLR0915, PLR0917, PLR2004, S110, S112, SLF001, TC001, TRY003, TRY301, UP037
"""CTIF-2 opt-in pdfminer native-event lineage sidecar.

This module does not alter pdfminer/pdfplumber or Product execution.  It runs
inside CTIF Safe Runtime and accepts a native character only when its exact
interpreter event and decoder code ancestry are uniquely bound to CTIF-1M.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from hashlib import sha256
from io import BytesIO
from typing import Any, Literal

import pdfminer
import pdfplumber
from pdfminer.converter import PDFPageAggregator
from pdfminer.layout import LAParams, LTChar
from pdfminer.pdfinterp import PDFPageInterpreter, PDFResourceManager
from pdfminer.pdfpage import PDFPage
from pdfplumber.utils.text import WordExtractor, chars_to_textmap
from pydantic import BaseModel, ConfigDict, Field
from pypdf.generic import ArrayObject, ContentStream

from .decoder import StrictDecoderResult
from .operation_provenance import OperationProvenanceResult
from .raw_string_lexer import lex_content_stream
from .serialization import canonical_float, canonical_sha256

SOURCE_LINEAGE_VERSION = "ctif_source_lineage.v1"
SOURCE_LINEAGE_POLICY = "ctif_source_lineage.experimental.v1"


class _Frozen(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class NativeTextEventEvidence(_Frozen):
    event_ordinal: int = Field(ge=0)
    operator: Literal["Tj", "TJ", "'", '"']
    raw_segment_digests: tuple[str, ...]
    adjustment_digests: tuple[str, ...] = ()
    operation_identity: str | None = None
    proof_method: Literal[
        "EXACT_NATIVE_OPERATION_EVENT",
        "NATIVE_INTERPRETER_EVENT_REVIEW_ONLY",
        "UNPROVEN",
    ]
    limitation_codes: tuple[str, ...] = ()
    event_identity: str = Field(pattern=r"^[0-9a-f]{64}$")


class NativeCharacterEvidence(_Frozen):
    character_ordinal: int = Field(ge=0)
    event_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    operation_identity: str | None = None
    decoder_code_identity: str | None = None
    decoder_code_identities: tuple[str, ...] = ()
    source_code_ordinal: int = Field(ge=0)
    unicode_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    unicode_scalar_count: int = Field(ge=0)
    bbox: tuple[str, str, str, str] | None = None
    font_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    proof_method: Literal[
        "EXACT_DECODER_CODE_LINEAGE",
        "REVERSIBLE_SEGMENTED_NATIVE_ALIGNMENT",
        "UNPROVEN",
    ]
    limitation_codes: tuple[str, ...] = ()
    character_identity: str = Field(pattern=r"^[0-9a-f]{64}$")


class SourceLayoutParentageEvidence(_Frozen):
    layout_kind: Literal["word", "line"]
    deterministic_ordinal: int = Field(ge=0)
    child_character_identities: tuple[str, ...]
    text_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    geometry_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    proof_method: Literal["NATIVE_LAYOUT_CHILD_PARENTAGE"] = (
        "NATIVE_LAYOUT_CHILD_PARENTAGE"
    )
    parentage_identity: str = Field(pattern=r"^[0-9a-f]{64}$")


class SourceFactLineageEvidence(_Frozen):
    fact_kind: Literal["word", "line"]
    selector_indices: tuple[int, ...]
    parentage_identities: tuple[str, ...]
    child_character_identities: tuple[str, ...]
    operation_identities: tuple[str, ...]
    decoder_code_identities: tuple[str, ...]
    decision: Literal[
        "SOURCE_LINEAGE_PROVEN",
        "SOURCE_LINEAGE_REVIEW_REQUIRED",
        "SOURCE_CANONICAL_UNMAPPABLE",
    ]
    limitation_codes: tuple[str, ...] = ()
    lineage_identity: str = Field(pattern=r"^[0-9a-f]{64}$")


class SourceLineageMetrics(_Frozen):
    native_event_count: int = Field(ge=0)
    source_character_count: int = Field(ge=0)
    exact_operation_linked_characters: int = Field(ge=0)
    exact_decoder_code_linked_characters: int = Field(ge=0)
    ambiguous_characters: int = Field(ge=0)
    unmapped_characters: int = Field(ge=0)


class SourceLineageBundle(_Frozen):
    bundle_version: str = SOURCE_LINEAGE_VERSION
    source_artifact_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    original_page_number: int = Field(gt=0)
    parser_identity: str
    parser_configuration_identity: str
    operation_provenance_digest: str | None = Field(
        default=None, pattern=r"^[0-9a-f]{64}$"
    )
    policy_identity: str = SOURCE_LINEAGE_POLICY
    events: tuple[NativeTextEventEvidence, ...]
    characters: tuple[NativeCharacterEvidence, ...]
    words: tuple[SourceLayoutParentageEvidence, ...]
    lines: tuple[SourceLayoutParentageEvidence, ...]
    limitation_codes: tuple[str, ...]
    completeness: Literal["complete", "partial", "unsafe"]
    metrics: SourceLineageMetrics
    bundle_digest: str = Field(pattern=r"^[0-9a-f]{64}$")


class SourceLineageResult(_Frozen):
    status: Literal["complete", "partial", "unsafe", "unavailable"]
    bundle: SourceLineageBundle | None
    limitation_codes: tuple[str, ...]


@dataclass
class _Event:
    ordinal: int
    operator: str
    segments: tuple[bytes, ...]
    adjustments: tuple[str, ...]
    operands: tuple[Any, ...]
    emitted: list[
        tuple[int, str, tuple[float, float, float, float] | None, str, Any]
    ] = field(default_factory=list)


@dataclass
class _Trace:
    source_artifact_sha256: str
    original_page_number: int
    events: list[_Event] = field(default_factory=list)
    current: _Event | None = None
    character_ordinal: int = 0


class _TraceDevice(PDFPageAggregator):
    def __init__(self, rsrcmgr: PDFResourceManager, trace: _Trace) -> None:
        super().__init__(rsrcmgr, laparams=LAParams())
        self.trace = trace

    def render_char(  # type: ignore[no-untyped-def]
        self, matrix, font, fontsize, scaling, rise, cid, ncs, graphicstate
    ):
        advance = super().render_char(
            matrix, font, fontsize, scaling, rise, cid, ncs, graphicstate
        )
        event = self.trace.current
        if event is not None:
            try:
                text = font.to_unichr(cid)
            except Exception:
                text = ""
            bbox = None
            try:
                item = self.cur_item._objs[-1]
                if isinstance(item, LTChar):
                    bbox = tuple(float(value) for value in item.bbox)
            except Exception:
                pass
            font_identity = canonical_sha256(
                {
                    "source": self.trace.source_artifact_sha256,
                    "page": self.trace.original_page_number,
                    "class": f"{font.__class__.__module__}.{font.__class__.__qualname__}",
                    "fontname": str(getattr(font, "fontname", "")),
                    "vertical": bool(font.is_vertical()),
                    "multibyte": bool(font.is_multibyte()),
                }
            )
            event.emitted.append(
                (  # type: ignore[arg-type]
                    int(cid),
                    text,
                    bbox,  # pyright: ignore[reportArgumentType]
                    font_identity,
                    item if "item" in locals() else None,  # pyright: ignore[reportPossiblyUnboundVariable]
                )
            )
            self.trace.character_ordinal += 1
        return advance


class _TraceInterpreter(PDFPageInterpreter):
    def __init__(
        self, rsrcmgr: PDFResourceManager, device: _TraceDevice, trace: _Trace
    ) -> None:
        super().__init__(rsrcmgr, device)
        self.trace = trace
        self._forced_operator: str | None = None

    def _show(self, operator: str, seq: Any, call: Any) -> None:
        values = list(seq) if isinstance(seq, (list, tuple)) else [seq]
        segments = tuple(bytes(item) for item in values if isinstance(item, bytes))
        adjustments = tuple(
            canonical_float(item) for item in values if isinstance(item, (int, float))
        )
        event = _Event(
            len(self.trace.events),
            self._forced_operator or operator,
            segments,
            adjustments,
            tuple(values),
        )
        self.trace.events.append(event)
        previous = self.trace.current
        self.trace.current = event
        try:
            call()
        finally:
            self.trace.current = previous

    def do_Tj(self, s: Any) -> None:
        # PDFPageInterpreter.do_Tj delegates back to self.do_TJ; call the base
        # TJ implementation directly so one PDF operator creates one event.
        self._show("Tj", [s], lambda: PDFPageInterpreter.do_TJ(self, [s]))

    def do_TJ(self, seq: Any) -> None:
        self._show("TJ", seq, lambda: super(_TraceInterpreter, self).do_TJ(seq))

    def do__q(self, s: Any) -> None:
        self.do_T_a()
        self._show("'", [s], lambda: PDFPageInterpreter.do_TJ(self, [s]))

    def do__w(self, aw: Any, ac: Any, s: Any) -> None:
        self.do_Tw(aw)
        self.do_Tc(ac)
        self.do_T_a()
        self._show('"', [aw, ac, s], lambda: PDFPageInterpreter.do_TJ(self, [s]))

    def dup(self) -> "_TraceInterpreter":
        return _TraceInterpreter(self.rsrcmgr, self.device, self.trace)  # type: ignore[arg-type]


def _empty(code: str) -> SourceLineageResult:
    return SourceLineageResult(
        status="unavailable", bundle=None, limitation_codes=(code,)
    )


def _stream_lexemes(
    source_bytes: bytes, page_number: int
) -> dict[str, tuple[Any, ...]]:
    from .safe_reader import open_ctif_pdf_reader

    reader, _ = open_ctif_pdf_reader(source_bytes)
    page = reader.pages[page_number - 1]
    found: dict[str, tuple[Any, ...]] = {}
    active: set[str] = set()
    visited: set[str] = set()

    def visit(contents: Any, resources: Any, depth: int = 0) -> None:
        if depth > 16:
            return
        streams = (
            list(contents)
            if isinstance(contents, ArrayObject)
            else [contents]
            if contents is not None
            else []
        )
        for ref in streams:
            try:
                obj = ref.get_object() if hasattr(ref, "get_object") else ref
                data = obj.get_data()
            except Exception:
                continue
            digest = sha256(data).hexdigest()
            if digest not in found:
                found[digest] = lex_content_stream(data).operations
            try:
                xobjects = (resources or {}).get("/XObject", {})
            except Exception:
                xobjects = {}
            try:
                invoked = {
                    str(operands[0])
                    for operands, operator in ContentStream(ref, reader).operations
                    if bytes(operator) == b"Do" and operands
                }
            except Exception:
                invoked = set()
            for name, xref in sorted(xobjects.items(), key=lambda item: str(item[0])):
                if str(name) not in invoked:
                    continue
                try:
                    child = xref.get_object()
                    subtype = str(child.get("/Subtype") or "")
                except Exception:
                    continue
                key = f"{getattr(xref, 'idnum', 'direct')}:{getattr(xref, 'generation', 0)}"
                if subtype != "/Form" or key in active or key in visited:
                    continue
                active.add(key)
                visited.add(key)
                visit(xref, child.get("/Resources") or resources, depth + 1)
                active.remove(key)

    visit(page.get("/Contents"), page.get("/Resources") or {})
    return found


def _build_source_lineage_unisolated(
    *,
    source_bytes: bytes,
    expected_source_sha256: str,
    original_page_number: int,
    operation_provenance_result: OperationProvenanceResult,
    decoder_result: StrictDecoderResult,
    parser_configuration_identity: str = "pdfminer.layout.default.v1",
) -> SourceLineageResult:
    actual = sha256(source_bytes).hexdigest()
    provenance = operation_provenance_result.bundle
    if actual != expected_source_sha256:
        return _empty("source_identity_mismatch")
    trace = _Trace(actual, original_page_number)
    try:
        rsrcmgr = PDFResourceManager()
        device = _TraceDevice(rsrcmgr, trace)
        interpreter = _TraceInterpreter(rsrcmgr, device, trace)
        # Page-local child lifetime bounds this cache. Disabling pdfminer object
        # caching causes adversarial repeated object-stream resolution for CID
        # width tables and can exhaust the wall budget before tracing begins.
        pages = PDFPage.get_pages(
            BytesIO(source_bytes),
            pagenos={original_page_number - 1},
            caching=True,
            check_extractable=True,
        )
        page = next(pages)
        interpreter.process_page(page)
        layout = device.get_result()
        stream_lexemes = (
            _stream_lexemes(source_bytes, original_page_number) if provenance else {}
        )
    except Exception:
        return _empty("native_interpreter_trace_unavailable")
    text_operations = (
        [
            item
            for item in provenance.operations
            if item.operator in {"Tj", "TJ", "'", '"'}
        ]
        if provenance
        else []
    )
    code_by_operation: dict[str, list[Any]] = {}
    for item in provenance.code_execution if provenance else ():
        code_by_operation.setdefault(item.operation_identity, []).append(item)
    unicode_by_identity = (
        {
            item.evidence_identity: item
            for item in decoder_result.inventory.unicode_sequences
        }
        if decoder_result.inventory
        else {}
    )
    limitations: set[str] = set()
    event_models = []
    character_models = []
    character_ordinal = 0
    if provenance is None:
        limitations.add("canonical_operation_provenance_unavailable")
    if decoder_result.inventory is None:
        limitations.add("decoder_evidence_unavailable")
    for event in trace.events:
        operation = (
            text_operations[event.ordinal]
            if event.ordinal < len(text_operations)
            else None
        )
        event_digests = tuple(sha256(v).hexdigest() for v in event.segments)
        expected_digests: tuple[str, ...] = ()
        if operation is not None:
            candidates = [
                item
                for item in stream_lexemes.get(
                    operation.byte_span.decoded_stream_sha256, ()
                )
                if item.operator_start == operation.byte_span.operator_start
                and item.operator == operation.operator
            ]
            if len(candidates) == 1:
                expected_digests = tuple(
                    item.decoded_operand_digest for item in candidates[0].string_tokens
                )
        exact = (
            operation is not None
            and operation.operator == event.operator
            and expected_digests == event_digests
        )
        if not exact and provenance is not None:
            limitations.add("native_operation_correlation_unproven")
        operation_identity = operation.operation_identity if exact else None  # type: ignore[union-attr]
        event_method = (
            "EXACT_NATIVE_OPERATION_EVENT"
            if exact
            else "NATIVE_INTERPRETER_EVENT_REVIEW_ONLY"
            if provenance is None
            else "UNPROVEN"
        )
        event_limitations = (
            ()
            if exact
            else ("canonical_operation_provenance_unavailable",)
            if provenance is None
            else ("native_operation_correlation_unproven",)
        )
        event_values = {
            "event_ordinal": event.ordinal,
            "operator": event.operator,
            "raw_segment_digests": event_digests,
            "adjustment_digests": tuple(
                sha256(v.encode()).hexdigest() for v in event.adjustments
            ),
            "operation_identity": operation_identity,
            "proof_method": event_method,
            "limitation_codes": event_limitations,
        }
        event_model = NativeTextEventEvidence(
            **event_values,  # type: ignore[arg-type]
            event_identity=canonical_sha256(
                {
                    "version": SOURCE_LINEAGE_VERSION,
                    "source": actual,
                    "page": original_page_number,
                    **event_values,
                }
            ),
        )
        event_models.append(event_model)
        codes = sorted(
            code_by_operation.get(operation_identity or "", ()),
            key=lambda item: item.deterministic_ordinal,
        )
        cardinality_proven = len(codes) == len(event.emitted)
        code_texts = []
        for code in codes:
            candidates = [
                unicode_by_identity[value]
                for value in code.canonical_unicode_evidence_identities
                if value in unicode_by_identity
                and unicode_by_identity[value].reversible
            ]
            code_texts.append(
                "".join(chr(value) for value in candidates[0].unicode_scalar_sequence)
                if len(candidates) == 1
                else None
            )
        emitted_texts = [item[1] for item in event.emitted]
        segmented_proven = (
            bool(codes)
            and all(value is not None for value in code_texts)
            and "".join(code_texts) == "".join(emitted_texts)  # type: ignore[arg-type]
        )
        code_spans = []
        offset = 0
        for value in code_texts:
            size = len(value or "")
            code_spans.append((offset, offset + size))
            offset += size
        emitted_spans = []
        offset = 0
        for value in emitted_texts:
            size = len(value)
            emitted_spans.append((offset, offset + size))
            offset += size
        for source_code_ordinal, (
            cid,
            text,
            bbox,
            font_identity,
            _layout_item,
        ) in enumerate(event.emitted):
            code = (
                codes[source_code_ordinal] if source_code_ordinal < len(codes) else None
            )
            linked_codes = tuple(
                codes[index].decoder_code_identity
                for index, (start, end) in enumerate(code_spans)
                if segmented_proven
                and start < emitted_spans[source_code_ordinal][1]
                and end > emitted_spans[source_code_ordinal][0]
            )
            proven = exact and (
                (cardinality_proven and code is not None) or bool(linked_codes)
            )
            if not proven:
                limitations.add("decoder_code_lineage_unproven")
            identities = linked_codes or (
                (code.decoder_code_identity,) if proven and code is not None else ()
            )
            method = (
                "REVERSIBLE_SEGMENTED_NATIVE_ALIGNMENT"
                if proven and not cardinality_proven
                else "EXACT_DECODER_CODE_LINEAGE"
                if proven
                else "UNPROVEN"
            )
            values = {
                "character_ordinal": character_ordinal,
                "event_identity": event_model.event_identity,
                "operation_identity": operation_identity,
                "decoder_code_identity": identities[0]
                if len(identities) == 1
                else None,
                "decoder_code_identities": identities,
                "source_code_ordinal": source_code_ordinal,
                "unicode_digest": sha256(text.encode("utf-8")).hexdigest(),
                "unicode_scalar_count": len(text),
                "bbox": tuple(canonical_float(v) for v in bbox) if bbox else None,
                "font_identity": font_identity,
                "proof_method": method,
                "limitation_codes": ()
                if proven
                else ("decoder_code_lineage_unproven",),
            }
            character_models.append(
                NativeCharacterEvidence(
                    **values,  # type: ignore[arg-type]
                    character_identity=canonical_sha256(
                        {
                            "version": SOURCE_LINEAGE_VERSION,
                            "source": actual,
                            "page": original_page_number,
                            **values,
                        }
                    ),
                )
            )
            character_ordinal += 1
        if len(codes) != len(event.emitted) and not segmented_proven:
            limitations.add("decoder_emission_cardinality_mismatch")
    if provenance is not None and len(trace.events) != len(text_operations):
        limitations.add("native_event_inventory_mismatch")
    unsafe = any(
        code in limitations
        for code in (
            "native_operation_correlation_unproven",
            "native_event_inventory_mismatch",
        )
    )
    completeness = "unsafe" if unsafe else "partial" if limitations else "complete"
    lines_raw: list[tuple[list[str], str, tuple[Any, ...]]] = []
    word_groups: list[tuple[list[str], str, tuple[Any, ...]]] = []
    try:
        page_height = float(layout.height)
        native_chars = []
        identities = {}  # type: ignore[assignment]
        for event in trace.events:
            for _cid, text, bbox, _font_identity, item in event.emitted:
                if item is None or bbox is None:
                    continue
                x0, y0, x1, y1 = bbox
                record = {
                    "matrix": tuple(item.matrix),
                    "fontname": item.fontname,
                    "adv": float(item.adv),
                    "upright": bool(item.upright),
                    "x0": x0,
                    "y0": y0,
                    "x1": x1,
                    "y1": y1,
                    "width": x1 - x0,
                    "height": y1 - y0,
                    "size": float(item.size),
                    "text": text,
                    "top": page_height - y1,
                    "bottom": page_height - y0,
                    "doctop": page_height - y1,
                    "object_type": "char",
                    "page_number": original_page_number,
                }
                native_chars.append(record)
        if len(native_chars) != len(character_models):
            raise ValueError("native character inventory mismatch")
        identities = {  # type: ignore[assignment]
            id(item): character_models[index].character_identity
            for index, item in enumerate(native_chars)
        }

        def group(item: dict[str, Any]) -> tuple[list[str], str, tuple[Any, ...]]:
            return (
                [identities[id(char)] for char in item.get("chars", ())],
                str(item.get("text") or ""),
                (item["x0"], item["top"], item["x1"], item["bottom"]),
            )

        word_groups = [
            group(item)
            for item in WordExtractor(
                use_text_flow=False, keep_blank_chars=False
            ).extract_words(native_chars, return_chars=True)
        ]
        lines_raw = [
            group(item)
            for item in chars_to_textmap(native_chars, layout=False).extract_text_lines(
                strip=True, return_chars=True
            )
        ]
    except Exception:
        limitations.add("source_layout_parentage_unavailable")

    def parents(
        kind: str, groups: list[tuple[list[str], str, tuple[Any, ...]]]
    ) -> tuple[SourceLayoutParentageEvidence, ...]:
        result = []
        for ordinal, (children, text_value, bbox) in enumerate(groups):
            base = {
                "layout_kind": kind,
                "deterministic_ordinal": ordinal,
                "child_character_identities": tuple(children),
                "text_digest": sha256(text_value.encode()).hexdigest(),
                "geometry_digest": canonical_sha256(
                    tuple(canonical_float(v) for v in bbox)
                ),
            }
            result.append(
                SourceLayoutParentageEvidence(
                    **base,  # type: ignore[arg-type]
                    parentage_identity=canonical_sha256(
                        {
                            "version": SOURCE_LINEAGE_VERSION,
                            "source": actual,
                            "page": original_page_number,
                            **base,
                        }
                    ),
                )
            )
        return tuple(result)

    line_models = parents("line", lines_raw)
    word_models = parents("word", word_groups)
    metrics = SourceLineageMetrics(
        native_event_count=len(event_models),
        source_character_count=len(character_models),
        exact_operation_linked_characters=sum(
            item.operation_identity is not None for item in character_models
        ),
        exact_decoder_code_linked_characters=sum(
            item.decoder_code_identity is not None for item in character_models
        ),
        ambiguous_characters=0,
        unmapped_characters=sum(
            item.proof_method == "UNPROVEN" for item in character_models
        ),
    )
    values = {
        "source_artifact_sha256": actual,
        "original_page_number": original_page_number,
        "parser_identity": f"pdfminer.six:{pdfminer.__version__}|pdfplumber:{pdfplumber.__version__}",
        "parser_configuration_identity": parser_configuration_identity,
        "operation_provenance_digest": provenance.bundle_digest if provenance else None,
        "events": tuple(event_models),
        "characters": tuple(character_models),
        "words": word_models,
        "lines": line_models,
        "limitation_codes": tuple(sorted(limitations)),
        "completeness": completeness,
        "metrics": metrics,
    }
    provisional = SourceLineageBundle.model_construct(
        **values,  # type: ignore[arg-type]
        bundle_version=SOURCE_LINEAGE_VERSION,
        policy_identity=SOURCE_LINEAGE_POLICY,
        bundle_digest="0" * 64,
    )
    bundle = SourceLineageBundle(
        **values,  # type: ignore[arg-type]
        bundle_digest=canonical_sha256(provisional.model_dump(mode="json")),
    )
    return SourceLineageResult(
        status=completeness,  # type: ignore[arg-type]
        bundle=bundle,
        limitation_codes=bundle.limitation_codes,
    )


def build_source_lineage(
    *,
    source_bytes: bytes,
    expected_source_sha256: str,
    original_page_number: int,
    operation_provenance_result: OperationProvenanceResult,
    decoder_result: StrictDecoderResult,
    parser_configuration_identity: str = "pdfminer.layout.default.v1",
) -> SourceLineageResult:
    from .runtime_adapter import run_source_lineage

    outcome = run_source_lineage(
        source_bytes=source_bytes,
        expected_source_sha256=expected_source_sha256,
        original_page_number=original_page_number,
        operation_provenance_result=operation_provenance_result,
        decoder_result=decoder_result,
        parser_configuration_identity=parser_configuration_identity,
    )
    if outcome.outcome == "completed" and isinstance(
        outcome.value, SourceLineageResult
    ):
        return outcome.value
    return _empty(outcome.limitation_code or "ctif_runtime_worker_failed")


def reanchor_source_fact(
    bundle: SourceLineageBundle,
    *,
    fact_kind: Literal["word", "line"],
    selector_indices: tuple[int, ...],
) -> SourceFactLineageEvidence:
    """Select native layout facts and report proof strength without guessing.

    Selector indices are governance input only.  Identity is inherited solely
    from the selected facts' native character/operation/code parentage.
    """
    inventory = bundle.words if fact_kind == "word" else bundle.lines
    selected = [
        inventory[index] for index in selector_indices if 0 <= index < len(inventory)
    ]
    by_character = {item.character_identity: item for item in bundle.characters}
    children = tuple(
        identity for item in selected for identity in item.child_character_identities
    )
    characters = [
        by_character[identity] for identity in children if identity in by_character
    ]
    complete = (
        bool(selector_indices)
        and len(selected) == len(selector_indices)
        and bool(children)
        and len(characters) == len(children)
    )
    operation_ids = tuple(
        item.operation_identity
        for item in characters
        if item.operation_identity is not None
    )
    code_ids = tuple(
        identity for item in characters for identity in item.decoder_code_identities
    )
    if complete and all(item.decoder_code_identities for item in characters):
        decision = "SOURCE_LINEAGE_PROVEN"
        limitations = ()
    elif complete:
        decision = "SOURCE_LINEAGE_REVIEW_REQUIRED"
        limitations = ("strict_canonical_lineage_incomplete",)  # type: ignore[assignment]
    else:
        decision = "SOURCE_CANONICAL_UNMAPPABLE"
        limitations = ("native_fact_parentage_incomplete",)  # type: ignore[assignment]
    values = {
        "fact_kind": fact_kind,
        "selector_indices": selector_indices,
        "parentage_identities": tuple(item.parentage_identity for item in selected),
        "child_character_identities": children,
        "operation_identities": operation_ids,
        "decoder_code_identities": code_ids,
        "decision": decision,
        "limitation_codes": limitations,
    }
    return SourceFactLineageEvidence(
        **values,  # type: ignore[arg-type]
        lineage_identity=canonical_sha256(
            {
                "version": SOURCE_LINEAGE_VERSION,
                "source": bundle.source_artifact_sha256,
                "page": bundle.original_page_number,
                **values,
            }
        ),
    )

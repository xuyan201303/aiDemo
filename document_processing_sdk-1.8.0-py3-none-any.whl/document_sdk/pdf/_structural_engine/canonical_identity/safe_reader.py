# ruff: noqa: BLE001, EM101, N818, TRY003
"""CTIF-only in-memory reader opening with typed safe error categories."""

from __future__ import annotations

from io import BytesIO

from pypdf import PdfReader


class CtifEncryptedSourceUnsupported(ValueError):
    """The PDF cannot be opened by the bounded offline authority."""

    category = "encrypted_source_unsupported"


class CtifMalformedSource(ValueError):
    """The source cannot be parsed as a PDF inside the private CTIF boundary."""

    category = "malformed_pdf"


def open_ctif_pdf_reader(source_bytes: bytes) -> tuple[PdfReader, bool]:
    if type(source_bytes) is not bytes:
        raise TypeError("source_bytes must be immutable bytes")
    try:
        reader = PdfReader(BytesIO(source_bytes), strict=False)
        encrypted = reader.is_encrypted
    except Exception:
        raise CtifMalformedSource("malformed_pdf") from None
    if not encrypted:
        return reader, False
    try:
        status = reader.decrypt("")
    except Exception:
        raise CtifEncryptedSourceUnsupported("encrypted_source_unsupported") from None
    if not status:
        raise CtifEncryptedSourceUnsupported("encrypted_source_unsupported")
    return reader, True

# ruff: noqa: C901, EM101, FBT003, I001, PLR0912, PLR0915, PLR2004

"""Strict bounded lexer for raw PDF text-show strings.

The lexer works on decoded content-stream bytes.  It never reconstructs bytes
from Unicode and keeps lexical and decoded byte identities separate.
"""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from typing import Literal

from .decoder_limits import DecoderResourcePolicy, EXPERIMENTAL_CTIF1B_DECODER_POLICY
from .serialization import canonical_sha256

_WS = b"\x00\x09\x0a\x0c\x0d\x20"
_DELIMITERS = _WS + b"()<>[]{}/%"
_OPERATORS = {
    b"b",
    b"B",
    b"b*",
    b"B*",
    b"BDC",
    b"BI",
    b"BMC",
    b"BT",
    b"BX",
    b"c",
    b"cm",
    b"CS",
    b"cs",
    b"d",
    b"d0",
    b"d1",
    b"Do",
    b"DP",
    b"EI",
    b"EMC",
    b"ET",
    b"EX",
    b"f",
    b"F",
    b"f*",
    b"G",
    b"g",
    b"gs",
    b"h",
    b"i",
    b"ID",
    b"j",
    b"J",
    b"K",
    b"k",
    b"l",
    b"m",
    b"M",
    b"MP",
    b"n",
    b"q",
    b"Q",
    b"re",
    b"RG",
    b"rg",
    b"ri",
    b"s",
    b"S",
    b"SC",
    b"sc",
    b"SCN",
    b"scn",
    b"sh",
    b"T*",
    b"Tc",
    b"Td",
    b"TD",
    b"Tf",
    b"Tj",
    b"TJ",
    b"TL",
    b"Tm",
    b"Tr",
    b"Ts",
    b"Tw",
    b"Tz",
    b"v",
    b"w",
    b"W",
    b"W*",
    b"y",
    b"'",
    b'"',
}
_TEXT_SHOW = {b"Tj", b"TJ", b"'", b'"'}


class RawLexerError(ValueError):
    """Typed fail-closed lexical error."""


@dataclass(frozen=True)
class RawStringToken:
    token_type: Literal["literal", "hex"]
    raw_stream_start: int
    raw_stream_end_exclusive: int
    raw_token_digest: str
    raw_token_length: int
    bounded_raw_token_hex: str
    decoded_bytes: bytes
    decoded_operand_digest: str
    operand_index: int
    tj_element_ordinal: int | None
    deterministic_ordinal: int
    malformed: bool = False
    limitation_codes: tuple[str, ...] = ()

    @property
    def token_identity(self) -> str:
        return canonical_sha256(
            {
                "type": self.token_type,
                "start": self.raw_stream_start,
                "end": self.raw_stream_end_exclusive,
                "raw": self.raw_token_digest,
                "decoded": self.decoded_operand_digest,
                "operand": self.operand_index,
                "tj": self.tj_element_ordinal,
                "ordinal": self.deterministic_ordinal,
                "malformed": self.malformed,
                "limitations": self.limitation_codes,
            }
        )


@dataclass(frozen=True)
class RawLexedOperation:
    operation_ordinal: int
    operator: str
    operator_start: int
    operator_end_exclusive: int
    operand_count: int
    string_tokens: tuple[RawStringToken, ...]
    operation_identity: str
    malformed: bool = False
    limitation_codes: tuple[str, ...] = ()


@dataclass(frozen=True)
class RawLexerResult:
    operations: tuple[RawLexedOperation, ...]
    text_show_operations: tuple[RawLexedOperation, ...]
    stream_digest: str
    stream_bytes: int
    token_count: int
    malformed_count: int
    complete: bool
    limitation_codes: tuple[str, ...]


def _bounded_hex(data: bytes, limit: int = 32) -> str:
    return data[:limit].hex().upper()


def _skip_ws_comments(data: bytes, index: int) -> int:
    size = len(data)
    while index < size:
        if data[index] in _WS:
            index += 1
            continue
        if data[index] == 0x25:
            index += 1
            while index < size and data[index] not in (0x0A, 0x0D):
                index += 1
            continue
        break
    return index


def _literal(
    data: bytes, start: int, policy: DecoderResourcePolicy
) -> tuple[int, bytes, int]:
    index = start + 1
    depth = 1
    output = bytearray()
    escapes = 0
    while index < len(data):
        if index - start > policy.max_raw_token_bytes:
            raise RawLexerError("raw_token_bound_exceeded")
        value = data[index]
        if value == 0x5C:
            escapes += 1
            if escapes > policy.max_escape_count:
                raise RawLexerError("escape_bound_exceeded")
            index += 1
            if index >= len(data):
                raise RawLexerError("unclosed_literal_string")
            escaped = data[index]
            standard = {
                ord("n"): 0x0A,
                ord("r"): 0x0D,
                ord("t"): 0x09,
                ord("b"): 0x08,
                ord("f"): 0x0C,
                ord("("): 0x28,
                ord(")"): 0x29,
                ord("\\"): 0x5C,
            }
            if escaped in standard:
                output.append(standard[escaped])
                index += 1
                continue
            if escaped in (0x0A, 0x0D):
                if (
                    escaped == 0x0D
                    and index + 1 < len(data)
                    and data[index + 1] == 0x0A
                ):
                    index += 1
                index += 1
                continue
            if 0x30 <= escaped <= 0x37:
                digits = bytearray([escaped])
                index += 1
                while (
                    index < len(data)
                    and len(digits) < 3
                    and 0x30 <= data[index] <= 0x37
                ):
                    digits.append(data[index])
                    index += 1
                output.append(int(digits.decode("ascii"), 8) & 0xFF)
                continue
            output.append(escaped)
            index += 1
            continue
        if value == 0x28:
            depth += 1
            if depth > policy.max_lexer_nesting:
                raise RawLexerError("literal_nesting_bound_exceeded")
            output.append(value)
            index += 1
            continue
        if value == 0x29:
            depth -= 1
            index += 1
            if depth == 0:
                return index, bytes(output), escapes
            output.append(value)
            continue
        output.append(value)
        index += 1
    raise RawLexerError("unclosed_literal_string")


def _hex_string(
    data: bytes, start: int, policy: DecoderResourcePolicy
) -> tuple[int, bytes]:
    end = data.find(b">", start + 1)
    if end < 0:
        raise RawLexerError("unclosed_hex_string")
    if end - start + 1 > policy.max_raw_token_bytes:
        raise RawLexerError("raw_token_bound_exceeded")
    payload = bytes(value for value in data[start + 1 : end] if value not in _WS)
    if any(value not in b"0123456789abcdefABCDEF" for value in payload):
        raise RawLexerError("invalid_hex_string")
    if len(payload) % 2:
        payload += b"0"
    return end + 1, bytes.fromhex(payload.decode("ascii"))


def lex_content_stream(
    data: bytes, *, policy: DecoderResourcePolicy = EXPERIMENTAL_CTIF1B_DECODER_POLICY
) -> RawLexerResult:
    if len(data) > policy.max_raw_stream_bytes:
        raise RawLexerError("raw_stream_bound_exceeded")
    index = 0
    operation_ordinal = 0
    token_ordinal = 0
    top_operand_count = 0
    array_depth = 0
    dict_depth = 0
    tj_element = 0
    strings: list[RawStringToken] = []
    operations: list[RawLexedOperation] = []
    limitations: set[str] = set()
    malformed = 0

    def record_tj_element() -> None:
        nonlocal tj_element
        tj_element += 1
        if tj_element > policy.max_tj_elements:
            raise RawLexerError("tj_element_bound_exceeded")

    while True:
        index = _skip_ws_comments(data, index)
        if index >= len(data):
            break
        if token_ordinal >= policy.max_text_tokens_per_page:
            raise RawLexerError("text_token_bound_exceeded")
        start = index
        value = data[index]
        if value == 0x28:
            end, decoded, _ = _literal(data, start, policy)
            if array_depth == 0 and dict_depth == 0:
                top_operand_count += 1
            token = RawStringToken(
                "literal",
                start,
                end,
                sha256(data[start:end]).hexdigest(),
                end - start,
                _bounded_hex(data[start:end]),
                decoded,
                sha256(decoded).hexdigest(),
                max(top_operand_count - 1, 0),
                tj_element if array_depth else None,
                token_ordinal,
            )
            strings.append(token)
            token_ordinal += 1
            if array_depth:
                record_tj_element()
            index = end
            continue
        if value == 0x3C and index + 1 < len(data) and data[index + 1] != 0x3C:
            end, decoded = _hex_string(data, start, policy)
            if array_depth == 0 and dict_depth == 0:
                top_operand_count += 1
            token = RawStringToken(
                "hex",
                start,
                end,
                sha256(data[start:end]).hexdigest(),
                end - start,
                _bounded_hex(data[start:end]),
                decoded,
                sha256(decoded).hexdigest(),
                max(top_operand_count - 1, 0),
                tj_element if array_depth else None,
                token_ordinal,
            )
            strings.append(token)
            token_ordinal += 1
            if array_depth:
                record_tj_element()
            index = end
            continue
        if data.startswith(b"<<", index):
            if array_depth == 0 and dict_depth == 0:
                top_operand_count += 1
            dict_depth += 1
            index += 2
            continue
        if data.startswith(b">>", index):
            dict_depth = max(0, dict_depth - 1)
            index += 2
            continue
        if value == 0x5B:
            if array_depth == 0 and dict_depth == 0:
                top_operand_count += 1
                tj_element = 0
            array_depth += 1
            index += 1
            continue
        if value == 0x5D:
            array_depth = max(0, array_depth - 1)
            index += 1
            continue
        if value == 0x2F:
            index += 1
            while index < len(data) and data[index] not in _DELIMITERS:
                index += 1
            if array_depth == 0 and dict_depth == 0:
                top_operand_count += 1
            elif array_depth:
                record_tj_element()
            continue
        index += 1
        while index < len(data) and data[index] not in _DELIMITERS:
            index += 1
        word = data[start:index]
        if array_depth:
            record_tj_element()
            continue
        if dict_depth:
            continue
        if word == b"BI":
            marker = data.find(b" ID", index)
            if marker < 0:
                marker = data.find(b"\nID", index)
            if marker < 0:
                raise RawLexerError("malformed_inline_image")
            image_start = marker + 3
            image_end = data.find(b" EI", image_start)
            if image_end < 0:
                image_end = data.find(b"\nEI", image_start)
            if image_end < 0:
                raise RawLexerError("malformed_inline_image")
            op = b"INLINE IMAGE"
            index = image_end + 3
        elif word in _OPERATORS:
            op = word
        else:
            top_operand_count += 1
            continue
        op_text = op.decode("latin-1")
        identity = canonical_sha256(
            {
                "ordinal": operation_ordinal,
                "operator": op_text,
                "start": start,
                "end": index,
                "operands": top_operand_count,
                "tokens": [item.token_identity for item in strings],
            }
        )
        operation = RawLexedOperation(
            operation_ordinal,
            op_text,
            start,
            index,
            top_operand_count,
            tuple(strings),
            identity,
            False,
            (),
        )
        operations.append(operation)
        operation_ordinal += 1
        top_operand_count = 0
        strings = []
        tj_element = 0
    if strings or top_operand_count or array_depth or dict_depth:
        malformed += 1
        limitations.add("trailing_or_unbalanced_operands")
    text = tuple(
        item for item in operations if item.operator.encode("latin-1") in _TEXT_SHOW
    )
    return RawLexerResult(
        tuple(operations),
        text,
        sha256(data).hexdigest(),
        len(data),
        token_ordinal,
        malformed,
        malformed == 0,
        tuple(sorted(limitations)),
    )

# ruff: noqa: BLE001, C901, EM101, PLR2004, TC006, TRY003

"""Disposable fixed-operation worker for the private CTIF A2 boundary.

The worker accepts one bounded JSON request on stdin and emits one terminal
JSON result on stdout.  It has no callable registry, dynamic import target,
fallback path, or diagnostic output channel.
"""

from __future__ import annotations

import json
import logging
import math
import os
import resource
import sys
import threading
from typing import TYPE_CHECKING, NoReturn, cast

if TYPE_CHECKING:
    from .runtime_adapter import CtifRequest, CtifResponse

_BOOTSTRAP_MEMORY_LIMIT_BYTES = 2_000_000_000
_BOOTSTRAP_CPU_LIMIT_SECONDS = 300
_BOOTSTRAP_MAX_REQUEST_BYTES = 256 * 1024 * 1024
_RESOURCE_EXIT_CODE = 120
_WORKER_FAILURE_EXIT_CODE = 121
_INVALID_REQUEST_EXIT_CODE = 2


def _reject_nonstandard_number(_: str) -> NoReturn:
    raise ValueError("non-standard JSON number")


def _reject_duplicate_keys(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key")
        result[key] = value
    return result


def _parse_request(payload: bytes) -> CtifRequest:
    from pydantic import ValidationError

    from .runtime_adapter import (
        _MAX_REQUEST_BYTES,
        CTIF_FIXED_OPERATION_PROTOCOL_VERSION,
        CtifOperationProvenanceRequest,
        CtifPdfiumLineageRequest,
        CtifRawAuthorityRequest,
        CtifRuntimeRequestError,
        CtifSourceLineageRequest,
        CtifStrictDecoderRequest,
    )

    if not payload or len(payload) > _MAX_REQUEST_BYTES:
        raise CtifRuntimeRequestError("Invalid CTIF runtime request")
    try:
        decoded = payload.decode("utf-8")
        envelope = json.loads(
            decoded,
            object_pairs_hook=_reject_duplicate_keys,
            parse_constant=_reject_nonstandard_number,
        )
    except (UnicodeDecodeError, ValueError):
        raise CtifRuntimeRequestError("Invalid CTIF runtime request") from None
    if type(envelope) is not dict:
        raise CtifRuntimeRequestError("Invalid CTIF runtime request")
    mapping = cast(dict[str, object], envelope)
    if mapping.get("protocol_version") != CTIF_FIXED_OPERATION_PROTOCOL_VERSION:
        raise CtifRuntimeRequestError("Invalid CTIF runtime request")
    operation = mapping.get("operation")
    request_type: type[
        CtifRawAuthorityRequest
        | CtifStrictDecoderRequest
        | CtifOperationProvenanceRequest
        | CtifPdfiumLineageRequest
        | CtifSourceLineageRequest
    ]
    if operation == "raw_authority":
        request_type = CtifRawAuthorityRequest
    elif operation == "strict_decoder":
        request_type = CtifStrictDecoderRequest
    elif operation == "operation_provenance":
        request_type = CtifOperationProvenanceRequest
    elif operation == "pdfium_lineage":
        request_type = CtifPdfiumLineageRequest
    elif operation == "source_lineage":
        request_type = CtifSourceLineageRequest
    else:
        raise CtifRuntimeRequestError("Invalid CTIF runtime request")
    try:
        return request_type.model_validate_json(payload, strict=True)
    except (TypeError, ValidationError, ValueError):
        raise CtifRuntimeRequestError("Invalid CTIF runtime request") from None


def _lower_limit(limit: int, requested: int) -> bool:
    try:
        _, hard = resource.getrlimit(limit)
        ceiling = (
            requested if hard in (resource.RLIM_INFINITY, -1) else min(requested, hard)
        )
        resource.setrlimit(limit, (ceiling, ceiling))
    except (OSError, ValueError):
        return False
    return True


def _install_limits(*, memory_limit_bytes: int, cpu_limit_seconds: int) -> None:
    for name in ("RLIMIT_AS", "RLIMIT_DATA", "RLIMIT_RSS"):
        limit = getattr(resource, name, None)
        if limit is not None:
            _lower_limit(limit, memory_limit_bytes)
    cpu_limit = getattr(resource, "RLIMIT_CPU", None)
    if cpu_limit is not None:
        _lower_limit(cpu_limit, max(1, cpu_limit_seconds))


def _peak_rss_bytes() -> int:
    value = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    return value if value > 10_000_000 else value * 1_024


def _memory_watchdog(memory_limit_bytes: int, stopped: threading.Event) -> None:
    while not stopped.wait(0.005):
        if _peak_rss_bytes() > memory_limit_bytes:
            os._exit(_RESOURCE_EXIT_CODE)


def _install_bounded_pdf_decompression(memory_limit_bytes: int) -> None:
    import pypdf.filters

    pypdf.filters.ZLIB_MAX_OUTPUT_LENGTH = max(
        1,
        min(32 * 1024 * 1024, memory_limit_bytes // 8),
    )


def _dispatch(request: CtifRequest, source_bytes: bytes) -> object:
    from .runtime_adapter import (
        CtifOperationProvenanceRequest,
        CtifPdfiumLineageRequest,
        CtifRawAuthorityRequest,
        CtifRuntimeRequestError,
        CtifSourceLineageRequest,
        CtifStrictDecoderRequest,
    )

    if type(request) is CtifRawAuthorityRequest:
        from .authority import _build_raw_canonical_authority_unisolated

        return _build_raw_canonical_authority_unisolated(
            source_bytes=source_bytes,
            expected_source_sha256=request.expected_source_sha256,
            original_page_number=request.original_page_number,
            document_identity=request.document_identity,
            page_identity=request.page_identity,
            source_snapshot_identity=request.source_snapshot_identity,
            extraction_configuration_identity=request.extraction_configuration_identity,
            policy=request.resource_policy,
        )
    if type(request) is CtifStrictDecoderRequest:
        from .decoder import _build_strict_decoder_evidence_unisolated

        return _build_strict_decoder_evidence_unisolated(
            source_bytes=source_bytes,
            expected_source_sha256=request.expected_source_sha256,
            original_page_number=request.original_page_number,
            raw_authority_result=request.raw_authority_result,
            policy=request.decoder_policy,
        )
    if type(request) is CtifOperationProvenanceRequest:
        from .operation_provenance import _build_operation_provenance_unisolated

        return _build_operation_provenance_unisolated(
            source_bytes=source_bytes,
            expected_source_sha256=request.expected_source_sha256,
            original_page_number=request.original_page_number,
            raw_authority_result=request.raw_authority_result,
            decoder_result=request.decoder_result,
            policy=request.decoder_policy,
            text_lineage_only=request.text_lineage_only,
        )
    if type(request) is CtifPdfiumLineageRequest:
        from .pdfium_lineage import _build_pdfium_lineage_unisolated

        return _build_pdfium_lineage_unisolated(
            source_bytes=source_bytes,
            expected_source_sha256=request.expected_source_sha256,
            document_identity=request.document_identity,
            original_page_number=request.original_page_number,
            page_identity=request.page_identity,
            parser_configuration_identity=request.parser_configuration_identity,
            max_text_objects=request.max_text_objects,
            max_characters=request.max_characters,
        )
    if type(request) is CtifSourceLineageRequest:
        from .source_lineage import _build_source_lineage_unisolated

        return _build_source_lineage_unisolated(
            source_bytes=source_bytes,
            expected_source_sha256=request.expected_source_sha256,
            original_page_number=request.original_page_number,
            operation_provenance_result=request.operation_provenance_result,
            decoder_result=request.decoder_result,
            parser_configuration_identity=request.parser_configuration_identity,
        )
    raise CtifRuntimeRequestError("Invalid CTIF runtime request")


def _emit_response(request: CtifRequest, response: CtifResponse) -> int:
    from .runtime_adapter import _failure_response, _worker_response_limit_bytes

    serialized = response.model_dump_json().encode("utf-8") + b"\n"
    if len(serialized) > _worker_response_limit_bytes(request):
        bounded = _failure_response(request, "resource_exceeded")
        serialized = bounded.model_dump_json().encode("utf-8") + b"\n"
    sys.stdout.buffer.write(serialized)
    sys.stdout.buffer.flush()
    return 0


def _execute(request: CtifRequest) -> int:
    from .runtime_adapter import (
        CtifPdfiumLineageRequest,
        CtifRuntimeRequestError,
        _completed_response,
        _decode_and_validate_source,
        _failure_response,
        _process_configuration,
        _request_memory_limit_bytes,
    )

    try:
        source_bytes = _decode_and_validate_source(request)
    except CtifRuntimeRequestError:
        return _emit_response(request, _failure_response(request, "invalid_request"))

    memory_limit_bytes = _request_memory_limit_bytes(request)
    timeout = _process_configuration(request).hard_timeout_seconds
    _install_limits(
        memory_limit_bytes=memory_limit_bytes,
        cpu_limit_seconds=max(1, math.ceil(timeout)),
    )
    stopped = threading.Event()
    watchdog = threading.Thread(
        target=_memory_watchdog,
        args=(memory_limit_bytes, stopped),
        daemon=True,
    )
    watchdog.start()
    try:
        try:
            if type(request) is not CtifPdfiumLineageRequest:
                _install_bounded_pdf_decompression(memory_limit_bytes)
            payload = _dispatch(request, source_bytes)
            response = _completed_response(request, payload)
        except MemoryError:
            try:
                response = _failure_response(request, "resource_exceeded")
            except MemoryError:
                return _RESOURCE_EXIT_CODE
        except (ImportError, OSError):
            response = _failure_response(request, "dependency_unavailable")
        except BaseException:
            response = _failure_response(request, "worker_failed")
        try:
            return _emit_response(request, response)
        except MemoryError:
            try:
                return _emit_response(
                    request, _failure_response(request, "resource_exceeded")
                )
            except MemoryError:
                return _RESOURCE_EXIT_CODE
    finally:
        stopped.set()


def main() -> int:
    _install_limits(
        memory_limit_bytes=_BOOTSTRAP_MEMORY_LIMIT_BYTES,
        cpu_limit_seconds=_BOOTSTRAP_CPU_LIMIT_SECONDS,
    )
    try:
        request_payload = sys.stdin.buffer.read(_BOOTSTRAP_MAX_REQUEST_BYTES + 1)
    except MemoryError:
        return _RESOURCE_EXIT_CODE
    if len(request_payload) > _BOOTSTRAP_MAX_REQUEST_BYTES:
        return _RESOURCE_EXIT_CODE
    logging.disable(logging.CRITICAL)
    from .runtime_adapter import CtifRuntimeRequestError

    try:
        request = _parse_request(request_payload)
    except MemoryError:
        return _RESOURCE_EXIT_CODE
    except CtifRuntimeRequestError:
        return _INVALID_REQUEST_EXIT_CODE
    return _execute(request)


if __name__ == "__main__":
    try:
        _exit_code = main()
    except BaseException:
        _exit_code = _WORKER_FAILURE_EXIT_CODE
    raise SystemExit(_exit_code)

# ruff: noqa: BLE001, C401, C408, C901, PLR0912, PLR0913, PLR0915, PLR2004, RUF005, SIM103, TC001, TC002
"""CTIF-1B strict raw font/CMap decoder orchestration.

This is a validation-only API.  It is not imported by existing extractors or
Product routes and does not mutate the frozen v1 raw-authority bundle.
"""

from __future__ import annotations

import resource
from dataclasses import dataclass, field
from hashlib import sha256
from time import perf_counter
from typing import Any

from pypdf import PdfReader
from pypdf.generic import (
    ArrayObject,
    ByteStringObject,
    ContentStream,
    DictionaryObject,
    NameObject,
    TextStringObject,
)

from .cmap_decoder import CMapError, CMapMapping, segment_codes
from .contracts import CanonicalAuthorityMode, CanonicalContentPath
from .decoder_contracts import (
    CANONICAL_EVIDENCE_BUNDLE_V2_VERSION,
    DECODER_CONTRACT_VERSION,
    ActualTextSubstitutionEvidence,
    CanonicalEvidenceBundleV2,
    CIDMappingMethod,
    ConflictType,
    DecoderCIDMappingEvidence,
    DecoderCodeRange,
    DecoderCodeSpaceEvidence,
    DecoderCodeUnit,
    DecoderCompleteness,
    DecoderEvidenceInventory,
    DecoderFontCodeEvidence,
    DecoderGIDMappingEvidence,
    DecoderMappingConflict,
    DecoderMappingMethod,
    DecoderMappingStep,
    DecoderResourceUsage,
    DecoderUnicodeSequenceEvidence,
    DecoderValueType,
    MappingCompleteness,
    ResolutionStatus,
    SegmentationStatus,
    UnicodeMappingMethod,
)
from .decoder_limits import EXPERIMENTAL_CTIF1B_DECODER_POLICY, DecoderResourcePolicy
from .evidence import RawAuthorityResult
from .font_decoder import (
    FontDecodeError,
    ResolvedFont,
    decode_actualtext_bytes,
    resolve_font,
)
from .pdf_object_identity import PdfObjectIdentityContext, canonical_pdf_object_digest
from .raw_pdf import TEXT_SHOW, _safe_operand, object_identity
from .raw_string_lexer import (
    RawLexedOperation,
    RawLexerError,
    RawStringToken,
    lex_content_stream,
)
from .serialization import canonical_json_bytes, canonical_sha256

CTIF1B_DECODER_VERSION = "ctif_strict_raw_font_cmap_decoder.v1"


@dataclass(frozen=True)
class DecoderMetrics:
    raw_stream_bytes: int
    text_show_operation_count: int
    raw_token_count: int
    operation_correlation_success_count: int
    operation_correlation_ambiguous_count: int
    font_count: int
    font_subtypes: tuple[str, ...]
    tounicode_count: int
    encoding_cmap_count: int
    identity_h_count: int
    identity_v_count: int
    codespace_count: int
    code_unit_count: int
    cid_mapping_count: int
    gid_mapping_count: int
    unicode_evidence_count: int
    actualtext_scope_count: int
    actualtext_substitution_count: int
    unmapped_code_count: int
    raw_only_count: int
    lossy_count: int
    conflict_count: int
    ambiguous_segmentation_count: int
    mapping_step_count: int
    reversible_code_count: int
    elapsed_ms: float
    peak_rss_bytes: int | None
    serialized_inventory_bytes: int

    @property
    def reversible_coverage(self) -> float:
        return (
            self.reversible_code_count / self.code_unit_count
            if self.code_unit_count
            else 0.0
        )


@dataclass(frozen=True)
class StrictDecoderResult:
    status: DecoderCompleteness
    inventory: DecoderEvidenceInventory | None
    bundle_v2: CanonicalEvidenceBundleV2 | None
    limitations: tuple[str, ...]
    metrics: DecoderMetrics


@dataclass
class _MarkedScope:
    path_identity: str
    start_operation: int
    actualtext_bytes: bytes | None
    mcid: int | None
    property_identity: str
    raw_identities: list[str] = field(default_factory=list)


@dataclass
class _State:
    source_sha: str
    page_number: int
    raw_result: RawAuthorityResult
    policy: DecoderResourcePolicy
    started: float
    global_operation: int = 0
    text_show_ordinal: int = 0
    raw_stream_bytes: int = 0
    correlations: int = 0
    correlation_ambiguous: int = 0
    raw_token_count: int = 0
    active_forms: set[str] = field(default_factory=set)
    fonts: dict[str, ResolvedFont] = field(default_factory=dict)
    code_units: list[DecoderCodeUnit] = field(default_factory=list)
    codespaces: dict[str, DecoderCodeSpaceEvidence] = field(default_factory=dict)
    font_codes: list[DecoderFontCodeEvidence] = field(default_factory=list)
    cid_mappings: list[DecoderCIDMappingEvidence] = field(default_factory=list)
    gid_mappings: list[DecoderGIDMappingEvidence] = field(default_factory=list)
    unicode_sequences: list[DecoderUnicodeSequenceEvidence] = field(
        default_factory=list
    )
    steps: list[DecoderMappingStep] = field(default_factory=list)
    conflicts: list[DecoderMappingConflict] = field(default_factory=list)
    substitutions: list[ActualTextSubstitutionEvidence] = field(default_factory=list)
    marked_stack: list[_MarkedScope] = field(default_factory=list)
    limitations: set[str] = field(default_factory=set)
    unmapped: int = 0
    raw_only: int = 0
    lossy: int = 0
    ambiguous: int = 0
    reversible: int = 0
    resource_truncated: bool = False

    def limit(self, code: str) -> None:
        self.limitations.add(code)
        self.resource_truncated = True


def _peak_rss_bytes() -> int | None:
    try:
        value = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        return value if value > 10_000_000 else value * 1024
    except Exception:
        return None


def _model_digest(model: Any, field: str) -> str:
    payload = model.model_dump(mode="json")
    payload.pop(field, None)
    return canonical_sha256(payload)


def _codespace_contract(font: ResolvedFont) -> DecoderCodeSpaceEvidence:
    ranges = tuple(
        DecoderCodeRange(
            byte_length=len(item.lower),
            lower_bound_hex=item.lower.hex().upper(),
            upper_bound_hex=item.upper.hex().upper(),
            source_mapping_identity=item.identity,
            deterministic_ordinal=index,
        )
        for index, item in enumerate(font.codespaces)
    )
    overlap = 0
    for index, left in enumerate(ranges):
        for right in ranges[index + 1 :]:
            if (
                left.byte_length == right.byte_length
                and int(left.lower_bound_hex, 16) <= int(right.upper_bound_hex, 16)
                and int(right.lower_bound_hex, 16) <= int(left.upper_bound_hex, 16)
            ):
                overlap += 1
    widths = [item.byte_length for item in ranges]
    completeness = (
        MappingCompleteness.COMPLETE
        if ranges and not overlap
        else MappingCompleteness.UNSAFE
        if overlap
        else MappingCompleteness.UNAVAILABLE
    )
    limitations = tuple(
        sorted(
            ({"overlapping_codespace"} if overlap else set())
            | ({"codespace_unavailable"} if not ranges else set())
        )
    )
    values = dict(
        codespace_source=font.encoding_identity
        or ("embedded_cmap" if font.encoding_cmap else "tounicode"),
        font_identity=font.font_identity,
        encoding_cmap_identity=font.encoding_cmap.cmap_identity
        if font.encoding_cmap
        else None,
        usecmap_ancestry=(
            font.encoding_cmap.usecmap_names if font.encoding_cmap else ()
        ),
        code_ranges=ranges,
        minimum_code_bytes=min(widths) if widths else 0,
        maximum_code_bytes=max(widths) if widths else 0,
        variable_length=len(set(widths)) > 1,
        overlap_count=overlap,
        ambiguity_count=overlap,
        conflict_count=overlap,
        completeness=completeness,
        limitation_codes=limitations,
    )
    provisional = DecoderCodeSpaceEvidence.model_construct(
        **values,  # type: ignore[arg-type]
        codespace_version=DECODER_CONTRACT_VERSION,  # type: ignore[arg-type]
        evidence_digest="0" * 64,
    )
    return DecoderCodeSpaceEvidence(
        **values,  # type: ignore[arg-type]
        evidence_digest=_model_digest(provisional, "evidence_digest"),
    )


def _step(
    state: _State,
    *,
    input_identity: str,
    input_type: DecoderValueType,
    output_identity: str,
    output_type: DecoderValueType,
    method: DecoderMappingMethod,
    source_identity: str,
    binding: DecoderCodeUnit,
    font_identity: str,
    reversible: bool,
    lossy: bool = False,
    ambiguous: bool = False,
    conflict_count: int = 0,
    limitations: tuple[str, ...] = (),
) -> DecoderMappingStep | None:
    if len(state.steps) >= state.policy.max_mapping_steps:
        state.limit("mapping_step_bound_exceeded")
        return None
    values = dict(
        step_ordinal=len(state.steps),
        source_artifact_sha256=state.source_sha,
        original_page_number=state.page_number,
        content_path_identity=binding.content_path_identity,
        text_show_operation_identity=binding.text_show_operation_identity,
        font_identity=font_identity,
        input_identity=input_identity,
        input_type=input_type,
        output_identity=output_identity,
        output_type=output_type,
        method=method,
        source_evidence_identity=source_identity,
        reversible=reversible,
        lossy=lossy,
        ambiguous=ambiguous,
        conflict_count=conflict_count,
        limitation_codes=limitations,
    )
    provisional = DecoderMappingStep.model_construct(
        **values,  # type: ignore[arg-type]
        mapping_step_version=DECODER_CONTRACT_VERSION,  # type: ignore[arg-type]
        step_digest="0" * 64,
    )
    result = DecoderMappingStep(
        **values,  # type: ignore[arg-type]
        step_digest=_model_digest(provisional, "step_digest"),
    )
    state.steps.append(result)
    return result


def _unicode(
    state: _State,
    scalars: tuple[int, ...],
    *,
    source_identity: str,
    method: UnicodeMappingMethod,
    reversible: bool,
    limitations: tuple[str, ...] = (),
) -> DecoderUnicodeSequenceEvidence:
    result = DecoderUnicodeSequenceEvidence(
        source_mapping_step_identity=source_identity,
        unicode_scalar_sequence=scalars,
        unicode_sequence_digest=canonical_sha256(list(scalars)),
        scalar_count=len(scalars),
        mapping_method=method,
        reversible=reversible,
        lossy=not reversible,
        unmapped=not scalars,
        replacement_count=scalars.count(0xFFFD),
        invalid_scalar_count=0,
        limitation_codes=limitations,
    )
    state.unicode_sequences.append(result)
    return result


def _conflict(
    state: _State,
    conflict_type: ConflictType,
    source: str,
    competing: tuple[str, ...],
    reason: str,
) -> None:
    if len(state.conflicts) >= state.policy.max_mapping_conflicts:
        state.limit("mapping_conflict_bound_exceeded")
        return
    values = (
        competing
        if len(competing) >= 2
        else (
            competing[0] if competing else source,
            canonical_sha256({"missing": source}),
        )
    )
    state.conflicts.append(
        DecoderMappingConflict(
            conflict_type=conflict_type,
            source_identity=source,
            competing_mapping_identities=values,
            competing_output_digests=tuple(canonical_sha256(item) for item in values),
            conflict_count=len(values),
            resolution_status=ResolutionStatus.REJECTED,
            fail_closed_reason=reason,
            limitation_codes=(reason,),
        )
    )
    state.limitations.add(reason)


def _pypdf_string_bytes(value: Any) -> bytes | None:
    if isinstance(value, ByteStringObject):
        return bytes(value)
    if isinstance(value, TextStringObject):
        try:
            return value.get_original_bytes()
        except Exception:
            return None
    if isinstance(value, bytes):
        return value
    return None


def _pypdf_text_values(operands: list[Any], operator: bytes) -> list[bytes | None]:
    target = (
        operands[-1]
        if operator == b'"' and operands
        else operands[0]
        if operands
        else None
    )
    values = (
        target
        if operator == b"TJ" and isinstance(target, (list, ArrayObject))
        else [target]
    )
    return [
        _pypdf_string_bytes(item)
        for item in values
        if not isinstance(item, (int, float))
    ]


def _correlate(
    raw: RawLexedOperation, operands: list[Any], operator: bytes, raw_operation: Any
) -> bool:
    if raw.operator.encode("latin-1") != operator or raw.operand_count != len(operands):
        return False
    if (
        raw_operation.operator != raw.operator
        or raw_operation.operand_digest
        != canonical_sha256(_safe_operand(list(operands)))
    ):
        return False
    parsed = _pypdf_text_values(operands, operator)
    if len(parsed) != len(raw.string_tokens):
        return False
    # TextStringObject may normalize lexical bytes (for example by adding a
    # UTF-16 BOM).  The frozen Raw Authority operand digest plus exact stream
    # ordinal, operator, operand count, and token count proves correlation;
    # the independent lexer remains the byte authority.
    return True


def _mapping_for_source(cmap: Any, source: bytes) -> tuple[CMapMapping, ...]:
    return (
        tuple(item for item in cmap.mappings if item.source == source) if cmap else ()
    )


def _decode_token(
    state: _State,
    token: RawStringToken,
    font: ResolvedFont,
    path_id: str,
    operation_id: str,
) -> None:
    codespace = state.codespaces.setdefault(
        font.font_identity, _codespace_contract(font)
    )
    try:
        segments = segment_codes(
            token.decoded_bytes,
            font.codespaces,
            max_code_bytes=state.policy.max_code_bytes,
        )
    except CMapError as error:
        state.ambiguous += 1
        state.raw_only += 1
        state.limitations.add(str(error))
        return
    for start, end, raw_code in segments:
        status = (
            SegmentationStatus.PROVEN
            if codespace.completeness is MappingCompleteness.COMPLETE
            else SegmentationStatus.AMBIGUOUS
        )
        limitations = (
            ()
            if status is SegmentationStatus.PROVEN
            else ("ambiguous_code_segmentation",)
        )
        unit = DecoderCodeUnit(
            source_artifact_sha256=state.source_sha,
            original_page_number=state.page_number,
            content_path_identity=path_id,
            text_show_operation_identity=operation_id,
            operand_index=token.operand_index,
            raw_operand_digest=token.decoded_operand_digest,
            raw_code_start=start,
            raw_code_end_exclusive=end,
            raw_code_length_bytes=end - start,
            raw_code_hex=raw_code.hex().upper(),
            code_width_bytes=end - start,
            codespace_identity=codespace.evidence_digest
            if status is SegmentationStatus.PROVEN
            else None,
            segmentation_method="codespace_range",
            segmentation_status=status,
            deterministic_ordinal=len(state.code_units),
            limitation_codes=limitations,
        )
        state.code_units.append(unit)
        for scope in state.marked_stack:
            scope.raw_identities.append(unit.evidence_identity)
        font_value = int.from_bytes(raw_code, "big")
        font_code = DecoderFontCodeEvidence(
            font_identity=font.font_identity,
            raw_code_identity=unit.evidence_identity,
            font_code_value=font_value,
            font_code_hex=raw_code.hex().upper(),
            font_code_width=len(raw_code),
            encoding_method=font.encoding_identity or font.subtype,
            encoding_source_identity=font.encoding_cmap.cmap_identity
            if font.encoding_cmap
            else font.font_identity,
            differences_entry_identity=dict(font.differences_identities).get(
                font_value
            ),
            unicode_mapping_eligibility="eligible"
            if font.to_unicode or font_value in font.simple_map
            else "unknown",
            limitation_codes=(),
        )
        state.font_codes.append(font_code)
        if font.subtype != "/Type0":
            first = _step(
                state,
                input_identity=unit.evidence_identity,
                input_type=DecoderValueType.RAW_CODE,
                output_identity=font_code.evidence_identity,
                output_type=DecoderValueType.FONT_CODE,
                method=DecoderMappingMethod.RAW_SEGMENTATION,
                source_identity=codespace.evidence_digest,
                binding=unit,
                font_identity=font.font_identity,
                reversible=True,
            )
            if first is None:
                return
        cid_identity = None
        if font.subtype == "/Type0":
            cid_entries = _mapping_for_source(font.encoding_cmap, raw_code)
            if font.encoding_identity in {"/Identity-H", "/Identity-V"}:
                cid = font_value
                cid_method = (
                    CIDMappingMethod.IDENTITY_H
                    if font.encoding_identity == "/Identity-H"
                    else CIDMappingMethod.IDENTITY_V
                )
                entry_identity = canonical_sha256(
                    {"identity": font.encoding_identity, "code": font_value}
                )
            elif len(cid_entries) == 1 and cid_entries[0].cid is not None:
                cid = cid_entries[0].cid
                cid_method = (
                    CIDMappingMethod.CIDCHAR
                    if cid_entries[0].method == "cidchar"
                    else CIDMappingMethod.CIDRANGE
                )
                entry_identity = cid_entries[0].entry_identity
            else:
                state.raw_only += 1
                state.limitations.add("cid_mapping_unavailable")
                cid = None
            if cid is not None:
                cid_evidence = DecoderCIDMappingEvidence(
                    source_code_identity=font_code.evidence_identity,
                    cid_value=cid,
                    cid_system_info_identity=font.cid_system_info_identity
                    or "unavailable",
                    encoding_cmap_identity=font.encoding_cmap.cmap_identity
                    if font.encoding_cmap
                    else (font.encoding_identity or "unavailable"),
                    mapping_entry_identity=entry_identity,  # pyright: ignore[reportPossiblyUnboundVariable]
                    mapping_method=cid_method,  # pyright: ignore[reportPossiblyUnboundVariable]
                    mapping_completeness=MappingCompleteness.COMPLETE,
                    conflict_status="none",
                    limitation_codes=(),
                )
                state.cid_mappings.append(cid_evidence)
                cid_identity = cid_evidence.evidence_identity
                _step(
                    state,
                    input_identity=unit.evidence_identity,
                    input_type=DecoderValueType.RAW_CODE,
                    output_identity=cid_identity,
                    output_type=DecoderValueType.CID,
                    method=DecoderMappingMethod.CODE_TO_CID,
                    source_identity=entry_identity,  # pyright: ignore[reportPossiblyUnboundVariable]
                    binding=unit,
                    font_identity=font.font_identity,
                    reversible=True,
                )
                gid = None
                gid_method = "unavailable"
                gid_limit = ("cid_to_gid_map_unavailable",)
                if font.cid_to_gid_identity == "identity":
                    gid = cid
                    gid_method = "identity"
                    gid_limit = ()  # type: ignore[assignment]
                elif font.cid_to_gid_bytes is not None and cid * 2 + 2 <= len(
                    font.cid_to_gid_bytes
                ):
                    gid = int.from_bytes(
                        font.cid_to_gid_bytes[cid * 2 : cid * 2 + 2], "big"
                    )
                    gid_method = "cid_to_gid_map"
                    gid_limit = ()  # type: ignore[assignment]
                gid_evidence = DecoderGIDMappingEvidence(
                    cid_identity=cid_identity,
                    gid_value=gid,
                    cid_to_gid_map_identity=font.cid_to_gid_identity,
                    mapping_method=gid_method,  # type: ignore[arg-type]
                    mapping_completeness=MappingCompleteness.COMPLETE
                    if gid is not None
                    else MappingCompleteness.UNAVAILABLE,
                    limitation_codes=gid_limit,
                )
                state.gid_mappings.append(gid_evidence)
                # GID is retained as glyph provenance. It is not a Unicode
                # prerequisite and therefore does not consume a page-level
                # Unicode mapping-chain step.
        unicode_entries = _mapping_for_source(font.to_unicode, raw_code)
        scalars = None
        method = None
        source_mapping = None
        if len(unicode_entries) == 1 and unicode_entries[0].unicode_scalars is not None:
            scalars = unicode_entries[0].unicode_scalars
            method = {
                "bfchar": UnicodeMappingMethod.TOUNICODE_BFCHAR,
                "bfrange_scalar": UnicodeMappingMethod.TOUNICODE_BFRANGE_SCALAR,
                "bfrange_array": UnicodeMappingMethod.TOUNICODE_BFRANGE_ARRAY,
            }[unicode_entries[0].method]
            source_mapping = unicode_entries[0].entry_identity
        elif len(unicode_entries) > 1:
            _conflict(
                state,
                ConflictType.MULTIPLE_UNICODE_OUTPUTS,
                unit.evidence_identity,
                tuple(item.entry_identity for item in unicode_entries),
                "multiple_unicode_outputs",
            )
        elif font.subtype != "/Type0":
            scalars = font.simple_map.get(font_value)
            method = (
                UnicodeMappingMethod.DIFFERENCES_GLYPH_NAME
                if font_code.differences_entry_identity
                else UnicodeMappingMethod.SIMPLE_ENCODING
            )
            source_mapping = font_code.differences_entry_identity or font.font_identity
        if scalars is None:
            state.unmapped += 1
            state.raw_only += 1
            state.limitations.add("unicode_mapping_unavailable")
            continue
        unicode_item = _unicode(
            state,
            scalars,
            source_identity=source_mapping or font.font_identity,
            method=method,  # type: ignore[arg-type]
            reversible=True,
        )
        input_identity = (
            unit.evidence_identity if font.to_unicode else font_code.evidence_identity
        )
        input_type = (
            DecoderValueType.RAW_CODE if font.to_unicode else DecoderValueType.FONT_CODE
        )
        step_method = (
            DecoderMappingMethod.TOUNICODE
            if font.to_unicode
            else DecoderMappingMethod.DIFFERENCES
            if font_code.differences_entry_identity
            else DecoderMappingMethod.SIMPLE_ENCODING
        )
        if _step(
            state,
            input_identity=input_identity,
            input_type=input_type,
            output_identity=unicode_item.evidence_identity,
            output_type=DecoderValueType.UNICODE_SEQUENCE,
            method=step_method,
            source_identity=source_mapping or font.font_identity,
            binding=unit,
            font_identity=font.font_identity,
            reversible=True,
        ):
            state.reversible += 1


def _property_actualtext(
    operands: list[Any], resources: Any, *, context: PdfObjectIdentityContext
) -> tuple[bytes | None, int | None, str]:
    if len(operands) < 2:
        return None, None, canonical_sha256(None)
    prop = operands[1]
    if isinstance(prop, (NameObject, str)):
        try:
            prop = (resources or {}).get("/Properties", {}).get(str(prop))
            prop = prop.get_object() if prop is not None else None
        except Exception:
            prop = None
    if not isinstance(prop, (DictionaryObject, dict)):
        return None, None, canonical_pdf_object_digest(operands[1], context=context)
    actual = _pypdf_string_bytes(prop.get("/ActualText"))
    mcid = prop.get("/MCID")
    return (
        actual,
        int(mcid) if isinstance(mcid, (int, float)) and int(mcid) >= 0 else None,
        canonical_pdf_object_digest(prop, context=context),
    )


def _close_scope(state: _State, end_operation: int) -> None:
    if not state.marked_stack:
        state.limitations.add("unbalanced_emc")
        return
    scope = state.marked_stack.pop()
    if scope.actualtext_bytes is None:
        return
    try:
        scalars = decode_actualtext_bytes(scope.actualtext_bytes)
    except FontDecodeError:
        state.limitations.add("actualtext_decode_failed")
        return
    unicode_item = _unicode(
        state,
        scalars,
        source_identity=scope.property_identity,
        method=UnicodeMappingMethod.ACTUALTEXT,
        reversible=False,
        limitations=("actualtext_requires_raw_agreement",),
    )
    if not scope.raw_identities:
        state.limitations.add("actualtext_scope_empty")
        return
    state.substitutions.append(
        ActualTextSubstitutionEvidence(
            marked_content_path_identity=scope.path_identity,
            source_operation_start=scope.start_operation,
            source_operation_end_exclusive=max(
                end_operation, scope.start_operation + 1
            ),
            raw_glyph_code_identities=tuple(scope.raw_identities),
            actualtext_raw_digest=sha256(scope.actualtext_bytes).hexdigest(),
            actualtext_unicode_evidence_identity=unicode_item.evidence_identity,
            substitution_scope="marked_content_range",
            nesting_depth=len(state.marked_stack),
            mcid=scope.mcid,
            property_source_identity=scope.property_identity,
            raw_actualtext_agreement="unknown",
            reversible=False,
            lossy=True,
            conflict_count=0,
            limitation_codes=("actualtext_raw_agreement_unproven",),
        )
    )
    state.limitations.add("actualtext_raw_agreement_unproven")


def _traverse(
    *,
    reader: PdfReader,
    streams: list[Any],
    resources: Any,
    state: _State,
    raw_operations: tuple[Any, ...],
    root_stream_ordinal: int = 0,
    form_path: tuple[str, ...] = (),
    depth: int = 0,
    active_font: str | None = None,
) -> str | None:
    for stream_index, stream_ref in enumerate(streams):
        try:
            content = ContentStream(stream_ref, reader)
            data = content.get_data()
            lexed = lex_content_stream(data, policy=state.policy)
        except (RawLexerError, Exception) as error:
            state.limitations.add(
                str(error)
                if isinstance(error, RawLexerError)
                else "content_stream_unavailable"
            )
            continue
        state.raw_stream_bytes += len(data)
        state.raw_token_count += lexed.token_count
        if len(lexed.operations) != len(content.operations):
            state.correlation_ambiguous += 1
            state.limitations.add("operation_count_mismatch")
            return active_font
        for local, (operands, operator) in enumerate(content.operations):
            op = bytes(operator)
            rawlex = lexed.operations[local]
            if state.global_operation >= len(raw_operations):
                state.correlation_ambiguous += 1
                state.limitations.add("raw_authority_operation_missing")
                return active_font
            rawop = raw_operations[state.global_operation]
            path = CanonicalContentPath(
                content_stream_object_identity=object_identity(stream_ref),
                content_stream_ordinal=root_stream_ordinal + stream_index,
                form_xobject_path=form_path,
                recursion_depth=depth,
                text_show_operation_ordinal=state.text_show_ordinal
                if op in TEXT_SHOW
                else None,
                availability="available" if op in TEXT_SHOW else "unknown",
            )
            path_id = canonical_sha256(path.model_dump(mode="json"))
            operation_id = canonical_sha256(
                {
                    "path": path_id,
                    "operand": canonical_sha256(_safe_operand(list(operands))),
                }
            )
            if (
                rawlex.operator != op.decode("latin-1")
                or rawop.global_ordinal != state.global_operation
                or rawop.local_ordinal != local
                or rawop.operator != op.decode("latin-1")
            ):
                state.correlation_ambiguous += 1
                state.limitations.add("operation_correlation_ambiguous")
                return active_font
            state.global_operation += 1
            if op == b"Tf" and operands:
                active_font = str(operands[0])
            elif op in {b"BMC", b"BDC"}:
                object_context = PdfObjectIdentityContext(
                    source_artifact_sha256=state.source_sha,
                    document_identity=state.raw_result.bundle.authority_identity.document_identity,  # type: ignore[union-attr]
                    original_page_number=state.page_number,
                    content_path_identity=path_id,
                )
                actual, mcid, prop_id = (
                    _property_actualtext(
                        list(operands), resources, context=object_context
                    )
                    if op == b"BDC"
                    else (
                        None,
                        None,
                        canonical_sha256({"tag": str(operands[0]) if operands else ""}),
                    )
                )
                state.marked_stack.append(
                    _MarkedScope(
                        canonical_sha256(
                            {
                                "parent": [
                                    item.path_identity for item in state.marked_stack
                                ],
                                "operation": state.global_operation - 1,
                                "property": prop_id,
                            }
                        ),
                        state.global_operation - 1,
                        actual,
                        mcid,
                        prop_id,
                    )
                )
            elif op == b"EMC":
                _close_scope(state, state.global_operation)
            if op in TEXT_SHOW:
                state.text_show_ordinal += 1
                if not _correlate(rawlex, list(operands), op, rawop):
                    state.correlation_ambiguous += 1
                    state.limitations.add("operation_correlation_ambiguous")
                    continue
                state.correlations += 1
                if active_font is None:
                    state.limitations.add("active_font_unavailable")
                    state.raw_only += len(rawlex.string_tokens)
                    continue
                cache_key = canonical_sha256(
                    {
                        "resources": object_identity(resources)
                        or canonical_sha256(
                            sorted(str(key) for key in (resources or {}))
                        ),
                        "name": active_font,
                    }
                )
                font = state.fonts.get(cache_key)
                if font is None:
                    if len(state.fonts) >= state.policy.max_font_objects_per_page:
                        state.limit("font_object_bound_exceeded")
                        continue
                    try:
                        font = resolve_font(
                            resources,
                            active_font,
                            source_artifact_sha256=state.source_sha,
                            document_identity=state.raw_result.bundle.authority_identity.document_identity,  # type: ignore[union-attr]
                            original_page_number=state.page_number,
                            content_path_identity=path_id,
                            policy=state.policy,
                        )
                        state.fonts[cache_key] = font
                    except FontDecodeError as error:
                        state.limitations.add(str(error))
                        state.raw_only += len(rawlex.string_tokens)
                        continue
                for token in rawlex.string_tokens:
                    _decode_token(state, token, font, path_id, operation_id)
            elif op == b"Do" and operands:
                name = str(operands[0])
                try:
                    xmap = (resources or {}).get("/XObject") or {}
                    xref = xmap.get(name)
                    xobj = xref.get_object() if xref is not None else None
                except Exception:
                    xref = xobj = None
                if xobj is None or str(xobj.get("/Subtype") or "") != "/Form":
                    continue
                form_id = object_identity(xref) or canonical_sha256(
                    {"name": name, "path": form_path}
                )
                if form_id in state.active_forms:
                    state.limitations.add("recursive_xobject")
                    continue
                state.active_forms.add(form_id)
                child_resources = xobj.get("/Resources") or resources
                _traverse(
                    reader=reader,
                    streams=[xref],
                    resources=child_resources,
                    state=state,
                    raw_operations=raw_operations,
                    root_stream_ordinal=root_stream_ordinal + stream_index,
                    form_path=form_path
                    + (f"{name}@{state.global_operation - 1}:{form_id}",),
                    depth=depth + 1,
                    active_font=active_font,
                )
                state.active_forms.discard(form_id)
    return active_font


def _inventory(
    state: _State, completeness: DecoderCompleteness
) -> DecoderEvidenceInventory:
    usage = DecoderResourceUsage(
        code_unit_count=len(state.code_units),
        mapping_step_count=len(state.steps),
        conflict_count=len(state.conflicts),
        serialized_bytes=0,
        resource_truncated=state.resource_truncated,
    )
    values = dict(
        authority_identity_digest=canonical_sha256(
            state.raw_result.bundle.authority_identity.model_dump(mode="json")  # type: ignore[union-attr]
        ),
        code_units=tuple(state.code_units),
        codespaces=tuple(
            sorted(state.codespaces.values(), key=lambda item: item.font_identity)
        ),
        font_codes=tuple(state.font_codes),
        cid_mappings=tuple(state.cid_mappings),
        gid_mappings=tuple(state.gid_mappings),
        unicode_sequences=tuple(state.unicode_sequences),
        mapping_steps=tuple(state.steps),
        conflicts=tuple(state.conflicts),
        actualtext_substitutions=tuple(state.substitutions),
        limitation_inventory=tuple(sorted(state.limitations)),
        completeness=completeness,
        resource_usage=usage,
    )
    provisional = DecoderEvidenceInventory.model_construct(
        **values,  # type: ignore[arg-type]
        inventory_version=DECODER_CONTRACT_VERSION,  # type: ignore[arg-type]
        inventory_digest="0" * 64,
    )
    estimated = len(canonical_json_bytes(provisional.model_dump(mode="json")))
    values["resource_usage"] = usage.model_copy(
        update={
            "serialized_bytes": min(estimated, state.policy.max_decoder_inventory_bytes)
        }
    )
    provisional = DecoderEvidenceInventory.model_construct(
        **values,  # type: ignore[arg-type]
        inventory_version=DECODER_CONTRACT_VERSION,  # type: ignore[arg-type]
        inventory_digest="0" * 64,
    )
    return DecoderEvidenceInventory(
        **values,  # type: ignore[arg-type]
        inventory_digest=_model_digest(provisional, "inventory_digest"),
    )


def _v2(
    raw: RawAuthorityResult, inventory: DecoderEvidenceInventory
) -> CanonicalEvidenceBundleV2:
    v1 = raw.bundle
    values = dict(
        authority_identity=v1.authority_identity,  # type: ignore[union-attr]
        content_paths=v1.content_paths,  # type: ignore[union-attr]
        glyph_evidence=v1.glyph_evidence,  # type: ignore[union-attr]
        canonical_stream_digest=v1.canonical_stream_digest,  # type: ignore[union-attr]
        mapping_segments=v1.mapping_segments,  # type: ignore[union-attr]
        parser_lineage=v1.parser_lineage,  # type: ignore[union-attr]
        limitation_codes=v1.limitation_codes,  # type: ignore[union-attr]
        resource_policy=v1.resource_policy,  # type: ignore[union-attr]
        generation_completeness=v1.generation_completeness,  # type: ignore[union-attr]
        decoder_evidence=inventory,
        decoder_evidence_digest=inventory.inventory_digest,
        decoder_provenance_completeness=inventory.completeness,
        v1_compatibility_reference=v1.bundle_digest,  # type: ignore[union-attr]
    )
    provisional = CanonicalEvidenceBundleV2.model_construct(
        **values,  # type: ignore[arg-type]
        bundle_contract_version=CANONICAL_EVIDENCE_BUNDLE_V2_VERSION,  # type: ignore[arg-type]
        bundle_v2_digest="0" * 64,
    )
    return CanonicalEvidenceBundleV2(
        **values,  # type: ignore[arg-type]
        bundle_v2_digest=_model_digest(provisional, "bundle_v2_digest"),
    )


def _empty_decoder_metrics(*, elapsed_ms: float = 0) -> DecoderMetrics:
    return DecoderMetrics(
        raw_stream_bytes=0,
        text_show_operation_count=0,
        raw_token_count=0,
        operation_correlation_success_count=0,
        operation_correlation_ambiguous_count=0,
        font_count=0,
        font_subtypes=(),
        tounicode_count=0,
        encoding_cmap_count=0,
        identity_h_count=0,
        identity_v_count=0,
        codespace_count=0,
        code_unit_count=0,
        cid_mapping_count=0,
        gid_mapping_count=0,
        unicode_evidence_count=0,
        actualtext_scope_count=0,
        actualtext_substitution_count=0,
        unmapped_code_count=0,
        raw_only_count=0,
        lossy_count=0,
        conflict_count=0,
        ambiguous_segmentation_count=0,
        mapping_step_count=0,
        reversible_code_count=0,
        elapsed_ms=elapsed_ms,
        peak_rss_bytes=None,
        serialized_inventory_bytes=0,
    )


def _build_strict_decoder_evidence_unisolated(
    *,
    source_bytes: bytes,
    expected_source_sha256: str,
    original_page_number: int,
    raw_authority_result: RawAuthorityResult,
    policy: DecoderResourcePolicy = EXPERIMENTAL_CTIF1B_DECODER_POLICY,
) -> StrictDecoderResult:
    started = perf_counter()
    empty = _empty_decoder_metrics()
    actual = sha256(source_bytes).hexdigest()
    if actual != expected_source_sha256 or raw_authority_result.bundle is None:
        return StrictDecoderResult(
            DecoderCompleteness.UNAVAILABLE,
            None,
            None,
            ("source_or_raw_authority_unavailable",),
            empty,
        )
    identity = raw_authority_result.bundle.authority_identity
    if (
        identity.source_artifact_sha256 != actual
        or identity.original_page_number != original_page_number
    ):
        return StrictDecoderResult(
            DecoderCompleteness.UNSAFE, None, None, ("source_or_page_mismatch",), empty
        )
    if identity.generation_mode is CanonicalAuthorityMode.OFF:
        return StrictDecoderResult(
            DecoderCompleteness.UNAVAILABLE, None, None, ("authority_off",), empty
        )
    try:
        from .safe_reader import open_ctif_pdf_reader

        reader, empty_password_decryption = open_ctif_pdf_reader(source_bytes)
        page = reader.pages[original_page_number - 1]
    except Exception:
        return StrictDecoderResult(
            DecoderCompleteness.UNAVAILABLE,
            None,
            None,
            ("pdf_or_page_unavailable",),
            empty,
        )
    contents = page.get("/Contents")
    streams = (
        list(contents)
        if isinstance(contents, ArrayObject)
        else [contents]
        if contents is not None
        else []
    )
    resources = page.get("/Resources") or {}
    state = _State(actual, original_page_number, raw_authority_result, policy, started)
    if empty_password_decryption:
        state.limitations.add("empty_password_decryption_applied")
    _traverse(
        reader=reader,
        streams=streams,
        resources=resources,
        state=state,
        raw_operations=raw_authority_result.operations,
    )
    while state.marked_stack:
        state.limitations.add("unclosed_marked_content")
        _close_scope(state, state.global_operation)
    elapsed = (perf_counter() - started) * 1000
    if elapsed > policy.max_decoder_elapsed_ms_per_page:
        state.limit("decoder_elapsed_bound_exceeded")
    if _peak_rss_bytes() and _peak_rss_bytes() > policy.max_decoder_peak_rss_bytes:  # type: ignore[operator]
        state.limit("decoder_rss_bound_exceeded")
    if raw_authority_result.bundle.generation_completeness != "complete":
        state.limitations.add("raw_authority_generation_not_complete")
    if state.correlation_ambiguous:
        completeness = DecoderCompleteness.UNSAFE
    elif (
        state.limitations
        or state.conflicts
        or state.unmapped
        or state.raw_only
        or state.resource_truncated
    ):
        completeness = DecoderCompleteness.PARTIAL
    elif state.code_units:
        completeness = DecoderCompleteness.COMPLETE
    else:
        completeness = DecoderCompleteness.UNAVAILABLE
    try:
        inventory = _inventory(state, completeness)
        bundle = _v2(raw_authority_result, inventory)
    except Exception as error:
        return StrictDecoderResult(
            DecoderCompleteness.UNSAFE,
            None,
            None,
            tuple(
                sorted(
                    state.limitations
                    | {f"decoder_inventory_validation_failed_{type(error).__name__}"}
                )
            ),
            empty,
        )
    font_values = tuple(state.fonts.values())
    metrics = DecoderMetrics(
        state.raw_stream_bytes,
        state.text_show_ordinal,
        state.raw_token_count,
        state.correlations,
        state.correlation_ambiguous,
        len(font_values),
        tuple(sorted(set(item.subtype for item in font_values))),
        sum(item.to_unicode is not None for item in font_values),
        sum(item.encoding_cmap is not None for item in font_values),
        sum(item.encoding_identity == "/Identity-H" for item in font_values),
        sum(item.encoding_identity == "/Identity-V" for item in font_values),
        len(state.codespaces),
        len(state.code_units),
        len(state.cid_mappings),
        len(state.gid_mappings),
        len(state.unicode_sequences),
        len(state.substitutions),
        len(state.substitutions),
        state.unmapped,
        state.raw_only,
        state.lossy,
        len(state.conflicts),
        state.ambiguous,
        len(state.steps),
        state.reversible,
        elapsed,
        _peak_rss_bytes(),
        inventory.resource_usage.serialized_bytes,
    )
    return StrictDecoderResult(
        completeness, inventory, bundle, tuple(sorted(state.limitations)), metrics
    )


def build_strict_decoder_evidence(
    *,
    source_bytes: bytes,
    expected_source_sha256: str,
    original_page_number: int,
    raw_authority_result: RawAuthorityResult,
    policy: DecoderResourcePolicy = EXPERIMENTAL_CTIF1B_DECODER_POLICY,
) -> StrictDecoderResult:
    """Decode in a disposable child with preventive wall and memory limits."""
    from .runtime_adapter import run_strict_decoder

    outcome = run_strict_decoder(
        source_bytes=source_bytes,
        expected_source_sha256=expected_source_sha256,
        original_page_number=original_page_number,
        raw_authority_result=raw_authority_result,
        decoder_policy=policy,
    )
    if outcome.outcome == "completed" and isinstance(
        outcome.value, StrictDecoderResult
    ):
        return outcome.value
    limitation = outcome.limitation_code or "ctif_runtime_worker_failed"
    status = (
        DecoderCompleteness.UNAVAILABLE
        if outcome.outcome
        in {
            "timeout",
            "resource_exceeded",
            "dependency_unavailable",
            "runtime_unavailable",
        }
        else DecoderCompleteness.UNSAFE
    )
    return StrictDecoderResult(
        status,
        None,
        None,
        (limitation,),
        _empty_decoder_metrics(elapsed_ms=outcome.elapsed_milliseconds),
    )

"""Private deterministic CTIF canonical-identity core."""

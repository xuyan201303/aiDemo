"""Experimental CTIF-1B decoder resource policy."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class DecoderResourcePolicy(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    policy_version: str = "ctif1b_decoder_policy.experimental.v1"
    experimental: bool = True
    max_font_objects_per_page: int = Field(default=256, ge=1)
    max_raw_stream_bytes: int = Field(default=32 * 1024 * 1024, ge=1)
    max_text_tokens_per_page: int = Field(default=32_768, ge=1)
    max_raw_token_bytes: int = Field(default=64 * 1024, ge=1)
    max_cmap_bytes: int = Field(default=4 * 1024 * 1024, ge=1)
    max_tounicode_bytes: int = Field(default=4 * 1024 * 1024, ge=1)
    max_codespace_ranges: int = Field(default=1_024, ge=1)
    max_bfchar_entries: int = Field(default=65_536, ge=1)
    max_bfrange_entries: int = Field(default=16_384, ge=1)
    max_range_expansion: int = Field(default=65_536, ge=1)
    max_usecmap_depth: int = Field(default=8, ge=0)
    max_code_bytes: int = Field(default=8, ge=1, le=32)
    max_decoded_scalars_per_code: int = Field(default=64, ge=1, le=64)
    max_actualtext_scalars: int = Field(default=4_096, ge=1)
    max_mapping_steps: int = Field(default=4_096, ge=1, le=4_096)
    max_mapping_conflicts: int = Field(default=1_024, ge=1)
    max_decoder_inventory_bytes: int = Field(default=16 * 1024 * 1024, ge=1)
    max_decoder_elapsed_ms_per_page: int = Field(default=10_000, ge=1)
    max_decoder_peak_rss_bytes: int = Field(default=2_000_000_000, ge=1)
    max_lexer_nesting: int = Field(default=64, ge=1)
    max_escape_count: int = Field(default=262_144, ge=1)
    max_tj_elements: int = Field(default=65_536, ge=1)
    max_malformed_tokens: int = Field(default=256, ge=0)


EXPERIMENTAL_CTIF1B_DECODER_POLICY = DecoderResourcePolicy()

# ruff: noqa: ANN001, C901, E501, PLR0911, PLR0912, PLR0913, PLR0915, PLR0917, PLR2004, PLW2901, TC001
"""CTIF-4 bounded strict source-to-PDFium canonical alignment."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from .operation_provenance import OperationProvenanceBundle
from .pdfium_lineage import PdfiumCharacterEvidence, PdfiumLineageBundle
from .serialization import canonical_sha256
from .source_lineage import SourceFactLineageEvidence, SourceLineageBundle

CROSS_PARSER_ALIGNMENT_VERSION = "ctif_cross_parser_alignment.v1"
CROSS_PARSER_ALIGNMENT_POLICY = "ctif_cross_parser_alignment.bounded.v1"


def _text_digest(value: str) -> str:
    from hashlib import sha256

    return sha256(value.encode("utf-8")).hexdigest()


_WHITESPACE_DIGESTS = frozenset(
    _text_digest(value) for value in (" ", "\t", "\r", "\n", "\u00a0", "\u3000")
)


class _Frozen(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class CrossParserAlignmentEvidence(_Frozen):
    alignment_version: str = CROSS_PARSER_ALIGNMENT_VERSION
    source_artifact_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    document_identity: str = Field(min_length=1)
    original_page_number: int = Field(gt=0)
    page_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    source_parser_identity: str
    source_parser_configuration_identity: str
    selected_parser_identity: str
    selected_parser_configuration_identity: str
    source_lineage_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    canonical_operation_identities: tuple[str, ...]
    operation_provenance_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    canonical_decoder_code_identities: tuple[str, ...]
    selected_character_start: int = Field(ge=0)
    selected_character_end_exclusive: int = Field(gt=0)
    selected_character_identities: tuple[str, ...]
    selected_parent_text_object_identities: tuple[str, ...]
    mapping_shape: Literal["one_to_one", "one_to_many", "many_to_one", "subspan"]
    ordering_transform: Literal["identity", "rotation_reversed"]
    normalization_transformations: tuple[
        Literal["tracked_whitespace_elision"], ...
    ] = ()
    source_whitespace_character_count: int = Field(ge=0)
    selected_whitespace_character_count: int = Field(ge=0)
    lookup_method: Literal[
        "canonical_bound_exact_context", "canonical_bound_unique_occurrence"
    ]
    candidate_count: int = Field(ge=1)
    qualified_candidate_count: Literal[1] = 1
    ambiguity_count: Literal[0] = 0
    context_character_count: int = Field(ge=0)
    geometry_consistent: Literal[True] = True
    policy_identity: str = CROSS_PARSER_ALIGNMENT_POLICY
    alignment_identity: str = Field(pattern=r"^[0-9a-f]{64}$")


class CrossParserAlignmentResult(_Frozen):
    decision: Literal[
        "CROSS_PARSER_ALIGNMENT_PROVEN",
        "SOURCE_LINEAGE_UNAVAILABLE",
        "SELECTED_SEQUENCE_UNAVAILABLE",
        "CANONICAL_CONTEXT_UNPROVEN",
        "AMBIGUOUS_FAIL_CLOSED",
        "GEOMETRY_INCONSISTENT",
        "SOURCE_PAGE_MISMATCH",
        "RESOURCE_BOUND_EXCEEDED",
    ]
    evidence: CrossParserAlignmentEvidence | None = None
    candidate_count: int = Field(default=0, ge=0)
    qualified_candidate_count: int = Field(default=0, ge=0)
    ambiguity_count: int = Field(default=0, ge=0)
    limitation_codes: tuple[str, ...] = ()


def _union(
    boxes: list[tuple[str, str, str, str] | None],
) -> tuple[float, float, float, float] | None:
    values = [tuple(float(v) for v in box) for box in boxes if box is not None]
    if not values:
        return None
    return (
        min(v[0] for v in values),
        min(v[1] for v in values),
        max(v[2] for v in values),
        max(v[3] for v in values),
    )


def _geometry_consistent(
    source_boxes: list[tuple[str, str, str, str] | None],
    selected_boxes: list[tuple[str, str, str, str] | None],
) -> bool:
    left, right = _union(source_boxes), _union(selected_boxes)
    if left is None or right is None:
        return False
    ix0, iy0, ix1, iy1 = (
        max(left[0], right[0]),
        max(left[1], right[1]),
        min(left[2], right[2]),
        min(left[3], right[3]),
    )
    intersection = max(0.0, ix1 - ix0) * max(0.0, iy1 - iy0)
    area_left = max(0.0, left[2] - left[0]) * max(0.0, left[3] - left[1])
    area_right = max(0.0, right[2] - right[0]) * max(0.0, right[3] - right[1])
    union = area_left + area_right - intersection
    if union > 0 and intersection / union >= 0.2:
        return True
    left_center = ((left[0] + left[2]) / 2, (left[1] + left[3]) / 2)
    right_center = ((right[0] + right[2]) / 2, (right[1] + right[3]) / 2)
    scale = max(
        left[2] - left[0],
        left[3] - left[1],
        right[2] - right[0],
        right[3] - right[1],
        1.0,
    )
    return (  # type: ignore[no-any-return]
        (left_center[0] - right_center[0]) ** 2
        + (left_center[1] - right_center[1]) ** 2
    ) ** 0.5 <= scale * 0.35


def _rotate_box(
    box: tuple[str, str, str, str] | None,
    rotation: int,
    media_box: tuple[str, str, str, str],
) -> tuple[str, str, str, str] | None:
    if box is None or rotation % 360 == 0:
        return box
    x0, y0, x1, y1 = map(float, box)
    mx0, my0, mx1, my1 = map(float, media_box)
    width, height = mx1 - mx0, my1 - my0
    points = []
    for x, y in ((x0, y0), (x0, y1), (x1, y0), (x1, y1)):
        x -= mx0
        y -= my0
        if rotation % 360 == 90:
            point = (y, width - x)
        elif rotation % 360 == 180:
            point = (width - x, height - y)
        elif rotation % 360 == 270:
            point = (height - y, x)
        else:
            return None
        points.append(point)
    return tuple(
        str(value)
        for value in (
            min(p[0] for p in points),
            min(p[1] for p in points),
            max(p[0] for p in points),
            max(p[1] for p in points),
        )
    )  # type: ignore[return-value]


def _context_matches(  # type: ignore[no-untyped-def]
    source_all,
    fact_positions: set[int],
    selected_native,
    start: int,
    length: int,
    bound: int,
) -> int:
    first, last = min(fact_positions), max(fact_positions)
    before = [
        item.text_digest for item in selected_native[max(0, start - bound) : start]
    ]
    after = [
        item.text_digest
        for item in selected_native[start + length : start + length + bound]
    ]
    source_before = [
        item.unicode_digest
        for item in source_all[max(0, first - bound) : first]
        if item.proof_method != "UNPROVEN"
    ]
    source_after = [
        item.unicode_digest
        for item in source_all[last + 1 : last + 1 + bound]
        if item.proof_method != "UNPROVEN"
    ]
    matched = 0
    for amount in range(min(len(before), len(source_before)), 0, -1):
        if before[-amount:] == source_before[-amount:]:
            matched += amount
            break
    for amount in range(min(len(after), len(source_after)), 0, -1):
        if after[:amount] == source_after[:amount]:
            matched += amount
            break
    return matched


def align_source_fact_to_pdfium(
    *,
    source_bundle: SourceLineageBundle,
    source_fact: SourceFactLineageEvidence,
    selected_bundle: PdfiumLineageBundle,
    operation_provenance: OperationProvenanceBundle,
    document_identity: str,
    page_identity: str,
    maximum_candidates: int = 256,
    context_bound: int = 16,
) -> CrossParserAlignmentResult:
    if (
        source_bundle.source_artifact_sha256 != selected_bundle.source_artifact_sha256
        or operation_provenance.source_artifact_sha256
        != selected_bundle.source_artifact_sha256
        or source_bundle.original_page_number != selected_bundle.original_page_number
        or operation_provenance.original_page_number
        != selected_bundle.original_page_number
        or selected_bundle.document_identity != document_identity
        or operation_provenance.document_identity != document_identity
        or selected_bundle.page_identity != page_identity
        or operation_provenance.page_identity != page_identity
    ):
        return CrossParserAlignmentResult(
            decision="SOURCE_PAGE_MISMATCH",
            limitation_codes=("source_page_identity_mismatch",),
        )
    if source_fact.decision != "SOURCE_LINEAGE_PROVEN":
        return CrossParserAlignmentResult(
            decision="SOURCE_LINEAGE_UNAVAILABLE",
            limitation_codes=("strict_source_lineage_required",),
        )
    source_by_id = {item.character_identity: item for item in source_bundle.characters}
    try:
        source_chars = [
            source_by_id[value] for value in source_fact.child_character_identities
        ]
    except KeyError:
        return CrossParserAlignmentResult(
            decision="SOURCE_LINEAGE_UNAVAILABLE",
            limitation_codes=("source_character_inventory_incomplete",),
        )
    if not source_chars or any(
        not item.operation_identity or not item.decoder_code_identities
        for item in source_chars
    ):
        return CrossParserAlignmentResult(
            decision="SOURCE_LINEAGE_UNAVAILABLE",
            limitation_codes=("canonical_character_ancestry_incomplete",),
        )
    source_content = [
        item
        for item in source_bundle.characters
        if item.unicode_digest not in _WHITESPACE_DIGESTS
    ]
    source_chars_content = [
        item for item in source_chars if item.unicode_digest not in _WHITESPACE_DIGESTS
    ]
    sequence = [item.unicode_digest for item in source_chars_content]
    selected_content = [
        item
        for item in selected_bundle.characters
        if item.character_role == "native_text"
        and item.text_digest not in _WHITESPACE_DIGESTS
    ]
    candidates: list[tuple[int, list[PdfiumCharacterEvidence], str]] = []
    for index in range(max(0, len(selected_content) - len(sequence) + 1)):
        candidate = [
            item.text_digest for item in selected_content[index : index + len(sequence)]
        ]
        if candidate == sequence:
            candidates.append(
                (index, selected_content[index : index + len(sequence)], "identity")
            )
        elif candidate == list(reversed(sequence)):
            chars = selected_content[index : index + len(sequence)]
            if operation_provenance.page_rotation_degrees in (90, 270):
                candidates.append((index, chars, "rotation_reversed"))
        if len(candidates) > maximum_candidates:
            return CrossParserAlignmentResult(
                decision="RESOURCE_BOUND_EXCEEDED",
                candidate_count=len(candidates),
                limitation_codes=("candidate_bound_exceeded",),
            )
    if not candidates:
        return CrossParserAlignmentResult(
            decision="SELECTED_SEQUENCE_UNAVAILABLE",
            limitation_codes=("exact_selected_sequence_unavailable",),
        )
    source_positions = {
        index
        for index, item in enumerate(source_content)
        if item.character_identity in source_fact.child_character_identities
    }
    qualified = []
    context_counts = {}
    geometry_rejected = 0
    contextless_geometry_candidates = []
    for index, chars, ordering in candidates:
        context = (
            _context_matches(
                source_content,
                source_positions,
                selected_content,
                index,
                len(chars),
                context_bound,
            )
            if ordering == "identity"
            else 0
        )
        context_counts[index] = context
        selected_boxes = [
            _rotate_box(
                item.bbox,
                operation_provenance.page_rotation_degrees,
                operation_provenance.media_box,
            )
            for item in chars
        ]
        if not _geometry_consistent(
            [item.bbox for item in source_chars], selected_boxes
        ):
            geometry_rejected += 1
            continue
        if context < 1 and len(candidates) != 1:
            contextless_geometry_candidates.append((index, chars, context, ordering))
            continue
        qualified.append((index, chars, context, ordering))
    if not qualified:
        if len(contextless_geometry_candidates) == 1:
            qualified = contextless_geometry_candidates
        elif len(contextless_geometry_candidates) > 1:
            return CrossParserAlignmentResult(
                decision="AMBIGUOUS_FAIL_CLOSED",
                candidate_count=len(candidates),
                qualified_candidate_count=len(contextless_geometry_candidates),
                ambiguity_count=len(contextless_geometry_candidates),
                limitation_codes=(
                    "multiple_geometry_consistent_intervals_without_canonical_context",
                ),
            )
    if not qualified:
        decision = (
            "GEOMETRY_INCONSISTENT"
            if geometry_rejected
            else "CANONICAL_CONTEXT_UNPROVEN"
        )
        return CrossParserAlignmentResult(
            decision=decision,  # type: ignore[arg-type]
            candidate_count=len(candidates),
            limitation_codes=(decision.lower(),),
        )
    if len(qualified) > 1:
        maximum_context = max(item[2] for item in qualified)
        strongest = [item for item in qualified if item[2] == maximum_context]
        if maximum_context > 0 and len(strongest) == 1:
            qualified = strongest
        else:
            return CrossParserAlignmentResult(
                decision="AMBIGUOUS_FAIL_CLOSED",
                candidate_count=len(candidates),
                qualified_candidate_count=len(qualified),
                ambiguity_count=len(qualified),
                limitation_codes=("multiple_qualified_canonical_intervals",),
            )
    _, chars, context, ordering = qualified[0]
    operations = tuple(
        dict.fromkeys(
            item.operation_identity for item in source_chars if item.operation_identity
        )
    )
    provenance_operations = {
        item.operation_identity for item in operation_provenance.operations
    }
    if not operations or any(
        value not in provenance_operations for value in operations
    ):
        return CrossParserAlignmentResult(
            decision="SOURCE_LINEAGE_UNAVAILABLE",
            candidate_count=len(candidates),
            limitation_codes=("canonical_operation_binding_incomplete",),
        )
    codes = tuple(
        dict.fromkeys(
            value for item in source_chars for value in item.decoder_code_identities
        )
    )
    parents = tuple(
        dict.fromkeys(
            item.parent_text_object_identity
            for item in chars
            if item.parent_text_object_identity
        )
    )
    start = min(item.character_index for item in chars)
    end = max(item.character_index for item in chars) + 1
    selected_whitespace = sum(
        item.character_index >= start
        and item.character_index < end
        and (
            item.character_role == "parser_inserted_separator"
            or item.text_digest in _WHITESPACE_DIGESTS
        )
        for item in selected_bundle.characters
    )
    source_whitespace = len(source_chars) - len(source_chars_content)
    shape = (
        "one_to_one"
        if len(parents) == 1 and len(operations) == 1
        else "one_to_many"
        if len(parents) > len(operations)
        else "many_to_one"
        if len(operations) > len(parents)
        else "subspan"
    )
    values = {
        "source_artifact_sha256": selected_bundle.source_artifact_sha256,
        "document_identity": document_identity,
        "original_page_number": selected_bundle.original_page_number,
        "page_identity": page_identity,
        "source_parser_identity": source_bundle.parser_identity,
        "source_parser_configuration_identity": source_bundle.parser_configuration_identity,
        "selected_parser_identity": selected_bundle.parser_identity,
        "selected_parser_configuration_identity": selected_bundle.parser_configuration_identity,
        "source_lineage_identity": source_fact.lineage_identity,
        "canonical_operation_identities": operations,
        "operation_provenance_digest": operation_provenance.bundle_digest,
        "canonical_decoder_code_identities": codes,
        "selected_character_start": start,
        "selected_character_end_exclusive": end,
        "selected_character_identities": tuple(
            item.character_identity for item in chars
        ),
        "selected_parent_text_object_identities": parents,
        "mapping_shape": shape,
        "ordering_transform": ordering,
        "normalization_transformations": ("tracked_whitespace_elision",)
        if source_whitespace or selected_whitespace
        else (),
        "source_whitespace_character_count": source_whitespace,
        "selected_whitespace_character_count": selected_whitespace,
        "lookup_method": "canonical_bound_exact_context"
        if context
        else "canonical_bound_unique_occurrence",
        "candidate_count": len(candidates),
        "context_character_count": context,
    }
    evidence = CrossParserAlignmentEvidence(
        **values,  # type: ignore[arg-type]
        alignment_identity=canonical_sha256(
            {"version": CROSS_PARSER_ALIGNMENT_VERSION, **values}
        ),
    )
    return CrossParserAlignmentResult(
        decision="CROSS_PARSER_ALIGNMENT_PROVEN",
        evidence=evidence,
        candidate_count=len(candidates),
        qualified_candidate_count=1,
    )

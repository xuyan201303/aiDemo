# ruff: noqa: EM101, I001, TRY003

"""Deterministic serialization helpers for CTIF evidence."""

from __future__ import annotations
from decimal import Decimal, InvalidOperation, ROUND_HALF_EVEN
from hashlib import sha256
import json
import math


def canonical_float(value: object, *, places: int = 9) -> str:
    parsed = float(value)  # type: ignore[arg-type]
    if not math.isfinite(parsed):
        raise ValueError("canonical identity floats must be finite")
    if parsed == 0:
        parsed = 0.0
    try:
        quantized = Decimal(str(parsed)).quantize(
            Decimal(1).scaleb(-places), rounding=ROUND_HALF_EVEN
        )
    except InvalidOperation:
        raise ValueError("float cannot be canonicalized") from None
    return format(quantized, "f")


def canonical_json_bytes(value: object) -> bytes:
    return json.dumps(
        value, ensure_ascii=True, separators=(",", ":"), sort_keys=True
    ).encode("utf-8")


def canonical_sha256(value: object) -> str:
    return sha256(canonical_json_bytes(value)).hexdigest()

# ruff: noqa: BLE001, C901, EM101, FURB171, PLR0911, PLR0912, PLR2004, RUF005

"""Bounded deterministic PDF-object identity representation for CTIF-1B-D1."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Any

from pypdf.generic import (
    ArrayObject,
    BooleanObject,
    ByteStringObject,
    DictionaryObject,
    FloatObject,
    IndirectObject,
    NameObject,
    NullObject,
    NumberObject,
    StreamObject,
    TextStringObject,
)

from .serialization import canonical_float, canonical_json_bytes, canonical_sha256

PDF_OBJECT_CANONICALIZATION_VERSION = "ctif_pdf_object_identity.v1"
PDF_OBJECT_CANONICALIZATION_POLICY = "ctif_pdf_object_identity.bounded.v1"


class PdfObjectCanonicalizationError(ValueError):
    """Stable fail-closed PDF object canonicalization error."""


@dataclass(frozen=True)
class PdfObjectCanonicalizationLimits:
    max_depth: int = 32
    max_dictionary_entries: int = 4_096
    max_array_items: int = 65_536
    max_total_visited_nodes: int = 250_000
    max_stream_bytes_hashed: int = 32 * 1024 * 1024
    max_canonical_serialized_bytes: int = 16 * 1024 * 1024


@dataclass(frozen=True)
class PdfObjectIdentityContext:
    source_artifact_sha256: str
    document_identity: str
    original_page_number: int | None = None
    content_path_identity: str | None = None
    policy_identity: str = PDF_OBJECT_CANONICALIZATION_POLICY
    limits: PdfObjectCanonicalizationLimits = PdfObjectCanonicalizationLimits()

    def __post_init__(self) -> None:
        if len(self.source_artifact_sha256) != 64 or any(
            character not in "0123456789abcdef"
            for character in self.source_artifact_sha256
        ):
            raise PdfObjectCanonicalizationError("invalid_source_artifact_sha256")
        if not self.document_identity or len(self.document_identity) > 256:
            raise PdfObjectCanonicalizationError("invalid_document_identity")
        if self.original_page_number is not None and self.original_page_number <= 0:
            raise PdfObjectCanonicalizationError("invalid_original_page_number")


@dataclass
class _Traversal:
    context: PdfObjectIdentityContext
    visited_nodes: int = 0
    active_runtime_objects: dict[int, tuple[str, ...]] | None = None

    def __post_init__(self) -> None:
        self.active_runtime_objects = {}

    def enter(self, value: object, path: tuple[str, ...], depth: int) -> int:
        if depth > self.context.limits.max_depth:
            raise PdfObjectCanonicalizationError("pdf_object_depth_bound_exceeded")
        self.visited_nodes += 1
        if self.visited_nodes > self.context.limits.max_total_visited_nodes:
            raise PdfObjectCanonicalizationError("pdf_object_node_bound_exceeded")
        runtime_identity = id(value)
        if runtime_identity in self.active_runtime_objects:  # type: ignore[operator]
            # Runtime id controls recursion only; the stable path is serialized.
            raise PdfObjectCanonicalizationError("pdf_object_direct_cycle")
        self.active_runtime_objects[runtime_identity] = path  # type: ignore[index]
        return runtime_identity

    def leave(self, runtime_identity: int) -> None:
        self.active_runtime_objects.pop(runtime_identity, None)  # type: ignore[union-attr]


def _bytes_evidence(value: bytes, kind: str) -> dict[str, object]:
    return {
        "type": kind,
        "length": len(value),
        "sha256": canonical_sha256({"bytes_hex": value.hex().upper()}),
    }


def _canonical_key(value: object) -> str:
    if isinstance(value, NameObject):
        return str(value)
    if isinstance(value, str) and value.startswith("/"):
        return value
    raise PdfObjectCanonicalizationError("unsupported_pdf_dictionary_key")


def _canonicalize(
    value: Any, traversal: _Traversal, path: tuple[str, ...], depth: int
) -> object:
    if value is None or isinstance(value, NullObject):
        return {"type": "null"}
    if isinstance(value, (BooleanObject, bool)):
        return {"type": "boolean", "value": bool(value)}
    if isinstance(value, (NumberObject, int)) and not isinstance(value, bool):
        return {"type": "integer", "value": int(value)}
    if isinstance(value, (FloatObject, float, Decimal)):
        try:
            number = canonical_float(value)
        except (TypeError, ValueError, OverflowError):
            raise PdfObjectCanonicalizationError(
                "non_finite_or_invalid_pdf_number"
            ) from None
        return {"type": "decimal", "value": number}
    if isinstance(value, NameObject):
        return {"type": "name", "value": str(value)}
    if isinstance(value, ByteStringObject):
        return _bytes_evidence(bytes(value), "byte_string")
    if isinstance(value, TextStringObject):
        try:
            original = value.get_original_bytes()
        except Exception:
            raise PdfObjectCanonicalizationError(
                "text_string_original_bytes_unavailable"
            ) from None
        return _bytes_evidence(original, "text_string_original_bytes")
    if isinstance(value, bytes):
        return _bytes_evidence(value, "bytes")
    if isinstance(value, str):
        encoded = value.encode("utf-8")
        return {
            "type": "string_utf8",
            "length": len(value),
            "sha256": canonical_sha256({"utf8_hex": encoded.hex().upper()}),
        }
    if isinstance(value, IndirectObject):
        return {
            "type": "indirect_reference",
            "source_artifact_sha256": traversal.context.source_artifact_sha256,
            "document_identity": traversal.context.document_identity,
            "object_number": int(value.idnum),
            "generation": int(value.generation),
        }
    if isinstance(value, StreamObject):
        runtime_identity = traversal.enter(value, path, depth)
        try:
            try:
                decoded = value.get_data()
            except Exception:
                raise PdfObjectCanonicalizationError(
                    "decoded_stream_unavailable"
                ) from None
            if len(decoded) > traversal.context.limits.max_stream_bytes_hashed:
                raise PdfObjectCanonicalizationError("pdf_stream_byte_bound_exceeded")
            metadata = {
                key: _canonicalize(item, traversal, path + (key,), depth + 1)
                for key, item in _sorted_dictionary_items(
                    value, traversal.context.limits.max_dictionary_entries
                )
                if key not in {"/Length"}
            }
            reference = getattr(value, "indirect_reference", None)
            return {
                "type": "stream",
                "indirect_reference": _canonicalize(
                    reference, traversal, path + ("@ref",), depth + 1
                )
                if isinstance(reference, IndirectObject)
                else None,
                "metadata": metadata,
                "decoded_stream_length": len(decoded),
                "decoded_stream_sha256": canonical_sha256(
                    {"decoded_stream_hex": decoded.hex().upper()}
                ),
                "stream_digest_kind": "decoded",
            }
        finally:
            traversal.leave(runtime_identity)
    if isinstance(value, (DictionaryObject, dict)):
        runtime_identity = traversal.enter(value, path, depth)
        try:
            return {
                "type": "dictionary",
                "entries": {
                    key: _canonicalize(item, traversal, path + (key,), depth + 1)
                    for key, item in _sorted_dictionary_items(
                        value, traversal.context.limits.max_dictionary_entries
                    )
                },
            }
        finally:
            traversal.leave(runtime_identity)
    if isinstance(value, (ArrayObject, list, tuple)):
        if len(value) > traversal.context.limits.max_array_items:
            raise PdfObjectCanonicalizationError("pdf_array_item_bound_exceeded")
        runtime_identity = traversal.enter(value, path, depth)
        try:
            return {
                "type": "array",
                "items": [
                    _canonicalize(item, traversal, path + (str(index),), depth + 1)
                    for index, item in enumerate(value)
                ],
            }
        finally:
            traversal.leave(runtime_identity)
    raise PdfObjectCanonicalizationError("unsupported_pdf_object_type")


def _sorted_dictionary_items(
    value: Any, maximum: int
) -> tuple[tuple[str, object], ...]:
    if len(value) > maximum:
        raise PdfObjectCanonicalizationError("pdf_dictionary_entry_bound_exceeded")
    items = [(_canonical_key(key), item) for key, item in value.items()]
    keys = [key for key, _ in items]
    if len(keys) != len(set(keys)):
        raise PdfObjectCanonicalizationError("duplicate_pdf_dictionary_key")
    return tuple(sorted(items, key=lambda item: item[0]))


def canonicalize_pdf_object_for_identity(
    value: Any, *, context: PdfObjectIdentityContext
) -> dict[str, object]:
    traversal = _Traversal(context)
    payload = {
        "canonicalization_version": PDF_OBJECT_CANONICALIZATION_VERSION,
        "policy_identity": context.policy_identity,
        "source_artifact_sha256": context.source_artifact_sha256,
        "document_identity": context.document_identity,
        "original_page_number": context.original_page_number,
        "content_path_identity": context.content_path_identity,
        "object": _canonicalize(value, traversal, ("root",), 0),
    }
    if (
        len(canonical_json_bytes(payload))
        > context.limits.max_canonical_serialized_bytes
    ):
        raise PdfObjectCanonicalizationError("pdf_object_serialized_bound_exceeded")
    return payload


def canonical_pdf_object_digest(
    value: Any, *, context: PdfObjectIdentityContext
) -> str:
    return canonical_sha256(
        canonicalize_pdf_object_for_identity(value, context=context)
    )

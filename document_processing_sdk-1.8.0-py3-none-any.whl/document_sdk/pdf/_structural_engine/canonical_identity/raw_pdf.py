# ruff: noqa: ANN202, BLE001, C901, PLR0911, PLR0912, PLR0913, PLR0915, RUF005, TC002
"""Bounded raw PDF content traversal used only by CTIF authority."""

from __future__ import annotations

from dataclasses import dataclass, field
from hashlib import sha256
from typing import Any

from pypdf import PdfReader
from pypdf.errors import LimitReachedError
from pypdf.generic import (
    ArrayObject,
    ContentStream,
    IndirectObject,
    NameObject,
    TextStringObject,
)

from .contracts import CanonicalContentPath, CanonicalGlyphEvidence, ResourcePolicy
from .evidence import FontEvidence, NativeCanonicalMappingSegment, RawOperationEvidence
from .serialization import canonical_float, canonical_sha256

TEXT_SHOW = {b"Tj", b"TJ", b"'", b'"'}
SUPPORTED = {
    b"q",
    b"Q",
    b"cm",
    b"BT",
    b"ET",
    b"Tf",
    b"Tm",
    b"Td",
    b"TD",
    b"T*",
    b"Tc",
    b"Tw",
    b"Tz",
    b"TL",
    b"Ts",
    b"Tr",
    b"Tj",
    b"TJ",
    b"'",
    b'"',
    b"Do",
    b"BMC",
    b"BDC",
    b"EMC",
}


def object_identity(value: Any) -> str | None:
    ref = (
        value
        if isinstance(value, IndirectObject)
        else getattr(value, "indirect_reference", None)
    )
    if ref is None:
        return None
    return f"{int(ref.idnum)}:{int(ref.generation)}"


def _safe_operand(value: Any) -> object:
    if isinstance(value, (bytes, bytearray)):
        return {"bytes_sha256": sha256(bytes(value)).hexdigest(), "length": len(value)}
    if isinstance(value, str):
        return {
            "text_sha256": sha256(value.encode("utf-8")).hexdigest(),
            "length": len(value),
        }
    if isinstance(value, (int, bool)) or value is None:
        return value
    if isinstance(value, float):
        return canonical_float(value)
    if isinstance(value, (list, tuple, ArrayObject)):
        return [_safe_operand(item) for item in value]
    if isinstance(value, (NameObject,)):
        return str(value)[:256]
    return {"type": type(value).__name__}


def _bounded_resource_identity(value: Any, *, maximum: int = 256) -> str | None:
    if value is None:
        return None
    if isinstance(value, NameObject):
        return str(value)[:maximum]
    reference = object_identity(value)
    if reference:
        return f"indirect:{reference}"
    return f"direct:{type(value).__name__}:{canonical_sha256(_safe_operand(value))}"[
        :maximum
    ]


def _decode_text_operand(value: Any) -> tuple[str, bool, int, int]:
    # ContentStream has already applied pypdf's font/string decoding by this
    # point.  Until CTIF owns the CMap/encoding proof, the resulting Unicode is
    # useful as partial evidence but is not claimed reversible.
    if isinstance(value, TextStringObject):
        return str(value), False, len(value), 0
    if isinstance(value, str):
        return value, False, len(value), 0
    if isinstance(value, bytes):
        try:
            return value.decode("utf-16-be"), True, len(value), 0
        except UnicodeDecodeError:
            try:
                return value.decode("latin-1"), False, len(value), len(value)
            except UnicodeDecodeError:
                return "", False, len(value), len(value)
    return "", False, 0, 0


def decode_text_show(
    operands: list[Any], operator: bytes
) -> tuple[str, bool, int, int]:
    target = (
        operands[-1]
        if operator == b'"' and operands
        else operands[0]
        if operands
        else ""
    )
    values = (
        target
        if operator == b"TJ" and isinstance(target, (list, ArrayObject))
        else [target]
    )
    chunks = []
    reversible = True
    codes = 0
    unmapped = 0
    for value in values:
        if isinstance(value, (int, float)):
            continue
        text, item_reversible, item_codes, item_unmapped = _decode_text_operand(value)
        chunks.append(text)
        reversible &= item_reversible
        codes += item_codes
        unmapped += item_unmapped
    return "".join(chunks), reversible, codes, unmapped


@dataclass
class Traversal:
    policy: ResourcePolicy
    operations: list[RawOperationEvidence] = field(default_factory=list)
    content_paths: list[CanonicalContentPath] = field(default_factory=list)
    glyphs: list[CanonicalGlyphEvidence] = field(default_factory=list)
    fonts: dict[str, FontEvidence] = field(default_factory=dict)
    mappings: list[NativeCanonicalMappingSegment] = field(default_factory=list)
    limitations: set[str] = field(default_factory=set)
    canonical_chars: list[str] = field(default_factory=list)
    operation_count: int = 0
    text_show_count: int = 0
    form_count: int = 0
    max_depth: int = 0
    glyph_count: int = 0
    unmapped_count: int = 0
    lossy_count: int = 0
    malformed_count: int = 0
    resource_exceeded: bool = False
    active_forms: set[str] = field(default_factory=set)

    def limit(self, code: str):  # type: ignore[no-untyped-def]
        self.limitations.add(code)
        self.resource_exceeded = True


def inventory_fonts(resources: Any) -> dict[str, FontEvidence]:
    result = {}  # type: ignore[var-annotated]
    try:
        font_map = (resources or {}).get("/Font") or {}
    except Exception:
        return result
    for name in sorted(font_map, key=str):
        raw = font_map[name]
        try:
            font = raw.get_object()
            subtype = _bounded_resource_identity(font.get("/Subtype"), maximum=64)
            base = _bounded_resource_identity(font.get("/BaseFont"))
            encoding = _bounded_resource_identity(font.get("/Encoding"))
            tounicode = object_identity(font.get("/ToUnicode"))
            descendants = font.get("/DescendantFonts") or []
            descendant = object_identity(descendants[0]) if descendants else None
        except Exception:
            subtype = base = encoding = tounicode = descendant = None
        payload = {
            "name": str(name),
            "object": object_identity(raw),
            "subtype": subtype,
            "base": base,
            "encoding": encoding,
            "to_unicode": tounicode,
            "descendant": descendant,
        }
        result[str(name)] = FontEvidence(
            resource_name=str(name),
            object_identity=object_identity(raw),
            subtype=subtype,
            base_font=base,
            encoding_identity=encoding,
            to_unicode_identity=tounicode,
            descendant_font_identity=descendant,
            writing_mode="vertical"
            if encoding and encoding.endswith("-V")
            else "horizontal"
            if encoding
            else "unknown",
            unsupported=subtype
            not in {
                "/Type0",
                "/Type1",
                "/TrueType",
                "/Type3",
                "/CIDFontType0",
                "/CIDFontType2",
            },
            evidence_digest=canonical_sha256(payload),
        )
    return result


def traverse_streams(  # type: ignore[no-untyped-def]
    *,
    reader: PdfReader,
    streams: list[Any],
    resources: Any,
    traversal: Traversal,
    root_stream_ordinal: int = 0,
    form_path: tuple[str, ...] = (),
    depth: int = 0,
):
    traversal.max_depth = max(traversal.max_depth, depth)
    if depth > traversal.policy.max_form_xobject_recursion_depth:
        traversal.limit("form_xobject_recursion_bound_exceeded")
        return
    traversal.fonts.update(inventory_fonts(resources))
    if len(streams) > traversal.policy.max_content_streams_per_page:
        traversal.limit("content_stream_bound_exceeded")
        streams = streams[: traversal.policy.max_content_streams_per_page]
    for stream_index, stream_ref in enumerate(streams):
        try:
            content = ContentStream(stream_ref, reader)
        except LimitReachedError:
            traversal.limit("stream_decompression_bound_exceeded")
            continue
        except Exception:
            traversal.limitations.add("malformed_content_stream")
            traversal.malformed_count += 1
            continue
        for local_ordinal, (operands, operator) in enumerate(content.operations):
            if traversal.operation_count >= traversal.policy.max_operations_per_page:
                traversal.limit("operation_bound_exceeded")
                return
            op = bytes(operator)
            global_ordinal = traversal.operation_count
            traversal.operation_count += 1
            path = CanonicalContentPath(
                content_stream_object_identity=object_identity(stream_ref),
                content_stream_ordinal=root_stream_ordinal + stream_index,
                form_xobject_path=form_path,
                recursion_depth=depth,
                text_show_operation_ordinal=traversal.text_show_count
                if op in TEXT_SHOW
                else None,
                availability="available" if op in TEXT_SHOW else "unknown",
            )
            path_id = canonical_sha256(path.model_dump(mode="json"))
            operand_digest = canonical_sha256(_safe_operand(list(operands)))
            traversal.operations.append(
                RawOperationEvidence(
                    global_ordinal=global_ordinal,
                    local_ordinal=local_ordinal,
                    operator=op.decode("latin-1")[:8],
                    operand_digest=operand_digest,
                    content_path_identity=path_id,
                    graphics_state_digest=canonical_sha256(
                        {"form_path": form_path, "depth": depth}
                    ),
                    text_state_digest=canonical_sha256({"ordinal": global_ordinal}),
                    unsupported=op not in SUPPORTED,
                )
            )
            if op not in SUPPORTED:
                traversal.limitations.add("unsupported_operator")
            if op in TEXT_SHOW:
                if (
                    traversal.text_show_count
                    >= traversal.policy.max_text_show_operations_per_page
                ):
                    traversal.limit("text_show_operation_bound_exceeded")
                    return
                traversal.text_show_count += 1
                traversal.content_paths.append(path)
                text, reversible, codes, unmapped = decode_text_show(list(operands), op)
                traversal.glyph_count += codes
                traversal.unmapped_count += unmapped
                if traversal.glyph_count > traversal.policy.max_glyphs_per_page:
                    traversal.limit("glyph_bound_exceeded")
                    return
                start = len(traversal.canonical_chars)
                traversal.canonical_chars.extend(text)
                end = len(traversal.canonical_chars)
                if end > traversal.policy.max_canonical_characters_per_page:
                    traversal.limit("canonical_character_bound_exceeded")
                    return
                operation_id = canonical_sha256(
                    {"path": path_id, "operand": operand_digest}
                )
                traversal.glyphs.append(
                    CanonicalGlyphEvidence(
                        content_path=path,
                        raw_operand_digest=operand_digest,
                        raw_glyph_code_digest=canonical_sha256(
                            {"codes": codes, "operand": operand_digest}
                        ),
                        decoded_text_digest=sha256(text.encode("utf-8")).hexdigest(),
                        reversible=reversible,
                        lossy=not reversible,
                        unmapped=unmapped > 0,
                        warning_codes=("lossy_decode",) if not reversible else (),
                    )
                )
                traversal.mappings.append(
                    NativeCanonicalMappingSegment(
                        native_start=0,
                        native_end_exclusive=codes,
                        canonical_start=start,
                        canonical_end_exclusive=end,
                        transformation="identity"
                        if reversible
                        else "lossy_replacement",
                        reversible=reversible,
                        lossy=not reversible,
                        unmapped=unmapped > 0,
                        source_operation_identity=operation_id,
                        limitation_codes=("lossy_decode",) if not reversible else (),
                    )
                )
                if not reversible:
                    traversal.lossy_count += 1
                    traversal.limitations.add("lossy_decode")
            elif op == b"Do" and operands:
                name = str(operands[0])
                try:
                    xmap = (resources or {}).get("/XObject") or {}
                    xref = xmap.get(name)
                    xobj = xref.get_object() if xref is not None else None
                except Exception:
                    xref = xobj = None
                if xobj is None:
                    traversal.limitations.add("missing_xobject")
                    continue
                if str(xobj.get("/Subtype") or "") != "/Form":
                    continue
                traversal.form_count += 1
                form_id = object_identity(xref) or canonical_sha256(
                    {"name": name, "path": form_path}
                )
                invocation = f"{name}@{global_ordinal}:{form_id}"
                if form_id in traversal.active_forms:
                    traversal.limitations.add("recursive_xobject")
                    continue
                traversal.active_forms.add(form_id)
                child_resources = xobj.get("/Resources") or resources
                traverse_streams(
                    reader=reader,
                    streams=[xref],
                    resources=child_resources,
                    traversal=traversal,
                    root_stream_ordinal=root_stream_ordinal + stream_index,
                    form_path=form_path + (invocation,),
                    depth=depth + 1,
                )
                traversal.active_forms.discard(form_id)

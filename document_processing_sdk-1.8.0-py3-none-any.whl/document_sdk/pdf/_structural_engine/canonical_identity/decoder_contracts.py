# ruff: noqa: C901, E501, EM101, PLR0912, PLR2004, SIM102, TRY003, TRY004, UP042

"""CTIF-0A immutable decoder provenance contracts.

This module is deliberately parser- and I/O-free.  It extends, but never
reinterprets, the frozen CTIF v1 evidence contract.
"""

from __future__ import annotations

from enum import Enum
from typing import Literal, Self

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .contracts import (
    CanonicalAuthorityMode,
    CanonicalContentPath,
    CanonicalEvidenceBundle,
    CanonicalGlyphEvidence,
    CanonicalTextAuthorityIdentity,
    CrossParserMappingEvidence,
    ParserLineageEvidence,
    ResourcePolicy,
)
from .serialization import canonical_sha256

DECODER_CONTRACT_VERSION = "canonical_text_decoder.v2"
CANONICAL_EVIDENCE_BUNDLE_V2_VERSION = "canonical_evidence_bundle.v2"
MAX_RAW_CODE_BYTES = 32
MAX_UNICODE_SCALARS = 64
MAX_COMPETING_MAPPINGS = 64
MAX_MAPPING_STEPS = 4096
MAX_CONFLICTS = 1024
MAX_LIMITATION_CODES = 256
MAX_DECODER_INVENTORY_BYTES = 16 * 1024 * 1024
SHA256_PATTERN = r"^[0-9a-f]{64}$"


class _Frozen(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class SegmentationStatus(str, Enum):
    PROVEN = "proven"
    AMBIGUOUS = "ambiguous"
    UNAVAILABLE = "unavailable"
    UNSUPPORTED = "unsupported"
    MALFORMED = "malformed"
    RESOURCE_EXCEEDED = "resource_exceeded"


class DecoderCompleteness(str, Enum):
    COMPLETE = "complete"
    PARTIAL = "partial"
    UNAVAILABLE = "unavailable"
    UNSAFE = "unsafe"
    UNAVAILABLE_BY_CONTRACT_VERSION = "unavailable_by_contract_version"


class MappingCompleteness(str, Enum):
    COMPLETE = "complete"
    PARTIAL = "partial"
    UNAVAILABLE = "unavailable"
    UNSAFE = "unsafe"


class DecoderValueType(str, Enum):
    RAW_CODE = "raw_code"
    FONT_CODE = "font_code"
    CID = "cid"
    GID = "gid"
    UNICODE_SEQUENCE = "unicode_sequence"
    ACTUALTEXT_SEQUENCE = "actualtext_sequence"
    CANONICAL_INTERVAL = "canonical_interval"


class DecoderMappingMethod(str, Enum):
    RAW_SEGMENTATION = "raw_segmentation"
    SIMPLE_ENCODING = "simple_encoding"
    DIFFERENCES = "differences"
    CODE_TO_CID = "code_to_cid"
    CID_TO_GID = "cid_to_gid"
    TOUNICODE = "tounicode"
    PREDEFINED_CMAP = "predefined_cmap"
    USECMAP = "usecmap"
    GLYPH_NAME_MAPPING = "glyph_name_mapping"
    ACTUALTEXT_SUBSTITUTION = "actualtext_substitution"
    CANONICAL_APPEND = "canonical_append"
    UNMAPPED = "unmapped"
    UNSUPPORTED = "unsupported"


class UnicodeMappingMethod(str, Enum):
    TOUNICODE_BFCHAR = "tounicode_bfchar"
    TOUNICODE_BFRANGE_SCALAR = "tounicode_bfrange_scalar"
    TOUNICODE_BFRANGE_ARRAY = "tounicode_bfrange_array"
    SIMPLE_ENCODING = "simple_encoding"
    DIFFERENCES_GLYPH_NAME = "differences_glyph_name"
    ADOBE_GLYPH_LIST = "adobe_glyph_list"
    ACTUALTEXT = "actualtext"
    PREDEFINED_CMAP = "predefined_cmap"
    FALLBACK_UNPROVEN = "fallback_unproven"
    UNMAPPED = "unmapped"


class CIDMappingMethod(str, Enum):
    IDENTITY_H = "identity_h"
    IDENTITY_V = "identity_v"
    CIDCHAR = "cidchar"
    CIDRANGE = "cidrange"
    EMBEDDED_CMAP = "embedded_cmap"
    PREDEFINED_CMAP = "predefined_cmap"
    USECMAP_INHERITED = "usecmap_inherited"
    UNAVAILABLE = "unavailable"
    UNSUPPORTED = "unsupported"


class ConflictType(str, Enum):
    DUPLICATE_SOURCE_MAPPING = "duplicate_source_mapping"
    OVERLAPPING_CODESPACE = "overlapping_codespace"
    CONFLICTING_BFCHAR = "conflicting_bfchar"
    CONFLICTING_BFRANGE = "conflicting_bfrange"
    USECMAP_CONFLICT = "usecmap_conflict"
    DIFFERENCES_DUPLICATE_ASSIGNMENT = "differences_duplicate_assignment"
    ACTUALTEXT_CONFLICT = "actualtext_conflict"
    MULTIPLE_UNICODE_OUTPUTS = "multiple_unicode_outputs"
    AMBIGUOUS_SEGMENTATION = "ambiguous_segmentation"
    CYCLE = "cycle"
    RESOURCE_TRUNCATION = "resource_truncation"


class ResolutionStatus(str, Enum):
    UNRESOLVED = "unresolved"
    REJECTED = "rejected"
    PROVEN_UNIQUE = "proven_unique"


def _valid_scalar(value: int) -> bool:
    return 0 <= value <= 0x10FFFF and not 0xD800 <= value <= 0xDFFF


def _identity_payload(model: BaseModel, digest_field: str) -> dict[str, object]:
    payload = model.model_dump(mode="json")
    payload.pop(digest_field, None)
    return payload


class DecoderCodeUnit(_Frozen):
    code_unit_version: Literal["canonical_text_decoder.v2"] = DECODER_CONTRACT_VERSION  # type: ignore[assignment]
    source_artifact_sha256: str = Field(pattern=SHA256_PATTERN)
    original_page_number: int = Field(gt=0)
    content_path_identity: str = Field(min_length=1, max_length=256)
    text_show_operation_identity: str = Field(min_length=1, max_length=256)
    operand_index: int = Field(ge=0)
    raw_operand_digest: str = Field(pattern=SHA256_PATTERN)
    raw_code_start: int = Field(ge=0)
    raw_code_end_exclusive: int = Field(gt=0)
    raw_code_length_bytes: int = Field(ge=1, le=MAX_RAW_CODE_BYTES)
    raw_code_hex: str = Field(
        min_length=2, max_length=MAX_RAW_CODE_BYTES * 2, pattern=r"^[0-9A-F]+$"
    )
    code_width_bytes: int = Field(ge=1, le=MAX_RAW_CODE_BYTES)
    codespace_identity: str | None = Field(default=None, max_length=256)
    segmentation_method: str = Field(min_length=1, max_length=128)
    segmentation_status: SegmentationStatus
    deterministic_ordinal: int = Field(ge=0)
    limitation_codes: tuple[str, ...] = Field(
        default=(), max_length=MAX_LIMITATION_CODES
    )

    @model_validator(mode="after")
    def validate_code(self) -> Self:
        length = self.raw_code_end_exclusive - self.raw_code_start
        if length != self.raw_code_length_bytes or length != self.code_width_bytes:
            raise ValueError("raw byte interval and code width must agree")
        if len(self.raw_code_hex) != self.raw_code_length_bytes * 2:
            raise ValueError("raw code hex length mismatch")
        if self.segmentation_status is SegmentationStatus.PROVEN:
            if not self.codespace_identity or self.limitation_codes:
                raise ValueError(
                    "proven segmentation requires an unqualified codespace identity"
                )
        return self

    @property
    def evidence_identity(self) -> str:
        return canonical_sha256(self.model_dump(mode="json"))


class DecoderCodeRange(_Frozen):
    byte_length: int = Field(ge=1, le=8)
    lower_bound_hex: str = Field(min_length=2, max_length=16, pattern=r"^[0-9A-F]+$")
    upper_bound_hex: str = Field(min_length=2, max_length=16, pattern=r"^[0-9A-F]+$")
    source_mapping_identity: str = Field(min_length=1, max_length=256)
    deterministic_ordinal: int = Field(ge=0)

    @model_validator(mode="after")
    def validate_range(self) -> Self:
        expected = self.byte_length * 2
        if (
            len(self.lower_bound_hex) != expected
            or len(self.upper_bound_hex) != expected
        ):
            raise ValueError("codespace bound width mismatch")
        if int(self.lower_bound_hex, 16) > int(self.upper_bound_hex, 16):
            raise ValueError("codespace range is reversed")
        return self


class DecoderCodeSpaceEvidence(_Frozen):
    codespace_version: Literal["canonical_text_decoder.v2"] = DECODER_CONTRACT_VERSION  # type: ignore[assignment]
    codespace_source: str = Field(min_length=1, max_length=128)
    font_identity: str = Field(min_length=1, max_length=256)
    encoding_cmap_identity: str | None = Field(default=None, max_length=256)
    usecmap_ancestry: tuple[str, ...] = Field(default=(), max_length=32)
    code_ranges: tuple[DecoderCodeRange, ...] = Field(default=(), max_length=1024)
    minimum_code_bytes: int = Field(ge=0, le=8)
    maximum_code_bytes: int = Field(ge=0, le=8)
    variable_length: bool
    overlap_count: int = Field(ge=0)
    ambiguity_count: int = Field(ge=0)
    conflict_count: int = Field(ge=0)
    completeness: MappingCompleteness
    evidence_digest: str = Field(pattern=SHA256_PATTERN)
    limitation_codes: tuple[str, ...] = Field(
        default=(), max_length=MAX_LIMITATION_CODES
    )

    @model_validator(mode="after")
    def validate_codespace(self) -> Self:
        ordered = tuple(
            sorted(
                self.code_ranges,
                key=lambda item: (
                    item.byte_length,
                    item.lower_bound_hex,
                    item.upper_bound_hex,
                    item.deterministic_ordinal,
                ),
            )
        )
        if ordered != self.code_ranges:
            raise ValueError("codespace ranges must use deterministic ordering")
        if self.code_ranges:
            widths = tuple(item.byte_length for item in self.code_ranges)
            if self.minimum_code_bytes != min(widths) or self.maximum_code_bytes != max(
                widths
            ):
                raise ValueError("codespace width summary mismatch")
            if self.variable_length != (min(widths) != max(widths)):
                raise ValueError("codespace variable-length flag mismatch")
        elif self.minimum_code_bytes or self.maximum_code_bytes:
            raise ValueError("absent codespace cannot report widths")
        calculated_overlap = 0
        for index, left in enumerate(self.code_ranges):
            for right in self.code_ranges[index + 1 :]:
                if (
                    left.byte_length == right.byte_length
                    and int(left.lower_bound_hex, 16) <= int(right.upper_bound_hex, 16)
                    and int(right.lower_bound_hex, 16) <= int(left.upper_bound_hex, 16)
                ):
                    calculated_overlap += 1
        if self.overlap_count != calculated_overlap:
            raise ValueError("codespace overlap inventory mismatch")
        if self.completeness is MappingCompleteness.COMPLETE and (
            self.overlap_count
            or self.ambiguity_count
            or self.conflict_count
            or self.limitation_codes
        ):
            raise ValueError(
                "complete codespace cannot contain ambiguity, conflict, or limitation"
            )
        if self.evidence_digest != canonical_sha256(
            _identity_payload(self, "evidence_digest")
        ):
            raise ValueError("codespace evidence digest mismatch")
        return self


class DecoderFontCodeEvidence(_Frozen):
    font_code_version: Literal["canonical_text_decoder.v2"] = DECODER_CONTRACT_VERSION  # type: ignore[assignment]
    font_identity: str = Field(min_length=1, max_length=256)
    raw_code_identity: str = Field(min_length=1, max_length=256)
    font_code_value: int = Field(ge=0)
    font_code_hex: str = Field(min_length=2, max_length=16, pattern=r"^[0-9A-F]+$")
    font_code_width: int = Field(ge=1, le=8)
    encoding_method: str = Field(min_length=1, max_length=128)
    encoding_source_identity: str = Field(min_length=1, max_length=256)
    differences_entry_identity: str | None = Field(default=None, max_length=256)
    cid_identity: str | None = Field(default=None, max_length=256)
    gid_identity: str | None = Field(default=None, max_length=256)
    unicode_mapping_eligibility: Literal["eligible", "ineligible", "unknown"]
    limitation_codes: tuple[str, ...] = Field(
        default=(), max_length=MAX_LIMITATION_CODES
    )

    @model_validator(mode="after")
    def validate_font_code(self) -> Self:
        if len(self.font_code_hex) != self.font_code_width * 2:
            raise ValueError("font code width mismatch")
        if int(self.font_code_hex, 16) != self.font_code_value:
            raise ValueError("font code value mismatch")
        return self

    @property
    def evidence_identity(self) -> str:
        return canonical_sha256(self.model_dump(mode="json"))


class DecoderCIDMappingEvidence(_Frozen):
    cid_mapping_version: Literal["canonical_text_decoder.v2"] = DECODER_CONTRACT_VERSION  # type: ignore[assignment]
    source_code_identity: str = Field(min_length=1, max_length=256)
    cid_value: int = Field(ge=0)
    cid_system_info_identity: str = Field(min_length=1, max_length=256)
    encoding_cmap_identity: str = Field(min_length=1, max_length=256)
    mapping_entry_identity: str = Field(min_length=1, max_length=256)
    mapping_method: CIDMappingMethod
    mapping_completeness: MappingCompleteness
    conflict_status: Literal["none", "present", "unknown"]
    limitation_codes: tuple[str, ...] = Field(
        default=(), max_length=MAX_LIMITATION_CODES
    )

    @model_validator(mode="after")
    def validate_cid(self) -> Self:
        if self.mapping_completeness is MappingCompleteness.COMPLETE and (
            self.conflict_status != "none" or self.limitation_codes
        ):
            raise ValueError(
                "complete CID mapping cannot contain conflict or limitation"
            )
        return self

    @property
    def evidence_identity(self) -> str:
        return canonical_sha256(self.model_dump(mode="json"))


class DecoderGIDMappingEvidence(_Frozen):
    gid_mapping_version: Literal["canonical_text_decoder.v2"] = DECODER_CONTRACT_VERSION  # type: ignore[assignment]
    cid_identity: str = Field(min_length=1, max_length=256)
    gid_value: int | None = Field(default=None, ge=0)
    cid_to_gid_map_identity: str | None = Field(default=None, max_length=256)
    mapping_method: Literal["identity", "cid_to_gid_map", "unavailable", "unsupported"]
    mapping_completeness: MappingCompleteness
    limitation_codes: tuple[str, ...] = Field(
        default=(), max_length=MAX_LIMITATION_CODES
    )

    @model_validator(mode="after")
    def validate_gid(self) -> Self:
        if (
            self.mapping_completeness is MappingCompleteness.COMPLETE
            and self.gid_value is None
        ):
            raise ValueError("complete GID mapping requires a GID value")
        return self

    @property
    def evidence_identity(self) -> str:
        return canonical_sha256(self.model_dump(mode="json"))


class DecoderUnicodeSequenceEvidence(_Frozen):
    unicode_evidence_version: Literal["canonical_text_decoder.v2"] = (
        DECODER_CONTRACT_VERSION  # type: ignore[assignment]
    )
    source_mapping_step_identity: str = Field(min_length=1, max_length=256)
    unicode_scalar_sequence: tuple[int, ...] = Field(
        default=(), max_length=MAX_UNICODE_SCALARS
    )
    unicode_sequence_digest: str = Field(pattern=SHA256_PATTERN)
    scalar_count: int = Field(ge=0, le=MAX_UNICODE_SCALARS)
    utf16be_source_digest: str | None = Field(default=None, pattern=SHA256_PATTERN)
    mapping_method: UnicodeMappingMethod
    reversible: bool
    lossy: bool
    unmapped: bool
    replacement_count: int = Field(ge=0)
    invalid_scalar_count: int = Field(ge=0)
    limitation_codes: tuple[str, ...] = Field(
        default=(), max_length=MAX_LIMITATION_CODES
    )

    @model_validator(mode="after")
    def validate_unicode(self) -> Self:
        invalid = sum(
            not _valid_scalar(value) for value in self.unicode_scalar_sequence
        )
        if invalid != self.invalid_scalar_count:
            raise ValueError("invalid scalar inventory mismatch")
        if self.scalar_count != len(self.unicode_scalar_sequence):
            raise ValueError("Unicode scalar count mismatch")
        if self.unicode_sequence_digest != canonical_sha256(
            list(self.unicode_scalar_sequence)
        ):
            raise ValueError("Unicode sequence digest mismatch")
        replacements = self.unicode_scalar_sequence.count(0xFFFD)
        if replacements != self.replacement_count:
            raise ValueError("replacement inventory mismatch")
        if self.reversible and (
            self.lossy
            or self.unmapped
            or self.replacement_count
            or self.invalid_scalar_count
            or self.mapping_method
            in {UnicodeMappingMethod.FALLBACK_UNPROVEN, UnicodeMappingMethod.UNMAPPED}
        ):
            raise ValueError(
                "lossy, replacement, invalid, or unproven Unicode cannot be reversible"
            )
        return self

    @property
    def evidence_identity(self) -> str:
        return canonical_sha256(self.model_dump(mode="json"))


class DecoderMappingStep(_Frozen):
    mapping_step_version: Literal["canonical_text_decoder.v2"] = (
        DECODER_CONTRACT_VERSION  # type: ignore[assignment]
    )
    step_ordinal: int = Field(ge=0)
    source_artifact_sha256: str = Field(pattern=SHA256_PATTERN)
    original_page_number: int = Field(gt=0)
    content_path_identity: str = Field(min_length=1, max_length=256)
    text_show_operation_identity: str = Field(min_length=1, max_length=256)
    font_identity: str = Field(min_length=1, max_length=256)
    input_identity: str = Field(min_length=1, max_length=256)
    input_type: DecoderValueType
    output_identity: str = Field(min_length=1, max_length=256)
    output_type: DecoderValueType
    method: DecoderMappingMethod
    source_evidence_identity: str = Field(min_length=1, max_length=256)
    reversible: bool
    lossy: bool
    ambiguous: bool
    conflict_count: int = Field(ge=0)
    limitation_codes: tuple[str, ...] = Field(
        default=(), max_length=MAX_LIMITATION_CODES
    )
    step_digest: str = Field(pattern=SHA256_PATTERN)

    @model_validator(mode="after")
    def validate_step(self) -> Self:
        if self.input_identity == self.output_identity:
            raise ValueError("mapping step cannot self-cycle")
        if self.reversible and (
            self.lossy or self.ambiguous or self.conflict_count or self.limitation_codes
        ):
            raise ValueError(
                "reversible mapping step cannot be lossy, ambiguous, or conflicted"
            )
        if self.step_digest != canonical_sha256(_identity_payload(self, "step_digest")):
            raise ValueError("mapping step digest mismatch")
        return self


class DecoderMappingConflict(_Frozen):
    conflict_version: Literal["canonical_text_decoder.v2"] = DECODER_CONTRACT_VERSION  # type: ignore[assignment]
    conflict_type: ConflictType
    source_identity: str = Field(min_length=1, max_length=256)
    competing_mapping_identities: tuple[str, ...] = Field(
        min_length=2, max_length=MAX_COMPETING_MAPPINGS
    )
    competing_output_digests: tuple[str, ...] = Field(
        min_length=2, max_length=MAX_COMPETING_MAPPINGS
    )
    conflict_count: int = Field(ge=1, le=MAX_COMPETING_MAPPINGS)
    resolution_status: ResolutionStatus
    fail_closed_reason: str = Field(min_length=1, max_length=256)
    limitation_codes: tuple[str, ...] = Field(
        default=(), max_length=MAX_LIMITATION_CODES
    )

    @model_validator(mode="after")
    def validate_conflict(self) -> Self:
        if self.conflict_count != len(self.competing_mapping_identities):
            raise ValueError("conflict count mismatch")
        if len(self.competing_output_digests) != self.conflict_count:
            raise ValueError("competing output inventory mismatch")
        if (
            self.resolution_status is ResolutionStatus.PROVEN_UNIQUE
            and self.conflict_count > 1
        ):
            raise ValueError("multiple competing mappings cannot be proven unique")
        return self

    @property
    def evidence_identity(self) -> str:
        return canonical_sha256(self.model_dump(mode="json"))


class ActualTextSubstitutionEvidence(_Frozen):
    substitution_version: Literal["canonical_text_decoder.v2"] = (
        DECODER_CONTRACT_VERSION  # type: ignore[assignment]
    )
    marked_content_path_identity: str = Field(min_length=1, max_length=256)
    source_operation_start: int = Field(ge=0)
    source_operation_end_exclusive: int = Field(gt=0)
    raw_glyph_code_identities: tuple[str, ...] = Field(min_length=1, max_length=4096)
    actualtext_raw_digest: str = Field(pattern=SHA256_PATTERN)
    actualtext_unicode_evidence_identity: str = Field(min_length=1, max_length=256)
    substitution_scope: Literal["glyph", "operation", "marked_content_range"]
    nesting_depth: int = Field(ge=0, le=64)
    mcid: int | None = Field(default=None, ge=0)
    property_source_identity: str = Field(min_length=1, max_length=256)
    raw_actualtext_agreement: Literal["agree", "disagree", "unknown", "unavailable"]
    reversible: bool
    lossy: bool
    conflict_count: int = Field(ge=0)
    limitation_codes: tuple[str, ...] = Field(
        default=(), max_length=MAX_LIMITATION_CODES
    )

    @model_validator(mode="after")
    def validate_substitution(self) -> Self:
        if self.source_operation_end_exclusive <= self.source_operation_start:
            raise ValueError(
                "ActualText operation scope must be end-exclusive and non-empty"
            )
        if self.reversible and (
            self.lossy
            or self.conflict_count
            or self.raw_actualtext_agreement != "agree"
        ):
            raise ValueError(
                "reversible ActualText must agree with raw evidence without conflict"
            )
        return self

    @property
    def evidence_identity(self) -> str:
        return canonical_sha256(self.model_dump(mode="json"))


class DecoderResourceUsage(_Frozen):
    code_unit_count: int = Field(ge=0)
    mapping_step_count: int = Field(ge=0, le=MAX_MAPPING_STEPS)
    conflict_count: int = Field(ge=0, le=MAX_CONFLICTS)
    serialized_bytes: int = Field(ge=0, le=MAX_DECODER_INVENTORY_BYTES)
    resource_truncated: bool = False


def _has_cycle(steps: tuple[DecoderMappingStep, ...]) -> bool:
    graph: dict[str, set[str]] = {}
    for step in steps:
        graph.setdefault(step.input_identity, set()).add(step.output_identity)
    active: set[str] = set()
    done: set[str] = set()

    def visit(node: str) -> bool:
        if node in active:
            return True
        if node in done:
            return False
        active.add(node)
        if any(visit(child) for child in graph.get(node, ())):
            return True
        active.remove(node)
        done.add(node)
        return False

    return any(visit(node) for node in tuple(graph))


class DecoderEvidenceInventory(_Frozen):
    inventory_version: Literal["canonical_text_decoder.v2"] = DECODER_CONTRACT_VERSION  # type: ignore[assignment]
    authority_identity_digest: str = Field(pattern=SHA256_PATTERN)
    code_units: tuple[DecoderCodeUnit, ...] = Field(default=(), max_length=250_000)
    codespaces: tuple[DecoderCodeSpaceEvidence, ...] = Field(
        default=(), max_length=4096
    )
    font_codes: tuple[DecoderFontCodeEvidence, ...] = Field(
        default=(), max_length=250_000
    )
    cid_mappings: tuple[DecoderCIDMappingEvidence, ...] = Field(
        default=(), max_length=250_000
    )
    gid_mappings: tuple[DecoderGIDMappingEvidence, ...] = Field(
        default=(), max_length=250_000
    )
    unicode_sequences: tuple[DecoderUnicodeSequenceEvidence, ...] = Field(
        default=(), max_length=250_000
    )
    mapping_steps: tuple[DecoderMappingStep, ...] = Field(
        default=(), max_length=MAX_MAPPING_STEPS
    )
    conflicts: tuple[DecoderMappingConflict, ...] = Field(
        default=(), max_length=MAX_CONFLICTS
    )
    actualtext_substitutions: tuple[ActualTextSubstitutionEvidence, ...] = Field(
        default=(), max_length=4096
    )
    limitation_inventory: tuple[str, ...] = Field(
        default=(), max_length=MAX_LIMITATION_CODES
    )
    completeness: DecoderCompleteness
    resource_usage: DecoderResourceUsage
    inventory_digest: str = Field(pattern=SHA256_PATTERN)

    @model_validator(mode="after")
    def validate_inventory(self) -> Self:
        if (
            tuple(sorted(self.code_units, key=lambda item: item.deterministic_ordinal))
            != self.code_units
        ):
            raise ValueError("code units must use deterministic ordering")
        if (
            tuple(sorted(self.mapping_steps, key=lambda item: item.step_ordinal))
            != self.mapping_steps
        ):
            raise ValueError("mapping steps must use deterministic ordering")
        if len({item.deterministic_ordinal for item in self.code_units}) != len(
            self.code_units
        ):
            raise ValueError("code unit ordinals must be unique")
        if len({item.step_ordinal for item in self.mapping_steps}) != len(
            self.mapping_steps
        ):
            raise ValueError("mapping step ordinals must be unique")
        if self.mapping_steps and tuple(
            item.step_ordinal for item in self.mapping_steps
        ) != tuple(range(len(self.mapping_steps))):
            raise ValueError("mapping step ordinals must be contiguous")
        if _has_cycle(self.mapping_steps):
            raise ValueError("decoder mapping chain must be acyclic")
        if self.mapping_steps:
            if not self.code_units:
                raise ValueError("mapping steps require raw code evidence")
            bindings = {
                item.evidence_identity: (
                    item.source_artifact_sha256,
                    item.original_page_number,
                    item.content_path_identity,
                    item.text_show_operation_identity,
                )
                for item in self.code_units
            }
            known_fonts = {item.font_identity for item in self.codespaces} | {
                item.font_identity for item in self.font_codes
            }
            for mapping_step in self.mapping_steps:
                expected_binding = bindings.get(mapping_step.input_identity)
                if expected_binding is None:
                    raise ValueError("decoder mapping chain is broken")
                actual_binding = (
                    mapping_step.source_artifact_sha256,
                    mapping_step.original_page_number,
                    mapping_step.content_path_identity,
                    mapping_step.text_show_operation_identity,
                )
                if actual_binding != expected_binding:
                    raise ValueError(
                        "mapping step source/page/operation binding mismatch"
                    )
                if mapping_step.font_identity not in known_fonts:
                    raise ValueError("mapping step font binding mismatch")
                bindings[mapping_step.output_identity] = actual_binding
        if (
            self.resource_usage.code_unit_count != len(self.code_units)
            or self.resource_usage.mapping_step_count != len(self.mapping_steps)
            or self.resource_usage.conflict_count != len(self.conflicts)
        ):
            raise ValueError("decoder resource inventory count mismatch")
        if self.resource_usage.serialized_bytes > MAX_DECODER_INVENTORY_BYTES:
            raise ValueError("decoder inventory exceeds serialized resource bound")
        unsafe_step = any(
            step.lossy
            or step.ambiguous
            or step.conflict_count
            or step.method
            in {DecoderMappingMethod.UNMAPPED, DecoderMappingMethod.UNSUPPORTED}
            for step in self.mapping_steps
        )
        if self.completeness is DecoderCompleteness.COMPLETE:
            if not self.code_units or any(
                item.segmentation_status is not SegmentationStatus.PROVEN
                for item in self.code_units
            ):
                raise ValueError(
                    "complete decoder inventory requires proven raw code boundaries"
                )
            if (
                self.conflicts
                or self.limitation_inventory
                or self.resource_usage.resource_truncated
                or unsafe_step
            ):
                raise ValueError(
                    "complete decoder inventory cannot contain conflict, loss, limitation, or truncation"
                )
            if any(
                not item.reversible or item.lossy or item.unmapped
                for item in self.unicode_sequences
            ):
                raise ValueError(
                    "complete decoder inventory requires reversible Unicode mappings"
                )
        if self.completeness is DecoderCompleteness.UNAVAILABLE_BY_CONTRACT_VERSION:
            raise ValueError("v2 inventory cannot claim v1 contract unavailability")
        if self.inventory_digest != canonical_sha256(
            _identity_payload(self, "inventory_digest")
        ):
            raise ValueError("decoder inventory digest mismatch")
        return self


class CanonicalEvidenceBundleV2(_Frozen):
    bundle_contract_version: Literal["canonical_evidence_bundle.v2"] = (
        CANONICAL_EVIDENCE_BUNDLE_V2_VERSION  # type: ignore[assignment]
    )
    authority_identity: CanonicalTextAuthorityIdentity
    content_paths: tuple[CanonicalContentPath, ...] = ()
    glyph_evidence: tuple[CanonicalGlyphEvidence, ...] = ()
    canonical_stream_digest: str = Field(pattern=SHA256_PATTERN)
    mapping_segments: tuple[CrossParserMappingEvidence, ...] = ()
    parser_lineage: tuple[ParserLineageEvidence, ...] = ()
    limitation_codes: tuple[str, ...] = Field(
        default=(), max_length=MAX_LIMITATION_CODES
    )
    resource_policy: ResourcePolicy
    generation_completeness: Literal["complete", "partial", "unavailable"]
    decoder_evidence: DecoderEvidenceInventory
    decoder_evidence_digest: str = Field(pattern=SHA256_PATTERN)
    decoder_provenance_completeness: DecoderCompleteness
    v1_compatibility_reference: str = Field(pattern=SHA256_PATTERN)
    bundle_v2_digest: str = Field(pattern=SHA256_PATTERN)

    @model_validator(mode="after")
    def validate_v2(self) -> Self:
        if self.authority_identity.generation_mode is CanonicalAuthorityMode.OFF:
            raise ValueError("OFF mode cannot generate a v2 decoder bundle")
        if self.decoder_evidence.authority_identity_digest != canonical_sha256(
            self.authority_identity.model_dump(mode="json")
        ):
            raise ValueError("decoder inventory authority mismatch")
        if self.decoder_evidence_digest != self.decoder_evidence.inventory_digest:
            raise ValueError("decoder evidence digest binding mismatch")
        if (
            self.decoder_provenance_completeness
            is not self.decoder_evidence.completeness
        ):
            raise ValueError("decoder completeness binding mismatch")
        if (
            self.decoder_provenance_completeness is DecoderCompleteness.COMPLETE
            and self.generation_completeness != "complete"
        ):
            raise ValueError(
                "decoder-complete bundle requires complete raw authority generation"
            )
        if self.bundle_v2_digest != canonical_sha256(
            _identity_payload(self, "bundle_v2_digest")
        ):
            raise ValueError("v2 bundle digest mismatch")
        return self


def v1_decoder_provenance_status(
    bundle: CanonicalEvidenceBundle,
) -> DecoderCompleteness:
    """Return the only valid decoder status for an immutable v1 bundle."""
    if not isinstance(bundle, CanonicalEvidenceBundle):
        raise TypeError("expected a CTIF v1 CanonicalEvidenceBundle")
    return DecoderCompleteness.UNAVAILABLE_BY_CONTRACT_VERSION


def reject_v1_automatic_upgrade(bundle: CanonicalEvidenceBundle) -> None:
    """Fail closed: v1 evidence cannot be promoted into v2 provenance."""
    if isinstance(bundle, CanonicalEvidenceBundle):
        raise ValueError(
            "CTIF v1 evidence cannot be automatically upgraded to decoder provenance v2"
        )

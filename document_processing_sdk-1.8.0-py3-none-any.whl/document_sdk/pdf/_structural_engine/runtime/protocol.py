# ruff: noqa: C901

"""Private JSON/NDJSON worker response parsing."""

import json
import re

from document_sdk.pdf._structural_engine.runtime.contracts import (
    PdfIsolatedBenchmarkResult,
)


def _parse_worker_output(
    output: bytes,
) -> tuple[dict[str, object], bool, PdfIsolatedBenchmarkResult | None]:
    preflight: dict[str, object] = {}
    parser_started = False
    result = None
    try:
        lines = output.decode("utf-8").splitlines()
    except UnicodeDecodeError:
        return preflight, parser_started, None
    for line in lines:
        try:
            event = json.loads(line)
        except (json.JSONDecodeError, TypeError):
            continue
        if not isinstance(event, dict):
            continue
        if event.get("event") == "preflight":
            document_hash = event.get("document_sha256")
            source_size = event.get("source_size_bytes")
            if isinstance(document_hash, str) and re.fullmatch(
                r"[0-9a-f]{64}", document_hash
            ):
                preflight["document_sha256"] = document_hash
            if isinstance(source_size, int) and source_size >= 0:
                preflight["source_size_bytes"] = source_size
            identity_matches_expected = event.get("identity_matches_expected")
            if isinstance(identity_matches_expected, bool):
                preflight["identity_matches_expected"] = identity_matches_expected
        elif event.get("event") == "parser_started":
            parser_started = True
        elif event.get("event") == "result":
            try:
                result = PdfIsolatedBenchmarkResult.model_validate(event.get("result"))
            except (TypeError, ValueError):
                result = None
    return preflight, parser_started, result

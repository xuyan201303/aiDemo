# ruff: noqa: C901, D202, EM101, PLR0911, PLR0912, PLR0913, PLR0915, TRY003

"""Private worker protocol and result integrity contracts."""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from document_sdk.pdf._structural_engine.facts.capabilities import (
    PdfParserCapabilities,
)
from document_sdk.pdf._structural_engine.facts.limits import (
    PdfExtractionLimits,
    PdfExtractionOptions,
    PdfExtractionScope,
    canonical_request_scope_inventory_sha256,
)
from document_sdk.pdf._structural_engine.facts.status import (
    PDF_COMPLETE_SCOPE_EXTRACTION_STATUSES,
    PDF_PARTIAL_SCOPE_EXTRACTION_STATUSES,
    PdfExtractionStatus,
)

PDF_ISOLATED_BENCHMARK_SCHEMA_VERSION: Literal["pdf_isolated_benchmark.v1"] = (
    "pdf_isolated_benchmark.v1"
)
PDF_WORKER_PROTOCOL_VERSION: Literal["pdf_fact_worker.v2"] = "pdf_fact_worker.v2"
PDF_WORKER_PROTOCOL_V1: Literal["pdf_fact_worker.v1"] = "pdf_fact_worker.v1"
PDF_WORKER_SCOPE_RESULT_INVARIANT_CONTRACT_VERSION = "pdf_worker_scope_invariants.v1"
PDF_ADAPTER_TRAVERSAL_METRIC_SEMANTICS = "adapter_observable_only"
PDF_FACT_WORKER_MODE: Literal["fact_extraction"] = "fact_extraction"
PDF_COMPLETED_PAYLOAD_INVARIANT_CONTRACT_VERSION = (
    "pdf_completed_worker_payload_invariants.v2"
)
PDF_EXTRACTION_STATUS_CONSISTENCY_CONTRACT_VERSION = (
    "pdf_extraction_status_consistency.v1"
)
PDF_WORKER_PROCESS_OUTCOME_CONTRACT_VERSION = "pdf_worker_process_outcome.v1"

PdfWorkerExitMode = Literal[
    "completed",
    "rejected",
    "timeout_terminated",
    "timeout_killed",
    "crashed",
    "launch_error",
    "protocol_error",
]
PdfWorkerErrorCategory = Literal[
    "none",
    "unsafe_source",
    "file_too_large",
    "source_changed",
    "short_read",
    "parser_unavailable",
    "parser_error",
    "timeout",
    "crash",
    "worker_protocol_error",
    "resource_limit_setup",
    "corpus_identity_mismatch",
    "probable_memory_limit",
    "internal_error",
    "invalid_request",
]
PdfWorkerExitClassification = Literal[
    "completed",
    "rejected",
    "sigxcpu",
    "hard_wall_timeout_terminated",
    "hard_wall_timeout_killed",
    "probable_memory_limit_exit",
    "parser_crash",
    "unknown_abnormal_exit",
    "launch_error",
    "protocol_error",
]
PdfWorkerProtocolErrorReason = Literal[
    "invalid_worker_output",
    "protocol_version_mismatch",
    "parser_name_mismatch",
    "document_label_mismatch",
    "worker_mode_mismatch",
    "scope_mode_mismatch",
    "requested_page_count_mismatch",
    "requested_inventory_digest_mismatch",
    "document_identity_mismatch",
    "source_page_count_mismatch",
    "page_inventory_mismatch",
    "requested_case_count_mismatch",
    "requested_case_inventory_digest_mismatch",
    "returned_case_inventory_mismatch",
    "duplicate_case_result",
    "case_page_scope_mismatch",
    "product_preflight_payload_mismatch",
    "product_parser_payload_mismatch",
    "gold_case_provenance_mismatch",
    "gold_locator_inventory_mismatch",
    "gold_relation_probe_inventory_mismatch",
    "gold_separator_probe_inventory_mismatch",
    "gold_source_provenance_mismatch",
]
PdfProbeMatchStatus = Literal["matched", "mismatched", "not_evaluated"]
PdfTextProbeStatus = Literal["found", "missing", "not_evaluated"]
PdfImageProbeStatus = Literal[
    "matched",
    "mismatched",
    "unavailable",
    "not_evaluated",
]

PDF_WORKER_EXIT_CLASSIFICATIONS_BY_MODE: dict[
    PdfWorkerExitMode,
    frozenset[PdfWorkerExitClassification],
] = {
    "completed": frozenset({"completed"}),
    "protocol_error": frozenset({"protocol_error"}),
    "launch_error": frozenset({"launch_error"}),
    "timeout_terminated": frozenset({"hard_wall_timeout_terminated"}),
    "timeout_killed": frozenset({"hard_wall_timeout_killed"}),
    "crashed": frozenset(
        {
            "sigxcpu",
            "probable_memory_limit_exit",
            "parser_crash",
            "unknown_abnormal_exit",
        }
    ),
    "rejected": frozenset(
        {
            "rejected",
            "probable_memory_limit_exit",
            "unknown_abnormal_exit",
        }
    ),
}


def validate_worker_process_outcome_integrity(
    *,
    protocol_version: str,
    legacy_protocol_version: str,
    exit_mode: PdfWorkerExitMode,
    exit_classification: PdfWorkerExitClassification | None,
    timed_out: bool,
    killed: bool,
    signal_number: int | None,
    exit_code: int | None,
    protocol_error_reason: PdfWorkerProtocolErrorReason | None,
    error_category: str,
) -> None:
    """Validate current worker process outcomes without changing historical v1."""

    if protocol_version == legacy_protocol_version:
        return
    if exit_classification not in PDF_WORKER_EXIT_CLASSIFICATIONS_BY_MODE[exit_mode]:
        raise ValueError("worker exit mode and classification are inconsistent")
    if (exit_mode == "protocol_error") != (protocol_error_reason is not None):
        raise ValueError(
            "protocol error exit and machine-readable reason must be paired"
        )
    if exit_mode == "completed":
        if timed_out or killed or signal_number is not None or exit_code != 0:
            raise ValueError("completed worker has an invalid process outcome")
    elif exit_mode == "protocol_error":
        if timed_out or killed or signal_number is not None:
            raise ValueError("protocol error worker has an invalid process outcome")
        if error_category != "worker_protocol_error":
            raise ValueError("protocol error requires the worker protocol category")
    elif exit_mode == "launch_error":
        if timed_out or killed or signal_number is not None:
            raise ValueError("launch error worker has an invalid process outcome")
    elif exit_mode == "timeout_terminated":
        if not timed_out or killed:
            raise ValueError("terminated timeout has inconsistent process flags")
    elif exit_mode == "timeout_killed":
        if not timed_out or not killed:
            raise ValueError("killed timeout has inconsistent process flags")
    elif exit_mode == "rejected" and (timed_out or killed or signal_number is not None):
        raise ValueError("rejected worker has an invalid process outcome")


def validate_worker_scope_result_integrity(
    *,
    protocol_version: str,
    legacy_protocol_version: str,
    scope_mode: Literal["full_document", "selected_pages"],
    requested_page_count: int,
    extracted_requested_page_count: int,
    missing_requested_page_count: int,
    incomplete_requested_page_count: int,
    requested_scope_complete: bool,
    source_document_fully_extracted: bool,
    page_count: int,
    extracted_page_count: int,
    pages_attempted: int,
    artifact_generated: bool,
    partial_extraction: bool,
    extraction_status: PdfExtractionStatus | str | None = None,
    page_numbers: tuple[int, ...] | None = None,
    requested_page_numbers: tuple[int, ...] | None = None,
) -> None:
    """Validate the shared Fact/Layout worker scope summary."""

    counts = (
        requested_page_count,
        extracted_requested_page_count,
        missing_requested_page_count,
        incomplete_requested_page_count,
        page_count,
        extracted_page_count,
        pages_attempted,
    )
    if any(count < 0 for count in counts):
        raise ValueError("worker scope counts cannot be negative")
    if protocol_version == legacy_protocol_version and scope_mode == "selected_pages":
        raise ValueError("selected-page scope requires worker protocol v2")
    if extracted_requested_page_count > requested_page_count:
        raise ValueError("worker extraction exceeds its requested page count")
    if extracted_page_count > pages_attempted:
        raise ValueError("worker extracted page count exceeds pages attempted")
    if incomplete_requested_page_count > extracted_requested_page_count:
        raise ValueError("incomplete page count exceeds extracted requested pages")
    if missing_requested_page_count != (
        requested_page_count - extracted_requested_page_count
    ):
        raise ValueError("worker missing page count is inconsistent")
    if requested_scope_complete and (
        extracted_requested_page_count != requested_page_count
        or missing_requested_page_count
        or incomplete_requested_page_count
    ):
        raise ValueError("complete worker scope has incomplete page counts")
    if source_document_fully_extracted:
        if not requested_scope_complete:
            raise ValueError("full source extraction requires a complete request scope")
        if partial_extraction:
            raise ValueError("partial extraction cannot claim full source extraction")
        if not (
            requested_page_count
            == extracted_requested_page_count
            == extracted_page_count
            == page_count
        ):
            raise ValueError("full source extraction has inconsistent page counts")
        if missing_requested_page_count or incomplete_requested_page_count:
            raise ValueError("full source extraction cannot have incomplete pages")
    current_protocol = protocol_version != legacy_protocol_version
    if artifact_generated:
        if extracted_page_count != extracted_requested_page_count:
            raise ValueError(
                "artifact page count must equal extracted requested page count"
            )
        if scope_mode == "full_document" and requested_page_count != page_count:
            raise ValueError("full-document request count must equal source page count")
        if current_protocol:
            if requested_scope_complete and partial_extraction:
                raise ValueError("complete worker scope cannot be partial")
            if not requested_scope_complete and not partial_extraction:
                raise ValueError("incomplete worker scope must be partial")
            normalized_status = (
                extraction_status.value
                if isinstance(extraction_status, PdfExtractionStatus)
                else extraction_status
            )
            complete_statuses = {
                status.value for status in PDF_COMPLETE_SCOPE_EXTRACTION_STATUSES
            }
            partial_statuses = {
                status.value for status in PDF_PARTIAL_SCOPE_EXTRACTION_STATUSES
            }
            if requested_scope_complete and normalized_status not in complete_statuses:
                raise ValueError("complete worker scope has an incompatible status")
            if (
                not requested_scope_complete
                and normalized_status not in partial_statuses
            ):
                raise ValueError("partial worker scope has an incompatible status")
    if requested_page_numbers is not None:
        if tuple(sorted(set(requested_page_numbers))) != requested_page_numbers:
            raise ValueError("requested page inventory must be canonical")
        if any(page_number <= 0 for page_number in requested_page_numbers):
            raise ValueError("requested page inventory must be positive and 1-based")
        if scope_mode == "selected_pages" and requested_page_count != len(
            requested_page_numbers
        ):
            raise ValueError("selected request count does not match its inventory")
    if page_numbers is not None:
        if len(page_numbers) != len(set(page_numbers)):
            raise ValueError("worker page inventory contains duplicates")
        if any(page_number <= 0 for page_number in page_numbers):
            raise ValueError("worker page inventory must be positive and 1-based")
        if artifact_generated and len(page_numbers) != extracted_page_count:
            raise ValueError("worker page inventory count is inconsistent")
        if scope_mode == "selected_pages" and requested_page_numbers is not None:
            if not set(page_numbers) <= set(requested_page_numbers):
                raise ValueError("worker returned a page outside the selected scope")
        elif scope_mode == "full_document" and any(
            page_number > page_count for page_number in page_numbers
        ):
            raise ValueError("worker returned a page outside the source document")


def worker_response_binding_error(
    *,
    request_protocol_version: str,
    response_protocol_version: str,
    request_document_label: str,
    response_document_label: str,
    request_parser_name: str,
    response_parser_name: str,
    request_scope: PdfExtractionScope,
    response_scope_mode: str,
    response_requested_page_count: int,
    response_requested_page_inventory_sha256: str,
    response_exit_mode: PdfWorkerExitMode,
    expected_document_sha256: str | None,
    expected_source_size_bytes: int | None,
    expected_page_count: int | None,
    response_document_sha256: str | None,
    response_source_size_bytes: int | None,
    response_page_count: int,
    response_expected_page_count: int | None,
    response_page_count_matches_expected: bool | None,
    response_identity_matches_expected: bool | None,
    response_page_numbers: tuple[int, ...] = (),
    request_worker_mode: str | None = None,
    response_worker_mode: str | None = None,
) -> PdfWorkerProtocolErrorReason | None:
    """Return the first bounded request/response binding mismatch."""

    if response_protocol_version != request_protocol_version:
        return "protocol_version_mismatch"
    if response_parser_name != request_parser_name:
        return "parser_name_mismatch"
    if response_document_label != request_document_label:
        return "document_label_mismatch"
    if request_worker_mode is not None and response_worker_mode != request_worker_mode:
        return "worker_mode_mismatch"
    if response_scope_mode != request_scope.mode.value:
        return "scope_mode_mismatch"
    expected_requested_page_count = (
        len(request_scope.requested_page_numbers)
        if request_scope.mode.value == "selected_pages"
        else (
            expected_page_count
            if response_exit_mode == "completed" and expected_page_count is not None
            else response_requested_page_count
        )
    )
    if response_requested_page_count != expected_requested_page_count:
        return "requested_page_count_mismatch"
    if response_requested_page_inventory_sha256 != (
        canonical_request_scope_inventory_sha256(request_scope)
    ):
        return "requested_inventory_digest_mismatch"
    if response_exit_mode == "completed":
        if expected_document_sha256 is not None and (
            response_document_sha256 != expected_document_sha256
            or response_identity_matches_expected is not True
        ):
            return "document_identity_mismatch"
        if expected_source_size_bytes is not None and (
            response_source_size_bytes != expected_source_size_bytes
            or response_identity_matches_expected is not True
        ):
            return "document_identity_mismatch"
        if (
            expected_page_count is not None
            and response_page_count != expected_page_count
        ):
            return "source_page_count_mismatch"
    if response_expected_page_count != expected_page_count:
        return "source_page_count_mismatch"
    expected_page_count_match = (
        response_page_count == expected_page_count
        if expected_page_count is not None
        else None
    )
    if response_page_count_matches_expected != expected_page_count_match:
        return "source_page_count_mismatch"
    if len(response_page_numbers) != len(set(response_page_numbers)):
        return "page_inventory_mismatch"
    if request_scope.mode.value == "selected_pages":
        if not set(response_page_numbers) <= set(request_scope.requested_page_numbers):
            return "page_inventory_mismatch"
    elif response_page_numbers and any(
        page_number < 1 or page_number > response_page_count
        for page_number in response_page_numbers
    ):
        return "page_inventory_mismatch"
    return None


class PdfHumanReviewProbe(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    probe_id: str = Field(pattern=r"^[a-z0-9][a-z0-9-]{2,95}$")
    page_number: int = Field(ge=1)
    expected_short_text: tuple[str, ...] = Field(default_factory=tuple, max_length=8)
    expected_page_rotation: Literal[0, 90, 180, 270]
    expected_drawing_presence: bool
    expected_image_presence: bool | None = None


class PdfHumanReviewTextProbeResult(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    text_probe_id: str = Field(pattern=r"^[a-z0-9][a-z0-9-]{2,111}$")
    status: PdfTextProbeStatus


class PdfHumanReviewProbeResult(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    probe_id: str = Field(pattern=r"^[a-z0-9][a-z0-9-]{2,95}$")
    parser_name: str = Field(min_length=1, max_length=64)
    page_number: int = Field(ge=1)
    page_evaluated: bool
    text_results: tuple[PdfHumanReviewTextProbeResult, ...] = ()
    rotation_status: PdfProbeMatchStatus
    drawing_status: PdfProbeMatchStatus
    image_status: PdfImageProbeStatus


class PdfWorkerResourceLimits(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    hard_timeout_seconds: float = Field(default=150.0, gt=0)
    terminate_grace_seconds: float = Field(default=2.0, gt=0)
    max_stdout_bytes: int = Field(default=2 * 1024 * 1024, ge=4_096)
    max_stderr_bytes: int = Field(default=16 * 1024, ge=0, le=1024 * 1024)
    max_address_space_bytes: int | None = Field(default=None, ge=128 * 1024 * 1024)
    max_cpu_seconds: int | None = Field(default=None, ge=1)
    max_open_files: int | None = Field(default=256, ge=32)
    parent_rss_sample_interval_seconds: float = Field(
        default=0.1,
        ge=0.05,
        le=5.0,
    )


class PdfWorkerRequest(BaseModel):
    """Internal worker request. `source_path` never appears in a result."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    protocol_version: Literal["pdf_fact_worker.v1", "pdf_fact_worker.v2"] = (
        PDF_WORKER_PROTOCOL_VERSION
    )
    worker_mode: Literal["fact_extraction"] = PDF_FACT_WORKER_MODE
    source_path: str = Field(min_length=1, max_length=4_096)
    document_label: str = Field(min_length=1, max_length=128)
    parser_name: Literal["pypdf", "pdfplumber", "pypdfium2"]
    extraction_limits: PdfExtractionLimits
    extraction_options: PdfExtractionOptions
    worker_limits: PdfWorkerResourceLimits
    expected_document_sha256: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )
    expected_source_size_bytes: int | None = Field(default=None, ge=0)
    expected_page_count: int | None = Field(default=None, ge=1)
    human_review_probes: tuple[PdfHumanReviewProbe, ...] = Field(
        default_factory=tuple,
        max_length=32,
    )

    @model_validator(mode="after")
    def validate_protocol_scope(self) -> "PdfWorkerRequest":
        if (
            self.protocol_version == PDF_WORKER_PROTOCOL_V1
            and self.extraction_options.extraction_scope.mode.value == "selected_pages"
        ):
            raise ValueError("selected-page extraction requires worker protocol v2")
        return self


class PdfWorkerPageIdentityFingerprint(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    page_number: int = Field(ge=1)
    page_id_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    fact_id_inventory_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    fact_count: int = Field(ge=0)


class PdfIsolatedBenchmarkResult(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    schema_version: Literal["pdf_isolated_benchmark.v1"] = (
        PDF_ISOLATED_BENCHMARK_SCHEMA_VERSION
    )
    worker_protocol_version: Literal[
        "pdf_fact_worker.v1",
        "pdf_fact_worker.v2",
    ] = PDF_WORKER_PROTOCOL_VERSION
    worker_mode: Literal["fact_extraction"] = PDF_FACT_WORKER_MODE
    document_label: str = Field(min_length=1, max_length=128)
    document_sha256: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    parser_name: str = Field(min_length=1, max_length=64)
    parser_version: str | None = Field(default=None, max_length=64)
    extraction_status: PdfExtractionStatus | None = None
    partial_extraction: bool = False
    diagnostics_truncated: bool = False
    exit_mode: PdfWorkerExitMode
    exit_classification: PdfWorkerExitClassification | None = None
    timed_out: bool = False
    killed: bool = False
    exit_code: int | None = None
    signal: int | None = Field(default=None, ge=1)
    elapsed_milliseconds: float = Field(default=0, ge=0)
    cpu_time_milliseconds: float | None = Field(default=None, ge=0)
    peak_rss_bytes: int | None = Field(default=None, ge=0)
    peak_rss_measurement: str = Field(default="unavailable", max_length=64)
    parent_observed_peak_rss_bytes: int | None = Field(default=None, ge=0)
    parent_rss_measurement: str = Field(default="unavailable", max_length=64)
    parent_rss_sample_interval_seconds: float | None = Field(default=None, ge=0)
    peak_python_heap_bytes: int | None = Field(default=None, ge=0)
    artifact_serialized_bytes: int | None = Field(default=None, ge=0)
    source_size_bytes: int | None = Field(default=None, ge=0)
    identity_matches_expected: bool | None = None
    page_count: int = Field(default=0, ge=0)
    expected_page_count: int | None = Field(default=None, ge=1)
    page_count_matches_expected: bool | None = None
    extracted_page_count: int = Field(default=0, ge=0)
    pages_attempted: int = Field(default=0, ge=0)
    adapter_page_traversal_count: int = Field(
        default=0,
        ge=0,
        description=(
            "Adapter-observable extraction loop visits; parser-internal page-tree, "
            "xref, cache, and document-open work is outside this metric."
        ),
    )
    unrequested_page_content_traversal_count: int = Field(
        default=0,
        ge=0,
        description=(
            "Adapter-observable unrequested page content visits only; native and "
            "parser-internal document inventory work is not measured."
        ),
    )
    extraction_scope_mode: Literal["full_document", "selected_pages"] = "full_document"
    requested_page_count: int = Field(default=0, ge=0)
    requested_page_inventory_sha256: str = Field(
        default_factory=lambda: canonical_request_scope_inventory_sha256(
            PdfExtractionScope()
        ),
        pattern=r"^[0-9a-f]{64}$",
    )
    extracted_requested_page_count: int = Field(default=0, ge=0)
    missing_requested_page_count: int = Field(default=0, ge=0)
    incomplete_requested_page_count: int = Field(default=0, ge=0)
    requested_scope_complete: bool = False
    source_document_fully_extracted: bool = False
    text_span_count: int = Field(default=0, ge=0)
    word_count: int = Field(default=0, ge=0)
    line_candidate_count: int = Field(default=0, ge=0)
    character_count: int = Field(default=0, ge=0)
    text_span_font_name_available_count: int = Field(default=0, ge=0)
    text_span_font_size_available_count: int = Field(default=0, ge=0)
    text_span_rotation_available_count: int = Field(default=0, ge=0)
    text_span_rotation_count_by_quadrant: dict[str, int] = Field(default_factory=dict)
    drawing_count: int = Field(default=0, ge=0)
    path_segment_count: int = Field(default=0, ge=0)
    path_segment_truncated_drawing_count: int = Field(default=0, ge=0)
    drawing_count_by_kind: dict[str, int] = Field(default_factory=dict)
    drawing_bbox_quality_count: dict[str, int] = Field(default_factory=dict)
    drawing_paint_operation_count: dict[str, int] = Field(default_factory=dict)
    clipping_path_count: int = Field(default=0, ge=0)
    image_region_count: int = Field(default=0, ge=0)
    image_region_parser_available_count: int = Field(default=0, ge=0)
    total_fact_count: int = Field(default=0, ge=0)
    page_rotation_count: dict[str, int] = Field(default_factory=dict)
    page_geometry_completeness_count: dict[str, int] = Field(default_factory=dict)
    page_geometry_confidence_count: dict[str, int] = Field(default_factory=dict)
    page_geometry_source_count: dict[str, int] = Field(default_factory=dict)
    warning_occurrence_count: int = Field(default=0, ge=0)
    suppressed_warning_count: int = Field(default=0, ge=0)
    suppressed_warning_count_by_code: dict[str, int] = Field(default_factory=dict)
    warning_count_by_scope: dict[str, int] = Field(default_factory=dict)
    warning_count_by_code: dict[str, int] = Field(default_factory=dict)
    text_fragmentation_ratio: float = Field(default=0, ge=0)
    single_character_span_ratio: float = Field(default=0, ge=0)
    whitespace_inflation_ratio: float = Field(default=0, ge=0)
    duplicate_text_ratio: float = Field(default=0, ge=0)
    normalized_text_character_count: int = Field(default=0, ge=0)
    normalized_text_sha256: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    deterministic_digest: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    parser_capabilities: PdfParserCapabilities | None = None
    page_identity_fingerprints: tuple[PdfWorkerPageIdentityFingerprint, ...] = ()
    parser_error_category: PdfWorkerErrorCategory = Field(
        default="none",
        description=(
            "Worker process category; a completed Artifact may still report a typed "
            "parser domain status without representing a process crash."
        ),
    )
    protocol_error_reason: PdfWorkerProtocolErrorReason | None = None
    error_message: str | None = Field(default=None, max_length=240)
    stderr_excerpt: str = Field(default="", max_length=4_096)
    stderr_truncated: bool = False
    human_review_probe_results: tuple[PdfHumanReviewProbeResult, ...] = ()

    @model_validator(mode="after")
    def validate_scope_summary(self) -> "PdfIsolatedBenchmarkResult":
        validate_worker_process_outcome_integrity(
            protocol_version=self.worker_protocol_version,
            legacy_protocol_version=PDF_WORKER_PROTOCOL_V1,
            exit_mode=self.exit_mode,
            exit_classification=self.exit_classification,
            timed_out=self.timed_out,
            killed=self.killed,
            signal_number=self.signal,
            exit_code=self.exit_code,
            protocol_error_reason=self.protocol_error_reason,
            error_category=self.parser_error_category,
        )
        artifact_generated = self.artifact_serialized_bytes is not None
        validate_worker_scope_result_integrity(
            protocol_version=self.worker_protocol_version,
            legacy_protocol_version=PDF_WORKER_PROTOCOL_V1,
            scope_mode=self.extraction_scope_mode,
            requested_page_count=self.requested_page_count,
            extracted_requested_page_count=self.extracted_requested_page_count,
            missing_requested_page_count=self.missing_requested_page_count,
            incomplete_requested_page_count=self.incomplete_requested_page_count,
            requested_scope_complete=self.requested_scope_complete,
            source_document_fully_extracted=self.source_document_fully_extracted,
            page_count=self.page_count,
            extracted_page_count=self.extracted_page_count,
            pages_attempted=self.pages_attempted,
            artifact_generated=artifact_generated,
            partial_extraction=self.partial_extraction,
            extraction_status=self.extraction_status,
            page_numbers=(
                tuple(
                    fingerprint.page_number
                    for fingerprint in self.page_identity_fingerprints
                )
                if (
                    self.worker_protocol_version == PDF_WORKER_PROTOCOL_VERSION
                    or self.page_identity_fingerprints
                )
                else None
            ),
        )
        if self.worker_protocol_version == PDF_WORKER_PROTOCOL_VERSION:
            expected_page_count_match = (
                self.page_count == self.expected_page_count
                if self.expected_page_count is not None
                else None
            )
            if self.page_count_matches_expected != expected_page_count_match:
                raise ValueError(
                    "Fact worker expected page-count result is inconsistent"
                )
            if self.exit_mode == "completed":
                required_payload = (
                    self.document_sha256,
                    self.source_size_bytes,
                    self.extraction_status,
                    self.parser_version,
                    self.artifact_serialized_bytes,
                    self.deterministic_digest,
                    self.parser_capabilities,
                )
                if any(value is None for value in required_payload):
                    raise ValueError(
                        "completed Fact worker result requires its artifact payload"
                    )
                if not self.artifact_serialized_bytes:
                    raise ValueError(
                        "completed Fact worker result requires a nonempty artifact"
                    )
                if self.identity_matches_expected is False:
                    raise ValueError(
                        "completed Fact worker result cannot fail source identity"
                    )
                if self.extraction_status is PdfExtractionStatus.INVALID_REQUEST:
                    raise ValueError(
                        "invalid request cannot be a completed Fact worker result"
                    )
                if len(self.page_identity_fingerprints) != self.extracted_page_count:
                    raise ValueError(
                        "completed Fact worker result requires every page fingerprint"
                    )
            else:
                if self.extraction_status is PdfExtractionStatus.SUCCESS:
                    raise ValueError("non-completed Fact worker cannot report success")
                if (
                    self.requested_scope_complete
                    or self.source_document_fully_extracted
                ):
                    raise ValueError(
                        "non-completed Fact worker cannot report a complete scope"
                    )
                if (
                    self.artifact_serialized_bytes is not None
                    or self.deterministic_digest is not None
                    or self.parser_capabilities is not None
                    or self.page_identity_fingerprints
                ):
                    raise ValueError(
                        "non-completed Fact worker cannot retain artifact identity"
                    )
        return self

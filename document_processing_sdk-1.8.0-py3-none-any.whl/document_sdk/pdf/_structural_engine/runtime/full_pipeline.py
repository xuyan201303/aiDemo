# ruff: noqa: C901, EM101, PLR0912, PLR0915, TRY003

"""Thin orchestration over the existing private structural builders."""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from time import monotonic
from typing import TYPE_CHECKING, Literal

import pypdfium2 as pdfium
import pypdfium2.raw as pdfium_c

from document_sdk.core import DocumentProcessingError, EncryptedDocumentError
from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.pdf._document import (
    _encrypted_pdf_access_message,
    _preflight_document,
    enforce_native_text_page_limit,
)
from document_sdk.pdf._structural_engine.canonical import (
    CanonicalArtifactBundle,
    CanonicalProjectionLimits,
)
from document_sdk.pdf._structural_engine.facts.limits import (
    PdfExtractionLimits,
    PdfExtractionOptions,
    PdfSource,
)
from document_sdk.pdf._structural_engine.layout.builder import PdfLayoutGraphBuilder
from document_sdk.pdf._structural_engine.layout.limits import PdfLayoutGraphLimits
from document_sdk.pdf._structural_engine.parsers import (
    PdfPlumberFactExtractor,
    create_pdf_fact_extractor,
)
from document_sdk.pdf._structural_engine.structure.document_table_assembly import (
    assemble_document_tables,
)
from document_sdk.pdf._structural_engine.structure.document_table_contracts import (
    PdfDocumentTable,
    PdfDocumentTableManifest,
    PdfPhase3DResourceContract,
    PdfTablePageTransition,
    build_document_table_manifest,
    build_table_page_transition,
)
from document_sdk.pdf._structural_engine.structure.document_table_fingerprint import (
    PdfTableTransitionFingerprint,
    PdfTransitionFingerprintInputAuthority,
    PdfTransitionFingerprintResourceContract,
    build_transition_fingerprint_from_authority,
)
from document_sdk.pdf._structural_engine.structure.document_table_input_adapter import (
    PdfTransitionTableInputAuthority,
    build_page_transition_inputs,
)
from document_sdk.pdf._structural_engine.structure.document_table_transition import (
    evaluate_adjacent_candidates,
)
from document_sdk.pdf._structural_engine.structure.identity import (
    canonical_json_bytes,
    canonical_sha256,
)
from document_sdk.pdf._structural_engine.structure.reading_algorithm import (
    PHASE3B_READING_ALGORITHM_VERSION,
    PHASE3B_READING_OPERATION_VERSION,
    build_reading_structure_page,
    phase3b_reading_configuration_identity,
)
from document_sdk.pdf._structural_engine.structure.reading_contracts import (
    PdfReadingStructurePageReference,
)
from document_sdk.pdf._structural_engine.structure.reading_input import (
    PdfPageScopedFactSnapshot,
    PdfPageScopedLayoutSnapshot,
    PdfPageScopedReference,
    PdfReadingPagePayload,
    build_reading_page_authority,
    build_reading_page_evidence,
    build_unavailable_reading_canonical_evidence,
)
from document_sdk.pdf._structural_engine.structure.table_algorithm import (
    PdfTableAlgorithmConfig,
    build_table_structure_page_from_inherited,
)
from document_sdk.pdf._structural_engine.structure.table_contracts import (
    PdfTableStructurePageReference,
    PdfTableStructurePageSidecar,
)
from document_sdk.pdf._structural_engine.structure.table_document_manifest import (
    PdfTableDocumentManifest,
    build_table_manifest,
)
from document_sdk.pdf._text import extract_bounded_page_text
from document_sdk.pdf._xref_keyword_recovery import verified_parser_view
from document_sdk.pdf.errors import PdfLimitExceededError
from document_sdk.pdf.models import PdfProcessingLimits

if TYPE_CHECKING:
    from document_sdk.pdf._structural_engine.facts.contracts import PdfFactArtifact

_DEPENDENCY = canonical_sha256({"runtime": "document_sdk.pdf.full_local.v1"})
_PROVENANCE = canonical_sha256({"runtime": "local_provider_free"})
_ReadingPageState = Literal[
    "complete",
    "partial",
    "review_required",
    "unsupported",
    "unavailable",
]


@dataclass(frozen=True, slots=True)
class _DocumentTableLayers:
    transitions: tuple[PdfTablePageTransition, ...]
    document_tables: tuple[PdfDocumentTable, ...]
    manifest: PdfDocumentTableManifest
    fingerprints: tuple[PdfTableTransitionFingerprint, ...]


def _enforce_limit(name: str, observed: float, maximum: float) -> None:
    if observed > maximum:
        raise PdfLimitExceededError(
            limit_name=name,
            observed=observed,
            maximum=maximum,
        )


def _enforce_public_source_limits(
    content: bytes,
    limits: PdfProcessingLimits,
    *,
    password: str | None = None,
) -> None:
    try:
        document = pdfium.PdfDocument(verified_parser_view(content), password=password)
    except pdfium.PdfiumError as error:
        if error.err_code in {
            pdfium_c.FPDF_ERR_PASSWORD,
            pdfium_c.FPDF_ERR_SECURITY,
        }:
            _raise_redacted_translation(
                error,
                EncryptedDocumentError(
                    _encrypted_pdf_access_message(
                        password_supplied=password is not None
                    )
                ),
            )
        _raise_redacted_translation(
            error,
            DocumentProcessingError("Advanced local PDF input is invalid"),
        )
    try:
        if (
            password is None
            and pdfium_c.FPDF_GetSecurityHandlerRevision(document.raw) != -1
        ):
            raise EncryptedDocumentError(
                _encrypted_pdf_access_message(password_supplied=False)
            )
        preflight = _preflight_document(document, limits)
        enforce_native_text_page_limit(preflight.page_count, limits)
        native_characters = 0
        for page_index in range(preflight.page_count):
            page = document[page_index]
            try:
                text_page = page.get_textpage()
                try:
                    _, native_characters = extract_bounded_page_text(
                        text_page,
                        characters_so_far=native_characters,
                        limits=limits,
                    )
                finally:
                    text_page.close()
            finally:
                page.close()
    finally:
        document.close()


def _enforce_extracted_facts_limits(
    facts: PdfFactArtifact,
    limits: PdfProcessingLimits,
) -> None:
    """Rebind public limits to the Facts authority consumed downstream.

    PDFium remains the cheap whole-source preflight, but the full local pipeline
    consumes pdfplumber Facts.  Rechecking the independent parser output keeps a
    parser disagreement from bypassing caller geometry or native-text budgets.
    Text layers are alternate views over the same native content, so the largest
    retained layer is the bounded conservative inventory rather than their
    duplicate-counting sum.
    """
    _enforce_limit("page count", facts.page_count, limits.max_pages)
    _enforce_limit(
        "native text pages",
        facts.page_count,
        limits.max_native_text_pages,
    )
    native_text_characters = 0
    for page in facts.pages:
        width = page.media_box.width
        height = page.media_box.height
        _enforce_limit(
            "page width points",
            width,
            limits.max_page_width_points,
        )
        _enforce_limit(
            "page height points",
            height,
            limits.max_page_height_points,
        )
        _enforce_limit(
            "page area points",
            width * height,
            limits.max_page_area_points,
        )
        native_text_characters += max(
            (
                sum(len(item.text) for item in layer)
                for layer in (
                    page.text_spans,
                    page.words,
                    page.line_candidates,
                    page.characters,
                )
            ),
            default=0,
        )
        _enforce_limit(
            "native text characters",
            native_text_characters,
            limits.max_native_text_characters,
        )


def _effective_full_local_processing_limits(
    requested: PdfProcessingLimits,
) -> PdfProcessingLimits:
    validated = PdfProcessingLimits.model_validate(
        {
            field_name: getattr(requested, field_name)
            for field_name in PdfProcessingLimits.model_fields
        }
    )
    extraction = PdfExtractionLimits()
    document_tables = PdfPhase3DResourceContract()
    maximum_pages = min(
        validated.max_pages,
        extraction.max_page_count,
        document_tables.maximum_pages_per_document,
    )
    values = {
        field_name: getattr(validated, field_name)
        for field_name in PdfProcessingLimits.model_fields
    }
    values.update(
        max_file_bytes=min(
            validated.max_file_bytes,
            extraction.max_file_size_bytes,
        ),
        max_pages=maximum_pages,
        max_native_text_pages=min(
            validated.max_native_text_pages,
            maximum_pages,
        ),
        max_native_text_characters=min(
            validated.max_native_text_characters,
            extraction.max_characters_per_page * maximum_pages,
        ),
    )
    return PdfProcessingLimits.model_validate(values)


def _structural_page_evidence_sha256(
    *,
    facts: PdfPageScopedFactSnapshot,
    layout: PdfPageScopedLayoutSnapshot,
    ctif: object,
) -> str:
    """Bind the structural component to the exact page-local evidence used."""
    return canonical_sha256(
        {
            "fact_snapshot_sha256": canonical_sha256(facts),
            "layout_snapshot_sha256": canonical_sha256(layout),
            "ctif_reference_sha256": canonical_sha256(ctif),
        }
    )


def _reading_state(
    *,
    fact_status: str,
    layout_status: str,
) -> tuple[_ReadingPageState, tuple[str, ...]]:
    limitations = {"CTIF_UNAVAILABLE"}
    if fact_status != "success":
        limitations.add(f"FACTS_{fact_status.upper()}")
    if layout_status != "success":
        limitations.add(f"LAYOUT_{layout_status.upper()}")
    if fact_status == "success" and layout_status == "success":
        return "complete", tuple(sorted(limitations))
    if fact_status == "no_text_layer":
        return "unavailable", tuple(sorted(limitations))
    if fact_status == "unsupported" or layout_status == "unsupported":
        return "unsupported", tuple(sorted(limitations))
    return "partial", tuple(sorted(limitations))


def _fingerprint_input(
    authority: PdfTransitionTableInputAuthority,
) -> PdfTransitionFingerprintInputAuthority:
    features = authority.features
    return PdfTransitionFingerprintInputAuthority(
        features=features,
        page_width=authority.page_width,
        page_height=authority.page_height,
        table_x0=features.normalized_x0 * authority.page_width,
        table_y0=features.normalized_y0 * authority.page_height,
        table_x1=features.normalized_x1 * authority.page_width,
        table_y1=features.normalized_y1 * authority.page_height,
        table_state=authority.table_state,
        required_authority_available=authority.required_authority_available,
        optional_authority_available=authority.optional_authority_available,
        runtime_truncated=authority.runtime_truncated,
        limitation_codes=authority.limitation_codes,
    )


def _document_table_stage_resource_check(
    *,
    contract: PdfPhase3DResourceContract,
    transitions: tuple[PdfTablePageTransition, ...],
    document_tables: tuple[PdfDocumentTable, ...],
    manifest: PdfDocumentTableManifest,
) -> None:
    if any(
        len(table.page_table_references) > contract.maximum_chain_length
        for table in document_tables
    ):
        raise ValueError("document table chain resource contract exceeded")
    logical_rows = sum(len(table.logical_rows) for table in document_tables)
    logical_cells = sum(
        len(row.fragment_cell_ids)
        for table in document_tables
        for row in table.logical_rows
    )
    if logical_rows > contract.maximum_logical_rows:
        raise ValueError("document table logical-row resource contract exceeded")
    if logical_cells > contract.maximum_logical_cells:
        raise ValueError("document table logical-cell resource contract exceeded")
    artifact_bytes = len(
        canonical_json_bytes(
            {
                "document_tables": document_tables,
                "manifest": manifest,
                "transitions": transitions,
            }
        )
    )
    if artifact_bytes > contract.maximum_artifact_bytes:
        raise ValueError("document table artifact resource contract exceeded")


def _document_table_deadline_exceeded(
    *,
    contract: PdfPhase3DResourceContract,
    started_at: float,
) -> bool:
    return monotonic() - started_at > contract.maximum_stage_runtime_seconds


def _bind_complete_candidate_inventory(
    transition: PdfTablePageTransition,
    *,
    candidate_count: int,
    inventory_partial: bool,
) -> PdfTablePageTransition:
    linking_outcomes = {
        "CONTINUATION_PROVEN",
        "REPEATED_HEADER_CONTINUATION",
        "SPLIT_ROW_CONTINUATION",
    }
    downgrade = inventory_partial and transition.outcome in linking_outcomes
    return build_table_page_transition(
        left=transition.left,
        right=transition.right,
        outcome="CONTINUATION_PARTIAL" if downgrade else transition.outcome,
        column_mappings=transition.column_mappings,
        repeated_header_mappings=transition.repeated_header_mappings,
        row_fragment_links=transition.row_fragment_links,
        table_geometry_compatible=transition.table_geometry_compatible,
        topology_compatible=transition.topology_compatible,
        page_boundary_evidence_strength=transition.page_boundary_evidence_strength,
        fingerprint_support_strength=transition.fingerprint_support_strength,
        candidate_pair_count=candidate_count,
        limitation_codes=tuple(
            sorted(
                {
                    *transition.limitation_codes,
                    *({"PAIR_INPUT_PARTIAL"} if inventory_partial else set()),
                }
            )
        ),
    )


def _build_document_table_layers(
    *,
    facts: PdfFactArtifact,
    table_pages: tuple[PdfTableStructurePageSidecar, ...],
    table_manifest: PdfTableDocumentManifest,
) -> _DocumentTableLayers:
    started_at = monotonic()
    contract = PdfPhase3DResourceContract()
    fingerprint_contract = PdfTransitionFingerprintResourceContract()
    canonical_limits = CanonicalProjectionLimits()
    maximum_transitions = min(
        contract.maximum_adjacent_transitions,
        canonical_limits.maximum_transitions,
    )
    maximum_fingerprints = min(
        maximum_transitions,
        canonical_limits.maximum_transition_fingerprints,
    )
    page_count = len(table_pages)
    adjacent_count = max(0, page_count - 1)
    if page_count > contract.maximum_pages_per_document:
        raise ValueError("document table page resource contract exceeded")
    if adjacent_count > contract.maximum_adjacent_transitions:
        raise ValueError("document table transition resource contract exceeded")

    page_inputs = tuple(
        build_page_transition_inputs(
            facts=facts,
            page=page,
            manifest=table_manifest,
        )
        for page in table_pages
    )
    authorities_by_table_id = {
        result.authority.features.endpoint.table_id: result.authority
        for results in page_inputs
        for result in results
        if result.authority is not None
    }
    transitions: list[PdfTablePageTransition] = []
    evaluated_pairs = 0
    no_candidate_pairs = 0
    resource_limited_pairs = 0
    unavailable_pairs = 0
    transition_reservations = 0
    fingerprint_reservations = 0
    deadline_limited = False
    limitations: set[str] = set()
    for pair_index in range(adjacent_count):
        if _document_table_deadline_exceeded(
            contract=contract,
            started_at=started_at,
        ):
            resource_limited_pairs += adjacent_count - pair_index
            limitations.add("DOCUMENT_TABLE_RESOURCE_LIMITED")
            deadline_limited = True
            break

        left_page = table_pages[pair_index]
        right_page = table_pages[pair_index + 1]
        left_results = page_inputs[pair_index]
        right_results = page_inputs[pair_index + 1]
        pair_bucket: Literal[
            "evaluated", "no_candidate", "resource_limited", "unavailable"
        ]
        pair_limitations: set[str] = set()
        pair_transitions: tuple[PdfTablePageTransition, ...] = ()
        pair_reservations = 0
        if left_page.outcome == "NO_TABLE" or right_page.outcome == "NO_TABLE":
            pair_bucket = "no_candidate"
        elif not left_results or not right_results:
            pair_bucket = "unavailable"
            pair_limitations.add("DOCUMENT_TABLE_INPUT_UNAVAILABLE")
        elif (
            len(left_results) > contract.maximum_tables_per_page
            or len(right_results) > contract.maximum_tables_per_page
            or len(left_results) * len(right_results)
            > contract.maximum_candidate_pairs_per_transition
        ):
            pair_bucket = "resource_limited"
            pair_limitations.add("DOCUMENT_TABLE_RESOURCE_LIMITED")
        else:
            candidate_count = len(left_results) * len(right_results)
            left_authorities = tuple(
                result.authority
                for result in left_results
                if result.authority is not None
            )
            right_authorities = tuple(
                result.authority
                for result in right_results
                if result.authority is not None
            )
            if not left_authorities or not right_authorities:
                pair_bucket = "unavailable"
                pair_limitations.add("DOCUMENT_TABLE_INPUT_UNAVAILABLE")
            else:
                pair_reservations = len(left_authorities) * len(right_authorities)
                remaining_transitions = maximum_transitions - transition_reservations
                remaining_fingerprints = maximum_fingerprints - fingerprint_reservations
                if pair_reservations > remaining_transitions or (
                    pair_reservations > remaining_fingerprints
                ):
                    pair_bucket = "resource_limited"
                    pair_limitations.add("DOCUMENT_TABLE_RESOURCE_LIMITED")
                else:
                    inventory_partial = len(left_authorities) != len(
                        left_results
                    ) or len(right_authorities) != len(right_results)
                    if inventory_partial:
                        pair_limitations.add("DOCUMENT_TABLE_INPUT_PARTIAL")
                    pair_transitions = tuple(
                        _bind_complete_candidate_inventory(
                            transition,
                            candidate_count=candidate_count,
                            inventory_partial=inventory_partial,
                        )
                        for transition in evaluate_adjacent_candidates(
                            tuple(authority.features for authority in left_authorities),
                            tuple(
                                authority.features for authority in right_authorities
                            ),
                            resource_contract=contract,
                        )
                    )
                    if any(
                        len(canonical_json_bytes(transition))
                        > contract.maximum_transition_evidence_bytes
                        for transition in pair_transitions
                    ):
                        pair_bucket = "resource_limited"
                        pair_limitations.add("DOCUMENT_TABLE_RESOURCE_LIMITED")
                        pair_transitions = ()
                    else:
                        pair_bucket = "evaluated"
                        if (
                            left_page.outcome != "COMPLETE"
                            or right_page.outcome != "COMPLETE"
                        ):
                            pair_limitations.add("DOCUMENT_TABLE_UPSTREAM_PARTIAL")

        if _document_table_deadline_exceeded(
            contract=contract,
            started_at=started_at,
        ):
            resource_limited_pairs += adjacent_count - pair_index
            limitations.add("DOCUMENT_TABLE_RESOURCE_LIMITED")
            deadline_limited = True
            break

        limitations.update(pair_limitations)
        if pair_bucket == "evaluated":
            evaluated_pairs += 1
            transitions.extend(pair_transitions)
            transition_reservations += pair_reservations
            fingerprint_reservations += pair_reservations
        elif pair_bucket == "no_candidate":
            no_candidate_pairs += 1
        elif pair_bucket == "resource_limited":
            resource_limited_pairs += 1
        else:
            unavailable_pairs += 1

    typed_transitions = tuple(transitions)
    document_tables: tuple[PdfDocumentTable, ...]
    fingerprints: tuple[PdfTableTransitionFingerprint, ...]
    if deadline_limited or _document_table_deadline_exceeded(
        contract=contract,
        started_at=started_at,
    ):
        limitations.add("DOCUMENT_TABLE_RESOURCE_LIMITED")
        document_tables = ()
        fingerprints = ()
    else:
        document_tables = assemble_document_tables(typed_transitions)
        if _document_table_deadline_exceeded(
            contract=contract,
            started_at=started_at,
        ):
            limitations.add("DOCUMENT_TABLE_RESOURCE_LIMITED")
            fingerprints = ()
        else:
            fingerprints = tuple(
                build_transition_fingerprint_from_authority(
                    transition=transition,
                    left=_fingerprint_input(
                        authorities_by_table_id[transition.left.table_id]
                    ),
                    right=_fingerprint_input(
                        authorities_by_table_id[transition.right.table_id]
                    ),
                    resource_contract=fingerprint_contract,
                )
                for transition in typed_transitions
                if transition.outcome != "UNAVAILABLE_UPSTREAM"
            )
            if _document_table_deadline_exceeded(
                contract=contract,
                started_at=started_at,
            ):
                limitations.add("DOCUMENT_TABLE_RESOURCE_LIMITED")
                fingerprints = ()
    manifest = build_document_table_manifest(
        source_sha256=facts.source_sha256,
        document_identity=table_manifest.document_identity,
        page_table_manifest_id=table_manifest.manifest_id,
        page_table_manifest_sha256=table_manifest.page_table_manifest_sha256,
        transition_ids=tuple(item.transition_id for item in typed_transitions),
        document_table_ids=tuple(item.document_table_id for item in document_tables),
        transition_count=len(typed_transitions),
        document_table_count=len(document_tables),
        adjacent_page_pair_count=adjacent_count,
        evaluated_adjacent_page_pair_count=evaluated_pairs,
        no_candidate_page_pair_count=no_candidate_pairs,
        resource_limited_page_pair_count=resource_limited_pairs,
        unavailable_adjacent_page_pair_count=unavailable_pairs,
        limitation_codes=tuple(sorted(limitations)),
    )
    _document_table_stage_resource_check(
        contract=contract,
        transitions=typed_transitions,
        document_tables=document_tables,
        manifest=manifest,
    )
    if (
        _document_table_deadline_exceeded(
            contract=contract,
            started_at=started_at,
        )
        and "DOCUMENT_TABLE_RESOURCE_LIMITED" not in limitations
    ):
        limitations.add("DOCUMENT_TABLE_RESOURCE_LIMITED")
        manifest = build_document_table_manifest(
            source_sha256=facts.source_sha256,
            document_identity=table_manifest.document_identity,
            page_table_manifest_id=table_manifest.manifest_id,
            page_table_manifest_sha256=table_manifest.page_table_manifest_sha256,
            transition_ids=tuple(item.transition_id for item in typed_transitions),
            document_table_ids=tuple(
                item.document_table_id for item in document_tables
            ),
            transition_count=len(typed_transitions),
            document_table_count=len(document_tables),
            adjacent_page_pair_count=adjacent_count,
            evaluated_adjacent_page_pair_count=evaluated_pairs,
            no_candidate_page_pair_count=no_candidate_pairs,
            resource_limited_page_pair_count=resource_limited_pairs,
            unavailable_adjacent_page_pair_count=unavailable_pairs,
            limitation_codes=tuple(sorted(limitations)),
        )
        _document_table_stage_resource_check(
            contract=contract,
            transitions=typed_transitions,
            document_tables=document_tables,
            manifest=manifest,
        )
    return _DocumentTableLayers(
        transitions=typed_transitions,
        document_tables=document_tables,
        manifest=manifest,
        fingerprints=fingerprints,
    )


def build_full_local_canonical_bundle(
    content: bytes,
    *,
    limits: PdfProcessingLimits | None = None,
    password: str | None = None,
) -> CanonicalArtifactBundle:
    """Build one path-free bundle by sequencing existing private algorithms."""
    selected = _effective_full_local_processing_limits(limits or PdfProcessingLimits())
    _enforce_limit("file bytes", len(content), selected.max_file_bytes)
    _enforce_public_source_limits(content, selected, password=password)
    private_extraction_limits = PdfExtractionLimits()
    document_table_limits = PdfPhase3DResourceContract()
    extraction_limits = private_extraction_limits.model_copy(
        update={
            "max_file_size_bytes": min(
                selected.max_file_bytes,
                private_extraction_limits.max_file_size_bytes,
            ),
            "max_page_count": min(
                selected.max_pages,
                selected.max_native_text_pages,
                private_extraction_limits.max_page_count,
                document_table_limits.maximum_pages_per_document,
            ),
        }
    )
    if password is None:
        facts = create_pdf_fact_extractor("pdfplumber").extract(
            PdfSource(content),
            limits=extraction_limits,
            options=PdfExtractionOptions(include_text_members=True),
        )
    else:
        facts = PdfPlumberFactExtractor().extract(
            PdfSource(content),
            limits=extraction_limits,
            options=PdfExtractionOptions(include_text_members=True),
            password=password,
        )
    _enforce_extracted_facts_limits(facts, selected)
    layout = PdfLayoutGraphBuilder().build(
        facts,
        limits=PdfLayoutGraphLimits(),
    )
    configuration = phase3b_reading_configuration_identity()
    evidence = []
    evidence_bytes = []
    references = []
    for fact_page, layout_page in zip(facts.pages, layout.pages, strict=True):
        fact_snapshot = PdfPageScopedFactSnapshot(
            inherited_artifact_identity=layout.source_fact_artifact_sha256,
            source_sha256=facts.source_sha256,
            document_id=facts.document_id,
            parser_name=facts.parser_name,
            parser_version=facts.parser_version,
            extraction_scope_identity=facts.extraction_scope_result.scope_digest,
            page=fact_page,
        )
        layout_snapshot = PdfPageScopedLayoutSnapshot(
            inherited_graph_id=layout.layout_graph_id,
            inherited_graph_digest=layout.graph_digest,
            inherited_fact_artifact_identity=layout.source_fact_artifact_sha256,
            source_sha256=facts.source_sha256,
            page_id=layout_page.source_page_id,
            page_graph_id=layout_page.page_graph_id,
            page_number=layout_page.page_number,
            canonical_width=layout_page.canonical_width,
            canonical_height=layout_page.canonical_height,
            rotation=layout_page.rotation,
            nodes=layout_page.nodes,
            edges=layout_page.edges,
            separator_candidates=layout_page.separator_candidates,
            relation_observation=layout_page.relation_observation,
            quality_signals=layout_page.quality_signals,
            build_status=layout_page.build_status,
            warnings=layout_page.warnings,
        )
        ctif = build_unavailable_reading_canonical_evidence(
            source_sha256=facts.source_sha256,
            document_identity=facts.document_id,
            page_identity=fact_page.page_id,
            page_number=fact_page.page_number,
        )
        payload = PdfReadingPagePayload(
            facts=fact_snapshot,
            layout=layout_snapshot,
            ctif=ctif,
            structural_page_sha256=_structural_page_evidence_sha256(
                facts=fact_snapshot,
                layout=layout_snapshot,
                ctif=ctif,
            ),
        )
        reading_state, reading_limitations = _reading_state(
            fact_status=fact_page.extraction_status.value,
            layout_status=layout_page.build_status.value,
        )
        item = build_reading_page_evidence(
            payload=payload,
            dependency_identity=_DEPENDENCY,
            parser_lineage_identity="document_sdk.pdf.full_local.v1",
            algorithm_version=PHASE3B_READING_ALGORITHM_VERSION,
            configuration_identity=configuration,
            state=reading_state,
            limitation_codes=reading_limitations,
            provenance_identity=_PROVENANCE,
        )
        serialized = canonical_json_bytes(item)
        evidence.append(item)
        evidence_bytes.append(serialized)
        references.append(
            PdfPageScopedReference(
                page_id=item.page_id,
                page_index=item.page_index,
                sidecar_id=item.sidecar_id,
                structural_page_sha256=item.payload.structural_page_sha256,
                sidecar_file_sha256=sha256(serialized).hexdigest(),
                sidecar_bytes=len(serialized),
            )
        )
    authority_limitations = {
        limitation for item in evidence for limitation in item.limitation_codes
    }
    if facts.partial_extraction:
        authority_limitations.add("FACTS_PARTIAL")
    authority_state: _ReadingPageState = (
        "complete"
        if not facts.partial_extraction
        and all(item.state == "complete" for item in evidence)
        else "partial"
    )
    reading_authority = build_reading_page_authority(
        source_sha256=facts.source_sha256,
        references=tuple(references),
        dependency_identity=_DEPENDENCY,
        operation_version=PHASE3B_READING_OPERATION_VERSION,
        configuration_identity=configuration,
        algorithm_version=PHASE3B_READING_ALGORITHM_VERSION,
        ctif_contract=evidence[0].payload.ctif.authority_identity.authority_version,
        state=authority_state,
        limitation_codes=tuple(sorted(authority_limitations)),
        provenance_identity=_PROVENANCE,
    )
    reading_pages = []
    reading_refs = []
    reading_bytes = []
    for item, serialized in zip(evidence, evidence_bytes, strict=True):
        reading = build_reading_structure_page(
            inherited=item,
            inherited_manifest=reading_authority,
            inherited_sidecar_bytes=serialized,
        )
        content_bytes = canonical_json_bytes(reading)
        reading_pages.append(reading)
        reading_bytes.append(content_bytes)
        reading_refs.append(
            PdfReadingStructurePageReference(
                page_id=reading.page_id,
                page_index=reading.page_index,
                sidecar_id=reading.sidecar_id,
                sidecar_sha256=sha256(content_bytes).hexdigest(),
                sidecar_bytes=len(content_bytes),
                reading_order_graph_id=reading.reading_order.graph_id,
                hierarchy_graph_id=reading.hierarchy.graph_id,
                block_ids=tuple(block.block_id for block in reading.blocks),
            )
        )
    table_config = PdfTableAlgorithmConfig()
    table_pages = []
    table_refs = []
    for inherited, inherited_bytes, reading, reading_ref, reading_content in zip(
        evidence,
        evidence_bytes,
        reading_pages,
        reading_refs,
        reading_bytes,
        strict=True,
    ):
        table = build_table_structure_page_from_inherited(
            inherited=inherited,
            inherited_manifest=reading_authority,
            inherited_sidecar_bytes=inherited_bytes,
            reading=reading,
            reading_reference=reading_ref,
            reading_sidecar_bytes=reading_content,
            config=table_config,
        )
        table_bytes = canonical_json_bytes(table)
        table_pages.append(table)
        table_refs.append(
            PdfTableStructurePageReference(
                page_id=table.page_id,
                page_index=table.page_index,
                sidecar_id=table.sidecar_id,
                sidecar_sha256=sha256(table_bytes).hexdigest(),
                sidecar_bytes=len(table_bytes),
                outcome=table.outcome,
                table_ids=tuple(item.table_id for item in table.tables),
            )
        )
    authority_bytes = canonical_json_bytes(reading_authority)
    table_manifest = build_table_manifest(
        source_sha256=facts.source_sha256,
        reading_authority_id=reading_authority.manifest_id,
        reading_authority_sha256=sha256(authority_bytes).hexdigest(),
        page_references=tuple(table_refs),
        dependency_identity=_DEPENDENCY,
        configuration_identity=table_config.identity,
        limitation_codes=tuple(
            sorted(
                {
                    limitation
                    for page in table_pages
                    for limitation in page.limitation_codes
                }
            )
        ),
    )
    document_layers = _build_document_table_layers(
        facts=facts,
        table_pages=tuple(table_pages),
        table_manifest=table_manifest,
    )
    return CanonicalArtifactBundle(
        facts=facts,
        layout=layout,
        reading_pages=tuple(reading_pages),
        table_pages=tuple(table_pages),
        table_manifest=table_manifest,
        transitions=document_layers.transitions,
        document_tables=document_layers.document_tables,
        document_table_manifest=document_layers.manifest,
        transition_fingerprints=document_layers.fingerprints,
    )

# ruff: noqa: C901, EM101, PLR0912, PTH100, TRY301

"""Private bounded regular-file reads for isolated PDF workers."""

import os
import stat
from dataclasses import dataclass
from pathlib import Path

from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.pdf._structural_engine.runtime.contracts import (
    PdfWorkerErrorCategory,
    PdfWorkerRequest,
)

_READ_CHUNK_BYTES = 1024 * 1024


@dataclass(frozen=True)
class PdfSafeFileRead:
    content: bytes
    file_size_bytes: int


class PdfSafeFileError(Exception):
    def __init__(self, category: PdfWorkerErrorCategory, message: str) -> None:
        super().__init__(message)
        self.category = category


def safe_read_pdf_file(
    path: Path,
    *,
    max_file_size_bytes: int,
) -> PdfSafeFileRead:
    """Reject observed symlink components and read one stable regular file."""
    try:
        if _path_has_symlink_component(path):
            raise PdfSafeFileError(
                "unsafe_source",
                "PDF source path contains a symlink component.",
            )
        before = os.lstat(path)
    except (OSError, ValueError) as error:
        _raise_redacted_translation(
            error,
            PdfSafeFileError("unsafe_source", "PDF source could not be inspected."),
        )
    if stat.S_ISLNK(before.st_mode) or not stat.S_ISREG(before.st_mode):
        raise PdfSafeFileError(
            "unsafe_source", "PDF source is not a regular non-symlink file."
        )
    if before.st_size > max_file_size_bytes:
        raise PdfSafeFileError(
            "file_too_large", "PDF source exceeds the configured file-size limit."
        )

    flags = os.O_RDONLY
    flags |= getattr(os, "O_CLOEXEC", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0)
    descriptor: int | None = None
    try:
        descriptor = os.open(path, flags)
        opened = os.fstat(descriptor)
        if not stat.S_ISREG(opened.st_mode):
            raise PdfSafeFileError(
                "unsafe_source", "Opened PDF source is not a regular file."
            )
        if (before.st_dev, before.st_ino) != (opened.st_dev, opened.st_ino):
            raise PdfSafeFileError(
                "source_changed", "PDF source changed during safe open."
            )
        if opened.st_size != before.st_size:
            raise PdfSafeFileError(
                "source_changed", "PDF source size changed during safe open."
            )
        if opened.st_size > max_file_size_bytes:
            raise PdfSafeFileError(
                "file_too_large", "PDF source exceeds the configured file-size limit."
            )

        remaining = opened.st_size
        chunks: list[bytes] = []
        while remaining:
            chunk = os.read(descriptor, min(remaining, _READ_CHUNK_BYTES))
            if not chunk:
                raise PdfSafeFileError(
                    "short_read", "PDF source ended before its inspected size."
                )
            chunks.append(chunk)
            remaining -= len(chunk)
        if os.read(descriptor, 1):
            raise PdfSafeFileError(
                "source_changed", "PDF source grew during safe read."
            )
        after = os.fstat(descriptor)
        if (
            (opened.st_dev, opened.st_ino) != (after.st_dev, after.st_ino)
            or opened.st_size != after.st_size
            or getattr(opened, "st_mtime_ns", None)
            != getattr(after, "st_mtime_ns", None)
        ):
            raise PdfSafeFileError(
                "source_changed", "PDF source changed during safe read."
            )
        return PdfSafeFileRead(content=b"".join(chunks), file_size_bytes=opened.st_size)
    except PdfSafeFileError:
        raise
    except (OSError, ValueError) as error:
        _raise_redacted_translation(
            error,
            PdfSafeFileError("unsafe_source", "PDF source could not be opened safely."),
        )
    finally:
        if descriptor is not None:
            os.close(descriptor)


def _path_has_symlink_component(path: Path) -> bool:
    absolute = Path(os.path.abspath(path))
    current = Path(absolute.anchor)
    for component in absolute.parts[1:]:
        current /= component
        try:
            inspected = os.lstat(current)
        except FileNotFoundError:
            return False
        if stat.S_ISLNK(inspected.st_mode):
            return True
    return False


def _matches_expected_identity(
    *,
    request: PdfWorkerRequest,
    document_hash: str,
    source_size: int,
) -> bool | None:
    checks = []
    if request.expected_document_sha256 is not None:
        checks.append(document_hash == request.expected_document_sha256)
    if request.expected_source_size_bytes is not None:
        checks.append(source_size == request.expected_source_size_bytes)
    return all(checks) if checks else None


def _matches_expected_identity_if_available(
    *,
    request: PdfWorkerRequest,
    document_hash: str | None,
    source_size: int | None,
) -> bool | None:
    if document_hash is None or source_size is None:
        return None
    return _matches_expected_identity(
        request=request,
        document_hash=document_hash,
        source_size=source_size,
    )

# ruff: noqa: C901, PLR0911, PLR0912, PLR0913, PLR0915, PLR2004, S101, S603, S607, SIM102, SIM105, TRY300

"""Private bounded subprocess lifecycle primitives."""

import os
import signal
import subprocess
from collections.abc import Callable
from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from threading import Event, Thread
from time import perf_counter
from typing import IO

from document_sdk.pdf._structural_engine.runtime.contracts import (
    PdfIsolatedBenchmarkResult,
    PdfWorkerExitClassification,
)


@dataclass(frozen=True)
class _ProcessOutcome:
    process_id: int | None
    exit_code: int | None
    timed_out: bool
    killed: bool
    stdout: bytes
    stdout_truncated: bool
    stderr: bytes
    stderr_truncated: bool
    elapsed_milliseconds: float
    parent_observed_peak_rss_bytes: int | None
    parent_rss_measurement: str
    ready_observed: bool
    rss_sample_count: int = 0
    process_contributions: tuple[tuple[int, str, int], ...] = ()


class _BoundedPipeReader(Thread):
    def __init__(
        self,
        stream: IO[bytes],
        *,
        limit: int,
        ready_marker: bytes | None = None,
    ) -> None:
        super().__init__(daemon=True)
        self._stream = stream
        self._limit = limit
        self._ready_marker = ready_marker
        self._ready_event = Event()
        self._marker_tail = b""
        self._buffer = bytearray()
        self.total_bytes = 0

    @property
    def truncated(self) -> bool:
        return self.total_bytes > len(self._buffer)

    def run(self) -> None:
        read_chunk = getattr(self._stream, "read1", self._stream.read)
        while True:
            chunk = read_chunk(8_192)
            if not chunk:
                return
            if self._ready_marker is not None and not self._ready_event.is_set():
                searchable = self._marker_tail + chunk
                if self._ready_marker in searchable:
                    self._ready_event.set()
                keep = max(len(self._ready_marker) - 1, 0)
                self._marker_tail = searchable[-keep:] if keep else b""
            self.total_bytes += len(chunk)
            remaining = self._limit - len(self._buffer)
            if remaining > 0:
                self._buffer.extend(chunk[:remaining])

    def value(self) -> bytes:
        return bytes(self._buffer)

    def wait_until_ready(self, timeout_seconds: float) -> bool:
        if self._ready_marker is None:
            return True
        return self._ready_event.wait(timeout_seconds)


class _ParentRssSampler(Thread):
    def __init__(
        self,
        *,
        pid: int,
        sample_interval_seconds: float,
        sample_callback: Callable[[int, int, str], None] | None = None,
    ) -> None:
        super().__init__(daemon=True)
        self._pid = pid
        self._sample_interval_seconds = sample_interval_seconds
        self._sample_callback = sample_callback
        self._stop_event = Event()
        self.peak_bytes: int | None = None
        self.measurement = "unavailable"
        self.sample_count = 0
        self.contribution_peaks: dict[int, int] = {}

    def stop(self) -> None:
        self._stop_event.set()

    def run(self) -> None:
        while not self._stop_event.is_set():
            snapshot, measurement = _read_process_tree_rss_snapshot(self._pid)
            if snapshot:
                value = sum(snapshot.values())
                self.sample_count += 1
                self.peak_bytes = max(self.peak_bytes or 0, value)
                self.measurement = measurement
                for pid, rss in snapshot.items():
                    self.contribution_peaks[pid] = max(
                        self.contribution_peaks.get(pid, 0), rss
                    )
                if self._sample_callback is not None:
                    self._sample_callback(self._pid, value, measurement)
            self._stop_event.wait(self._sample_interval_seconds)


def _run_bounded_process(
    command: list[str],
    *,
    stdin_payload: bytes,
    hard_timeout_seconds: float,
    terminate_grace_seconds: float,
    max_stdout_bytes: int,
    max_stderr_bytes: int,
    parent_rss_sample_interval_seconds: float = 0.1,
    ready_marker: bytes | None = None,
    ready_timeout_seconds: float = 5.0,
    process_started_callback: Callable[[int], None] | None = None,
    process_finished_callback: Callable[[int], None] | None = None,
    process_rss_sample_callback: Callable[[int, int, str], None] | None = None,
) -> _ProcessOutcome:
    started_at = perf_counter()
    try:
        process = subprocess.Popen(
            command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            start_new_session=True,
        )
    except OSError:
        return _ProcessOutcome(
            process_id=None,
            exit_code=None,
            timed_out=False,
            killed=False,
            stdout=b"",
            stdout_truncated=False,
            stderr=b"",
            stderr_truncated=False,
            elapsed_milliseconds=(perf_counter() - started_at) * 1_000,
            parent_observed_peak_rss_bytes=None,
            parent_rss_measurement="unavailable",
            ready_observed=False,
        )
    assert process.stdout is not None
    assert process.stderr is not None
    assert process.stdin is not None
    if process_started_callback is not None:
        process_started_callback(process.pid)
    stdout_reader = _BoundedPipeReader(
        process.stdout,
        limit=max_stdout_bytes,
        ready_marker=ready_marker,
    )
    stderr_reader = _BoundedPipeReader(process.stderr, limit=max_stderr_bytes)
    rss_sampler = _ParentRssSampler(
        pid=process.pid,
        sample_interval_seconds=parent_rss_sample_interval_seconds,
        sample_callback=process_rss_sample_callback,
    )
    stdout_reader.start()
    stderr_reader.start()
    rss_sampler.start()
    try:
        process.stdin.write(stdin_payload)
    except BrokenPipeError:
        pass
    finally:
        try:
            process.stdin.close()
        except BrokenPipeError:
            pass
    timed_out = False
    killed = False
    ready_observed = stdout_reader.wait_until_ready(ready_timeout_seconds)
    if ready_marker is not None and not ready_observed and process.poll() is None:
        timed_out = True
    if not timed_out:
        try:
            process.wait(timeout=hard_timeout_seconds)
        except subprocess.TimeoutExpired:
            timed_out = True
    if timed_out:
        _terminate_process_tree(process)
        try:
            process.wait(timeout=terminate_grace_seconds)
        except subprocess.TimeoutExpired:
            killed = True
            _kill_process_tree(process)
            process.wait()
    try:
        if process.poll() is None:
            process.wait()
    finally:
        rss_sampler.stop()
        rss_sampler.join(timeout=1)
        stdout_reader.join(timeout=1)
        stderr_reader.join(timeout=1)
        process.stdout.close()
        process.stderr.close()
        if process_finished_callback is not None:
            process_finished_callback(process.pid)
    return _ProcessOutcome(
        process_id=process.pid,
        exit_code=process.returncode,
        timed_out=timed_out,
        killed=killed,
        stdout=stdout_reader.value(),
        stdout_truncated=stdout_reader.truncated,
        stderr=stderr_reader.value(),
        stderr_truncated=stderr_reader.truncated,
        elapsed_milliseconds=(perf_counter() - started_at) * 1_000,
        parent_observed_peak_rss_bytes=rss_sampler.peak_bytes,
        parent_rss_measurement=rss_sampler.measurement,
        ready_observed=ready_observed,
        rss_sample_count=rss_sampler.sample_count,
        process_contributions=tuple(
            (
                pid,
                "isolated_worker" if pid == process.pid else "worker_descendant",
                peak,
            )
            for pid, peak in sorted(rss_sampler.contribution_peaks.items())
        ),
    )


def _terminate_process_tree(process: subprocess.Popen[bytes]) -> None:
    if os.name == "posix":
        try:
            os.killpg(process.pid, signal.SIGTERM)
            return
        except (OSError, ProcessLookupError):
            pass
    process.terminate()


def _kill_process_tree(process: subprocess.Popen[bytes]) -> None:
    if os.name == "posix":
        try:
            os.killpg(process.pid, signal.SIGKILL)
            return
        except (OSError, ProcessLookupError):
            pass
    process.kill()


def _classify_abnormal_process_exit(
    *,
    outcome: _ProcessOutcome,
    parser_started: bool,
) -> PdfWorkerExitClassification:
    sigxcpu = getattr(signal, "SIGXCPU", None)
    if (
        sigxcpu is not None
        and outcome.exit_code is not None
        and outcome.exit_code == -sigxcpu
    ):
        return "sigxcpu"
    if parser_started and _is_parser_crash_exit(outcome.exit_code):
        return "parser_crash"
    return "unknown_abnormal_exit"


def _is_parser_crash_exit(exit_code: int | None) -> bool:
    if exit_code is None:
        return False
    if exit_code > 0:
        return True
    crash_signals = {
        value
        for name in ("SIGABRT", "SIGBUS", "SIGFPE", "SIGILL", "SIGSEGV")
        if (value := getattr(signal, name, None)) is not None
    }
    return -exit_code in crash_signals


def classify_isolated_benchmark_exit(
    result: PdfIsolatedBenchmarkResult,
) -> PdfWorkerExitClassification:
    """Classify current and legacy results without guessing causes."""
    if result.exit_classification is not None:
        return result.exit_classification
    sigxcpu = getattr(signal, "SIGXCPU", None)
    if sigxcpu is not None and result.signal == sigxcpu:
        return "sigxcpu"
    if result.exit_mode == "timeout_killed":
        return "hard_wall_timeout_killed"
    if result.exit_mode == "timeout_terminated":
        return "hard_wall_timeout_terminated"
    if result.parser_error_category == "probable_memory_limit":
        return "probable_memory_limit_exit"
    if result.exit_mode == "completed":
        return "completed"
    if result.exit_mode == "rejected":
        return "rejected"
    if result.exit_mode == "launch_error":
        return "launch_error"
    if result.exit_mode == "protocol_error":
        return "protocol_error"
    if result.exit_mode == "crashed" and result.parser_error_category == "crash":
        if _is_parser_crash_exit(result.exit_code):
            return "parser_crash"
    return "unknown_abnormal_exit"


def _read_process_tree_rss_snapshot(
    root_pid: int,
) -> tuple[dict[int, int], str]:
    """Read a time-aligned RSS snapshot for one process tree."""
    try:
        completed = subprocess.run(
            ["ps", "-axo", "pid=,ppid=,rss="],
            check=False,
            capture_output=True,
            text=True,
            timeout=2,
        )
    except (OSError, subprocess.SubprocessError):
        return {}, "unavailable"
    parents: dict[int, int] = {}
    rss: dict[int, int] = {}
    for line in completed.stdout.splitlines():
        fields = line.split()
        if len(fields) != 3:
            continue
        try:
            pid, ppid, rss_kib = (int(field) for field in fields)
        except ValueError:
            continue
        parents[pid] = ppid
        rss[pid] = rss_kib * 1024
    selected = {root_pid}
    changed = True
    while changed:
        changed = False
        for pid, ppid in parents.items():
            if ppid in selected and pid not in selected:
                selected.add(pid)
                changed = True
    values = {pid: rss[pid] for pid in sorted(selected) if pid in rss}
    return (
        values,
        "time_aligned_process_tree_ps_rss_snapshot" if values else "unavailable",
    )


def _bounded_safe_diagnostic(
    value: bytes,
    *,
    source_path: Path,
    limit: int,
) -> str:
    del source_path
    if not value or limit <= 0:
        return ""
    summary = (
        f"Worker stderr captured: {len(value)} bounded bytes; "
        f"sha256={sha256(value).hexdigest()[:16]}."
    )
    return summary[:limit]

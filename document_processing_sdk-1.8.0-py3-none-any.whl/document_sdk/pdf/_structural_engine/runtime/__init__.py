"""Private, unwired PDF worker runtime primitives."""

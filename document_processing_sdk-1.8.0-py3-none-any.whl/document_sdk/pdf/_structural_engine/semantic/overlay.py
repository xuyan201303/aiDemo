"""Faithful observable candidates and a separately versioned semantic overlay."""

from __future__ import annotations

from itertools import pairwise
from math import isfinite
from re import fullmatch
from typing import TYPE_CHECKING, Annotated, Literal, NoReturn, Self

from pydantic import Field, model_validator

from document_sdk.core.models import SdkModel
from document_sdk.pdf._structural_engine.canonical.contracts import (
    CanonicalBoundingBox,
    CanonicalDocument,
    CanonicalDocumentTable,
    CanonicalTable,
    CanonicalTableCell,
    CanonicalTableColumn,
    CanonicalTableRow,
    CanonicalTransition,
)
from document_sdk.pdf._structural_engine.canonical.identifiers import (
    canonical_payload_sha256,
)
from document_sdk.pdf.local_evidence_members import (
    PdfLocalCellMemberLink,  # noqa: TC001 - Pydantic runtime field schema.
)
from document_sdk.pdf.unified import (
    UnifiedPdfTableSourceIdentity,  # noqa: TC001 - Pydantic runtime field schema.
)

from .authority import (
    AuthorityEvaluation,
    CandidateCellScope,
    CandidateScope,
    NativeEventScope,
)

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from document_sdk.pdf.local_evidence_members import PdfLocalPageEvidenceV3

SEMANTIC_IDENTITY_DOMAIN = "document_sdk.pdf.table_semantics.identity.v1"


def _fail(message: str) -> NoReturn:
    raise ValueError(message)


def semantic_identifier(prefix: str, payload: object) -> str:
    """Bind a semantic identity in a domain independent of legacy Canonical IDs."""
    return (
        prefix
        + "-"
        + canonical_payload_sha256(
            {"domain": SEMANTIC_IDENTITY_DOMAIN, "payload": payload}
        )
    )


class SemanticGeometry(SdkModel):
    """A coordinate value accompanied by its actual evidence claim."""

    bbox: CanonicalBoundingBox
    claim_kind: Literal[
        "SOURCE_NOMINAL", "SOURCE_PATH", "INFERRED_PARTITION", "GLYPH_INK"
    ]
    unit: Literal["canonical_pdf_point"] = "canonical_pdf_point"


class EmptyTextEvidence(SdkModel):
    """Reserved evidence references; their hashes do not establish text absence."""

    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    cell_id: str
    source_evidence_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    trusted_receipt_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")


class SemanticCell(SdkModel):
    """An unchanged Canonical cell with explicit evidence qualifications."""

    cell_id: str
    row_index: int = Field(ge=0)
    column_index: int = Field(ge=0)
    row_span: int = Field(ge=1)
    column_span: int = Field(ge=1)
    text: str | None
    text_state: Literal["PRESENT", "EMPTY_UNPROVED", "PROVEN_EMPTY", "UNAVAILABLE"]
    empty_text_evidence: EmptyTextEvidence | None = None
    geometry: SemanticGeometry
    source_refs: tuple[str, ...]
    source_member_ids: tuple[str, ...]
    member_links: tuple[PdfLocalCellMemberLink, ...]
    ownership_state: Literal["RECORDED_PROJECTION", "UNPROVED", "AMBIGUOUS"]
    canonical_cell: CanonicalTableCell

    @model_validator(mode="after")
    def validate_cell(self) -> Self:
        """Reject changed text, coordinates, or fabricated empty content."""
        base = self.canonical_cell
        for name in (
            "cell_id",
            "row_index",
            "column_index",
            "row_span",
            "column_span",
            "text",
        ):
            if getattr(self, name) != getattr(base, name):
                _fail("semantic cell differs from retained Canonical cell")
        if self.geometry.bbox != base.bbox:
            _fail("semantic cell geometry differs from retained Canonical cell")
        self._validate_text_claim()
        return self

    def _validate_text_claim(self) -> None:
        """Keep observed values separate from unsupported proof assertions."""
        if self.text_state == "PRESENT" and not self.text:
            _fail("PRESENT requires nonempty text")
        if self.text_state == "UNAVAILABLE" and self.text is not None:
            _fail("UNAVAILABLE requires null text")
        if self.text_state == "EMPTY_UNPROVED":
            if self.text != "":
                _fail("EMPTY_UNPROVED requires exactly empty text")
            if self.ownership_state == "RECORDED_PROJECTION":
                _fail("empty observation ownership remains unproved or ambiguous")
        if self.text_state == "PROVEN_EMPTY":
            # No independent source-absence verifier is implemented. A valid
            # reference shape or a recomputed hash cannot authorize this claim.
            _fail(
                "PROVEN_EMPTY requires an implemented independent empty-text verifier"
            )
        elif self.empty_text_evidence is not None:
            _fail("unexpected empty-text evidence")


class TableCandidate(SdkModel):
    """Master observable inventory, including semantically confirmed candidates."""

    schema_version: Literal["document_sdk.pdf.table_candidate.v1"] = (
        "document_sdk.pdf.table_candidate.v1"
    )
    candidate_id: str = Field(pattern=r"^TC5-[0-9a-f]{64}$")
    legacy_canonical_table_id: str
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_id: str
    page_number: int = Field(ge=1)
    observable_state: Literal["COMPLETE", "PARTIAL", "UNAVAILABLE"]
    row_count: int = Field(ge=1)
    column_count: int = Field(ge=1)
    rows: tuple[CanonicalTableRow, ...]
    columns: tuple[CanonicalTableColumn, ...]
    cells: tuple[SemanticCell, ...]
    geometry: SemanticGeometry
    source_identity: UnifiedPdfTableSourceIdentity
    source_provenance: tuple[str, ...]
    canonical_table: CanonicalTable
    semantic_assertion: AuthorityEvaluation

    def observable_payload(self) -> dict[str, object]:
        """Return only identity-bound observable data, excluding semantic decisions."""
        return self.model_dump(
            mode="json", exclude={"candidate_id", "semantic_assertion"}
        )

    @property
    def payload_sha256(self) -> str:
        """Hash the complete observable payload in canonical JSON form."""
        return canonical_payload_sha256(self.observable_payload())

    @model_validator(mode="after")
    def validate_inventory(self) -> Self:
        """Require exact ordered rows, columns and cells from the retained table."""
        base = self.canonical_table
        if (
            self.legacy_canonical_table_id != base.table_id
            or self.page_id != base.page_id
            or self.rows != base.rows
            or self.columns != base.columns
            or self.row_count != base.row_count
            or self.column_count != base.column_count
            or tuple(cell.canonical_cell for cell in self.cells) != base.cells
            or self.geometry.bbox != base.bbox
        ):
            _fail("candidate changed or omitted retained Canonical content")
        if self.candidate_id != candidate_identifier(
            self.source_sha256, self.payload_sha256
        ):
            _fail("candidate observable identity mismatch")
        if self.observable_state == "COMPLETE" and any(
            cell.text_state == "EMPTY_UNPROVED" for cell in self.cells
        ):
            _fail("candidate with empty observations must remain PARTIAL")
        return self


def candidate_identifier(source_sha256: str, payload_sha256: str) -> str:
    """Keep candidate identity independent of changing semantic authority."""
    return semantic_identifier(
        "TC5",
        {
            "kind": "candidate",
            "source_sha256": source_sha256,
            "payload_sha256": payload_sha256,
        },
    )


_SUPPLEMENTAL_LIMITATION: Literal["supplemental_grid_cell_text_ownership_unproved"] = (
    "supplemental_grid_cell_text_ownership_unproved"
)
_SUPPLEMENTAL_REASON = "SUPPLEMENTAL_GRID_CELL_TEXT_OWNERSHIP_UNPROVED"
_MIN_SUPPLEMENTAL_AXIS_COORDINATES = 2
_MAX_SUPPLEMENTAL_AXIS_COORDINATES = 257
_MAX_SUPPLEMENTAL_CELLS = 4096
_MAX_SUPPLEMENTAL_SOURCE_IDS = 100_000
_SourceFactId = Annotated[str, Field(pattern=r"^PDFF-[0-9a-f]{24}$")]
_NativeEventId = Annotated[str, Field(pattern=r"^PDFTE-[0-9a-f]{64}$")]
_GridCoordinate = Annotated[float, Field(allow_inf_nan=False)]


def _supplemental_axis(values: tuple[float, ...]) -> tuple[float, ...]:
    """Require a finite, strictly increasing axis before deriving identities."""
    if not (
        _MIN_SUPPLEMENTAL_AXIS_COORDINATES
        <= len(values)
        <= _MAX_SUPPLEMENTAL_AXIS_COORDINATES
    ):
        _fail("supplemental grid axis count is invalid")
    if any(
        type(value) not in (int, float) or not isfinite(value) or value < 0
        for value in values
    ):
        _fail("supplemental grid axis coordinate is invalid")
    axis = tuple(float(value) for value in values)
    if any(start >= end for start, end in pairwise(axis)):
        _fail("supplemental grid axis must increase strictly")
    return axis


def _supplemental_source_ids(
    values: tuple[str, ...], *, pattern: str, required: bool
) -> tuple[str, ...]:
    if (
        (required and not values)
        or len(values) > _MAX_SUPPLEMENTAL_SOURCE_IDS
        or any(
            type(value) is not str or fullmatch(pattern, value) is None
            for value in values
        )
        or values != tuple(sorted(set(values)))
    ):
        _fail("supplemental source identity inventory is invalid")
    return values


def _supplemental_grid_identifier(
    source_sha256: str,
    page_id: str,
    row_coordinates: tuple[float, ...],
    column_coordinates: tuple[float, ...],
    source_drawing_fact_ids: tuple[str, ...],
) -> str:
    return semantic_identifier(
        "SG5",
        {
            "kind": "supplemental_physical_grid",
            "source_sha256": source_sha256,
            "page_id": page_id,
            "row_coordinates": row_coordinates,
            "column_coordinates": column_coordinates,
            "source_drawing_fact_ids": source_drawing_fact_ids,
        },
    )


def _supplemental_cell_identifier(grid_id: str, row: int, column: int) -> str:
    return semantic_identifier(
        "SC5",
        {
            "kind": "supplemental_grid_cell",
            "grid_id": grid_id,
            "row_index": row,
            "column_index": column,
        },
    )


def _supplemental_geometry(
    x0: float, y0: float, x1: float, y1: float
) -> SemanticGeometry:
    return SemanticGeometry(
        bbox=CanonicalBoundingBox(x0=x0, y0=y0, x1=x1, y1=y1),
        claim_kind="INFERRED_PARTITION",
    )


class NativeAnchorTextProjection(SdkModel):
    """Exact decoded event text associated by its first native source anchor.

    This source-emission association does not prove physical glyph containment
    or the author's intended semantic cell ownership.
    """

    basis: Literal["NATIVE_EVENT_START_ANCHOR_V1"] = "NATIVE_EVENT_START_ANCHOR_V1"
    source_event_id: _NativeEventId
    native_event_ordinal: int = Field(ge=0)
    event_member_ids: tuple[_SourceFactId, ...] = Field(
        min_length=1, max_length=100_000
    )
    anchor_x: _GridCoordinate
    anchor_y: _GridCoordinate
    text: str = Field(min_length=1, max_length=1_000_000)

    @model_validator(mode="after")
    def validate_members(self) -> Self:
        """Keep every source occurrence distinct and ordered as emitted."""
        if len(self.event_member_ids) != len(set(self.event_member_ids)):
            _fail("native anchor projection repeats a source member")
        return self


class SupplementalTableCell(SdkModel):
    """One inferred grid slot, optionally carrying source-emission text only."""

    cell_id: str = Field(pattern=r"^SC5-[0-9a-f]{64}$")
    row_index: int = Field(ge=0)
    column_index: int = Field(ge=0)
    row_span: Literal[1] = 1
    column_span: Literal[1] = 1
    text: str | None = None
    text_state: Literal["PRESENT", "UNAVAILABLE"] = "UNAVAILABLE"
    ownership_state: Literal["AMBIGUOUS"] = "AMBIGUOUS"
    source_member_ids: tuple[()] = ()
    text_projection: NativeAnchorTextProjection | None = Field(
        default=None, exclude_if=lambda value: value is None
    )
    geometry: SemanticGeometry

    @model_validator(mode="after")
    def validate_text_projection(self) -> Self:
        """A projected value needs an explicit source link, never ownership."""
        if self.text_projection is None:
            if self.text is not None or self.text_state != "UNAVAILABLE":
                _fail("supplemental cell text has no source projection")
        elif self.text != self.text_projection.text or self.text_state != "PRESENT":
            _fail("supplemental cell text differs from source projection")
        return self


class SupplementalTableCandidate(SdkModel):
    """A physical grid candidate with unresolved cell text and semantic intent."""

    schema_version: Literal[
        "document_sdk.pdf.table_candidate.supplemental.v1",
        "document_sdk.pdf.table_candidate.supplemental.v2",
    ] = "document_sdk.pdf.table_candidate.supplemental.v1"
    candidate_id: str = Field(pattern=r"^TC5-[0-9a-f]{64}$")
    legacy_canonical_table_id: None = None
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_id: str = Field(pattern=r"^P3CE1-page-[0-9a-f]{64}$")
    page_number: int = Field(ge=1)
    grid_id: str = Field(pattern=r"^SG5-[0-9a-f]{64}$")
    observable_state: Literal["PARTIAL"] = "PARTIAL"
    row_count: int = Field(ge=1, le=256)
    column_count: int = Field(ge=1, le=256)
    row_coordinates: tuple[_GridCoordinate, ...] = Field(
        min_length=2, max_length=_MAX_SUPPLEMENTAL_AXIS_COORDINATES
    )
    column_coordinates: tuple[_GridCoordinate, ...] = Field(
        min_length=2, max_length=_MAX_SUPPLEMENTAL_AXIS_COORDINATES
    )
    cells: tuple[SupplementalTableCell, ...] = Field(
        min_length=1, max_length=_MAX_SUPPLEMENTAL_CELLS
    )
    geometry: SemanticGeometry
    source_drawing_fact_ids: tuple[_SourceFactId, ...] = Field(
        min_length=1, max_length=4096
    )
    unassigned_member_ids: tuple[_SourceFactId, ...] = Field(
        min_length=1, max_length=100_000
    )
    unassigned_native_event_ids: tuple[_NativeEventId, ...] = Field(max_length=100_000)
    limitation_codes: tuple[
        Literal["supplemental_grid_cell_text_ownership_unproved"]
    ] = (_SUPPLEMENTAL_LIMITATION,)
    semantic_assertion: AuthorityEvaluation

    def observable_payload(self) -> dict[str, object]:
        """Hash all observable structure and provenance, excluding decisions."""
        return self.model_dump(
            mode="json", exclude={"candidate_id", "semantic_assertion"}
        )

    @property
    def payload_sha256(self) -> str:
        return canonical_payload_sha256(self.observable_payload())

    @model_validator(mode="after")
    def validate_grid(self) -> Self:
        """Reject rehashed structural changes or unsupported semantic claims."""
        rows = _supplemental_axis(self.row_coordinates)
        columns = _supplemental_axis(self.column_coordinates)
        drawing_ids = _supplemental_source_ids(
            self.source_drawing_fact_ids,
            pattern=r"PDFF-[0-9a-f]{24}",
            required=True,
        )
        _supplemental_source_ids(
            self.unassigned_member_ids,
            pattern=r"PDFF-[0-9a-f]{24}",
            required=True,
        )
        _supplemental_source_ids(
            self.unassigned_native_event_ids,
            pattern=r"PDFTE-[0-9a-f]{64}",
            required=False,
        )
        if (
            self.row_count != len(rows) - 1
            or self.column_count != len(columns) - 1
            or self.row_count * self.column_count > _MAX_SUPPLEMENTAL_CELLS
            or len(self.cells) != self.row_count * self.column_count
            or self.grid_id
            != _supplemental_grid_identifier(
                self.source_sha256,
                self.page_id,
                rows,
                columns,
                drawing_ids,
            )
            or self.geometry
            != _supplemental_geometry(columns[0], rows[0], columns[-1], rows[-1])
        ):
            _fail("supplemental grid structure or identity mismatch")
        for index, cell in enumerate(self.cells):
            row, column = divmod(index, self.column_count)
            if (
                (cell.row_index, cell.column_index) != (row, column)
                or cell.cell_id
                != _supplemental_cell_identifier(self.grid_id, row, column)
                or cell.geometry
                != _supplemental_geometry(
                    columns[column],
                    rows[row],
                    columns[column + 1],
                    rows[row + 1],
                )
            ):
                _fail("supplemental cell differs from its physical grid slot")
        self._validate_projection_inventory()
        if self.semantic_assertion != AuthorityEvaluation(
            "UNRESOLVED", _SUPPLEMENTAL_REASON
        ):
            _fail("supplemental candidate cannot assert semantic authority")
        if self.candidate_id != candidate_identifier(
            self.source_sha256, self.payload_sha256
        ):
            _fail("supplemental candidate observable identity mismatch")
        return self

    def _validate_projection_inventory(self) -> None:
        """Keep a source-emission projection separate from physical ownership."""
        projected = tuple(
            cell.text_projection
            for cell in self.cells
            if cell.text_projection is not None
        )
        if bool(projected) != (
            self.schema_version == "document_sdk.pdf.table_candidate.supplemental.v2"
        ) or (projected and len(projected) != len(self.cells)):
            _fail("supplemental projection schema or cell inventory mismatch")
        if projected:
            event_ids = tuple(projection.source_event_id for projection in projected)
            member_ids = tuple(
                member_id
                for projection in projected
                for member_id in projection.event_member_ids
            )
            if (
                len(set(event_ids)) != len(event_ids)
                or set(event_ids) != set(self.unassigned_native_event_ids)
                or len(set(member_ids)) != len(member_ids)
            ):
                _fail("supplemental projection source event inventory mismatch")
            for cell in self.cells:
                projection = cell.text_projection
                if projection is None:
                    _fail("supplemental projection cell is missing")
                box = cell.geometry.bbox
                if not (
                    box.x0 < projection.anchor_x < box.x1
                    and box.y0 < projection.anchor_y < box.y1
                ):
                    _fail("supplemental projection anchor is not strictly within cell")


_BORDERLESS_REASON = "BORDERLESS_ANCHOR_LATTICE_ONLY"
_BORDERLESS_LIMITATION: Literal["borderless_physical_cell_boundary_unproved"] = (
    "borderless_physical_cell_boundary_unproved"
)
_MAX_BORDERLESS_TEXT_LENGTH = 1_000_000
_TWO_ROW_COUNT = 2


def _borderless_axis(values: tuple[float, ...], *, minimum: int) -> tuple[float, ...]:
    """An anchor axis is observed positions, never inferred cell boundaries."""
    if not minimum <= len(values) <= _MAX_SUPPLEMENTAL_AXIS_COORDINATES:
        _fail("borderless anchor axis count is invalid")
    if any(
        type(value) not in (int, float) or not isfinite(value) or value < 0
        for value in values
    ):
        _fail("borderless anchor coordinate is invalid")
    axis = tuple(float(value) for value in values)
    gaps = tuple(end - start for start, end in pairwise(axis))
    if not gaps or gaps[0] <= 0 or any(gap != gaps[0] for gap in gaps):
        _fail("borderless anchor axis is not exactly regular")
    return axis


def _borderless_two_row_columns(values: tuple[float, ...]) -> tuple[float, ...]:
    """Validate exact observed column anchors without inferring equal spacing."""
    if not _TWO_ROW_COUNT <= len(values) <= _MAX_SUPPLEMENTAL_AXIS_COORDINATES:
        _fail("borderless anchor axis count is invalid")
    if any(
        type(value) not in (int, float) or not isfinite(value) or value < 0
        for value in values
    ):
        _fail("borderless anchor coordinate is invalid")
    axis = tuple(float(value) for value in values)
    if any(start >= end for start, end in pairwise(axis)):
        _fail("borderless column anchors are not strictly increasing")
    return axis


class BorderlessLatticeSlot(SdkModel):
    """One logical anchor position with source-emission text, without a cell box."""

    row_index: int = Field(ge=0)
    column_index: int = Field(ge=0)
    anchor_x: _GridCoordinate
    anchor_y: _GridCoordinate
    source_event_id: _NativeEventId
    native_event_ordinal: int = Field(ge=0)
    source_member_ids: tuple[_SourceFactId, ...] = Field(
        min_length=1, max_length=100_000
    )
    text: str = Field(min_length=1, max_length=1_000_000)
    text_state: Literal["PRESENT"] = "PRESENT"
    physical_cell_bbox: None = None
    physical_cell_geometry_state: Literal["UNPROVED"] = "UNPROVED"
    ownership_state: Literal["AMBIGUOUS"] = "AMBIGUOUS"

    @model_validator(mode="after")
    def validate_source_members(self) -> Self:
        if len(set(self.source_member_ids)) != len(self.source_member_ids):
            _fail("borderless slot repeats a source member")
        return self


class BorderlessLatticeCandidate(SdkModel):
    """A v5-only alignment hypothesis; source text does not imply table intent."""

    schema_version: Literal[
        "document_sdk.pdf.table_candidate.borderless_lattice.v1"
    ] = "document_sdk.pdf.table_candidate.borderless_lattice.v1"
    candidate_id: str = Field(pattern=r"^TC5-[0-9a-f]{64}$")
    legacy_canonical_table_id: None = None
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_id: str = Field(pattern=r"^P3CE1-page-[0-9a-f]{64}$")
    page_number: int = Field(ge=1)
    observable_state: Literal["PARTIAL"] = "PARTIAL"
    row_count: int = Field(ge=2, le=256)
    column_count: int = Field(ge=2, le=256)
    row_anchor_coordinates: tuple[_GridCoordinate, ...] = Field(
        min_length=2, max_length=_MAX_SUPPLEMENTAL_AXIS_COORDINATES
    )
    column_anchor_coordinates: tuple[_GridCoordinate, ...] = Field(
        min_length=2, max_length=_MAX_SUPPLEMENTAL_AXIS_COORDINATES
    )
    cells: tuple[BorderlessLatticeSlot, ...] = Field(
        min_length=4, max_length=_MAX_SUPPLEMENTAL_CELLS
    )
    physical_cell_geometry_state: Literal["UNPROVED"] = "UNPROVED"
    limitation_codes: tuple[Literal["borderless_physical_cell_boundary_unproved"]] = (
        _BORDERLESS_LIMITATION,
    )
    semantic_assertion: AuthorityEvaluation

    def observable_payload(self) -> dict[str, object]:
        return self.model_dump(
            mode="json", exclude={"candidate_id", "semantic_assertion"}
        )

    @property
    def payload_sha256(self) -> str:
        return canonical_payload_sha256(self.observable_payload())

    @model_validator(mode="after")
    def validate_lattice(self) -> Self:
        rows = _borderless_axis(
            self.row_anchor_coordinates,
            minimum=_TWO_ROW_COUNT if self.row_count == _TWO_ROW_COUNT else 3,
        )
        columns = (
            _borderless_two_row_columns(self.column_anchor_coordinates)
            if self.row_count == _TWO_ROW_COUNT
            else _borderless_axis(self.column_anchor_coordinates, minimum=2)
        )
        if (
            self.row_count != len(rows)
            or self.column_count != len(columns)
            or self.row_count * self.column_count > _MAX_SUPPLEMENTAL_CELLS
            or len(self.cells) != self.row_count * self.column_count
        ):
            _fail("borderless lattice inventory is invalid")
        event_ids: set[str] = set()
        member_ids: set[str] = set()
        total_text_length = 0
        for index, slot in enumerate(self.cells):
            row, column = divmod(index, self.column_count)
            if (
                (slot.row_index, slot.column_index) != (row, column)
                or (slot.anchor_x, slot.anchor_y) != (columns[column], rows[row])
                or slot.native_event_ordinal != index
                or slot.source_event_id in event_ids
                or any(member_id in member_ids for member_id in slot.source_member_ids)
            ):
                _fail("borderless logical slot is not a unique row-major source event")
            event_ids.add(slot.source_event_id)
            member_ids.update(slot.source_member_ids)
            total_text_length += len(slot.text)
        if (
            len(member_ids) > _MAX_SUPPLEMENTAL_SOURCE_IDS
            or total_text_length > _MAX_BORDERLESS_TEXT_LENGTH
        ):
            _fail("borderless lattice source text budget exceeded")
        if self.semantic_assertion != AuthorityEvaluation(
            "UNRESOLVED", _BORDERLESS_REASON
        ):
            _fail("borderless lattice cannot assert semantic authority")
        if self.candidate_id != candidate_identifier(
            self.source_sha256, self.payload_sha256
        ):
            _fail("borderless lattice observable identity mismatch")
        return self


def build_borderless_lattice_candidate(  # noqa: PLR0913 - Explicit source axes.
    *,
    source_sha256: str,
    page_id: str,
    page_number: int,
    row_anchor_coordinates: tuple[float, ...],
    column_anchor_coordinates: tuple[float, ...],
    cells: tuple[BorderlessLatticeSlot, ...],
) -> BorderlessLatticeCandidate:
    """Build a bounded logical lattice from a separately checked source inventory."""
    payload = {
        "schema_version": "document_sdk.pdf.table_candidate.borderless_lattice.v1",
        "legacy_canonical_table_id": None,
        "source_sha256": source_sha256,
        "page_id": page_id,
        "page_number": page_number,
        "observable_state": "PARTIAL",
        "row_count": len(row_anchor_coordinates),
        "column_count": len(column_anchor_coordinates),
        "row_anchor_coordinates": row_anchor_coordinates,
        "column_anchor_coordinates": column_anchor_coordinates,
        "cells": cells,
        "physical_cell_geometry_state": "UNPROVED",
        "limitation_codes": (_BORDERLESS_LIMITATION,),
    }
    return BorderlessLatticeCandidate.model_validate(
        {
            **payload,
            "candidate_id": candidate_identifier(
                source_sha256, canonical_payload_sha256(payload)
            ),
            "semantic_assertion": AuthorityEvaluation("UNRESOLVED", _BORDERLESS_REASON),
        }
    )


ObservableTableCandidate = (
    TableCandidate | SupplementalTableCandidate | BorderlessLatticeCandidate
)


def build_supplemental_candidate(  # noqa: PLR0913 - Explicit source/grid evidence.
    *,
    source_sha256: str,
    page_id: str,
    page_number: int,
    row_coordinates: tuple[float, ...],
    column_coordinates: tuple[float, ...],
    source_drawing_fact_ids: tuple[str, ...],
    unassigned_member_ids: tuple[str, ...],
    unassigned_native_event_ids: tuple[str, ...],
    cell_text_projections: Mapping[tuple[int, int], NativeAnchorTextProjection]
    | None = None,
) -> SupplementalTableCandidate:
    """Build a bounded unresolved candidate from separately checked source facts.

    The caller must verify that the supplied drawing facts form this exact grid;
    their identity strings alone cannot establish physical separator coverage.
    """
    rows = _supplemental_axis(row_coordinates)
    columns = _supplemental_axis(column_coordinates)
    drawing_ids = _supplemental_source_ids(
        source_drawing_fact_ids, pattern=r"PDFF-[0-9a-f]{24}", required=True
    )
    member_ids = _supplemental_source_ids(
        unassigned_member_ids, pattern=r"PDFF-[0-9a-f]{24}", required=True
    )
    event_ids = _supplemental_source_ids(
        unassigned_native_event_ids, pattern=r"PDFTE-[0-9a-f]{64}", required=False
    )
    if (len(rows) - 1) * (len(columns) - 1) > _MAX_SUPPLEMENTAL_CELLS:
        _fail("supplemental grid cell limit exceeded")
    grid_id = _supplemental_grid_identifier(
        source_sha256, page_id, rows, columns, drawing_ids
    )
    projections = {} if cell_text_projections is None else dict(cell_text_projections)
    if projections and set(projections) != {
        (row, column)
        for row in range(len(rows) - 1)
        for column in range(len(columns) - 1)
    }:
        _fail("supplemental projection must cover every grid cell")
    cells = tuple(
        SupplementalTableCell(
            cell_id=_supplemental_cell_identifier(grid_id, row, column),
            row_index=row,
            column_index=column,
            text=projections[(row, column)].text if projections else None,
            text_state="PRESENT" if projections else "UNAVAILABLE",
            text_projection=projections.get((row, column)),
            geometry=_supplemental_geometry(
                columns[column], rows[row], columns[column + 1], rows[row + 1]
            ),
        )
        for row in range(len(rows) - 1)
        for column in range(len(columns) - 1)
    )
    payload = {
        "schema_version": (
            "document_sdk.pdf.table_candidate.supplemental.v2"
            if projections
            else "document_sdk.pdf.table_candidate.supplemental.v1"
        ),
        "legacy_canonical_table_id": None,
        "source_sha256": source_sha256,
        "page_id": page_id,
        "page_number": page_number,
        "grid_id": grid_id,
        "observable_state": "PARTIAL",
        "row_count": len(rows) - 1,
        "column_count": len(columns) - 1,
        "row_coordinates": rows,
        "column_coordinates": columns,
        "cells": cells,
        "geometry": _supplemental_geometry(columns[0], rows[0], columns[-1], rows[-1]),
        "source_drawing_fact_ids": drawing_ids,
        "unassigned_member_ids": member_ids,
        "unassigned_native_event_ids": event_ids,
        "limitation_codes": (_SUPPLEMENTAL_LIMITATION,),
    }
    return SupplementalTableCandidate.model_validate(
        {
            **payload,
            "candidate_id": candidate_identifier(
                source_sha256, canonical_payload_sha256(payload)
            ),
            "semantic_assertion": AuthorityEvaluation(
                "UNRESOLVED", _SUPPLEMENTAL_REASON
            ),
        }
    )


def table_identifier(source_sha256: str, candidate_id: str, authority_id: str) -> str:
    """Derive a confirmed-table reference in its separate identity namespace."""
    return semantic_identifier(
        "ST5",
        {
            "kind": "confirmed_table",
            "source_sha256": source_sha256,
            "candidate_id": candidate_id,
            "authority_id": authority_id,
        },
    )


class ConfirmedTableReference(SdkModel):
    """A semantic index entry; all cell content remains in the candidate master."""

    table_id: str = Field(pattern=r"^ST5-[0-9a-f]{64}$")
    candidate_id: str = Field(pattern=r"^TC5-[0-9a-f]{64}$")
    page_id: str
    authority_id: str


class DocumentTableHypothesis(SdkModel):
    """Preserve observable multi-page grouping without asserting author intent."""

    candidate_ids: tuple[str, ...]
    legacy: CanonicalDocumentTable
    authority_id: None = None
    semantic_table_ids: tuple[()] = ()
    disposition: Literal["UNRESOLVED"] = "UNRESOLVED"
    reason_code: Literal["CONTINUITY_AUTHORITY_NOT_IMPLEMENTED"] = (
        "CONTINUITY_AUTHORITY_NOT_IMPLEMENTED"
    )


class TransitionHypothesis(SdkModel):
    """Retain every legacy transition as an unconfirmed observable hypothesis."""

    candidate_ids: tuple[str, str]
    legacy: CanonicalTransition
    authority_id: None = None
    disposition: Literal["UNRESOLVED"] = "UNRESOLVED"


class OverlayBinding(SdkModel):
    """Bind a candidate decision and its separate confirmed reference."""

    candidate_id: str
    authority_id: str | None
    proof_id: str | None
    disposition: Literal["CONFIRMED", "REFUTED", "UNDERDETERMINED", "UNRESOLVED"]
    semantic_table_id: str | None


class CanonicalSemanticOverlay(SdkModel):
    """Additive overlay bound to the full, unchanged legacy Canonical payload."""

    schema_version: Literal["document_sdk.pdf.canonical.semantic_overlay.v1"] = (
        "document_sdk.pdf.canonical.semantic_overlay.v1"
    )
    identity_domain: Literal["document_sdk.pdf.table_semantics.identity.v1"] = (
        "document_sdk.pdf.table_semantics.identity.v1"
    )
    overlay_id: str
    source_sha256: str
    canonical_document_id: str
    canonical_payload_sha256: str
    bindings: tuple[OverlayBinding, ...]

    @model_validator(mode="after")
    def validate_identity(self) -> Self:
        """Reject recombinations across source, base document or semantic state."""
        if self.overlay_id != semantic_identifier(
            "SO5", self.model_dump(mode="json", exclude={"overlay_id"})
        ):
            _fail("semantic overlay identity mismatch")
        return self


def _cell_members(
    links: Sequence[PdfLocalCellMemberLink], evidence: PdfLocalPageEvidenceV3
) -> tuple[str, ...]:
    selections = {item.binding_id: item for item in evidence.table_member_selections}
    memberships = {
        item.fact_id: item.source_group_id for item in evidence.fact_memberships
    }
    groups = {item.source_group_id: item for item in evidence.source_groups}
    found: list[str] = []
    for link in links:
        for part in link.text_parts:
            if part.member_binding_id is not None:
                found.extend(selections[part.member_binding_id].member_ids)
            elif part.source_fact_id in memberships:
                found.extend(groups[memberships[part.source_fact_id]].member_ids)
    return tuple(dict.fromkeys(found))


def _build_cell(
    cell: CanonicalTableCell, evidence: PdfLocalPageEvidenceV3
) -> SemanticCell:
    links = tuple(
        link
        for link in evidence.cell_member_links
        if link.table_id == cell.table_id and link.source_cell_id == cell.source_cell_id
    )
    overflow = any(
        part.source_anchored_overflow_id for link in links for part in link.text_parts
    )
    return SemanticCell(
        cell_id=cell.cell_id,
        row_index=cell.row_index,
        column_index=cell.column_index,
        row_span=cell.row_span,
        column_span=cell.column_span,
        text=cell.text,
        text_state=(
            "UNAVAILABLE"
            if cell.text is None
            else "EMPTY_UNPROVED"
            if cell.text == ""
            else "PRESENT"
        ),
        geometry=SemanticGeometry(bbox=cell.bbox, claim_kind="INFERRED_PARTITION"),
        source_refs=tuple(
            dict.fromkeys(
                part.source_fact_id for link in links for part in link.text_parts
            )
        ),
        source_member_ids=_cell_members(links, evidence),
        member_links=links,
        ownership_state=(
            "AMBIGUOUS"
            if overflow
            else "UNPROVED"
            if cell.text in (None, "") or not links
            else "RECORDED_PROJECTION"
        ),
        canonical_cell=cell,
    )


def build_candidate(
    table: CanonicalTable,
    evidence: PdfLocalPageEvidenceV3,
    source_identity: UnifiedPdfTableSourceIdentity,
    source_sha256: str,
) -> TableCandidate:
    """Preserve every retained field before evaluating any semantic assertion."""
    cells = tuple(_build_cell(cell, evidence) for cell in table.cells)
    payload = {
        "schema_version": "document_sdk.pdf.table_candidate.v1",
        "legacy_canonical_table_id": table.table_id,
        "source_sha256": source_sha256,
        "page_id": table.page_id,
        "page_number": evidence.page_number,
        "observable_state": "COMPLETE"
        if table.availability.state == "AVAILABLE"
        and all(cell.ownership_state == "RECORDED_PROJECTION" for cell in cells)
        else "PARTIAL",
        "row_count": table.row_count,
        "column_count": table.column_count,
        "rows": table.rows,
        "columns": table.columns,
        "cells": cells,
        "geometry": SemanticGeometry(bbox=table.bbox, claim_kind="INFERRED_PARTITION"),
        "source_identity": source_identity,
        "source_provenance": tuple(
            dict.fromkeys(ref for cell in cells for ref in cell.source_refs)
        ),
        "canonical_table": table,
    }
    payload["candidate_id"] = candidate_identifier(
        source_sha256, canonical_payload_sha256(payload)
    )
    payload["semantic_assertion"] = AuthorityEvaluation("UNRESOLVED", "NOT_EVALUATED")
    return TableCandidate.model_validate(payload)


def candidate_scope(
    candidate: TableCandidate, evidence: PdfLocalPageEvidenceV3
) -> CandidateScope:
    """Resolve native occurrence identities from same-call retained memberships."""
    members = {member.member_id: member for member in evidence.text_members}
    events = {
        event.source_event_id: event
        for event in (
            evidence.native_text_event_evidence.events
            if evidence.native_text_event_evidence is not None
            else ()
        )
    }
    scopes: list[CandidateCellScope] = []
    for cell in candidate.cells:
        by_event: dict[str, list[str]] = {}
        for member_id in cell.source_member_ids:
            member = members[member_id]
            if member.native_text_event_id is not None:
                by_event.setdefault(member.native_text_event_id, []).append(member_id)
        native = tuple(
            NativeEventScope(
                source_event_id=event_id,
                native_event_ordinal=events[event_id].native_event_ordinal,
                invocation_path=events[event_id].invocation_path,
                operator=events[event_id].operator,
                operand_sequence_sha256=events[event_id].operand_sequence_sha256,
                source_member_ids=tuple(ids),
            )
            for event_id, ids in by_event.items()
            if event_id in events
        )
        scopes.append(
            CandidateCellScope(
                cell.row_index,
                cell.column_index,
                cell.row_span,
                cell.column_span,
                cell.source_member_ids,
                native,
            )
        )
    return CandidateScope(
        candidate.candidate_id,
        candidate.source_sha256,
        candidate.page_id,
        candidate.page_number,
        candidate.payload_sha256,
        candidate.observable_state == "COMPLETE",
        tuple(dict.fromkeys(m for cell in scopes for m in cell.source_member_ids)),
        tuple(
            dict.fromkeys(
                e.source_event_id for cell in scopes for e in cell.native_events
            )
        ),
        tuple(scopes),
    )


def confirmed_references(
    candidates: tuple[ObservableTableCandidate, ...],
) -> tuple[ConfirmedTableReference, ...]:
    """Index only positively authorized candidates without copying their contents."""
    result: list[ConfirmedTableReference] = []
    for candidate in candidates:
        decision = candidate.semantic_assertion
        if isinstance(candidate, SupplementalTableCandidate):
            if decision != AuthorityEvaluation("UNRESOLVED", _SUPPLEMENTAL_REASON):
                _fail("supplemental candidate cannot become a confirmed table")
            continue
        if isinstance(candidate, BorderlessLatticeCandidate):
            if decision != AuthorityEvaluation("UNRESOLVED", _BORDERLESS_REASON):
                _fail("borderless candidate cannot become a confirmed table")
            continue
        if decision.disposition == "CONFIRMED":
            if (
                decision.authority_id is None
                or decision.claim != "PAGE_TABLE_EXISTENCE"
            ):
                _fail("confirmed table lacks scoped positive authority")
            result.append(
                ConfirmedTableReference(
                    table_id=table_identifier(
                        candidate.source_sha256,
                        candidate.candidate_id,
                        decision.authority_id,
                    ),
                    candidate_id=candidate.candidate_id,
                    page_id=candidate.page_id,
                    authority_id=decision.authority_id,
                )
            )
    return tuple(result)


def build_overlay(
    source_sha256: str,
    canonical: CanonicalDocument,
    candidates: tuple[ObservableTableCandidate, ...],
) -> CanonicalSemanticOverlay:
    """Build an additive semantic index without rewriting any legacy identity."""
    canonical = CanonicalDocument.model_validate_json(canonical.model_dump_json())
    references = {ref.candidate_id: ref for ref in confirmed_references(candidates)}
    bindings = tuple(
        OverlayBinding(
            candidate_id=c.candidate_id,
            authority_id=c.semantic_assertion.authority_id,
            proof_id=c.semantic_assertion.proof_id,
            disposition=c.semantic_assertion.disposition,
            semantic_table_id=references[c.candidate_id].table_id
            if c.candidate_id in references
            else None,
        )
        for c in candidates
    )
    payload = {
        "schema_version": "document_sdk.pdf.canonical.semantic_overlay.v1",
        "identity_domain": SEMANTIC_IDENTITY_DOMAIN,
        "source_sha256": source_sha256,
        "canonical_document_id": canonical.canonical_document_id,
        "canonical_payload_sha256": canonical_payload_sha256(canonical),
        "bindings": bindings,
    }
    return CanonicalSemanticOverlay.model_validate(
        {**payload, "overlay_id": semantic_identifier("SO5", payload)}
    )

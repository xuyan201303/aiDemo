"""Source-bound and caller-pinned authority for the opt-in PDF table contract.

This module never interprets a detector's geometry as author intent.  A PDF
structure tree can provide positive authority only for the supported, fully
bound subset.  Caller assertions and proof approvals require pins supplied
separately from the submitted artifact bytes.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from hashlib import sha256
from io import BytesIO
from typing import TYPE_CHECKING, Literal, TypeGuard

if TYPE_CHECKING:
    from pypdf import PdfReader
    from pypdf.generic import ArrayObject, DictionaryObject

type SemanticDisposition = Literal[
    "CONFIRMED", "UNDERDETERMINED", "REFUTED", "UNRESOLVED"
]
type SemanticClaim = Literal[
    "PAGE_TABLE_EXISTENCE", "LOGICAL_TABLE_CONTINUITY", "CANDIDATE_TRANSITION"
]
type TableAssertion = Literal["TABLE", "NOT_TABLE"]

_TAG_PROFILE = "PDF_TAGGED_TABLE_V1"
_SIDECAR_PROFILE = "CALLER_PINNED_TABLE_SIDECAR_V1"
_PROOF_PROFILE = "SOURCE_SEMANTIC_UNDERDETERMINATION_V1"
_RULE = "UNTAGGED_RELATIONAL_VS_MARKS_SERIALIZATION_V1"
_QUESTION = "HIDDEN_AUTHOR_TABLE_INTENT"
_MAX_TAG_NODES = 10_000
_MAX_CONTENT_OPERATIONS = 250_000
_MAX_TAG_DEPTH = 32
_HEX = frozenset("0123456789abcdef")
_SHA_LENGTH = 64
_PAIR_COUNT = 2
_TEXT_SHOW = frozenset({b"Tj", b"TJ", b"'", b'"'})
_PROOF_CHANNELS = frozenset(
    {
        "STRUCTURE_TREE",
        "ROLE_MAP",
        "PARENT_TREE",
        "MARKED_CONTENT",
        "XOBJECTS_AND_RESOURCES",
        "ASSOCIATED_FILES",
        "AUTHORIZED_METADATA",
        "CALLER_SIDECARS",
    }
)


@dataclass(frozen=True, slots=True)
class NativeEventScope:
    """One same-call native source occurrence used by a candidate cell."""

    source_event_id: str
    native_event_ordinal: int
    invocation_path: tuple[int, ...]
    operator: Literal["Tj", "TJ", "'", '"']
    operand_sequence_sha256: str
    source_member_ids: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class CandidateCellScope:
    """A cell's exact row, source-member, and native-occurrence scope."""

    row_index: int
    column_index: int
    row_span: int
    column_span: int
    source_member_ids: tuple[str, ...]
    native_events: tuple[NativeEventScope, ...]


@dataclass(frozen=True, slots=True)
class CandidateScope:
    """Same-call observable candidate evidence supplied by the v5 builder."""

    candidate_id: str
    source_sha256: str
    page_id: str
    page_number: int
    candidate_payload_sha256: str
    observable_complete: bool
    source_member_ids: tuple[str, ...]
    source_occurrence_ids: tuple[str, ...]
    cells: tuple[CandidateCellScope, ...]


@dataclass(frozen=True, slots=True)
class AuthorityArtifact:
    """Untrusted local artifact bytes and the caller's expected content digest."""

    artifact_sha256: str
    payload: bytes


@dataclass(frozen=True, slots=True)
class TrustedAuthorityReceipt:
    """A reviewer decision supplied independently of an artifact payload."""

    receipt_sha256: str
    artifact_sha256: str
    source_sha256: str
    authorized_input_context_sha256: str
    candidate_id: str
    candidate_payload_sha256: str
    claim: SemanticClaim
    assertion: TableAssertion | Literal["UNDERDETERMINED"]
    semantic_scope: str
    subject_id: str
    reviewer_id: str
    decision: Literal["APPROVED", "PENDING", "REJECTED"]


@dataclass(frozen=True, slots=True)
class TrustedAuthorityPolicy:
    """Out-of-band trust pin; artifact contents cannot manufacture its pins."""

    policy_sha256: str
    pinned_receipt_sha256s: frozenset[str]
    receipts: tuple[TrustedAuthorityReceipt, ...]


@dataclass(frozen=True, slots=True)
class AuthorityEvaluationRequest:
    """All independent inputs to one candidate's authority evaluation."""

    source_bytes: bytes
    input_sha256: str
    expected_context_sha256: str
    candidate: CandidateScope
    semantic_context: dict[str, object] | None = None
    artifacts: tuple[AuthorityArtifact, ...] = ()
    trusted_policy: TrustedAuthorityPolicy | None = None


@dataclass(frozen=True, slots=True)
class AuthorityEvaluation:
    """One candidate's independently evaluated semantic disposition."""

    disposition: SemanticDisposition
    reason_code: str
    authority_id: str | None = None
    proof_id: str | None = None
    receipt_sha256: str | None = None
    claim: SemanticClaim | None = None
    evidence_sha256s: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class _ReceiptTarget:
    artifact_sha256: str
    claim: SemanticClaim
    assertion: TableAssertion | Literal["UNDERDETERMINED"]
    semantic_scope: str
    subject_id: str


def _digest(payload: bytes) -> str:
    return sha256(payload).hexdigest()


def _json_bytes(value: object) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def _is_sha(value: object) -> bool:
    return isinstance(value, str) and len(value) == _SHA_LENGTH and set(value) <= _HEX


def _is_pdf_int(value: object) -> TypeGuard[int]:
    return isinstance(value, int) and not isinstance(value, bool)


def _unresolved(reason: str) -> AuthorityEvaluation:
    return AuthorityEvaluation("UNRESOLVED", reason)


def _parse_object(payload: bytes) -> dict[str, object] | None:
    try:
        value = json.loads(payload)
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None
    if not isinstance(value, dict) or not all(isinstance(k, str) for k in value):
        return None
    return value


def _receipt_payload(receipt: TrustedAuthorityReceipt) -> dict[str, object]:
    return {
        "artifact_sha256": receipt.artifact_sha256,
        "source_sha256": receipt.source_sha256,
        "authorized_input_context_sha256": receipt.authorized_input_context_sha256,
        "candidate_id": receipt.candidate_id,
        "candidate_payload_sha256": receipt.candidate_payload_sha256,
        "claim": receipt.claim,
        "assertion": receipt.assertion,
        "semantic_scope": receipt.semantic_scope,
        "subject_id": receipt.subject_id,
        "reviewer_id": receipt.reviewer_id,
        "decision": receipt.decision,
    }


def receipt_digest(receipt: TrustedAuthorityReceipt) -> str:
    """Compute the immutable receipt digest without adding it to a trust pin."""
    return _digest(_json_bytes(_receipt_payload(receipt)))


def _trusted_receipt(
    request: AuthorityEvaluationRequest,
    target: _ReceiptTarget,
) -> TrustedAuthorityReceipt | None:
    policy = request.trusted_policy
    if policy is None:
        return None
    matched = [
        receipt
        for receipt in policy.receipts
        if receipt.artifact_sha256 == target.artifact_sha256
        and receipt.source_sha256 == request.input_sha256
        and receipt.authorized_input_context_sha256 == request.expected_context_sha256
        and receipt.candidate_id == request.candidate.candidate_id
        and receipt.candidate_payload_sha256
        == request.candidate.candidate_payload_sha256
        and receipt.claim == target.claim
        and receipt.assertion == target.assertion
        and receipt.semantic_scope == target.semantic_scope
        and receipt.subject_id == target.subject_id
        and receipt.decision == "APPROVED"
        and receipt.reviewer_id
        and receipt.receipt_sha256 == receipt_digest(receipt)
        and receipt.receipt_sha256 in policy.pinned_receipt_sha256s
    ]
    return matched[0] if len(matched) == 1 else None


def _candidate_scope_valid(candidate: CandidateScope) -> bool:
    if (
        not candidate.candidate_id
        or not _is_sha(candidate.source_sha256)
        or not _is_sha(candidate.candidate_payload_sha256)
        or not candidate.page_id
        or candidate.page_number < 1
        or len(set(candidate.source_member_ids)) != len(candidate.source_member_ids)
        or len(set(candidate.source_occurrence_ids))
        != len(candidate.source_occurrence_ids)
    ):
        return False
    cells = candidate.cells
    positions = [(cell.row_index, cell.column_index) for cell in cells]
    if not cells or len(set(positions)) != len(positions):
        return False
    members: set[str] = set()
    occurrences: set[str] = set()
    for cell in cells:
        if (
            min(cell.row_index, cell.column_index) < 0
            or min(cell.row_span, cell.column_span) < 1
            or len(set(cell.source_member_ids)) != len(cell.source_member_ids)
        ):
            return False
        if members.intersection(cell.source_member_ids):
            return False
        members.update(cell.source_member_ids)
        for event in cell.native_events:
            if (
                not event.source_event_id.startswith("PDFTE-")
                or event.native_event_ordinal < 0
                or not _is_sha(event.operand_sequence_sha256)
                or event.invocation_path
                or not event.source_member_ids
                or not set(event.source_member_ids) <= set(cell.source_member_ids)
                or event.source_event_id in occurrences
            ):
                return False
            occurrences.add(event.source_event_id)
    return members == set(candidate.source_member_ids) and occurrences == set(
        candidate.source_occurrence_ids
    )


def _object(value: object) -> object:
    from pypdf.generic import IndirectObject

    return value.get_object() if isinstance(value, IndirectObject) else value


def _reference_key(value: object) -> tuple[int, int] | None:
    from pypdf.generic import IndirectObject

    if isinstance(value, IndirectObject):
        return value.idnum, value.generation
    return None


def _role(
    value: object,
    role_map: DictionaryObject,
) -> str | None:
    from pypdf.generic import NameObject

    if not isinstance(value, NameObject):
        return None
    name = str(value)
    seen: set[str] = set()
    while name in role_map:
        if name in seen:
            return None
        seen.add(name)
        replacement = _object(role_map[name])
        if not isinstance(replacement, NameObject):
            return None
        name = str(replacement)
    return name


def _children(value: object) -> tuple[object, ...] | None:
    from pypdf.generic import ArrayObject, DictionaryObject, IndirectObject

    resolved = _object(value)
    if isinstance(resolved, ArrayObject):
        return tuple(resolved)
    if isinstance(resolved, (DictionaryObject, IndirectObject, int)):
        return (value,)
    return None


def _parent_tree_array(
    root: DictionaryObject, page: DictionaryObject
) -> ArrayObject | None:
    from pypdf.generic import ArrayObject, DictionaryObject

    parent_tree = _object(root.get("/ParentTree"))
    parent_index = page.get("/StructParents")
    if not isinstance(parent_tree, DictionaryObject) or not _is_pdf_int(parent_index):
        return None
    leaves = _number_tree_leaves(parent_tree)
    if leaves is None:
        return None
    matches: list[ArrayObject] = []
    for numbers in leaves:
        if len(numbers) % 2:
            return None
        found = [
            _object(numbers[i + 1])
            for i in range(0, len(numbers), 2)
            if numbers[i] == parent_index
        ]
        if any(not isinstance(value, ArrayObject) for value in found):
            return None
        matches.extend(value for value in found if isinstance(value, ArrayObject))
    return matches[0] if len(matches) == 1 else None


def _number_tree_leaves(root: DictionaryObject) -> list[ArrayObject] | None:
    from pypdf.generic import ArrayObject, DictionaryObject

    pending: list[object] = [root]
    seen: set[tuple[int, int]] = set()
    leaves: list[ArrayObject] = []
    while pending and len(seen) + len(leaves) <= _MAX_TAG_NODES:
        node_ref = pending.pop()
        key = _reference_key(node_ref)
        if key is not None and key in seen:
            return None
        if key is not None:
            seen.add(key)
        node = _object(node_ref)
        if not isinstance(node, DictionaryObject):
            return None
        numbers = _object(node.get("/Nums"))
        kids = _object(node.get("/Kids"))
        if isinstance(numbers, ArrayObject) and kids is None:
            leaves.append(numbers)
        elif isinstance(kids, ArrayObject) and numbers is None:
            pending.extend(reversed(kids))
        else:
            return None
    return leaves if not pending else None


def _cell_mcids(
    cell: DictionaryObject,
    page_ref: object,
) -> tuple[int, ...] | None:
    from pypdf.generic import DictionaryObject

    children = _children(cell.get("/K"))
    if not children:
        return None
    result: list[int] = []
    for child_ref in children:
        child = _object(child_ref)
        if _is_pdf_int(child):
            mcid = int(child)
            owner_page = cell.get("/Pg")
        elif isinstance(child, DictionaryObject) and child.get("/Type") == "/MCR":
            candidate_mcid = child.get("/MCID")
            owner_page = child.get("/Pg", cell.get("/Pg"))
            if "/Stm" in child or "/StmOwn" in child:
                return None
            if not _is_pdf_int(candidate_mcid):
                return None
            mcid = int(candidate_mcid)
        else:
            return None
        if mcid < 0 or _reference_key(owner_page) != _reference_key(page_ref):
            return None
        result.append(mcid)
    return tuple(result) if len(set(result)) == len(result) else None


@dataclass(frozen=True, slots=True)
class _TagScan:
    root: DictionaryObject
    role_map: DictionaryObject
    page_ref: object
    candidate: CandidateScope


def _match_tagged_cell(
    cell_ref: object, row_ref: object, scope: CandidateCellScope, scan: _TagScan
) -> tuple[CandidateCellScope, tuple[int, ...], object] | None:
    from pypdf.generic import DictionaryObject

    cell = _object(cell_ref)
    if not isinstance(cell, DictionaryObject):
        return None
    valid = (
        _role(cell.get("/S"), scan.role_map) in {"/TH", "/TD"}
        and _reference_key(cell.get("/P")) == _reference_key(row_ref)
        and _is_pdf_int(cell.get("/RowSpan", 1))
        and _is_pdf_int(cell.get("/ColSpan", 1))
        and cell.get("/RowSpan", 1) == scope.row_span
        and cell.get("/ColSpan", 1) == scope.column_span
    )
    if not valid:
        return None
    mcids = _cell_mcids(cell, scan.page_ref)
    return (scope, mcids, cell_ref) if mcids is not None else None


def _match_tagged_row(
    row_ref: object, table_ref: object, row_index: int, scan: _TagScan
) -> list[tuple[CandidateCellScope, tuple[int, ...], object]] | None:
    from pypdf.generic import DictionaryObject

    row = _object(row_ref)
    if not isinstance(row, DictionaryObject) or (
        _role(row.get("/S"), scan.role_map) != "/TR"
        or _reference_key(row.get("/P")) != _reference_key(table_ref)
    ):
        return None
    children = _children(row.get("/K"))
    expected = sorted(
        (cell for cell in scan.candidate.cells if cell.row_index == row_index),
        key=lambda cell: cell.column_index,
    )
    if children is None or len(children) != len(expected):
        return None
    matched = [
        _match_tagged_cell(ref, row_ref, scope, scan)
        for scope, ref in zip(expected, children, strict=True)
    ]
    return (
        [item for item in matched if item is not None]
        if all(item is not None for item in matched)
        else None
    )


def _match_tagged_table(
    table_ref: object, scan: _TagScan
) -> tuple[tuple[CandidateCellScope, tuple[int, ...], object], ...] | None:
    from pypdf.generic import DictionaryObject

    table = _object(table_ref)
    if (
        not isinstance(table, DictionaryObject)
        or _role(table.get("/S"), scan.role_map) != "/Table"
    ):
        return None
    if (
        _reference_key(table.get("/P")) != _reference_key(scan.root)
        and _object(table.get("/P")) is not scan.root
    ):
        return None
    rows = _children(table.get("/K"))
    expected_rows = sorted({cell.row_index for cell in scan.candidate.cells})
    if rows is None or len(rows) != len(expected_rows):
        return None
    matched = [
        _match_tagged_row(ref, table_ref, row_index, scan)
        for row_index, ref in zip(expected_rows, rows, strict=True)
    ]
    return (
        tuple(item for row in matched if row is not None for item in row)
        if all(row is not None for row in matched)
        else None
    )


def _tagged_cells(
    *, root: DictionaryObject, page_ref: object, candidate: CandidateScope
) -> tuple[tuple[CandidateCellScope, tuple[int, ...], object], ...] | None:
    from pypdf.generic import DictionaryObject

    role_map = _object(root.get("/RoleMap", DictionaryObject()))
    root_kids = _children(root.get("/K"))
    if not isinstance(role_map, DictionaryObject) or root_kids is None:
        return None
    if len(root_kids) > _MAX_TAG_NODES:
        return None
    scan = _TagScan(root, role_map, page_ref, candidate)
    matches = [
        table
        for ref in root_kids
        if (table := _match_tagged_table(ref, scan)) is not None
    ]
    return matches[0] if len(matches) == 1 else None


def _operand_digest(operands: list[object]) -> str | None:
    from pypdf.generic import ArrayObject, ByteStringObject, TextStringObject

    descriptors: list[dict[str, object]] = []
    for value in operands:
        if isinstance(value, ArrayObject):
            for part in value:
                if isinstance(part, (TextStringObject, ByteStringObject)):
                    raw = part.original_bytes
                    descriptors.append(
                        {"kind": "bytes", "sha256": _digest(raw), "size": len(raw)}
                    )
                elif type(part) in (int, float):
                    descriptors.append({"kind": "number", "value": part})
                else:
                    return None
        elif isinstance(value, (TextStringObject, ByteStringObject)):
            raw = value.original_bytes
            descriptors.append(
                {"kind": "bytes", "sha256": _digest(raw), "size": len(raw)}
            )
        elif type(value) in (int, float):
            descriptors.append({"kind": "number", "value": value})
        else:
            return None
    return _digest(_json_bytes(descriptors))


@dataclass(slots=True)
class _MarkedState:
    stack: list[int | None]
    events: dict[int, list[tuple[int, str, str]]]
    markers: set[int]
    event_ordinal: int = 0


def _begin_marked_content(
    operands: list[object], op: bytes, state: _MarkedState
) -> bool:
    from pypdf.generic import DictionaryObject

    if len(state.stack) >= _MAX_TAG_DEPTH:
        return False
    mcid: int | None = None
    if op == b"BMC":
        pass
    elif len(operands) == _PAIR_COUNT:
        properties = _object(operands[1])
        if not isinstance(properties, DictionaryObject):
            return False
        candidate_mcid = properties.get("/MCID")
        if candidate_mcid is not None:
            if not _is_pdf_int(candidate_mcid) or candidate_mcid < 0:
                return False
            mcid = int(candidate_mcid)
    else:
        return False
    if mcid is not None:
        if mcid in state.markers:
            return False
        state.markers.add(mcid)
    state.stack.append(mcid)
    return True


def _record_text_show(operands: list[object], op: bytes, state: _MarkedState) -> bool:
    digest = _operand_digest(operands)
    if digest is None:
        return False
    active = next((item for item in reversed(state.stack) if item is not None), None)
    if active is not None:
        state.events.setdefault(active, []).append(
            (state.event_ordinal, op.decode("ascii"), digest)
        )
    state.event_ordinal += 1
    return True


def _consume_content_operation(
    operands: list[object], op: bytes, state: _MarkedState
) -> bool:
    if op == b"Do":
        return False  # Form invocation correlation is not supported here.
    if op in {b"BMC", b"BDC"}:
        return _begin_marked_content(operands, op, state)
    if op == b"EMC":
        if not state.stack:
            return False
        state.stack.pop()
    elif op in _TEXT_SHOW:
        return _record_text_show(operands, op, state)
    return True


def _content_occurrences(
    reader: PdfReader,
    page: DictionaryObject,
) -> tuple[dict[int, list[tuple[int, str, str]]], set[int]] | None:
    from pypdf.errors import PdfReadError
    from pypdf.generic import ContentStream

    contents = page.get("/Contents")
    if contents is None:
        return None
    try:
        operations = ContentStream(contents, reader).operations
    except (PdfReadError, TypeError, ValueError, KeyError, AttributeError):
        return None
    if len(operations) > _MAX_CONTENT_OPERATIONS:
        return None
    state = _MarkedState([], {}, set())
    for operands, operator in operations:
        if not _consume_content_operation(list(operands), bytes(operator), state):
            return None
    return (state.events, state.markers) if not state.stack else None


def _tagged_authority(
    source_bytes: bytes,
    candidate: CandidateScope,
) -> AuthorityEvaluation | None:
    evidence = _read_tagged_evidence(source_bytes, candidate)
    if evidence is None:
        return None
    parent_tree, cells, occurrences = evidence
    claimed_mcids = _check_mcid_bindings(parent_tree, cells, occurrences)
    if not claimed_mcids:
        return None
    authority_id = "pdfv5-tagged-" + _digest(
        _json_bytes(
            {
                "profile": _TAG_PROFILE,
                "source_sha256": candidate.source_sha256,
                "candidate_id": candidate.candidate_id,
                "candidate_payload_sha256": candidate.candidate_payload_sha256,
                "page_number": candidate.page_number,
                "mcids": sorted(claimed_mcids),
            }
        )
    )
    return AuthorityEvaluation(
        "CONFIRMED",
        "SOURCE_TAGGED_TABLE_VALIDATED",
        authority_id=authority_id,
        claim="PAGE_TABLE_EXISTENCE",
        evidence_sha256s=(_digest(source_bytes),),
    )


def _read_tagged_evidence(
    source_bytes: bytes,
    candidate: CandidateScope,
) -> (
    tuple[
        ArrayObject,
        tuple[tuple[CandidateCellScope, tuple[int, ...], object], ...],
        tuple[dict[int, list[tuple[int, str, str]]], set[int]],
    ]
    | None
):
    from pypdf import PdfReader
    from pypdf.errors import PdfReadError
    from pypdf.generic import DictionaryObject

    try:
        reader = PdfReader(BytesIO(source_bytes), strict=True)
        page = reader.pages[candidate.page_number - 1]
        catalog = _object(reader.trailer["/Root"])
        if not isinstance(catalog, DictionaryObject):
            return None
        root_ref = catalog.get("/StructTreeRoot")
        root = _object(root_ref)
        if not isinstance(root, DictionaryObject):
            return None
        parent_tree = _parent_tree_array(root, page)
        page_ref = page.indirect_reference
        cells = _tagged_cells(root=root, page_ref=page_ref, candidate=candidate)
        occurrences = _content_occurrences(reader, page)
    except (PdfReadError, ValueError, TypeError, KeyError, IndexError, AttributeError):
        return None
    return (
        (parent_tree, cells, occurrences)
        if parent_tree is not None and cells is not None and occurrences is not None
        else None
    )


def _check_mcid_bindings(
    parent_tree: ArrayObject,
    cells: tuple[tuple[CandidateCellScope, tuple[int, ...], object], ...],
    occurrences: tuple[dict[int, list[tuple[int, str, str]]], set[int]],
) -> set[int] | None:
    events, markers = occurrences
    claimed_mcids: set[int] = set()
    for cell, mcids, cell_ref in cells:
        actual_events = [item for mcid in mcids for item in events.get(mcid, [])]
        expected_events = [
            (event.native_event_ordinal, event.operator, event.operand_sequence_sha256)
            for event in cell.native_events
        ]
        if sorted(actual_events) != sorted(expected_events):
            return None
        for mcid in mcids:
            if (
                mcid not in markers
                or mcid >= len(parent_tree)
                or _reference_key(parent_tree[mcid]) != _reference_key(cell_ref)
                or mcid in claimed_mcids
            ):
                return None
            claimed_mcids.add(mcid)
    return claimed_mcids


def _artifact_by_digest(
    artifacts: tuple[AuthorityArtifact, ...],
) -> dict[str, bytes] | None:
    result: dict[str, bytes] = {}
    for artifact in artifacts:
        if (
            not _is_sha(artifact.artifact_sha256)
            or _digest(artifact.payload) != artifact.artifact_sha256
            or artifact.artifact_sha256 in result
        ):
            return None
        result[artifact.artifact_sha256] = artifact.payload
    return result


def _sidecar_body(
    request: AuthorityEvaluationRequest, body: dict[str, object]
) -> tuple[str, TableAssertion, str] | None:
    candidate = request.candidate
    required = {
        "schema_version",
        "authority_id",
        "profile",
        "input_sha256",
        "candidate_id",
        "candidate_payload_sha256",
        "page_id",
        "page_number",
        "claim",
        "assertion",
        "semantic_scope",
        "source_member_ids",
        "source_occurrence_ids",
        "cells",
    }
    if set(body) != required or body["schema_version"] != "pdf_table_sidecar.v1":
        return None
    assertion = body["assertion"]
    claim = body["claim"]
    if assertion not in {"TABLE", "NOT_TABLE"} or claim != "PAGE_TABLE_EXISTENCE":
        return None
    if (
        body["profile"] != _SIDECAR_PROFILE
        or body["input_sha256"] != request.input_sha256
        or body["candidate_id"] != candidate.candidate_id
        or body["candidate_payload_sha256"] != candidate.candidate_payload_sha256
        or body["page_id"] != candidate.page_id
        or body["page_number"] != candidate.page_number
        or body["source_member_ids"] != list(candidate.source_member_ids)
        or body["source_occurrence_ids"] != list(candidate.source_occurrence_ids)
        or not isinstance(body["semantic_scope"], str)
        or not body["semantic_scope"]
        or not isinstance(body["authority_id"], str)
    ):
        return None
    expected_cells = [
        {
            "row_index": cell.row_index,
            "column_index": cell.column_index,
            "row_span": cell.row_span,
            "column_span": cell.column_span,
            "source_member_ids": list(cell.source_member_ids),
            "source_occurrence_ids": [
                event.source_event_id for event in cell.native_events
            ],
        }
        for cell in candidate.cells
    ]
    if body["cells"] != expected_cells:
        return None
    unsigned = {key: value for key, value in body.items() if key != "authority_id"}
    authority_id = "pdfv5-sidecar-" + _digest(_json_bytes(unsigned))
    if body["authority_id"] != authority_id:
        return None
    typed_assertion: TableAssertion = "TABLE" if assertion == "TABLE" else "NOT_TABLE"
    return authority_id, typed_assertion, body["semantic_scope"]


def _sidecar_authority(
    request: AuthorityEvaluationRequest,
    artifact_sha256: str,
    body: dict[str, object],
) -> AuthorityEvaluation | None:
    parsed = _sidecar_body(request, body)
    if parsed is None:
        return None
    authority_id, assertion, scope = parsed
    receipt = _trusted_receipt(
        request,
        _ReceiptTarget(
            artifact_sha256,
            "PAGE_TABLE_EXISTENCE",
            assertion,
            scope,
            authority_id,
        ),
    )
    if receipt is None:
        return None
    return AuthorityEvaluation(
        "CONFIRMED" if assertion == "TABLE" else "REFUTED",
        "CALLER_PINNED_SIDECAR_VALIDATED",
        authority_id=authority_id,
        receipt_sha256=receipt.receipt_sha256,
        claim="PAGE_TABLE_EXISTENCE",
        evidence_sha256s=(artifact_sha256,),
    )


def _underdetermination_proof(
    request: AuthorityEvaluationRequest,
    artifact_sha256: str,
    body: dict[str, object],
    artifact_map: dict[str, bytes],
) -> AuthorityEvaluation | None:
    if not _proof_header_valid(request, body):
        return None
    dependencies = _proof_dependencies(request, body, artifact_map)
    if dependencies is None or not _proof_source_channels_supported(
        request.source_bytes
    ):
        return None
    unsigned = {key: value for key, value in body.items() if key != "proof_id"}
    proof_id = "pdfv5-underdetermination-" + _digest(_json_bytes(unsigned))
    if body["proof_id"] != proof_id or body["reviewer_status"] != "APPROVED":
        return None
    scope = body["semantic_scope"]
    if not isinstance(scope, str):
        return None
    receipt = _trusted_receipt(
        request,
        _ReceiptTarget(
            artifact_sha256,
            "PAGE_TABLE_EXISTENCE",
            "UNDERDETERMINED",
            scope,
            proof_id,
        ),
    )
    return (
        AuthorityEvaluation(
            "UNDERDETERMINED",
            "SCOPED_NONUNIQUENESS_REVIEWED",
            proof_id=proof_id,
            receipt_sha256=receipt.receipt_sha256,
            claim="PAGE_TABLE_EXISTENCE",
            evidence_sha256s=(artifact_sha256, *dependencies),
        )
        if receipt is not None
        else None
    )


def _proof_header_valid(
    request: AuthorityEvaluationRequest, body: dict[str, object]
) -> bool:
    required = {
        "schema_version",
        "proof_id",
        "input_sha256",
        "authorized_input_context_sha256",
        "candidate_id",
        "candidate_payload_sha256",
        "obligation_id",
        "semantic_question",
        "proof_rule_version",
        "semantic_scope",
        "reviewer_status",
        "source_valid",
        "observable_extraction_complete",
        "implementation_gap_excluded",
        "parser_error_excluded",
        "semantic_channels_complete",
        "opposite_intent_same_authorized_bytes",
        "applicability_certificate_sha256",
        "equivalent_histories",
    }
    return (
        set(body) == required
        and body["schema_version"] == _PROOF_PROFILE
        and body["input_sha256"] == request.input_sha256
        and body["authorized_input_context_sha256"] == request.expected_context_sha256
        and body["candidate_id"] == request.candidate.candidate_id
        and body["candidate_payload_sha256"]
        == request.candidate.candidate_payload_sha256
        and body["semantic_question"] == _QUESTION
        and body["proof_rule_version"] == _RULE
        and isinstance(body["obligation_id"], str)
        and bool(body["obligation_id"])
        and isinstance(body["semantic_scope"], str)
        and bool(body["semantic_scope"])
        and request.candidate.observable_complete
        and all(
            body[key] is True
            for key in (
                "source_valid",
                "observable_extraction_complete",
                "implementation_gap_excluded",
                "parser_error_excluded",
                "semantic_channels_complete",
                "opposite_intent_same_authorized_bytes",
            )
        )
        and _is_sha(body["applicability_certificate_sha256"])
    )


def _proof_dependencies(
    request: AuthorityEvaluationRequest,
    body: dict[str, object],
    artifact_map: dict[str, bytes],
) -> tuple[str, ...] | None:
    input_sha256 = request.input_sha256
    context_sha256 = request.expected_context_sha256
    histories = body["equivalent_histories"]
    if not isinstance(histories, list):
        return None
    valid_histories = [history for history in histories if isinstance(history, dict)]
    if (
        len(histories) != _PAIR_COUNT
        or len(valid_histories) != _PAIR_COUNT
        or not all(
            _history_reference_valid(history, request) for history in valid_histories
        )
        or {history["intent"] for history in valid_histories} != {"TABLE", "NOT_TABLE"}
    ):
        return None
    applicability_sha = body["applicability_certificate_sha256"]
    if not isinstance(applicability_sha, str):
        return None
    applicability = _parse_dependency(artifact_map, applicability_sha)
    if applicability is None or not _valid_applicability(
        applicability,
        body=body,
        candidate=request.candidate,
        input_sha256=input_sha256,
        context_sha256=context_sha256,
    ):
        return None
    if not all(
        _history_witness_valid(history, request, artifact_map)
        for history in valid_histories
    ):
        return None
    return (
        applicability_sha,
        *(
            history["witness_sha256"]
            for history in valid_histories
            if isinstance(history["witness_sha256"], str)
        ),
    )


def _history_reference_valid(
    history: dict[str, object], request: AuthorityEvaluationRequest
) -> bool:
    return (
        set(history)
        == {
            "intent",
            "source_sha256",
            "authorized_input_context_sha256",
            "witness_sha256",
        }
        and history["source_sha256"] == request.input_sha256
        and history["authorized_input_context_sha256"]
        == request.expected_context_sha256
        and _is_sha(history["witness_sha256"])
        and history["intent"] in {"TABLE", "NOT_TABLE"}
    )


def _history_witness_valid(
    history: dict[str, object],
    request: AuthorityEvaluationRequest,
    artifact_map: dict[str, bytes],
) -> bool:
    witness_sha = history["witness_sha256"]
    if not isinstance(witness_sha, str):
        return False
    witness = _parse_dependency(artifact_map, witness_sha)
    return witness is not None and _valid_history_witness(
        witness,
        history=history,
        input_sha256=request.input_sha256,
        context_sha256=request.expected_context_sha256,
    )


def _parse_dependency(
    artifacts: dict[str, bytes], expected_sha256: str
) -> dict[str, object] | None:
    payload = artifacts.get(expected_sha256)
    return _parse_object(payload) if payload is not None else None


def _valid_applicability(
    certificate: dict[str, object],
    *,
    body: dict[str, object],
    candidate: CandidateScope,
    input_sha256: str,
    context_sha256: str,
) -> bool:
    required = {
        "schema_version",
        "input_sha256",
        "authorized_input_context_sha256",
        "candidate_id",
        "candidate_payload_sha256",
        "obligation_id",
        "semantic_question",
        "channels_inspected",
        "source_valid",
        "observable_extraction_complete",
        "implementation_gap_excluded",
        "parser_error_excluded",
        "semantic_channels_complete",
        "applicable",
    }
    return (
        set(certificate) == required
        and certificate["schema_version"] == "pdf_table_intent_applicability.v1"
        and certificate["input_sha256"] == input_sha256
        and certificate["authorized_input_context_sha256"] == context_sha256
        and certificate["candidate_id"] == candidate.candidate_id
        and certificate["candidate_payload_sha256"]
        == candidate.candidate_payload_sha256
        and certificate["obligation_id"] == body["obligation_id"]
        and certificate["semantic_question"] == _QUESTION
        and isinstance(certificate["channels_inspected"], list)
        and set(certificate["channels_inspected"]) == _PROOF_CHANNELS
        and len(certificate["channels_inspected"]) == len(_PROOF_CHANNELS)
        and all(
            certificate[key] is True
            for key in (
                "source_valid",
                "observable_extraction_complete",
                "implementation_gap_excluded",
                "parser_error_excluded",
                "semantic_channels_complete",
                "applicable",
            )
        )
    )


def _valid_history_witness(
    witness: dict[str, object],
    *,
    history: dict[str, object],
    input_sha256: str,
    context_sha256: str,
) -> bool:
    return (
        set(witness)
        == {
            "schema_version",
            "source_sha256",
            "authorized_input_context_sha256",
            "intent",
            "byte_preserving_construction",
            "source_history_valid",
        }
        and witness["schema_version"] == "pdf_opposite_intent_history.v1"
        and witness["source_sha256"] == input_sha256
        and witness["authorized_input_context_sha256"] == context_sha256
        and witness["intent"] == history["intent"]
        and witness["byte_preserving_construction"] is True
        and witness["source_history_valid"] is True
    )


def _proof_source_channels_supported(source_bytes: bytes) -> bool:
    """Accept the small PDF-only proof subset whose channels can be audited."""
    from pypdf import PdfReader
    from pypdf.errors import PdfReadError
    from pypdf.generic import ContentStream, DictionaryObject

    try:
        reader = PdfReader(BytesIO(source_bytes), strict=True)
        catalog = _object(reader.trailer["/Root"])
        if not isinstance(catalog, DictionaryObject) or any(
            key in catalog for key in ("/StructTreeRoot", "/Names", "/AF", "/Metadata")
        ):
            return False
        for page in reader.pages:
            if any(key in page for key in ("/Annots", "/AF", "/Metadata")):
                return False
            contents = page.get("/Contents")
            if contents is None:
                continue
            operations = ContentStream(contents, reader).operations
            if len(operations) > _MAX_CONTENT_OPERATIONS or any(
                bytes(operator) in {b"Do", b"BDC", b"BMC"} for _, operator in operations
            ):
                return False
    except (PdfReadError, ValueError, TypeError, KeyError, IndexError, AttributeError):
        return False
    return True


def _context_references(
    request: AuthorityEvaluationRequest,
) -> tuple[list[object], list[object]] | None:
    context = request.semantic_context
    if context is None:
        return (
            ([], [])
            if not request.artifacts and request.trusted_policy is None
            else None
        )
    required = {
        "schema_version",
        "source_sha256",
        "trust_policy_sha256",
        "sidecars",
        "underdetermination_certificates",
    }
    policy = request.trusted_policy
    if (
        set(context) != required
        or context["schema_version"] != "document_sdk.pdf.semantic_context.v1"
        or context["source_sha256"] != request.input_sha256
        or policy is None
        or context["trust_policy_sha256"] != policy.policy_sha256
        or not _is_sha(policy.policy_sha256)
    ):
        return None
    sidecars = context["sidecars"]
    proofs = context["underdetermination_certificates"]
    return (
        (sidecars, proofs)
        if isinstance(sidecars, list) and isinstance(proofs, list)
        else None
    )


def _referenced_body(
    reference: object, artifacts: dict[str, bytes], used: set[str]
) -> tuple[str, dict[str, object]] | None:
    if not isinstance(reference, dict) or set(reference) != {
        "artifact_sha256",
        "pointer",
    }:
        return None
    digest = reference["artifact_sha256"]
    if (
        not _is_sha(digest)
        or reference["pointer"] != ""
        or digest in used
        or digest not in artifacts
    ):
        return None
    body = _parse_object(artifacts[digest])
    if body is None or not isinstance(body.get("candidate_id"), str):
        return None
    used.add(digest)
    return digest, body


def _external_decisions(
    request: AuthorityEvaluationRequest,
    references: tuple[list[object], list[object]],
    artifacts: dict[str, bytes],
) -> list[AuthorityEvaluation] | AuthorityEvaluation:
    decisions: list[AuthorityEvaluation] = []
    used: set[str] = set()
    for entries, is_proof in ((references[0], False), (references[1], True)):
        for reference in entries:
            item = _referenced_body(reference, artifacts, used)
            if item is None:
                return _unresolved("INVALID_AUTHORITY")
            digest, body = item
            if body["candidate_id"] != request.candidate.candidate_id:
                continue
            decision = (
                _underdetermination_proof(request, digest, body, artifacts)
                if is_proof
                else _sidecar_authority(request, digest, body)
            )
            if decision is None:
                reason = "PENDING_PROOF_REVIEW" if is_proof else "INVALID_AUTHORITY"
                return _unresolved(reason)
            if not set(decision.evidence_sha256s) <= set(artifacts):
                return _unresolved("INVALID_AUTHORITY")
            decisions.append(decision)
    return decisions


def _decide(
    decisions: list[AuthorityEvaluation], candidate: CandidateScope
) -> AuthorityEvaluation:
    if len(decisions) > 1 and (
        len({decision.disposition for decision in decisions}) > 1
        or len({decision.authority_id or decision.proof_id for decision in decisions})
        > 1
    ):
        return _unresolved("CONFLICTING_AUTHORITY")
    if decisions:
        return decisions[0]
    reason = (
        "NOT_EVALUATED"
        if candidate.observable_complete
        else "INCOMPLETE_OBSERVABLE_EXTRACTION"
    )
    return _unresolved(reason)


def evaluate_authority(request: AuthorityEvaluationRequest) -> AuthorityEvaluation:
    """Evaluate source tags and independently pinned artifacts, fail closed."""
    candidate = request.candidate
    if (
        not _is_sha(request.input_sha256)
        or _digest(request.source_bytes) != request.input_sha256
        or candidate.source_sha256 != request.input_sha256
        or not _is_sha(request.expected_context_sha256)
        or not _candidate_scope_valid(candidate)
    ):
        return _unresolved("MISSING_SOURCE_EVIDENCE")
    references = _context_references(request)
    artifacts = _artifact_by_digest(request.artifacts)
    if references is None or artifacts is None:
        return _unresolved("INVALID_AUTHORITY")
    external = _external_decisions(request, references, artifacts)
    if isinstance(external, AuthorityEvaluation):
        return external
    tagged = _tagged_authority(request.source_bytes, candidate)
    if tagged is not None:
        external.insert(0, tagged)
    return _decide(external, candidate)

"""V5-only borderless source-anchor lattice without physical cell geometry.

The complete native event inventory must itself form an exact row-major
Cartesian lattice. Three or more rows retain the regular-axis requirement;
two rows require repeated exact column anchors. This is an observable
alignment hypothesis and exact source text mapping, with no cell-boundary,
ownership, or table-intent claim.
"""

from __future__ import annotations

from itertools import pairwise
from typing import TYPE_CHECKING

from document_sdk.pdf._structural_engine.facts.coordinates import (
    pdfminer_native_origin_to_canonical,
)

from .overlay import (
    BorderlessLatticeCandidate,
    BorderlessLatticeSlot,
    build_borderless_lattice_candidate,
)

if TYPE_CHECKING:
    from document_sdk.pdf._structural_engine.canonical.contracts import (
        CanonicalDocument,
        CanonicalPage,
    )
    from document_sdk.pdf._structural_engine.facts.native_text_contracts import (
        PdfNativeTextShowEvent,
    )
    from document_sdk.pdf.local_evidence_members import (
        PdfLocalEvidenceV3,
        PdfLocalPageEvidenceV3,
        PdfLocalTextMember,
    )

_MAX_SLOTS = 4096
_MAX_MEMBERS = 100_000
_MAX_TEXT_LENGTH = 1_000_000
_MAX_AXIS = 256
_MIN_LATTICE_SLOTS = 4
_TWO_ROW_COUNT = 2


def _complete_page_inventory(page: PdfLocalPageEvidenceV3) -> bool:
    native = page.native_text_event_evidence
    if (
        native is None
        or page.drawings
        or page.source_member_inventory_status != "COMPLETE"
        or page.native_text_event_capture_status != "COMPLETE"
        or page.projection_truncated
        or page.source_group_truncated
        or page.source_group_count != len(page.source_groups)
        or native.availability != "COMPLETE"
        or native.truncated
        or native.limitation_codes
        or native.source_event_count != native.retained_event_count
        or native.retained_event_count != len(native.events)
        or native.source_member_count != native.retained_member_count
        or native.retained_member_count != len(page.text_members)
        or page.source_member_count != len(page.text_members)
        or page.available_record_counts.text_members != len(page.text_members)
        or page.available_record_counts.native_text_events != len(native.events)
        or not _MIN_LATTICE_SLOTS <= len(native.events) <= _MAX_SLOTS
        or len(page.text_members) > _MAX_MEMBERS
        or any(
            group.member_inventory_status != "COMPLETE"
            or group.member_projection_status not in {"EXACT", "TRANSFORMED"}
            for group in page.source_groups
        )
    ):
        return False
    member_ids = {member.member_id for member in page.text_members}
    # Word, text-span, and line groups can overlap; each group's ordered
    # projection is model-validated. Require complete coverage, not membership
    # in exactly one group.
    return (
        len(member_ids) == len(page.text_members)
        and {
            member_id for group in page.source_groups for member_id in group.member_ids
        }
        == member_ids
    )


def _ordered_members(
    event: PdfNativeTextShowEvent,
    group: list[PdfLocalTextMember],
) -> tuple[PdfLocalTextMember, ...] | None:
    if (
        event.completeness != "COMPLETE"
        or event.limitation_codes
        or event.operator != "Tj"
        or event.operand_count != 1
        or event.string_segment_count != 1
        or event.numeric_adjustment_count != 0
        or event.source_member_count != len(group)
        or event.retained_member_count != len(group)
        or not group
    ):
        return None
    ordered = tuple(
        sorted(
            group,
            key=lambda member: (
                member.native_text_event_member_ordinal
                if member.native_text_event_member_ordinal is not None
                else -1
            ),
        )
    )
    if tuple(member.native_text_event_member_ordinal for member in ordered) != tuple(
        range(len(ordered))
    ):
        return None
    if any(
        member.native_text_event_id != event.source_event_id
        or member.native_text_event_ordinal != event.native_event_ordinal
        or member.selection_state != "RETAINED"
        or member.duplicate_of_member_id is not None
        or member.geometry_status != "INSIDE"
        or member.bbox is None
        or member.warnings
        or member.rotation != 0
        or member.source_writing_mode != "HORIZONTAL"
        or member.parser_advance is None
        or member.parser_advance <= 0
        or member.parser_text_matrix is None
        or member.parser_text_matrix[:4] != (1, 0, 0, 1)
        or member.native_character_ordinal is None
        for member in ordered
    ) or any(
        left.native_character_ordinal is None
        or right.native_character_ordinal != left.native_character_ordinal + 1
        or right.source_character_index != left.source_character_index + 1
        for left, right in pairwise(ordered)
    ):
        return None
    return ordered


def _anchor(
    page: PdfLocalPageEvidenceV3,
    first: PdfLocalTextMember,
) -> tuple[float, float] | None:
    matrix = first.parser_text_matrix
    box = first.bbox
    if matrix is None or box is None:
        return None
    media = page.media_box_points
    effective = page.effective_page_box_points
    try:
        x, y = pdfminer_native_origin_to_canonical(
            parser_origin=(matrix[4], matrix[5]),
            media_box=(media.x0, media.y0, media.x1, media.y1),
            effective_box=(effective.x0, effective.y0, effective.x1, effective.y1),
            page_rotation=page.rotation,
            user_unit=page.user_unit,
        )
    except ValueError:
        return None
    # An unrecorded text rise can move glyphs away from the matrix origin.
    # This check binds the first visible member to the chosen source anchor;
    # it does not turn a character extent into a physical cell boundary.
    if not (
        0 <= x <= page.width_points
        and 0 <= y <= page.height_points
        and box.x0 <= x <= box.x1
        and box.y0 <= y <= box.y1
    ):
        return None
    return x, y


def _regular_axis(values: tuple[float, ...], *, minimum: int) -> bool:
    if not minimum <= len(values) <= _MAX_AXIS:
        return False
    gaps = tuple(end - start for start, end in pairwise(values))
    return bool(gaps) and gaps[0] > 0 and all(gap == gaps[0] for gap in gaps)


def _page_lattice(  # noqa: C901, PLR0911, PLR0912 - Fail closed at each source gate.
    canonical: CanonicalPage,
    page: PdfLocalPageEvidenceV3,
    source_sha256: str,
) -> BorderlessLatticeCandidate | None:
    if (
        canonical.source_page_id != page.source_page_id
        or canonical.table_ids
        or not _complete_page_inventory(page)
    ):
        return None
    native = page.native_text_event_evidence
    if native is None:
        return None
    events = tuple(sorted(native.events, key=lambda event: event.native_event_ordinal))
    if (
        len({event.source_event_id for event in events}) != len(events)
        or tuple(event.native_event_ordinal for event in events)
        != tuple(range(len(events)))
        or {member.native_character_ordinal for member in page.text_members}
        != set(range(len(page.text_members)))
    ):
        return None
    groups: dict[str, list[PdfLocalTextMember]] = {}
    event_ids = {event.source_event_id for event in events}
    for member in page.text_members:
        if member.native_text_event_id not in event_ids:
            return None
        groups.setdefault(member.native_text_event_id, []).append(member)
    if set(groups) != event_ids:
        return None
    observed: list[
        tuple[float, float, PdfNativeTextShowEvent, tuple[PdfLocalTextMember, ...], str]
    ] = []
    text_length = 0
    for event in events:
        if (
            event.source_sha256 != source_sha256
            or event.page_number != page.page_number
        ):
            return None
        ordered = _ordered_members(event, groups[event.source_event_id])
        if ordered is None:
            return None
        point = _anchor(page, ordered[0])
        if point is None:
            return None
        text = "".join(member.text for member in ordered)
        text_length += len(text)
        if not text or text_length > _MAX_TEXT_LENGTH:
            return None
        observed.append((point[0], point[1], event, ordered, text))
    columns = tuple(sorted({item[0] for item in observed}))
    rows = tuple(sorted({item[1] for item in observed}))
    if len(rows) == _TWO_ROW_COUNT:
        # Two complete rows prove an observable Cartesian product when their
        # exact ordered x anchors agree; equal column spacing is unnecessary.
        if (
            not _TWO_ROW_COUNT <= len(columns) <= _MAX_AXIS
            or any(start >= end for start, end in pairwise(columns))
            or len(observed) != _TWO_ROW_COUNT * len(columns)
            or tuple(item[0] for item in observed[: len(columns)]) != columns
            or tuple(item[0] for item in observed[len(columns) :]) != columns
        ):
            return None
    elif (
        not _regular_axis(rows, minimum=3)
        or not _regular_axis(columns, minimum=2)
        or len(observed) != len(rows) * len(columns)
        or any(
            group.member_projection_status != "EXACT" for group in page.source_groups
        )
    ):
        # Preserve Wave7A's three-or-more-row rule and its candidate IDs.
        return None
    row_index = {value: index for index, value in enumerate(rows)}
    column_index = {value: index for index, value in enumerate(columns)}
    slots: list[BorderlessLatticeSlot] = []
    for ordinal, (x, y, event, members, text) in enumerate(observed):
        row, column = divmod(ordinal, len(columns))
        if row_index[y] != row or column_index[x] != column:
            return None
        slots.append(
            BorderlessLatticeSlot(
                row_index=row,
                column_index=column,
                anchor_x=x,
                anchor_y=y,
                source_event_id=event.source_event_id,
                native_event_ordinal=event.native_event_ordinal,
                source_member_ids=tuple(member.member_id for member in members),
                text=text,
            )
        )
    return build_borderless_lattice_candidate(
        source_sha256=source_sha256,
        page_id=canonical.page_id,
        page_number=page.page_number,
        row_anchor_coordinates=rows,
        column_anchor_coordinates=columns,
        cells=tuple(slots),
    )


def supplemental_borderless_candidates(
    canonical: CanonicalDocument, evidence: PdfLocalEvidenceV3
) -> tuple[BorderlessLatticeCandidate, ...]:
    """Return one source-complete logical lattice per eligible page, if any."""
    pages = {page.page_number: page for page in evidence.pages}
    found = []
    for canonical_page in canonical.pages:
        page = pages.get(canonical_page.page_number)
        if page is None:
            continue
        candidate = _page_lattice(canonical_page, page, evidence.source_sha256)
        if candidate is not None:
            found.append(candidate)
    return tuple(found)

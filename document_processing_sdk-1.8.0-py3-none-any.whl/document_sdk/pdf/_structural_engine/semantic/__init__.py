"""Additive semantic authority; legacy detection and identities remain unchanged."""

"""Conservative v5-only ruled grids from same-call retained source paths.

This is an observable physical hypothesis. A complete native event may supply
source-emission text by its first anchor, but physical and semantic ownership
remain unresolved. The legacy Table producer and Canonical projection stay put.
"""

from __future__ import annotations

from bisect import bisect_right
from dataclasses import dataclass
from itertools import pairwise
from typing import TYPE_CHECKING, Literal

from document_sdk.pdf._structural_engine.facts.coordinates import (
    pdfminer_native_origin_to_canonical,
)
from document_sdk.pdf.local_evidence_members import _overflow_strokes

from .overlay import (
    NativeAnchorTextProjection,
    SupplementalTableCandidate,
    build_supplemental_candidate,
)

if TYPE_CHECKING:
    from document_sdk.pdf._structural_engine.canonical.contracts import (
        CanonicalDocument,
        CanonicalPage,
    )
    from document_sdk.pdf._structural_engine.facts.native_text_contracts import (
        PdfNativeTextShowEvent,
    )
    from document_sdk.pdf.local_evidence import PdfLocalDrawingEvidence
    from document_sdk.pdf.local_evidence_members import (
        PdfLocalEvidenceV3,
        PdfLocalPageEvidenceV3,
        PdfLocalTextMember,
    )

_MAX_PAGE_STROKES = 2048
_MAX_GRID_COMPONENT_STROKES = 128
_MINIMUM_AXES = 3
_SIMPLE_LINE_PATH_SEGMENTS = 2
_MAX_PROJECTED_EVENT_MEMBERS = 100_000
_MAX_PROJECTED_TEXT_LENGTH = 1_000_000


@dataclass(frozen=True, slots=True)
class _Stroke:
    axis: Literal["ROW", "COLUMN"]
    coordinate: float
    start: float
    end: float
    fact_id: str


@dataclass(frozen=True, slots=True)
class _NativeProjectionPool:
    events: dict[str, PdfNativeTextShowEvent]
    members: dict[str, tuple[PdfLocalTextMember, ...]]


def _native_projection_pool(
    page: PdfLocalPageEvidenceV3, source_sha256: str
) -> _NativeProjectionPool | None:
    """Index the complete same-page native inventory once, without truth data."""
    native = page.native_text_event_evidence
    if (
        native is None
        or native.availability != "COMPLETE"
        or native.truncated
        or native.limitation_codes
        or page.source_member_inventory_status != "COMPLETE"
        or page.native_text_event_capture_status != "COMPLETE"
        or page.projection_truncated
        or page.source_group_truncated
        or page.source_group_count != len(page.source_groups)
        or any(
            group.member_inventory_status != "COMPLETE" for group in page.source_groups
        )
        or native.source_event_count != native.retained_event_count
        or native.retained_event_count != len(native.events)
        or native.source_member_count != native.retained_member_count
        or native.retained_member_count != len(page.text_members)
        or page.source_member_count != len(page.text_members)
        or page.available_record_counts.text_members != len(page.text_members)
        or page.available_record_counts.native_text_events != len(native.events)
    ):
        return None
    events = {event.source_event_id: event for event in native.events}
    if (
        len(events) != len(native.events)
        or {event.native_event_ordinal for event in native.events}
        != set(range(len(native.events)))
        or any(
            event.source_sha256 != source_sha256
            or event.page_number != page.page_number
            for event in native.events
        )
    ):
        return None
    members: dict[str, list[PdfLocalTextMember]] = {}
    seen_member_ids: set[str] = set()
    native_ordinals: set[int] = set()
    for member in page.text_members:
        event_id = member.native_text_event_id
        native_ordinal = member.native_character_ordinal
        if (
            event_id not in events
            or member.member_id in seen_member_ids
            or native_ordinal is None
            or native_ordinal in native_ordinals
        ):
            return None
        seen_member_ids.add(member.member_id)
        native_ordinals.add(native_ordinal)
        members.setdefault(event_id, []).append(member)
    if set(members) != set(events) or native_ordinals != set(
        range(len(page.text_members))
    ):
        return None
    return _NativeProjectionPool(
        events,
        {event_id: tuple(group) for event_id, group in members.items()},
    )


def _simple_source_line(drawing: PdfLocalDrawingEvidence) -> bool:
    """Reject a path bbox if it could conceal more than one actual segment."""
    if (
        drawing.path_segment_count != _SIMPLE_LINE_PATH_SEGMENTS
        or drawing.path_segment_count_is_lower_bound
        or len(drawing.path_segments) != _SIMPLE_LINE_PATH_SEGMENTS
    ):
        return False
    move, line = drawing.path_segments
    if (
        move.kind != "move"
        or line.kind != "line"
        or move.geometry_quality != "precise"
        or line.geometry_quality != "precise"
        or move.warnings
        or line.warnings
        or line.start != move.end
    ):
        return False
    box = drawing.bbox
    return (
        min(line.start[0], line.end[0]) == box.x0
        and max(line.start[0], line.end[0]) == box.x1
        and min(line.start[1], line.end[1]) == box.y0
        and max(line.start[1], line.end[1]) == box.y1
    )


def _source_strokes(
    canonical: CanonicalPage, page: PdfLocalPageEvidenceV3
) -> tuple[_Stroke, ...]:
    """Require each retained path to match its Canonical drawing source Fact."""
    canonical_by_source = {
        drawing.source_drawing_id: drawing for drawing in canonical.drawings
    }
    eligible = {
        drawing.fact_id
        for drawing in page.drawings
        if _simple_source_line(drawing)
        and (match := canonical_by_source.get(drawing.fact_id)) is not None
        and match.kind == drawing.kind
        and match.path_geometry_complete
        and (match.bbox.x0, match.bbox.y0, match.bbox.x1, match.bbox.y1)
        == (
            drawing.bbox.x0,
            drawing.bbox.y0,
            drawing.bbox.x1,
            drawing.bbox.y1,
        )
    }
    support = _overflow_strokes(page)
    return tuple(
        _Stroke("ROW" if axis == "ROW" else "COLUMN", coordinate, start, end, fact_id)
        for (axis, coordinate), intervals in sorted(support.items())
        for start, end, fact_id in intervals
        if fact_id in eligible and axis in {"ROW", "COLUMN"}
    )


def _components(strokes: tuple[_Stroke, ...]) -> tuple[tuple[_Stroke, ...], ...]:
    """Keep distinct physical grids separate without inferring missing rules."""
    parent = list(range(len(strokes)))

    def root(index: int) -> int:
        while parent[index] != index:
            parent[index] = parent[parent[index]]
            index = parent[index]
        return index

    for left_index, left in enumerate(strokes):
        if left.axis != "ROW":
            continue
        for right_index, right in enumerate(strokes):
            if (
                right.axis == "COLUMN"
                and left.start <= right.coordinate <= left.end
                and right.start <= left.coordinate <= right.end
            ):
                parent[root(right_index)] = root(left_index)
    groups: dict[int, list[_Stroke]] = {}
    for index, stroke in enumerate(strokes):
        groups.setdefault(root(index), []).append(stroke)
    return tuple(tuple(group) for _, group in sorted(groups.items()))


def _covers_axis(
    strokes: tuple[_Stroke, ...],
    axis: Literal["ROW", "COLUMN"],
    coordinate: float,
    low: float,
    high: float,
) -> bool:
    """Every boundary needs continuous observed ink-path support, without gaps."""
    cursor = low
    intervals = sorted(
        (stroke.start, stroke.end)
        for stroke in strokes
        if stroke.axis == axis and stroke.coordinate == coordinate
    )
    for start, end in intervals:
        if end <= cursor:
            continue
        if start > cursor:
            return False
        cursor = end
        if cursor >= high:
            return True
    return False


def _closed_axes(
    strokes: tuple[_Stroke, ...], page: PdfLocalPageEvidenceV3
) -> tuple[tuple[float, ...], tuple[float, ...]] | None:
    rows = tuple(sorted({item.coordinate for item in strokes if item.axis == "ROW"}))
    columns = tuple(
        sorted({item.coordinate for item in strokes if item.axis == "COLUMN"})
    )
    if (
        len(rows) < _MINIMUM_AXES
        or len(columns) < _MINIMUM_AXES
        or rows[0] < 0
        or columns[0] < 0
        or rows[-1] > page.height_points
        or columns[-1] > page.width_points
        or any(
            not _covers_axis(strokes, "ROW", coordinate, columns[0], columns[-1])
            for coordinate in rows
        )
        or any(
            not _covers_axis(strokes, "COLUMN", coordinate, rows[0], rows[-1])
            for coordinate in columns
        )
    ):
        return None
    return rows, columns


def _intersects(
    member: PdfLocalTextMember,
    rows: tuple[float, ...],
    columns: tuple[float, ...],
) -> bool:
    box = member.bbox
    return box is not None and (
        min(box.x1, columns[-1]) > max(box.x0, columns[0])
        and min(box.y1, rows[-1]) > max(box.y0, rows[0])
    )


def _crosses_grid(
    member: PdfLocalTextMember, rows: tuple[float, ...], columns: tuple[float, ...]
) -> bool:
    """Mirror strict member containment, never absorb crossings by tolerance."""
    box = member.bbox
    if box is None:
        return False
    row = bisect_right(rows, box.y0) - 1
    column = bisect_right(columns, box.x0) - 1
    return not (
        0 <= row < len(rows) - 1
        and 0 <= column < len(columns) - 1
        and columns[column] <= box.x0 <= box.x1 <= columns[column + 1]
        and rows[row] <= box.y0 <= box.y1 <= rows[row + 1]
    )


def _ordered_event_members(
    event: PdfNativeTextShowEvent,
    group: tuple[PdfLocalTextMember, ...],
) -> tuple[PdfLocalTextMember, ...] | None:
    """Require a complete contiguous decoded character stream for one event."""
    if (
        event.completeness != "COMPLETE"
        or event.limitation_codes
        or event.operator != "Tj"
        or event.operand_count != 1
        or event.string_segment_count != 1
        or event.numeric_adjustment_count != 0
        or event.source_member_count != len(group)
        or event.retained_member_count != len(group)
        or not group
        or len(group) > _MAX_PROJECTED_EVENT_MEMBERS
        or sum(len(member.text) for member in group) > _MAX_PROJECTED_TEXT_LENGTH
    ):
        return None
    ordered = tuple(
        sorted(
            group,
            key=lambda member: (
                member.native_text_event_member_ordinal
                if member.native_text_event_member_ordinal is not None
                else -1
            ),
        )
    )
    if tuple(member.native_text_event_member_ordinal for member in ordered) != tuple(
        range(len(group))
    ):
        return None
    if any(
        member.native_text_event_id != event.source_event_id
        or member.native_text_event_ordinal != event.native_event_ordinal
        or member.selection_state != "RETAINED"
        or member.duplicate_of_member_id is not None
        or member.geometry_status != "INSIDE"
        or member.bbox is None
        or member.warnings
        or member.rotation != 0
        or member.source_writing_mode != "HORIZONTAL"
        or member.parser_advance is None
        or member.parser_advance <= 0
        or member.parser_text_matrix is None
        or member.parser_text_matrix[:4] != (1, 0, 0, 1)
        or member.native_character_ordinal is None
        for member in ordered
    ) or any(
        left.native_character_ordinal is None
        or right.native_character_ordinal != left.native_character_ordinal + 1
        or right.source_character_index != left.source_character_index + 1
        for left, right in pairwise(ordered)
    ):
        return None
    return ordered


def _first_native_anchor(
    page: PdfLocalPageEvidenceV3,
    group: tuple[PdfLocalTextMember, ...],
) -> tuple[float, float] | None:
    """Read the actual first emission matrix, never a bbox-derived centre."""
    first = next(
        (member for member in group if member.native_text_event_member_ordinal == 0),
        None,
    )
    if first is None or first.parser_text_matrix is None:
        return None
    matrix = first.parser_text_matrix
    media = page.media_box_points
    effective = page.effective_page_box_points
    try:
        return pdfminer_native_origin_to_canonical(
            parser_origin=(matrix[4], matrix[5]),
            media_box=(media.x0, media.y0, media.x1, media.y1),
            effective_box=(effective.x0, effective.y0, effective.x1, effective.y1),
            page_rotation=page.rotation,
            user_unit=page.user_unit,
        )
    except ValueError:
        return None


def _event_anchor_projection(
    page: PdfLocalPageEvidenceV3,
    source_sha256: str,
    event: PdfNativeTextShowEvent,
    group: tuple[PdfLocalTextMember, ...],
    axes: tuple[tuple[float, ...], tuple[float, ...]],
) -> tuple[tuple[int, int], NativeAnchorTextProjection] | None:
    """Bind decoded event text to its first native position, not glyph extents."""
    if event.source_sha256 != source_sha256 or event.page_number != page.page_number:
        return None
    ordered = _ordered_event_members(event, group)
    if ordered is None:
        return None
    origin = _first_native_anchor(page, ordered)
    if origin is None:
        return None
    x, y = origin
    rows, columns = axes
    row = bisect_right(rows, y) - 1
    column = bisect_right(columns, x) - 1
    if (
        not 0 <= row < len(rows) - 1
        or not 0 <= column < len(columns) - 1
        or not rows[row] < y < rows[row + 1]
        or not columns[column] < x < columns[column + 1]
    ):
        return None
    return (row, column), NativeAnchorTextProjection(
        source_event_id=event.source_event_id,
        native_event_ordinal=event.native_event_ordinal,
        event_member_ids=tuple(member.member_id for member in ordered),
        anchor_x=x,
        anchor_y=y,
        text="".join(member.text for member in ordered),
    )


def _projected_cell_text(
    page: PdfLocalPageEvidenceV3,
    source_sha256: str,
    pool: _NativeProjectionPool | None,
    event_ids: tuple[str, ...],
    axes: tuple[tuple[float, ...], tuple[float, ...]],
) -> dict[tuple[int, int], NativeAnchorTextProjection] | None:
    """Project only a complete bijection; all uncertain cells remain null."""
    rows, columns = axes
    cell_count = (len(rows) - 1) * (len(columns) - 1)
    if pool is None or len(event_ids) != cell_count:
        return None
    selected = set(event_ids)
    for event_id, group in pool.members.items():
        if event_id in selected:
            continue
        origin = _first_native_anchor(page, group)
        if origin is None:
            return None
        x, y = origin
        if columns[0] <= x <= columns[-1] and rows[0] <= y <= rows[-1]:
            return None
    projected: dict[tuple[int, int], NativeAnchorTextProjection] = {}
    for event_id in event_ids:
        event = pool.events.get(event_id)
        if event is None:
            return None
        result = _event_anchor_projection(
            page, source_sha256, event, pool.members.get(event_id, ()), axes
        )
        if result is None or result[0] in projected:
            return None
        projected[result[0]] = result[1]
    return projected if len(projected) == cell_count else None


def _candidate_from_component(
    canonical: CanonicalPage,
    page: PdfLocalPageEvidenceV3,
    source_sha256: str,
    strokes: tuple[_Stroke, ...],
    projection_pool: _NativeProjectionPool | None,
) -> SupplementalTableCandidate | None:
    axes = _closed_axes(strokes, page)
    if axes is None:
        return None
    rows, columns = axes
    members = tuple(
        member
        for member in page.text_members
        if member.selection_state == "RETAINED" and _intersects(member, rows, columns)
    )
    event_evidence = page.native_text_event_evidence
    if (
        event_evidence is None
        or not members
        or not any(_crosses_grid(member, rows, columns) for member in members)
    ):
        return None
    event_ids = {event.source_event_id for event in event_evidence.events}
    if any(
        member.native_text_event_id is None
        or member.native_text_event_id not in event_ids
        for member in members
    ):
        return None
    selected_event_ids = tuple(
        sorted(
            {
                member.native_text_event_id
                for member in members
                if member.native_text_event_id is not None
            }
        )
    )
    projections = _projected_cell_text(
        page, source_sha256, projection_pool, selected_event_ids, axes
    )
    return build_supplemental_candidate(
        source_sha256=source_sha256,
        page_id=canonical.page_id,
        page_number=page.page_number,
        row_coordinates=rows,
        column_coordinates=columns,
        source_drawing_fact_ids=tuple(sorted({item.fact_id for item in strokes})),
        unassigned_member_ids=tuple(sorted({item.member_id for item in members})),
        unassigned_native_event_ids=selected_event_ids,
        cell_text_projections=projections,
    )


def supplemental_ruled_candidates(
    canonical: CanonicalDocument, evidence: PdfLocalEvidenceV3
) -> tuple[SupplementalTableCandidate, ...]:
    """Expose verified ruled structure after the legacy producer lost ownership."""
    evidence_by_page = {page.page_number: page for page in evidence.pages}
    found: list[SupplementalTableCandidate] = []
    for canonical_page in canonical.pages:
        page = evidence_by_page.get(canonical_page.page_number)
        if (
            page is None
            or canonical_page.source_page_id != page.source_page_id
            or canonical_page.table_ids
            or canonical_page.page_table_outcome != "AMBIGUOUS"
            or "table_member_crosses_physical_separator"
            not in canonical_page.page_table_availability.reason_codes
            or page.projection_truncated
            or page.source_group_truncated
            or page.source_member_inventory_status != "COMPLETE"
            or page.native_text_event_capture_status != "COMPLETE"
            or page.native_text_event_evidence is None
            or page.native_text_event_evidence.truncated
        ):
            continue
        strokes = _source_strokes(canonical_page, page)
        if len(strokes) > _MAX_PAGE_STROKES:
            continue
        projection_pool = _native_projection_pool(page, evidence.source_sha256)
        for component in _components(strokes):
            if len(component) > _MAX_GRID_COMPONENT_STROKES:
                continue
            candidate = _candidate_from_component(
                canonical_page,
                page,
                evidence.source_sha256,
                component,
                projection_pool,
            )
            if candidate is not None:
                found.append(candidate)
    return tuple(
        sorted(
            found,
            key=lambda item: (
                item.page_number,
                item.row_coordinates[0],
                item.column_coordinates[0],
                item.candidate_id,
            ),
        )
    )

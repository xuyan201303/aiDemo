# ruff: noqa: BLE001, C901, E501, E741, PLR0911, PLR0912, PLR0913, PLR0915, PLR2004

import math
from dataclasses import dataclass
from importlib.metadata import version
from io import BytesIO
from time import perf_counter
from typing import Any, Literal

from pypdf import PdfReader
from pypdf.errors import PyPdfError

from document_sdk.pdf._structural_engine.facts.capabilities import PdfParserCapabilities
from document_sdk.pdf._structural_engine.facts.contracts import (
    PDF_DRAWING_PATH_GEOMETRY_VERSION,
    PdfDrawingBBoxQuality,
    PdfDrawingBBoxSemantics,
    PdfDrawingFact,
    PdfDrawingKind,
    PdfDrawingPathSegment,
    PdfFactArtifact,
    PdfPageFacts,
    PdfPaintOperation,
    PdfScalarProvenance,
    PdfTextFact,
)
from document_sdk.pdf._structural_engine.facts.coordinates import (
    PdfSourceCoordinateSpace,
    PdfTextRotationSource,
    canonical_affine_scale_components,
    canonical_page_geometry,
    canonical_text_rotation,
    coordinate_transform_provenance,
    effective_affine_scalar_components,
    fact_bbox_dimension_warning,
    normalize_bbox,
    normalize_point,
    normalize_scalar_length,
    source_affine_transform,
)
from document_sdk.pdf._structural_engine.facts.identifiers import (
    fact_identifier,
    page_identifier,
    source_sha256,
)
from document_sdk.pdf._structural_engine.facts.limits import (
    PdfExtractionLimits,
    PdfExtractionOptions,
    PdfSource,
)
from document_sdk.pdf._structural_engine.facts.normalization import (
    build_size_limited_artifact,
    make_warning,
    source_preflight_warning,
    terminal_artifact,
)
from document_sdk.pdf._structural_engine.facts.status import (
    PdfExtractionStatus,
    PdfFactWarning,
    PdfWarningCode,
    PdfWarningSeverity,
)
from document_sdk.pdf._structural_engine.parsers.common import (
    PdfParserExtractionState,
    add_fact_warning,
    add_page_warning,
    add_requested_capability_warnings,
    normalized_page_rotation,
    resolve_extraction_scope,
)


@dataclass(frozen=True)
class _RawPathSegment:
    kind: Literal[
        "move",
        "line",
        "cubic_bezier",
        "quadratic_or_unknown_curve",
        "close",
    ]
    start: tuple[float, float]
    end: tuple[float, float]
    control_points: tuple[tuple[float, float], ...] = ()
    subpath_index: int = 0
    closed: bool = False


@dataclass(frozen=True)
class _PendingPathDrawing:
    kind: Literal["line", "rectangle", "curve"]
    raw_bbox: tuple[float, float, float, float]
    bbox_quality: Literal["precise", "approximate"]
    segments: tuple[_RawPathSegment, ...]
    path_closed: bool = False


class PyPdfFactExtractor:
    parser_name = "pypdf"

    @property
    def parser_version(self) -> str:
        return version("pypdf")

    def capabilities(self) -> PdfParserCapabilities:
        return PdfParserCapabilities(
            page_geometry=True,
            text_spans=True,
            words=False,
            line_candidates=False,
            optional_characters=False,
            font_name=True,
            font_size=True,
            text_rotation=True,
            writing_direction=False,
            drawings=True,
            drawing_lines=True,
            drawing_rectangles=True,
            drawing_curves=True,
            image_regions=False,
            text_bbox_quality="anchor",
            native_engine=False,
            text_affine_transform=True,
            effective_font_size=True,
            nominal_stroke_width=True,
            drawing_affine_transform=True,
            drawing_paint_operation=True,
            drawing_path_segments=True,
            character_rotation=False,
            drawing_bbox_quality="approximate",
            graphics_state_fidelity="partial",
            selected_page_extraction=True,
        )

    def extract(
        self,
        source: PdfSource,
        *,
        limits: PdfExtractionLimits,
        options: PdfExtractionOptions,
    ) -> PdfFactArtifact:
        started_at = perf_counter()
        preflight = source_preflight_warning(
            source=source,
            parser_name=self.parser_name,
            limits=limits,
        )
        if preflight is not None:
            status, warning = preflight
            return terminal_artifact(
                source=source,
                parser_name=self.parser_name,
                parser_version=self.parser_version,
                capabilities=self.capabilities(),
                limits=limits,
                options=options,
                status=status,
                warning=warning,
                started_at=started_at,
            )

        try:
            reader = PdfReader(BytesIO(source.content), strict=False)
            if reader.is_encrypted:
                return terminal_artifact(
                    source=source,
                    parser_name=self.parser_name,
                    parser_version=self.parser_version,
                    capabilities=self.capabilities(),
                    limits=limits,
                    options=options,
                    status=PdfExtractionStatus.ENCRYPTED,
                    warning=make_warning(
                        code=PdfWarningCode.ENCRYPTED_DOCUMENT,
                        parser_name=self.parser_name,
                        message="Encrypted PDFs are outside the Phase 1A extraction boundary.",
                        severity=PdfWarningSeverity.ERROR,
                        recoverable=False,
                    ),
                    started_at=started_at,
                )
            page_count = len(reader.pages)
        except (PyPdfError, OSError, ValueError, TypeError, KeyError) as error:
            return self._parser_failure(
                source=source,
                limits=limits,
                options=options,
                started_at=started_at,
                error=error,
            )
        except Exception as error:
            return self._unexpected_parser_failure(
                source=source,
                limits=limits,
                options=options,
                started_at=started_at,
                error=error,
            )

        state = PdfParserExtractionState(
            parser_name=self.parser_name,
            limits=limits,
            started_at=started_at,
        )
        add_requested_capability_warnings(
            state=state,
            capabilities=self.capabilities(),
            options=options,
        )
        pages: list[PdfPageFacts] = []
        resolved_scope = resolve_extraction_scope(
            page_count=page_count,
            options=options,
            state=state,
        )
        if resolved_scope.invalid:
            return build_size_limited_artifact(
                source=source,
                parser_name=self.parser_name,
                parser_version=self.parser_version,
                capabilities=self.capabilities(),
                limits=limits,
                options=options,
                status=PdfExtractionStatus.INVALID_REQUEST,
                page_count=page_count,
                pages=[],
                warnings=state.warnings.final_items(),
                warning_suppression=state.warnings.suppression_summary(),
                started_at=started_at,
                pages_attempted=0,
                partial_extraction=False,
            )

        source_hash = source_sha256(source.content)
        for page_number in resolved_scope.page_numbers:
            if state.timed_out():
                break
            state.pages_attempted += 1
            page_index = page_number - 1
            try:
                page = reader.pages[page_index]
                content = page.get_contents()
                if content is not None:
                    content_size = len(content.get_data())
                    if content_size > limits.max_page_content_stream_bytes:
                        state.resource_limited = True
                        state.warnings.add_fields(
                            code=PdfWarningCode.CONTENT_STREAM_TOO_LARGE,
                            message="A PDF page content stream exceeded the configured limit.",
                            page_number=page_number,
                            recoverable=False,
                        )
                        break
                page_facts = self._extract_page(
                    page=page,
                    page_number=page_number,
                    source_hash=source_hash,
                    limits=limits,
                    options=options,
                    state=state,
                )
            except (
                PyPdfError,
                OSError,
                ValueError,
                TypeError,
                KeyError,
                AttributeError,
            ):
                state.page_failed = True
                state.warnings.add_fields(
                    code=PdfWarningCode.PARTIAL_PAGE_FAILURE,
                    message="A PDF page could not be converted into canonical facts.",
                    page_number=page_number,
                )
                continue
            if not state.add_page(page_facts, pages):
                break

        status, partial = state.status(
            pages=pages,
            requested_page_numbers=resolved_scope.page_numbers,
        )
        if status is PdfExtractionStatus.NO_TEXT_LAYER:
            state.warnings.add_fields(
                code=PdfWarningCode.NO_TEXT_LAYER,
                message="No extractable electronic text layer was found.",
                recoverable=False,
            )
        return build_size_limited_artifact(
            source=source,
            parser_name=self.parser_name,
            parser_version=self.parser_version,
            capabilities=self.capabilities(),
            limits=limits,
            options=options,
            status=status,
            page_count=page_count,
            pages=pages,
            warnings=state.warnings.final_items(),
            warning_suppression=state.warnings.suppression_summary(),
            started_at=started_at,
            pages_attempted=state.pages_attempted,
            partial_extraction=partial,
        )

    def _extract_page(
        self,
        *,
        page: Any,
        page_number: int,
        source_hash: str,
        limits: PdfExtractionLimits,
        options: PdfExtractionOptions,
        state: PdfParserExtractionState,
    ) -> PdfPageFacts:
        page_warnings: list[PdfFactWarning] = []
        page_partial = False
        rotation, rotation_valid = normalized_page_rotation(page.get("/Rotate", 0))
        if not rotation_valid:
            page_partial = True
            add_page_warning(
                state=state,
                page_warnings=page_warnings,
                code=PdfWarningCode.UNSUPPORTED_ROTATION,
                message="A PDF page declared an unsupported rotation.",
                page_number=page_number,
            )
        geometry = canonical_page_geometry(
            media_box=tuple(  # type: ignore[arg-type]
                float(value) for value in page.mediabox
            ),
            crop_box=tuple(  # type: ignore[arg-type]
                float(value) for value in page.cropbox
            ),
            page_rotation=rotation,
            user_unit=float(page.get("/UserUnit", 1)),
        )
        page_id = page_identifier(
            source_hash=source_hash,
            parser_name=self.parser_name,
            parser_version=self.parser_version,
            page_number=page_number,
        )
        text_spans: list[PdfTextFact] = []
        drawings: list[PdfDrawingFact] = []
        source_order = 0
        text_limit_reached = False
        drawing_limit_reached = False
        current_path_point: tuple[float, float] | None = None
        current_subpath_start: tuple[float, float] | None = None
        current_subpath_index = -1
        current_stroke_width = 1.0
        graphics_state_stack: list[float] = []
        pending_path: list[_PendingPathDrawing] = []
        pending_clip = False
        retained_path_segment_count = 0
        path_segment_limit_reached = False

        def next_order() -> int:
            nonlocal source_order
            value = source_order
            source_order += 1
            return value

        def visitor_text(
            text: str,
            cm: list[float],
            tm: list[float],
            font_dict: dict[str, Any] | None,
            font_size: float,
        ) -> None:
            nonlocal text_limit_reached, page_partial
            if not text or not text.strip():
                return
            if len(text_spans) >= limits.max_text_facts_per_page:
                text_limit_reached = True
                return
            matrix = _multiply_pdf_matrices(tm, cm)
            x = float(matrix[4])
            y = float(matrix[5])
            normalized = normalize_bbox(
                bbox=(x, y, x, y),
                original_width=geometry.original_width,
                original_height=geometry.original_height,
                page_rotation=rotation,
                source_space=PdfSourceCoordinateSpace.BOTTOM_LEFT_Y_UP_UNROTATED,
                source_origin_x=geometry.source_effective_box[0],
                source_origin_y=geometry.source_effective_box[1],
                user_unit=geometry.user_unit,
            )
            if normalized.bbox is None or normalized.normalized_bbox is None:
                page_partial = True
                add_page_warning(
                    state=state,
                    page_warnings=page_warnings,
                    code=PdfWarningCode.INVALID_BBOX,
                    message="A parser-provided text anchor was outside page bounds.",
                    page_number=page_number,
                )
                return
            order = next_order()
            fact_id = fact_identifier(
                source_hash=source_hash,
                parser_name=self.parser_name,
                parser_version=self.parser_version,
                page_number=page_number,
                fact_type="text_span",
                source_order=order,
                bbox=normalized.bbox,
                text=text,
            )
            raw_font_size = max(float(font_size), 0.0)
            effective_font_size = effective_affine_scalar_components(
                raw_font_size,
                matrix,
                user_unit=geometry.user_unit,
            )
            effective_font_scale = canonical_affine_scale_components(
                matrix,
                user_unit=geometry.user_unit,
            )
            text_spans.append(
                PdfTextFact(
                    fact_id=fact_id,
                    page_id=page_id,
                    granularity="text_span",
                    text=text,
                    bbox=normalized.bbox,
                    normalized_bbox=normalized.normalized_bbox,
                    source_order=order,
                    font_name=_pypdf_font_name(font_dict),
                    font_size=normalize_scalar_length(
                        raw_font_size,
                        user_unit=geometry.user_unit,
                    ),
                    effective_font_scale_x=(
                        effective_font_scale[0]
                        if effective_font_scale is not None
                        else None
                    ),
                    effective_font_scale_y=(
                        effective_font_scale[1]
                        if effective_font_scale is not None
                        else None
                    ),
                    effective_font_size_x=(
                        effective_font_size[0]
                        if effective_font_size is not None
                        else None
                    ),
                    effective_font_size_y=(
                        effective_font_size[1]
                        if effective_font_size is not None
                        else None
                    ),
                    text_transform=source_affine_transform(matrix),
                    font_size_provenance=PdfScalarProvenance(
                        parser_native_value=raw_font_size,
                        parser_native_semantics="nominal",
                        parser_native_unit="pdf_user_space",
                        canonical_derivation="affine_derived",
                        parser_applies_user_unit=False,
                        affine_transform_available=True,
                        source="pypdf_text_state_and_visitor_matrix",
                    ),
                    rotation=canonical_text_rotation(
                        text_rotation=_matrix_rotation(matrix),
                        page_rotation=rotation,
                        source=PdfTextRotationSource.PDF_USER_SPACE_COUNTERCLOCKWISE,
                    ),
                    writing_direction="unknown",
                    parser_metadata={
                        "bbox_basis": "text_anchor",
                        "raw_font_size": raw_font_size,
                        "raw_scalar_unit": "pdf_user_space",
                    },
                    warnings=[],
                )
            )

        def visitor_operand_before(
            operator: bytes,
            operands: list[Any],
            cm: list[float],
            _tm: list[float],
        ) -> None:
            nonlocal current_path_point, current_subpath_start, current_subpath_index
            nonlocal current_stroke_width, pending_clip
            nonlocal drawing_limit_reached, page_partial, pending_path
            if not options.include_drawings:
                return
            try:
                if operator == b"q":
                    graphics_state_stack.append(current_stroke_width)
                    return
                if operator == b"Q":
                    if graphics_state_stack:
                        current_stroke_width = graphics_state_stack.pop()
                    return
                if operator == b"w" and operands:
                    current_stroke_width = max(float(operands[0]), 0.0)
                    return
                if operator == b"m" and len(operands) >= 2:
                    current_subpath_index += 1
                    current_path_point = _transform_point(
                        float(operands[0]),
                        float(operands[1]),
                        cm,
                    )
                    current_subpath_start = current_path_point
                    return
                if operator == b"l" and len(operands) >= 2 and current_path_point:
                    endpoint = _transform_point(
                        float(operands[0]),
                        float(operands[1]),
                        cm,
                    )
                    raw_bbox = (*current_path_point, *endpoint)
                    segment = _RawPathSegment(
                        kind="line",
                        start=current_path_point,
                        end=endpoint,
                        subpath_index=max(current_subpath_index, 0),
                    )
                    current_path_point = endpoint
                    pending_path.append(
                        _PendingPathDrawing(
                            kind="line",
                            raw_bbox=raw_bbox,
                            bbox_quality="precise",
                            segments=(segment,),
                        )
                    )
                    return
                if operator == b"re" and len(operands) >= 4:
                    x, y, width, height = (float(item) for item in operands[:4])
                    current_subpath_index += 1
                    corners = (
                        _transform_point(x, y, cm),
                        _transform_point(x + width, y, cm),
                        _transform_point(x + width, y + height, cm),
                        _transform_point(x, y + height, cm),
                    )
                    xs = [point[0] for point in corners]
                    ys = [point[1] for point in corners]
                    pending_path.append(
                        _PendingPathDrawing(
                            kind="rectangle",
                            raw_bbox=(min(xs), min(ys), max(xs), max(ys)),
                            bbox_quality="precise",
                            segments=tuple(
                                _RawPathSegment(
                                    kind="line",
                                    start=corners[index],
                                    end=corners[(index + 1) % 4],
                                    subpath_index=current_subpath_index,
                                    closed=index == 3,
                                )
                                for index in range(4)
                            ),
                            path_closed=True,
                        )
                    )
                    current_path_point = corners[0]
                    current_subpath_start = corners[0]
                    return
                if operator in {b"c", b"v", b"y"} and len(operands) >= 4:
                    operand_points = [
                        _transform_point(
                            float(operands[index]), float(operands[index + 1]), cm
                        )
                        for index in range(0, len(operands) - 1, 2)
                    ]
                    if current_path_point is not None and operand_points:
                        if operator == b"c" and len(operand_points) >= 3:
                            control_points = tuple(operand_points[:2])
                            endpoint = operand_points[2]
                        elif operator == b"v" and len(operand_points) >= 2:
                            control_points = (current_path_point, operand_points[0])
                            endpoint = operand_points[1]
                        else:
                            endpoint = operand_points[-1]
                            control_points = (operand_points[0], endpoint)
                        points = (current_path_point, *control_points, endpoint)
                        xs = [point[0] for point in points]
                        ys = [point[1] for point in points]
                        pending_path.append(
                            _PendingPathDrawing(
                                kind="curve",
                                raw_bbox=(min(xs), min(ys), max(xs), max(ys)),
                                bbox_quality="approximate",
                                segments=(
                                    _RawPathSegment(
                                        kind="cubic_bezier",
                                        start=current_path_point,
                                        end=endpoint,
                                        control_points=control_points,
                                        subpath_index=max(current_subpath_index, 0),
                                    ),
                                ),
                            )
                        )
                        current_path_point = endpoint
                    return
                if operator == b"h":
                    close_current_subpath()
                    return
                if operator in {b"W", b"W*"}:
                    pending_clip = True
                    return
                paint_operations: dict[bytes, PdfPaintOperation] = {
                    b"S": "stroke",
                    b"s": "stroke",
                    b"f": "fill",
                    b"F": "fill",
                    b"f*": "fill",
                    b"B": "fill_stroke",
                    b"B*": "fill_stroke",
                    b"b": "fill_stroke",
                    b"b*": "fill_stroke",
                }
                paint_operation = paint_operations.get(operator)
                if paint_operation is not None:
                    if operator in {b"s", b"b", b"b*"}:
                        close_current_subpath()
                    emit_pending_path(
                        paint_operation=paint_operation,
                        cm=cm,
                        is_clipping_path=pending_clip,
                    )
                    reset_path()
                    return
                if operator == b"n":
                    if pending_clip:
                        emit_pending_path(
                            paint_operation="clip",
                            cm=cm,
                            is_clipping_path=True,
                        )
                    reset_path()
            except (TypeError, ValueError, IndexError):
                page_partial = True
                add_page_warning(
                    state=state,
                    page_warnings=page_warnings,
                    code=PdfWarningCode.INVALID_BBOX,
                    message="A drawing operand could not be normalized.",
                    page_number=page_number,
                )

        def close_current_subpath() -> None:
            nonlocal current_path_point
            if current_path_point is None or current_subpath_start is None:
                return
            if current_path_point != current_subpath_start:
                pending_path.append(
                    _PendingPathDrawing(
                        kind="line",
                        raw_bbox=(*current_path_point, *current_subpath_start),
                        bbox_quality="precise",
                        segments=(
                            _RawPathSegment(
                                kind="close",
                                start=current_path_point,
                                end=current_subpath_start,
                                subpath_index=max(current_subpath_index, 0),
                                closed=True,
                            ),
                        ),
                        path_closed=True,
                    )
                )
            current_path_point = current_subpath_start

        def reset_path() -> None:
            nonlocal current_path_point, current_subpath_start, current_subpath_index
            nonlocal pending_clip, pending_path
            current_path_point = None
            current_subpath_start = None
            current_subpath_index = -1
            pending_clip = False
            pending_path = []

        def emit_pending_path(
            *,
            paint_operation: PdfPaintOperation,
            cm: list[float],
            is_clipping_path: bool,
        ) -> None:
            nonlocal drawing_limit_reached
            for drawing in pending_path:
                if len(drawings) >= limits.max_drawing_facts_per_page:
                    drawing_limit_reached = True
                    return
                add_drawing(
                    drawing.kind,
                    drawing.raw_bbox,
                    cm,
                    bbox_quality=drawing.bbox_quality,
                    paint_operation=paint_operation,
                    is_clipping_path=is_clipping_path,
                    raw_path_segments=drawing.segments,
                    path_closed=drawing.path_closed,
                )

        def add_drawing(
            kind: PdfDrawingKind,
            raw_bbox: tuple[float, float, float, float],
            cm: list[float],
            *,
            bbox_quality: PdfDrawingBBoxQuality,
            paint_operation: PdfPaintOperation,
            is_clipping_path: bool,
            raw_path_segments: tuple[_RawPathSegment, ...],
            path_closed: bool,
        ) -> None:
            nonlocal page_partial, retained_path_segment_count
            nonlocal path_segment_limit_reached
            normalized = normalize_bbox(
                bbox=(
                    min(raw_bbox[0], raw_bbox[2]),
                    min(raw_bbox[1], raw_bbox[3]),
                    max(raw_bbox[0], raw_bbox[2]),
                    max(raw_bbox[1], raw_bbox[3]),
                ),
                original_width=geometry.original_width,
                original_height=geometry.original_height,
                page_rotation=rotation,
                source_space=PdfSourceCoordinateSpace.BOTTOM_LEFT_Y_UP_UNROTATED,
                source_origin_x=geometry.source_effective_box[0],
                source_origin_y=geometry.source_effective_box[1],
                user_unit=geometry.user_unit,
            )
            if normalized.bbox is None or normalized.normalized_bbox is None:
                page_partial = True
                add_page_warning(
                    state=state,
                    page_warnings=page_warnings,
                    code=PdfWarningCode.INVALID_BBOX,
                    message="A parser-provided drawing box was outside page bounds.",
                    page_number=page_number,
                )
                return
            order = next_order()
            fact_id = fact_identifier(
                source_hash=source_hash,
                parser_name=self.parser_name,
                parser_version=self.parser_version,
                page_number=page_number,
                fact_type=kind,
                source_order=order,
                bbox=normalized.bbox,
            )
            fact_warnings: list[PdfFactWarning] = []
            if (
                fact_bbox_dimension_warning(
                    bbox=normalized.bbox,
                    fact_kind=kind,
                    path_present=True,
                )
                is PdfWarningCode.ZERO_AREA_BBOX
            ):
                add_fact_warning(
                    state=state,
                    fact_warnings=fact_warnings,
                    code=PdfWarningCode.ZERO_AREA_BBOX,
                    message="The parser-provided drawing box has zero area.",
                    page_number=page_number,
                    fact_id=fact_id,
                )
            has_stroke = paint_operation in {"stroke", "fill_stroke"}
            effective_stroke_width = (
                effective_affine_scalar_components(
                    current_stroke_width,
                    cm,
                    user_unit=geometry.user_unit,
                )
                if has_stroke
                else None
            )
            effective_stroke_scale = canonical_affine_scale_components(
                cm,
                user_unit=geometry.user_unit,
            )
            nominal_stroke_width = (
                normalize_scalar_length(
                    current_stroke_width,
                    user_unit=geometry.user_unit,
                )
                if has_stroke
                else None
            )
            retained_budget = min(
                limits.max_path_segments_per_drawing,
                max(
                    limits.max_path_segments_per_page - retained_path_segment_count,
                    0,
                ),
            )
            selected_raw_segments = raw_path_segments[:retained_budget]
            segment_limit_truncated = len(selected_raw_segments) < len(
                raw_path_segments
            )
            if segment_limit_truncated:
                page_partial = True
                path_segment_limit_reached = True
            canonical_segments: list[PdfDrawingPathSegment] = []
            for segment_index, raw_segment in enumerate(selected_raw_segments):
                canonical_segment = _normalize_pypdf_path_segment(
                    raw_segment=raw_segment,
                    segment_index=segment_index,
                    geometry=geometry,
                    rotation=rotation,
                    geometry_quality=bbox_quality,
                )
                if canonical_segment is None:
                    page_partial = True
                    continue
                canonical_segments.append(canonical_segment)
            retained_path_segment_count += len(selected_raw_segments)
            path_geometry_complete = not segment_limit_truncated and len(
                canonical_segments
            ) == len(raw_path_segments)
            drawings.append(
                PdfDrawingFact(
                    fact_id=fact_id,
                    page_id=page_id,
                    kind=kind,
                    bbox=normalized.bbox,
                    normalized_bbox=normalized.normalized_bbox,
                    stroke_width=nominal_stroke_width,
                    effective_stroke_scale_x=effective_stroke_scale[0],  # type: ignore[index]
                    effective_stroke_scale_y=effective_stroke_scale[1],  # type: ignore[index]
                    effective_stroke_width_x=(
                        effective_stroke_width[0]
                        if effective_stroke_width is not None
                        else None
                    ),
                    effective_stroke_width_y=(
                        effective_stroke_width[1]
                        if effective_stroke_width is not None
                        else None
                    ),
                    graphics_transform=source_affine_transform(cm),
                    stroke_width_provenance=PdfScalarProvenance(
                        parser_native_value=(
                            current_stroke_width if has_stroke else None
                        ),
                        parser_native_semantics=(
                            "nominal" if has_stroke else "unavailable"
                        ),
                        parser_native_unit=(
                            "pdf_user_space" if has_stroke else "unknown"
                        ),
                        canonical_derivation=(
                            "affine_derived" if has_stroke else "unavailable"
                        ),
                        parser_applies_user_unit=False,
                        affine_transform_available=True,
                        source=(
                            "pypdf_graphics_state"
                            if has_stroke
                            else "unavailable_for_non_stroked_path"
                        ),
                    ),
                    bbox_semantics=PdfDrawingBBoxSemantics(
                        kind="path_geometry",
                        quality=bbox_quality,
                        stroke_inclusion="excluded",
                        clipping_application="unknown",
                    ),
                    paint_operation=paint_operation,
                    is_clipping_path=is_clipping_path,
                    path_geometry_version=PDF_DRAWING_PATH_GEOMETRY_VERSION,
                    path_segments=canonical_segments,
                    path_segment_count=len(raw_path_segments),
                    path_segment_truncated=segment_limit_truncated,
                    path_closed=path_closed,
                    path_geometry_complete=path_geometry_complete,
                    rotation=canonical_text_rotation(
                        text_rotation=_matrix_rotation(cm),
                        page_rotation=rotation,
                        source=PdfTextRotationSource.PDF_USER_SPACE_COUNTERCLOCKWISE,
                    ),
                    source_order=order,
                    parser_metadata={
                        "operator_family": kind,
                        "raw_stroke_width": (
                            current_stroke_width if has_stroke else None
                        ),
                        "raw_scalar_unit": "pdf_user_space",
                    },
                    warnings=fact_warnings,
                )
            )

        page.extract_text(
            visitor_text=visitor_text,
            visitor_operand_before=visitor_operand_before,
        )
        if drawings:
            add_page_warning(
                state=state,
                page_warnings=page_warnings,
                code=PdfWarningCode.APPROXIMATE_GRAPHICS_STATE,
                message=(
                    "pypdf drawing facts preserve supported path and paint "
                    "operators but do not apply clipping or renderer paint bounds."
                ),
                page_number=page_number,
            )
        if text_spans:
            add_page_warning(
                state=state,
                page_warnings=page_warnings,
                code=PdfWarningCode.APPROXIMATE_BBOX,
                message=(
                    "pypdf text spans use zero-area anchor boxes; precise text "
                    "bounding boxes are unavailable."
                ),
                page_number=page_number,
            )
        page_status = (
            PdfExtractionStatus.PARTIAL if page_partial else PdfExtractionStatus.SUCCESS
        )
        if text_limit_reached:
            page_status = PdfExtractionStatus.PARTIAL
            warning = make_warning(
                code=PdfWarningCode.TEXT_FACT_LIMIT_REACHED,
                parser_name=self.parser_name,
                message="Text facts on this page were truncated by the configured limit.",
                page_number=page_number,
            )
            state.warnings.add_page(warning, target=page_warnings)
        if drawing_limit_reached:
            page_status = PdfExtractionStatus.PARTIAL
            warning = make_warning(
                code=PdfWarningCode.DRAWING_LIMIT_REACHED,
                parser_name=self.parser_name,
                message="Drawing facts on this page were truncated by the configured limit.",
                page_number=page_number,
            )
            state.warnings.add_page(warning, target=page_warnings)
        if path_segment_limit_reached:
            page_status = PdfExtractionStatus.PARTIAL
            warning = make_warning(
                code=PdfWarningCode.PATH_SEGMENT_LIMIT_REACHED,
                parser_name=self.parser_name,
                message="Drawing path segments on this page were truncated by the configured limit.",
                page_number=page_number,
            )
            state.warnings.add_page(warning, target=page_warnings)
        return PdfPageFacts(
            page_id=page_id,
            page_number=page_number,
            media_box=geometry.media_box,
            crop_box=geometry.crop_box,
            effective_page_box=geometry.effective_page_box,
            effective_page_box_basis=geometry.effective_page_box_basis,
            effective_origin_x=geometry.effective_page_box.x0,
            effective_origin_y=geometry.effective_page_box.y0,
            user_unit=geometry.user_unit,
            coordinate_transform=coordinate_transform_provenance(
                parser_coordinate_space="pdf_user_space_absolute",
                parser_page_box_basis="media_box",
                parser_applies_page_rotation=False,
                parser_applies_user_unit=False,
                canonical_page_box_basis=geometry.effective_page_box_basis,
                geometry_source="pypdf_page_dictionary",
            ),
            original_width=geometry.original_width,
            original_height=geometry.original_height,
            rotation=rotation,
            canonical_width=geometry.canonical_width,
            canonical_height=geometry.canonical_height,
            text_spans=text_spans,
            words=[],
            line_candidates=[],
            characters=[],
            drawings=drawings,
            image_regions=[],
            text_span_count=len(text_spans),
            word_count=0,
            line_candidate_count=0,
            character_count=0,
            drawing_count=len(drawings),
            image_region_count=0,
            warnings=page_warnings,
            extraction_status=page_status,
        )

    def _parser_failure(
        self,
        *,
        source: PdfSource,
        limits: PdfExtractionLimits,
        options: PdfExtractionOptions,
        started_at: float,
        error: Exception,
    ) -> PdfFactArtifact:
        del error
        return terminal_artifact(
            source=source,
            parser_name=self.parser_name,
            parser_version=self.parser_version,
            capabilities=self.capabilities(),
            limits=limits,
            options=options,
            status=PdfExtractionStatus.MALFORMED,
            warning=make_warning(
                code=PdfWarningCode.MALFORMED_DOCUMENT,
                parser_name=self.parser_name,
                message="The PDF parser could not open the document.",
                severity=PdfWarningSeverity.ERROR,
                recoverable=False,
            ),
            started_at=started_at,
        )

    def _unexpected_parser_failure(
        self,
        *,
        source: PdfSource,
        limits: PdfExtractionLimits,
        options: PdfExtractionOptions,
        started_at: float,
        error: Exception,
    ) -> PdfFactArtifact:
        del error
        return terminal_artifact(
            source=source,
            parser_name=self.parser_name,
            parser_version=self.parser_version,
            capabilities=self.capabilities(),
            limits=limits,
            options=options,
            status=PdfExtractionStatus.PARSER_ERROR,
            warning=make_warning(
                code=PdfWarningCode.PARSER_EXCEPTION,
                parser_name=self.parser_name,
                message="The PDF parser failed without exposing document content.",
                severity=PdfWarningSeverity.ERROR,
                recoverable=False,
            ),
            started_at=started_at,
        )


def _multiply_pdf_matrices(first: list[float], second: list[float]) -> list[float]:
    a, b, c, d, e, f = (float(value) for value in first)
    g, h, i, j, k, l = (float(value) for value in second)
    return [
        (a * g) + (b * i),
        (a * h) + (b * j),
        (c * g) + (d * i),
        (c * h) + (d * j),
        (e * g) + (f * i) + k,
        (e * h) + (f * j) + l,
    ]


def _transform_point(x: float, y: float, matrix: list[float]) -> tuple[float, float]:
    a, b, c, d, e, f = (float(value) for value in matrix)
    return (x * a) + (y * c) + e, (x * b) + (y * d) + f


def _normalize_pypdf_path_segment(
    *,
    raw_segment: _RawPathSegment,
    segment_index: int,
    geometry: Any,
    rotation: int,
    geometry_quality: PdfDrawingBBoxQuality,
) -> PdfDrawingPathSegment | None:
    normalized_points = [
        normalize_point(
            point=point,
            original_width=geometry.original_width,
            original_height=geometry.original_height,
            page_rotation=rotation,
            source_space=PdfSourceCoordinateSpace.BOTTOM_LEFT_Y_UP_UNROTATED,
            source_origin_x=geometry.source_effective_box[0],
            source_origin_y=geometry.source_effective_box[1],
            user_unit=geometry.user_unit,
        ).point
        for point in (
            raw_segment.start,
            raw_segment.end,
            *raw_segment.control_points,
        )
    ]
    if any(point is None for point in normalized_points):
        return None
    return PdfDrawingPathSegment(
        segment_index=segment_index,
        subpath_index=raw_segment.subpath_index,
        kind=raw_segment.kind,
        start=normalized_points[0],  # type: ignore[arg-type]
        end=normalized_points[1],  # type: ignore[arg-type]
        control_points=normalized_points[2:],  # type: ignore[arg-type]
        closed=raw_segment.closed,
        geometry_quality=(
            "precise" if geometry_quality == "precise" else "approximate"
        ),
        source_order=segment_index,
    )


def _matrix_rotation(matrix: list[float]) -> float:
    return math.degrees(math.atan2(float(matrix[1]), float(matrix[0]))) % 360


def _pypdf_font_name(font_dict: dict[str, Any] | None) -> str | None:
    if not font_dict:
        return None
    value = font_dict.get("/BaseFont")
    if value is None:
        return None
    return str(value).lstrip("/")[:256] or None

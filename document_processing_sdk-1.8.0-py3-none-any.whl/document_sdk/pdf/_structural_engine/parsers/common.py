# ruff: noqa: PLR0913

import math
from dataclasses import dataclass, field
from time import perf_counter
from typing import Literal

from document_sdk.pdf._structural_engine.facts.capabilities import PdfParserCapabilities
from document_sdk.pdf._structural_engine.facts.contracts import PdfPageFacts
from document_sdk.pdf._structural_engine.facts.limits import (
    PdfExtractionLimits,
    PdfExtractionOptions,
    PdfExtractionScopeMode,
)
from document_sdk.pdf._structural_engine.facts.normalization import (
    PdfWarningCollector,
    make_warning,
    page_total_facts,
)
from document_sdk.pdf._structural_engine.facts.status import (
    PdfExtractionStatus,
    PdfFactWarning,
    PdfWarningCode,
)


@dataclass
class PdfParserExtractionState:
    parser_name: str
    limits: PdfExtractionLimits
    started_at: float
    warnings: PdfWarningCollector = field(init=False)
    pages_attempted: int = 0
    total_facts: int = 0
    resource_limited: bool = False
    page_failed: bool = False

    def __post_init__(self) -> None:
        self.warnings = PdfWarningCollector(
            parser_name=self.parser_name,
            limit=self.limits.max_warning_count,
        )

    def timed_out(self) -> bool:
        if perf_counter() - self.started_at <= self.limits.timeout_seconds:
            return False
        if not self.resource_limited:
            self.warnings.add_fields(
                code=PdfWarningCode.EXTRACTION_TIMEOUT,
                message="PDF extraction exceeded the configured cooperative timeout.",
                recoverable=False,
            )
        self.resource_limited = True
        return True

    def add_page(self, page: PdfPageFacts, pages: list[PdfPageFacts]) -> bool:
        page_fact_count = page_total_facts(page)
        if self.total_facts + page_fact_count > self.limits.max_total_facts:
            self.warnings.add_fields(
                code=PdfWarningCode.TOTAL_FACT_LIMIT_REACHED,
                message="PDF extraction reached the configured total-fact limit.",
                page_number=page.page_number,
                recoverable=False,
            )
            self.resource_limited = True
            return False
        pages.append(page)
        self.total_facts += page_fact_count
        return True

    def status(
        self,
        *,
        pages: list[PdfPageFacts],
        requested_page_numbers: tuple[int, ...],
    ) -> tuple[PdfExtractionStatus, bool]:
        if self.resource_limited:
            return PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED, True
        if self.page_failed or any(
            page.extraction_status is PdfExtractionStatus.PARTIAL for page in pages
        ):
            return PdfExtractionStatus.PARTIAL, True
        if not any(
            page.text_span_count
            or page.word_count
            or page.line_candidate_count
            or page.character_count
            for page in pages
        ):
            return PdfExtractionStatus.NO_TEXT_LAYER, False
        if tuple(sorted(page.page_number for page in pages)) != requested_page_numbers:
            return PdfExtractionStatus.PARTIAL, True
        return PdfExtractionStatus.SUCCESS, False


@dataclass(frozen=True)
class PdfResolvedExtractionScope:
    page_numbers: tuple[int, ...]
    invalid: bool = False


def resolve_extraction_scope(
    *,
    page_count: int,
    options: PdfExtractionOptions,
    state: PdfParserExtractionState,
) -> PdfResolvedExtractionScope:
    scope = options.extraction_scope
    if scope.mode is PdfExtractionScopeMode.FULL_DOCUMENT:
        page_numbers = tuple(range(1, min(page_count, state.limits.max_page_count) + 1))
        if page_count > state.limits.max_page_count:
            state.resource_limited = True
            state.warnings.add_fields(
                code=PdfWarningCode.PAGE_LIMIT_REACHED,
                message="PDF extraction stopped at the configured page-count limit.",
                recoverable=False,
            )
        return PdfResolvedExtractionScope(page_numbers=page_numbers)

    requested = scope.requested_page_numbers
    if len(requested) > state.limits.max_selected_page_count:
        state.warnings.add_fields(
            code=PdfWarningCode.SELECTED_PAGE_LIMIT_REACHED,
            message="Selected-page extraction exceeded its requested-page limit.",
            recoverable=False,
        )
        return PdfResolvedExtractionScope(page_numbers=(), invalid=True)
    if any(page_number > page_count for page_number in requested):
        state.warnings.add_fields(
            code=PdfWarningCode.INVALID_EXTRACTION_SCOPE,
            message="Selected-page extraction requested a page outside the document.",
            recoverable=False,
        )
        return PdfResolvedExtractionScope(page_numbers=(), invalid=True)
    return PdfResolvedExtractionScope(page_numbers=requested)


def normalized_page_rotation(
    value: object,
) -> tuple[Literal[0, 90, 180, 270], bool]:
    try:
        numeric = float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return 0, False
    if not math.isfinite(numeric):
        return 0, False
    normalized = int(numeric) % 360
    if normalized not in (0, 90, 180, 270) or not math.isclose(
        numeric % 360,
        normalized,
        abs_tol=1e-6,
    ):
        return 0, False
    return normalized, True  # type: ignore[return-value]


def add_requested_capability_warnings(
    *,
    state: PdfParserExtractionState,
    capabilities: PdfParserCapabilities,
    options: PdfExtractionOptions,
) -> None:
    requested = (
        (
            options.include_text_members,
            capabilities.text_members,
            "source text members",
        ),
        (
            options.include_characters,
            capabilities.optional_characters,
            "character facts",
        ),
        (options.include_drawings, capabilities.drawings, "drawing facts"),
        (
            options.include_image_regions,
            capabilities.image_regions,
            "image-region facts",
        ),
    )
    for enabled, available, label in requested:
        if enabled and not available:
            state.warnings.add_fields(
                code=PdfWarningCode.PARSER_CAPABILITY_UNAVAILABLE,
                message=f"The selected parser cannot provide requested {label}.",
            )


def add_page_warning(
    *,
    state: PdfParserExtractionState,
    page_warnings: list[PdfFactWarning],
    code: PdfWarningCode,
    message: str,
    page_number: int,
    recoverable: bool = True,
) -> PdfFactWarning:
    warning = make_warning(
        code=code,
        parser_name=state.parser_name,
        message=message,
        page_number=page_number,
        recoverable=recoverable,
    )
    state.warnings.add_page(warning, target=page_warnings)
    return warning


def add_fact_warning(
    *,
    state: PdfParserExtractionState,
    fact_warnings: list[PdfFactWarning],
    code: PdfWarningCode,
    message: str,
    page_number: int,
    fact_id: str,
    recoverable: bool = True,
) -> PdfFactWarning:
    warning = make_warning(
        code=code,
        parser_name=state.parser_name,
        message=message,
        page_number=page_number,
        fact_id=fact_id,
        recoverable=recoverable,
    )
    state.warnings.add_fact(warning, target=fact_warnings)
    return warning

"""Recover a uniquely bounded font dictionary at its original xref offset."""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from io import BytesIO
from typing import TYPE_CHECKING, Any

from pdfminer.pdfexceptions import PDFException
from pdfminer.pdfparser import PDFParser
from pdfminer.pdftypes import PDFObjRef
from pdfminer.psexceptions import PSEOF, PSException, PSSyntaxError
from pdfminer.psparser import KWD, PSKeyword, PSLiteral, literal_name

if TYPE_CHECKING:
    from pdfminer.pdfdocument import PDFDocument
    from pdfminer.pdftypes import PDFStream
    from pdfminer.psparser import PSStackType

_MAXIMUM_DICTIONARY_BYTES = 65_536
_MAXIMUM_XREF_OBJECTS = 65_536


@dataclass(frozen=True)
class FontResourceRecovery:
    """Original input and exact object-range binding for recovered font metrics."""

    dictionary: dict[str, Any]
    source_sha256: str
    object_number: int
    generation: int
    byte_start: int
    byte_end: int
    dictionary_sha256: str
    reason: str = "MISSING_ENDOBJ_COMPLETE_FONT_DICTIONARY"


class _SourceReference(PDFObjRef):
    """Retain the reference generation discarded by the backend PDFObjRef."""

    def __init__(
        self, document: PDFDocument, object_number: int, generation: int
    ) -> None:
        super().__init__(document, object_number)
        self.source_generation = generation


def _integer_token(value: object) -> int | None:
    return value if type(value) is int else None


class _DictionaryParser(PDFParser):
    """Return complete top-level objects without requiring an endobj token."""

    def flush(self) -> None:
        """Publish only a complete top-level parser object."""
        self.add_results(*self.popall())

    def do_keyword(self, pos: int, token: PSKeyword) -> None:
        """Retain exact indirect-reference generations before backend resolution."""
        if token is not self.KEYWORD_R:
            super().do_keyword(pos, token)
            return
        values = self.pop(2)
        object_number, generation = (_integer_token(value) for _, value in values)
        if (
            self.doc is None
            or object_number is None
            or generation is None
            or object_number <= 0
            or generation < 0
        ):
            message = "Invalid indirect reference in font recovery source"
            raise PSSyntaxError(message)
        self.push((pos, _SourceReference(self.doc, object_number, generation)))

    def end_type(
        self, *args: str, **kwargs: str
    ) -> tuple[int, list[PSStackType[PSKeyword | PDFStream | PDFObjRef | None]]]:
        """Preserve backend positional/type keyword calls and reject duplicate keys."""
        position, values = super().end_type(*args, **kwargs)
        typename = args[0] if args else kwargs["type"]
        if typename == "d":
            keys = values[::2]
            if not all(isinstance(key, PSLiteral) for key in keys):
                message = "Non-name font dictionary key"
                raise PSSyntaxError(message)
            names = [literal_name(key) for key in keys]
            if len(names) != len(set(names)):
                message = "Duplicate font dictionary key"
                raise PSSyntaxError(message)
        return position, values


def _object_range(
    document: PDFDocument, object_number: int
) -> tuple[int, int, int] | None:
    for xref in document.xrefs:
        try:
            stream_id, start, generation = xref.get_pos(object_number)
        except KeyError:
            continue
        if stream_id is not None or start < 0:
            return None
        end = start + _MAXIMUM_DICTIONARY_BYTES + 1
        for count, candidate in enumerate(xref.get_objids()):
            if count >= _MAXIMUM_XREF_OBJECTS:
                return None
            other_stream, offset, _ = xref.get_pos(candidate)
            if other_stream is None and start < offset < end:
                end = offset
        if end - start > _MAXIMUM_DICTIONARY_BYTES:
            return None
        return start, end, generation
    return None


def _active_generation(reference: PDFObjRef) -> int | None:
    if reference.doc is not None:
        for xref in reference.doc.xrefs:
            try:
                return xref.get_pos(reference.objid)[2]
            except KeyError:
                continue
    return None


def _reference_generations_match(dictionary: dict[str, Any]) -> bool:
    pending: list[object] = [dictionary]
    while pending:
        value = pending.pop()
        if isinstance(value, _SourceReference):
            if value.source_generation != _active_generation(value):
                return False
        elif isinstance(value, dict):
            pending.extend(value.values())
        elif isinstance(value, list):
            pending.extend(value)
    return True


def _read_dictionary(
    segment: bytes, reference: PDFObjRef, generation: int, terminator: str
) -> tuple[dict[str, Any], int, int] | None:
    if reference.doc is None:
        return None
    parser = _DictionaryParser(BytesIO(segment))
    parser.set_document(reference.doc)
    header = [parser.nexttoken()[1] for _ in range(3)]
    if header != [reference.objid, generation, KWD(b"obj")]:
        return None
    dictionary_start, dictionary = parser.nextobject()
    dictionary_end = parser.tell()
    if not isinstance(dictionary, dict) or not _reference_generations_match(dictionary):
        return None
    if terminator == "PRESENT" and parser.nexttoken()[1] != KWD(b"endobj"):
        return None
    try:
        parser.nexttoken()
    except PSEOF:
        return dictionary, dictionary_start, dictionary_end
    return None


def _font_dictionary(
    segment: bytes, reference: PDFObjRef, generation: int
) -> tuple[dict[str, Any], int, int] | None:
    parsed = _read_dictionary(segment, reference, generation, "ABSENT")
    if parsed is None:
        return None
    dictionary, dictionary_start, dictionary_end = parsed
    if (
        not isinstance(dictionary.get("Type"), PSLiteral)
        or literal_name(dictionary["Type"]) != "Font"
        or not isinstance(dictionary.get("Subtype"), PSLiteral)
        or literal_name(dictionary["Subtype"]) not in {"Type1", "TrueType"}
        or not isinstance(dictionary.get("BaseFont"), PSLiteral)
    ):
        return None
    return dictionary, dictionary_start, dictionary_end


def _strict_object_dictionary(
    reference: PDFObjRef, source: bytes
) -> dict[str, Any] | None:
    if reference.doc is None:
        return None
    bounds = _object_range(reference.doc, reference.objid)
    if bounds is None:
        return None
    start, end, generation = bounds
    if end > len(source):
        return None
    parsed = _read_dictionary(source[start:end], reference, generation, "PRESENT")
    return parsed[0] if parsed is not None else None


def _direct_or_referenced_dictionary(
    value: object, source: bytes
) -> dict[str, Any] | None:
    if isinstance(value, PDFObjRef):
        return _strict_object_dictionary(value, source)
    return value if isinstance(value, dict) else None


def _font_reference_inventory(value: dict[str, Any]) -> dict[str, int] | None:
    if not all(isinstance(item, PDFObjRef) for item in value.values()):
        return None
    return {name: item.objid for name, item in value.items()}


def verify_page_font_resource_binding(
    page_reference: PDFObjRef, resources: dict[object, object], source: bytes
) -> bool:
    """Prove unique explicit page/Resources/Font references before font recovery.

    Unknown inheritance and nested Form resource paths are deliberately excluded
    from this narrow malformed-object repair; their normal extraction is unchanged.
    Duplicate keys are checked on original dictionaries before backend conversion.
    """
    try:
        page = _strict_object_dictionary(page_reference, source)
        if page is None:
            return False
        source_resources = _direct_or_referenced_dictionary(
            page.get("Resources"), source
        )
        if source_resources is None:
            return False
        source_fonts = _direct_or_referenced_dictionary(
            source_resources.get("Font"), source
        )
        if source_fonts is None:
            return False
        observed_fonts = _direct_or_referenced_dictionary(resources.get("Font"), source)
        if observed_fonts is None:
            return False
        source_inventory = _font_reference_inventory(source_fonts)
        return (
            source_inventory is not None
            and source_inventory == _font_reference_inventory(observed_fonts)
        )
    except (PDFException, PSException, ValueError, TypeError, KeyError):
        return False


def recover_font_resource(
    reference: PDFObjRef, source: bytes
) -> FontResourceRecovery | None:
    """Recover one complete font dictionary; never guess a name or substitute bytes.

    The active xref must delimit an uncompressed object of at most 64 KiB.
    Conflicting, truncated, encrypted, stream, or unsupported dictionaries retain
    the backend's ordinary unavailable-font result. The complete dictionary is
    supplied to the normal font factory, so encoding and glyph metrics are restored
    together rather than relabelling already-created fallback characters.
    """
    document = reference.doc
    if document is None or document.decipher is not None:
        return None
    try:
        bounds = _object_range(document, reference.objid)
        if bounds is None:
            return None
        start, end, generation = bounds
        if end > len(source):
            return None
        parsed = _font_dictionary(source[start:end], reference, generation)
    except (PDFException, PSException, ValueError, TypeError, KeyError):
        return None
    if parsed is None:
        return None
    dictionary, dictionary_start, dictionary_end = parsed
    return FontResourceRecovery(
        dictionary=dictionary,
        source_sha256=sha256(source).hexdigest(),
        object_number=reference.objid,
        generation=generation,
        byte_start=start + dictionary_start,
        byte_end=start + dictionary_end,
        dictionary_sha256=sha256(
            source[start + dictionary_start : start + dictionary_end]
        ).hexdigest(),
    )

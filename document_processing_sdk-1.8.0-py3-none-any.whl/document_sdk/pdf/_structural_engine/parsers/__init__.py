# ruff: noqa: EM101, TRY003

from importlib import import_module
from importlib.util import find_spec
from typing import TYPE_CHECKING, Any

from document_sdk.pdf._structural_engine.facts.extractor import PdfFactExtractor

if TYPE_CHECKING:
    from document_sdk.pdf._structural_engine.parsers.pdfplumber_extractor import (
        PdfPlumberFactExtractor,
    )
    from document_sdk.pdf._structural_engine.parsers.pypdf_extractor import (
        PyPdfFactExtractor,
    )
    from document_sdk.pdf._structural_engine.parsers.pypdfium2_extractor import (
        PyPdfium2FactExtractor,
    )

_EXTRACTOR_MODULES = {
    "PdfPlumberFactExtractor": (
        "document_sdk.pdf._structural_engine.parsers.pdfplumber_extractor",
        "PdfPlumberFactExtractor",
    ),
    "PyPdfFactExtractor": (
        "document_sdk.pdf._structural_engine.parsers.pypdf_extractor",
        "PyPdfFactExtractor",
    ),
    "PyPdfium2FactExtractor": (
        "document_sdk.pdf._structural_engine.parsers.pypdfium2_extractor",
        "PyPdfium2FactExtractor",
    ),
}

_PARSER_CLASSES = {
    "pypdf": "PyPdfFactExtractor",
    "pdfplumber": "PdfPlumberFactExtractor",
    "pypdfium2": "PyPdfium2FactExtractor",
}

_PARSER_DEPENDENCIES = {
    "pypdf": ("pypdf",),
    "pdfplumber": ("pdfplumber", "pdfminer"),
    "pypdfium2": ("pypdfium2", "pypdf"),
}

__all__ = [
    "PdfPlumberFactExtractor",
    "PyPdfFactExtractor",
    "PyPdfium2FactExtractor",
]


def __getattr__(name: str) -> Any:
    target = _EXTRACTOR_MODULES.get(name)
    if target is None:
        raise AttributeError(name)
    module_name, class_name = target
    value = getattr(import_module(module_name), class_name)
    globals()[name] = value
    return value


def pdf_fact_parser_available(parser_name: str) -> bool:
    dependencies = _PARSER_DEPENDENCIES.get(parser_name)
    if dependencies is None:
        raise ValueError("unknown PDF Fact parser")
    return all(find_spec(module_name) is not None for module_name in dependencies)


def create_pdf_fact_extractor(parser_name: str) -> PdfFactExtractor:
    class_name = _PARSER_CLASSES.get(parser_name)
    if class_name is None:
        raise ValueError("unknown PDF Fact parser")
    if not pdf_fact_parser_available(parser_name):
        raise RuntimeError("requested PDF Fact parser dependency is unavailable")
    extractor_type = globals().get(class_name) or __getattr__(class_name)
    return extractor_type()  # type: ignore[no-any-return]

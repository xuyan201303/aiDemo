# ruff: noqa: BLE001, C408, EM101, N802, PLR0913, PLR0917, PLR2004, SLF001, TRY003
"""Per-instance native text-event evidence with source-bound font metric repair.

This prototype captures interpreter occurrences, not raw stream byte locations,
decoded-code ancestry, painted-ink geometry, or table-cell ownership.
"""

from __future__ import annotations

import hashlib
import json
import math
from contextlib import contextmanager
from dataclasses import dataclass, field
from io import BytesIO
from typing import TYPE_CHECKING, Any, cast

import pdfminer
import pdfplumber
from pdfminer.layout import LTChar, LTItem, LTPage
from pdfminer.pdffont import FontMetricsDB, PDFCIDFont, PDFType1Font
from pdfminer.pdfinterp import PDFPageInterpreter, PDFResourceManager
from pdfminer.pdfpage import PDFPage
from pdfminer.pdftypes import PDFObjRef, dict_value, resolve1
from pdfminer.psparser import literal_name
from pdfminer.utils import apply_matrix_pt
from pdfplumber.page import Page, PDFPageAggregatorWithMarkedContent
from pdfplumber.pdf import PDF
from pdfplumber.utils.exceptions import PdfminerException

from document_sdk.core.errors import _raise_redacted_translation

from .font_resource_recovery import (
    FontResourceRecovery,
    recover_font_resource,
    verify_page_font_resource_binding,
)

if TYPE_CHECKING:
    from collections.abc import Callable, Iterator, Sequence

METHOD = "pdf_native_text_show_event.v1"
HOOK_METHOD = "pdfplumber.native_text_events.v1"
_COUNTER_RESERVATION = (1 << 63) - 1


def _repair_courier_euro_advance(
    font: PDFType1Font, spec: dict[object, object]
) -> None:
    """Supply the omitted Standard-14 Courier Euro WX without global mutation.

    Adobe Courier AFM specifies a 600-unit Euro advance. The pinned backend's
    Standard-14 table omits it and otherwise falls back to zero. This narrow
    repair requires the source's direct WinAnsi binding and no custom metrics,
    descriptor or Unicode mapping. It does not supply painted-glyph geometry.
    """
    if (
        font.basefont != "Courier"
        or literal_name(spec.get("Encoding")) != "WinAnsiEncoding"
        or any(key in spec for key in ("Widths", "FontDescriptor", "ToUnicode"))
        or font.char_width(128) != 0
    ):
        return
    # Backend Standard-14 width dictionaries are shared. Copy before repairing
    # this request-local font so another PDF/font cannot inherit the correction.
    font.widths = dict(font.widths)
    font.widths[128] = 600


def _bytes(value: object) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        ensure_ascii=False,
        allow_nan=False,
        separators=(",", ":"),
    ).encode("utf-8")


def _sha(value: object) -> str:
    return hashlib.sha256(_bytes(value)).hexdigest()


def observed_writing_mode(font: Any) -> str:
    try:
        value = font.is_vertical()
    except Exception:
        return "UNKNOWN"
    return (
        "VERTICAL" if value is True else "HORIZONTAL" if value is False else "UNKNOWN"
    )


def _operands(values: Sequence[Any], maximum: int) -> tuple[str, int, int, int] | None:
    """Digest ordered operands without keeping raw text or an unbounded list."""
    digest = hashlib.sha256()
    digest.update(b"[")
    strings = numbers = count = 0
    for value in values:
        if count >= maximum:
            return None
        if count:
            digest.update(b",")
        if isinstance(value, bytes):
            descriptor = {
                "kind": "bytes",
                "sha256": hashlib.sha256(value).hexdigest(),
                "size": len(value),
            }
            strings += 1
        elif type(value) in (int, float) and math.isfinite(value):
            descriptor = {"kind": "number", "value": value}
            numbers += 1
        else:
            return None
        digest.update(_bytes(descriptor))
        count += 1
    digest.update(b"]")
    return digest.hexdigest(), count, strings, numbers


@dataclass
class NativeTextEvidenceScope:
    source_sha256: str
    page_number: int
    parser_configuration_identity: str
    maximum_events: int = 250_000
    maximum_members: int = 250_000
    maximum_bytes: int = 32 * 1024 * 1024
    font_source: bytes = b""
    font_recovery_receipts: list[FontResourceRecovery] = field(default_factory=list)
    font_recovery_attempts: int = 0
    events: list[dict[str, Any]] = field(default_factory=list)
    by_native_id: dict[int, tuple[LTChar, dict[str, Any]]] = field(default_factory=dict)
    source_event_count: int = 0
    source_member_count: int = 0
    retained_member_count: int = 0
    reserved_bytes: int = 2
    limitation_codes: set[str] = field(default_factory=set)
    active_event: dict[str, Any] | None = None
    active_member_ordinal: int = 0
    invocation_path: tuple[int, ...] = ()
    invocation_count: int = 0
    invocation_depth: int = 0
    horizontal_spacing: tuple[float, float] | None = None

    @contextmanager
    def event(self, operator: str, operands: Sequence[Any]) -> Iterator[None]:
        previous = self.active_event, self.active_member_ordinal
        ordinal = self.source_event_count
        self.source_event_count += 1
        digest = (
            _operands(operands, min(self.maximum_members, 100_000))
            if len(self.events) < self.maximum_events
            and self.reserved_bytes < self.maximum_bytes
            and self.invocation_depth <= 256
            else None
        )
        record = None
        if digest is not None and len(self.events) < self.maximum_events:
            operand_sha, count, strings, numbers = digest
            fixed = dict(
                schema_version=METHOD,
                source_sha256=self.source_sha256,
                page_number=self.page_number,
                parser_identity=f"pdfplumber:{pdfplumber.__version__}|pdfminer:{pdfminer.__version__}",
                parser_configuration_identity=self.parser_configuration_identity,
                native_event_ordinal=ordinal,
                invocation_path=self.invocation_path,
                operator=operator,
                operand_sequence_sha256=operand_sha,
                operand_count=count,
                string_segment_count=strings,
                numeric_adjustment_count=numbers if operator == "TJ" else 0,
            )
            candidate = fixed | dict(
                source_event_id="PDFTE-" + _sha(fixed),
                source_member_count=0,
                retained_member_count=0,
                completeness="COMPLETE",
                limitation_codes=(),
            )
            # Reserve maximum counter digits and failure labels before admission;
            # exact published bytes are calculated separately on sealed records.
            reserve = (
                len(
                    _bytes(
                        candidate
                        | dict(
                            source_member_count=_COUNTER_RESERVATION,
                            retained_member_count=_COUNTER_RESERVATION,
                            completeness="TRUNCATED",
                            limitation_codes=("native_member_evidence_limit",),
                        )
                    )
                )
                + 1
            )
            if self.reserved_bytes + reserve <= self.maximum_bytes:
                self.reserved_bytes += reserve
                self.events.append(candidate)
                record = candidate
        if record is None:
            self.limitation_codes.add(
                "native_event_evidence_limit_or_unsupported_operand"
            )
        self.active_event, self.active_member_ordinal = record, 0
        try:
            yield
        finally:
            self.active_event, self.active_member_ordinal = previous

    def observe(self, item: LTChar, font: Any, *, clip_excluded: bool = False) -> None:
        ordinal = self.source_member_count
        self.source_member_count += 1
        event = self.active_event
        member_ordinal = self.active_member_ordinal
        self.active_member_ordinal += 1
        if event is not None:
            event["source_member_count"] += 1
        else:
            return
        bridge = dict(
            _native_character_ordinal=ordinal,
            _native_writing_mode=observed_writing_mode(font),
        )
        if self.horizontal_spacing is not None:
            bridge["_native_horizontal_spacing"] = self.horizontal_spacing
        if clip_excluded:
            bridge["_native_clip_excluded"] = True
        if event is not None:
            bridge.update(
                _native_text_show_event_id=event["source_event_id"],
                _native_text_show_event_ordinal=event["native_event_ordinal"],
                _native_text_show_member_ordinal=member_ordinal,
            )
        cost = len(_bytes(bridge)) + 1
        if (
            self.retained_member_count >= self.maximum_members
            or self.reserved_bytes + cost > self.maximum_bytes
        ):
            self.limitation_codes.add("native_member_evidence_limit")
            if event is not None:
                event.update(
                    completeness="TRUNCATED",
                    limitation_codes=("native_member_evidence_limit",),
                )
            return
        native_key = id(item)
        if native_key in self.by_native_id:
            self.limitation_codes.add("native_character_identity_repeated")
            event.update(
                completeness="TRUNCATED",
                limitation_codes=("native_member_evidence_limit",),
            )
            return
        self.reserved_bytes += cost
        self.retained_member_count += 1
        if event is not None:
            event["retained_member_count"] += 1
        self.by_native_id[native_key] = (item, bridge)

    def member_fields(self, item: LTChar) -> dict[str, Any]:
        found = self.by_native_id.get(id(item))
        if found is None or found[0] is not item:
            return {"_native_writing_mode": "UNKNOWN"}
        return dict(found[1])

    def evidence(self) -> dict[str, Any]:
        """Report captured observations separately from Unicode decode coverage."""
        events = [dict(record) for record in self.events]
        size = len(_bytes(events))
        if not size <= self.reserved_bytes <= self.maximum_bytes:
            raise ValueError("native evidence accounting exceeds reserved bytes")
        truncated = (
            self.source_event_count != len(events)
            or self.source_member_count != self.retained_member_count
            or any(record["completeness"] == "TRUNCATED" for record in events)
        )
        # These codes describe decode evidence, not discarded render_char
        # observations. Keep them public even when their inventory is complete.
        decode_limitations = {
            "native_character_decode_unavailable",
            "native_character_decode_coverage_unproved",
        }
        capture_incomplete = truncated or bool(
            self.limitation_codes - decode_limitations
        )
        return dict(
            method_version=HOOK_METHOD,
            availability="PARTIAL" if capture_incomplete else "COMPLETE",
            events=events,
            source_event_count=self.source_event_count,
            retained_event_count=len(events),
            source_member_count=self.source_member_count,
            retained_member_count=self.retained_member_count,
            serialized_bytes=size,
            reserved_bytes=self.reserved_bytes,
            truncated=truncated,
            limitation_codes=tuple(sorted(self.limitation_codes)),
        )


class NativeEvidenceDevice(PDFPageAggregatorWithMarkedContent):
    def __init__(
        self, *args: Any, native_scope: NativeTextEvidenceScope, **kwargs: Any
    ) -> None:
        super().__init__(*args, **kwargs)
        self.native_scope = native_scope
        self.clip_outer_bounds: tuple[float, float, float, float] | None = None
        self.clip_font_ids: set[int] = set()
        self.clip_fill_text = False

    def _excluded_by_clip(
        self, matrix: Any, font: Any, fontsize: float, scaling: float, rise: float
    ) -> bool:
        """Reject only a finite font envelope wholly outside a source clip bound."""
        clip = self.clip_outer_bounds
        if (
            clip is None
            or type(font) is not PDFType1Font
            or id(font) not in self.clip_font_ids
            or font.is_vertical()
            or not self.clip_fill_text
        ):
            return False
        if clip[0] > clip[2] or clip[1] > clip[3]:
            return True
        bbox = font.bbox
        if len(bbox) != 4 or not all(
            isinstance(value, (int, float)) and math.isfinite(value)
            for value in (*bbox, fontsize, scaling, rise, *matrix)
        ):
            return False
        if bbox[0] >= bbox[2] or bbox[1] >= bbox[3]:
            return False
        points = [
            apply_matrix_pt(
                matrix,
                (
                    x * font.hscale * fontsize * scaling,
                    y * font.vscale * fontsize + rise,
                ),
            )
            for x in (bbox[0], bbox[2])
            for y in (bbox[1], bbox[3])
        ]
        x0 = min(point[0] for point in points)
        y0 = min(point[1] for point in points)
        x1 = max(point[0] for point in points)
        y1 = max(point[1] for point in points)
        return x1 < clip[0] or clip[2] < x0 or y1 < clip[1] or clip[3] < y0

    def handle_undefined_char(self, font: Any, cid: int) -> str:
        self.native_scope.limitation_codes.add("native_character_decode_unavailable")
        return super().handle_undefined_char(font, cid)

    def render_char(
        self,
        matrix: Any,
        font: Any,
        fontsize: float,
        scaling: float,
        rise: float,
        cid: int,
        ncs: Any,
        graphicstate: Any,
    ) -> float:
        advance = super().render_char(
            matrix, font, fontsize, scaling, rise, cid, ncs, graphicstate
        )
        item = self.cur_item._objs[-1] if self.cur_item._objs else None
        if isinstance(item, LTChar):
            self.native_scope.observe(
                item,
                font,
                clip_excluded=self._excluded_by_clip(
                    matrix, font, fontsize, scaling, rise
                ),
            )
        else:
            self.native_scope.limitation_codes.add(
                "native_character_creation_unavailable"
            )
        return advance


class NativeEvidenceInterpreter(PDFPageInterpreter):
    def __init__(
        self, rsrcmgr: PDFResourceManager, device: NativeEvidenceDevice
    ) -> None:
        super().__init__(rsrcmgr, device)
        self._native_device = device
        self.native_scope = device.native_scope
        self._forced_native_operator: tuple[str, Sequence[Any]] | None = None
        self._font_recovery_resources: dict[object, object] | None = None
        self._font_recovery_page_reference: PDFObjRef | None = None
        self._clip_stack: list[tuple[float, float, float, float] | None] = []
        self._rectangle_path: tuple[Any, Any, Any] | None = None
        self._pending_clip = False

    def do_q(self) -> None:
        self._clip_stack.append(self._native_device.clip_outer_bounds)
        super().do_q()

    def do_Q(self) -> None:
        super().do_Q()
        if self._clip_stack:
            self._native_device.clip_outer_bounds = self._clip_stack.pop()

    def do_re(self, x: Any, y: Any, width: Any, height: Any) -> None:
        previous = len(self.curpath)
        super().do_re(x, y, width, height)
        self._rectangle_path = (
            (tuple(self.curpath), self.ctm, self._native_device.clip_outer_bounds)
            if previous == 0 and len(self.curpath) == 5
            else None
        )

    def _observe_rectangle_clip(self) -> None:
        """Keep a conservative bound; unknown paths never invent visibility."""
        captured = self._rectangle_path
        if (
            captured is None
            or tuple(self.curpath) not in (captured[0], (*captured[0], ("h",)))
            or captured[1] != self.ctm
        ):
            return
        corners = []
        for point in self.curpath[:4]:
            if len(point) == 3:
                corners.append(apply_matrix_pt(self.ctm, (point[1], point[2])))
            else:
                return
        bounds = (
            min(point[0] for point in corners),
            min(point[1] for point in corners),
            max(point[0] for point in corners),
            max(point[1] for point in corners),
        )
        old = self._native_device.clip_outer_bounds
        self._native_device.clip_outer_bounds = (
            (
                max(old[0], bounds[0]),
                max(old[1], bounds[1]),
                min(old[2], bounds[2]),
                min(old[3], bounds[3]),
            )
            if old is not None
            else bounds
        )

    def do_W(self) -> None:
        self._pending_clip = True
        super().do_W()

    def do_W_a(self) -> None:
        self._pending_clip = True
        super().do_W_a()

    def _end_clip_path(self, terminate: Callable[[], None]) -> None:
        """Activate W only when the path is ended, retaining the backend paint."""
        if self._pending_clip:
            self._observe_rectangle_clip()
        try:
            terminate()
        finally:
            self._pending_clip = False
            self._rectangle_path = None

    def do_n(self) -> None:
        self._end_clip_path(super().do_n)

    def do_S(self) -> None:
        self._end_clip_path(super().do_S)

    def do_f(self) -> None:
        self._end_clip_path(super().do_f)

    def do_F(self) -> None:
        self._end_clip_path(super().do_F)

    def do_f_a(self) -> None:
        self._end_clip_path(super().do_f_a)

    def do_B(self) -> None:
        self._end_clip_path(super().do_B)

    def do_B_a(self) -> None:
        self._end_clip_path(super().do_B_a)

    def init_resources(self, resources: dict[object, object]) -> None:
        self._init_resources(resources)
        supported: set[int] = set()
        for name, reference in dict_value(resources.get("Font")).items():
            spec = resolve1(reference)
            if not isinstance(spec, dict) or "FontDescriptor" in spec:
                continue
            try:
                basefont = literal_name(spec.get("BaseFont"))
                FontMetricsDB.get_metrics(basefont)
            except (KeyError, TypeError):
                continue
            font = self.fontmap.get(literal_name(name))
            if font is not None and type(font) is PDFType1Font:
                _repair_courier_euro_advance(font, spec)
                supported.add(id(font))
        self._native_device.clip_font_ids = supported

    def _init_resources(self, resources: dict[object, object]) -> None:
        if resources is not self._font_recovery_resources:
            super().init_resources(resources)
            return
        resolved_resources: dict[object, object] = dict_value(resources)
        fonts = dict_value(resolved_resources.get("Font"))
        invalid_fonts = {
            name: reference
            for name, reference in fonts.items()
            if isinstance(reference, PDFObjRef)
            and not isinstance(resolve1(reference), dict)
        }
        if not invalid_fonts or self._font_recovery_page_reference is None:
            super().init_resources(resources)
            return
        if not verify_page_font_resource_binding(
            self._font_recovery_page_reference, resources, self.native_scope.font_source
        ):
            super().init_resources(resources)
            return
        recovered_fonts: dict[str, Any] = {}
        for resource_name, reference in invalid_fonts.items():
            if self.native_scope.font_recovery_attempts >= 64:
                self.native_scope.limitation_codes.add("native_font_recovery_budget")
                break
            self.native_scope.font_recovery_attempts += 1
            receipt = recover_font_resource(reference, self.native_scope.font_source)
            if receipt is not None:
                recovered_fonts[resource_name] = receipt.dictionary
                self.native_scope.font_recovery_receipts.append(receipt)
        if recovered_fonts:
            resolved_resources = dict(resolved_resources)
            resolved_resources["Font"] = fonts | recovered_fonts
        super().init_resources(resolved_resources)

    def _force(
        self, operator: str, operands: Sequence[Any], call: Callable[[], None]
    ) -> None:
        previous = self._forced_native_operator
        self._forced_native_operator = operator, operands
        try:
            return call()
        finally:
            self._forced_native_operator = previous

    def do_Tj(self, s: Any) -> None:
        return self._force(
            "Tj", (s,), lambda: super(NativeEvidenceInterpreter, self).do_Tj(s)
        )

    def do__q(self, s: Any) -> None:
        return self._force(
            "'", (s,), lambda: super(NativeEvidenceInterpreter, self).do__q(s)
        )

    def do__w(self, aw: Any, ac: Any, s: Any) -> None:
        # Preserve this installed backend's exact quote behavior, including any
        # existing limitations. Do not reproduce or repair its state transitions.
        return self._force(
            '"',
            (aw, ac, s),
            lambda: super(NativeEvidenceInterpreter, self).do__w(aw, ac, s),
        )

    def do_TJ(self, seq: Any) -> None:
        operator, original = self._forced_native_operator or ("TJ", seq)
        previous_fill = self._native_device.clip_fill_text
        previous_spacing = self.native_scope.horizontal_spacing
        font = self.textstate.font
        self.native_scope.horizontal_spacing = (
            (
                self.textstate.charspace * self.textstate.scaling * 0.01,
                0.0
                if font.is_multibyte()
                else self.textstate.wordspace * self.textstate.scaling * 0.01,
            )
            if font is not None and not font.is_vertical()
            else None
        )
        self._native_device.clip_fill_text = self.textstate.render == 0
        with self.native_scope.event(operator, original):
            # PDFCIDFont.decode may omit undecodable bytes without render_char.
            # Observed character retention cannot prove multibyte code coverage.
            if isinstance(self.textstate.font, PDFCIDFont) and any(
                isinstance(value, bytes) and value for value in seq
            ):
                self.native_scope.limitation_codes.add(
                    "native_character_decode_coverage_unproved"
                )
            try:
                return super().do_TJ(seq)
            finally:
                self._native_device.clip_fill_text = previous_fill
                self.native_scope.horizontal_spacing = previous_spacing

    def do_Do(self, xobjid_arg: Any) -> None:
        previous = self.native_scope.invocation_path
        previous_clip = self._native_device.clip_outer_bounds
        previous_clip_fonts = self._native_device.clip_font_ids
        invocation = self.native_scope.invocation_count
        self.native_scope.invocation_count += 1
        self.native_scope.invocation_depth += 1
        if self.native_scope.invocation_depth <= 256:
            self.native_scope.invocation_path = (*previous, invocation)
        else:
            self.native_scope.limitation_codes.add("native_invocation_depth_limit")
        try:
            return super().do_Do(xobjid_arg)
        finally:
            self._native_device.clip_outer_bounds = previous_clip
            self._native_device.clip_font_ids = previous_clip_fonts
            self.native_scope.invocation_path = previous
            self.native_scope.invocation_depth -= 1


class NativeEvidencePage(Page):
    @property
    def layout(self) -> LTPage:
        if hasattr(self, "_layout"):
            return self._layout
        self._native_scope = NativeTextEvidenceScope(
            page_number=self.page_number,
            font_source=cast("NativeEvidencePDF", self.pdf).font_recovery_source,
            **cast("NativeEvidencePDF", self.pdf).native_evidence_options,
        )
        device = NativeEvidenceDevice(
            self.pdf.rsrcmgr,
            pageno=self.page_number,
            laparams=self.pdf.laparams,
            native_scope=self._native_scope,
        )
        interpreter = NativeEvidenceInterpreter(self.pdf.rsrcmgr, device)
        if type(self.page_obj.pageid) is int:
            interpreter._font_recovery_resources = self.page_obj.resources
            interpreter._font_recovery_page_reference = PDFObjRef(
                self.page_obj.doc, self.page_obj.pageid
            )
        try:
            interpreter.process_page(self.page_obj)
        except Exception as error:
            _raise_redacted_translation(
                error, PdfminerException("Native PDF text processing failed")
            )
        self._layout = device.get_result()
        return self._layout

    def process_object(self, obj: LTItem) -> dict[str, Any]:
        value = super().process_object(obj)
        if isinstance(obj, LTChar):
            value.update(self._native_scope.member_fields(obj))
        return value

    def close(self) -> None:
        # Keep the bounded identity lookaside while the cached LTPage is alive:
        # a caller may discard only _objects and project that same layout again.
        # Closing the page discards the layout and its identity references together.
        try:
            super().close()
        finally:
            if hasattr(self, "_native_scope"):
                self._native_scope.by_native_id.clear()

    def native_text_event_evidence(self) -> dict[str, Any]:
        if not hasattr(self, "_native_scope"):
            return dict(
                method_version=HOOK_METHOD,
                availability="NOT_CAPTURED",
                events=[],
                source_event_count=0,
                retained_event_count=0,
                source_member_count=0,
                retained_member_count=0,
                serialized_bytes=0,
                reserved_bytes=0,
                truncated=False,
                limitation_codes=(),
            )
        return self._native_scope.evidence()


class NativeEvidencePDF(PDF):
    native_evidence_options: dict[str, Any]
    font_recovery_source: bytes

    @property
    def pages(self) -> list[Page]:
        if hasattr(self, "_pages"):
            return self._pages
        # Match pinned pdfplumber's page selection/doctop behavior while changing
        # only this instance's Page factory. No backend module attribute changes.
        self._pages = []
        doctop: float = 0
        try:
            for index, page in enumerate(PDFPage.create_pages(self.doc)):
                page_number = index + 1
                if (
                    self.pages_to_parse is not None
                    and page_number not in self.pages_to_parse
                ):
                    continue
                item = NativeEvidencePage(
                    self, page, page_number=page_number, initial_doctop=doctop
                )
                self._pages.append(item)
                doctop += item.height
        except Exception as error:
            _raise_redacted_translation(
                error, PdfminerException("Native PDF text processing failed")
            )
        return self._pages


def open_native_evidence_pdf(
    path_or_fp: Any,
    *,
    source_sha256: str,
    parser_configuration_identity: str,
    maximum_events: int = 250_000,
    maximum_members: int = 250_000,
    maximum_bytes: int = 32 * 1024 * 1024,
    **pdf_open_kwargs: Any,
) -> NativeEvidencePDF:
    """Open one local parser instance; evidence shares the caller's page budget."""
    if (
        len(source_sha256) != 64
        or len(parser_configuration_identity) != 64
        or any(
            c not in "0123456789abcdef"
            for c in source_sha256 + parser_configuration_identity
        )
    ):
        raise ValueError("native event evidence requires SHA-256 source/configuration")
    if min(maximum_events, maximum_members) < 0 or maximum_bytes < 2:
        raise ValueError("native event evidence limits are invalid")
    pdf = cast(
        "NativeEvidencePDF", NativeEvidencePDF.open(path_or_fp, **pdf_open_kwargs)
    )
    if isinstance(pdf.stream, BytesIO):
        pdf.font_recovery_source = pdf.stream.getvalue()
    else:
        position = pdf.stream.tell()
        pdf.stream.seek(0)
        pdf.font_recovery_source = pdf.stream.read()
        pdf.stream.seek(position)
    pdf.native_evidence_options = dict(
        source_sha256=source_sha256,
        parser_configuration_identity=parser_configuration_identity,
        maximum_events=maximum_events,
        maximum_members=maximum_members,
        maximum_bytes=maximum_bytes,
    )
    return pdf

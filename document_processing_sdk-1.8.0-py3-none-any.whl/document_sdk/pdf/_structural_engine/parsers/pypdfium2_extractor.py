# ruff: noqa: BLE001, C901, E501, FBT003, PLR0912, PLR0913, PLR0915, PLR2004, S110, SIM105, TRY300

import math
from ctypes import byref, c_float, c_int
from dataclasses import dataclass
from importlib.metadata import version
from io import BytesIO
from time import perf_counter
from typing import Any, Literal

import pypdfium2 as pdfium
import pypdfium2.raw as pdfium_raw
from pypdf import PdfReader

from document_sdk.pdf._structural_engine.facts.capabilities import PdfParserCapabilities
from document_sdk.pdf._structural_engine.facts.contracts import (
    PDF_DRAWING_PATH_GEOMETRY_VERSION,
    PdfDrawingBBoxSemantics,
    PdfDrawingFact,
    PdfDrawingPathSegment,
    PdfFactArtifact,
    PdfImageRegionFact,
    PdfPageFacts,
    PdfPaintOperation,
    PdfScalarProvenance,
    PdfTextFact,
)
from document_sdk.pdf._structural_engine.facts.coordinates import (
    PdfCanonicalPageGeometry,
    PdfCoordinateNormalizationResult,
    PdfSourceCoordinateSpace,
    PdfTextRotationSource,
    canonical_affine_scale_components,
    canonical_page_geometry,
    canonical_text_rotation,
    coordinate_transform_provenance,
    effective_affine_scalar_components,
    fact_bbox_dimension_warning,
    normalize_bbox,
    normalize_point,
    normalize_scalar_length,
    source_affine_transform,
)
from document_sdk.pdf._structural_engine.facts.identifiers import (
    fact_identifier,
    page_identifier,
    source_sha256,
)
from document_sdk.pdf._structural_engine.facts.limits import (
    PdfExtractionLimits,
    PdfExtractionOptions,
    PdfSource,
)
from document_sdk.pdf._structural_engine.facts.normalization import (
    build_size_limited_artifact,
    make_warning,
    source_preflight_warning,
    terminal_artifact,
)
from document_sdk.pdf._structural_engine.facts.status import (
    PdfExtractionStatus,
    PdfFactWarning,
    PdfWarningCode,
    PdfWarningSeverity,
)
from document_sdk.pdf._structural_engine.parsers.common import (
    PdfParserExtractionState,
    add_fact_warning,
    add_page_warning,
    add_requested_capability_warnings,
    normalized_page_rotation,
    resolve_extraction_scope,
)
from document_sdk.pdf._xref_keyword_recovery import verified_parser_view


@dataclass(frozen=True)
class _PdfiumRawPathEntry:
    segment_type: int
    point: tuple[float, float]
    closed: bool


@dataclass(frozen=True)
class _PdfiumLogicalPathSegment:
    kind: Literal["move", "line", "cubic_bezier", "close"]
    start: tuple[float, float]
    end: tuple[float, float]
    control_points: tuple[tuple[float, float], ...]
    subpath_index: int
    closed: bool


@dataclass(frozen=True)
class _PdfiumPathGeometry:
    segments: tuple[PdfDrawingPathSegment, ...]
    source_segment_count: int
    count_is_lower_bound: bool
    truncated: bool
    closed: bool | None
    complete: bool


class PyPdfium2FactExtractor:
    parser_name = "pypdfium2"

    @property
    def parser_version(self) -> str:
        return version("pypdfium2")

    def capabilities(self) -> PdfParserCapabilities:
        return PdfParserCapabilities(
            page_geometry=True,
            text_spans=True,
            words=False,
            line_candidates=False,
            optional_characters=True,
            font_name=True,
            font_size=True,
            text_rotation=True,
            writing_direction=False,
            drawings=True,
            drawing_lines=False,
            drawing_rectangles=False,
            drawing_curves=True,
            image_regions=True,
            text_bbox_quality="precise",
            native_engine=True,
            text_affine_transform=True,
            effective_font_size=True,
            nominal_stroke_width=True,
            drawing_affine_transform=True,
            drawing_paint_operation=True,
            drawing_path_segments=True,
            character_rotation=True,
            drawing_bbox_quality="approximate",
            graphics_state_fidelity="partial",
            selected_page_extraction=True,
        )

    def extract(
        self,
        source: PdfSource,
        *,
        limits: PdfExtractionLimits,
        options: PdfExtractionOptions,
    ) -> PdfFactArtifact:
        started_at = perf_counter()
        preflight = source_preflight_warning(
            source=source,
            parser_name=self.parser_name,
            limits=limits,
        )
        if preflight is not None:
            status, warning = preflight
            return terminal_artifact(
                source=source,
                parser_name=self.parser_name,
                parser_version=self.parser_version,
                capabilities=self.capabilities(),
                limits=limits,
                options=options,
                status=status,
                warning=warning,
                started_at=started_at,
            )
        try:
            document = pdfium.PdfDocument(verified_parser_view(source.content))
        except (pdfium.PdfiumError, OSError, ValueError, TypeError) as error:
            return self._terminal_open_failure(
                source=source,
                limits=limits,
                options=options,
                started_at=started_at,
                error=error,
            )
        except Exception as error:
            return self._terminal_parser_error(
                source=source,
                limits=limits,
                options=options,
                started_at=started_at,
                error=error,
            )

        geometry_reader = None
        try:
            geometry_reader = PdfReader(
                BytesIO(verified_parser_view(source.content)), strict=False
            )
        except Exception:
            pass

        try:
            page_count = len(document)
            state = PdfParserExtractionState(
                parser_name=self.parser_name,
                limits=limits,
                started_at=started_at,
            )
            add_requested_capability_warnings(
                state=state,
                capabilities=self.capabilities(),
                options=options,
            )
            if geometry_reader is None:
                state.warnings.add_fields(
                    code=PdfWarningCode.GEOMETRY_PROVIDER_UNAVAILABLE,
                    message=(
                        "The supplemental pypdf geometry provider was unavailable; "
                        "PDFium geometry fallback is partial."
                    ),
                )
            pages: list[PdfPageFacts] = []
            resolved_scope = resolve_extraction_scope(
                page_count=page_count,
                options=options,
                state=state,
            )
            if resolved_scope.invalid:
                return build_size_limited_artifact(
                    source=source,
                    parser_name=self.parser_name,
                    parser_version=self.parser_version,
                    capabilities=self.capabilities(),
                    limits=limits,
                    options=options,
                    status=PdfExtractionStatus.INVALID_REQUEST,
                    page_count=page_count,
                    pages=[],
                    warnings=state.warnings.final_items(),
                    warning_suppression=state.warnings.suppression_summary(),
                    started_at=started_at,
                    pages_attempted=0,
                    partial_extraction=False,
                )
            source_hash = source_sha256(source.content)
            for page_number in resolved_scope.page_numbers:
                if state.timed_out():
                    break
                state.pages_attempted += 1
                page_index = page_number - 1
                page = None
                try:
                    page = document[page_index]
                    geometry_page = None
                    if geometry_reader is not None:
                        try:
                            geometry_page = geometry_reader.pages[page_index]
                        except Exception:
                            state.warnings.add_fields(
                                code=PdfWarningCode.GEOMETRY_PROVIDER_UNAVAILABLE,
                                message=(
                                    "Supplemental geometry was unavailable for one "
                                    "PDFium page."
                                ),
                                page_number=page_number,
                            )
                    page_facts = self._extract_page(
                        page=page,
                        geometry_page=geometry_page,
                        page_number=page_number,
                        source_hash=source_hash,
                        limits=limits,
                        options=options,
                        state=state,
                    )
                except (
                    pdfium.PdfiumError,
                    OSError,
                    ValueError,
                    TypeError,
                    KeyError,
                    AttributeError,
                ):
                    state.page_failed = True
                    state.warnings.add_fields(
                        code=PdfWarningCode.PARTIAL_PAGE_FAILURE,
                        message="A PDF page could not be converted into canonical facts.",
                        page_number=page_number,
                    )
                    continue
                finally:
                    if page is not None:
                        page.close()
                if not state.add_page(page_facts, pages):
                    break
            status, partial = state.status(
                pages=pages,
                requested_page_numbers=resolved_scope.page_numbers,
            )
            if status is PdfExtractionStatus.NO_TEXT_LAYER:
                state.warnings.add_fields(
                    code=PdfWarningCode.NO_TEXT_LAYER,
                    message="No extractable electronic text layer was found.",
                    recoverable=False,
                )
            return build_size_limited_artifact(
                source=source,
                parser_name=self.parser_name,
                parser_version=self.parser_version,
                capabilities=self.capabilities(),
                limits=limits,
                options=options,
                status=status,
                page_count=page_count,
                pages=pages,
                warnings=state.warnings.final_items(),
                warning_suppression=state.warnings.suppression_summary(),
                started_at=started_at,
                pages_attempted=state.pages_attempted,
                partial_extraction=partial,
            )
        finally:
            document.close()

    def _extract_page(
        self,
        *,
        page: Any,
        geometry_page: Any | None,
        page_number: int,
        source_hash: str,
        limits: PdfExtractionLimits,
        options: PdfExtractionOptions,
        state: PdfParserExtractionState,
    ) -> PdfPageFacts:
        page_warnings: list[PdfFactWarning] = []
        page_partial = False
        rotation, rotation_valid = normalized_page_rotation(page.get_rotation())
        if not rotation_valid:
            page_partial = True
            add_page_warning(
                state=state,
                page_warnings=page_warnings,
                code=PdfWarningCode.UNSUPPORTED_ROTATION,
                message="A PDF page declared an unsupported rotation.",
                page_number=page_number,
            )
        geometry, geometry_provenance = _pdfium_page_geometry(
            page=page,
            geometry_page=geometry_page,
            rotation=rotation,
        )
        if geometry_provenance["geometry_completeness"] != "complete":
            page_partial = True
            add_page_warning(
                state=state,
                page_warnings=page_warnings,
                code=PdfWarningCode.GEOMETRY_FALLBACK_ASSUMPTION,
                message=(
                    "PDFium page geometry was used with incomplete UserUnit or "
                    "origin provenance."
                ),
                page_number=page_number,
            )
        page_id = page_identifier(
            source_hash=source_hash,
            parser_name=self.parser_name,
            parser_version=self.parser_version,
            page_number=page_number,
        )
        textpage = page.get_textpage()
        try:
            source_order = 0
            text_spans: list[PdfTextFact] = []
            characters: list[PdfTextFact] = []
            drawings: list[PdfDrawingFact] = []
            image_regions: list[PdfImageRegionFact] = []
            retained_path_segment_count = 0
            path_segment_limit_reached = False

            def next_order() -> int:
                nonlocal source_order
                value = source_order
                source_order += 1
                return value

            page_objects = list(page.get_objects(textpage=textpage))
            text_objects = [
                item
                for item in page_objects
                if item.type == pdfium_raw.FPDF_PAGEOBJ_TEXT
            ]
            for item in text_objects[: limits.max_text_facts_per_page]:
                normalized = _normalize_pdfium_bbox(
                    bbox=item.get_bounds(),
                    geometry=geometry,
                    rotation=rotation,
                )
                if normalized.bbox is None or normalized.normalized_bbox is None:
                    page_partial = True
                    add_page_warning(
                        state=state,
                        page_warnings=page_warnings,
                        code=PdfWarningCode.INVALID_BBOX,
                        message="A parser-provided text box was outside page bounds.",
                        page_number=page_number,
                    )
                    continue
                text = textpage.get_text_bounded(*item.get_bounds())
                if not text or not text.strip():
                    continue
                order = next_order()
                font_name = None
                font = item.get_font()
                try:
                    font_name = str(font.get_base_name())[:256] or None
                finally:
                    font.close()
                matrix = item.get_matrix().get()
                fact_id = fact_identifier(
                    source_hash=source_hash,
                    parser_name=self.parser_name,
                    parser_version=self.parser_version,
                    page_number=page_number,
                    fact_type="text_span",
                    source_order=order,
                    bbox=normalized.bbox,
                    text=text,
                )
                fact_warnings: list[PdfFactWarning] = []
                if (
                    fact_bbox_dimension_warning(
                        bbox=normalized.bbox,
                        fact_kind="text",
                    )
                    is PdfWarningCode.ZERO_AREA_BBOX
                ):
                    add_fact_warning(
                        state=state,
                        fact_warnings=fact_warnings,
                        code=PdfWarningCode.ZERO_AREA_BBOX,
                        message="The parser-provided text box has zero area.",
                        page_number=page_number,
                        fact_id=fact_id,
                    )
                raw_font_size = _optional_nonnegative_float(item.get_font_size())
                effective_font_size = effective_affine_scalar_components(
                    raw_font_size,
                    matrix,
                    user_unit=geometry.user_unit,
                )
                effective_font_scale = canonical_affine_scale_components(
                    matrix,
                    user_unit=geometry.user_unit,
                )
                text_spans.append(
                    PdfTextFact(
                        fact_id=fact_id,
                        page_id=page_id,
                        granularity="text_span",
                        text=text,
                        bbox=normalized.bbox,
                        normalized_bbox=normalized.normalized_bbox,
                        source_order=order,
                        font_name=font_name,
                        font_size=normalize_scalar_length(
                            raw_font_size,
                            user_unit=geometry.user_unit,
                        ),
                        effective_font_scale_x=(
                            effective_font_scale[0]
                            if effective_font_scale is not None
                            else None
                        ),
                        effective_font_scale_y=(
                            effective_font_scale[1]
                            if effective_font_scale is not None
                            else None
                        ),
                        effective_font_size_x=(
                            effective_font_size[0]
                            if effective_font_size is not None
                            else None
                        ),
                        effective_font_size_y=(
                            effective_font_size[1]
                            if effective_font_size is not None
                            else None
                        ),
                        text_transform=source_affine_transform(matrix),
                        font_size_provenance=PdfScalarProvenance(
                            parser_native_value=raw_font_size,
                            parser_native_semantics=(
                                "nominal"
                                if raw_font_size is not None
                                else "unavailable"
                            ),
                            parser_native_unit=(
                                "pdf_user_space"
                                if raw_font_size is not None
                                else "unknown"
                            ),
                            canonical_derivation=(
                                "affine_derived"
                                if raw_font_size is not None
                                else "unavailable"
                            ),
                            parser_applies_user_unit=False,
                            affine_transform_available=True,
                            source=(
                                "pdfium_text_object"
                                if raw_font_size is not None
                                else "unavailable"
                            ),
                        ),
                        rotation=canonical_text_rotation(
                            text_rotation=_matrix_rotation(matrix),
                            page_rotation=rotation,
                            source=PdfTextRotationSource.PDF_USER_SPACE_COUNTERCLOCKWISE,
                        ),
                        writing_direction="unknown",
                        parser_metadata={
                            "coordinate_space": "pdf_user_space",
                            "raw_font_size": raw_font_size,
                            "raw_scalar_unit": "pdf_user_space",
                        },
                        warnings=fact_warnings,
                    )
                )
            if len(text_objects) > limits.max_text_facts_per_page:
                page_partial = True
                warning = make_warning(
                    code=PdfWarningCode.TEXT_FACT_LIMIT_REACHED,
                    parser_name=self.parser_name,
                    message="Text facts on this page were truncated by the configured limit.",
                    page_number=page_number,
                )
                state.warnings.add_page(warning, target=page_warnings)

            if options.include_characters:
                char_count = textpage.count_chars()
                for index in range(min(char_count, limits.max_characters_per_page)):
                    text = textpage.get_text_range(index, 1)
                    if not text or text in {"\r", "\n"}:
                        continue
                    try:
                        charbox = textpage.get_charbox(index)
                    except pdfium.PdfiumError:
                        page_partial = True
                        add_page_warning(
                            state=state,
                            page_warnings=page_warnings,
                            code=PdfWarningCode.PARTIAL_PAGE_FAILURE,
                            message="A parser-provided character box was unavailable.",
                            page_number=page_number,
                        )
                        continue
                    normalized = _normalize_pdfium_bbox(
                        bbox=charbox,
                        geometry=geometry,
                        rotation=rotation,
                    )
                    if normalized.bbox is None or normalized.normalized_bbox is None:
                        page_partial = True
                        add_page_warning(
                            state=state,
                            page_warnings=page_warnings,
                            code=PdfWarningCode.INVALID_BBOX,
                            message="A parser-provided character box was outside page bounds.",
                            page_number=page_number,
                        )
                        continue
                    order = next_order()
                    fact_id = fact_identifier(
                        source_hash=source_hash,
                        parser_name=self.parser_name,
                        parser_version=self.parser_version,
                        page_number=page_number,
                        fact_type="character",
                        source_order=order,
                        bbox=normalized.bbox,
                        text=text,
                    )
                    fact_warnings = []
                    if (
                        fact_bbox_dimension_warning(
                            bbox=normalized.bbox,
                            fact_kind="text",
                        )
                        is PdfWarningCode.ZERO_AREA_BBOX
                    ):
                        add_fact_warning(
                            state=state,
                            fact_warnings=fact_warnings,
                            code=PdfWarningCode.ZERO_AREA_BBOX,
                            message="The parser-provided character box has zero area.",
                            page_number=page_number,
                            fact_id=fact_id,
                        )
                    raw_character_angle = _pdfium_character_angle(
                        textpage=textpage,
                        index=index,
                    )
                    character_rotation = (
                        canonical_text_rotation(
                            text_rotation=raw_character_angle,
                            page_rotation=rotation,
                            source=(PdfTextRotationSource.UNROTATED_VISUAL_CLOCKWISE),
                        )
                        if raw_character_angle is not None
                        else None
                    )
                    if character_rotation is None:
                        add_fact_warning(
                            state=state,
                            fact_warnings=fact_warnings,
                            code=PdfWarningCode.ROTATION_UNAVAILABLE,
                            message="PDFium did not expose a character rotation.",
                            page_number=page_number,
                            fact_id=fact_id,
                        )
                    characters.append(
                        PdfTextFact(
                            fact_id=fact_id,
                            page_id=page_id,
                            granularity="character",
                            text=text,
                            bbox=normalized.bbox,
                            normalized_bbox=normalized.normalized_bbox,
                            source_order=order,
                            rotation=character_rotation,
                            writing_direction="unknown",
                            parser_metadata={
                                "character_index": index,
                                "raw_character_angle_degrees": raw_character_angle,
                                "raw_rotation_semantics": (
                                    "unrotated_visual_clockwise"
                                    if raw_character_angle is not None
                                    else "unavailable"
                                ),
                            },
                            warnings=fact_warnings,
                        )
                    )
                if char_count > limits.max_characters_per_page:
                    page_partial = True
                    warning = make_warning(
                        code=PdfWarningCode.CHARACTER_LIMIT_REACHED,
                        parser_name=self.parser_name,
                        message="Character facts on this page were truncated by the configured limit.",
                        page_number=page_number,
                    )
                    state.warnings.add_page(warning, target=page_warnings)

            if options.include_drawings:
                path_objects = [
                    item
                    for item in page_objects
                    if item.type == pdfium_raw.FPDF_PAGEOBJ_PATH
                ]
                for item in path_objects[: limits.max_drawing_facts_per_page]:
                    normalized = _normalize_pdfium_bbox(
                        bbox=item.get_bounds(),
                        geometry=geometry,
                        rotation=rotation,
                    )
                    if normalized.bbox is None or normalized.normalized_bbox is None:
                        page_partial = True
                        add_page_warning(
                            state=state,
                            page_warnings=page_warnings,
                            code=PdfWarningCode.INVALID_BBOX,
                            message="A parser-provided drawing box was outside page bounds.",
                            page_number=page_number,
                        )
                        continue
                    order = next_order()
                    fact_id = fact_identifier(
                        source_hash=source_hash,
                        parser_name=self.parser_name,
                        parser_version=self.parser_version,
                        page_number=page_number,
                        fact_type="curve",
                        source_order=order,
                        bbox=normalized.bbox,
                    )
                    fact_warnings = []
                    if (
                        fact_bbox_dimension_warning(
                            bbox=normalized.bbox,
                            fact_kind="curve",
                            path_present=True,
                        )
                        is PdfWarningCode.ZERO_AREA_BBOX
                    ):
                        add_fact_warning(
                            state=state,
                            fact_warnings=fact_warnings,
                            code=PdfWarningCode.ZERO_AREA_BBOX,
                            message="The parser-provided drawing box has zero area.",
                            page_number=page_number,
                            fact_id=fact_id,
                        )
                    raw_stroke_width = _pdfium_stroke_width(item)
                    matrix = item.get_matrix().get()
                    paint_operation = _pdfium_paint_operation(item)
                    remaining_page_segments = max(
                        limits.max_path_segments_per_page - retained_path_segment_count,
                        0,
                    )
                    path_geometry = _pdfium_path_geometry(
                        item=item,
                        matrix=matrix,
                        geometry=geometry,
                        rotation=rotation,
                        retained_limit=min(
                            limits.max_path_segments_per_drawing,
                            remaining_page_segments,
                        ),
                        source_scan_limit=(
                            (limits.max_path_segments_per_drawing * 3) + 3
                        ),
                    )
                    retained_path_segment_count += len(path_geometry.segments)
                    if path_geometry.truncated:
                        page_partial = True
                        path_segment_limit_reached = True
                    has_stroke = paint_operation in {"stroke", "fill_stroke"}
                    effective_stroke_width = (
                        effective_affine_scalar_components(
                            raw_stroke_width,
                            matrix,
                            user_unit=geometry.user_unit,
                        )
                        if has_stroke
                        else None
                    )
                    effective_stroke_scale = canonical_affine_scale_components(
                        matrix,
                        user_unit=geometry.user_unit,
                    )
                    drawings.append(
                        PdfDrawingFact(
                            fact_id=fact_id,
                            page_id=page_id,
                            kind="curve",
                            bbox=normalized.bbox,
                            normalized_bbox=normalized.normalized_bbox,
                            stroke_width=(
                                normalize_scalar_length(
                                    raw_stroke_width,
                                    user_unit=geometry.user_unit,
                                )
                                if has_stroke
                                else None
                            ),
                            effective_stroke_scale_x=effective_stroke_scale[0],  # type: ignore[index]
                            effective_stroke_scale_y=effective_stroke_scale[1],  # type: ignore[index]
                            effective_stroke_width_x=(
                                effective_stroke_width[0]
                                if effective_stroke_width is not None
                                else None
                            ),
                            effective_stroke_width_y=(
                                effective_stroke_width[1]
                                if effective_stroke_width is not None
                                else None
                            ),
                            graphics_transform=source_affine_transform(matrix),
                            stroke_width_provenance=PdfScalarProvenance(
                                parser_native_value=(
                                    raw_stroke_width if has_stroke else None
                                ),
                                parser_native_semantics=(
                                    "nominal"
                                    if has_stroke and raw_stroke_width is not None
                                    else "unavailable"
                                ),
                                parser_native_unit=(
                                    "pdf_user_space"
                                    if has_stroke and raw_stroke_width is not None
                                    else "unknown"
                                ),
                                canonical_derivation=(
                                    "affine_derived"
                                    if has_stroke and raw_stroke_width is not None
                                    else "unavailable"
                                ),
                                parser_applies_user_unit=False,
                                affine_transform_available=True,
                                source=(
                                    "pdfium_path_object"
                                    if has_stroke and raw_stroke_width is not None
                                    else "unavailable"
                                ),
                            ),
                            bbox_semantics=PdfDrawingBBoxSemantics(
                                kind="parser_object_bounds",
                                quality="approximate",
                                stroke_inclusion="unknown",
                                clipping_application="unknown",
                            ),
                            paint_operation=paint_operation,
                            is_clipping_path=False,
                            path_geometry_version=(
                                PDF_DRAWING_PATH_GEOMETRY_VERSION
                                if path_geometry.source_segment_count
                                else None
                            ),
                            path_segments=list(path_geometry.segments),
                            path_segment_count=path_geometry.source_segment_count,
                            path_segment_count_is_lower_bound=(
                                path_geometry.count_is_lower_bound
                            ),
                            path_segment_truncated=path_geometry.truncated,
                            path_closed=path_geometry.closed,
                            path_geometry_complete=path_geometry.complete,
                            rotation=canonical_text_rotation(
                                text_rotation=_matrix_rotation(matrix),
                                page_rotation=rotation,
                                source=PdfTextRotationSource.PDF_USER_SPACE_COUNTERCLOCKWISE,
                            ),
                            source_order=order,
                            parser_metadata={
                                "pdfium_object_type": "path",
                                "raw_stroke_width": raw_stroke_width,
                                "raw_scalar_unit": "pdf_user_space",
                            },
                            warnings=fact_warnings,
                        )
                    )
                if len(path_objects) > limits.max_drawing_facts_per_page:
                    page_partial = True
                    warning = make_warning(
                        code=PdfWarningCode.DRAWING_LIMIT_REACHED,
                        parser_name=self.parser_name,
                        message="Drawing facts on this page were truncated by the configured limit.",
                        page_number=page_number,
                    )
                    state.warnings.add_page(warning, target=page_warnings)
                if path_segment_limit_reached:
                    warning = make_warning(
                        code=PdfWarningCode.PATH_SEGMENT_LIMIT_REACHED,
                        parser_name=self.parser_name,
                        message="Drawing path segments on this page were truncated by the configured limit.",
                        page_number=page_number,
                    )
                    state.warnings.add_page(warning, target=page_warnings)

            if options.include_image_regions:
                image_objects = [
                    item
                    for item in page_objects
                    if item.type == pdfium_raw.FPDF_PAGEOBJ_IMAGE
                ]
                for item in image_objects[: limits.max_image_regions_per_page]:
                    normalized = _normalize_pdfium_bbox(
                        bbox=item.get_bounds(),
                        geometry=geometry,
                        rotation=rotation,
                    )
                    if normalized.bbox is None or normalized.normalized_bbox is None:
                        page_partial = True
                        add_page_warning(
                            state=state,
                            page_warnings=page_warnings,
                            code=PdfWarningCode.INVALID_BBOX,
                            message="A parser-provided image box was outside page bounds.",
                            page_number=page_number,
                        )
                        continue
                    order = next_order()
                    pixel_width, pixel_height = item.get_px_size()
                    fact_id = fact_identifier(
                        source_hash=source_hash,
                        parser_name=self.parser_name,
                        parser_version=self.parser_version,
                        page_number=page_number,
                        fact_type="image_region",
                        source_order=order,
                        bbox=normalized.bbox,
                    )
                    fact_warnings = []
                    if (
                        fact_bbox_dimension_warning(
                            bbox=normalized.bbox,
                            fact_kind="image_region",
                        )
                        is PdfWarningCode.ZERO_AREA_BBOX
                    ):
                        add_fact_warning(
                            state=state,
                            fact_warnings=fact_warnings,
                            code=PdfWarningCode.ZERO_AREA_BBOX,
                            message="The parser-provided image box has zero area.",
                            page_number=page_number,
                            fact_id=fact_id,
                        )
                    image_regions.append(
                        PdfImageRegionFact(
                            fact_id=fact_id,
                            page_id=page_id,
                            bbox=normalized.bbox,
                            normalized_bbox=normalized.normalized_bbox,
                            pixel_width=(int(pixel_width) if pixel_width > 0 else None),
                            pixel_height=(
                                int(pixel_height) if pixel_height > 0 else None
                            ),
                            image_type="unknown",
                            parser_available=True,
                            source_order=order,
                            warnings=fact_warnings,
                        )
                    )
                if len(image_objects) > limits.max_image_regions_per_page:
                    page_partial = True
                    warning = make_warning(
                        code=PdfWarningCode.IMAGE_LIMIT_REACHED,
                        parser_name=self.parser_name,
                        message="Image-region facts on this page were truncated by the configured limit.",
                        page_number=page_number,
                    )
                    state.warnings.add_page(warning, target=page_warnings)

            return PdfPageFacts(
                page_id=page_id,
                page_number=page_number,
                media_box=geometry.media_box,
                crop_box=geometry.crop_box,
                effective_page_box=geometry.effective_page_box,
                effective_page_box_basis=geometry.effective_page_box_basis,
                effective_origin_x=geometry.effective_page_box.x0,
                effective_origin_y=geometry.effective_page_box.y0,
                user_unit=geometry.user_unit,
                coordinate_transform=coordinate_transform_provenance(
                    parser_coordinate_space="pdf_user_space_absolute",
                    parser_page_box_basis="media_crop_intersection",
                    parser_applies_page_rotation=False,
                    parser_applies_user_unit=False,
                    canonical_page_box_basis=geometry.effective_page_box_basis,
                    **geometry_provenance,
                ),
                original_width=geometry.original_width,
                original_height=geometry.original_height,
                rotation=rotation,
                canonical_width=geometry.canonical_width,
                canonical_height=geometry.canonical_height,
                text_spans=text_spans,
                words=[],
                line_candidates=[],
                characters=characters,
                drawings=drawings,
                image_regions=image_regions,
                text_span_count=len(text_spans),
                word_count=0,
                line_candidate_count=0,
                character_count=len(characters),
                drawing_count=len(drawings),
                image_region_count=len(image_regions),
                warnings=page_warnings,
                extraction_status=(
                    PdfExtractionStatus.PARTIAL
                    if page_partial
                    else PdfExtractionStatus.SUCCESS
                ),
            )
        finally:
            textpage.close()

    def _terminal_open_failure(
        self,
        *,
        source: PdfSource,
        limits: PdfExtractionLimits,
        options: PdfExtractionOptions,
        started_at: float,
        error: Exception,
    ) -> PdfFactArtifact:
        encrypted = "password" in str(error).casefold()
        return terminal_artifact(
            source=source,
            parser_name=self.parser_name,
            parser_version=self.parser_version,
            capabilities=self.capabilities(),
            limits=limits,
            options=options,
            status=(
                PdfExtractionStatus.ENCRYPTED
                if encrypted
                else PdfExtractionStatus.MALFORMED
            ),
            warning=make_warning(
                code=(
                    PdfWarningCode.ENCRYPTED_DOCUMENT
                    if encrypted
                    else PdfWarningCode.MALFORMED_DOCUMENT
                ),
                parser_name=self.parser_name,
                message=(
                    "Encrypted PDFs are outside the Phase 1A extraction boundary."
                    if encrypted
                    else "The PDF parser could not open the document."
                ),
                severity=PdfWarningSeverity.ERROR,
                recoverable=False,
            ),
            started_at=started_at,
        )

    def _terminal_parser_error(
        self,
        *,
        source: PdfSource,
        limits: PdfExtractionLimits,
        options: PdfExtractionOptions,
        started_at: float,
        error: Exception,
    ) -> PdfFactArtifact:
        del error
        return terminal_artifact(
            source=source,
            parser_name=self.parser_name,
            parser_version=self.parser_version,
            capabilities=self.capabilities(),
            limits=limits,
            options=options,
            status=PdfExtractionStatus.PARSER_ERROR,
            warning=make_warning(
                code=PdfWarningCode.PARSER_EXCEPTION,
                parser_name=self.parser_name,
                message="The PDF parser failed without exposing document content.",
                severity=PdfWarningSeverity.ERROR,
                recoverable=False,
            ),
            started_at=started_at,
        )


def _normalize_pdfium_bbox(
    *,
    bbox: Any,
    geometry: PdfCanonicalPageGeometry,
    rotation: int,
) -> PdfCoordinateNormalizationResult:
    x0, y0, x1, y1 = (float(value) for value in bbox)
    return normalize_bbox(
        bbox=(min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1)),
        original_width=geometry.original_width,
        original_height=geometry.original_height,
        page_rotation=rotation,
        source_space=PdfSourceCoordinateSpace.BOTTOM_LEFT_Y_UP_UNROTATED,
        source_origin_x=geometry.source_effective_box[0],
        source_origin_y=geometry.source_effective_box[1],
        user_unit=geometry.user_unit,
    )


def _pdfium_path_geometry(
    *,
    item: Any,
    matrix: tuple[float, float, float, float, float, float],
    geometry: Any,
    rotation: int,
    retained_limit: int,
    source_scan_limit: int,
) -> _PdfiumPathGeometry:
    try:
        raw_segment_count = int(pdfium_raw.FPDFPath_CountSegments(item.raw))
    except (AttributeError, TypeError, ValueError):
        return _PdfiumPathGeometry((), 0, False, False, None, False)
    if raw_segment_count <= 0:
        return _PdfiumPathGeometry((), 0, False, False, False, True)

    scanned_count = min(raw_segment_count, max(source_scan_limit, 0))
    raw_entries: list[_PdfiumRawPathEntry] = []
    parse_complete = True
    for raw_index in range(scanned_count):
        raw_segment = pdfium_raw.FPDFPath_GetPathSegment(item.raw, raw_index)
        if not raw_segment:
            parse_complete = False
            break
        x_value = c_float()
        y_value = c_float()
        if not pdfium_raw.FPDFPathSegment_GetPoint(
            raw_segment,
            byref(x_value),
            byref(y_value),
        ):
            parse_complete = False
            break
        raw_entries.append(
            _PdfiumRawPathEntry(
                segment_type=int(pdfium_raw.FPDFPathSegment_GetType(raw_segment)),
                point=(float(x_value.value), float(y_value.value)),
                closed=bool(pdfium_raw.FPDFPathSegment_GetClose(raw_segment)),
            )
        )

    source_scan_truncated = len(raw_entries) < raw_segment_count
    logical_segments: list[_PdfiumLogicalPathSegment] = []
    observed_logical_count = 0
    current_point: tuple[float, float] | None = None
    subpath_start: tuple[float, float] | None = None
    subpath_index = -1
    path_closed = False
    raw_index = 0
    while raw_index < len(raw_entries):
        entry = raw_entries[raw_index]
        observed_logical_count += 1
        if entry.segment_type == pdfium_raw.FPDF_SEGMENT_MOVETO:
            subpath_index += 1
            current_point = entry.point
            subpath_start = entry.point
            logical_segments.append(
                _PdfiumLogicalPathSegment(
                    kind="move",
                    start=entry.point,
                    end=entry.point,
                    control_points=(),
                    subpath_index=max(subpath_index, 0),
                    closed=False,
                )
            )
            raw_index += 1
            continue
        if (
            entry.segment_type == pdfium_raw.FPDF_SEGMENT_LINETO
            and current_point is not None
        ):
            path_closed = path_closed or entry.closed
            logical_segments.append(
                _PdfiumLogicalPathSegment(
                    kind="close" if entry.closed else "line",
                    start=current_point,
                    end=entry.point,
                    control_points=(),
                    subpath_index=max(subpath_index, 0),
                    closed=entry.closed,
                )
            )
            current_point = (
                subpath_start if entry.closed and subpath_start else entry.point
            )
            raw_index += 1
            continue
        if (
            entry.segment_type == pdfium_raw.FPDF_SEGMENT_BEZIERTO
            and current_point is not None
        ):
            curve_entries = raw_entries[raw_index : raw_index + 3]
            if len(curve_entries) == 3 and all(
                item.segment_type == pdfium_raw.FPDF_SEGMENT_BEZIERTO
                for item in curve_entries
            ):
                endpoint = curve_entries[2].point
                closed = curve_entries[2].closed
                path_closed = path_closed or closed
                logical_segments.append(
                    _PdfiumLogicalPathSegment(
                        kind="cubic_bezier",
                        start=current_point,
                        end=endpoint,
                        control_points=(
                            curve_entries[0].point,
                            curve_entries[1].point,
                        ),
                        subpath_index=max(subpath_index, 0),
                        closed=closed,
                    )
                )
                current_point = subpath_start if closed and subpath_start else endpoint
                raw_index += 3
                continue
        parse_complete = False
        raw_index += 1

    retained_logical_segments = logical_segments[:retained_limit]
    retention_truncated = len(retained_logical_segments) < len(logical_segments)
    truncated = source_scan_truncated or retention_truncated
    source_segment_count = (
        observed_logical_count + 1 if source_scan_truncated else observed_logical_count
    )
    canonical_segments: list[PdfDrawingPathSegment] = []
    for segment_index, segment in enumerate(retained_logical_segments):
        transformed_points = tuple(
            _transform_pdfium_path_point(point, matrix)
            for point in (
                segment.start,
                segment.end,
                *segment.control_points,
            )
        )
        normalized_points = tuple(
            normalize_point(
                point=point,
                original_width=geometry.original_width,
                original_height=geometry.original_height,
                page_rotation=rotation,
                source_space=PdfSourceCoordinateSpace.BOTTOM_LEFT_Y_UP_UNROTATED,
                source_origin_x=geometry.source_effective_box[0],
                source_origin_y=geometry.source_effective_box[1],
                user_unit=geometry.user_unit,
            ).point
            for point in transformed_points
        )
        if any(point is None for point in normalized_points):
            parse_complete = False
            continue
        canonical_segments.append(
            PdfDrawingPathSegment(
                segment_index=segment_index,
                subpath_index=segment.subpath_index,
                kind=segment.kind,
                start=normalized_points[0],  # type: ignore[arg-type]
                end=normalized_points[1],  # type: ignore[arg-type]
                control_points=list(normalized_points[2:]),  # type: ignore[arg-type]
                closed=segment.closed,
                geometry_quality="precise",
                source_order=segment_index,
            )
        )

    return _PdfiumPathGeometry(
        segments=tuple(canonical_segments),
        source_segment_count=source_segment_count,
        count_is_lower_bound=source_scan_truncated,
        truncated=truncated,
        closed=(None if source_scan_truncated else path_closed),
        complete=(
            not truncated
            and parse_complete
            and len(canonical_segments) == source_segment_count
        ),
    )


def _transform_pdfium_path_point(
    point: tuple[float, float],
    matrix: tuple[float, float, float, float, float, float],
) -> tuple[float, float]:
    a, b, c, d, e, f = (float(value) for value in matrix)
    x, y = point
    return (x * a) + (y * c) + e, (x * b) + (y * d) + f


def _pdfium_page_geometry(
    *,
    page: Any,
    geometry_page: Any | None,
    rotation: int,
) -> tuple[PdfCanonicalPageGeometry, dict[str, Any]]:
    if geometry_page is not None:
        try:
            geometry = canonical_page_geometry(
                media_box=tuple(  # type: ignore[arg-type]
                    float(value) for value in geometry_page.mediabox
                ),
                crop_box=tuple(  # type: ignore[arg-type]
                    float(value) for value in geometry_page.cropbox
                ),
                page_rotation=rotation,
                user_unit=float(geometry_page.get("/UserUnit", 1)),
            )
            return geometry, {
                "geometry_source": "pypdf_page_dictionary_for_pdfium",
                "geometry_completeness": "complete",
                "geometry_confidence": "high",
                "assumed_origin": False,
                "assumed_user_unit": False,
                "fallback_provider": None,
            }
        except Exception:
            pass

    assumed_origin = False
    completeness = "partial"
    geometry_source = "pdfium_page_boxes_without_user_unit"
    try:
        media_box = tuple(float(value) for value in page.get_mediabox())
        crop_box = tuple(float(value) for value in page.get_cropbox())
        geometry = canonical_page_geometry(
            media_box=media_box,  # type: ignore[arg-type]
            crop_box=crop_box,  # type: ignore[arg-type]
            page_rotation=rotation,
            user_unit=1,
        )
    except Exception:
        visual_width, visual_height = (float(value) for value in page.get_size())
        unrotated_width, unrotated_height = (
            (visual_height, visual_width)
            if rotation in (90, 270)
            else (visual_width, visual_height)
        )
        geometry = canonical_page_geometry(
            media_box=(0, 0, unrotated_width, unrotated_height),
            crop_box=None,
            page_rotation=rotation,
            user_unit=1,
        )
        assumed_origin = True
        completeness = "assumed"
        geometry_source = "pdfium_visual_size_assumed_origin"
    return geometry, {
        "geometry_source": geometry_source,
        "geometry_completeness": completeness,
        "geometry_confidence": "low",
        "assumed_origin": assumed_origin,
        "assumed_user_unit": True,
        "fallback_provider": "pypdfium2",
    }


def _pdfium_stroke_width(item: Any) -> float | None:
    raw_width = c_float()
    try:
        if not pdfium_raw.FPDFPageObj_GetStrokeWidth(item.raw, byref(raw_width)):
            return None
    except (AttributeError, TypeError, ValueError):
        return None
    return _optional_nonnegative_float(raw_width.value)


def _pdfium_paint_operation(item: Any) -> PdfPaintOperation:
    fill_mode = c_int()
    stroked = c_int()
    try:
        available = pdfium_raw.FPDFPath_GetDrawMode(
            item.raw,
            byref(fill_mode),
            byref(stroked),
        )
    except (AttributeError, TypeError, ValueError):
        return "unknown"
    if not available:
        return "unknown"
    filled = fill_mode.value != 0
    if bool(stroked.value) and filled:
        return "fill_stroke"
    if bool(stroked.value):
        return "stroke"
    if filled:
        return "fill"
    return "unknown"


def _pdfium_character_angle(*, textpage: Any, index: int) -> float | None:
    """Return PDFium's per-character angle in unrotated visual clockwise degrees."""
    try:
        radians = float(pdfium_raw.FPDFText_GetCharAngle(textpage.raw, index))
    except (AttributeError, TypeError, ValueError, pdfium.PdfiumError):
        return None
    if not math.isfinite(radians) or radians < 0:
        return None
    return math.degrees(radians) % 360


def _matrix_rotation(matrix: Any) -> float:
    values = tuple(float(value) for value in matrix)
    return math.degrees(math.atan2(values[1], values[0])) % 360


def _optional_nonnegative_float(value: object) -> float | None:
    try:
        parsed = float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return None
    if not math.isfinite(parsed) or parsed < 0:
        return None
    return parsed

"""Bounded references to one invocation's native pdfplumber characters."""

from __future__ import annotations

import math
from typing import TYPE_CHECKING, Any, Literal, TypedDict

from document_sdk.pdf._structural_engine.facts.contracts import (
    PDF_TEXT_MEMBER_LIGATURES,
    PDF_TEXT_MEMBER_METHOD_VERSION,
    PdfBoundingBox,
    PdfNormalizedBoundingBox,
    PdfTextGranularity,
    PdfTextMember,
    PdfTextProjectionPart,
    PdfTextSourceGroup,
)
from document_sdk.pdf._structural_engine.facts.coordinates import (
    PdfCanonicalPageGeometry,
    PdfSourceCoordinateSpace,
    normalize_bbox,
    source_affine_transform,
    transform_bbox_without_admission,
)
from document_sdk.pdf._structural_engine.facts.identifiers import (
    text_member_identifier,
    text_source_group_identifier,
)
from document_sdk.pdf._structural_engine.facts.normalization import (
    canonical_json_serialized_size,
    make_warning,
)
from document_sdk.pdf._structural_engine.facts.status import (
    PdfFactWarning,
    PdfWarningCode,
)

if TYPE_CHECKING:
    from collections.abc import Callable, Sequence

    from document_sdk.pdf._structural_engine.facts.native_text_contracts import (
        PdfNativeTextEventEvidence,
    )
    from document_sdk.pdf._structural_engine.parsers.common import (
        PdfParserExtractionState,
    )

_BBoxTuple = tuple[float, float, float, float]
_GeometryStatus = Literal["INSIDE", "INTERSECTS", "OUTSIDE", "ZERO_AREA", "INVALID"]
_ProjectionStatus = Literal["EXACT", "TRANSFORMED", "UNRESOLVED", "NOT_CAPTURED"]
_Disposition = Literal[
    "ADMITTED",
    "GEOMETRY_REJECTED",
    "FACT_LIMIT_REJECTED",
    "SEGMENTATION_SUPERSEDED",
]


class _CoordinateArguments(TypedDict):
    original_width: float
    original_height: float
    page_rotation: int
    source_space: PdfSourceCoordinateSpace
    source_origin_x: float
    source_origin_y: float
    user_unit: float


class _MembershipFields(TypedDict):
    member_ids: tuple[str, ...]
    source_member_count: int
    source_group_id: str
    member_inventory_status: Literal["COMPLETE", "PARTIAL"]
    member_projection_status: _ProjectionStatus
    member_projection: tuple[PdfTextProjectionPart, ...]


class _NativeMemberFields(TypedDict):
    parser_advance: float | None
    source_writing_mode: Literal["HORIZONTAL", "VERTICAL", "UNKNOWN"]
    native_text_event_id: str | None
    native_text_event_ordinal: int | None
    native_text_event_member_ordinal: int | None
    native_character_ordinal: int | None


_MAX_MEMBER_TEXT = 1_000_000
_MAX_FONT_NAME = 256
_SURROGATE_START = 0xD800
_SURROGATE_END = 0xDFFF


def _projection(  # noqa: C901 - Every supported transform remains explicit.
    text: str, members: Sequence[PdfTextMember]
) -> tuple[_ProjectionStatus, tuple[PdfTextProjectionPart, ...]]:
    """Reconstruct the observed projection without discarding unknown changes."""
    parts: list[PdfTextProjectionPart] = []
    offset = 0
    for member in members:
        value = member.text
        transform: Literal["IDENTITY", "LIGATURE_EXPANSION"] = "IDENTITY"
        expanded = PDF_TEXT_MEMBER_LIGATURES.get(value)
        if expanded is not None and not text.startswith(value, offset):
            value = expanded
            transform = "LIGATURE_EXPANSION"
        if not text.startswith(value, offset):
            if member.text.isspace():
                parts.append(
                    PdfTextProjectionPart(
                        member_id=member.member_id,
                        output_start=offset,
                        output_end=offset,
                        transform="OMITTED_WHITESPACE",
                    )
                )
                continue
            end = offset
            while end < len(text) and text[end].isspace():
                end += 1
            if end > offset:
                parts.append(
                    PdfTextProjectionPart(
                        output_start=offset,
                        output_end=end,
                        transform="INSERTED_WHITESPACE",
                    )
                )
                offset = end
            if not text.startswith(value, offset):
                return "UNRESOLVED", ()
        end = offset + len(value)
        parts.append(
            PdfTextProjectionPart(
                member_id=member.member_id,
                output_start=offset,
                output_end=end,
                transform=transform,
            )
        )
        offset = end
    if offset < len(text):
        if not text[offset:].isspace():
            return "UNRESOLVED", ()
        parts.append(
            PdfTextProjectionPart(
                output_start=offset,
                output_end=len(text),
                transform="INSERTED_WHITESPACE",
            )
        )
    if not members and text:
        return "UNRESOLVED", ()
    status: _ProjectionStatus = (
        "EXACT"
        if all(part.transform == "IDENTITY" for part in parts)
        else "TRANSFORMED"
    )
    return status, tuple(parts)


class PdfPlumberTextMemberPool:
    """Per-page source pool using existing global warning/fact/byte guardrails."""

    def __init__(  # noqa: PLR0913 - Explicit finite parser invocation context.
        self,
        *,
        source_hash: str,
        parser_name: str,
        parser_version: str,
        page_id: str,
        page_number: int,
        geometry: PdfCanonicalPageGeometry,
        visual_effective_box: tuple[float, float, float, float],
        page_rotation: int,
        state: PdfParserExtractionState,
        requested: bool,
        rotation_for_item: Callable[[dict[str, Any]], float],
    ) -> None:
        self.source_hash = source_hash
        self.parser_name = parser_name
        self.parser_version = parser_version
        self.page_id = page_id
        self.page_number = page_number
        self.geometry = geometry
        self.state = state
        self.requested = requested
        self.rotation_for_item = rotation_for_item
        self.members: list[PdfTextMember] = []
        self.by_native_id: dict[int, PdfTextMember] = {}
        self.source_count = 0
        self.member_bytes = 0
        self.native_evidence: PdfNativeTextEventEvidence | None = None
        self.native_evidence_bytes = 0
        self.native_capture_status: Literal["NOT_CAPTURED", "COMPLETE", "PARTIAL"] = (
            "NOT_CAPTURED"
        )
        self.native_event_ids: set[str] = set()
        self.reference_bytes = 0
        self.groups: list[PdfTextSourceGroup] = []
        self.group_bytes = 2 if requested else 0
        self.source_group_count = 0
        self.group_truncated = False
        self.truncated = False
        self.projection_incomplete = False
        self._limit_codes: set[PdfWarningCode] = set()
        self._coordinate_arguments: _CoordinateArguments = {
            "original_width": geometry.original_width,
            "original_height": geometry.original_height,
            "page_rotation": page_rotation,
            "source_space": PdfSourceCoordinateSpace.TOP_LEFT_Y_DOWN_VISUAL,
            "source_origin_x": visual_effective_box[0],
            "source_origin_y": visual_effective_box[1],
            "user_unit": geometry.user_unit,
        }

    def _limit(self, code: PdfWarningCode) -> None:
        self.truncated = True
        self.state.resource_limited = True
        if code not in self._limit_codes:
            self._limit_codes.add(code)
            self.state.warnings.add_fields(
                code=code,
                page_number=self.page_number,
                message=(
                    "Source text-member evidence reached its configured finite limit."
                ),
            )

    def _observe_geometry(
        self, item: dict[str, Any]
    ) -> tuple[
        _BBoxTuple | None,
        PdfBoundingBox | None,
        PdfBoundingBox | None,
        PdfNormalizedBoundingBox | None,
        _GeometryStatus,
    ]:
        raw: _BBoxTuple | None
        geometry_status: _GeometryStatus
        try:
            raw = (
                float(item["x0"]),
                float(item["top"]),
                float(item["x1"]),
                float(item["bottom"]),
            )
        except (KeyError, TypeError, ValueError):
            raw = None
        if raw is not None and (
            not all(math.isfinite(value) for value in raw)
            or raw[0] > raw[2]
            or raw[1] > raw[3]
        ):
            raw = None
        parser_bbox = (
            PdfBoundingBox(x0=raw[0], y0=raw[1], x1=raw[2], y1=raw[3])
            if raw is not None
            else None
        )
        observed = (
            transform_bbox_without_admission(bbox=raw, **self._coordinate_arguments)
            if raw is not None
            else None
        )
        admitted = (
            normalize_bbox(bbox=raw, **self._coordinate_arguments)
            if raw is not None
            else None
        )
        normalized = admitted.normalized_bbox if admitted is not None else None
        if observed is None:
            geometry_status = "INVALID"
        elif normalized is not None:
            # Reuse only the existing tolerance clamp; do not enlarge it.
            if admitted is None or admitted.bbox is None:
                message = "admitted geometry result is missing"
                raise RuntimeError(message)
            observed = admitted.bbox
            geometry_status = (
                "ZERO_AREA"
                if observed.x0 == observed.x1 or observed.y0 == observed.y1
                else "INSIDE"
            )
        elif (
            observed.x1 < 0
            or observed.y1 < 0
            or observed.x0 > self.geometry.canonical_width
            or observed.y0 > self.geometry.canonical_height
        ):
            geometry_status = "OUTSIDE"
        else:
            geometry_status = "INTERSECTS"
        return raw, parser_bbox, observed, normalized, geometry_status

    def _native_member_fields(self, item: dict[str, Any]) -> _NativeMemberFields:
        value = item.get("adv")
        advance = (
            float(value)
            if isinstance(value, (int, float))
            and not isinstance(value, bool)
            and math.isfinite(value)
            and value >= 0
            else None
        )
        result: _NativeMemberFields = {
            "parser_advance": advance,
            "source_writing_mode": "UNKNOWN",
            "native_text_event_id": None,
            "native_text_event_ordinal": None,
            "native_text_event_member_ordinal": None,
            "native_character_ordinal": None,
        }
        event_id = item.get("_native_text_show_event_id")
        if not isinstance(event_id, str) or event_id not in self.native_event_ids:
            return result
        event_ordinal = item.get("_native_text_show_event_ordinal")
        member_ordinal = item.get("_native_text_show_member_ordinal")
        native_ordinal = item.get("_native_character_ordinal")
        mode = item.get("_native_writing_mode")
        if any(
            type(index) is not int or index < 0
            for index in (event_ordinal, member_ordinal, native_ordinal)
        ) or mode not in ("HORIZONTAL", "VERTICAL", "UNKNOWN"):
            message = "native parser bridge has an invalid observed member identity"
            raise ValueError(message)
        result["native_text_event_id"] = event_id
        result["native_text_event_ordinal"] = event_ordinal
        result["native_text_event_member_ordinal"] = member_ordinal
        result["native_character_ordinal"] = native_ordinal
        result["source_writing_mode"] = mode
        return result

    def _retain_native_evidence(
        self, evidence: PdfNativeTextEventEvidence | None
    ) -> None:
        if evidence is None:
            return
        cost = evidence.wire_size()
        if (
            cost + self.group_bytes + 2
            > self.state.limits.max_text_member_bytes_per_page
        ):
            self.native_capture_status = "PARTIAL"
            self._limit(PdfWarningCode.TEXT_MEMBER_BYTES_LIMIT_REACHED)
            return
        self.native_evidence = evidence
        self.native_evidence_bytes = cost
        self.native_capture_status = evidence.availability
        self.native_event_ids = {event.source_event_id for event in evidence.events}
        if evidence.availability != "COMPLETE":
            self.projection_incomplete = True
            self.state.warnings.add_fields(
                code=PdfWarningCode.TEXT_MEMBER_PROJECTION_INCOMPLETE,
                page_number=self.page_number,
                message=(
                    "Native text-show evidence is incomplete; source direction "
                    "or operation membership may be unavailable."
                ),
            )

    def _observe_member(
        self,
        item: dict[str, Any],
        source_index: int,
        text: str,
        dedupe_relations: dict[int, int],
    ) -> PdfTextMember:
        raw, parser_bbox, observed, normalized, geometry_status = (
            self._observe_geometry(item)
        )
        matrix = source_affine_transform(item.get("matrix"))
        matrix_values = (
            (matrix.a, matrix.b, matrix.c, matrix.d, matrix.e, matrix.f)
            if matrix is not None
            else None
        )
        native_fields = self._native_member_fields(item)
        member_id = text_member_identifier(
            source_hash=self.source_hash,
            parser_name=self.parser_name,
            parser_version=self.parser_version,
            method_version=PDF_TEXT_MEMBER_METHOD_VERSION,
            page_number=self.page_number,
            source_character_index=source_index,
            text=text,
            parser_bbox=raw,
            matrix=matrix_values,
            **native_fields,
        )
        representative = dedupe_relations.get(id(item), id(item))
        selection: Literal["DEDUPE_SUPPRESSED", "RETAINED", "GEOMETRY_REJECTED"] = (
            "DEDUPE_SUPPRESSED"
            if representative != id(item)
            else "RETAINED"
            if normalized is not None
            else "GEOMETRY_REJECTED"
        )
        font_name = item.get("fontname")
        if not isinstance(font_name, str) or len(font_name) > _MAX_FONT_NAME:
            font_name = None
        size = item.get("size")
        if not isinstance(size, (int, float)) or not math.isfinite(size) or size < 0:
            size = None
        warning = None
        if geometry_status in {"INVALID", "OUTSIDE", "INTERSECTS", "ZERO_AREA"}:
            warning = make_warning(
                code=PdfWarningCode.ZERO_AREA_BBOX
                if geometry_status == "ZERO_AREA"
                else PdfWarningCode.INVALID_BBOX,
                parser_name=self.parser_name,
                page_number=self.page_number,
                fact_id=member_id,
                message=(
                    "Source member geometry is uncertain or "
                    "outside admitted page bounds."
                ),
            )
        rotation_value = self.rotation_for_item(item)
        observed_rotation = rotation_value if math.isfinite(rotation_value) else None
        # Reserve a possible duplicate link before collection completes.
        return PdfTextMember(
            member_id=member_id,
            page_id=self.page_id,
            source_character_index=source_index,
            text=text,
            parser_bbox=parser_bbox,
            bbox=observed,
            normalized_bbox=normalized,
            text_transform=matrix,
            font_name=font_name,
            parser_font_size=size,
            **native_fields,
            rotation=observed_rotation,
            geometry_status=geometry_status,
            selection_state=selection,
            warnings=[warning] if warning is not None else [],
        )

    def collect(
        self,
        chars: Sequence[dict[str, Any]],
        dedupe_relations: dict[int, int],
        *,
        native_evidence: PdfNativeTextEventEvidence | None = None,
    ) -> None:
        if not self.requested:
            return
        self._retain_native_evidence(native_evidence)
        self.source_count = len(chars)
        self.member_bytes = 2
        limits = self.state.limits
        maximum = min(
            limits.max_text_members_per_page,
            limits.max_characters_per_page,
            max(0, limits.max_total_facts - self.state.total_facts),
        )
        for source_index, item in enumerate(chars):
            if self.state.timed_out():
                self.truncated = True
                break
            if len(self.members) >= maximum:
                self._limit(PdfWarningCode.TEXT_MEMBER_LIMIT_REACHED)
                break
            if id(item) in self.by_native_id:
                self.truncated = True
                self.state.warnings.add_fields(
                    code=PdfWarningCode.TEXT_MEMBER_PROJECTION_INCOMPLETE,
                    page_number=self.page_number,
                    message=(
                        "Repeated native object identity prevents "
                        "a unique occurrence binding."
                    ),
                )
                continue
            text = str(item.get("text") or "")
            if (
                not text
                or len(text) > _MAX_MEMBER_TEXT
                or any(_SURROGATE_START <= ord(char) <= _SURROGATE_END for char in text)
            ):
                self.truncated = True
                self.state.warnings.add_fields(
                    code=PdfWarningCode.TEXT_MEMBER_PROJECTION_INCOMPLETE,
                    page_number=self.page_number,
                    message=(
                        "A source member has unavailable or unsupported decoded text."
                    ),
                )
                continue
            provisional = self._observe_member(
                item, source_index, text, dedupe_relations
            )
            cost = canonical_json_serialized_size(
                provisional.model_dump(mode="json")
            ) + (1 if self.members else 0)
            duplicate_reserve = (
                29 if provisional.selection_state == "DEDUPE_SUPPRESSED" else 0
            )
            if (
                self.member_bytes
                + self.native_evidence_bytes
                + self.reference_bytes
                + self.group_bytes
                + cost
                + duplicate_reserve
                > limits.max_text_member_bytes_per_page
            ):
                self._limit(PdfWarningCode.TEXT_MEMBER_BYTES_LIMIT_REACHED)
                break
            actual_warnings: list[PdfFactWarning] = []
            for warning in provisional.warnings:
                self.state.warnings.add_fact(warning, target=actual_warnings)
            member = provisional.model_copy(update={"warnings": actual_warnings})
            self.members.append(member)
            self.by_native_id[id(item)] = member
            self.member_bytes += (
                canonical_json_serialized_size(member.model_dump(mode="json"))
                + (1 if len(self.members) > 1 else 0)
                + duplicate_reserve
            )
        self._resolve_dedupe(dedupe_relations)

    def _resolve_dedupe(self, dedupe_relations: dict[int, int]) -> None:
        # Resolve only retained representatives. Source identity does not change.
        for native_id, member in tuple(self.by_native_id.items()):
            if member.selection_state != "DEDUPE_SUPPRESSED":
                continue
            representative = self.by_native_id.get(
                dedupe_relations.get(native_id, native_id)
            )
            if representative is None:
                self.truncated = True
                continue
            self.by_native_id[native_id] = member.model_copy(
                update={"duplicate_of_member_id": representative.member_id}
            )
        self.members = list(self.by_native_id.values())
        self.member_bytes = (
            2
            + max(0, len(self.members) - 1)
            + sum(
                canonical_json_serialized_size(member.model_dump(mode="json"))
                for member in self.members
            )
        )
        if (
            self.member_bytes
            + self.native_evidence_bytes
            + self.reference_bytes
            + self.group_bytes
            > self.state.limits.max_text_member_bytes_per_page
        ):
            message = "member admission accountant exceeded its exact byte budget"
            raise RuntimeError(message)

    def bind(  # noqa: PLR0913 - Records one exact parser grouping and disposition.
        self,
        *,
        item: dict[str, Any],
        granularity: PdfTextGranularity,
        source_group_order: int,
        text: str,
        disposition: _Disposition | None = None,
        parent_fact_id: str | None = None,
    ) -> dict[str, Any]:
        if not self.requested:
            return {}
        raw_members = item.get("chars") or (
            [item] if granularity == "character" else []
        )
        unique_native = dict.fromkeys(id(char) for char in raw_members)
        members = [
            self.by_native_id[identity]
            for identity in unique_native
            if identity in self.by_native_id
        ]
        complete = len(members) == len(unique_native) and bool(members)
        status, projection = (
            _projection(text, members) if complete else ("UNRESOLVED", ())
        )
        values: _MembershipFields = {
            "member_ids": tuple(member.member_id for member in members),
            "source_member_count": len(unique_native),
            "source_group_id": text_source_group_identifier(
                source_hash=self.source_hash,
                page_id=self.page_id,
                method_version=PDF_TEXT_MEMBER_METHOD_VERSION,
                granularity=granularity,
                source_group_order=source_group_order,
                text=text,
            ),
            "member_inventory_status": "COMPLETE" if complete else "PARTIAL",
            "member_projection_status": status,
            "member_projection": projection,
        }
        serializable = {
            **values,
            "member_projection": [part.model_dump(mode="json") for part in projection],
        }
        cost = (
            canonical_json_serialized_size(serializable)
            if disposition in {None, "ADMITTED"}
            else 0
        )
        group = None
        group_cost = 0
        if disposition is not None:
            self.source_group_count += 1
            if disposition == "FACT_LIMIT_REJECTED":
                self.group_truncated = True
            _raw, parser_box, box, _normalized, geometry_status = (
                self._observe_geometry(item)
            )
            group = PdfTextSourceGroup(
                **values,
                page_id=self.page_id,
                granularity=granularity,
                source_group_order=source_group_order,
                parent_fact_id=parent_fact_id,
                derived_from_source_group_id=item.get("_member_parent_group"),
                text=text,
                parser_bbox=parser_box,
                bbox=box,
                geometry_status=geometry_status,
                disposition=disposition,
            )
            group_cost = canonical_json_serialized_size(
                group.model_dump(mode="json")
            ) + (1 if self.groups else 0)
        if (
            self.member_bytes
            + self.native_evidence_bytes
            + self.reference_bytes
            + self.group_bytes
            + cost
            + group_cost
            > self.state.limits.max_text_member_bytes_per_page
        ):
            self._limit(PdfWarningCode.TEXT_MEMBER_BYTES_LIMIT_REACHED)
            self.group_truncated = disposition is not None or self.group_truncated
            # Refuse the Fact append instead of emitting a false binding.
            return {"_member_budget_rejected": True}
        self.reference_bytes += cost
        if group is not None:
            self.groups.append(group)
            self.group_bytes += group_cost
        if status == "UNRESOLVED":
            self.projection_incomplete = True
            self.state.warnings.add_fields(
                code=PdfWarningCode.TEXT_MEMBER_PROJECTION_INCOMPLETE,
                page_number=self.page_number,
                message=(
                    "A text Fact retains incomplete or "
                    "unresolved source-member projection."
                ),
            )
        return dict(values)

    def recover_inside_runs(
        self, item: dict[str, Any], evidence: dict[str, Any]
    ) -> list[dict[str, Any]]:
        """Recover only source-contiguous, independently admitted member geometry."""
        if evidence.get("member_inventory_status") != "COMPLETE" or evidence.get(
            "member_projection_status"
        ) not in {"EXACT", "TRANSFORMED"}:
            return []
        source_group_id = evidence.get("source_group_id")
        if source_group_id is None or evidence.get("_member_budget_rejected"):
            return []
        raw_members = item.get("chars") or []
        native = {
            self.by_native_id[id(char)].member_id: char
            for char in raw_members
            if id(char) in self.by_native_id
        }
        members = {member.member_id: member for member in self.members}
        projection = {
            part.member_id: part
            for part in evidence["member_projection"]
            if part.member_id is not None
        }
        runs: list[list[PdfTextMember]] = []
        run: list[PdfTextMember] = []
        for member_id in evidence["member_ids"]:
            member = members[member_id]
            usable = (
                member.selection_state == "RETAINED"
                and member.geometry_status == "INSIDE"
                and member.parser_bbox is not None
                and member.bbox is not None
                and member.bbox.x1 > member.bbox.x0
                and member.bbox.y1 > member.bbox.y0
                and member_id in native
                and member_id in projection
            )
            if usable:
                run.append(member)
            elif run:
                runs.append(run)
                run = []
        if run:
            runs.append(run)
        recovered = []
        text = str(item.get("text") or "")
        for selected in runs:
            start = projection[selected[0].member_id].output_start
            end = projection[selected[-1].member_id].output_end
            projected = text[start:end]
            boxes = [
                member.parser_bbox
                for member in selected
                if member.parser_bbox is not None
            ]
            if not projected or not projected.strip() or len(boxes) != len(selected):
                continue
            recovered.append(
                {
                    **item,
                    "text": projected,
                    "x0": min(box.x0 for box in boxes),
                    "top": min(box.y0 for box in boxes),
                    "x1": max(box.x1 for box in boxes),
                    "bottom": max(box.y1 for box in boxes),
                    "chars": [native[member.member_id] for member in selected],
                    "_member_parent_group": source_group_id,
                }
            )
        return recovered

    def page_values(self) -> dict[str, Any]:
        if not self.requested:
            return {}
        return {
            "text_members": self.members,
            "native_text_event_evidence": self.native_evidence,
            "native_text_event_capture_status": self.native_capture_status,
            "native_text_event_serialized_bytes": self.native_evidence_bytes,
            "text_source_groups": self.groups,
            "text_source_group_count": len(self.groups),
            "source_text_group_count": self.source_group_count,
            "text_source_group_truncated": self.group_truncated,
            "text_source_group_serialized_bytes": self.group_bytes,
            "text_member_method_version": PDF_TEXT_MEMBER_METHOD_VERSION,
            "text_member_inventory_status": "TRUNCATED"
            if self.truncated
            else "COMPLETE",
            "text_member_count": len(self.members),
            "source_text_member_count": self.source_count,
            "text_member_serialized_bytes": self.member_bytes,
            "text_member_reference_bytes": self.reference_bytes,
        }

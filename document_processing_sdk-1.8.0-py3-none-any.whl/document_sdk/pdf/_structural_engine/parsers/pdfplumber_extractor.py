# ruff: noqa: BLE001, C901, E501, EM101, EM102, FBT003, PLR0911, PLR0912, PLR0913, PLR0915, PLR2004, TRY003

import json
import math
from dataclasses import dataclass
from importlib.metadata import version
from io import BytesIO
from itertools import groupby
from operator import itemgetter
from time import perf_counter
from typing import TYPE_CHECKING, Any, Literal, cast

import pdfplumber

if TYPE_CHECKING:
    from collections.abc import Callable, Sequence

    from pdfplumber.pdf import PDF
from pdfminer.pdfdocument import PDFDocument, PDFPasswordIncorrect
from pdfminer.pdfparser import PDFParser, PDFSyntaxError
from pdfminer.pdftypes import resolve_all
from pdfplumber.page import FilteredPage, Page
from pdfplumber.utils.clustering import cluster_objects

from document_sdk.pdf._structural_engine.facts.capabilities import PdfParserCapabilities
from document_sdk.pdf._structural_engine.facts.contracts import (
    PDF_DRAWING_PATH_GEOMETRY_VERSION,
    PdfDrawingBBoxSemantics,
    PdfDrawingFact,
    PdfDrawingKind,
    PdfDrawingPathSegment,
    PdfDrawingPathSegmentKind,
    PdfFactArtifact,
    PdfImageRegionFact,
    PdfPageFacts,
    PdfPaintOperation,
    PdfScalarProvenance,
    PdfTextFact,
    PdfTextGranularity,
    PdfWritingDirection,
)
from document_sdk.pdf._structural_engine.facts.coordinates import (
    PdfCanonicalPageGeometry,
    PdfCoordinateNormalizationResult,
    PdfSourceCoordinateSpace,
    PdfTextRotationSource,
    canonical_affine_scale_components,
    canonical_page_geometry,
    canonical_text_rotation,
    coordinate_transform_provenance,
    fact_bbox_dimension_warning,
    normalize_bbox,
    normalize_point,
    source_affine_transform,
)
from document_sdk.pdf._structural_engine.facts.identifiers import (
    fact_identifier,
    page_identifier,
    source_sha256,
)
from document_sdk.pdf._structural_engine.facts.limits import (
    PdfExtractionLimits,
    PdfExtractionOptions,
    PdfSource,
)
from document_sdk.pdf._structural_engine.facts.native_text_contracts import (
    PdfNativeTextEventEvidence,
)
from document_sdk.pdf._structural_engine.facts.normalization import (
    build_size_limited_artifact,
    make_warning,
    source_preflight_warning,
    terminal_artifact,
)
from document_sdk.pdf._structural_engine.facts.status import (
    PdfExtractionStatus,
    PdfFactWarning,
    PdfWarningCode,
    PdfWarningSeverity,
)
from document_sdk.pdf._structural_engine.parsers.common import (
    PdfParserExtractionState,
    add_fact_warning,
    add_page_warning,
    add_requested_capability_warnings,
    normalized_page_rotation,
    resolve_extraction_scope,
)
from document_sdk.pdf._structural_engine.parsers.native_text_events import (
    open_native_evidence_pdf,
)
from document_sdk.pdf._structural_engine.parsers.rotated_member_runs import (
    exact_rotated_member_run,
    exact_spaced_member_run,
    native_run_items,
)
from document_sdk.pdf._structural_engine.parsers.text_members import (
    PdfPlumberTextMemberPool,
)
from document_sdk.pdf._xref_keyword_recovery import verified_parser_view


@dataclass(frozen=True)
class _PdfPlumberPathGeometry:
    segments: tuple[PdfDrawingPathSegment, ...]
    source_segment_count: int
    truncated: bool
    closed: bool | None
    complete: bool


def _dedupe_visible_text_page(
    page: Page,
    *,
    dedupe_relations: dict[int, int] | None = None,
    member_native_ids: frozenset[int] | None = None,
) -> FilteredPage:
    """Preserve pinned pdfplumber clustering without repeated list.index scans.

    Selection uses the same attributes, tolerance, stable grouping and minimum
    position as pdfplumber 0.11.9. Selected objects retain their original source
    order. Equal dictionaries cluster together, and stable selection retains
    their first occurrence, so identity positions have the same order as the
    reference's equality-based list.index result.
    """
    chars = [
        char for char in page.chars if char.get("_native_clip_excluded") is not True
    ]
    key = itemgetter("upright", "text", "fontname", "size")
    position = itemgetter("doctop", "x0")
    selected: set[int] = set()
    for _, group in groupby(sorted(chars, key=key), key=key):
        for row in cluster_objects(list(group), itemgetter("doctop"), 0.1):
            for column in cluster_objects(row, itemgetter("x0"), 0.1):
                representative = id(min(column, key=position))
                selected.add(representative)
                if dedupe_relations is not None:
                    for character in column:
                        if (
                            member_native_ids is None
                            or id(character) in member_native_ids
                        ):
                            dedupe_relations[id(character)] = representative
    ordered = []
    for char in chars:
        identity = id(char)
        if identity in selected:
            ordered.append(char)
            selected.remove(identity)
    result = FilteredPage(page, lambda _: True)
    # Match the pinned Page.dedupe_chars page projection and preserve all
    # non-character objects; no backend/global monkey patch is installed.
    result._objects = page.objects.copy()  # noqa: SLF001
    result._objects["char"] = ordered  # noqa: SLF001
    return result


def _tag_text_groups(
    items: "Sequence[Any]",
    granularity: PdfTextGranularity,
) -> list[tuple[dict[str, Any], PdfTextGranularity]]:
    """Preserve backend objects while fixing the finite granularity type."""
    return [(cast("dict[str, Any]", item), granularity) for item in items]


class PdfPlumberFactExtractor:
    parser_name = "pdfplumber"

    @property
    def parser_version(self) -> str:
        return version("pdfplumber")

    def capabilities(self) -> PdfParserCapabilities:
        return PdfParserCapabilities(
            page_geometry=True,
            text_spans=True,
            words=True,
            line_candidates=True,
            optional_characters=True,
            text_members=True,
            font_name=True,
            font_size=False,
            text_rotation=True,
            writing_direction=True,
            drawings=True,
            drawing_lines=True,
            drawing_rectangles=True,
            drawing_curves=True,
            image_regions=True,
            text_bbox_quality="precise",
            native_engine=False,
            text_affine_transform=True,
            effective_font_size=False,
            nominal_stroke_width=False,
            drawing_affine_transform=False,
            drawing_paint_operation=True,
            drawing_path_segments=True,
            character_rotation=True,
            drawing_bbox_quality="approximate",
            graphics_state_fidelity="partial",
            selected_page_extraction=True,
        )

    def extract(
        self,
        source: PdfSource,
        *,
        limits: PdfExtractionLimits,
        options: PdfExtractionOptions,
        password: str | None = None,
    ) -> PdfFactArtifact:
        started_at = perf_counter()
        preflight = source_preflight_warning(
            source=source,
            parser_name=self.parser_name,
            limits=limits,
        )
        if preflight is not None:
            status, warning = preflight
            return terminal_artifact(
                source=source,
                parser_name=self.parser_name,
                parser_version=self.parser_version,
                capabilities=self.capabilities(),
                limits=limits,
                options=options,
                status=status,
                warning=warning,
                started_at=started_at,
            )

        try:
            PDFDocument(
                PDFParser(BytesIO(verified_parser_view(source.content))),
                password=password or "",
            )
        except PDFPasswordIncorrect:
            return self._terminal_encrypted(source, limits, options, started_at)
        except PDFSyntaxError as error:
            return self._terminal_malformed(source, limits, options, started_at, error)
        pdf: PDF
        try:
            if options.include_text_members:
                configuration = {
                    "unicode_norm": "NFC",
                    "strict_metadata": False,
                    "parser_version": self.parser_version,
                    "extraction_options": options.model_dump(mode="json"),
                    "resource_limits": limits.model_dump(mode="json"),
                }
                pdf = open_native_evidence_pdf(
                    BytesIO(verified_parser_view(source.content)),
                    source_sha256=source_sha256(source.content),
                    parser_configuration_identity=source_sha256(
                        json.dumps(
                            configuration,
                            ensure_ascii=False,
                            sort_keys=True,
                            separators=(",", ":"),
                            allow_nan=False,
                        ).encode()
                    ),
                    maximum_events=limits.max_text_members_per_page,
                    maximum_members=min(
                        limits.max_text_members_per_page,
                        limits.max_characters_per_page,
                        limits.max_total_facts,
                    ),
                    maximum_bytes=max(2, limits.max_text_member_bytes_per_page - 4),
                    unicode_norm="NFC",
                    strict_metadata=False,
                    password=password,
                )
            else:
                pdf = pdfplumber.open(
                    BytesIO(verified_parser_view(source.content)),
                    unicode_norm="NFC",
                    strict_metadata=False,
                    password=password,
                )
        except PDFPasswordIncorrect:
            return self._terminal_encrypted(source, limits, options, started_at)
        except (PDFSyntaxError, OSError, ValueError, TypeError, KeyError) as error:
            return self._terminal_malformed(source, limits, options, started_at, error)
        except Exception as error:
            return self._terminal_parser_error(
                source, limits, options, started_at, error
            )

        try:
            page_count = len(pdf.pages)
            state = PdfParserExtractionState(
                parser_name=self.parser_name,
                limits=limits,
                started_at=started_at,
            )
            add_requested_capability_warnings(
                state=state,
                capabilities=self.capabilities(),
                options=options,
            )
            pages: list[PdfPageFacts] = []
            resolved_scope = resolve_extraction_scope(
                page_count=page_count,
                options=options,
                state=state,
            )
            if resolved_scope.invalid:
                return build_size_limited_artifact(
                    source=source,
                    parser_name=self.parser_name,
                    parser_version=self.parser_version,
                    capabilities=self.capabilities(),
                    limits=limits,
                    options=options,
                    status=PdfExtractionStatus.INVALID_REQUEST,
                    page_count=page_count,
                    pages=[],
                    warnings=state.warnings.final_items(),
                    warning_suppression=state.warnings.suppression_summary(),
                    started_at=started_at,
                    pages_attempted=0,
                    partial_extraction=False,
                )
            source_hash = source_sha256(source.content)
            for page_number in resolved_scope.page_numbers:
                if state.timed_out():
                    break
                state.pages_attempted += 1
                page_index = page_number - 1
                try:
                    page = self._extract_page(
                        page=pdf.pages[page_index],
                        page_number=page_number,
                        source_hash=source_hash,
                        limits=limits,
                        options=options,
                        state=state,
                    )
                except (
                    PDFSyntaxError,
                    OSError,
                    ValueError,
                    TypeError,
                    KeyError,
                    AttributeError,
                ):
                    state.page_failed = True
                    state.warnings.add_fields(
                        code=PdfWarningCode.PARTIAL_PAGE_FAILURE,
                        message="A PDF page could not be converted into canonical facts.",
                        page_number=page_number,
                    )
                    continue
                if not state.add_page(page, pages):
                    break
            status, partial = state.status(
                pages=pages,
                requested_page_numbers=resolved_scope.page_numbers,
            )
            if status is PdfExtractionStatus.NO_TEXT_LAYER:
                state.warnings.add_fields(
                    code=PdfWarningCode.NO_TEXT_LAYER,
                    message="No extractable electronic text layer was found.",
                    recoverable=False,
                )
            return build_size_limited_artifact(
                source=source,
                parser_name=self.parser_name,
                parser_version=self.parser_version,
                capabilities=self.capabilities(),
                limits=limits,
                options=options,
                status=status,
                page_count=page_count,
                pages=pages,
                warnings=state.warnings.final_items(),
                warning_suppression=state.warnings.suppression_summary(),
                started_at=started_at,
                pages_attempted=state.pages_attempted,
                partial_extraction=partial,
            )
        finally:
            pdf.close()

    def _extract_page(
        self,
        *,
        page: Any,
        page_number: int,
        source_hash: str,
        limits: PdfExtractionLimits,
        options: PdfExtractionOptions,
        state: PdfParserExtractionState,
    ) -> PdfPageFacts:
        page_warnings: list[PdfFactWarning] = []
        page_partial = False
        rotation, rotation_valid = normalized_page_rotation(page.rotation or 0)
        raw_media_box = _resolved_page_box(page, "MediaBox")
        raw_crop_box = _resolved_page_box(page, "CropBox", fallback=raw_media_box)
        user_unit = float(resolve_all(page.page_obj.attrs.get("UserUnit", 1)))
        geometry = canonical_page_geometry(
            media_box=raw_media_box,
            crop_box=raw_crop_box,
            page_rotation=rotation,
            user_unit=user_unit,
        )
        visual_effective_box = _intersect_visual_boxes(
            tuple(float(value) for value in page.mediabox),  # type: ignore[arg-type]
            tuple(float(value) for value in page.cropbox),  # type: ignore[arg-type]
        )
        if not rotation_valid:
            page_partial = True
            add_page_warning(
                state=state,
                page_warnings=page_warnings,
                code=PdfWarningCode.UNSUPPORTED_ROTATION,
                message="A PDF page declared an unsupported rotation.",
                page_number=page_number,
            )
        page_id = page_identifier(
            source_hash=source_hash,
            parser_name=self.parser_name,
            parser_version=self.parser_version,
            page_number=page_number,
        )
        source_order = 0
        text_spans: list[PdfTextFact] = []
        words: list[PdfTextFact] = []
        line_candidates: list[PdfTextFact] = []
        characters: list[PdfTextFact] = []
        drawings: list[PdfDrawingFact] = []
        image_regions: list[PdfImageRegionFact] = []
        retained_path_segment_count = 0
        path_segment_limit_reached = False

        def next_order() -> int:
            nonlocal source_order
            value = source_order
            source_order += 1
            return value

        dedupe_relations: dict[int, int] | None = (
            {} if options.include_text_members else None
        )
        member_native_ids = (
            frozenset(
                id(char)
                for char in page.chars[
                    : min(
                        limits.max_text_members_per_page,
                        limits.max_characters_per_page,
                        max(0, limits.max_total_facts - state.total_facts),
                    )
                ]
            )
            if options.include_text_members
            else None
        )
        visible_text_page = _dedupe_visible_text_page(
            page, dedupe_relations=dedupe_relations, member_native_ids=member_native_ids
        )
        member_pool = PdfPlumberTextMemberPool(
            source_hash=source_hash,
            parser_name=self.parser_name,
            parser_version=self.parser_version,
            page_id=page_id,
            page_number=page_number,
            geometry=geometry,
            visual_effective_box=visual_effective_box,
            page_rotation=rotation,
            state=state,
            requested=options.include_text_members,
            rotation_for_item=lambda item: canonical_text_rotation(
                text_rotation=_plumber_text_rotation(item),
                page_rotation=rotation,
                source=PdfTextRotationSource.VISUAL_SPACE_COUNTERCLOCKWISE,
            ),
        )
        if options.include_text_members:
            native_report = cast(
                "Callable[[], dict[str, Any]] | None",
                getattr(page, "native_text_event_evidence", None),
            )
            evidence = None
            if callable(native_report):
                raw_native_evidence = dict(native_report())
                raw_native_evidence.pop("reserved_bytes", None)
                evidence = PdfNativeTextEventEvidence.model_validate(
                    raw_native_evidence
                )
            else:
                member_pool.projection_incomplete = True
                state.warnings.add_fields(
                    code=PdfWarningCode.TEXT_MEMBER_PROJECTION_INCOMPLETE,
                    page_number=page_number,
                    message="Native text-show evidence was not captured by this parser page instance.",
                )
            member_pool.collect(
                page.chars, dedupe_relations or {}, native_evidence=evidence
            )
        member_group_order = 0
        text_fact_count = 0
        text_truncated = False
        member_evidence_budget_exhausted = False

        def add_text(
            *,
            target: list[PdfTextFact],
            item: dict[str, Any],
            granularity: Literal["character", "word", "text_span", "line_candidate"],
        ) -> bool:
            nonlocal member_evidence_budget_exhausted
            nonlocal member_group_order, page_partial, text_fact_count, text_truncated
            text = str(item.get("text") or "")
            current_group_order = member_group_order
            member_group_order += 1
            if not text or (granularity != "character" and not text.strip()):
                return True
            if (
                granularity != "character"
                and text_fact_count >= limits.max_text_facts_per_page
            ):
                page_partial = True
                text_truncated = True
                rejected = member_pool.bind(
                    item=item,
                    granularity=granularity,
                    source_group_order=current_group_order,
                    text=text,
                    disposition="FACT_LIMIT_REJECTED",
                )
                if rejected.get("_member_budget_rejected"):
                    member_evidence_budget_exhausted = True
                return False
            normalized = _normalize_visual_item_bbox(
                item=item,
                geometry=geometry,
                visual_effective_box=visual_effective_box,
                rotation=rotation,
            )
            if normalized.bbox is None or normalized.normalized_bbox is None:
                page_partial = True
                rejected_group = member_pool.bind(
                    item=item,
                    granularity=granularity,
                    source_group_order=current_group_order,
                    text=text,
                    disposition="GEOMETRY_REJECTED",
                )
                add_page_warning(
                    state=state,
                    page_warnings=page_warnings,
                    code=PdfWarningCode.INVALID_BBOX,
                    message="A parser-provided text box was outside page bounds.",
                    page_number=page_number,
                )
                if rejected_group.get("_member_budget_rejected"):
                    member_evidence_budget_exhausted = True
                    return False
                if granularity != "character" and not item.get("_member_parent_group"):
                    for recovered_item in member_pool.recover_inside_runs(
                        item, rejected_group
                    ):
                        if not add_text(
                            target=target, item=recovered_item, granularity=granularity
                        ):
                            return False
                return True
            order = next_order()
            fact_id = fact_identifier(
                source_hash=source_hash,
                parser_name=self.parser_name,
                parser_version=self.parser_version,
                page_number=page_number,
                fact_type=granularity,
                source_order=order,
                bbox=normalized.bbox,
                text=text,
            )
            member_evidence = member_pool.bind(
                item=item,
                granularity=granularity,
                source_group_order=current_group_order,
                text=text,
                disposition="ADMITTED",
                parent_fact_id=fact_id,
            )
            if member_evidence.pop("_member_budget_rejected", False):
                page_partial = True
                member_evidence_budget_exhausted = True
                return False
            chars = item.get("chars") or []
            first_char = chars[0] if chars else item
            direction = _writing_direction(item.get("direction"), first_char)
            fact_warnings: list[PdfFactWarning] = []
            if (
                fact_bbox_dimension_warning(
                    bbox=normalized.bbox,
                    fact_kind="text",
                )
                is PdfWarningCode.ZERO_AREA_BBOX
            ):
                add_fact_warning(
                    state=state,
                    fact_warnings=fact_warnings,
                    code=PdfWarningCode.ZERO_AREA_BBOX,
                    message="The parser-provided text box has zero area.",
                    page_number=page_number,
                    fact_id=fact_id,
                )
            parser_font_size = _optional_nonnegative_float(first_char.get("size"))
            raw_font_size = _plumber_font_size(first_char)
            text_transform = source_affine_transform(first_char.get("matrix"))
            effective_font_scale = canonical_affine_scale_components(
                first_char.get("matrix"),
                user_unit=geometry.user_unit,
            )
            target.append(
                PdfTextFact(
                    fact_id=fact_id,
                    page_id=page_id,
                    granularity=granularity,
                    **member_evidence,
                    text=text,
                    bbox=normalized.bbox,
                    normalized_bbox=normalized.normalized_bbox,
                    source_order=order,
                    font_name=_optional_string(first_char.get("fontname")),
                    font_size=None,
                    effective_font_scale_x=(
                        effective_font_scale[0]
                        if effective_font_scale is not None
                        else None
                    ),
                    effective_font_scale_y=(
                        effective_font_scale[1]
                        if effective_font_scale is not None
                        else None
                    ),
                    effective_font_size_x=None,
                    effective_font_size_y=None,
                    text_transform=text_transform,
                    font_size_provenance=PdfScalarProvenance(
                        parser_native_value=parser_font_size,
                        parser_native_semantics=(
                            "effective_visual_aggregate"
                            if parser_font_size is not None
                            else "unavailable"
                        ),
                        parser_native_unit=(
                            "pdf_user_space"
                            if parser_font_size is not None
                            else "unknown"
                        ),
                        canonical_derivation=(
                            "parser_native_only"
                            if parser_font_size is not None
                            else "unavailable"
                        ),
                        parser_applies_user_unit=False,
                        affine_transform_available=text_transform is not None,
                        source=(
                            "pdfminer_glyph_extent"
                            if parser_font_size is not None
                            else "unavailable"
                        ),
                    ),
                    rotation=canonical_text_rotation(
                        text_rotation=_plumber_text_rotation(first_char),
                        page_rotation=rotation,
                        source=PdfTextRotationSource.VISUAL_SPACE_COUNTERCLOCKWISE,
                    ),
                    writing_direction=direction,
                    parser_metadata={
                        **(
                            {
                                "source_run_projection": item["_native_source_run"],
                                **(
                                    {
                                        "source_run_charspace": item[
                                            "_native_source_spacing"
                                        ][0],
                                        "source_run_wordspace": item[
                                            "_native_source_spacing"
                                        ][1],
                                    }
                                    if "_native_source_spacing" in item
                                    else {}
                                ),
                            }
                            if item.get("_native_source_run")
                            else {}
                        ),
                        "upright": bool(first_char.get("upright", True)),
                        "coordinate_space": "visual_top_left",
                        "raw_font_size": raw_font_size,
                        "parser_font_size": parser_font_size,
                        "raw_scalar_unit": "pdf_user_space",
                    },
                    warnings=fact_warnings,
                )
            )
            if granularity != "character":
                text_fact_count += 1
            return True

        line_items = visible_text_page.extract_text_lines(
            strip=False,
            return_chars=True,
            use_text_flow=True,
        )
        word_items = visible_text_page.extract_words(
            extra_attrs=["fontname", "size"],
            return_chars=True,
            use_text_flow=True,
        )
        rotated_run = exact_rotated_member_run(
            member_pool.members,
            inventory_complete=(
                member_pool.requested
                and not member_pool.truncated
                and len(member_pool.members) == member_pool.source_count
            ),
            native_capture_complete=member_pool.native_capture_status == "COMPLETE",
        )
        spaced_run = rotated_run is None
        if spaced_run:
            rotated_run = exact_spaced_member_run(
                member_pool.members,
                page.chars,
                inventory_complete=(
                    member_pool.requested
                    and not member_pool.truncated
                    and len(member_pool.members) == member_pool.source_count
                ),
                native_capture_complete=member_pool.native_capture_status == "COMPLETE",
            )
        native_items = (
            native_run_items(
                rotated_run,
                [
                    char
                    for char in page.chars
                    if char.get("_native_clip_excluded") is not True
                ],
                member_pool.by_native_id,
                spacing=(
                    page.chars[0]["_native_horizontal_spacing"] if spaced_run else None
                ),
            )
            if rotated_run is not None
            else None
        )
        if native_items is not None:
            # Preserve backend grouping before replacing only this proven single
            # native baseline. No original grouping is relabelled as an admitted Fact.
            replaced_groups = (
                _tag_text_groups(line_items, "text_span")
                + _tag_text_groups(line_items, "line_candidate")
                + _tag_text_groups(word_items, "word")
            )
            group_budget_ok = True
            for old_item, old_granularity in replaced_groups:
                old_text = str(old_item.get("text") or "")
                if not old_text or not old_text.strip():
                    continue
                old_evidence = member_pool.bind(
                    item=old_item,
                    granularity=old_granularity,
                    source_group_order=member_group_order,
                    text=old_text,
                    disposition="SEGMENTATION_SUPERSEDED",
                )
                member_group_order += 1
                if old_evidence.get("_member_budget_rejected"):
                    group_budget_ok = False
                    page_partial = True
                    text_truncated = True
                    member_evidence_budget_exhausted = True
                    break
            if group_budget_ok:
                line_items, word_items = native_items
            else:
                line_items, word_items = [], []
        aggregate_text_available = True
        prioritize_body_spans = not (page.lines or page.rects or page.curves)
        for item in line_items:
            if not add_text(target=text_spans, item=item, granularity="text_span"):
                aggregate_text_available = False
                break
            if not prioritize_body_spans and not add_text(
                target=line_candidates, item=item, granularity="line_candidate"
            ):
                aggregate_text_available = False
                break
        # Text-only pages reserve body spans before their alternative line view.
        # Drawing/table pages retain their established Fact order and IDs.
        if aggregate_text_available and prioritize_body_spans:
            for item in line_items:
                if not add_text(
                    target=line_candidates,
                    item=item,
                    granularity="line_candidate",
                ):
                    aggregate_text_available = False
                    break
        if aggregate_text_available:
            for item in word_items:
                if not add_text(target=words, item=item, granularity="word"):
                    break

        if options.include_characters and not member_evidence_budget_exhausted:
            for item in page.chars[: limits.max_characters_per_page]:
                if not add_text(
                    target=characters,
                    item=item,
                    granularity="character",
                ):
                    break
            if len(page.chars) > limits.max_characters_per_page:
                page_partial = True
                warning = make_warning(
                    code=PdfWarningCode.CHARACTER_LIMIT_REACHED,
                    parser_name=self.parser_name,
                    message="Character facts on this page were truncated by the configured limit.",
                    page_number=page_number,
                )
                state.warnings.add_page(warning, target=page_warnings)

        if options.include_drawings:
            drawing_items: list[tuple[PdfDrawingKind, dict[str, Any]]] = [
                *(("line", item) for item in page.lines),
                *(("rectangle", item) for item in page.rects),
                *(("curve", item) for item in page.curves),
            ]
            for kind, item in drawing_items[: limits.max_drawing_facts_per_page]:
                normalized = _normalize_visual_item_bbox(
                    item=item,
                    geometry=geometry,
                    visual_effective_box=visual_effective_box,
                    rotation=rotation,
                )
                if normalized.bbox is None or normalized.normalized_bbox is None:
                    page_partial = True
                    add_page_warning(
                        state=state,
                        page_warnings=page_warnings,
                        code=PdfWarningCode.INVALID_BBOX,
                        message="A parser-provided drawing box was outside page bounds.",
                        page_number=page_number,
                    )
                    continue
                order = next_order()
                fact_id = fact_identifier(
                    source_hash=source_hash,
                    parser_name=self.parser_name,
                    parser_version=self.parser_version,
                    page_number=page_number,
                    fact_type=kind,
                    source_order=order,
                    bbox=normalized.bbox,
                )
                fact_warnings: list[PdfFactWarning] = []
                if (
                    fact_bbox_dimension_warning(
                        bbox=normalized.bbox,
                        fact_kind=kind,
                        path_present=kind == "curve",
                    )
                    is PdfWarningCode.ZERO_AREA_BBOX
                ):
                    add_fact_warning(
                        state=state,
                        fact_warnings=fact_warnings,
                        code=PdfWarningCode.ZERO_AREA_BBOX,
                        message="The parser-provided drawing box has zero area.",
                        page_number=page_number,
                        fact_id=fact_id,
                    )
                raw_stroke_width = _optional_nonnegative_float(item.get("linewidth"))
                paint_operation = _plumber_paint_operation(item)
                fill_luminance = (
                    _plumber_fill_luminance(item.get("non_stroking_color"))
                    if paint_operation in {"fill", "fill_stroke"}
                    else None
                )
                remaining_page_segments = max(
                    limits.max_path_segments_per_page - retained_path_segment_count,
                    0,
                )
                path_geometry = _pdfplumber_path_geometry(
                    item=item,
                    geometry=geometry,
                    visual_effective_box=visual_effective_box,
                    rotation=rotation,
                    retained_limit=min(
                        limits.max_path_segments_per_drawing,
                        remaining_page_segments,
                    ),
                )
                retained_path_segment_count += len(path_geometry.segments)
                if path_geometry.truncated:
                    page_partial = True
                    path_segment_limit_reached = True
                drawings.append(
                    PdfDrawingFact(
                        fact_id=fact_id,
                        page_id=page_id,
                        kind=kind,
                        bbox=normalized.bbox,
                        normalized_bbox=normalized.normalized_bbox,
                        stroke_width=None,
                        effective_stroke_width_x=None,
                        effective_stroke_width_y=None,
                        graphics_transform=None,
                        stroke_width_provenance=PdfScalarProvenance(
                            parser_native_value=raw_stroke_width,
                            parser_native_semantics=(
                                "effective_visual_aggregate"
                                if raw_stroke_width is not None
                                else "unavailable"
                            ),
                            parser_native_unit=(
                                "pdf_user_space"
                                if raw_stroke_width is not None
                                else "unknown"
                            ),
                            canonical_derivation=(
                                "parser_native_only"
                                if raw_stroke_width is not None
                                else "unavailable"
                            ),
                            parser_applies_user_unit=False,
                            affine_transform_available=False,
                            source=(
                                "pdfminer_transformed_linewidth"
                                if raw_stroke_width is not None
                                else "unavailable"
                            ),
                        ),
                        bbox_semantics=PdfDrawingBBoxSemantics(
                            kind="path_geometry",
                            quality=(
                                "precise"
                                if kind in {"line", "rectangle"}
                                else "approximate"
                            ),
                            stroke_inclusion="excluded",
                            clipping_application="unknown",
                        ),
                        paint_operation=paint_operation,
                        is_clipping_path=False,
                        path_geometry_version=(
                            PDF_DRAWING_PATH_GEOMETRY_VERSION
                            if path_geometry.source_segment_count
                            else None
                        ),
                        path_segments=list(path_geometry.segments),
                        path_segment_count=path_geometry.source_segment_count,
                        path_segment_truncated=path_geometry.truncated,
                        path_closed=path_geometry.closed,
                        path_geometry_complete=path_geometry.complete,
                        rotation=None,
                        source_order=order,
                        parser_metadata={
                            "coordinate_space": "visual_top_left",
                            "raw_stroke_width": raw_stroke_width,
                            "raw_scalar_unit": "pdf_user_space",
                            **(
                                {"fill_luminance": fill_luminance}
                                if fill_luminance is not None
                                else {}
                            ),
                        },
                        warnings=fact_warnings,
                    )
                )
            if len(drawing_items) > limits.max_drawing_facts_per_page:
                page_partial = True
                warning = make_warning(
                    code=PdfWarningCode.DRAWING_LIMIT_REACHED,
                    parser_name=self.parser_name,
                    message="Drawing facts on this page were truncated by the configured limit.",
                    page_number=page_number,
                )
                state.warnings.add_page(warning, target=page_warnings)
            if path_segment_limit_reached:
                warning = make_warning(
                    code=PdfWarningCode.PATH_SEGMENT_LIMIT_REACHED,
                    parser_name=self.parser_name,
                    message="Drawing path segments on this page were truncated by the configured limit.",
                    page_number=page_number,
                )
                state.warnings.add_page(warning, target=page_warnings)

        if options.include_image_regions:
            for item in page.images[: limits.max_image_regions_per_page]:
                normalized = _normalize_visual_item_bbox(
                    item=item,
                    geometry=geometry,
                    visual_effective_box=visual_effective_box,
                    rotation=rotation,
                )
                if normalized.bbox is None or normalized.normalized_bbox is None:
                    page_partial = True
                    add_page_warning(
                        state=state,
                        page_warnings=page_warnings,
                        code=PdfWarningCode.INVALID_BBOX,
                        message="A parser-provided image box was outside page bounds.",
                        page_number=page_number,
                    )
                    continue
                order = next_order()
                pixel_width, pixel_height = _image_pixel_size(item)
                fact_id = fact_identifier(
                    source_hash=source_hash,
                    parser_name=self.parser_name,
                    parser_version=self.parser_version,
                    page_number=page_number,
                    fact_type="image_region",
                    source_order=order,
                    bbox=normalized.bbox,
                )
                fact_warnings = []
                if (
                    fact_bbox_dimension_warning(
                        bbox=normalized.bbox,
                        fact_kind="image_region",
                    )
                    is PdfWarningCode.ZERO_AREA_BBOX
                ):
                    add_fact_warning(
                        state=state,
                        fact_warnings=fact_warnings,
                        code=PdfWarningCode.ZERO_AREA_BBOX,
                        message="The parser-provided image box has zero area.",
                        page_number=page_number,
                        fact_id=fact_id,
                    )
                image_regions.append(
                    PdfImageRegionFact(
                        fact_id=fact_id,
                        page_id=page_id,
                        bbox=normalized.bbox,
                        normalized_bbox=normalized.normalized_bbox,
                        pixel_width=pixel_width,
                        pixel_height=pixel_height,
                        image_type="unknown",
                        parser_available=True,
                        source_order=order,
                        warnings=fact_warnings,
                    )
                )
            if len(page.images) > limits.max_image_regions_per_page:
                page_partial = True
                warning = make_warning(
                    code=PdfWarningCode.IMAGE_LIMIT_REACHED,
                    parser_name=self.parser_name,
                    message="Image-region facts on this page were truncated by the configured limit.",
                    page_number=page_number,
                )
                state.warnings.add_page(warning, target=page_warnings)

        if text_truncated:
            warning = make_warning(
                code=PdfWarningCode.TEXT_FACT_LIMIT_REACHED,
                parser_name=self.parser_name,
                message="Text facts on this page were truncated by the configured limit.",
                page_number=page_number,
            )
            state.warnings.add_page(warning, target=page_warnings)
        return PdfPageFacts(
            page_id=page_id,
            page_number=page_number,
            media_box=geometry.media_box,
            crop_box=geometry.crop_box,
            effective_page_box=geometry.effective_page_box,
            effective_page_box_basis=geometry.effective_page_box_basis,
            effective_origin_x=geometry.effective_page_box.x0,
            effective_origin_y=geometry.effective_page_box.y0,
            user_unit=geometry.user_unit,
            coordinate_transform=coordinate_transform_provenance(
                parser_coordinate_space="visual_top_left_absolute",
                parser_page_box_basis="media_box",
                parser_applies_page_rotation=True,
                parser_applies_user_unit=False,
                canonical_page_box_basis=geometry.effective_page_box_basis,
                geometry_source="pdfminer_page_dictionary",
            ),
            original_width=geometry.original_width,
            original_height=geometry.original_height,
            rotation=rotation,
            canonical_width=geometry.canonical_width,
            canonical_height=geometry.canonical_height,
            text_spans=text_spans,
            words=words,
            line_candidates=line_candidates,
            characters=characters,
            drawings=drawings,
            image_regions=image_regions,
            **member_pool.page_values(),
            text_span_count=len(text_spans),
            word_count=len(words),
            line_candidate_count=len(line_candidates),
            character_count=len(characters),
            drawing_count=len(drawings),
            image_region_count=len(image_regions),
            warnings=page_warnings,
            extraction_status=(
                PdfExtractionStatus.PARTIAL
                if page_partial
                or member_pool.truncated
                or member_pool.projection_incomplete
                else PdfExtractionStatus.SUCCESS
            ),
        )

    def _terminal_encrypted(
        self,
        source: PdfSource,
        limits: PdfExtractionLimits,
        options: PdfExtractionOptions,
        started_at: float,
    ) -> PdfFactArtifact:
        return terminal_artifact(
            source=source,
            parser_name=self.parser_name,
            parser_version=self.parser_version,
            capabilities=self.capabilities(),
            limits=limits,
            options=options,
            status=PdfExtractionStatus.ENCRYPTED,
            warning=make_warning(
                code=PdfWarningCode.ENCRYPTED_DOCUMENT,
                parser_name=self.parser_name,
                message="Encrypted PDF access requires a valid password or supported security handler.",
                severity=PdfWarningSeverity.ERROR,
                recoverable=False,
            ),
            started_at=started_at,
        )

    def _terminal_malformed(
        self,
        source: PdfSource,
        limits: PdfExtractionLimits,
        options: PdfExtractionOptions,
        started_at: float,
        error: Exception,
    ) -> PdfFactArtifact:
        del error
        return terminal_artifact(
            source=source,
            parser_name=self.parser_name,
            parser_version=self.parser_version,
            capabilities=self.capabilities(),
            limits=limits,
            options=options,
            status=PdfExtractionStatus.MALFORMED,
            warning=make_warning(
                code=PdfWarningCode.MALFORMED_DOCUMENT,
                parser_name=self.parser_name,
                message="The PDF parser could not open the document.",
                severity=PdfWarningSeverity.ERROR,
                recoverable=False,
            ),
            started_at=started_at,
        )

    def _terminal_parser_error(
        self,
        source: PdfSource,
        limits: PdfExtractionLimits,
        options: PdfExtractionOptions,
        started_at: float,
        error: Exception,
    ) -> PdfFactArtifact:
        del error
        return terminal_artifact(
            source=source,
            parser_name=self.parser_name,
            parser_version=self.parser_version,
            capabilities=self.capabilities(),
            limits=limits,
            options=options,
            status=PdfExtractionStatus.PARSER_ERROR,
            warning=make_warning(
                code=PdfWarningCode.PARSER_EXCEPTION,
                parser_name=self.parser_name,
                message="The PDF parser failed without exposing document content.",
                severity=PdfWarningSeverity.ERROR,
                recoverable=False,
            ),
            started_at=started_at,
        )


def _resolved_page_box(
    page: Any,
    key: str,
    *,
    fallback: tuple[float, float, float, float] | None = None,
) -> tuple[float, float, float, float]:
    value = resolve_all(page.page_obj.attrs.get(key))
    if value is None:
        if fallback is None:
            raise ValueError(f"PDF page is missing {key}")
        return fallback
    if not isinstance(value, (tuple, list)) or len(value) != 4:
        raise ValueError(f"PDF page {key} is invalid")
    return tuple(float(item) for item in value)  # type: ignore[return-value]


def _intersect_visual_boxes(
    first: tuple[float, float, float, float],
    second: tuple[float, float, float, float],
) -> tuple[float, float, float, float]:
    intersection = (
        max(first[0], second[0]),
        max(first[1], second[1]),
        min(first[2], second[2]),
        min(first[3], second[3]),
    )
    if intersection[0] >= intersection[2] or intersection[1] >= intersection[3]:
        raise ValueError("visual MediaBox and CropBox must intersect")
    return intersection


def _normalize_visual_item_bbox(
    *,
    item: dict[str, Any],
    geometry: PdfCanonicalPageGeometry,
    visual_effective_box: tuple[float, float, float, float],
    rotation: int,
) -> PdfCoordinateNormalizationResult:
    return normalize_bbox(
        bbox=(
            float(item["x0"]),
            float(item["top"]),
            float(item["x1"]),
            float(item["bottom"]),
        ),
        original_width=geometry.original_width,
        original_height=geometry.original_height,
        page_rotation=rotation,
        source_space=PdfSourceCoordinateSpace.TOP_LEFT_Y_DOWN_VISUAL,
        source_origin_x=visual_effective_box[0],
        source_origin_y=visual_effective_box[1],
        user_unit=geometry.user_unit,
    )


def _pdfplumber_path_geometry(
    *,
    item: dict[str, Any],
    geometry: Any,
    visual_effective_box: tuple[float, float, float, float],
    rotation: int,
    retained_limit: int,
) -> _PdfPlumberPathGeometry:
    raw_path = item.get("path")
    if not isinstance(raw_path, (tuple, list)) or not raw_path:
        return _PdfPlumberPathGeometry((), 0, False, None, False)

    source_segment_count = len(raw_path)
    truncated = source_segment_count > retained_limit
    current_point: tuple[float, float] | None = None
    subpath_start: tuple[float, float] | None = None
    subpath_index = -1
    path_closed = False
    parse_complete = True
    segments: list[PdfDrawingPathSegment] = []

    for source_order, raw_command in enumerate(raw_path[:retained_limit]):
        if not isinstance(raw_command, (tuple, list)) or not raw_command:
            parse_complete = False
            continue
        operator = str(raw_command[0]).lower()
        raw_start: tuple[float, float] | None = None
        raw_end: tuple[float, float] | None = None
        raw_controls: tuple[tuple[float, float], ...] = ()
        segment_kind: PdfDrawingPathSegmentKind
        closed = False

        if operator == "m":
            raw_end = _pdfplumber_path_point(
                raw_command[1] if len(raw_command) > 1 else None
            )
            if raw_end is None:
                parse_complete = False
                continue
            subpath_index += 1
            current_point = raw_end
            subpath_start = raw_end
            raw_start = raw_end
            segment_kind = "move"
        elif operator == "l" and current_point is not None:
            raw_end = _pdfplumber_path_point(
                raw_command[1] if len(raw_command) > 1 else None
            )
            if raw_end is None:
                parse_complete = False
                continue
            raw_start = current_point
            current_point = raw_end
            segment_kind = "line"
        elif operator == "c" and current_point is not None and len(raw_command) >= 4:
            curve_points = tuple(
                _pdfplumber_path_point(raw_command[index]) for index in range(1, 4)
            )
            if any(point is None for point in curve_points):
                parse_complete = False
                continue
            raw_start = current_point
            raw_controls = (curve_points[0], curve_points[1])  # type: ignore[assignment]
            raw_end = curve_points[2]
            current_point = raw_end
            segment_kind = "cubic_bezier"
        elif (
            operator == "h" and current_point is not None and subpath_start is not None
        ):
            raw_start = current_point
            raw_end = subpath_start
            current_point = subpath_start
            path_closed = True
            closed = True
            segment_kind = "close"
        else:
            parse_complete = False
            continue

        raw_points = (raw_start, raw_end, *raw_controls)
        canonical_points = tuple(
            normalize_point(
                point=point,  # type: ignore[arg-type]
                original_width=geometry.original_width,
                original_height=geometry.original_height,
                page_rotation=rotation,
                source_space=PdfSourceCoordinateSpace.TOP_LEFT_Y_DOWN_VISUAL,
                source_origin_x=visual_effective_box[0],
                source_origin_y=visual_effective_box[1],
                user_unit=geometry.user_unit,
            ).point
            for point in raw_points
        )
        if any(point is None for point in canonical_points):
            parse_complete = False
            continue
        segments.append(
            PdfDrawingPathSegment(
                segment_index=source_order,
                subpath_index=max(subpath_index, 0),
                kind=segment_kind,
                start=canonical_points[0],  # type: ignore[arg-type]
                end=canonical_points[1],  # type: ignore[arg-type]
                control_points=list(canonical_points[2:]),  # type: ignore[arg-type]
                closed=closed,
                geometry_quality=(
                    "approximate" if segment_kind == "cubic_bezier" else "precise"
                ),
                source_order=source_order,
            )
        )

    return _PdfPlumberPathGeometry(
        segments=tuple(segments),
        source_segment_count=source_segment_count,
        truncated=truncated,
        closed=(None if truncated else path_closed),
        complete=(
            not truncated and parse_complete and len(segments) == source_segment_count
        ),
    )


def _pdfplumber_path_point(value: Any) -> tuple[float, float] | None:
    if not isinstance(value, (tuple, list)) or len(value) != 2:
        return None
    try:
        point = float(value[0]), float(value[1])
    except (TypeError, ValueError):
        return None
    if not all(math.isfinite(coordinate) for coordinate in point):
        return None
    return point


def _plumber_text_rotation(item: dict[str, Any]) -> float:
    matrix = item.get("matrix")
    if isinstance(matrix, (tuple, list)) and len(matrix) >= 2:
        try:
            return math.degrees(math.atan2(float(matrix[1]), float(matrix[0]))) % 360
        except (TypeError, ValueError):
            pass
    return 0 if item.get("upright", True) else 90


def _plumber_font_size(item: dict[str, Any]) -> float | None:
    parser_size = _optional_nonnegative_float(item.get("size"))
    if item.get("upright", True):
        return parser_size
    dimensions = [
        value
        for value in (
            parser_size,
            _optional_nonnegative_float(item.get("width")),
            _optional_nonnegative_float(item.get("height")),
        )
        if value is not None
    ]
    return max(dimensions, default=None)


def _plumber_paint_operation(item: dict[str, Any]) -> PdfPaintOperation:
    stroked = bool(item.get("stroke"))
    filled = bool(item.get("fill"))
    if stroked and filled:
        return "fill_stroke"
    if stroked:
        return "stroke"
    if filled:
        return "fill"
    return "unknown"


def _plumber_fill_luminance(value: object) -> float | None:
    """Return bounded device-gray/RGB/CMYK luminance for physical fill evidence."""
    components: tuple[float, ...]
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        components = (float(value),)
    elif isinstance(value, (tuple, list)) and len(value) in {3, 4}:
        try:
            components = tuple(float(component) for component in value)
        except (TypeError, ValueError):
            return None
    else:
        return None
    if not all(
        math.isfinite(component) and 0 <= component <= 1 for component in components
    ):
        return None
    if len(components) == 1:
        return round(components[0], 6)
    if len(components) == 3:
        red, green, blue = components
    else:
        cyan, magenta, yellow, black = components
        red = (1 - cyan) * (1 - black)
        green = (1 - magenta) * (1 - black)
        blue = (1 - yellow) * (1 - black)
    return round(0.2126 * red + 0.7152 * green + 0.0722 * blue, 6)


def _writing_direction(
    value: object,
    item: dict[str, Any],
) -> PdfWritingDirection:
    mapping: dict[str, PdfWritingDirection] = {
        "ltr": "left_to_right",
        "rtl": "right_to_left",
        "ttb": "top_to_bottom",
        "btt": "bottom_to_top",
    }
    if isinstance(value, str) and value in mapping:
        return mapping[value]
    return "left_to_right" if item.get("upright", True) else "top_to_bottom"


def _optional_string(value: object) -> str | None:
    if value is None:
        return None
    normalized = str(value)[:256]
    return normalized or None


def _optional_nonnegative_float(value: object) -> float | None:
    try:
        parsed = float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return None
    if not math.isfinite(parsed) or parsed < 0:
        return None
    return parsed


def _image_pixel_size(item: dict[str, Any]) -> tuple[int | None, int | None]:
    value = item.get("srcsize")
    if not isinstance(value, (tuple, list)) or len(value) != 2:
        return None, None
    try:
        width, height = int(value[0]), int(value[1])
    except (TypeError, ValueError):
        return None, None
    if width <= 0 or height <= 0:
        return None, None
    return width, height

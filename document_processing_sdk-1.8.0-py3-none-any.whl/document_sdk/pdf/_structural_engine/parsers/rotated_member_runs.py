"""Strict same-parser source-run projection for a single rotated text baseline."""

from __future__ import annotations

import math
from itertools import pairwise
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from document_sdk.pdf._structural_engine.facts.contracts import PdfTextMember

_RUN_METHOD = "native_horizontal_advance_chain.v1"
_NUMERIC_ULPS = 32
_MAX_NUMERIC_EPSILON = 1e-9
_SPACING_COMPONENTS = 2


def _near(first: float, second: float) -> bool:
    epsilon = max(math.ulp(first), math.ulp(second), math.ulp(1.0)) * _NUMERIC_ULPS
    return epsilon <= _MAX_NUMERIC_EPSILON and abs(first - second) <= epsilon


def _usable(member: PdfTextMember) -> bool:
    matrix = member.text_transform
    box = member.bbox
    advance = member.parser_advance
    return (
        bool(member.text)
        and member.source_writing_mode == "HORIZONTAL"
        and (
            (
                member.selection_state == "RETAINED"
                and member.geometry_status == "INSIDE"
                and not member.warnings
            )
            or (
                member.selection_state == "GEOMETRY_REJECTED"
                and member.geometry_status in {"OUTSIDE", "INTERSECTS"}
                and all(w.code.value == "invalid_bbox" for w in member.warnings)
            )
        )
        and member.native_text_event_id is not None
        and member.native_text_event_ordinal is not None
        and member.native_character_ordinal is not None
        and member.native_text_event_member_ordinal is not None
        and matrix is not None
        and all(
            math.isfinite(getattr(matrix, k)) for k in ("a", "b", "c", "d", "e", "f")
        )
        and matrix.a * matrix.d - matrix.b * matrix.c > 0
        and math.hypot(matrix.a, matrix.b) > 0
        and advance is not None
        and math.isfinite(advance)
        and advance > 0
        and box is not None
        and box.x0 < box.x1
        and box.y0 < box.y1
        and member.parser_bbox is not None
        and (member.text.isspace() or not any(char.isspace() for char in member.text))
    )


def exact_rotated_member_run(
    members: Sequence[PdfTextMember],
    *,
    inventory_complete: bool,
    native_capture_complete: bool,
) -> tuple[PdfTextMember, ...] | None:
    """Authorize one complete source baseline, never a global column/read order."""
    if not inventory_complete or not native_capture_complete or not members:
        return None
    if not all(_usable(member) for member in members) or len(
        {member.member_id for member in members}
    ) != len(members):
        return None
    first = members[0]
    matrix = first.text_transform
    if matrix is None or (_near(matrix.b, 0.0) and matrix.a > 0):
        return None
    if not any(not member.text.isspace() for member in members):
        return None
    for previous, current in pairwise(members):
        pm, cm = previous.text_transform, current.text_transform
        advance = previous.parser_advance
        if (
            pm is None
            or cm is None
            or advance is None
            or current.page_id != first.page_id
            or current.native_text_event_id != first.native_text_event_id
            or current.source_character_index != previous.source_character_index + 1
            or previous.native_character_ordinal is None
            or current.native_character_ordinal != previous.native_character_ordinal + 1
            or not all(
                _near(getattr(pm, k), getattr(cm, k)) for k in ("a", "b", "c", "d")
            )
            or not _near(pm.e + pm.a * advance, cm.e)
            or not _near(pm.f + pm.b * advance, cm.f)
        ):
            return None
    return tuple(members)


def native_run_items(
    members: Sequence[PdfTextMember],
    raw_chars: Sequence[dict[str, Any]],
    by_native_id: Mapping[int, PdfTextMember],
    *,
    spacing: tuple[float, float] | None = None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]] | None:
    """Project real literal spaces and union original boxes; never invent a glyph."""
    selected = {member.member_id for member in members}
    native = {
        by_native_id[id(char)].member_id: char
        for char in raw_chars
        if id(char) in by_native_id and by_native_id[id(char)].member_id in selected
    }
    if len(native) != len(members):
        return None

    def item(run: Sequence[PdfTextMember]) -> dict[str, Any]:
        chars = [native[member.member_id] for member in run]
        return {
            **chars[0],
            "text": "".join(member.text for member in run),
            "x0": min(char["x0"] for char in chars),
            "top": min(char["top"] for char in chars),
            "x1": max(char["x1"] for char in chars),
            "bottom": max(char["bottom"] for char in chars),
            "chars": chars,
            "_native_source_run": (
                _RUN_METHOD if spacing is None else "native_spaced_advance_chain.v1"
            ),
            **({"_native_source_spacing": spacing} if spacing is not None else {}),
        }

    words: list[dict[str, Any]] = []
    current: list[PdfTextMember] = []

    def word_group_key(member: PdfTextMember) -> tuple[object, object, object]:
        char = native[member.member_id]
        # A qualified text-show event has fixed font state. Rotated glyph-box
        # height is a parser observation, not an independent font-size boundary.
        return char.get("upright"), char.get("fontname"), member.native_text_event_id

    for member in members:
        if member.text.isspace():
            if current:
                words.append(item(current))
                current = []
            continue
        if current and word_group_key(current[-1]) != word_group_key(member):
            words.append(item(current))
            current = []
        current.append(member)
    if current:
        words.append(item(current))
    return [item(members)], words


def exact_spaced_member_run(
    members: Sequence[PdfTextMember],
    raw_chars: Sequence[dict[str, Any]],
    *,
    inventory_complete: bool,
    native_capture_complete: bool,
) -> tuple[PdfTextMember, ...] | None:
    """Prove one horizontal event's advance chain including executed Tc and Tw.

    Source event identity alone does not authorize joining. Every actual origin
    must match its predecessor's glyph advance and captured spacing. Numeric TJ
    displacements, different baselines/events and missing members cannot pass.
    Geometry admission is left to the existing Fact/crop projection boundary.
    """
    if (
        not inventory_complete
        or not native_capture_complete
        or not members
        or len(members) != len(raw_chars)
        or len({member.member_id for member in members}) != len(members)
    ):
        return None
    first = members[0]
    for ordinal, (member, char) in enumerate(zip(members, raw_chars, strict=True)):
        matrix = member.text_transform
        spacing = char.get("_native_horizontal_spacing")
        if (
            not (
                member.selection_state == "RETAINED"
                or (
                    member.selection_state == "GEOMETRY_REJECTED"
                    and member.geometry_status in {"OUTSIDE", "INTERSECTS"}
                    and all(w.code.value == "invalid_bbox" for w in member.warnings)
                )
            )
            or member.geometry_status not in {"INSIDE", "INTERSECTS", "OUTSIDE"}
            or member.source_writing_mode != "HORIZONTAL"
            or member.native_text_event_id is None
            or member.native_text_event_id != first.native_text_event_id
            or member.native_text_event_member_ordinal != ordinal
            or member.source_character_index != first.source_character_index + ordinal
            or member.text != char.get("text")
            or matrix is None
            or not all(math.isfinite(getattr(matrix, k)) for k in "abcdef")
            or matrix.a <= 0
            or matrix.d <= 0
            or not _near(matrix.b, 0.0)
            or not _near(matrix.c, 0.0)
            or member.parser_advance is None
            or not math.isfinite(member.parser_advance)
            or member.parser_advance <= 0
            or not isinstance(spacing, tuple)
            or len(spacing) != _SPACING_COMPONENTS
            or not all(
                isinstance(v, (int, float)) and math.isfinite(v) for v in spacing
            )
        ):
            return None
        if ordinal:
            previous = members[ordinal - 1]
            pm = previous.text_transform
            advance = previous.parser_advance
            if pm is None or advance is None:
                return None
            step = advance + spacing[0]
            if previous.text == " ":
                step += spacing[1]
            if (
                step <= 0
                or not all(_near(getattr(pm, k), getattr(matrix, k)) for k in "abcd")
                or not _near(pm.e + pm.a * step, matrix.e)
                or not _near(pm.f, matrix.f)
            ):
                return None
    return tuple(members)

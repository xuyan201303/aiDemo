"""Private immutable contracts for provider-neutral hybrid PDF analysis."""

# ruff: noqa: EM101, EM102, TC001, TRY003

from __future__ import annotations

import re
from collections.abc import Iterable, Mapping
from enum import StrEnum
from hashlib import sha256
from typing import ClassVar, Literal, Protocol, Self

from pydantic import BaseModel, ConfigDict, Field, model_validator

from document_sdk.pdf._structural_engine.canonical.contracts import (
    CanonicalDocument,
)
from document_sdk.pdf._structural_engine.structure.identity import (
    canonical_json_bytes,
    canonical_sha256,
)

HYBRID_SCHEMA_VERSION: Literal["document_sdk.pdf.hybrid.v1"] = (
    "document_sdk.pdf.hybrid.v1"
)
_HYBRID_RESULT_SCHEMA_VERSION: Literal["document_sdk.pdf.hybrid.v2"] = (
    "document_sdk.pdf.hybrid.v2"
)
_HYBRID_RESULT_IDENTITY_DOMAIN = "document_sdk.pdf.hybrid.result.v2"
HYBRID_CLOUD_DOCUMENT_DOMAIN: Literal["document_sdk.pdf.hybrid.cloud_document.v1"] = (
    "document_sdk.pdf.hybrid.cloud_document.v1"
)
HYBRID_CLOUD_PAGE_DOMAIN = "document_sdk.pdf.hybrid.cloud_page.v1"
HYBRID_CLOUD_TEXT_DOMAIN = "document_sdk.pdf.hybrid.cloud_text.v1"
HYBRID_CLOUD_TABLE_DOMAIN = "document_sdk.pdf.hybrid.cloud_table.v1"
HYBRID_CLOUD_CELL_DOMAIN = "document_sdk.pdf.hybrid.cloud_cell.v1"
HYBRID_MERGE_DOMAIN = "document_sdk.pdf.hybrid.merge.v1"
_MAX_CAPABILITY_REASON_CODES = 32
_MAX_PROVIDER_METADATA_CODES = 256
_MAX_MERGE_METADATA_CODES = 512
_MAX_CLOUD_PAGES = 2_000
_MAX_EFFECTIVE_CAPABILITY_OUTCOMES = _MAX_CLOUD_PAGES * 3
_MAX_CLOUD_TABLE_DIMENSION = 200_000
_MAX_TABLE_TOPOLOGY_CELLS = 2_000_000
_MAX_TABLE_TOPOLOGY_WORK = 2_000_000
_SAFE_METADATA_CODE = re.compile(
    r"[A-Z][A-Z0-9_.:-]{0,127}",
    flags=re.ASCII,
)


def hybrid_identity(domain: str, value: object) -> str:
    """Return one versioned deterministic identity."""
    return canonical_sha256({"domain": domain, "payload": value})


def _validate_safe_metadata_codes(
    values: tuple[str, ...],
    *,
    label: str,
    maximum_items: int = _MAX_PROVIDER_METADATA_CODES,
) -> None:
    """Validate a bounded inventory of content-free provider metadata codes."""
    if len(values) > maximum_items:
        raise ValueError(f"{label} exceeds its fixed inventory bound")
    if values != tuple(sorted(set(values))):
        raise ValueError(f"{label} must be sorted and unique")
    if any(
        not item.isascii()
        or not item.isprintable()
        or _SAFE_METADATA_CODE.fullmatch(item) is None
        for item in values
    ):
        raise ValueError(f"{label} contains an unsafe metadata code")


def _validate_canonical_strings(values: tuple[str, ...], *, label: str) -> None:
    if values != tuple(sorted(set(values))):
        raise ValueError(f"{label} must be sorted and unique")


class _LogicalCellRectangle(Protocol):
    @property
    def row_index(self) -> int: ...

    @property
    def column_index(self) -> int: ...

    @property
    def row_span(self) -> int: ...

    @property
    def column_span(self) -> int: ...


class _LogicalTable(Protocol):
    @property
    def row_count(self) -> int: ...

    @property
    def column_count(self) -> int: ...

    @property
    def cells(self) -> tuple[_LogicalCellRectangle, ...]: ...


def cloud_table_resource_usage(
    tables: Iterable[_LogicalTable],
) -> tuple[int, int, int]:
    """Return actual logical-axis totals and one-pass materialization work."""
    rows_total = 0
    columns_total = 0
    axis_materialization_work = 0
    for table in tables:
        rows_total += table.row_count
        columns_total += table.column_count
        axis_materialization_work += (table.row_count + table.column_count) * max(
            1,
            len(table.cells),
        )
    return rows_total, columns_total, axis_materialization_work


def _validate_non_overlapping_cell_rectangles(
    cells: tuple[_LogicalCellRectangle, ...],
) -> None:
    """Reject overlapping half-open logical cell rectangles within fixed work."""
    if len(cells) > _MAX_TABLE_TOPOLOGY_CELLS:
        raise ValueError("cloud table cell inventory exceeds its fixed bound")
    rectangles = sorted(
        (
            item.row_index,
            item.row_index + item.row_span,
            item.column_index,
            item.column_index + item.column_span,
        )
        for item in cells
    )
    active: list[tuple[int, int, int, int]] = []
    work = 0
    for rectangle in rectangles:
        row_start, row_end, column_start, column_end = rectangle
        retained: list[tuple[int, int, int, int]] = []
        for prior in active:
            work += 1
            if work > _MAX_TABLE_TOPOLOGY_WORK:
                raise ValueError("cloud table topology validation budget exceeded")
            prior_row_start, prior_row_end, prior_column_start, prior_column_end = prior
            if prior_row_end <= row_start:
                continue
            retained.append(prior)
            rows_overlap = row_start < prior_row_end and prior_row_start < row_end
            columns_overlap = (
                column_start < prior_column_end and prior_column_start < column_end
            )
            if rows_overlap and columns_overlap:
                raise ValueError("cloud table cell rectangles overlap")
        retained.append(rectangle)
        active = retained


class HybridContractModel(BaseModel):
    """Shared immutable base with optional deterministic identity validation."""

    identity_spec: ClassVar[tuple[str, str, str] | None] = None
    model_config = ConfigDict(
        extra="forbid",
        frozen=True,
        hide_input_in_errors=True,
        strict=True,
        allow_inf_nan=False,
    )

    def require_hybrid_identity(self) -> Self:
        """Validate the configured content identity after structural checks."""
        if self.identity_spec is None:
            return self
        field, prefix, domain = self.identity_spec
        expected = prefix + hybrid_identity(
            domain,
            self.model_dump(mode="json", exclude={field}),
        )
        if getattr(self, field) != expected:
            raise ValueError("Hybrid identity mismatch")
        return self


class HybridAnalysisMode(StrEnum):
    LOCAL_ONLY = "LOCAL_ONLY"
    HYBRID_AUTO = "HYBRID_AUTO"
    CLOUD_FORCE_DIAGNOSTIC = "CLOUD_FORCE_DIAGNOSTIC"


class DocumentAnalysisCapability(StrEnum):
    OCR_TEXT = "OCR_TEXT"
    LAYOUT = "LAYOUT"
    TABLES = "TABLES"


class CloudCapabilityFulfillmentState(StrEnum):
    FULFILLED = "FULFILLED"
    OBSERVED_EMPTY = "OBSERVED_EMPTY"
    PARTIAL = "PARTIAL"
    UNAVAILABLE = "UNAVAILABLE"
    UNSUPPORTED = "UNSUPPORTED"


class HybridEffectiveCapabilityState(StrEnum):
    FULFILLED = "FULFILLED"
    PARTIAL = "PARTIAL"
    NOT_APPLIED = "NOT_APPLIED"
    UNAVAILABLE = "UNAVAILABLE"
    CONFLICT = "CONFLICT"


class HybridRoutingReason(StrEnum):
    LOCAL_SUFFICIENT = "LOCAL_SUFFICIENT"
    OCR_REQUIRED_IMAGE_ONLY = "OCR_REQUIRED_IMAGE_ONLY"
    TEXT_LAYER_UNRELIABLE = "TEXT_LAYER_UNRELIABLE"
    TEXT_UNAVAILABLE = "TEXT_UNAVAILABLE"
    LAYOUT_UNAVAILABLE = "LAYOUT_UNAVAILABLE"
    TABLE_STRUCTURE_UNAVAILABLE = "TABLE_STRUCTURE_UNAVAILABLE"
    LOCAL_PARTIAL_CLOUD_ELIGIBLE = "LOCAL_PARTIAL_CLOUD_ELIGIBLE"
    CLOUD_DISABLED = "CLOUD_DISABLED"
    PROVIDER_UNAVAILABLE = "PROVIDER_UNAVAILABLE"
    CLOUD_LIMIT_EXCEEDED = "CLOUD_LIMIT_EXCEEDED"
    CLOUD_FORCE_DIAGNOSTIC = "CLOUD_FORCE_DIAGNOSTIC"


class HybridPageRoute(StrEnum):
    LOCAL = "LOCAL"
    CLOUD = "CLOUD"


class HybridAvailabilityState(StrEnum):
    AVAILABLE = "AVAILABLE"
    PARTIAL = "PARTIAL"
    UNAVAILABLE = "UNAVAILABLE"
    UNSUPPORTED = "UNSUPPORTED"
    LIMITED_EVIDENCE = "LIMITED_EVIDENCE"


class HybridCloudStatus(StrEnum):
    NOT_REQUESTED = "NOT_REQUESTED"
    NOT_EXECUTED_DISABLED = "NOT_EXECUTED_DISABLED"
    NOT_EXECUTED_PROVIDER_UNAVAILABLE = "NOT_EXECUTED_PROVIDER_UNAVAILABLE"
    NOT_EXECUTED_LIMIT = "NOT_EXECUTED_LIMIT"
    COMPLETED = "COMPLETED"
    COMPLETED_PARTIAL = "COMPLETED_PARTIAL"
    FAILED_CONTROLLED = "FAILED_CONTROLLED"


class HybridDeletionStatus(StrEnum):
    NOT_REQUESTED = "NOT_REQUESTED"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"
    UNAVAILABLE = "UNAVAILABLE"


class HybridElementOrigin(StrEnum):
    LOCAL = "LOCAL"
    CLOUD = "CLOUD"
    LOCAL_WITH_CLOUD_FILL = "LOCAL_WITH_CLOUD_FILL"


class HybridFailureCategory(StrEnum):
    CLOUD_PROVIDER_UNAVAILABLE = "CLOUD_PROVIDER_UNAVAILABLE"
    CLOUD_CONFIGURATION_ERROR = "CLOUD_CONFIGURATION_ERROR"
    CLOUD_REQUEST_LIMIT = "CLOUD_REQUEST_LIMIT"
    CLOUD_PROVIDER_TIMEOUT = "CLOUD_PROVIDER_TIMEOUT"
    CLOUD_PROVIDER_REJECTED = "CLOUD_PROVIDER_REJECTED"
    CLOUD_RESPONSE_INVALID = "CLOUD_RESPONSE_INVALID"
    CLOUD_RESULT_LIMIT_EXCEEDED = "CLOUD_RESULT_LIMIT_EXCEEDED"
    CLOUD_DELETE_FAILED = "CLOUD_DELETE_FAILED"
    CLOUD_ANALYSIS_FAILED = "CLOUD_ANALYSIS_FAILED"
    HYBRID_INTERNAL_FAILURE = "HYBRID_INTERNAL_FAILURE"


class HybridFailureLimitation(StrEnum):
    AZURE_MULTIPLE_BOUNDING_REGIONS_UNSUPPORTED = (
        "AZURE_MULTIPLE_BOUNDING_REGIONS_UNSUPPORTED"
    )


class HybridAnalysisError(ValueError):
    """Base private Hybrid failure with a fixed content-free category."""

    def __init__(
        self,
        category: HybridFailureCategory,
        message: str,
        *,
        limitation_code: HybridFailureLimitation | None = None,
    ) -> None:
        self.category = category
        self.limitation_code = limitation_code
        super().__init__(message)


class HybridLimits(HybridContractModel):
    maximum_cloud_pages: int = Field(default=64, ge=1, le=2_000)
    maximum_cloud_requests: int = Field(default=1, ge=1, le=8)
    maximum_cloud_input_bytes: int = Field(default=50_000_000, ge=1, le=500_000_000)
    maximum_cloud_output_bytes: int = Field(
        default=64 * 1024 * 1024, ge=1_024, le=256 * 1024 * 1024
    )
    maximum_cloud_text_blocks: int = Field(default=500_000, ge=0, le=2_000_000)
    maximum_cloud_tables: int = Field(default=10_000, ge=0, le=100_000)
    maximum_cloud_cells: int = Field(default=500_000, ge=0, le=2_000_000)
    maximum_cloud_rows_total: int = Field(default=10_000, ge=1, le=200_000)
    maximum_cloud_columns_total: int = Field(default=10_000, ge=1, le=200_000)
    maximum_cloud_axis_materialization_work: int = Field(
        default=2_000_000,
        ge=1,
        le=4_000_000,
    )
    maximum_cloud_characters: int = Field(default=10_000_000, ge=0, le=50_000_000)
    maximum_elapsed_milliseconds: int = Field(default=120_000, ge=1, le=1_800_000)

    @property
    def identity(self) -> str:
        return hybrid_identity("document_sdk.pdf.hybrid.limits.v1", self)


class CloudPrivacyPolicy(HybridContractModel):
    submission_scope: Literal["FULL_DOCUMENT_BYTES"] = "FULL_DOCUMENT_BYTES"
    analysis_page_scope: Literal["SELECTED_PAGES"] = "SELECTED_PAGES"
    delete_result_after_fetch: bool = True
    require_delete_success: bool = False

    @model_validator(mode="after")
    def validate_delete_contract(self) -> Self:
        if self.require_delete_success and not self.delete_result_after_fetch:
            raise ValueError("required deletion must be requested")
        return self


class HybridOptions(HybridContractModel):
    mode: HybridAnalysisMode = HybridAnalysisMode.LOCAL_ONLY
    cloud_enabled: bool = False
    required_capabilities: tuple[DocumentAnalysisCapability, ...] = (
        DocumentAnalysisCapability.LAYOUT,
        DocumentAnalysisCapability.OCR_TEXT,
        DocumentAnalysisCapability.TABLES,
    )
    locale_hint: str | None = Field(default=None, min_length=1, max_length=64)
    privacy_policy: CloudPrivacyPolicy = Field(default_factory=CloudPrivacyPolicy)
    limits: HybridLimits = Field(default_factory=HybridLimits)

    @model_validator(mode="after")
    def validate_options(self) -> Self:
        if self.required_capabilities != tuple(
            sorted(set(self.required_capabilities), key=lambda item: item.value)
        ):
            raise ValueError("Hybrid capabilities must be sorted and unique")
        if self.mode is HybridAnalysisMode.LOCAL_ONLY and self.cloud_enabled:
            raise ValueError("LOCAL_ONLY cannot enable cloud execution")
        if (
            self.mode is HybridAnalysisMode.CLOUD_FORCE_DIAGNOSTIC
            and not self.cloud_enabled
        ):
            raise ValueError("diagnostic cloud mode requires cloud execution")
        return self


class HybridLocalPageAuthority(HybridContractModel):
    page_index: int = Field(ge=0)
    local_availability: HybridAvailabilityState
    text_availability: HybridAvailabilityState
    layout_availability: HybridAvailabilityState
    table_availability: HybridAvailabilityState
    page_table_outcome: str | None = Field(default=None, max_length=64)
    no_table_proven: bool = False
    typed_reason_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_authority(self) -> Self:
        _validate_canonical_strings(self.typed_reason_codes, label="local reason codes")
        if self.no_table_proven and self.page_table_outcome != "NO_TABLE":
            raise ValueError("no-table proof requires NO_TABLE authority")
        return self


class HybridPageRoutingDecision(HybridContractModel):
    page_index: int = Field(ge=0)
    route: HybridPageRoute
    required_capabilities: tuple[DocumentAnalysisCapability, ...] = ()
    reason_codes: tuple[HybridRoutingReason, ...]
    local_availability: HybridAvailabilityState
    local_result_retained: bool = True

    @model_validator(mode="after")
    def validate_decision(self) -> Self:
        if self.required_capabilities != tuple(
            sorted(set(self.required_capabilities), key=lambda item: item.value)
        ):
            raise ValueError("page routing capabilities must be canonical")
        if self.reason_codes != tuple(
            sorted(set(self.reason_codes), key=lambda item: item.value)
        ):
            raise ValueError("page routing reasons must be canonical")
        if not self.local_result_retained:
            raise ValueError("Hybrid routing must retain local authority")
        return self


class HybridRoutingPlan(HybridContractModel):
    identity_spec = (
        "routing_plan_sha256",
        "",
        "document_sdk.pdf.hybrid.routing_plan.v1",
    )
    schema_version: Literal["document_sdk.pdf.hybrid.v1"] = HYBRID_SCHEMA_VERSION
    mode: HybridAnalysisMode
    document_identity: str = Field(min_length=1, max_length=160)
    page_decisions: tuple[HybridPageRoutingDecision, ...]
    cloud_page_numbers: tuple[int, ...] = Field(
        default=(),
        max_length=_MAX_CLOUD_PAGES,
    )
    requested_capabilities: tuple[DocumentAnalysisCapability, ...] = ()
    reason_codes: tuple[HybridRoutingReason, ...]
    cloud_required: bool
    cloud_allowed: bool
    local_result_retained: bool = True
    limits_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    routing_plan_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_plan(self) -> Self:
        if tuple(item.page_index for item in self.page_decisions) != tuple(
            sorted(item.page_index for item in self.page_decisions)
        ):
            raise ValueError("routing decisions must use page order")
        if self.cloud_page_numbers != tuple(sorted(set(self.cloud_page_numbers))):
            raise ValueError("cloud pages must be sorted and unique")
        if any(item < 1 for item in self.cloud_page_numbers):
            raise ValueError("cloud pages must use positive page numbers")
        expected_cloud_pages = tuple(
            decision.page_index + 1
            for decision in self.page_decisions
            if decision.route is HybridPageRoute.CLOUD
        )
        if self.cloud_page_numbers != expected_cloud_pages:
            raise ValueError("cloud pages do not match page routing decisions")
        if self.requested_capabilities != tuple(
            sorted(set(self.requested_capabilities), key=lambda item: item.value)
        ):
            raise ValueError("routing capabilities must be canonical")
        expected_capabilities = tuple(
            sorted(
                {
                    capability
                    for decision in self.page_decisions
                    for capability in decision.required_capabilities
                },
                key=lambda item: item.value,
            )
        )
        if self.requested_capabilities != expected_capabilities:
            raise ValueError("routing capabilities do not match page requirements")
        if self.reason_codes != tuple(
            sorted(set(self.reason_codes), key=lambda item: item.value)
        ):
            raise ValueError("routing reasons must be canonical")
        if self.cloud_required != any(
            decision.required_capabilities for decision in self.page_decisions
        ):
            raise ValueError("routing cloud-required evidence is inconsistent")
        if not self.local_result_retained:
            raise ValueError("Hybrid plan must retain local authority")
        return self.require_hybrid_identity()


class CloudRequestPlan(HybridContractModel):
    identity_spec = (
        "request_plan_sha256",
        "",
        "document_sdk.pdf.hybrid.cloud_request_plan.v1",
    )
    document_identity: str = Field(min_length=1, max_length=160)
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_numbers: tuple[int, ...]
    capabilities: tuple[DocumentAnalysisCapability, ...]
    request_count: int = Field(ge=0, le=8)
    input_bytes: int = Field(ge=0)
    submission_scope: Literal["FULL_DOCUMENT_BYTES"] = "FULL_DOCUMENT_BYTES"
    analysis_page_scope: Literal["SELECTED_PAGES"] = "SELECTED_PAGES"
    allowed: bool
    reason_codes: tuple[HybridRoutingReason, ...] = ()
    limits_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    request_plan_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_request_plan(self) -> Self:
        if self.page_numbers != tuple(sorted(set(self.page_numbers))):
            raise ValueError("cloud request pages must be sorted and unique")
        if any(item < 1 for item in self.page_numbers):
            raise ValueError("cloud request pages must be positive")
        if self.capabilities != tuple(
            sorted(set(self.capabilities), key=lambda item: item.value)
        ):
            raise ValueError("cloud request capabilities must be canonical")
        if self.reason_codes != tuple(
            sorted(set(self.reason_codes), key=lambda item: item.value)
        ):
            raise ValueError("cloud request reasons must be canonical")
        if self.allowed and self.request_count != (1 if self.page_numbers else 0):
            raise ValueError("allowed cloud request count is inconsistent")
        if self.allowed and self.reason_codes:
            raise ValueError("allowed cloud request cannot carry denial reasons")
        return self.require_hybrid_identity()


class DocumentAnalysisRequest(HybridContractModel):
    analysis_mode: Literal[HybridAnalysisMode.HYBRID_AUTO]
    source_document_identity: str = Field(min_length=1, max_length=160)
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    document_bytes: bytes = Field(repr=False, exclude=True)
    page_numbers: tuple[int, ...] = Field(max_length=_MAX_CLOUD_PAGES)
    capabilities: tuple[DocumentAnalysisCapability, ...]
    locale_hint: str | None = Field(default=None, min_length=1, max_length=64)
    privacy_policy: CloudPrivacyPolicy
    limits: HybridLimits
    request_identity: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_request(self) -> Self:
        if self.page_numbers != tuple(sorted(set(self.page_numbers))):
            raise ValueError("analysis pages must be sorted and unique")
        if not self.page_numbers or any(item < 1 for item in self.page_numbers):
            raise ValueError("analysis requires positive page numbers")
        if len(self.page_numbers) > self.limits.maximum_cloud_pages:
            raise ValueError("analysis page limit exceeded")
        if self.capabilities != tuple(
            sorted(set(self.capabilities), key=lambda item: item.value)
        ):
            raise ValueError("analysis capabilities must be canonical")
        if sha256(self.document_bytes).hexdigest() != self.source_sha256:
            raise ValueError("analysis bytes do not match source identity")
        if len(self.document_bytes) > self.limits.maximum_cloud_input_bytes:
            raise ValueError("analysis input byte limit exceeded")
        expected = hybrid_identity(
            "document_sdk.pdf.hybrid.analysis_request.v1",
            {
                "analysis_mode": self.analysis_mode,
                "source_document_identity": self.source_document_identity,
                "source_sha256": self.source_sha256,
                "document_bytes": len(self.document_bytes),
                "page_numbers": self.page_numbers,
                "capabilities": self.capabilities,
                "locale_hint": self.locale_hint,
                "privacy_policy": self.privacy_policy,
                "limits_identity": self.limits.identity,
            },
        )
        if self.request_identity != expected:
            raise ValueError("analysis request identity mismatch")
        return self


class DocumentAnalysisProvider(Protocol):
    def analyze(
        self,
        request: DocumentAnalysisRequest,
    ) -> CloudDocumentAnalysisArtifact:
        """Return one provider-neutral normalized cloud artifact."""
        ...


class CloudPoint(HybridContractModel):
    x: float = Field(ge=0, le=1)
    y: float = Field(ge=0, le=1)


class CloudPolygon(HybridContractModel):
    points: tuple[CloudPoint, ...] = Field(min_length=4, max_length=32)


class CloudTextBlock(HybridContractModel):
    identity_spec = ("cloud_block_id", "P3HY1-cloud-text-", HYBRID_CLOUD_TEXT_DOMAIN)
    cloud_block_id: str = Field(pattern=r"^P3HY1-cloud-text-[0-9a-f]{64}$")
    page_index: int = Field(ge=0)
    ordinal: int = Field(ge=0)
    text: str = Field(repr=False)
    polygon: CloudPolygon
    confidence: float | None = Field(default=None, ge=0, le=1)
    source_role: str | None = Field(default=None, max_length=64)

    @model_validator(mode="after")
    def validate_identity(self) -> Self:
        return self.require_hybrid_identity()


class CloudTableCell(HybridContractModel):
    identity_spec = ("cloud_cell_id", "P3HY1-cloud-cell-", HYBRID_CLOUD_CELL_DOMAIN)
    cloud_cell_id: str = Field(pattern=r"^P3HY1-cloud-cell-[0-9a-f]{64}$")
    page_index: int = Field(ge=0)
    table_ordinal: int = Field(ge=0)
    ordinal: int = Field(ge=0)
    row_index: int = Field(ge=0)
    column_index: int = Field(ge=0)
    row_span: int = Field(default=1, ge=1, le=_MAX_CLOUD_TABLE_DIMENSION)
    column_span: int = Field(default=1, ge=1, le=_MAX_CLOUD_TABLE_DIMENSION)
    text: str = Field(repr=False)
    polygon: CloudPolygon
    kind: str | None = Field(default=None, max_length=64)
    confidence: float | None = Field(default=None, ge=0, le=1)

    @model_validator(mode="after")
    def validate_identity(self) -> Self:
        return self.require_hybrid_identity()


class CloudTable(HybridContractModel):
    identity_spec = (
        "cloud_table_id",
        "P3HY1-cloud-table-",
        HYBRID_CLOUD_TABLE_DOMAIN,
    )
    cloud_table_id: str = Field(pattern=r"^P3HY1-cloud-table-[0-9a-f]{64}$")
    page_index: int = Field(ge=0)
    ordinal: int = Field(ge=0)
    row_count: int = Field(ge=1, le=_MAX_CLOUD_TABLE_DIMENSION)
    column_count: int = Field(ge=1, le=_MAX_CLOUD_TABLE_DIMENSION)
    cells: tuple[CloudTableCell, ...]
    polygon: CloudPolygon
    confidence: float | None = Field(default=None, ge=0, le=1)

    @model_validator(mode="after")
    def validate_table(self) -> Self:
        if tuple(item.ordinal for item in self.cells) != tuple(range(len(self.cells))):
            raise ValueError("cloud table cells must be contiguous and ordered")
        if len({item.cloud_cell_id for item in self.cells}) != len(self.cells):
            raise ValueError("cloud table repeats a cell identity")
        if any(
            item.page_index != self.page_index
            or item.table_ordinal != self.ordinal
            or item.row_index + item.row_span > self.row_count
            or item.column_index + item.column_span > self.column_count
            for item in self.cells
        ):
            raise ValueError("cloud cell is outside table bounds")
        _validate_non_overlapping_cell_rectangles(self.cells)
        return self.require_hybrid_identity()


class CloudPageCapabilityOutcome(HybridContractModel):
    capability: DocumentAnalysisCapability
    state: CloudCapabilityFulfillmentState
    observed_item_count: int = Field(ge=0, le=2_000_000)
    reason_codes: tuple[str, ...] = Field(
        default=(),
        max_length=_MAX_CAPABILITY_REASON_CODES,
    )

    @model_validator(mode="after")
    def validate_outcome(self) -> Self:
        _validate_safe_metadata_codes(
            self.reason_codes,
            label="cloud capability reasons",
            maximum_items=_MAX_CAPABILITY_REASON_CODES,
        )
        if self.state is CloudCapabilityFulfillmentState.FULFILLED:
            if self.observed_item_count == 0 or self.reason_codes:
                raise ValueError(
                    "fulfilled cloud capability requires observed evidence"
                )
        elif self.state is CloudCapabilityFulfillmentState.OBSERVED_EMPTY:
            if self.observed_item_count != 0 or not self.reason_codes:
                raise ValueError("observed-empty capability requires a fixed reason")
        elif self.state in {
            CloudCapabilityFulfillmentState.UNAVAILABLE,
            CloudCapabilityFulfillmentState.UNSUPPORTED,
        } and (self.observed_item_count != 0 or not self.reason_codes):
            raise ValueError("unfulfilled cloud capability requires a fixed reason")
        elif self.state is CloudCapabilityFulfillmentState.PARTIAL and not (
            self.reason_codes
        ):
            raise ValueError("partial cloud capability requires a fixed reason")
        return self


class CloudPage(HybridContractModel):
    identity_spec = ("cloud_page_id", "P3HY1-cloud-page-", HYBRID_CLOUD_PAGE_DOMAIN)
    cloud_page_id: str = Field(pattern=r"^P3HY1-cloud-page-[0-9a-f]{64}$")
    page_index: int = Field(ge=0)
    width: float = Field(gt=0)
    height: float = Field(gt=0)
    unit: str = Field(min_length=1, max_length=32)
    rotation: float | None = Field(default=None, ge=-360, le=360)
    text_blocks: tuple[CloudTextBlock, ...] = Field(default=(), repr=False)
    tables: tuple[CloudTable, ...] = Field(default=(), repr=False)
    capability_outcomes: tuple[CloudPageCapabilityOutcome, ...]
    availability: HybridAvailabilityState
    warnings: tuple[str, ...] = Field(
        default=(),
        max_length=_MAX_PROVIDER_METADATA_CODES,
    )
    limitations: tuple[str, ...] = Field(
        default=(),
        max_length=_MAX_PROVIDER_METADATA_CODES,
    )

    @model_validator(mode="after")
    def validate_page(self) -> Self:
        if tuple(item.ordinal for item in self.text_blocks) != tuple(
            range(len(self.text_blocks))
        ) or tuple(item.ordinal for item in self.tables) != tuple(
            range(len(self.tables))
        ):
            raise ValueError("cloud page content must be contiguous and ordered")
        if any(item.page_index != self.page_index for item in self.text_blocks) or any(
            item.page_index != self.page_index for item in self.tables
        ):
            raise ValueError("cloud content crosses page authority")
        if len({item.cloud_block_id for item in self.text_blocks}) != len(
            self.text_blocks
        ) or len({item.cloud_table_id for item in self.tables}) != len(self.tables):
            raise ValueError("cloud page repeats content identity")
        outcome_capabilities = tuple(
            item.capability for item in self.capability_outcomes
        )
        if outcome_capabilities != tuple(
            sorted(set(outcome_capabilities), key=lambda item: item.value)
        ):
            raise ValueError("cloud page capability outcomes must be canonical")
        observed_counts = {
            DocumentAnalysisCapability.LAYOUT: 1,
            DocumentAnalysisCapability.OCR_TEXT: len(self.text_blocks),
            DocumentAnalysisCapability.TABLES: len(self.tables),
        }
        if any(
            item.observed_item_count != observed_counts[item.capability]
            for item in self.capability_outcomes
        ):
            raise ValueError("cloud capability observed item count is inconsistent")
        _validate_safe_metadata_codes(self.warnings, label="cloud page warnings")
        _validate_safe_metadata_codes(
            self.limitations,
            label="cloud page limitations",
        )
        return self.require_hybrid_identity()


def _cloud_artifact_provider_metadata_codes(
    *,
    warnings: tuple[str, ...],
    limitations: tuple[str, ...],
    pages: tuple[CloudPage, ...],
) -> tuple[str, ...]:
    """Return the bounded global provider code inventory without eager fan-out."""
    provider_codes: set[str] = set()

    def add_inventory(inventory: tuple[str, ...]) -> None:
        for code in inventory:
            if code in provider_codes:
                continue
            if len(provider_codes) == _MAX_PROVIDER_METADATA_CODES:
                raise ValueError(
                    "cloud artifact provider metadata exceeds its fixed inventory bound"
                )
            provider_codes.add(code)

    add_inventory(warnings)
    add_inventory(limitations)
    for page in pages:
        add_inventory(page.warnings)
        add_inventory(page.limitations)
        for outcome in page.capability_outcomes:
            add_inventory(outcome.reason_codes)
    return tuple(sorted(provider_codes))


class CloudDocumentAnalysisArtifact(HybridContractModel):
    identity_spec = ("payload_sha256", "", HYBRID_CLOUD_DOCUMENT_DOMAIN)
    schema_version: Literal["document_sdk.pdf.hybrid.cloud_document.v1"] = (
        HYBRID_CLOUD_DOCUMENT_DOMAIN
    )
    provider: str = Field(min_length=1, max_length=64)
    model_id: str = Field(min_length=1, max_length=128)
    api_version: str = Field(min_length=1, max_length=64)
    submission_scope: Literal["FULL_DOCUMENT_BYTES"]
    analysis_page_scope: Literal["SELECTED_PAGES"]
    source_document_identity: str = Field(min_length=1, max_length=160)
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    request_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    requested_page_numbers: tuple[int, ...] = Field(max_length=_MAX_CLOUD_PAGES)
    requested_capabilities: tuple[DocumentAnalysisCapability, ...]
    pages: tuple[CloudPage, ...] = Field(
        repr=False,
        max_length=_MAX_CLOUD_PAGES,
    )
    missing_page_numbers: tuple[int, ...] = Field(
        default=(),
        max_length=_MAX_CLOUD_PAGES,
    )
    availability: HybridAvailabilityState
    warnings: tuple[str, ...] = Field(
        default=(),
        max_length=_MAX_PROVIDER_METADATA_CODES,
    )
    limitations: tuple[str, ...] = Field(
        default=(),
        max_length=_MAX_PROVIDER_METADATA_CODES,
    )
    safe_result_identity: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )
    deletion_status: HybridDeletionStatus
    text_block_count: int = Field(ge=0)
    character_count: int = Field(ge=0)
    table_count: int = Field(ge=0)
    cell_count: int = Field(ge=0)
    normalized_output_bytes: int = Field(ge=0)
    # Live timing enforces the request bound but is not normalized replay data.
    elapsed_milliseconds: int = Field(default=0, ge=0, exclude=True)
    payload_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_artifact(self) -> Self:
        if self.requested_page_numbers != tuple(
            sorted(set(self.requested_page_numbers))
        ) or self.missing_page_numbers != tuple(sorted(set(self.missing_page_numbers))):
            raise ValueError("cloud artifact page inventories must be canonical")
        if not self.requested_page_numbers or any(
            item < 1 for item in self.requested_page_numbers
        ):
            raise ValueError("cloud artifact requires positive requested pages")
        returned = tuple(item.page_index + 1 for item in self.pages)
        if returned != tuple(sorted(set(returned))):
            raise ValueError("cloud artifact pages must be ordered and unique")
        if set(returned) | set(self.missing_page_numbers) != set(
            self.requested_page_numbers
        ) or set(returned) & set(self.missing_page_numbers):
            raise ValueError("cloud artifact page coverage is inconsistent")
        if self.missing_page_numbers and (
            self.availability is HybridAvailabilityState.AVAILABLE
        ):
            raise ValueError("cloud artifact with missing pages cannot be available")
        if self.requested_capabilities != tuple(
            sorted(set(self.requested_capabilities), key=lambda item: item.value)
        ):
            raise ValueError("cloud artifact capabilities must be canonical")
        if any(
            tuple(item.capability for item in page.capability_outcomes)
            != self.requested_capabilities
            for page in self.pages
        ):
            raise ValueError(
                "cloud page capability outcomes do not match requested capabilities"
            )
        _validate_safe_metadata_codes(self.warnings, label="cloud artifact warnings")
        _validate_safe_metadata_codes(
            self.limitations,
            label="cloud artifact limitations",
        )
        provider_codes = _cloud_artifact_provider_metadata_codes(
            warnings=self.warnings,
            limitations=self.limitations,
            pages=self.pages,
        )
        _validate_safe_metadata_codes(
            provider_codes,
            label="cloud artifact provider metadata",
        )
        observed_text_blocks = sum(len(page.text_blocks) for page in self.pages)
        observed_characters = sum(
            len(block.text) for page in self.pages for block in page.text_blocks
        ) + sum(
            len(cell.text)
            for page in self.pages
            for table in page.tables
            for cell in table.cells
        )
        observed_tables = sum(len(page.tables) for page in self.pages)
        observed_cells = sum(
            len(table.cells) for page in self.pages for table in page.tables
        )
        if (
            self.text_block_count != observed_text_blocks
            or self.character_count != observed_characters
            or self.table_count != observed_tables
            or self.cell_count != observed_cells
            or self.normalized_output_bytes
            != len(canonical_json_bytes(normalized_cloud_payload_for_size(self)))
        ):
            raise ValueError("cloud artifact resource accounting mismatch")
        return self.require_hybrid_identity()

    def canonical_json_bytes(self) -> bytes:
        """Return deterministic content-bearing replay bytes."""
        return canonical_json_bytes(self)


def normalized_cloud_payload_for_size(
    value: CloudDocumentAnalysisArtifact | Mapping[str, object],
) -> dict[str, object]:
    """Return the one authoritative normalized payload used for byte accounting."""
    if isinstance(value, CloudDocumentAnalysisArtifact):
        payload = {
            name: getattr(value, name)
            for name, field in type(value).model_fields.items()
            if not field.exclude
        }
    elif isinstance(value, Mapping):
        payload = dict(value)
    else:
        raise TypeError("normalized cloud payload source is invalid")
    for field in (
        "payload_sha256",
        "normalized_output_bytes",
        "elapsed_milliseconds",
    ):
        payload.pop(field, None)
    return payload


class HybridElementProvenance(HybridContractModel):
    canonical_id: str = Field(min_length=1, max_length=160)
    kind: str = Field(min_length=1, max_length=32)
    origin: HybridElementOrigin
    provider: str | None = Field(default=None, max_length=64)
    model_id: str | None = Field(default=None, max_length=128)
    api_version: str | None = Field(default=None, max_length=64)
    request_identity: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    submission_scope: Literal["FULL_DOCUMENT_BYTES"] | None = None
    analysis_page_scope: Literal["SELECTED_PAGES"] | None = None
    requested_page_numbers: tuple[int, ...] = ()
    fallback_reason_codes: tuple[HybridRoutingReason, ...] = ()

    @model_validator(mode="after")
    def validate_provenance(self) -> Self:
        cloud = self.origin is not HybridElementOrigin.LOCAL
        fields = (
            self.provider,
            self.model_id,
            self.api_version,
            self.request_identity,
            self.submission_scope,
            self.analysis_page_scope,
        )
        if cloud and (
            not all(item is not None for item in fields)
            or not self.requested_page_numbers
        ):
            raise ValueError("Hybrid element cloud provenance is incomplete")
        if not cloud and (
            any(item is not None for item in fields)
            or self.requested_page_numbers
            or self.fallback_reason_codes
        ):
            raise ValueError("local provenance cannot carry cloud evidence")
        if self.requested_page_numbers != tuple(
            sorted(set(self.requested_page_numbers))
        ):
            raise ValueError("provenance pages must be canonical")
        if self.fallback_reason_codes != tuple(
            sorted(set(self.fallback_reason_codes), key=lambda item: item.value)
        ):
            raise ValueError("provenance reasons must be canonical")
        return self


class HybridPageEffectiveCapabilityOutcome(HybridContractModel):
    page_index: int = Field(ge=0)
    capability: DocumentAnalysisCapability
    state: HybridEffectiveCapabilityState
    applied_item_count: int = Field(ge=0, le=2_000_000)
    reason_codes: tuple[str, ...] = Field(
        default=(),
        max_length=_MAX_CAPABILITY_REASON_CODES,
    )

    @model_validator(mode="after")
    def validate_outcome(self) -> Self:
        _validate_safe_metadata_codes(
            self.reason_codes,
            label="effective capability reasons",
            maximum_items=_MAX_CAPABILITY_REASON_CODES,
        )
        if self.state is HybridEffectiveCapabilityState.FULFILLED:
            if self.applied_item_count == 0 or self.reason_codes:
                raise ValueError(
                    "fulfilled effective capability requires applied evidence"
                )
        elif not self.reason_codes:
            raise ValueError("unfulfilled effective capability requires a fixed reason")
        if (
            self.state
            in {
                HybridEffectiveCapabilityState.NOT_APPLIED,
                HybridEffectiveCapabilityState.UNAVAILABLE,
                HybridEffectiveCapabilityState.CONFLICT,
            }
            and self.applied_item_count != 0
        ):
            raise ValueError("non-applied effective capability cannot count evidence")
        return self


class HybridMergeReport(HybridContractModel):
    identity_spec = ("merge_identity", "", HYBRID_MERGE_DOMAIN)
    local_pages: int = Field(ge=0)
    cloud_requested_pages: int = Field(ge=0)
    cloud_filled_pages: int = Field(ge=0)
    local_preserved_text_count: int = Field(ge=0)
    cloud_filled_text_count: int = Field(ge=0)
    local_preserved_table_count: int = Field(ge=0)
    cloud_filled_table_count: int = Field(ge=0)
    conflict_count: int = Field(ge=0)
    continuity_unavailable_count: int = Field(ge=0)
    effective_capability_outcomes: tuple[
        HybridPageEffectiveCapabilityOutcome,
        ...,
    ] = Field(max_length=_MAX_EFFECTIVE_CAPABILITY_OUTCOMES)
    warnings: tuple[str, ...] = Field(
        default=(),
        max_length=_MAX_MERGE_METADATA_CODES,
    )
    limitations: tuple[str, ...] = Field(
        default=(),
        max_length=_MAX_MERGE_METADATA_CODES,
    )
    review_required: bool = False
    merge_identity: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_report(self) -> Self:
        keys = tuple(
            (item.page_index, item.capability.value)
            for item in self.effective_capability_outcomes
        )
        if keys != tuple(sorted(set(keys))):
            raise ValueError("effective capability outcomes must be canonical")
        applied_text_count = sum(
            item.applied_item_count
            for item in self.effective_capability_outcomes
            if item.capability is DocumentAnalysisCapability.OCR_TEXT
        )
        applied_table_count = sum(
            item.applied_item_count
            for item in self.effective_capability_outcomes
            if item.capability is DocumentAnalysisCapability.TABLES
        )
        if (
            applied_text_count != self.cloud_filled_text_count
            or applied_table_count != self.cloud_filled_table_count
        ):
            raise ValueError("effective capability item accounting is inconsistent")
        applied_pages = {
            item.page_index
            for item in self.effective_capability_outcomes
            if item.capability
            in {
                DocumentAnalysisCapability.OCR_TEXT,
                DocumentAnalysisCapability.TABLES,
            }
            and item.applied_item_count
        }
        if len(applied_pages) != self.cloud_filled_pages:
            raise ValueError("effective capability page accounting is inconsistent")
        effective_conflicts = sum(
            item.capability is DocumentAnalysisCapability.TABLES
            and item.state is HybridEffectiveCapabilityState.CONFLICT
            for item in self.effective_capability_outcomes
        )
        if effective_conflicts != self.conflict_count:
            raise ValueError("effective capability conflict accounting is inconsistent")
        applied_by_page = {
            item.page_index
            for item in self.effective_capability_outcomes
            if item.capability
            in {
                DocumentAnalysisCapability.OCR_TEXT,
                DocumentAnalysisCapability.TABLES,
            }
            and item.applied_item_count
        }
        if any(
            item.applied_item_count != int(item.page_index in applied_by_page)
            for item in self.effective_capability_outcomes
            if item.capability is DocumentAnalysisCapability.LAYOUT
        ):
            raise ValueError("effective layout accounting lacks applied page evidence")
        _validate_safe_metadata_codes(
            self.warnings,
            label="merge warnings",
            maximum_items=_MAX_MERGE_METADATA_CODES,
        )
        _validate_safe_metadata_codes(
            self.limitations,
            label="merge limitations",
            maximum_items=_MAX_MERGE_METADATA_CODES,
        )
        return self.require_hybrid_identity()


def _validate_result_core_authority(result: HybridAnalysisResult) -> None:
    if result.local_canonical_document_id != result.routing_plan.document_identity:
        raise ValueError("Hybrid result does not bind its local Canonical identity")
    if tuple(item.page_index for item in result.canonical_document.pages) != tuple(
        item.page_index for item in result.routing_plan.page_decisions
    ):
        raise ValueError("Hybrid result routing pages do not match Canonical pages")
    if result.merge_report.local_pages != len(result.canonical_document.pages):
        raise ValueError("Hybrid result merge page accounting is inconsistent")


def _validate_result_cloud_authority(result: HybridAnalysisResult) -> None:
    completed_statuses = {
        HybridCloudStatus.COMPLETED,
        HybridCloudStatus.COMPLETED_PARTIAL,
    }
    if (
        result.cloud_status not in completed_statuses
        and result.merge_report.effective_capability_outcomes
    ):
        raise ValueError(
            "non-completed Hybrid result cannot claim effective capability"
        )
    if result.cloud_status in completed_statuses and result.cloud_artifact is None:
        raise ValueError("completed Hybrid result requires a cloud artifact")
    if result.cloud_artifact is None:
        return
    artifact = result.cloud_artifact
    if (
        artifact.source_document_identity
        != result.canonical_document.source_document_identity
        or artifact.source_sha256 != result.canonical_document.provenance.source_sha256
        or artifact.requested_page_numbers != result.routing_plan.cloud_page_numbers
        or artifact.requested_capabilities != result.routing_plan.requested_capabilities
        or result.merge_report.cloud_requested_pages
        != len(artifact.requested_page_numbers)
    ):
        raise ValueError("Hybrid result cloud authority is inconsistent")
    if result.cloud_status not in completed_statuses:
        return
    expected_effective_keys = tuple(
        sorted(
            (decision.page_index, capability.value)
            for decision in result.routing_plan.page_decisions
            if decision.route is HybridPageRoute.CLOUD
            for capability in decision.required_capabilities
        )
    )
    effective_keys = tuple(
        (item.page_index, item.capability.value)
        for item in result.merge_report.effective_capability_outcomes
    )
    if effective_keys != expected_effective_keys:
        raise ValueError("Hybrid result effective capabilities do not match routing")
    complete = (
        not artifact.missing_page_numbers
        and not result.merge_report.review_required
        and result.merge_report.conflict_count == 0
        and all(
            item.state is HybridEffectiveCapabilityState.FULFILLED
            for item in result.merge_report.effective_capability_outcomes
        )
    )
    if (result.cloud_status is HybridCloudStatus.COMPLETED) is not complete:
        raise ValueError("Hybrid cloud status contradicts effective capabilities")


class HybridAnalysisResult(HybridContractModel):
    schema_version: Literal["document_sdk.pdf.hybrid.v2"] = (
        _HYBRID_RESULT_SCHEMA_VERSION
    )
    local_canonical_document_id: str = Field(pattern=r"^P3CE1-document-[0-9a-f]{64}$")
    canonical_document: CanonicalDocument = Field(repr=False)
    routing_plan: HybridRoutingPlan
    cloud_status: HybridCloudStatus
    cloud_artifact: CloudDocumentAnalysisArtifact | None = Field(
        default=None,
        repr=False,
    )
    merge_report: HybridMergeReport
    element_provenance: tuple[HybridElementProvenance, ...]
    failure_category: HybridFailureCategory | None = None
    family: None = None
    family_status: str = "REVIEW_REQUIRED"
    family_auto_assignment: bool = False
    hybrid_result_identity: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_result(self) -> Self:
        _validate_result_core_authority(self)
        _validate_result_cloud_authority(self)
        if (
            self.family is not None
            or self.family_status != "REVIEW_REQUIRED"
            or self.family_auto_assignment
        ):
            raise ValueError("Hybrid Family authority must remain deferred")
        keys = tuple((item.kind, item.canonical_id) for item in self.element_provenance)
        if keys != tuple(sorted(set(keys))):
            raise ValueError("Hybrid element provenance must be canonical")
        expected = hybrid_identity(
            _HYBRID_RESULT_IDENTITY_DOMAIN,
            {
                "local_canonical_document_id": self.local_canonical_document_id,
                "canonical_document": self.canonical_document,
                "routing_plan": self.routing_plan,
                "cloud_status": self.cloud_status,
                "cloud_artifact_sha256": (
                    None
                    if self.cloud_artifact is None
                    else self.cloud_artifact.payload_sha256
                ),
                "merge_report": self.merge_report,
                "element_provenance": self.element_provenance,
                "failure_category": self.failure_category,
                "family": None,
                "family_status": self.family_status,
                "family_auto_assignment": self.family_auto_assignment,
            },
        )
        if self.hybrid_result_identity != expected:
            raise ValueError("Hybrid result identity mismatch")
        return self


__all__ = [
    "HYBRID_CLOUD_CELL_DOMAIN",
    "HYBRID_CLOUD_DOCUMENT_DOMAIN",
    "HYBRID_CLOUD_PAGE_DOMAIN",
    "HYBRID_CLOUD_TABLE_DOMAIN",
    "HYBRID_CLOUD_TEXT_DOMAIN",
    "HYBRID_MERGE_DOMAIN",
    "HYBRID_SCHEMA_VERSION",
    "CloudCapabilityFulfillmentState",
    "CloudDocumentAnalysisArtifact",
    "CloudPage",
    "CloudPageCapabilityOutcome",
    "CloudPoint",
    "CloudPolygon",
    "CloudPrivacyPolicy",
    "CloudRequestPlan",
    "CloudTable",
    "CloudTableCell",
    "CloudTextBlock",
    "DocumentAnalysisCapability",
    "DocumentAnalysisProvider",
    "DocumentAnalysisRequest",
    "HybridAnalysisError",
    "HybridAnalysisMode",
    "HybridAnalysisResult",
    "HybridAvailabilityState",
    "HybridCloudStatus",
    "HybridDeletionStatus",
    "HybridEffectiveCapabilityState",
    "HybridElementOrigin",
    "HybridElementProvenance",
    "HybridFailureCategory",
    "HybridFailureLimitation",
    "HybridLimits",
    "HybridLocalPageAuthority",
    "HybridMergeReport",
    "HybridOptions",
    "HybridPageEffectiveCapabilityOutcome",
    "HybridPageRoute",
    "HybridPageRoutingDecision",
    "HybridRoutingPlan",
    "HybridRoutingReason",
    "cloud_table_resource_usage",
    "hybrid_identity",
    "normalized_cloud_payload_for_size",
]

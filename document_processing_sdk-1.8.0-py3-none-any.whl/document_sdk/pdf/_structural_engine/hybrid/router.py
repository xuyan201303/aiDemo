"""Pure typed routing for provider-neutral hybrid PDF analysis."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .contracts import (
    HYBRID_SCHEMA_VERSION,
    CloudRequestPlan,
    DocumentAnalysisCapability,
    HybridAnalysisMode,
    HybridAvailabilityState,
    HybridLimits,
    HybridLocalPageAuthority,
    HybridOptions,
    HybridPageRoute,
    HybridPageRoutingDecision,
    HybridRoutingPlan,
    HybridRoutingReason,
    hybrid_identity,
)

if TYPE_CHECKING:
    from collections.abc import Iterable

    from document_sdk.pdf._structural_engine.canonical.contracts import (
        CanonicalAvailability,
        CanonicalDocument,
    )

_IMAGE_ONLY_REASON_CODES = frozenset({"IMAGE_ONLY_OCR_REQUIRED"})
_TEXT_UNRELIABLE_REASON_CODES = frozenset(
    {
        "LEGACY_ENCODING_UNRELIABLE",
        "MALFORMED_TEXT_OBJECT",
        "TEXT_FACT_LIMIT_REACHED",
        "TEXT_LAYER_UNRELIABLE",
        "UPSTREAM_MALFORMED_TEXT_OBJECT",
        "UPSTREAM_TEXT_FACT_LIMIT_REACHED",
        "malformed_text_object",
        "text_fact_limit_reached",
    }
)
_TEXT_UNAVAILABLE_REASON_CODES = frozenset(
    {
        "NO_TEXT_LAYER",
        "TEXT_LAYER_MISSING",
        "TEXT_UNAVAILABLE",
        "UPSTREAM_INTERNAL_ERROR",
        "UPSTREAM_NO_TEXT_LAYER",
        "UPSTREAM_TEXT_LAYER_MISSING",
        "no_text_layer",
        "text_layer_missing",
    }
)
_TEXT_AUTHORITY_COMPANION_REASON_CODES = frozenset({"OCR_NOT_EXECUTED"})
_LAYOUT_UNAVAILABLE_REASON_CODES = frozenset(
    {
        "LAYOUT_PAGE_UNAVAILABLE",
        "LAYOUT_UNAVAILABLE",
    }
)
_DENIAL_REASONS = frozenset(
    {
        HybridRoutingReason.CLOUD_DISABLED,
        HybridRoutingReason.PROVIDER_UNAVAILABLE,
        HybridRoutingReason.CLOUD_LIMIT_EXCEEDED,
    }
)
_UNAVAILABLE_STATES = (
    HybridAvailabilityState.UNAVAILABLE,
    HybridAvailabilityState.UNSUPPORTED,
)
_PARTIAL_STATES = (
    HybridAvailabilityState.PARTIAL,
    HybridAvailabilityState.LIMITED_EVIDENCE,
)
_OCR_LAYOUT = (
    DocumentAnalysisCapability.OCR_TEXT,
    DocumentAnalysisCapability.LAYOUT,
)
_LAYOUT_TABLES = (
    DocumentAnalysisCapability.LAYOUT,
    DocumentAnalysisCapability.TABLES,
)


def _canonical_capabilities(
    values: Iterable[DocumentAnalysisCapability],
) -> tuple[DocumentAnalysisCapability, ...]:
    return tuple(sorted(set(values), key=lambda item: item.value))


def _canonical_reasons(
    values: Iterable[HybridRoutingReason],
) -> tuple[HybridRoutingReason, ...]:
    return tuple(sorted(set(values), key=lambda item: item.value))


def _availability_state(value: CanonicalAvailability) -> HybridAvailabilityState:
    return HybridAvailabilityState(value.state)


def _aggregate_availability(
    values: Iterable[HybridAvailabilityState],
) -> HybridAvailabilityState:
    states = tuple(values)
    for state in (
        HybridAvailabilityState.UNAVAILABLE,
        HybridAvailabilityState.UNSUPPORTED,
        HybridAvailabilityState.PARTIAL,
        HybridAvailabilityState.LIMITED_EVIDENCE,
    ):
        if state in states:
            return state
    return HybridAvailabilityState.AVAILABLE


def _layout_availability(reason_codes: set[str]) -> HybridAvailabilityState:
    layout_reasons = {
        code
        for code in reason_codes
        if code in _LAYOUT_UNAVAILABLE_REASON_CODES
        or code.startswith("UPSTREAM_LAYOUT_PAGE_")
    }
    if not layout_reasons:
        return HybridAvailabilityState.AVAILABLE
    if any(
        code.endswith(("_UNSUPPORTED", "_INVALID_REQUEST")) for code in layout_reasons
    ):
        return HybridAvailabilityState.UNSUPPORTED
    if any(
        code.endswith(("_PARTIAL", "_RESOURCE_LIMIT_EXCEEDED"))
        for code in layout_reasons
    ):
        return HybridAvailabilityState.PARTIAL
    return HybridAvailabilityState.UNAVAILABLE


def _page_layout_availability(
    reason_codes: set[str],
    document_layout_availability: HybridAvailabilityState,
    *,
    document_text_unavailable: bool,
) -> HybridAvailabilityState:
    """Use document layout degradation only for a locally unobserved text page."""
    page_layout_availability = _layout_availability(reason_codes)
    if page_layout_availability is not HybridAvailabilityState.AVAILABLE:
        return page_layout_availability
    if document_layout_availability in {
        HybridAvailabilityState.UNAVAILABLE,
        HybridAvailabilityState.UNSUPPORTED,
    }:
        return document_layout_availability
    if document_text_unavailable and document_layout_availability in _PARTIAL_STATES:
        return document_layout_availability
    return HybridAvailabilityState.AVAILABLE


def derive_local_page_authorities(
    canonical_document: CanonicalDocument,
) -> tuple[HybridLocalPageAuthority, ...]:
    """Derive bounded page-local routing authority from retained Canonical evidence."""
    document_capabilities = {
        item.capability: _availability_state(item.availability)
        for item in canonical_document.capability_availability
    }
    document_layout_availability = document_capabilities.get(
        "layout",
        HybridAvailabilityState.UNAVAILABLE,
    )
    document_reason_codes = {
        *canonical_document.availability.reason_codes,
        *canonical_document.limitations,
        *(
            code
            for capability in canonical_document.capability_availability
            for code in capability.availability.reason_codes
        ),
    }
    warnings_by_page: dict[str, set[str]] = {}
    for warning in canonical_document.warnings:
        if warning.page_id is not None:
            warnings_by_page.setdefault(warning.page_id, set()).add(warning.code)
    tables_by_page = {
        page.page_id: tuple(
            table
            for table in canonical_document.tables
            if table.page_id == page.page_id
        )
        for page in canonical_document.pages
    }
    authorities = []
    for page in canonical_document.pages:
        tables = tables_by_page[page.page_id]
        document_text_unavailable = not page.text_blocks and bool(
            document_reason_codes & _TEXT_UNAVAILABLE_REASON_CODES
        )
        empty_text_without_local_ocr = (
            not page.text_blocks and "OCR_NOT_EXECUTED" in document_reason_codes
        )
        reason_codes = {
            *page.availability.reason_codes,
            *page.page_table_availability.reason_codes,
            *page.limitation_codes,
            *warnings_by_page.get(page.page_id, set()),
            *(
                code
                for block in page.text_blocks
                for code in (*block.availability.reason_codes, *block.limitation_codes)
            ),
            *(
                code
                for table in tables
                for code in (*table.availability.reason_codes, *table.limitation_codes)
            ),
            *(
                code
                for table in tables
                for cell in table.cells
                for code in (*cell.availability.reason_codes, *cell.limitation_codes)
            ),
        }
        if document_text_unavailable:
            reason_codes.update(
                document_reason_codes
                & (
                    _TEXT_UNAVAILABLE_REASON_CODES
                    | _TEXT_AUTHORITY_COMPANION_REASON_CODES
                )
            )
        if empty_text_without_local_ocr:
            reason_codes.add("OCR_NOT_EXECUTED")
        if reason_codes & _IMAGE_ONLY_REASON_CODES:
            text_availability = HybridAvailabilityState.UNAVAILABLE
        elif reason_codes & _TEXT_UNRELIABLE_REASON_CODES:
            text_availability = HybridAvailabilityState.LIMITED_EVIDENCE
        elif reason_codes & _TEXT_UNAVAILABLE_REASON_CODES:
            text_availability = HybridAvailabilityState.UNAVAILABLE
        else:
            text_availability = (
                HybridAvailabilityState.PARTIAL
                if empty_text_without_local_ocr
                else _aggregate_availability(
                    _availability_state(block.availability)
                    for block in page.text_blocks
                )
            )
        layout_availability = _page_layout_availability(
            reason_codes,
            document_layout_availability,
            document_text_unavailable=document_text_unavailable,
        )
        table_availability = _aggregate_availability(
            (
                _availability_state(page.page_table_availability),
                *(_availability_state(table.availability) for table in tables),
            )
        )
        no_table_proven = (
            page.page_table_outcome == "NO_TABLE"
            and text_availability is HybridAvailabilityState.AVAILABLE
            and layout_availability is HybridAvailabilityState.AVAILABLE
            and table_availability is HybridAvailabilityState.AVAILABLE
        )
        if (
            page.page_table_outcome == "NO_TABLE"
            and not no_table_proven
            and table_availability is HybridAvailabilityState.AVAILABLE
        ):
            table_availability = HybridAvailabilityState.UNAVAILABLE
        authorities.append(
            HybridLocalPageAuthority(
                page_index=page.page_index,
                local_availability=_availability_state(page.availability),
                text_availability=text_availability,
                layout_availability=layout_availability,
                table_availability=table_availability,
                page_table_outcome=page.page_table_outcome,
                no_table_proven=no_table_proven,
                typed_reason_codes=tuple(sorted(reason_codes)),
            )
        )
    return tuple(authorities)


def _validated_authorities(
    canonical_document: CanonicalDocument,
    local_authorities: tuple[HybridLocalPageAuthority, ...] | None,
) -> tuple[HybridLocalPageAuthority, ...]:
    authorities = (
        derive_local_page_authorities(canonical_document)
        if local_authorities is None
        else tuple(sorted(local_authorities, key=lambda item: item.page_index))
    )
    indexes = tuple(item.page_index for item in authorities)
    expected = tuple(page.page_index for page in canonical_document.pages)
    if len(indexes) != len(set(indexes)) or indexes != expected:
        message = "Hybrid local page authority does not match Canonical pages"
        raise ValueError(message)
    return authorities


def _add_availability_fallback(
    capabilities: set[DocumentAnalysisCapability],
    reasons: set[HybridRoutingReason],
    availability: HybridAvailabilityState,
    required: tuple[DocumentAnalysisCapability, ...],
    unavailable_reason: HybridRoutingReason,
) -> None:
    if availability in _UNAVAILABLE_STATES:
        reason = unavailable_reason
    elif availability in _PARTIAL_STATES:
        reason = HybridRoutingReason.LOCAL_PARTIAL_CLOUD_ELIGIBLE
    else:
        return
    capabilities.update(required)
    reasons.add(reason)


def _required_local_fallback(
    authority: HybridLocalPageAuthority,
    requested: frozenset[DocumentAnalysisCapability],
) -> tuple[set[DocumentAnalysisCapability], set[HybridRoutingReason]]:
    capabilities: set[DocumentAnalysisCapability] = set()
    reasons: set[HybridRoutingReason] = set()
    typed_reasons = set(authority.typed_reason_codes)
    ocr_requested = DocumentAnalysisCapability.OCR_TEXT in requested
    tables_requested = (
        DocumentAnalysisCapability.TABLES in requested and not authority.no_table_proven
    )

    if typed_reasons & _IMAGE_ONLY_REASON_CODES and (ocr_requested or tables_requested):
        reasons.add(HybridRoutingReason.OCR_REQUIRED_IMAGE_ONLY)
        if ocr_requested:
            capabilities.update(_OCR_LAYOUT)
        if tables_requested:
            capabilities.update(_LAYOUT_TABLES)
    elif typed_reasons & _TEXT_UNRELIABLE_REASON_CODES and ocr_requested:
        reasons.add(HybridRoutingReason.TEXT_LAYER_UNRELIABLE)
        capabilities.update(_OCR_LAYOUT)
    elif ocr_requested:
        _add_availability_fallback(
            capabilities,
            reasons,
            authority.text_availability,
            (DocumentAnalysisCapability.OCR_TEXT,),
            HybridRoutingReason.TEXT_UNAVAILABLE,
        )

    if DocumentAnalysisCapability.LAYOUT in requested:
        _add_availability_fallback(
            capabilities,
            reasons,
            authority.layout_availability,
            (DocumentAnalysisCapability.LAYOUT,),
            HybridRoutingReason.LAYOUT_UNAVAILABLE,
        )

    if tables_requested:
        _add_availability_fallback(
            capabilities,
            reasons,
            authority.table_availability,
            _LAYOUT_TABLES,
            HybridRoutingReason.TABLE_STRUCTURE_UNAVAILABLE,
        )
    return capabilities, reasons


def _decision(
    authority: HybridLocalPageAuthority,
    *,
    route: HybridPageRoute,
    capabilities: set[DocumentAnalysisCapability],
    reasons: set[HybridRoutingReason],
) -> HybridPageRoutingDecision:
    return HybridPageRoutingDecision(
        page_index=authority.page_index,
        route=route,
        required_capabilities=_canonical_capabilities(capabilities),
        reason_codes=_canonical_reasons(reasons),
        local_availability=authority.local_availability,
    )


def build_hybrid_routing_plan(
    canonical_document: CanonicalDocument,
    *,
    options: HybridOptions,
    provider_available: bool,
    local_authorities: tuple[HybridLocalPageAuthority, ...] | None = None,
) -> HybridRoutingPlan:
    """Build one deterministic route plan without local or cloud I/O."""
    authorities = _validated_authorities(canonical_document, local_authorities)
    requested = frozenset(options.required_capabilities)
    pending: list[
        tuple[
            HybridLocalPageAuthority,
            set[DocumentAnalysisCapability],
            set[HybridRoutingReason],
        ]
    ] = []
    for authority in authorities:
        capabilities, reasons = _required_local_fallback(authority, requested)
        if options.mode is HybridAnalysisMode.CLOUD_FORCE_DIAGNOSTIC and requested:
            capabilities.update(requested)
            reasons.add(HybridRoutingReason.CLOUD_FORCE_DIAGNOSTIC)
        pending.append((authority, capabilities, reasons))

    required_page_count = sum(bool(capabilities) for _, capabilities, _ in pending)
    over_page_limit = required_page_count > options.limits.maximum_cloud_pages
    decisions = []
    for authority, capabilities, reasons in pending:
        route = HybridPageRoute.LOCAL
        if capabilities:
            if (
                options.mode is HybridAnalysisMode.LOCAL_ONLY
                or not options.cloud_enabled
            ):
                reasons.add(HybridRoutingReason.CLOUD_DISABLED)
            elif not provider_available:
                reasons.add(HybridRoutingReason.PROVIDER_UNAVAILABLE)
            elif over_page_limit:
                reasons.add(HybridRoutingReason.CLOUD_LIMIT_EXCEEDED)
            else:
                route = HybridPageRoute.CLOUD
        else:
            reasons.add(HybridRoutingReason.LOCAL_SUFFICIENT)
        decisions.append(
            _decision(
                authority,
                route=route,
                capabilities=capabilities,
                reasons=reasons,
            )
        )
    page_decisions = tuple(decisions)
    cloud_page_numbers = tuple(
        decision.page_index + 1
        for decision in page_decisions
        if decision.route is HybridPageRoute.CLOUD
    )
    requested_capabilities = _canonical_capabilities(
        capability
        for decision in page_decisions
        for capability in decision.required_capabilities
    )
    reason_codes = _canonical_reasons(
        reason for decision in page_decisions for reason in decision.reason_codes
    )
    values = {
        "schema_version": HYBRID_SCHEMA_VERSION,
        "mode": options.mode,
        "document_identity": canonical_document.canonical_document_id,
        "page_decisions": page_decisions,
        "cloud_page_numbers": cloud_page_numbers,
        "requested_capabilities": requested_capabilities,
        "reason_codes": reason_codes,
        "cloud_required": any(
            decision.required_capabilities for decision in page_decisions
        ),
        "cloud_allowed": bool(cloud_page_numbers),
        "local_result_retained": True,
        "limits_identity": options.limits.identity,
    }
    return HybridRoutingPlan.model_validate(
        {
            **values,
            "routing_plan_sha256": hybrid_identity(
                "document_sdk.pdf.hybrid.routing_plan.v1",
                values,
            ),
        }
    )


def build_cloud_request_plan(
    routing_plan: HybridRoutingPlan,
    *,
    source_sha256: str,
    input_bytes: int,
    limits: HybridLimits,
    planned_request_count: int | None = None,
) -> CloudRequestPlan:
    """Bind a route to one bounded, content-free cloud request plan."""
    page_numbers = tuple(
        decision.page_index + 1
        for decision in routing_plan.page_decisions
        if decision.required_capabilities
    )
    request_count = (
        (1 if page_numbers else 0)
        if planned_request_count is None
        else planned_request_count
    )
    denied = (
        len(page_numbers) > limits.maximum_cloud_pages
        or request_count > limits.maximum_cloud_requests
        or input_bytes > limits.maximum_cloud_input_bytes
    )
    reasons = set(routing_plan.reason_codes) & _DENIAL_REASONS
    if denied:
        reasons.add(HybridRoutingReason.CLOUD_LIMIT_EXCEEDED)
    allowed = bool(page_numbers) and routing_plan.cloud_allowed and not denied
    values = {
        "document_identity": routing_plan.document_identity,
        "source_sha256": source_sha256,
        "page_numbers": page_numbers,
        "capabilities": routing_plan.requested_capabilities,
        "request_count": request_count,
        "input_bytes": input_bytes,
        "submission_scope": "FULL_DOCUMENT_BYTES",
        "analysis_page_scope": "SELECTED_PAGES",
        "allowed": allowed,
        "reason_codes": () if allowed else _canonical_reasons(reasons),
        "limits_identity": limits.identity,
    }
    return CloudRequestPlan.model_validate(
        {
            **values,
            "request_plan_sha256": hybrid_identity(
                "document_sdk.pdf.hybrid.cloud_request_plan.v1",
                values,
            ),
        }
    )


__all__ = [
    "build_cloud_request_plan",
    "build_hybrid_routing_plan",
    "derive_local_page_authorities",
]

# ruff: noqa: C901, EM101, PLR0912, PLR0913, PLR0915, TRY003

"""Element-level merge of local Canonical authority and cloud fragments."""

from __future__ import annotations

from collections import defaultdict
from typing import TYPE_CHECKING, Literal, Self

from pydantic import BaseModel, model_validator

from document_sdk.pdf._structural_engine.canonical.contracts import (
    CanonicalAvailability,
    CanonicalBoundingBox,
    CanonicalCapabilityAvailability,
    CanonicalDocument,
    CanonicalPage,
    CanonicalProvenance,
    CanonicalTable,
    CanonicalTableCell,
    CanonicalTableColumn,
    CanonicalTableRow,
    CanonicalTextBlock,
    CanonicalTextSpan,
)
from document_sdk.pdf._structural_engine.canonical.identifiers import (
    canonical_identifier,
)
from document_sdk.pdf._structural_engine.hybrid.contracts import (
    HYBRID_MERGE_DOMAIN,
    CloudCapabilityFulfillmentState,
    DocumentAnalysisCapability,
    HybridContractModel,
    HybridEffectiveCapabilityState,
    HybridElementOrigin,
    HybridElementProvenance,
    HybridLimits,
    HybridLocalPageAuthority,
    HybridMergeReport,
    HybridPageEffectiveCapabilityOutcome,
    HybridPageRoute,
    HybridPageRoutingDecision,
    HybridRoutingPlan,
    HybridRoutingReason,
    cloud_table_resource_usage,
    hybrid_identity,
)

if TYPE_CHECKING:
    from document_sdk.pdf._structural_engine.hybrid.cloud_projection import (
        CanonicalCloudFragment,
        CanonicalCloudPageFragment,
        CanonicalCloudTableFragment,
        CanonicalCloudTextFragment,
    )

_CLOUD_TABLE_CONTINUITY_LIMITATION = "HYBRID_CLOUD_TABLE_NO_LOCAL_DT_AUTHORITY"
_LOCAL_CLOUD_TABLE_CONFLICT = "LOCAL_CLOUD_TABLE_CONFLICT"
_CLOUD_TEXT_IGNORED_LOCAL_PROVEN = "CLOUD_TEXT_IGNORED_LOCAL_PROVEN"
_CLOUD_TABLE_AVAILABLE_LOCAL_PARTIAL = "CLOUD_TABLE_AVAILABLE_LOCAL_PARTIAL"
_CLOUD_TABLE_OUTCOME = "HYBRID_CLOUD_TABLE"
_CLOUD_TABLE_STATE = "CLOUD_OBSERVED"
_CLOUD_ROLE_STATUS = "CLOUD_OBSERVED"
_CLOUD_PAGE_NOT_RETURNED = "HYBRID_CLOUD_PAGE_NOT_RETURNED"
_CLOUD_OCR_NOT_APPLIED = "HYBRID_CLOUD_OCR_TEXT_NOT_APPLIED"
_CLOUD_OCR_PARTIAL = "HYBRID_CLOUD_OCR_TEXT_PARTIAL"
_CLOUD_TABLE_NOT_APPLIED = "HYBRID_CLOUD_TABLE_NOT_APPLIED"
_CLOUD_TABLE_PARTIAL = "HYBRID_CLOUD_TABLE_PARTIAL"
_CLOUD_LAYOUT_NOT_PROJECTED = "HYBRID_CLOUD_LAYOUT_NOT_EFFECTIVELY_PROJECTED"


class HybridMergeAuthorityError(ValueError):
    """Expected malformed cloud fragment or merge authority mismatch."""


class HybridMergeResourceLimitError(HybridMergeAuthorityError):
    """Cloud table axes exceed the exact bounded merge authority."""


class HybridMergeResult(HybridContractModel):
    """Private merge output consumed by the Hybrid runtime."""

    canonical_document: CanonicalDocument
    merge_report: HybridMergeReport
    element_provenance: tuple[HybridElementProvenance, ...]

    @model_validator(mode="after")
    def validate_provenance(self) -> Self:
        keys = tuple((item.kind, item.canonical_id) for item in self.element_provenance)
        if keys != tuple(sorted(set(keys))):
            raise ValueError("Hybrid merge provenance must be canonical")
        return self


def _effective_capability_outcomes(
    *,
    decision: HybridPageRoutingDecision,
    cloud_page: CanonicalCloudPageFragment | None,
    applied_text_count: int,
    text_completed: bool,
    applied_table_count: int,
    table_completed: bool,
    layout_completed: bool,
    conflict: bool,
) -> tuple[HybridPageEffectiveCapabilityOutcome, ...]:
    outcomes: list[HybridPageEffectiveCapabilityOutcome] = []
    provider_outcomes = (
        {}
        if cloud_page is None
        else {item.capability: item for item in cloud_page.provider_capability_outcomes}
    )
    for capability in decision.required_capabilities:
        state: HybridEffectiveCapabilityState
        applied_count: int
        reasons: tuple[str, ...]
        provider = provider_outcomes.get(capability)
        if provider is None:
            state = HybridEffectiveCapabilityState.UNAVAILABLE
            applied_count = 0
            reasons = (_CLOUD_PAGE_NOT_RETURNED,)
        elif capability is DocumentAnalysisCapability.TABLES and conflict:
            state = HybridEffectiveCapabilityState.CONFLICT
            applied_count = 0
            reasons = (_LOCAL_CLOUD_TABLE_CONFLICT,)
        elif provider.state is not CloudCapabilityFulfillmentState.FULFILLED:
            state = (
                HybridEffectiveCapabilityState.PARTIAL
                if provider.state is CloudCapabilityFulfillmentState.PARTIAL
                else HybridEffectiveCapabilityState.UNAVAILABLE
            )
            applied_count = (
                applied_text_count
                if capability is DocumentAnalysisCapability.OCR_TEXT
                else (
                    applied_table_count
                    if capability is DocumentAnalysisCapability.TABLES
                    else int(bool(applied_text_count or applied_table_count))
                )
            )
            if state is HybridEffectiveCapabilityState.UNAVAILABLE:
                applied_count = 0
            reasons = provider.reason_codes
        elif capability is DocumentAnalysisCapability.OCR_TEXT:
            if applied_text_count and text_completed:
                state = HybridEffectiveCapabilityState.FULFILLED
                applied_count = applied_text_count
                reasons = ()
            elif applied_text_count:
                state = HybridEffectiveCapabilityState.PARTIAL
                applied_count = applied_text_count
                reasons = (_CLOUD_OCR_PARTIAL,)
            else:
                state = HybridEffectiveCapabilityState.NOT_APPLIED
                applied_count = 0
                reasons = (_CLOUD_OCR_NOT_APPLIED,)
        elif capability is DocumentAnalysisCapability.TABLES:
            if applied_table_count and table_completed:
                state = HybridEffectiveCapabilityState.FULFILLED
                applied_count = applied_table_count
                reasons = ()
            elif applied_table_count:
                state = HybridEffectiveCapabilityState.PARTIAL
                applied_count = applied_table_count
                reasons = (_CLOUD_TABLE_PARTIAL,)
            else:
                state = HybridEffectiveCapabilityState.NOT_APPLIED
                applied_count = 0
                reasons = (_CLOUD_TABLE_NOT_APPLIED,)
        else:
            applied_layout_count = int(bool(applied_text_count or applied_table_count))
            if applied_layout_count and layout_completed:
                state = HybridEffectiveCapabilityState.FULFILLED
                applied_count = applied_layout_count
                reasons = ()
            elif applied_layout_count:
                state = HybridEffectiveCapabilityState.PARTIAL
                applied_count = applied_layout_count
                reasons = (_CLOUD_LAYOUT_NOT_PROJECTED,)
            else:
                state = HybridEffectiveCapabilityState.NOT_APPLIED
                applied_count = 0
                reasons = (_CLOUD_LAYOUT_NOT_PROJECTED,)
        outcomes.append(
            HybridPageEffectiveCapabilityOutcome(
                page_index=decision.page_index,
                capability=capability,
                state=state,
                applied_item_count=applied_count,
                reason_codes=reasons,
            )
        )
    return tuple(outcomes)


def _identified[CanonicalT: BaseModel](
    model: type[CanonicalT],
    *,
    field: str,
    kind: str,
    values: dict[str, object],
) -> CanonicalT:
    return model.model_validate(
        {
            field: canonical_identifier(kind, values),
            **values,
        }
    )


def _sorted_strings(*inventories: tuple[str, ...]) -> tuple[str, ...]:
    return tuple(sorted({item for values in inventories for item in values}))


def _page_reasons(
    routing_plan: HybridRoutingPlan,
    page_index: int,
) -> tuple[HybridRoutingReason, ...]:
    for decision in routing_plan.page_decisions:
        if decision.page_index == page_index:
            return decision.reason_codes
    return ()


def _document_fallback_reasons(
    routing_plan: HybridRoutingPlan,
    *,
    requested_page_numbers: tuple[int, ...],
    effective_page_indexes: set[int],
) -> tuple[HybridRoutingReason, ...]:
    relevant_indexes = {
        page_number - 1 for page_number in requested_page_numbers
    } | effective_page_indexes
    return tuple(
        sorted(
            {
                reason
                for decision in routing_plan.page_decisions
                if decision.page_index in relevant_indexes
                for reason in decision.reason_codes
            },
            key=lambda item: item.value,
        )
    )


def _provenance(
    *,
    canonical_id: str,
    kind: str,
    origin: HybridElementOrigin = HybridElementOrigin.LOCAL,
    fragment: CanonicalCloudFragment | None = None,
    page_index: int = 0,
    routing_plan: HybridRoutingPlan | None = None,
    fallback_reason_codes: tuple[HybridRoutingReason, ...] | None = None,
) -> HybridElementProvenance:
    if origin is HybridElementOrigin.LOCAL:
        return HybridElementProvenance(
            canonical_id=canonical_id,
            kind=kind,
            origin=origin,
        )
    if fragment is None or routing_plan is None:
        raise ValueError(
            "cloud provenance requires exact provider and routing evidence"
        )
    return HybridElementProvenance(
        canonical_id=canonical_id,
        kind=kind,
        origin=origin,
        provider=fragment.provider,
        model_id=fragment.model_id,
        api_version=fragment.api_version,
        request_identity=fragment.request_identity,
        submission_scope=fragment.submission_scope,
        analysis_page_scope=fragment.analysis_page_scope,
        requested_page_numbers=fragment.requested_page_numbers,
        fallback_reason_codes=(
            _page_reasons(routing_plan, page_index)
            if fallback_reason_codes is None
            else fallback_reason_codes
        ),
    )


def _cloud_text_block(
    item: CanonicalCloudTextFragment,
    *,
    page_id: str,
    block_index: int,
) -> CanonicalTextBlock:
    span_values: dict[str, object] = {
        "source_fact_id": item.source_cloud_block_id,
        "source_layout_node_id": None,
        "span_index": 0,
        "text": item.text,
        "bbox": item.bbox,
        "font_name": None,
        "font_size": None,
        "rotation": None,
        "availability": item.availability,
    }
    span = _identified(
        CanonicalTextSpan,
        field="span_id",
        kind="text-span",
        values=span_values,
    )
    limitations = (
        item.availability.reason_codes if item.availability.state != "AVAILABLE" else ()
    )
    block_values: dict[str, object] = {
        "page_id": page_id,
        "source_block_id": item.source_cloud_block_id,
        "block_index": block_index,
        "text": item.text,
        "bbox": item.bbox,
        "spans": (span,),
        "role": item.source_role or "cloud_ocr_text",
        "role_status": "cloud_fallback",
        "availability": item.availability,
        "limitation_codes": limitations,
    }
    return _identified(
        CanonicalTextBlock,
        field="text_block_id",
        kind="text-block",
        values=block_values,
    )


def _cell_axis_bbox(
    table: CanonicalCloudTableFragment,
    *,
    index: int,
    axis: Literal["row", "column"],
) -> CanonicalBoundingBox:
    bounds: tuple[float, float, float, float] | None = None
    for item in table.cells:
        matches_axis = (
            item.row_index <= index < item.row_index + item.row_span
            if axis == "row"
            else item.column_index <= index < item.column_index + item.column_span
        )
        if not matches_axis:
            continue
        bounds = (
            item.bbox.x0 if bounds is None else min(bounds[0], item.bbox.x0),
            item.bbox.y0 if bounds is None else min(bounds[1], item.bbox.y0),
            item.bbox.x1 if bounds is None else max(bounds[2], item.bbox.x1),
            item.bbox.y1 if bounds is None else max(bounds[3], item.bbox.y1),
        )
    if bounds is None:
        message = f"cloud table {axis} lacks bounded cell geometry"
        raise HybridMergeAuthorityError(message)
    return CanonicalBoundingBox(x0=bounds[0], y0=bounds[1], x1=bounds[2], y1=bounds[3])


def _cell_role(kind: str | None) -> str:
    normalized = None if kind is None else kind.casefold()
    if normalized == "rowheader":
        return "ROW_HEADER_LIKE"
    # Azure stubHead is column-axis header authority.
    if normalized in {"columnheader", "stubhead"}:
        return "COLUMN_HEADER_LIKE"
    return "BODY_LIKE"


def _cloud_table(
    item: CanonicalCloudTableFragment,
    *,
    page_id: str,
) -> CanonicalTable:
    table_values_for_id = {
        "page_id": page_id,
        "source_table_id": item.source_cloud_table_id,
        "table_ordinal": item.ordinal,
        "bbox": item.bbox,
        "state": _CLOUD_TABLE_STATE,
    }
    table_id = canonical_identifier("table", table_values_for_id)
    row_bboxes = {
        index: _cell_axis_bbox(item, index=index, axis="row")
        for index in range(item.row_count)
    }
    column_bboxes = {
        index: _cell_axis_bbox(item, index=index, axis="column")
        for index in range(item.column_count)
    }
    row_ids = {
        index: canonical_identifier(
            "table-row",
            {
                "table_id": table_id,
                "source_row_id": f"{item.source_cloud_table_id}:row:{index}",
                "row_index": index,
                "bbox": row_bboxes[index],
            },
        )
        for index in range(item.row_count)
    }
    column_ids = {
        index: canonical_identifier(
            "table-column",
            {
                "table_id": table_id,
                "source_column_id": (f"{item.source_cloud_table_id}:column:{index}"),
                "column_index": index,
                "bbox": column_bboxes[index],
            },
        )
        for index in range(item.column_count)
    }
    cells: list[CanonicalTableCell] = []
    cells_by_row: dict[int, list[str]] = defaultdict(list)
    cells_by_column: dict[int, list[str]] = defaultdict(list)
    for fragment_cell in item.cells:
        limitations = (
            fragment_cell.availability.reason_codes
            if fragment_cell.availability.state != "AVAILABLE"
            else ()
        )
        values: dict[str, object] = {
            "table_id": table_id,
            "row_id": row_ids[fragment_cell.row_index],
            "source_cell_id": fragment_cell.source_cloud_cell_id,
            "row_index": fragment_cell.row_index,
            "column_index": fragment_cell.column_index,
            "row_span": fragment_cell.row_span,
            "column_span": fragment_cell.column_span,
            "text": fragment_cell.text,
            "text_available": True,
            "bbox": fragment_cell.bbox,
            "state": _CLOUD_TABLE_STATE,
            "role": _cell_role(fragment_cell.kind),
            "role_status": _CLOUD_ROLE_STATUS,
            "availability": fragment_cell.availability,
            "limitation_codes": limitations,
        }
        cell = _identified(
            CanonicalTableCell,
            field="cell_id",
            kind="table-cell",
            values=values,
        )
        cells.append(cell)
        cells_by_row[cell.row_index].append(cell.cell_id)
        cells_by_column[cell.column_index].append(cell.cell_id)
    rows = tuple(
        CanonicalTableRow(
            row_id=row_ids[index],
            table_id=table_id,
            source_row_id=f"{item.source_cloud_table_id}:row:{index}",
            row_index=index,
            cell_ids=tuple(cells_by_row[index]),
            bbox=row_bboxes[index],
            availability=item.availability,
        )
        for index in range(item.row_count)
    )
    columns = tuple(
        CanonicalTableColumn(
            column_id=column_ids[index],
            table_id=table_id,
            source_column_id=f"{item.source_cloud_table_id}:column:{index}",
            column_index=index,
            cell_ids=tuple(cells_by_column[index]),
            bbox=column_bboxes[index],
            availability=item.availability,
        )
        for index in range(item.column_count)
    )
    table_limitations = (
        item.availability.reason_codes if item.availability.state != "AVAILABLE" else ()
    )
    return CanonicalTable(
        table_id=table_id,
        page_id=page_id,
        source_table_id=item.source_cloud_table_id,
        table_ordinal=item.ordinal,
        bbox=item.bbox,
        row_count=item.row_count,
        column_count=item.column_count,
        rows=rows,
        columns=columns,
        cells=tuple(cells),
        document_table_ids=(),
        state=_CLOUD_TABLE_STATE,
        availability=item.availability,
        limitation_codes=table_limitations,
    )


def _text_fill_allowed(page: CanonicalPage) -> bool:
    return not page.text_blocks or all(
        item.availability.state in {"UNAVAILABLE", "UNSUPPORTED", "LIMITED_EVIDENCE"}
        for item in page.text_blocks
    )


def _table_fill_allowed(
    authority: HybridLocalPageAuthority,
    local_tables: tuple[CanonicalTable, ...],
    *,
    has_continuity_authority: bool,
) -> bool:
    return (
        not has_continuity_authority
        and (
            not local_tables
            or all(
                item.availability.state
                in {"UNAVAILABLE", "UNSUPPORTED", "LIMITED_EVIDENCE"}
                for item in local_tables
            )
        )
        and not authority.no_table_proven
        and authority.table_availability
        in {"UNAVAILABLE", "UNSUPPORTED", "LIMITED_EVIDENCE", "PARTIAL"}
    )


def _aggregate_availability(
    values: tuple[CanonicalAvailability, ...],
    *,
    partial_reason: str,
) -> CanonicalAvailability:
    if not values:
        raise ValueError("availability aggregation requires evidence")
    states = {item.state for item in values}
    if states == {"AVAILABLE"}:
        return CanonicalAvailability(state="AVAILABLE")
    reasons = {reason for item in values for reason in item.reason_codes}
    if len(states) == 1:
        state = next(iter(states))
    else:
        state = "PARTIAL"
        reasons.add(partial_reason)
    if not reasons:
        reasons.add(partial_reason)
    return CanonicalAvailability.model_validate(
        {"state": state, "reason_codes": tuple(sorted(reasons))}
    )


def _updated_capabilities(
    local_document: CanonicalDocument,
    *,
    cloud_tables_present: bool,
    final_pages: tuple[CanonicalPage, ...],
    routing_plan: HybridRoutingPlan,
    completed_text_pages: set[int],
    completed_layout_pages: set[int],
) -> tuple[CanonicalCapabilityAvailability, ...]:
    recovered: set[str] = set()
    for capability, name, completed_pages in (
        (DocumentAnalysisCapability.OCR_TEXT, "reading", completed_text_pages),
        (DocumentAnalysisCapability.LAYOUT, "layout", completed_layout_pages),
    ):
        required_pages = {
            item.page_index
            for item in routing_plan.page_decisions
            if capability in item.required_capabilities
        }
        if required_pages and required_pages <= completed_pages:
            recovered.add(name)
    result = []
    for item in local_document.capability_availability:
        if item.capability in recovered and item.availability.state != "AVAILABLE":
            result.append(
                CanonicalCapabilityAvailability(
                    capability=item.capability,
                    availability=CanonicalAvailability(state="AVAILABLE"),
                )
            )
        elif (
            cloud_tables_present
            and item.capability == "page_table"
            and item.availability.state
            in {
                "UNAVAILABLE",
                "UNSUPPORTED",
                "LIMITED_EVIDENCE",
                "PARTIAL",
            }
        ):
            result.append(
                CanonicalCapabilityAvailability(
                    capability=item.capability,
                    availability=_aggregate_availability(
                        tuple(page.page_table_availability for page in final_pages),
                        partial_reason="PAGE_TABLE_PARTIAL",
                    ),
                )
            )
        else:
            result.append(item)
    return tuple(result)


def _document_provenance(
    local: CanonicalProvenance,
    *,
    fragment: CanonicalCloudFragment,
    cloud_effect: bool,
) -> CanonicalProvenance:
    if not cloud_effect:
        return local
    return CanonicalProvenance.model_validate(
        {
            **local.model_dump(mode="python"),
            "upstream_schema_versions": _sorted_strings(
                local.upstream_schema_versions,
                (fragment.schema_version,),
            ),
            "upstream_artifact_ids": _sorted_strings(
                local.upstream_artifact_ids,
                (fragment.cloud_payload_sha256,),
            ),
        }
    )


def merge_canonical_with_cloud(
    local_document: CanonicalDocument,
    fragment: CanonicalCloudFragment,
    *,
    routing_plan: HybridRoutingPlan,
    limits: HybridLimits,
) -> HybridMergeResult:
    """Merge cloud evidence without replacing proven local elements or DT authority."""
    from document_sdk.pdf._structural_engine.hybrid.cloud_projection import (
        CanonicalCloudFragment,
    )
    from document_sdk.pdf._structural_engine.hybrid.router import (
        derive_local_page_authorities,
    )

    if (
        type(fragment) is not CanonicalCloudFragment
        or type(routing_plan) is not HybridRoutingPlan
        or type(limits) is not HybridLimits
    ):
        raise HybridMergeAuthorityError("cloud merge input lacks exact authority")
    try:
        fragment = CanonicalCloudFragment.model_validate(
            fragment.model_dump(mode="python", warnings=False)
        )
        routing_plan = HybridRoutingPlan.model_validate(
            routing_plan.model_dump(mode="python", warnings=False)
        )
        limits = HybridLimits.model_validate(
            limits.model_dump(mode="python", warnings=False)
        )
    except (TypeError, ValueError):
        raise HybridMergeAuthorityError(
            "cloud merge input fails canonical capability authority"
        ) from None
    fragment_already_bound = (
        fragment.cloud_payload_sha256 in local_document.provenance.upstream_artifact_ids
    )
    if (
        fragment.source_document_identity != local_document.source_document_identity
        or fragment.source_sha256 != local_document.provenance.source_sha256
        or routing_plan.document_identity != fragment.local_canonical_document_id
        or fragment.routing_plan_sha256 != routing_plan.routing_plan_sha256
        or routing_plan.limits_identity != limits.identity
        or fragment.requested_page_numbers != routing_plan.cloud_page_numbers
        or (
            fragment.local_canonical_document_id != local_document.canonical_document_id
            and not fragment_already_bound
        )
    ):
        raise HybridMergeAuthorityError("cloud merge crosses local document authority")

    rows_total, columns_total, axis_materialization_work = cloud_table_resource_usage(
        table for page in fragment.pages for table in page.tables
    )
    if (
        rows_total > limits.maximum_cloud_rows_total
        or columns_total > limits.maximum_cloud_columns_total
        or axis_materialization_work > limits.maximum_cloud_axis_materialization_work
    ):
        raise HybridMergeResourceLimitError("cloud table resource limit exceeded")

    fragment_pages = {item.page_index: item for item in fragment.pages}
    decisions_by_page = {item.page_index: item for item in routing_plan.page_decisions}
    for fragment_page in fragment.pages:
        decision = decisions_by_page.get(fragment_page.page_index)
        if (
            decision is None
            or decision.route is not HybridPageRoute.CLOUD
            or fragment_page.required_capabilities != decision.required_capabilities
            or (
                fragment_page.text_blocks
                and DocumentAnalysisCapability.OCR_TEXT
                not in decision.required_capabilities
            )
            or (
                fragment_page.tables
                and DocumentAnalysisCapability.TABLES
                not in decision.required_capabilities
            )
        ):
            raise HybridMergeAuthorityError(
                "cloud fragment exceeds page capability authority"
            )
    local_tables_by_page: defaultdict[str, list[CanonicalTable]] = defaultdict(list)
    for table in local_document.tables:
        local_tables_by_page[table.page_id].append(table)
    continuity_table_ids = {
        table_id
        for item in local_document.document_tables
        for table_id in item.table_ids
    } | {
        table_id
        for item in local_document.transitions
        for table_id in (item.left_table_id, item.right_table_id)
    }
    local_authorities = derive_local_page_authorities(local_document)
    local_authorities_by_page = {
        authority.page_index: authority for authority in local_authorities
    }
    if tuple(local_authorities_by_page) != tuple(
        page.page_index for page in local_document.pages
    ):
        raise HybridMergeAuthorityError(
            "local table authority does not match Canonical pages"
        )
    final_pages: list[CanonicalPage] = []
    final_tables: list[CanonicalTable] = []
    provenance_specs: list[tuple[str, str, HybridElementOrigin, int]] = []
    local_text_count = 0
    cloud_text_count = 0
    local_table_count = 0
    cloud_table_count = 0
    conflict_count = 0
    cloud_filled_page_indexes: set[int] = set()
    completed_text_page_indexes: set[int] = set()
    completed_layout_page_indexes: set[int] = set()
    report_warnings = set(fragment.warnings)
    report_limitations = set(fragment.limitations)
    effective_outcomes: list[HybridPageEffectiveCapabilityOutcome] = []

    for page in local_document.pages:
        local_authority = local_authorities_by_page[page.page_index]
        cloud_page = fragment_pages.get(page.page_index)
        if cloud_page is not None and cloud_page.local_page_id != page.page_id:
            raise HybridMergeAuthorityError("cloud merge crosses local page authority")
        cloud_block_ids = (
            {item.source_cloud_block_id for item in cloud_page.text_blocks}
            if cloud_page is not None
            else set()
        )
        existing_cloud_blocks = tuple(
            item for item in page.text_blocks if item.source_block_id in cloud_block_ids
        )
        if existing_cloud_blocks:
            final_blocks = page.text_blocks
        elif (
            cloud_page is not None
            and cloud_page.text_blocks
            and _text_fill_allowed(page)
        ):
            final_blocks = tuple(
                _cloud_text_block(
                    item,
                    page_id=page.page_id,
                    block_index=index,
                )
                for index, item in enumerate(cloud_page.text_blocks)
            )
        else:
            final_blocks = page.text_blocks
        page_cloud_blocks = tuple(
            item for item in final_blocks if item.source_block_id in cloud_block_ids
        )
        cloud_text_count += len(page_cloud_blocks)
        local_text_count += len(final_blocks) - len(page_cloud_blocks)
        if page_cloud_blocks:
            cloud_filled_page_indexes.add(page.page_index)
            if all(item.availability.state == "AVAILABLE" for item in final_blocks):
                completed_text_page_indexes.add(page.page_index)
                completed_layout_page_indexes.add(page.page_index)
        elif (
            cloud_page is not None
            and cloud_page.text_blocks
            and any(
                item.availability.state == "AVAILABLE" or item.role_status == "proven"
                for item in page.text_blocks
            )
        ):
            report_warnings.add(_CLOUD_TEXT_IGNORED_LOCAL_PROVEN)

        page_local_tables = tuple(local_tables_by_page[page.page_id])
        cloud_table_ids = (
            {item.source_cloud_table_id for item in cloud_page.tables}
            if cloud_page is not None
            else set()
        )
        existing_cloud_tables = tuple(
            item
            for item in page_local_tables
            if item.source_table_id in cloud_table_ids
        )
        genuine_local_tables = tuple(
            item
            for item in page_local_tables
            if item.source_table_id not in cloud_table_ids
        )
        no_table_proven = local_authority.no_table_proven
        conflict = bool(cloud_page and cloud_page.tables and no_table_proven)
        local_partial_table_retained = bool(
            cloud_page
            and cloud_page.tables
            and any(
                item.availability.state in {"PARTIAL", "LIMITED_EVIDENCE"}
                for item in genuine_local_tables
            )
        )
        if conflict:
            conflict_count += 1
            report_warnings.add(_LOCAL_CLOUD_TABLE_CONFLICT)
            final_page_tables = page_local_tables
        elif existing_cloud_tables:
            final_page_tables = page_local_tables
        elif (
            cloud_page is not None
            and cloud_page.tables
            and _table_fill_allowed(
                local_authority,
                page_local_tables,
                has_continuity_authority=any(
                    item.table_id in continuity_table_ids for item in page_local_tables
                ),
            )
        ):
            projected_tables = tuple(
                _cloud_table(item, page_id=page.page_id) for item in cloud_page.tables
            )
            final_page_tables = projected_tables
        else:
            final_page_tables = page_local_tables
            if local_partial_table_retained:
                report_limitations.add(_CLOUD_TABLE_AVAILABLE_LOCAL_PARTIAL)
        page_cloud_tables = tuple(
            item
            for item in final_page_tables
            if item.source_table_id in cloud_table_ids
        )
        if page_cloud_tables and not conflict:
            cloud_table_count += len(page_cloud_tables)
            cloud_filled_page_indexes.add(page.page_index)
            report_limitations.add(_CLOUD_TABLE_CONTINUITY_LIMITATION)
            if all(
                item.availability.state == "AVAILABLE" for item in page_cloud_tables
            ):
                completed_layout_page_indexes.add(page.page_index)
        local_table_count += sum(
            item.source_table_id not in cloud_table_ids for item in final_page_tables
        )
        final_tables.extend(final_page_tables)

        page_limitations = set(page.limitation_codes)
        page_table_outcome: str | None
        if any(item.source_table_id in cloud_table_ids for item in final_page_tables):
            page_limitations.discard("PAGE_TABLE_UNAVAILABLE")
            page_limitations.add(_CLOUD_TABLE_CONTINUITY_LIMITATION)
            page_table_outcome = _CLOUD_TABLE_OUTCOME
            page_table_availability = _aggregate_availability(
                tuple(
                    item.availability
                    for item in final_page_tables
                    if item.source_table_id in cloud_table_ids
                ),
                partial_reason="HYBRID_CLOUD_PAGE_TABLE_PARTIAL",
            )
            negative_table_evidence: tuple[str, ...] = ()
        else:
            page_table_outcome = page.page_table_outcome
            page_table_availability = page.page_table_availability
            negative_table_evidence = page.page_table_negative_evidence_categories
        if conflict:
            page_limitations.add(_LOCAL_CLOUD_TABLE_CONFLICT)
        cloud_effect_on_page = page.page_index in cloud_filled_page_indexes or conflict
        page_availability = page.availability
        if cloud_effect_on_page:
            if page.page_index in completed_text_page_indexes:
                page_limitations.discard("READING_STRUCTURE_UNAVAILABLE")
            decision = decisions_by_page[page.page_index]
            fulfilled = set()
            if page.page_index in completed_text_page_indexes:
                fulfilled.add(DocumentAnalysisCapability.OCR_TEXT)
            if page.page_index in completed_layout_page_indexes:
                fulfilled.add(DocumentAnalysisCapability.LAYOUT)
            if (
                any(
                    item.source_table_id in cloud_table_ids
                    for item in final_page_tables
                )
                and page_table_availability.state == "AVAILABLE"
            ):
                fulfilled.add(DocumentAnalysisCapability.TABLES)
            page_complete = (
                set(decision.required_capabilities) <= fulfilled
                and page_table_availability.state == "AVAILABLE"
                and not conflict
                and not any(
                    item.source_table_id in cloud_table_ids
                    for item in final_page_tables
                )
                and not (cloud_page and cloud_page.limitations)
            )
            if page_complete:
                page_availability = CanonicalAvailability(state="AVAILABLE")
            else:
                reasons = tuple(sorted(page_limitations)) or (
                    "HYBRID_CLOUD_EVIDENCE_PARTIAL",
                )
                page_availability = CanonicalAvailability(
                    state="PARTIAL",
                    reason_codes=reasons,
                )
        final_page = CanonicalPage.model_validate(
            {
                **page.model_dump(mode="python"),
                "text_blocks": final_blocks,
                "table_ids": tuple(item.table_id for item in final_page_tables),
                "page_table_outcome": page_table_outcome,
                "page_table_availability": page_table_availability,
                "page_table_negative_evidence_categories": negative_table_evidence,
                "availability": page_availability,
                "limitation_codes": tuple(sorted(page_limitations)),
            }
        )
        final_pages.append(final_page)

        decision = decisions_by_page[page.page_index]
        if decision.route is HybridPageRoute.CLOUD:
            effective_outcomes.extend(
                _effective_capability_outcomes(
                    decision=decision,
                    cloud_page=cloud_page,
                    applied_text_count=len(page_cloud_blocks),
                    text_completed=(page.page_index in completed_text_page_indexes),
                    applied_table_count=len(page_cloud_tables),
                    table_completed=(
                        bool(page_cloud_tables)
                        and page_table_availability.state == "AVAILABLE"
                        and not conflict
                    ),
                    layout_completed=(page.page_index in completed_layout_page_indexes),
                    conflict=conflict,
                )
            )

        page_has_cloud = page.page_index in cloud_filled_page_indexes
        page_origin = (
            HybridElementOrigin.LOCAL_WITH_CLOUD_FILL
            if page_has_cloud and cloud_page is not None
            else HybridElementOrigin.LOCAL
        )
        provenance_specs.append(("page", page.page_id, page_origin, page.page_index))
        provenance_specs.extend(
            ("drawing", item.drawing_id, HybridElementOrigin.LOCAL, page.page_index)
            for item in page.drawings
        )
        for block in final_blocks:
            cloud_block = (
                block.source_block_id in cloud_block_ids and cloud_page is not None
            )
            origin = (
                HybridElementOrigin.CLOUD if cloud_block else HybridElementOrigin.LOCAL
            )
            provenance_specs.append(
                ("text_block", block.text_block_id, origin, page.page_index)
            )
            provenance_specs.extend(
                ("text_span", span.span_id, origin, page.page_index)
                for span in block.spans
            )
        for table in final_page_tables:
            cloud_table = (
                table.source_table_id in cloud_table_ids and cloud_page is not None
            )
            origin = (
                HybridElementOrigin.CLOUD if cloud_table else HybridElementOrigin.LOCAL
            )
            provenance_specs.extend(
                (kind, canonical_id, origin, page.page_index)
                for kind, canonical_id in (
                    ("table", table.table_id),
                    *(("table_row", item.row_id) for item in table.rows),
                    *(("table_column", item.column_id) for item in table.columns),
                    *(("table_cell", item.cell_id) for item in table.cells),
                )
            )
        if cloud_page is not None:
            report_warnings.update(cloud_page.warnings)
            report_limitations.update(cloud_page.limitations)

    provenance_specs.extend(
        spec
        for document_table in local_document.document_tables
        for spec in (
            (
                "document_table",
                document_table.document_table_id,
                HybridElementOrigin.LOCAL,
                0,
            ),
            *(
                ("logical_row", item.logical_row_id, HybridElementOrigin.LOCAL, 0)
                for item in document_table.logical_rows
            ),
        )
    )
    provenance_specs.extend(
        ("transition", item.transition_id, HybridElementOrigin.LOCAL, 0)
        for item in local_document.transitions
    )

    cloud_effect = bool(cloud_text_count or cloud_table_count or conflict_count)
    capabilities = _updated_capabilities(
        local_document,
        cloud_tables_present=bool(cloud_table_count),
        final_pages=tuple(final_pages),
        routing_plan=routing_plan,
        completed_text_pages=completed_text_page_indexes,
        completed_layout_pages=completed_layout_page_indexes,
    )
    document_limitations = set(local_document.limitations)
    original_capabilities = {
        item.capability: item.availability
        for item in local_document.capability_availability
    }
    for item in capabilities:
        original = original_capabilities[item.capability]
        if item.availability.state == "AVAILABLE" and original.state != "AVAILABLE":
            document_limitations.difference_update(original.reason_codes)
            if item.capability == "reading":
                document_limitations.discard("OCR_NOT_EXECUTED")
    if cloud_effect:
        document_limitations.update(report_limitations)
    if conflict_count:
        document_limitations.add(_LOCAL_CLOUD_TABLE_CONFLICT)
    document_availability = local_document.availability
    if cloud_effect:
        capability_by_name = {
            item.capability: item.availability for item in capabilities
        }
        core_complete = all(
            capability_by_name[name].state == "AVAILABLE"
            for name in ("facts", "layout", "reading", "page_table")
        )
        completion_blocked = bool(
            conflict_count
            or cloud_table_count
            or fragment.missing_page_numbers
            or report_limitations
        )
        if core_complete and not completion_blocked:
            document_availability = CanonicalAvailability(state="AVAILABLE")
        else:
            document_availability = CanonicalAvailability(
                state="PARTIAL",
                reason_codes=tuple(sorted(document_limitations))
                or ("HYBRID_CLOUD_EVIDENCE_PARTIAL",),
            )
    document_values: dict[str, object] = {
        **local_document.model_dump(
            mode="python",
            exclude={"canonical_document_id"},
        ),
        "projected_page_count": len(final_pages),
        "pages": tuple(final_pages),
        "tables": tuple(final_tables),
        "limitations": tuple(sorted(document_limitations)),
        "provenance": _document_provenance(
            local_document.provenance,
            fragment=fragment,
            cloud_effect=cloud_effect,
        ),
        "availability": document_availability,
        "capability_availability": capabilities,
    }
    merged_document = _identified(
        CanonicalDocument,
        field="canonical_document_id",
        kind="document",
        values=document_values,
    )
    document_origin = (
        HybridElementOrigin.LOCAL_WITH_CLOUD_FILL
        if cloud_effect
        else HybridElementOrigin.LOCAL
    )
    provenance_specs.append(
        (
            "document",
            merged_document.canonical_document_id,
            document_origin,
            0,
        )
    )
    document_fallback_reason_codes = _document_fallback_reasons(
        routing_plan,
        requested_page_numbers=fragment.requested_page_numbers,
        effective_page_indexes=cloud_filled_page_indexes,
    )
    provenance_tuple = tuple(
        sorted(
            (
                _provenance(
                    kind=kind,
                    canonical_id=canonical_id,
                    origin=origin,
                    fragment=fragment,
                    page_index=page_index,
                    routing_plan=routing_plan,
                    fallback_reason_codes=(
                        document_fallback_reason_codes if kind == "document" else None
                    ),
                )
                for kind, canonical_id, origin, page_index in provenance_specs
            ),
            key=lambda item: (item.kind, item.canonical_id),
        )
    )
    report_values: dict[str, object] = {
        "local_pages": len(local_document.pages),
        "cloud_requested_pages": len(fragment.requested_page_numbers),
        "cloud_filled_pages": len(cloud_filled_page_indexes),
        "local_preserved_text_count": local_text_count,
        "cloud_filled_text_count": cloud_text_count,
        "local_preserved_table_count": local_table_count,
        "cloud_filled_table_count": cloud_table_count,
        "conflict_count": conflict_count,
        "continuity_unavailable_count": cloud_table_count,
        "effective_capability_outcomes": tuple(
            sorted(
                effective_outcomes,
                key=lambda item: (item.page_index, item.capability.value),
            )
        ),
        "warnings": tuple(sorted(report_warnings)),
        "limitations": tuple(sorted(report_limitations)),
        "review_required": bool(
            conflict_count
            or report_limitations
            or fragment.availability.state != "AVAILABLE"
        ),
    }
    merge_report = HybridMergeReport.model_validate(
        {
            **report_values,
            "merge_identity": hybrid_identity(HYBRID_MERGE_DOMAIN, report_values),
        }
    )
    return HybridMergeResult(
        canonical_document=merged_document,
        merge_report=merge_report,
        element_provenance=provenance_tuple,
    )


__all__ = [
    "HybridMergeAuthorityError",
    "HybridMergeResourceLimitError",
    "HybridMergeResult",
    "merge_canonical_with_cloud",
]

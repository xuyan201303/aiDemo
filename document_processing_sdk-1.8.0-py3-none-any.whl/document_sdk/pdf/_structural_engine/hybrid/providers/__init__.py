"""Private, explicitly configured Hybrid document-analysis providers."""

from .azure_document_intelligence import AzureDocumentIntelligenceAdapter

__all__ = ["AzureDocumentIntelligenceAdapter"]

"""Explicit, private Azure Document Intelligence Hybrid adapter."""

# ruff: noqa: C901, EM101, PLR0912, PLR0913, PLR0915, TRY003, TRY004

from __future__ import annotations

from collections.abc import Iterable, Iterator, Mapping
from hashlib import sha256
from io import BytesIO
from math import isfinite
from re import fullmatch
from time import monotonic
from typing import Any, NoReturn, cast

from pydantic import ValidationError

from document_sdk.core import DependencyNotInstalledError
from document_sdk.core._exceptions import redact_exception
from document_sdk.pdf._structural_engine.hybrid.contracts import (
    _MAX_CLOUD_TABLE_DIMENSION,
    HYBRID_CLOUD_DOCUMENT_DOMAIN,
    CloudCapabilityFulfillmentState,
    CloudDocumentAnalysisArtifact,
    CloudPage,
    CloudPageCapabilityOutcome,
    CloudPoint,
    CloudPolygon,
    CloudTable,
    CloudTableCell,
    CloudTextBlock,
    DocumentAnalysisCapability,
    DocumentAnalysisRequest,
    HybridAnalysisError,
    HybridAnalysisMode,
    HybridAvailabilityState,
    HybridDeletionStatus,
    HybridFailureCategory,
    HybridFailureLimitation,
    hybrid_identity,
    normalized_cloud_payload_for_size,
)
from document_sdk.pdf._structural_engine.structure.identity import canonical_json_bytes

_PROVIDER = "AZURE_DOCUMENT_INTELLIGENCE"
_MODEL = "prebuilt-layout"
_API_VERSION = "2024-11-30"
_OPERATION_ID = r"[A-Za-z0-9._:-]{1,160}"
_MAX_POLYGON_POINTS = 32
_MISSING = object()
_IDENTITIES = {
    CloudTextBlock: (
        "cloud_block_id",
        "P3HY1-cloud-text-",
        "document_sdk.pdf.hybrid.cloud_text.v1",
    ),
    CloudTableCell: (
        "cloud_cell_id",
        "P3HY1-cloud-cell-",
        "document_sdk.pdf.hybrid.cloud_cell.v1",
    ),
    CloudTable: (
        "cloud_table_id",
        "P3HY1-cloud-table-",
        "document_sdk.pdf.hybrid.cloud_table.v1",
    ),
    CloudPage: (
        "cloud_page_id",
        "P3HY1-cloud-page-",
        "document_sdk.pdf.hybrid.cloud_page.v1",
    ),
}


def _get(value: object, name: str, default: object = None) -> object:
    if isinstance(value, Mapping):
        mapped = value.get(name, _MISSING)
        if mapped is not _MISSING:
            return mapped
    return getattr(value, name, default)


def _items(value: object) -> Iterator[object]:
    if value is None:
        return iter(())
    if isinstance(value, Iterable) and not isinstance(value, (str, bytes, bytearray)):
        return iter(value)
    raise ValueError("provider collection is invalid")


def _number(value: object, *, positive: bool = False) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("provider number is invalid")
    result = float(value)
    if not isfinite(result) or (positive and result <= 0):
        raise ValueError("provider number is outside bounds")
    return result


def _integer(value: object, *, minimum: int = 0) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError("provider integer is invalid")
    return value


def _span(value: object) -> int:
    return 1 if value is None else _integer(value, minimum=1)


def _table_dimension(value: object) -> int:
    result = _integer(value, minimum=1)
    if result > _MAX_CLOUD_TABLE_DIMENSION:
        raise OverflowError("provider table dimension limit exceeded")
    return result


def _table_span(value: object) -> int:
    result = _span(value)
    if result > _MAX_CLOUD_TABLE_DIMENSION:
        raise OverflowError("provider table span limit exceeded")
    return result


def _text(value: object) -> str:
    if not isinstance(value, str):
        raise ValueError("provider text is invalid")
    return value


def _polygon(value: object, width: float, height: float) -> CloudPolygon:
    raw = _items(value)
    points: list[CloudPoint] = []
    pending: float | None = None
    for item in raw:
        if len(points) >= _MAX_POLYGON_POINTS:
            raise ValueError("provider polygon exceeds bounds")
        if isinstance(item, (int, float)) and not isinstance(item, bool):
            coordinate = _number(item)
            if pending is None:
                pending = coordinate
                continue
            x, y, pending = pending, coordinate, None
        else:
            if pending is not None:
                raise ValueError("provider polygon is malformed")
            x = _number(_get(item, "x"))
            y = _number(_get(item, "y"))
        normalized_x, normalized_y = x / width, y / height
        if not 0 <= normalized_x <= 1 or not 0 <= normalized_y <= 1:
            raise ValueError("provider polygon is outside page bounds")
        points.append(CloudPoint(x=normalized_x, y=normalized_y))
    if pending is not None:
        raise ValueError("provider polygon is malformed")
    return CloudPolygon(points=tuple(points))


def _confidence(value: object) -> float | None:
    if value is None:
        return None
    result = _number(value)
    if not 0 <= result <= 1:
        raise ValueError("provider confidence is outside bounds")
    return result


def _region(item: object, requested: set[int]) -> tuple[int, object]:
    regions = _items(_get(item, "bounding_regions"))
    try:
        region = next(regions)
    except StopIteration:
        raise ValueError("provider item has no page authority") from None
    page_number = _integer(_get(region, "page_number"), minimum=1)
    if page_number not in requested:
        raise ValueError("provider item is outside requested pages")
    try:
        next(regions)
    except StopIteration:
        pass
    else:
        raise HybridAnalysisError(
            HybridFailureCategory.CLOUD_RESPONSE_INVALID,
            HybridFailureCategory.CLOUD_RESPONSE_INVALID.value,
            limitation_code=(
                HybridFailureLimitation.AZURE_MULTIPLE_BOUNDING_REGIONS_UNSUPPORTED
            ),
        ) from None
    return page_number, _get(region, "polygon")


def _identified(model: Any, payload: dict[str, Any]) -> Any:
    field, prefix, domain = _IDENTITIES[model]
    return model.model_validate(
        {field: prefix + hybrid_identity(domain, payload), **payload}
    )


def _fail(category: HybridFailureCategory, error: BaseException) -> NoReturn:
    redact_exception(error)
    raise HybridAnalysisError(category, category.value) from None


def _deny(category: HybridFailureCategory) -> NoReturn:
    raise HybridAnalysisError(category, category.value)


def _check_deadline(deadline: float) -> None:
    if monotonic() > deadline:
        raise TimeoutError("provider elapsed limit exceeded")


def _remaining(deadline: float) -> float:
    remaining = deadline - monotonic()
    if remaining <= 0:
        raise TimeoutError("provider elapsed limit exceeded")
    return remaining


def _elapsed(started: float, deadline: float) -> int:
    now = monotonic()
    if now > deadline:
        raise TimeoutError("provider elapsed limit exceeded")
    return max(0, int((now - started) * 1000))


def _provider_category(error: BaseException) -> HybridFailureCategory:
    try:
        from azure.core.exceptions import (
            HttpResponseError,
            ServiceRequestError,
            ServiceRequestTimeoutError,
            ServiceResponseError,
            ServiceResponseTimeoutError,
        )
    except ImportError:
        return HybridFailureCategory.CLOUD_ANALYSIS_FAILED
    if isinstance(error, (ServiceRequestTimeoutError, ServiceResponseTimeoutError)):
        return HybridFailureCategory.CLOUD_PROVIDER_TIMEOUT
    if isinstance(error, (ServiceRequestError, ServiceResponseError)):
        return HybridFailureCategory.CLOUD_PROVIDER_UNAVAILABLE
    if isinstance(error, HttpResponseError):
        return HybridFailureCategory.CLOUD_PROVIDER_REJECTED
    return HybridFailureCategory.CLOUD_ANALYSIS_FAILED


class AzureDocumentIntelligenceAdapter:
    """Default-off adapter requiring explicit configuration and Hybrid authorization."""

    def __init__(
        self,
        *,
        client: object | None = None,
        endpoint: str | None = None,
        credential: object | None = None,
    ) -> None:
        if client is None and (
            not isinstance(endpoint, str) or not endpoint or credential is None
        ):
            _deny(HybridFailureCategory.CLOUD_CONFIGURATION_ERROR)
        if client is not None and (endpoint is not None or credential is not None):
            _deny(HybridFailureCategory.CLOUD_CONFIGURATION_ERROR)
        self._client = client
        self._endpoint = endpoint
        self._credential = credential

    def __repr__(self) -> str:
        return "AzureDocumentIntelligenceAdapter(configured=True)"

    def _configured_client(self) -> Any:
        if self._client is not None:
            return self._client
        try:
            from azure.ai.documentintelligence import DocumentIntelligenceClient
        except ImportError as error:
            redact_exception(error)
            raise DependencyNotInstalledError(
                "Install document-processing-sdk[azure-document-intelligence] "
                "to use this provider."
            ) from None
        try:
            self._client = DocumentIntelligenceClient(
                endpoint=cast("str", self._endpoint),
                credential=self._credential,  # type: ignore[arg-type]
                api_version=_API_VERSION,
                logging_enable=False,
                retry_total=0,
                retry_connect=0,
                retry_read=0,
                retry_status=0,
            )
        except Exception as error:  # noqa: BLE001 - exact SDK construction boundary
            _fail(HybridFailureCategory.CLOUD_CONFIGURATION_ERROR, error)
        return self._client

    @staticmethod
    def _operation_id(poller: object) -> str | None:
        value = _get(_get(poller, "details"), "operation_id")
        if value is None:
            return None
        if not isinstance(value, str) or fullmatch(_OPERATION_ID, value) is None:
            raise ValueError("provider operation identity is invalid")
        return value

    @staticmethod
    def _delete(
        client: object,
        request: DocumentAnalysisRequest,
        result_id: str | None,
        timeout: float,
    ) -> HybridDeletionStatus:
        if not request.privacy_policy.delete_result_after_fetch:
            return HybridDeletionStatus.NOT_REQUESTED
        if result_id is None:
            return HybridDeletionStatus.UNAVAILABLE
        delete = getattr(client, "delete_analyze_result", None)
        if not callable(delete):
            return HybridDeletionStatus.UNAVAILABLE
        try:
            delete(
                model_id=_MODEL,
                result_id=result_id,
                connection_timeout=timeout,
                read_timeout=timeout,
            )
        except Exception as error:  # noqa: BLE001 - exact external boundary
            redact_exception(error)
            return HybridDeletionStatus.FAILED
        return HybridDeletionStatus.SUCCEEDED

    @staticmethod
    def _normalize(
        result: object,
        request: DocumentAnalysisRequest,
        *,
        deletion_status: HybridDeletionStatus,
        safe_result_identity: str | None,
        started: float,
        deadline: float,
    ) -> CloudDocumentAnalysisArtifact:
        if (
            _get(result, "model_id") != _MODEL
            or _get(result, "api_version") != _API_VERSION
        ):
            raise ValueError("provider result authority is invalid")
        requested = set(request.page_numbers)
        pages: dict[int, dict[str, Any]] = {}
        text_blocks = characters = estimated_output_bytes = tables = cells = 0
        rows_total = columns_total = axis_materialization_work = 0
        for raw_page in _items(_get(result, "pages")):
            _check_deadline(deadline)
            number = _integer(_get(raw_page, "page_number"), minimum=1)
            if number not in requested or number in pages:
                raise ValueError("provider page inventory is invalid")
            width = _number(_get(raw_page, "width"), positive=True)
            height = _number(_get(raw_page, "height"), positive=True)
            blocks: list[CloudTextBlock] = []
            for ordinal, line in enumerate(_items(_get(raw_page, "lines"))):
                _check_deadline(deadline)
                text_blocks += 1
                if text_blocks > request.limits.maximum_cloud_text_blocks:
                    raise OverflowError("provider text block limit exceeded")
                content = _text(_get(line, "content"))
                characters += len(content)
                estimated_output_bytes += max(1, len(content.encode()))
                if characters > request.limits.maximum_cloud_characters:
                    raise OverflowError("provider character limit exceeded")
                if estimated_output_bytes > request.limits.maximum_cloud_output_bytes:
                    raise OverflowError("provider output limit exceeded")
                payload: dict[str, Any] = {
                    "page_index": number - 1,
                    "ordinal": ordinal,
                    "text": content,
                    "polygon": _polygon(_get(line, "polygon"), width, height),
                    "confidence": _confidence(_get(line, "confidence")),
                    "source_role": None,
                }
                blocks.append(_identified(CloudTextBlock, payload))
            raw_unit = _get(raw_page, "unit")
            page_limitations = (
                ("AZURE_PAGE_UNIT_UNAVAILABLE",) if raw_unit is None else ()
            )
            pages[number] = {
                "width": width,
                "height": height,
                "unit": "unknown" if raw_unit is None else _text(raw_unit),
                "rotation": None
                if _get(raw_page, "angle") is None
                else _number(_get(raw_page, "angle")),
                "text_blocks": blocks,
                "tables": [],
                "limitations": page_limitations,
            }
        for raw_table in _items(_get(result, "tables")):
            _check_deadline(deadline)
            tables += 1
            if tables > request.limits.maximum_cloud_tables:
                raise OverflowError("provider table limit exceeded")
            row_count = _table_dimension(_get(raw_table, "row_count"))
            column_count = _table_dimension(_get(raw_table, "column_count"))
            rows_total += row_count
            columns_total += column_count
            axis_width = row_count + column_count
            axis_materialization_work += axis_width
            if rows_total > request.limits.maximum_cloud_rows_total:
                raise OverflowError("provider table row total limit exceeded")
            if columns_total > request.limits.maximum_cloud_columns_total:
                raise OverflowError("provider table column total limit exceeded")
            if (
                axis_materialization_work
                > request.limits.maximum_cloud_axis_materialization_work
            ):
                raise OverflowError("provider table axis work limit exceeded")
            number, polygon = _region(raw_table, requested)
            if number not in pages:
                raise ValueError("provider table references a missing page")
            page = pages[number]
            ordinal = len(page["tables"])
            normalized_cells: list[CloudTableCell] = []
            for cell_ordinal, raw_cell in enumerate(_items(_get(raw_table, "cells"))):
                _check_deadline(deadline)
                cells += 1
                if cells > request.limits.maximum_cloud_cells:
                    raise OverflowError("provider cell limit exceeded")
                if cell_ordinal:
                    axis_materialization_work += axis_width
                    if (
                        axis_materialization_work
                        > request.limits.maximum_cloud_axis_materialization_work
                    ):
                        raise OverflowError("provider table axis work limit exceeded")
                cell_page, cell_polygon = _region(raw_cell, requested)
                if cell_page != number:
                    raise ValueError("provider cell crosses table authority")
                content = _text(_get(raw_cell, "content"))
                characters += len(content)
                estimated_output_bytes += max(1, len(content.encode()))
                if characters > request.limits.maximum_cloud_characters:
                    raise OverflowError("provider character limit exceeded")
                if estimated_output_bytes > request.limits.maximum_cloud_output_bytes:
                    raise OverflowError("provider output limit exceeded")
                cell_payload: dict[str, Any] = {
                    "page_index": number - 1,
                    "table_ordinal": ordinal,
                    "ordinal": cell_ordinal,
                    "row_index": _integer(_get(raw_cell, "row_index")),
                    "column_index": _integer(_get(raw_cell, "column_index")),
                    "row_span": _table_span(_get(raw_cell, "row_span")),
                    "column_span": _table_span(_get(raw_cell, "column_span")),
                    "text": content,
                    "polygon": _polygon(cell_polygon, page["width"], page["height"]),
                    "kind": None
                    if _get(raw_cell, "kind") is None
                    else _text(_get(raw_cell, "kind")),
                    "confidence": _confidence(_get(raw_cell, "confidence")),
                }
                normalized_cells.append(_identified(CloudTableCell, cell_payload))
            table_payload: dict[str, Any] = {
                "page_index": number - 1,
                "ordinal": ordinal,
                "row_count": row_count,
                "column_count": column_count,
                "cells": tuple(normalized_cells),
                "polygon": _polygon(polygon, page["width"], page["height"]),
                "confidence": _confidence(_get(raw_table, "confidence")),
            }
            page["tables"].append(_identified(CloudTable, table_payload))
        normalized_pages: list[CloudPage] = []
        for number in sorted(pages):
            page = pages[number]
            capability_outcomes: list[CloudPageCapabilityOutcome] = []
            for capability in request.capabilities:
                if capability is DocumentAnalysisCapability.LAYOUT:
                    state = CloudCapabilityFulfillmentState.FULFILLED
                    observed_item_count = 1
                    reason_codes: tuple[str, ...] = ()
                elif capability is DocumentAnalysisCapability.OCR_TEXT:
                    observed_item_count = len(page["text_blocks"])
                    state = (
                        CloudCapabilityFulfillmentState.FULFILLED
                        if observed_item_count
                        else CloudCapabilityFulfillmentState.UNAVAILABLE
                    )
                    reason_codes = (
                        () if observed_item_count else ("CLOUD_OCR_TEXT_NOT_OBSERVED",)
                    )
                else:
                    observed_item_count = len(page["tables"])
                    state = (
                        CloudCapabilityFulfillmentState.FULFILLED
                        if observed_item_count
                        else CloudCapabilityFulfillmentState.OBSERVED_EMPTY
                    )
                    reason_codes = (
                        () if observed_item_count else ("CLOUD_TABLES_NOT_OBSERVED",)
                    )
                capability_outcomes.append(
                    CloudPageCapabilityOutcome(
                        capability=capability,
                        state=state,
                        observed_item_count=observed_item_count,
                        reason_codes=reason_codes,
                    )
                )
            page_payload: dict[str, Any] = {
                "page_index": number - 1,
                **page,
                "text_blocks": tuple(page["text_blocks"]),
                "tables": tuple(page["tables"]),
                "capability_outcomes": tuple(capability_outcomes),
                "availability": HybridAvailabilityState.AVAILABLE,
                "warnings": (),
                "limitations": page["limitations"],
            }
            normalized_pages.append(_identified(CloudPage, page_payload))
        missing = tuple(sorted(requested - pages.keys()))
        availability = (
            HybridAvailabilityState.PARTIAL
            if missing
            else HybridAvailabilityState.AVAILABLE
        )
        limitations = ("AZURE_MISSING_REQUESTED_PAGES",) if missing else ()
        core: dict[str, Any] = {
            "provider": _PROVIDER,
            "model_id": _MODEL,
            "api_version": _API_VERSION,
            "submission_scope": "FULL_DOCUMENT_BYTES",
            "analysis_page_scope": "SELECTED_PAGES",
            "source_document_identity": request.source_document_identity,
            "source_sha256": request.source_sha256,
            "request_identity": request.request_identity,
            "requested_page_numbers": request.page_numbers,
            "requested_capabilities": request.capabilities,
            "pages": tuple(normalized_pages),
            "missing_page_numbers": missing,
            "availability": availability,
            "warnings": (),
            "limitations": limitations,
            "safe_result_identity": safe_result_identity,
            "deletion_status": deletion_status,
            "text_block_count": text_blocks,
            "character_count": characters,
            "table_count": tables,
            "cell_count": cells,
            "elapsed_milliseconds": _elapsed(started, deadline),
        }
        size_payload = {
            "schema_version": HYBRID_CLOUD_DOCUMENT_DOMAIN,
            **core,
        }
        _check_deadline(deadline)
        normalized_output_bytes = len(
            canonical_json_bytes(normalized_cloud_payload_for_size(size_payload))
        )
        _check_deadline(deadline)
        if normalized_output_bytes > request.limits.maximum_cloud_output_bytes:
            raise OverflowError("provider output limit exceeded")
        core["normalized_output_bytes"] = normalized_output_bytes
        payload = {"schema_version": HYBRID_CLOUD_DOCUMENT_DOMAIN, **core}
        payload.pop("elapsed_milliseconds")
        return CloudDocumentAnalysisArtifact.model_validate(
            {
                "payload_sha256": hybrid_identity(
                    HYBRID_CLOUD_DOCUMENT_DOMAIN, payload
                ),
                **core,
            }
        )

    def analyze(
        self, request: DocumentAnalysisRequest
    ) -> CloudDocumentAnalysisArtifact:
        if type(request) is not DocumentAnalysisRequest:
            _deny(HybridFailureCategory.CLOUD_CONFIGURATION_ERROR)
        try:
            # Do not trust an exact Pydantic instance: reconstruct recursive
            # values so bypassed request, policy, and limit validators execute.
            values = request.model_dump(mode="python", warnings=False)
            # Source bytes are intentionally excluded from ordinary dumps.
            values["document_bytes"] = request.document_bytes
            request = DocumentAnalysisRequest.model_validate(values)
        except (KeyboardInterrupt, SystemExit, GeneratorExit):
            raise
        except Exception as error:  # noqa: BLE001 - untrusted request boundary.
            _fail(HybridFailureCategory.CLOUD_CONFIGURATION_ERROR, error)
        # Submission requires explicit, identity-bound HYBRID_AUTO authority.
        if request.analysis_mode is not HybridAnalysisMode.HYBRID_AUTO:
            _deny(HybridFailureCategory.CLOUD_CONFIGURATION_ERROR)
        started = monotonic()
        deadline = started + request.limits.maximum_elapsed_milliseconds / 1000
        try:
            client = self._configured_client()
            transport_timeout = _remaining(deadline)
            poller = client.begin_analyze_document(
                model_id=_MODEL,
                body=BytesIO(request.document_bytes),
                pages=",".join(map(str, request.page_numbers)),
                locale=request.locale_hint,
                connection_timeout=transport_timeout,
                read_timeout=transport_timeout,
            )
            result = poller.result(timeout=_remaining(deadline))
            result_id = self._operation_id(poller)
            _check_deadline(deadline)
            deletion = self._delete(
                client,
                request,
                result_id,
                _remaining(deadline),
            )
            _check_deadline(deadline)
            artifact = self._normalize(
                result,
                request,
                deletion_status=deletion,
                safe_result_identity=(
                    None
                    if result_id is None
                    else sha256(result_id.encode()).hexdigest()
                ),
                started=started,
                deadline=deadline,
            )
        except DependencyNotInstalledError:
            raise
        except HybridAnalysisError:
            raise
        except TimeoutError as error:
            _fail(HybridFailureCategory.CLOUD_PROVIDER_TIMEOUT, error)
        except OverflowError as error:
            _fail(HybridFailureCategory.CLOUD_RESULT_LIMIT_EXCEEDED, error)
        except (AttributeError, TypeError, ValueError, ValidationError) as error:
            _fail(HybridFailureCategory.CLOUD_RESPONSE_INVALID, error)
        except Exception as error:  # noqa: BLE001 - exact external boundary
            _fail(_provider_category(error), error)
        else:
            return artifact

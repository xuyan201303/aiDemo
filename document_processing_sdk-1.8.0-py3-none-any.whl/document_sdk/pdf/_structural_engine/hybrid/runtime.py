"""Private default-off orchestration for provider-neutral Hybrid PDF analysis."""

# ruff: noqa: C901, EM101, PLR0911, PLR0912, PLR0913, PLR0915, TRY003

from __future__ import annotations

from hashlib import sha256

from document_sdk.core import DependencyNotInstalledError
from document_sdk.core._exceptions import redact_exception
from document_sdk.pdf._structural_engine.canonical.contracts import CanonicalDocument

from .contracts import (
    _HYBRID_RESULT_IDENTITY_DOMAIN,
    HYBRID_MERGE_DOMAIN,
    CloudDocumentAnalysisArtifact,
    DocumentAnalysisCapability,
    DocumentAnalysisProvider,
    DocumentAnalysisRequest,
    HybridAnalysisError,
    HybridAnalysisMode,
    HybridAnalysisResult,
    HybridCloudStatus,
    HybridDeletionStatus,
    HybridEffectiveCapabilityState,
    HybridElementOrigin,
    HybridElementProvenance,
    HybridFailureCategory,
    HybridMergeReport,
    HybridOptions,
    HybridRoutingPlan,
    HybridRoutingReason,
    cloud_table_resource_usage,
    hybrid_identity,
)


def _identified_merge_report(values: dict[str, object]) -> HybridMergeReport:
    return HybridMergeReport.model_validate(
        {
            **values,
            "merge_identity": hybrid_identity(HYBRID_MERGE_DOMAIN, values),
        }
    )


def _local_provenance(
    document: CanonicalDocument,
) -> tuple[HybridElementProvenance, ...]:
    items: list[tuple[str, str]] = [("document", document.canonical_document_id)]
    for page in document.pages:
        items.append(("page", page.page_id))
        items.extend(("drawing", drawing.drawing_id) for drawing in page.drawings)
        for block in page.text_blocks:
            items.append(("text_block", block.text_block_id))
            items.extend(("text_span", span.span_id) for span in block.spans)
    for table in document.tables:
        items.append(("table", table.table_id))
        items.extend(("table_row", row.row_id) for row in table.rows)
        items.extend(("table_column", column.column_id) for column in table.columns)
        items.extend(("table_cell", cell.cell_id) for cell in table.cells)
    for document_table in document.document_tables:
        items.append(("document_table", document_table.document_table_id))
        items.extend(
            ("logical_row", row.logical_row_id) for row in document_table.logical_rows
        )
    items.extend(("transition", item.transition_id) for item in document.transitions)
    return tuple(
        HybridElementProvenance(
            canonical_id=canonical_id,
            kind=kind,
            origin=HybridElementOrigin.LOCAL,
        )
        for kind, canonical_id in sorted(set(items))
    )


def _merge_report(
    document: CanonicalDocument,
    *,
    cloud_requested_pages: int,
    limitations: tuple[str, ...] = (),
    warnings: tuple[str, ...] = (),
    review_required: bool = False,
) -> HybridMergeReport:
    values: dict[str, object] = {
        "local_pages": len(document.pages),
        "cloud_requested_pages": cloud_requested_pages,
        "cloud_filled_pages": 0,
        "local_preserved_text_count": sum(
            len(page.text_blocks) for page in document.pages
        ),
        "cloud_filled_text_count": 0,
        "local_preserved_table_count": len(document.tables),
        "cloud_filled_table_count": 0,
        "conflict_count": 0,
        "continuity_unavailable_count": 0,
        "effective_capability_outcomes": (),
        "warnings": tuple(sorted(set(warnings))),
        "limitations": tuple(sorted(set(limitations))),
        "review_required": review_required,
    }
    return _identified_merge_report(values)


def _merge_report_with_limitations(
    report: HybridMergeReport,
    *,
    limitations: tuple[str, ...],
) -> HybridMergeReport:
    values: dict[str, object] = report.model_dump(
        mode="python",
        exclude={"merge_identity"},
    )
    values["limitations"] = tuple(sorted({*report.limitations, *limitations}))
    values["review_required"] = True
    return _identified_merge_report(values)


def _result(
    *,
    local: CanonicalDocument,
    canonical: CanonicalDocument,
    routing_plan: HybridRoutingPlan,
    cloud_status: HybridCloudStatus,
    merge_report: HybridMergeReport,
    element_provenance: tuple[HybridElementProvenance, ...],
    cloud_artifact: CloudDocumentAnalysisArtifact | None = None,
    failure_category: HybridFailureCategory | None = None,
) -> HybridAnalysisResult:
    # Section 74 keeps original route authority separate from the final
    # content-addressed Canonical payload when cloud evidence changes it.
    identity_values = {
        "local_canonical_document_id": local.canonical_document_id,
        "canonical_document": canonical,
        "routing_plan": routing_plan,
        "cloud_status": cloud_status,
        "cloud_artifact_sha256": (
            None if cloud_artifact is None else cloud_artifact.payload_sha256
        ),
        "merge_report": merge_report,
        "element_provenance": element_provenance,
        "failure_category": failure_category,
        "family": None,
        "family_status": "REVIEW_REQUIRED",
        "family_auto_assignment": False,
    }
    return HybridAnalysisResult(
        local_canonical_document_id=local.canonical_document_id,
        canonical_document=canonical,
        routing_plan=routing_plan,
        cloud_status=cloud_status,
        cloud_artifact=cloud_artifact,
        merge_report=merge_report,
        element_provenance=element_provenance,
        failure_category=failure_category,
        family=None,
        family_status="REVIEW_REQUIRED",
        family_auto_assignment=False,
        hybrid_result_identity=hybrid_identity(
            _HYBRID_RESULT_IDENTITY_DOMAIN,
            identity_values,
        ),
    )


def _local_result(
    *,
    local: CanonicalDocument,
    routing_plan: HybridRoutingPlan,
    cloud_status: HybridCloudStatus,
    cloud_requested_pages: int,
    limitations: tuple[str, ...] = (),
    failure_category: HybridFailureCategory | None = None,
    cloud_artifact: CloudDocumentAnalysisArtifact | None = None,
) -> HybridAnalysisResult:
    return _result(
        local=local,
        canonical=local,
        routing_plan=routing_plan,
        cloud_status=cloud_status,
        cloud_artifact=cloud_artifact,
        merge_report=_merge_report(
            local,
            cloud_requested_pages=cloud_requested_pages,
            limitations=limitations,
            review_required=bool(limitations),
        ),
        element_provenance=_local_provenance(local),
        failure_category=failure_category,
    )


def _request(
    *,
    local: CanonicalDocument,
    document_bytes: bytes,
    page_numbers: tuple[int, ...],
    capabilities: tuple[DocumentAnalysisCapability, ...],
    options: HybridOptions,
) -> DocumentAnalysisRequest:
    values = {
        "analysis_mode": options.mode,
        "source_document_identity": local.source_document_identity,
        "source_sha256": local.provenance.source_sha256,
        "document_bytes": len(document_bytes),
        "page_numbers": page_numbers,
        "capabilities": capabilities,
        "locale_hint": options.locale_hint,
        "privacy_policy": options.privacy_policy,
        "limits_identity": options.limits.identity,
    }
    return DocumentAnalysisRequest(
        analysis_mode=HybridAnalysisMode.HYBRID_AUTO,
        source_document_identity=local.source_document_identity,
        source_sha256=local.provenance.source_sha256,
        document_bytes=document_bytes,
        page_numbers=page_numbers,
        capabilities=capabilities,
        locale_hint=options.locale_hint,
        privacy_policy=options.privacy_policy,
        limits=options.limits,
        request_identity=hybrid_identity(
            "document_sdk.pdf.hybrid.analysis_request.v1",
            values,
        ),
    )


def _validate_input(
    local_document: CanonicalDocument,
    document_bytes: bytes,
    options: HybridOptions | None,
) -> HybridOptions:
    if type(local_document) is not CanonicalDocument:
        raise TypeError("Hybrid runtime requires an exact CanonicalDocument")
    if type(document_bytes) is not bytes:
        raise TypeError("Hybrid runtime requires immutable PDF bytes")
    if sha256(document_bytes).hexdigest() != local_document.provenance.source_sha256:
        raise ValueError("Hybrid PDF bytes do not match local Canonical authority")
    if options is None:
        return HybridOptions()
    if type(options) is not HybridOptions:
        raise TypeError("Hybrid runtime options are invalid")
    try:
        # Exact Pydantic instances may have bypassed validation through
        # ``model_copy(update=...)`` or ``model_construct(...)``. Rebuild from
        # ordinary recursive values so nested Hybrid limits are validated too.
        values = options.model_dump(mode="python", warnings=False)
        return HybridOptions.model_validate(values)
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception as error:  # noqa: BLE001 - untrusted options boundary.
        redact_exception(error)
        raise ValueError("Hybrid runtime options are invalid") from None


def _cloud_result_exceeds_limits(
    cloud: CloudDocumentAnalysisArtifact,
    *,
    options: HybridOptions,
) -> bool:
    limits = options.limits
    rows_total, columns_total, axis_materialization_work = cloud_table_resource_usage(
        table for page in cloud.pages for table in page.tables
    )
    return any(
        (
            cloud.normalized_output_bytes > limits.maximum_cloud_output_bytes,
            cloud.text_block_count > limits.maximum_cloud_text_blocks,
            cloud.table_count > limits.maximum_cloud_tables,
            cloud.cell_count > limits.maximum_cloud_cells,
            rows_total > limits.maximum_cloud_rows_total,
            columns_total > limits.maximum_cloud_columns_total,
            axis_materialization_work > limits.maximum_cloud_axis_materialization_work,
            cloud.character_count > limits.maximum_cloud_characters,
            cloud.elapsed_milliseconds > limits.maximum_elapsed_milliseconds,
        )
    )


def _revalidate_cloud_artifact(
    cloud: CloudDocumentAnalysisArtifact,
) -> CloudDocumentAnalysisArtifact:
    # Rebuild from recursively serialized values so a custom Provider cannot
    # smuggle invalid nested models through ``model_copy`` / ``model_construct``.
    # Live elapsed time is intentionally excluded from normalized replay bytes,
    # so restore it explicitly for the caller's runtime limit check.
    values = cloud.model_dump(mode="python", warnings=False)
    values["elapsed_milliseconds"] = cloud.elapsed_milliseconds
    return CloudDocumentAnalysisArtifact.model_validate(values)


def run_hybrid_document_analysis(
    local_document: CanonicalDocument,
    document_bytes: bytes,
    *,
    options: HybridOptions | None = None,
    document_provider: DocumentAnalysisProvider | None = None,
) -> HybridAnalysisResult:
    """Route optional cloud analysis and merge once into Canonical output."""
    selected = _validate_input(local_document, document_bytes, options)
    from .router import build_cloud_request_plan, build_hybrid_routing_plan

    routing = build_hybrid_routing_plan(
        local_document,
        options=selected,
        provider_available=document_provider is not None,
    )
    requested_pages = len(routing.cloud_page_numbers)

    def fallback(
        *,
        cloud_status: HybridCloudStatus,
        limitations: tuple[str, ...] = (),
        failure_category: HybridFailureCategory | None = None,
        cloud_artifact: CloudDocumentAnalysisArtifact | None = None,
    ) -> HybridAnalysisResult:
        return _local_result(
            local=local_document,
            routing_plan=routing,
            cloud_status=cloud_status,
            cloud_requested_pages=requested_pages,
            limitations=limitations,
            failure_category=failure_category,
            cloud_artifact=cloud_artifact,
        )

    if not routing.cloud_required:
        return fallback(
            cloud_status=HybridCloudStatus.NOT_REQUESTED,
        )
    if (
        selected.mode is not HybridAnalysisMode.HYBRID_AUTO
        or not selected.cloud_enabled
    ):
        return fallback(
            cloud_status=HybridCloudStatus.NOT_EXECUTED_DISABLED,
            limitations=(HybridRoutingReason.CLOUD_DISABLED.value,),
        )
    if document_provider is None:
        return fallback(
            cloud_status=HybridCloudStatus.NOT_EXECUTED_PROVIDER_UNAVAILABLE,
            limitations=(HybridRoutingReason.PROVIDER_UNAVAILABLE.value,),
            failure_category=HybridFailureCategory.CLOUD_PROVIDER_UNAVAILABLE,
        )
    request_plan = build_cloud_request_plan(
        routing,
        source_sha256=local_document.provenance.source_sha256,
        input_bytes=len(document_bytes),
        limits=selected.limits,
    )
    if not request_plan.allowed:
        return fallback(
            cloud_status=HybridCloudStatus.NOT_EXECUTED_LIMIT,
            limitations=(HybridRoutingReason.CLOUD_LIMIT_EXCEEDED.value,),
            failure_category=HybridFailureCategory.CLOUD_REQUEST_LIMIT,
        )
    request = _request(
        local=local_document,
        document_bytes=document_bytes,
        page_numbers=request_plan.page_numbers,
        capabilities=request_plan.capabilities,
        options=selected,
    )
    try:
        cloud = document_provider.analyze(request)
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception as error:  # noqa: BLE001 - untrusted Provider boundary.
        limitation_code = (
            error.limitation_code if isinstance(error, HybridAnalysisError) else None
        )
        category = (
            error.category
            if isinstance(error, HybridAnalysisError)
            else (
                HybridFailureCategory.CLOUD_PROVIDER_UNAVAILABLE
                if isinstance(error, DependencyNotInstalledError)
                else HybridFailureCategory.CLOUD_ANALYSIS_FAILED
            )
        )
        redact_exception(error)
        limitations = {category.value}
        if limitation_code is not None:
            limitations.add(limitation_code.value)
        return fallback(
            cloud_status=HybridCloudStatus.FAILED_CONTROLLED,
            limitations=tuple(sorted(limitations)),
            failure_category=category,
        )
    if type(cloud) is not CloudDocumentAnalysisArtifact:
        return fallback(
            cloud_status=HybridCloudStatus.FAILED_CONTROLLED,
            limitations=(HybridFailureCategory.CLOUD_RESPONSE_INVALID.value,),
            failure_category=HybridFailureCategory.CLOUD_RESPONSE_INVALID,
        )
    try:
        cloud = _revalidate_cloud_artifact(cloud)
    except (TypeError, ValueError) as error:
        redact_exception(error)
        return fallback(
            cloud_status=HybridCloudStatus.FAILED_CONTROLLED,
            limitations=(HybridFailureCategory.CLOUD_RESPONSE_INVALID.value,),
            failure_category=HybridFailureCategory.CLOUD_RESPONSE_INVALID,
        )
    if (
        cloud.source_document_identity != local_document.source_document_identity
        or cloud.source_sha256 != local_document.provenance.source_sha256
        or cloud.request_identity != request.request_identity
        or cloud.requested_page_numbers != request.page_numbers
        or cloud.requested_capabilities != request.capabilities
    ):
        return fallback(
            cloud_status=HybridCloudStatus.FAILED_CONTROLLED,
            limitations=(HybridFailureCategory.CLOUD_RESPONSE_INVALID.value,),
            failure_category=HybridFailureCategory.CLOUD_RESPONSE_INVALID,
        )
    if _cloud_result_exceeds_limits(cloud, options=selected):
        return fallback(
            cloud_status=HybridCloudStatus.FAILED_CONTROLLED,
            limitations=(HybridFailureCategory.CLOUD_RESULT_LIMIT_EXCEEDED.value,),
            failure_category=HybridFailureCategory.CLOUD_RESULT_LIMIT_EXCEEDED,
        )
    if selected.privacy_policy.require_delete_success and (
        cloud.deletion_status is not HybridDeletionStatus.SUCCEEDED
    ):
        return fallback(
            cloud_status=HybridCloudStatus.FAILED_CONTROLLED,
            limitations=(HybridFailureCategory.CLOUD_DELETE_FAILED.value,),
            failure_category=HybridFailureCategory.CLOUD_DELETE_FAILED,
        )

    from .cloud_projection import CloudArtifactProjectionError, project_cloud_artifact
    from .merge import (
        HybridMergeAuthorityError,
        HybridMergeResourceLimitError,
        merge_canonical_with_cloud,
    )

    try:
        fragment = project_cloud_artifact(
            local_document,
            cloud,
            routing_plan=routing,
        )
        merged = merge_canonical_with_cloud(
            local_document,
            fragment,
            routing_plan=routing,
            limits=selected.limits,
        )
    except HybridMergeResourceLimitError as error:
        redact_exception(error)
        return fallback(
            cloud_status=HybridCloudStatus.FAILED_CONTROLLED,
            limitations=(HybridFailureCategory.CLOUD_RESULT_LIMIT_EXCEEDED.value,),
            failure_category=HybridFailureCategory.CLOUD_RESULT_LIMIT_EXCEEDED,
        )
    except (CloudArtifactProjectionError, HybridMergeAuthorityError) as error:
        redact_exception(error)
        return fallback(
            cloud_status=HybridCloudStatus.FAILED_CONTROLLED,
            limitations=(HybridFailureCategory.CLOUD_RESPONSE_INVALID.value,),
            failure_category=HybridFailureCategory.CLOUD_RESPONSE_INVALID,
        )
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception as error:  # noqa: BLE001 - trusted internal boundary.
        redact_exception(error)
        raise HybridAnalysisError(
            HybridFailureCategory.HYBRID_INTERNAL_FAILURE,
            HybridFailureCategory.HYBRID_INTERNAL_FAILURE.value,
        ) from None
    deletion_limitations: tuple[str, ...] = ()
    if selected.privacy_policy.delete_result_after_fetch and (
        cloud.deletion_status is not HybridDeletionStatus.SUCCEEDED
    ):
        deletion_limitations = (HybridFailureCategory.CLOUD_DELETE_FAILED.value,)
    merge_report = (
        _merge_report_with_limitations(
            merged.merge_report,
            limitations=deletion_limitations,
        )
        if deletion_limitations
        else merged.merge_report
    )
    cloud_status = (
        HybridCloudStatus.COMPLETED_PARTIAL
        if (
            cloud.missing_page_numbers
            or merge_report.review_required
            or merge_report.conflict_count
            or any(
                item.state is not HybridEffectiveCapabilityState.FULFILLED
                for item in merge_report.effective_capability_outcomes
            )
        )
        else HybridCloudStatus.COMPLETED
    )
    return _result(
        local=local_document,
        canonical=merged.canonical_document,
        routing_plan=routing,
        cloud_status=cloud_status,
        cloud_artifact=cloud,
        merge_report=merge_report,
        element_provenance=merged.element_provenance,
    )


__all__ = ["run_hybrid_document_analysis"]

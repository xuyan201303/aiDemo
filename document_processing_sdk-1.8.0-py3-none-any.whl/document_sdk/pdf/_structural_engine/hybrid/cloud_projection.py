# ruff: noqa: EM101, PLR2004, TRY003

"""Project cloud evidence into Hybrid-only Canonical-coordinate fragments."""

from __future__ import annotations

from typing import Literal, Self

from pydantic import Field, model_validator

from document_sdk.pdf._structural_engine.canonical.contracts import (
    CanonicalAvailability,
    CanonicalBoundingBox,
    CanonicalDocument,
    CanonicalPage,
)
from document_sdk.pdf._structural_engine.hybrid.contracts import (
    _MAX_CLOUD_TABLE_DIMENSION,
    CloudDocumentAnalysisArtifact,
    CloudPageCapabilityOutcome,
    CloudPolygon,
    DocumentAnalysisCapability,
    HybridAvailabilityState,
    HybridContractModel,
    HybridPageRoute,
    HybridRoutingPlan,
    HybridRoutingReason,
    _validate_non_overlapping_cell_rectangles,
    _validate_safe_metadata_codes,
    hybrid_identity,
)

CLOUD_FRAGMENT_SCHEMA_VERSION: Literal["document_sdk.pdf.hybrid.cloud_fragment.v1"] = (
    "document_sdk.pdf.hybrid.cloud_fragment.v1"
)
_CLOUD_FRAGMENT_DOMAIN = "document_sdk.pdf.hybrid.cloud_fragment.v1"
_CLOUD_FRAGMENT_PAGE_DOMAIN = "document_sdk.pdf.hybrid.cloud_fragment.page.v1"
_CLOUD_FRAGMENT_TEXT_DOMAIN = "document_sdk.pdf.hybrid.cloud_fragment.text.v1"
_CLOUD_FRAGMENT_TABLE_DOMAIN = "document_sdk.pdf.hybrid.cloud_fragment.table.v1"
_CLOUD_FRAGMENT_CELL_DOMAIN = "document_sdk.pdf.hybrid.cloud_fragment.cell.v1"


class CloudArtifactProjectionError(ValueError):
    """Expected malformed cloud geometry or authority mismatch."""


def _canonical_reasons(
    values: tuple[HybridRoutingReason, ...],
) -> tuple[HybridRoutingReason, ...]:
    return tuple(sorted(set(values), key=lambda item: item.value))


class CanonicalCloudTextFragment(HybridContractModel):
    identity_spec = (
        "fragment_id",
        "P3HY1-fragment-text-",
        _CLOUD_FRAGMENT_TEXT_DOMAIN,
    )
    fragment_id: str = Field(pattern=r"^P3HY1-fragment-text-[0-9a-f]{64}$")
    source_cloud_block_id: str = Field(pattern=r"^P3HY1-cloud-text-[0-9a-f]{64}$")
    page_index: int = Field(ge=0)
    ordinal: int = Field(ge=0)
    text: str = Field(repr=False)
    bbox: CanonicalBoundingBox
    confidence: float | None = Field(default=None, ge=0, le=1)
    source_role: str | None = Field(default=None, max_length=64)
    availability: CanonicalAvailability

    @model_validator(mode="after")
    def validate_identity(self) -> Self:
        return self.require_hybrid_identity()


class CanonicalCloudCellFragment(HybridContractModel):
    identity_spec = (
        "fragment_id",
        "P3HY1-fragment-cell-",
        _CLOUD_FRAGMENT_CELL_DOMAIN,
    )
    fragment_id: str = Field(pattern=r"^P3HY1-fragment-cell-[0-9a-f]{64}$")
    source_cloud_cell_id: str = Field(pattern=r"^P3HY1-cloud-cell-[0-9a-f]{64}$")
    page_index: int = Field(ge=0)
    table_ordinal: int = Field(ge=0)
    ordinal: int = Field(ge=0)
    row_index: int = Field(ge=0)
    column_index: int = Field(ge=0)
    row_span: int = Field(ge=1, le=_MAX_CLOUD_TABLE_DIMENSION)
    column_span: int = Field(ge=1, le=_MAX_CLOUD_TABLE_DIMENSION)
    text: str = Field(repr=False)
    bbox: CanonicalBoundingBox
    kind: str | None = Field(default=None, max_length=64)
    confidence: float | None = Field(default=None, ge=0, le=1)
    availability: CanonicalAvailability

    @model_validator(mode="after")
    def validate_identity(self) -> Self:
        return self.require_hybrid_identity()


class CanonicalCloudTableFragment(HybridContractModel):
    identity_spec = (
        "fragment_id",
        "P3HY1-fragment-table-",
        _CLOUD_FRAGMENT_TABLE_DOMAIN,
    )
    fragment_id: str = Field(pattern=r"^P3HY1-fragment-table-[0-9a-f]{64}$")
    source_cloud_table_id: str = Field(pattern=r"^P3HY1-cloud-table-[0-9a-f]{64}$")
    page_index: int = Field(ge=0)
    ordinal: int = Field(ge=0)
    row_count: int = Field(ge=1, le=_MAX_CLOUD_TABLE_DIMENSION)
    column_count: int = Field(ge=1, le=_MAX_CLOUD_TABLE_DIMENSION)
    cells: tuple[CanonicalCloudCellFragment, ...]
    bbox: CanonicalBoundingBox
    confidence: float | None = Field(default=None, ge=0, le=1)
    availability: CanonicalAvailability

    @model_validator(mode="after")
    def validate_table(self) -> Self:
        if tuple(item.ordinal for item in self.cells) != tuple(range(len(self.cells))):
            raise ValueError("cloud table fragments must remain ordered")
        if len({item.fragment_id for item in self.cells}) != len(self.cells):
            raise ValueError("cloud table fragment repeats a cell")
        if any(
            item.page_index != self.page_index
            or item.table_ordinal != self.ordinal
            or item.row_index + item.row_span > self.row_count
            or item.column_index + item.column_span > self.column_count
            for item in self.cells
        ):
            raise ValueError("cloud cell fragment is outside table bounds")
        _validate_non_overlapping_cell_rectangles(self.cells)
        return self.require_hybrid_identity()


class CanonicalCloudPageFragment(HybridContractModel):
    identity_spec = (
        "fragment_id",
        "P3HY1-fragment-page-",
        _CLOUD_FRAGMENT_PAGE_DOMAIN,
    )
    fragment_id: str = Field(pattern=r"^P3HY1-fragment-page-[0-9a-f]{64}$")
    source_cloud_page_id: str = Field(pattern=r"^P3HY1-cloud-page-[0-9a-f]{64}$")
    local_page_id: str = Field(pattern=r"^P3CE1-page-[0-9a-f]{64}$")
    page_index: int = Field(ge=0)
    local_rotation: Literal[0, 90, 180, 270]
    text_blocks: tuple[CanonicalCloudTextFragment, ...] = Field(
        default=(),
        repr=False,
    )
    tables: tuple[CanonicalCloudTableFragment, ...] = Field(
        default=(),
        repr=False,
    )
    required_capabilities: tuple[DocumentAnalysisCapability, ...]
    provider_capability_outcomes: tuple[CloudPageCapabilityOutcome, ...]
    availability: CanonicalAvailability
    warnings: tuple[str, ...] = ()
    limitations: tuple[str, ...] = ()
    fallback_reason_codes: tuple[HybridRoutingReason, ...] = ()

    @model_validator(mode="after")
    def validate_page(self) -> Self:
        if tuple(item.ordinal for item in self.text_blocks) != tuple(
            range(len(self.text_blocks))
        ) or tuple(item.ordinal for item in self.tables) != tuple(
            range(len(self.tables))
        ):
            raise ValueError("cloud page fragments must remain ordered")
        if any(item.page_index != self.page_index for item in self.text_blocks) or any(
            item.page_index != self.page_index for item in self.tables
        ):
            raise ValueError("cloud fragment crosses local page authority")
        if self.required_capabilities != tuple(
            sorted(set(self.required_capabilities), key=lambda item: item.value)
        ):
            raise ValueError("cloud fragment capabilities must be canonical")
        if (
            tuple(item.capability for item in self.provider_capability_outcomes)
            != self.required_capabilities
        ):
            raise ValueError("cloud fragment provider outcomes do not match authority")
        observed_counts = {
            DocumentAnalysisCapability.LAYOUT: 1,
            DocumentAnalysisCapability.OCR_TEXT: len(self.text_blocks),
            DocumentAnalysisCapability.TABLES: len(self.tables),
        }
        if any(
            item.observed_item_count != observed_counts[item.capability]
            for item in self.provider_capability_outcomes
        ):
            raise ValueError("cloud fragment provider evidence is inconsistent")
        if self.text_blocks and (
            DocumentAnalysisCapability.OCR_TEXT not in self.required_capabilities
        ):
            raise ValueError("cloud fragment text exceeds page capability authority")
        if self.tables and (
            DocumentAnalysisCapability.TABLES not in self.required_capabilities
        ):
            raise ValueError("cloud fragment tables exceed page capability authority")
        _validate_safe_metadata_codes(
            self.warnings,
            label="cloud fragment warnings",
        )
        _validate_safe_metadata_codes(
            self.limitations,
            label="cloud fragment limitations",
        )
        if self.fallback_reason_codes != _canonical_reasons(self.fallback_reason_codes):
            raise ValueError("cloud fragment routing reasons must be canonical")
        return self.require_hybrid_identity()


class CanonicalCloudFragment(HybridContractModel):
    identity_spec = ("fragment_id", "P3HY1-fragment-", _CLOUD_FRAGMENT_DOMAIN)
    schema_version: Literal["document_sdk.pdf.hybrid.cloud_fragment.v1"] = (
        CLOUD_FRAGMENT_SCHEMA_VERSION
    )
    fragment_id: str = Field(pattern=r"^P3HY1-fragment-[0-9a-f]{64}$")
    local_canonical_document_id: str = Field(pattern=r"^P3CE1-document-[0-9a-f]{64}$")
    source_document_identity: str = Field(min_length=1, max_length=160)
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    provider: str = Field(min_length=1, max_length=64)
    model_id: str = Field(min_length=1, max_length=128)
    api_version: str = Field(min_length=1, max_length=64)
    submission_scope: Literal["FULL_DOCUMENT_BYTES"]
    analysis_page_scope: Literal["SELECTED_PAGES"]
    request_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    routing_plan_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    requested_page_numbers: tuple[int, ...]
    missing_page_numbers: tuple[int, ...] = ()
    pages: tuple[CanonicalCloudPageFragment, ...] = Field(repr=False)
    availability: CanonicalAvailability
    warnings: tuple[str, ...] = ()
    limitations: tuple[str, ...] = ()
    safe_result_identity: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )
    cloud_payload_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_fragment(self) -> Self:
        if self.requested_page_numbers != tuple(
            sorted(set(self.requested_page_numbers))
        ) or self.missing_page_numbers != tuple(sorted(set(self.missing_page_numbers))):
            raise ValueError("cloud fragment page inventories must be canonical")
        returned_page_numbers = tuple(item.page_index + 1 for item in self.pages)
        if returned_page_numbers != tuple(sorted(set(returned_page_numbers))):
            raise ValueError("cloud fragments must remain in page order")
        if set(returned_page_numbers) | set(self.missing_page_numbers) != set(
            self.requested_page_numbers
        ) or set(returned_page_numbers) & set(self.missing_page_numbers):
            raise ValueError("cloud fragment page coverage is inconsistent")
        _validate_safe_metadata_codes(
            self.warnings,
            label="cloud fragment warnings",
        )
        _validate_safe_metadata_codes(
            self.limitations,
            label="cloud fragment limitations",
        )
        return self.require_hybrid_identity()


def _identified[FragmentT: HybridContractModel](
    model: type[FragmentT],
    *,
    values: dict[str, object],
) -> FragmentT:
    spec = model.identity_spec
    if spec is None:
        raise ValueError("cloud fragment model lacks identity authority")
    field, prefix, domain = spec
    return model.model_validate(
        {
            field: prefix + hybrid_identity(domain, values),
            **values,
        }
    )


def _availability(
    state: HybridAvailabilityState,
    limitations: tuple[str, ...],
) -> CanonicalAvailability:
    if state is HybridAvailabilityState.AVAILABLE:
        return CanonicalAvailability(state="AVAILABLE")
    reasons = tuple(sorted(set(limitations))) or (f"HYBRID_CLOUD_{state.value}",)
    return CanonicalAvailability.model_validate(
        {"state": state.value, "reason_codes": reasons}
    )


def _rotate_normalized_point(
    x: float,
    y: float,
    *,
    rotation: Literal[0, 90, 180, 270],
) -> tuple[float, float]:
    if rotation == 0:
        return x, y
    if rotation == 90:
        return 1 - y, x
    if rotation == 180:
        return 1 - x, 1 - y
    return y, 1 - x


def _project_polygon(
    polygon: CloudPolygon,
    *,
    local_page: CanonicalPage,
) -> CanonicalBoundingBox:
    geometry = local_page.geometry
    points = tuple(
        _rotate_normalized_point(
            point.x,
            point.y,
            rotation=geometry.rotation,
        )
        for point in polygon.points
    )
    doubled_area = sum(
        left[0] * right[1] - right[0] * left[1]
        for left, right in zip(points, (*points[1:], points[0]), strict=True)
    )
    if abs(doubled_area) <= 1e-12:
        raise CloudArtifactProjectionError("cloud polygon has no bounded area")
    x_values = tuple(item[0] * geometry.canonical_width for item in points)
    y_values = tuple(item[1] * geometry.canonical_height for item in points)
    x0, x1 = min(x_values), max(x_values)
    y0, y1 = min(y_values), max(y_values)
    if x0 >= x1 or y0 >= y1:
        raise CloudArtifactProjectionError("cloud polygon has no bounded area")
    return CanonicalBoundingBox(x0=x0, y0=y0, x1=x1, y1=y1)


def project_cloud_artifact(
    local_document: CanonicalDocument,
    cloud_artifact: CloudDocumentAnalysisArtifact,
    *,
    routing_plan: HybridRoutingPlan,
) -> CanonicalCloudFragment:
    """Project normalized cloud geometry using only local rotation authority."""
    if type(routing_plan) is not HybridRoutingPlan:
        raise CloudArtifactProjectionError("cloud routing authority is invalid")
    try:
        routing_plan = HybridRoutingPlan.model_validate(
            routing_plan.model_dump(mode="python", warnings=False)
        )
    except (TypeError, ValueError):
        raise CloudArtifactProjectionError(
            "cloud routing authority is invalid"
        ) from None
    if (
        cloud_artifact.source_document_identity
        != local_document.source_document_identity
        or cloud_artifact.source_sha256 != local_document.provenance.source_sha256
        or routing_plan.document_identity != local_document.canonical_document_id
    ):
        raise CloudArtifactProjectionError(
            "cloud projection crosses local document authority"
        )
    if (
        cloud_artifact.requested_page_numbers != routing_plan.cloud_page_numbers
        or cloud_artifact.requested_capabilities != routing_plan.requested_capabilities
    ):
        raise CloudArtifactProjectionError(
            "cloud artifact does not bind the routing page inventory"
        )
    local_pages = {item.page_index: item for item in local_document.pages}
    decisions = {item.page_index: item for item in routing_plan.page_decisions}
    projected_pages: list[CanonicalCloudPageFragment] = []
    for cloud_page in cloud_artifact.pages:
        local_page = local_pages.get(cloud_page.page_index)
        decision = decisions.get(cloud_page.page_index)
        if (
            local_page is None
            or decision is None
            or decision.route is not HybridPageRoute.CLOUD
            or cloud_page.page_index + 1 not in routing_plan.cloud_page_numbers
        ):
            raise CloudArtifactProjectionError(
                "cloud page lacks exact local routing authority"
            )
        authorized_capabilities = set(decision.required_capabilities)
        provider_outcomes = {
            item.capability: item for item in cloud_page.capability_outcomes
        }
        page_provider_outcomes_list: list[CloudPageCapabilityOutcome] = []
        for capability in decision.required_capabilities:
            outcome = provider_outcomes.get(capability)
            if outcome is None:
                raise CloudArtifactProjectionError(
                    "cloud page lacks required capability outcome"
                )
            page_provider_outcomes_list.append(outcome)
        page_provider_outcomes = tuple(page_provider_outcomes_list)
        page_availability = _availability(
            cloud_page.availability,
            cloud_page.limitations,
        )
        text_blocks = tuple(
            _identified(
                CanonicalCloudTextFragment,
                values={
                    "source_cloud_block_id": item.cloud_block_id,
                    "page_index": item.page_index,
                    "ordinal": item.ordinal,
                    "text": item.text,
                    "bbox": _project_polygon(item.polygon, local_page=local_page),
                    "confidence": item.confidence,
                    "source_role": item.source_role,
                    "availability": page_availability,
                },
            )
            for item in (
                cloud_page.text_blocks
                if DocumentAnalysisCapability.OCR_TEXT in authorized_capabilities
                else ()
            )
        )
        tables: list[CanonicalCloudTableFragment] = []
        authorized_tables = (
            cloud_page.tables
            if DocumentAnalysisCapability.TABLES in authorized_capabilities
            else ()
        )
        for table in authorized_tables:
            cells = tuple(
                _identified(
                    CanonicalCloudCellFragment,
                    values={
                        "source_cloud_cell_id": cell.cloud_cell_id,
                        "page_index": cell.page_index,
                        "table_ordinal": cell.table_ordinal,
                        "ordinal": cell.ordinal,
                        "row_index": cell.row_index,
                        "column_index": cell.column_index,
                        "row_span": cell.row_span,
                        "column_span": cell.column_span,
                        "text": cell.text,
                        "bbox": _project_polygon(
                            cell.polygon,
                            local_page=local_page,
                        ),
                        "kind": cell.kind,
                        "confidence": cell.confidence,
                        "availability": page_availability,
                    },
                )
                for cell in table.cells
            )
            tables.append(
                _identified(
                    CanonicalCloudTableFragment,
                    values={
                        "source_cloud_table_id": table.cloud_table_id,
                        "page_index": table.page_index,
                        "ordinal": table.ordinal,
                        "row_count": table.row_count,
                        "column_count": table.column_count,
                        "cells": cells,
                        "bbox": _project_polygon(
                            table.polygon,
                            local_page=local_page,
                        ),
                        "confidence": table.confidence,
                        "availability": page_availability,
                    },
                )
            )
        page_values: dict[str, object] = {
            "source_cloud_page_id": cloud_page.cloud_page_id,
            "local_page_id": local_page.page_id,
            "page_index": cloud_page.page_index,
            "local_rotation": local_page.geometry.rotation,
            "text_blocks": text_blocks,
            "tables": tuple(tables),
            "required_capabilities": decision.required_capabilities,
            "provider_capability_outcomes": page_provider_outcomes,
            "availability": page_availability,
            "warnings": cloud_page.warnings,
            "limitations": cloud_page.limitations,
            "fallback_reason_codes": _canonical_reasons(decision.reason_codes),
        }
        projected_pages.append(
            _identified(
                CanonicalCloudPageFragment,
                values=page_values,
            )
        )
    artifact_availability = _availability(
        cloud_artifact.availability,
        cloud_artifact.limitations,
    )
    fragment_values: dict[str, object] = {
        "schema_version": CLOUD_FRAGMENT_SCHEMA_VERSION,
        "local_canonical_document_id": local_document.canonical_document_id,
        "source_document_identity": local_document.source_document_identity,
        "source_sha256": local_document.provenance.source_sha256,
        "provider": cloud_artifact.provider,
        "model_id": cloud_artifact.model_id,
        "api_version": cloud_artifact.api_version,
        "submission_scope": cloud_artifact.submission_scope,
        "analysis_page_scope": cloud_artifact.analysis_page_scope,
        "request_identity": cloud_artifact.request_identity,
        "routing_plan_sha256": routing_plan.routing_plan_sha256,
        "requested_page_numbers": cloud_artifact.requested_page_numbers,
        "missing_page_numbers": cloud_artifact.missing_page_numbers,
        "pages": tuple(projected_pages),
        "availability": artifact_availability,
        "warnings": cloud_artifact.warnings,
        "limitations": cloud_artifact.limitations,
        "safe_result_identity": cloud_artifact.safe_result_identity,
        "cloud_payload_sha256": cloud_artifact.payload_sha256,
    }
    return _identified(
        CanonicalCloudFragment,
        values=fragment_values,
    )


__all__ = [
    "CLOUD_FRAGMENT_SCHEMA_VERSION",
    "CanonicalCloudCellFragment",
    "CanonicalCloudFragment",
    "CanonicalCloudPageFragment",
    "CanonicalCloudTableFragment",
    "CanonicalCloudTextFragment",
    "CloudArtifactProjectionError",
    "project_cloud_artifact",
]

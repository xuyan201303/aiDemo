# ruff: noqa: E501, EM101, I001, PLR0913, TRY003, UP017

from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from time import perf_counter
from typing import Literal

from document_sdk.pdf._structural_engine.facts.capabilities import PdfParserCapabilities
from document_sdk.pdf._structural_engine.facts.contracts import (
    PdfExtractionScopeResult,
    PdfFactArtifact,
    PdfPageFacts,
)
from document_sdk.pdf._structural_engine.facts.identifiers import (
    document_identifier,
    source_sha256,
)
from document_sdk.pdf._structural_engine.facts.limits import (
    PdfExtractionLimits,
    PdfExtractionOptions,
    PdfExtractionScopeMode,
    PdfResourceUsage,
    PdfSource,
)
from document_sdk.pdf._structural_engine.facts.status import (
    PdfExtractionStatus,
    PdfFactWarning,
    PdfWarningCode,
    PdfWarningSeverity,
    PdfWarningSuppressionSummary,
)


PDF_SIGNATURE_SEARCH_LIMIT_BYTES = 1_024


_SCOPE_WARNING_CODES = {
    PdfWarningCode.PAGE_LIMIT_REACHED,
    PdfWarningCode.SELECTED_PAGE_LIMIT_REACHED,
    PdfWarningCode.INVALID_EXTRACTION_SCOPE,
    PdfWarningCode.EXTRACTION_TIMEOUT,
    PdfWarningCode.TOTAL_FACT_LIMIT_REACHED,
    PdfWarningCode.ARTIFACT_SIZE_LIMIT_REACHED,
    PdfWarningCode.PARTIAL_PAGE_FAILURE,
}


class PdfWarningCollector:
    """Own the global stored-warning budget for one extraction.

    `max_warning_count` covers artifact, page, and fact occurrences together.
    One slot is reserved for `WARNING_LIMIT_REACHED`; suppressed diagnostics are
    represented only by bounded code/scope counters.
    """

    def __init__(
        self,
        *,
        parser_name: str,
        limit: int,
    ) -> None:
        self.parser_name = parser_name
        self.limit = limit
        self.items: list[PdfFactWarning] = []
        self._stored_count = 0
        self._suppressed_by_code: Counter[PdfWarningCode] = Counter()
        self._suppressed_by_scope: Counter[str] = Counter()
        self._suppressed_affected_page_count = 0
        self._suppressed_affected_fact_count = 0
        self._finalized = False

    @property
    def limit_reached(self) -> bool:
        return bool(self._suppressed_by_code)

    def add(self, warning: PdfFactWarning) -> None:
        self._add(warning=warning, scope="artifact", target=self.items)

    def add_page(
        self,
        warning: PdfFactWarning,
        *,
        target: list[PdfFactWarning],
    ) -> None:
        self._add(warning=warning, scope="page", target=target)

    def add_fact(
        self,
        warning: PdfFactWarning,
        *,
        target: list[PdfFactWarning],
    ) -> None:
        self._add(warning=warning, scope="fact", target=target)

    def _add(
        self,
        *,
        warning: PdfFactWarning,
        scope: Literal["artifact", "page", "fact"],
        target: list[PdfFactWarning],
    ) -> None:
        if self._finalized:
            raise RuntimeError("cannot add warnings after the collector is finalized")
        normal_capacity = max(self.limit - 1, 0)
        if self._stored_count < normal_capacity:
            target.append(warning)
            self._stored_count += 1
            return
        self._suppressed_by_code[warning.code] += 1
        self._suppressed_by_scope[scope] += 1
        if warning.page_number is not None:
            self._suppressed_affected_page_count += 1
        if warning.fact_id is not None:
            self._suppressed_affected_fact_count += 1

    def add_fields(
        self,
        *,
        code: PdfWarningCode,
        message: str,
        severity: PdfWarningSeverity = PdfWarningSeverity.WARNING,
        page_number: int | None = None,
        fact_id: str | None = None,
        recoverable: bool = True,
    ) -> None:
        self.add(
            make_warning(
                code=code,
                parser_name=self.parser_name,
                message=message,
                severity=severity,
                page_number=page_number,
                fact_id=fact_id,
                recoverable=recoverable,
            )
        )

    def final_items(self) -> list[PdfFactWarning]:
        if not self._finalized and self.limit_reached:
            self.items.append(
                make_warning(
                    code=PdfWarningCode.WARNING_LIMIT_REACHED,
                    parser_name=self.parser_name,
                    message=(
                        "Additional PDF extraction warnings were suppressed by the "
                        "global stored-warning limit."
                    ),
                )
            )
            self._stored_count += 1
        self._finalized = True
        return list(self.items)

    def suppression_summary(self) -> PdfWarningSuppressionSummary:
        self.final_items()
        return PdfWarningSuppressionSummary(
            suppressed_warning_count=sum(self._suppressed_by_code.values()),
            suppressed_warning_count_by_code=dict(self._suppressed_by_code),
            suppressed_warning_count_by_scope=dict(  # type: ignore[arg-type]
                self._suppressed_by_scope
            ),
            suppressed_affected_page_count=self._suppressed_affected_page_count,
            suppressed_affected_fact_count=self._suppressed_affected_fact_count,
        )


def make_warning(
    *,
    code: PdfWarningCode,
    parser_name: str,
    message: str,
    severity: PdfWarningSeverity = PdfWarningSeverity.WARNING,
    page_number: int | None = None,
    fact_id: str | None = None,
    recoverable: bool = True,
) -> PdfFactWarning:
    return PdfFactWarning(
        code=code,
        severity=severity,
        page_number=page_number,
        fact_id=fact_id,
        message=message[:240],
        parser_name=parser_name,
        recoverable=recoverable,
    )


def terminal_artifact(
    *,
    source: PdfSource,
    parser_name: str,
    parser_version: str,
    capabilities: PdfParserCapabilities,
    limits: PdfExtractionLimits,
    options: PdfExtractionOptions,
    status: PdfExtractionStatus,
    warning: PdfFactWarning,
    started_at: float,
    page_count: int = 0,
) -> PdfFactArtifact:
    source_hash = source_sha256(source.content)
    artifact = PdfFactArtifact(
        schema_version="pdf_facts.v2",
        document_id=document_identifier(source_hash=source_hash),
        source_sha256=source_hash,
        parser_name=parser_name,
        parser_version=parser_version,
        extracted_at=datetime.now(timezone.utc),
        extraction_status=status,
        page_count=page_count,
        extracted_page_count=0,
        parser_capabilities=capabilities,
        warnings=[warning],
        warning_suppression=PdfWarningSuppressionSummary(),
        applied_resource_limits=limits,
        extraction_options=options,
        extraction_scope_result=build_extraction_scope_result(
            options=options,
            page_count=page_count,
            pages=[],
            warnings=[warning],
            partial_extraction=True,
            force_incomplete=True,
        ),
        partial_extraction=status is PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED,
        resource_usage=PdfResourceUsage(
            source_size_bytes=len(source.content),
            elapsed_milliseconds=(perf_counter() - started_at) * 1_000,
            pages_attempted=0,
            pages_extracted=0,
            total_facts=0,
        ),
        pages=[],
    )
    if artifact_serialized_size(artifact) > limits.max_artifact_serialized_bytes:
        raise RuntimeError("minimum PDF Fact artifact envelope exceeds its hard limit")
    return artifact


def build_artifact(
    *,
    source: PdfSource,
    parser_name: str,
    parser_version: str,
    capabilities: PdfParserCapabilities,
    limits: PdfExtractionLimits,
    options: PdfExtractionOptions,
    status: PdfExtractionStatus,
    page_count: int,
    pages: list[PdfPageFacts],
    warnings: list[PdfFactWarning],
    warning_suppression: PdfWarningSuppressionSummary | None = None,
    started_at: float,
    pages_attempted: int,
    partial_extraction: bool,
) -> PdfFactArtifact:
    source_hash = source_sha256(source.content)
    if options.include_text_members and not capabilities.text_members:
        pages = [
            page.model_copy(update={"text_member_inventory_status": "UNSUPPORTED"})
            for page in pages
        ]
    total_facts = sum(page_total_facts(page) for page in pages)
    return PdfFactArtifact(
        schema_version="pdf_facts.v2",
        document_id=document_identifier(source_hash=source_hash),
        source_sha256=source_hash,
        parser_name=parser_name,
        parser_version=parser_version,
        extracted_at=datetime.now(timezone.utc),
        extraction_status=status,
        page_count=page_count,
        extracted_page_count=len(pages),
        parser_capabilities=capabilities,
        warnings=list(warnings),
        warning_suppression=(warning_suppression or PdfWarningSuppressionSummary()),
        applied_resource_limits=limits,
        extraction_options=options,
        extraction_scope_result=build_extraction_scope_result(
            options=options,
            page_count=page_count,
            pages=pages,
            warnings=warnings,
            partial_extraction=partial_extraction,
        ),
        partial_extraction=partial_extraction,
        resource_usage=PdfResourceUsage(
            source_size_bytes=len(source.content),
            elapsed_milliseconds=(perf_counter() - started_at) * 1_000,
            pages_attempted=pages_attempted,
            pages_extracted=len(pages),
            total_facts=total_facts,
            text_member_count=sum(page.text_member_count for page in pages),
            text_member_evidence_bytes=sum(
                page.text_member_serialized_bytes
                + page.text_member_reference_bytes
                + page.text_source_group_serialized_bytes
                + page.native_text_event_serialized_bytes
                for page in pages
            ),
        ),
        pages=pages,
    )


def build_extraction_scope_result(
    *,
    options: PdfExtractionOptions,
    page_count: int,
    pages: list[PdfPageFacts],
    warnings: list[PdfFactWarning],
    partial_extraction: bool,
    force_incomplete: bool = False,
) -> PdfExtractionScopeResult:
    request = options.extraction_scope
    extracted_page_numbers = tuple(sorted(page.page_number for page in pages))
    incomplete_page_number_set = {
        page.page_number
        for page in pages
        if page.extraction_status is not PdfExtractionStatus.SUCCESS
    }
    incomplete_page_number_set.update(
        warning.page_number
        for warning in warnings
        if warning.page_number in set(extracted_page_numbers)
        and warning.code
        in {
            PdfWarningCode.PAGE_PARTIALLY_PARSED,
            PdfWarningCode.PARTIAL_PAGE_FAILURE,
        }
    )
    if request.mode is PdfExtractionScopeMode.SELECTED_PAGES:
        requested_page_numbers = request.requested_page_numbers
        requested_page_count = len(requested_page_numbers)
        missing_page_numbers = tuple(
            sorted(set(requested_page_numbers) - set(extracted_page_numbers))
        )
        missing_page_count = len(missing_page_numbers)
    else:
        requested_page_numbers = ()
        requested_page_count = page_count
        missing_page_numbers = ()
        missing_page_count = max(page_count - len(extracted_page_numbers), 0)

    if partial_extraction and not missing_page_count and not incomplete_page_number_set:
        incomplete_page_number_set.update(extracted_page_numbers)
    incomplete_page_numbers = tuple(sorted(incomplete_page_number_set))

    scope_warning_codes = tuple(
        sorted(
            {
                warning.code
                for warning in warnings
                if warning.code in _SCOPE_WARNING_CODES
            },
            key=lambda code: code.value,
        )
    )
    selected_page_limit_applied = (
        PdfWarningCode.SELECTED_PAGE_LIMIT_REACHED in scope_warning_codes
    )
    requested_scope_complete = not (
        missing_page_count or incomplete_page_numbers or force_incomplete
    )
    digest_payload = {
        "schema_version": request.schema_version,
        "mode": request.mode.value,
        "source_document_page_count": page_count,
        "requested_page_numbers": list(requested_page_numbers),
    }
    scope_digest = hashlib.sha256(
        json.dumps(
            digest_payload,
            separators=(",", ":"),
            sort_keys=True,
        ).encode("utf-8")
    ).hexdigest()
    return PdfExtractionScopeResult(
        mode=request.mode,
        source_document_page_count=page_count,
        requested_page_numbers=requested_page_numbers,
        requested_page_count=requested_page_count,
        extracted_requested_page_numbers=extracted_page_numbers,
        extracted_requested_page_count=len(extracted_page_numbers),
        missing_requested_page_numbers=missing_page_numbers,
        missing_requested_page_count=missing_page_count,
        incomplete_requested_page_numbers=incomplete_page_numbers,
        incomplete_requested_page_count=len(incomplete_page_numbers),
        requested_scope_complete=requested_scope_complete,
        scope_evaluation_available=not force_incomplete,
        source_document_fully_extracted=(
            requested_scope_complete and len(extracted_page_numbers) == page_count
        ),
        scope_digest=scope_digest,
        selected_page_limit_applied=selected_page_limit_applied,
        scope_truncated=any(
            code
            in {
                PdfWarningCode.PAGE_LIMIT_REACHED,
                PdfWarningCode.SELECTED_PAGE_LIMIT_REACHED,
                PdfWarningCode.EXTRACTION_TIMEOUT,
                PdfWarningCode.TOTAL_FACT_LIMIT_REACHED,
                PdfWarningCode.ARTIFACT_SIZE_LIMIT_REACHED,
            }
            for code in scope_warning_codes
        ),
        scope_warning_codes=scope_warning_codes,
    )


def page_total_facts(page: PdfPageFacts) -> int:
    return (
        page.text_span_count
        + page.word_count
        + page.line_candidate_count
        + sum(not bool(fact.member_ids) for fact in page.characters)
        + page.text_member_count
        + page.drawing_count
        + page.image_region_count
    )


def canonical_json_serialized_size(value: object) -> int:
    """Use the artifact JSON encoding for bounded incremental admission."""
    return len(
        json.dumps(
            value,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        ).encode("utf-8")
    )


def artifact_serialized_size(artifact: PdfFactArtifact) -> int:
    return canonical_json_serialized_size(artifact.model_dump(mode="json"))


def build_size_limited_artifact(
    *,
    source: PdfSource,
    parser_name: str,
    parser_version: str,
    capabilities: PdfParserCapabilities,
    limits: PdfExtractionLimits,
    options: PdfExtractionOptions,
    status: PdfExtractionStatus,
    page_count: int,
    pages: list[PdfPageFacts],
    warnings: list[PdfFactWarning],
    warning_suppression: PdfWarningSuppressionSummary | None = None,
    started_at: float,
    pages_attempted: int,
    partial_extraction: bool,
) -> PdfFactArtifact:
    retained_pages = list(pages)
    effective_status = status
    effective_partial = partial_extraction
    effective_warnings = list(warnings)
    effective_warning_suppression = (
        warning_suppression or PdfWarningSuppressionSummary()
    )
    while True:
        artifact = build_artifact(
            source=source,
            parser_name=parser_name,
            parser_version=parser_version,
            capabilities=capabilities,
            limits=limits,
            options=options,
            status=effective_status,
            page_count=page_count,
            pages=retained_pages,
            warnings=effective_warnings,
            warning_suppression=effective_warning_suppression,
            started_at=started_at,
            pages_attempted=pages_attempted,
            partial_extraction=effective_partial,
        )
        if artifact_serialized_size(artifact) <= limits.max_artifact_serialized_bytes:
            return artifact
        if not any(
            item.code is PdfWarningCode.ARTIFACT_SIZE_LIMIT_REACHED
            for item in effective_warnings
        ):
            size_warning = make_warning(
                code=PdfWarningCode.ARTIFACT_SIZE_LIMIT_REACHED,
                parser_name=parser_name,
                message="PDF Fact artifact exceeded the configured serialized-size limit.",
                recoverable=False,
            )
            stored_count = _stored_warning_occurrence_count(
                pages=retained_pages,
                artifact_warnings=effective_warnings,
            )
            if stored_count < limits.max_warning_count:
                effective_warnings.append(size_warning)
            elif effective_warning_suppression.suppressed_warning_count:
                effective_warning_suppression = _with_suppressed_warning(
                    effective_warning_suppression,
                    warning=size_warning,
                    scope="artifact",
                )
            else:
                effective_warnings = [size_warning]
        effective_status = PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED
        effective_partial = True
        if not retained_pages:
            compact_warning = make_warning(
                code=PdfWarningCode.ARTIFACT_SIZE_LIMIT_REACHED,
                parser_name=parser_name,
                message="PDF Fact artifact exceeded the configured serialized-size limit.",
                recoverable=False,
            )
            terminal = build_artifact(
                source=source,
                parser_name=parser_name,
                parser_version=parser_version,
                capabilities=capabilities,
                limits=limits,
                options=options,
                status=effective_status,
                page_count=page_count,
                pages=[],
                warnings=_terminal_size_warnings(
                    parser_name=parser_name,
                    compact_warning=compact_warning,
                    limits=limits,
                    suppression=effective_warning_suppression,
                ),
                warning_suppression=effective_warning_suppression,
                started_at=started_at,
                pages_attempted=pages_attempted,
                partial_extraction=True,
            )
            if (
                artifact_serialized_size(terminal)
                > limits.max_artifact_serialized_bytes
            ):
                raise RuntimeError(
                    "minimum PDF Fact artifact envelope exceeds its hard limit"
                )
            return terminal
        retained_pages.pop()


def _stored_warning_occurrence_count(
    *,
    pages: list[PdfPageFacts],
    artifact_warnings: list[PdfFactWarning],
) -> int:
    count = len(artifact_warnings)
    for page in pages:
        count += len(page.warnings)
        count += sum(
            len(fact.warnings)  # type: ignore[misc, attr-defined]
            for fact in (
                *page.text_spans,
                *page.words,
                *page.line_candidates,
                *page.characters,
                *page.text_members,
                *page.drawings,
                *page.image_regions,
            )
        )
    return count


def _with_suppressed_warning(
    summary: PdfWarningSuppressionSummary,
    *,
    warning: PdfFactWarning,
    scope: Literal["artifact", "page", "fact"],
) -> PdfWarningSuppressionSummary:
    by_code = Counter(summary.suppressed_warning_count_by_code)
    by_scope = Counter(summary.suppressed_warning_count_by_scope)
    by_code[warning.code] += 1
    by_scope[scope] += 1
    return PdfWarningSuppressionSummary(
        suppressed_warning_count=summary.suppressed_warning_count + 1,
        suppressed_warning_count_by_code=dict(by_code),
        suppressed_warning_count_by_scope=dict(by_scope),
        suppressed_affected_page_count=(
            summary.suppressed_affected_page_count
            + int(warning.page_number is not None)
        ),
        suppressed_affected_fact_count=(
            summary.suppressed_affected_fact_count + int(warning.fact_id is not None)
        ),
    )


def _terminal_size_warnings(
    *,
    parser_name: str,
    compact_warning: PdfFactWarning,
    limits: PdfExtractionLimits,
    suppression: PdfWarningSuppressionSummary,
) -> list[PdfFactWarning]:
    if not suppression.suppressed_warning_count:
        return [compact_warning]
    marker = make_warning(
        code=PdfWarningCode.WARNING_LIMIT_REACHED,
        parser_name=parser_name,
        message=(
            "Additional PDF extraction warnings were suppressed by the global "
            "stored-warning limit."
        ),
    )
    if limits.max_warning_count == 1:
        return [marker]
    return [marker, compact_warning]


def source_preflight_warning(
    *,
    source: PdfSource,
    parser_name: str,
    limits: PdfExtractionLimits,
) -> tuple[PdfExtractionStatus, PdfFactWarning] | None:
    if len(source.content) > limits.max_file_size_bytes:
        return (
            PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED,
            make_warning(
                code=PdfWarningCode.FILE_SIZE_LIMIT_REACHED,
                parser_name=parser_name,
                message="PDF source exceeded the configured file-size limit.",
                recoverable=False,
            ),
        )
    if source.content[:PDF_SIGNATURE_SEARCH_LIMIT_BYTES].find(b"%PDF-") < 0:
        return (
            PdfExtractionStatus.MALFORMED,
            make_warning(
                code=PdfWarningCode.MALFORMED_DOCUMENT,
                parser_name=parser_name,
                message="PDF signature validation failed.",
                severity=PdfWarningSeverity.ERROR,
                recoverable=False,
            ),
        )
    return None

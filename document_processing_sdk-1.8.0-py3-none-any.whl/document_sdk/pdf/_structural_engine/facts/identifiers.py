# ruff: noqa: EM101, I001, PLR0913, TRY003

from hashlib import sha256
import json
import re

from document_sdk.pdf._structural_engine.facts.contracts import PdfBoundingBox


def source_sha256(content: bytes) -> str:
    return sha256(content).hexdigest()


def document_identifier(*, source_hash: str) -> str:
    return f"PDFD-{_digest('document', source_hash)}"


def page_identifier(
    *,
    source_hash: str,
    parser_name: str,
    parser_version: str,
    page_number: int,
) -> str:
    return f"PDFP-{_digest(source_hash, parser_name, parser_version, str(page_number))}"


def fact_identifier(
    *,
    source_hash: str,
    parser_name: str,
    parser_version: str,
    page_number: int,
    fact_type: str,
    source_order: int,
    bbox: PdfBoundingBox,
    text: str | None = None,
) -> str:
    bounded_text_hash = sha256((text or "")[:4_096].encode("utf-8")).hexdigest()[:16]
    bbox_key = ",".join(
        f"{value:.4f}" for value in (bbox.x0, bbox.y0, bbox.x1, bbox.y1)
    )
    return "PDFF-" + _digest(
        source_hash,
        parser_name,
        parser_version,
        str(page_number),
        _safe_token(fact_type),
        str(source_order),
        bbox_key,
        bounded_text_hash,
    )


def _digest(*parts: str) -> str:
    payload = "\x1f".join(parts).encode("utf-8")
    return sha256(payload).hexdigest()[:24]


def _safe_token(value: str) -> str:
    normalized = re.sub(r"[^a-z0-9_-]+", "-", value.casefold()).strip("-")
    if not normalized:
        raise ValueError("identifier token must contain a safe character")
    return normalized


def text_member_identifier(
    *,
    source_hash: str,
    parser_name: str,
    parser_version: str,
    method_version: str,
    page_number: int,
    source_character_index: int,
    text: str,
    parser_bbox: tuple[float, float, float, float] | None,
    matrix: tuple[float, float, float, float, float, float] | None,
    parser_advance: float | None = None,
    source_writing_mode: str = "UNKNOWN",
    native_text_event_id: str | None = None,
    native_text_event_ordinal: int | None = None,
    native_text_event_member_ordinal: int | None = None,
    native_character_ordinal: int | None = None,
) -> str:
    payload = {
        "domain": "document_sdk.pdf.text_member.v1",
        "source_sha256": source_hash,
        "parser_name": parser_name,
        "parser_version": parser_version,
        "method_version": method_version,
        "page_number": page_number,
        "source_character_index": source_character_index,
        "text": text,
        "parser_bbox": parser_bbox,
        "matrix": matrix,
    }
    if method_version == "pdfplumber.member_pool.v2":
        payload.update(
            {
                "parser_advance": parser_advance,
                "source_writing_mode": source_writing_mode,
                "native_text_event_id": native_text_event_id,
                "native_text_event_ordinal": native_text_event_ordinal,
                "native_text_event_member_ordinal": native_text_event_member_ordinal,
                "native_character_ordinal": native_character_ordinal,
            }
        )
    return (
        "PDFF-"
        + sha256(
            json.dumps(
                payload,
                sort_keys=True,
                ensure_ascii=False,
                allow_nan=False,
                separators=(",", ":"),
            ).encode()
        ).hexdigest()[:24]
    )


def text_source_group_identifier(
    *,
    source_hash: str,
    page_id: str,
    method_version: str,
    granularity: str,
    source_group_order: int,
    text: str,
) -> str:
    payload = (
        "document_sdk.pdf.text_source_group.v1",
        source_hash,
        page_id,
        method_version,
        granularity,
        source_group_order,
        sha256(text.encode()).hexdigest(),
    )
    return (
        "PDFTG-"
        + sha256(
            json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode()
        ).hexdigest()
    )

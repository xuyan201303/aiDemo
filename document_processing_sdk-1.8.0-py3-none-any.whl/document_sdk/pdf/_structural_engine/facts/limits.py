# ruff: noqa: D202, E501, EM101, I001, TRY003, TRY004, UP042

from dataclasses import dataclass
from enum import Enum
from hashlib import sha256
import json
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


MIN_PDF_FACT_ARTIFACT_SERIALIZED_BYTES = 4_096
PDF_EXTRACTION_SCOPE_SCHEMA_VERSION = "pdf_extraction_scope.v1"
PDF_REQUEST_SCOPE_DIGEST_CONTRACT_VERSION = "pdf_request_scope_digest.v1"


class PdfExtractionScopeMode(str, Enum):
    FULL_DOCUMENT = "full_document"
    SELECTED_PAGES = "selected_pages"


class PdfExtractionScope(BaseModel):
    """Requested source-page inventory for one canonical Fact extraction."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    schema_version: Literal["pdf_extraction_scope.v1"] = (
        PDF_EXTRACTION_SCOPE_SCHEMA_VERSION  # type: ignore[assignment]
    )
    mode: PdfExtractionScopeMode = PdfExtractionScopeMode.FULL_DOCUMENT
    requested_page_numbers: tuple[int, ...] = ()

    @field_validator("requested_page_numbers", mode="before")
    @classmethod
    def canonicalize_page_numbers(cls, value: Any) -> tuple[int, ...]:
        if value is None:
            return ()
        if isinstance(value, (str, bytes)):
            raise ValueError("requested page numbers must be an integer inventory")
        try:
            items = tuple(value)
        except TypeError:
            raise ValueError(
                "requested page numbers must be an integer inventory"
            ) from None
        if any(isinstance(item, bool) or not isinstance(item, int) for item in items):
            raise ValueError("requested page numbers must be integers")
        return tuple(sorted(set(items)))

    @model_validator(mode="after")
    def validate_scope(self) -> "PdfExtractionScope":
        if any(page_number <= 0 for page_number in self.requested_page_numbers):
            raise ValueError("requested page numbers must be positive and 1-based")
        if self.mode is PdfExtractionScopeMode.FULL_DOCUMENT:
            if self.requested_page_numbers:
                raise ValueError("full-document scope cannot carry selected pages")
        elif not self.requested_page_numbers:
            raise ValueError("selected-pages scope requires at least one page")
        return self


def canonical_request_scope_inventory_sha256(scope: PdfExtractionScope) -> str:
    """Bind a worker response to one canonical request inventory."""

    payload = {
        "schema_version": scope.schema_version,
        "mode": scope.mode.value,
        "requested_page_numbers": list(scope.requested_page_numbers),
    }
    return sha256(
        json.dumps(
            payload,
            separators=(",", ":"),
            sort_keys=True,
        ).encode("utf-8")
    ).hexdigest()


class PdfExtractionLimits(BaseModel):
    """Configurable Phase 1A guardrails; defaults remain benchmark candidates."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    max_file_size_bytes: int = Field(default=50 * 1024 * 1024, ge=1)
    max_page_count: int = Field(default=1_000, ge=1)
    max_selected_page_count: int = Field(default=256, ge=1)
    max_page_content_stream_bytes: int = Field(default=64 * 1024 * 1024, ge=1)
    max_text_facts_per_page: int = Field(default=250_000, ge=1)
    max_characters_per_page: int = Field(default=1_000_000, ge=1)
    max_text_members_per_page: int = Field(default=250_000, ge=1)
    max_text_member_bytes_per_page: int = Field(default=32 * 1024 * 1024, ge=256)
    max_drawing_facts_per_page: int = Field(default=100_000, ge=1)
    max_path_segments_per_drawing: int = Field(default=4_096, ge=1)
    max_path_segments_per_page: int = Field(default=250_000, ge=1)
    max_image_regions_per_page: int = Field(default=10_000, ge=1)
    max_total_facts: int = Field(default=2_000_000, ge=1)
    timeout_seconds: float = Field(default=120.0, gt=0)
    max_warning_count: int = Field(
        default=1_000,
        ge=1,
        description=(
            "Maximum stored warning occurrences across artifact, page, and fact scopes. "
            "A warning-limit marker consumes one occurrence when suppression occurs."
        ),
    )
    max_artifact_serialized_bytes: int = Field(
        default=256 * 1024 * 1024,
        ge=MIN_PDF_FACT_ARTIFACT_SERIALIZED_BYTES,
    )


class PdfExtractionOptions(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    include_characters: bool = False
    include_text_members: bool = False
    include_drawings: bool = True
    include_image_regions: bool = True
    extraction_scope: PdfExtractionScope = Field(default_factory=PdfExtractionScope)


class PdfResourceUsage(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    source_size_bytes: int = Field(ge=0)
    elapsed_milliseconds: float = Field(ge=0)
    pages_attempted: int = Field(ge=0)
    pages_extracted: int = Field(ge=0)
    total_facts: int = Field(ge=0)
    text_member_count: int = Field(default=0, ge=0)
    text_member_evidence_bytes: int = Field(default=0, ge=0)
    peak_memory_bytes: int | None = Field(default=None, ge=0)
    peak_memory_measurement: Literal[
        "unavailable",
        "python_tracemalloc",
    ] = "unavailable"


@dataclass(frozen=True)
class PdfSource:
    content: bytes

    def __post_init__(self) -> None:
        if not isinstance(self.content, bytes):
            raise TypeError("PdfSource.content must be bytes")

from typing import Protocol, runtime_checkable

from document_sdk.pdf._structural_engine.facts.capabilities import PdfParserCapabilities
from document_sdk.pdf._structural_engine.facts.contracts import PdfFactArtifact
from document_sdk.pdf._structural_engine.facts.limits import (
    PdfExtractionLimits,
    PdfExtractionOptions,
    PdfSource,
)


@runtime_checkable
class PdfFactExtractor(Protocol):
    @property
    def parser_name(self) -> str: ...

    @property
    def parser_version(self) -> str: ...

    def capabilities(self) -> PdfParserCapabilities: ...

    def extract(
        self,
        source: PdfSource,
        *,
        limits: PdfExtractionLimits,
        options: PdfExtractionOptions,
    ) -> PdfFactArtifact: ...

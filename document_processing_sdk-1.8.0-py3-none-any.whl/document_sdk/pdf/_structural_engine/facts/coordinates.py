# ruff: noqa: D202, EM101, I001, PLR0913, PLR2004, TRY003, UP042

from dataclasses import dataclass
from enum import Enum
import math
from typing import Literal

from document_sdk.pdf._structural_engine.facts.contracts import (
    PdfAffineTransform,
    PdfBoundingBox,
    PdfCoordinateTransformProvenance,
    PdfGeometryCompleteness,
    PdfGeometryConfidence,
    PdfNormalizedBoundingBox,
    PdfPageBox,
    PdfPageBoxBasis,
    PdfPoint,
)
from document_sdk.pdf._structural_engine.facts.status import PdfWarningCode


PDF_COORDINATE_TOLERANCE = 1e-6


class PdfSourceCoordinateSpace(str, Enum):
    BOTTOM_LEFT_Y_UP_UNROTATED = "bottom_left_y_up_unrotated"
    TOP_LEFT_Y_DOWN_UNROTATED = "top_left_y_down_unrotated"
    TOP_LEFT_Y_DOWN_VISUAL = "top_left_y_down_visual"


class PdfTextRotationSource(str, Enum):
    """Source angle semantics used to derive canonical visual rotation."""

    PDF_USER_SPACE_COUNTERCLOCKWISE = "pdf_user_space_counterclockwise"
    VISUAL_SPACE_COUNTERCLOCKWISE = "visual_space_counterclockwise"
    CANONICAL_VISUAL_CLOCKWISE = "canonical_visual_clockwise"
    UNROTATED_VISUAL_CLOCKWISE = "unrotated_visual_clockwise"


PdfBBoxFactKind = Literal[
    "text",
    "line",
    "rectangle",
    "curve",
    "image_region",
]


@dataclass(frozen=True)
class PdfCoordinateNormalizationResult:
    bbox: PdfBoundingBox | None
    normalized_bbox: PdfNormalizedBoundingBox | None
    warning_code: PdfWarningCode | None


@dataclass(frozen=True)
class PdfCoordinatePointNormalizationResult:
    point: PdfPoint | None
    warning_code: PdfWarningCode | None


@dataclass(frozen=True)
class PdfCanonicalPageGeometry:
    media_box: PdfPageBox
    crop_box: PdfPageBox
    effective_page_box: PdfPageBox
    effective_page_box_basis: PdfPageBoxBasis
    source_effective_box: tuple[float, float, float, float]
    original_width: float
    original_height: float
    canonical_width: float
    canonical_height: float
    user_unit: float


def canonical_page_geometry(
    *,
    media_box: tuple[float, float, float, float],
    crop_box: tuple[float, float, float, float] | None,
    page_rotation: int,
    user_unit: float,
) -> PdfCanonicalPageGeometry:
    """Normalize page dictionaries without discarding their non-zero origin."""

    raw_media = _ordered_page_box(media_box)
    raw_crop = _ordered_page_box(crop_box or media_box)
    if not math.isfinite(user_unit) or not 1 <= user_unit <= 75_000:
        raise ValueError("UserUnit must be finite and between 1 and 75000")
    _validate_page_geometry(
        raw_media[2] - raw_media[0],
        raw_media[3] - raw_media[1],
        page_rotation,
    )
    effective = (
        max(raw_media[0], raw_crop[0]),
        max(raw_media[1], raw_crop[1]),
        min(raw_media[2], raw_crop[2]),
        min(raw_media[3], raw_crop[3]),
    )
    if effective[0] >= effective[2] or effective[1] >= effective[3]:
        raise ValueError("MediaBox and CropBox must have a positive intersection")

    scaled_media = _scaled_page_box(raw_media, user_unit)
    scaled_crop = _scaled_page_box(raw_crop, user_unit)
    scaled_effective = _scaled_page_box(effective, user_unit)
    original_width = scaled_effective.width
    original_height = scaled_effective.height
    canonical_width, canonical_height = canonical_page_dimensions(
        original_width=original_width,
        original_height=original_height,
        page_rotation=page_rotation,
    )
    basis: PdfPageBoxBasis = (
        "media_box" if _boxes_close(raw_media, raw_crop) else "media_crop_intersection"
    )
    return PdfCanonicalPageGeometry(
        media_box=scaled_media,
        crop_box=scaled_crop,
        effective_page_box=scaled_effective,
        effective_page_box_basis=basis,
        source_effective_box=effective,
        original_width=original_width,
        original_height=original_height,
        canonical_width=canonical_width,
        canonical_height=canonical_height,
        user_unit=float(user_unit),
    )


def coordinate_transform_provenance(
    *,
    parser_coordinate_space: str,
    parser_page_box_basis: PdfPageBoxBasis,
    parser_applies_page_rotation: bool,
    parser_applies_user_unit: bool,
    canonical_page_box_basis: PdfPageBoxBasis,
    geometry_source: str,
    geometry_completeness: PdfGeometryCompleteness = "complete",
    geometry_confidence: PdfGeometryConfidence = "high",
    assumed_origin: bool = False,
    assumed_user_unit: bool = False,
    fallback_provider: str | None = None,
) -> PdfCoordinateTransformProvenance:
    return PdfCoordinateTransformProvenance(
        parser_coordinate_space=parser_coordinate_space,  # type: ignore[arg-type]
        parser_page_box_basis=parser_page_box_basis,
        parser_applies_page_rotation=parser_applies_page_rotation,
        parser_applies_user_unit=parser_applies_user_unit,
        canonical_page_box_basis=canonical_page_box_basis,
        canonical_origin_translation_applied=True,
        canonical_page_rotation_applied=True,
        canonical_user_unit_applied=not parser_applies_user_unit,
        geometry_source=geometry_source,
        geometry_completeness=geometry_completeness,
        geometry_confidence=geometry_confidence,
        assumed_origin=assumed_origin,
        assumed_user_unit=assumed_user_unit,
        fallback_provider=fallback_provider,
    )


def normalize_scalar_length(
    value: object,
    *,
    user_unit: float,
    source_applies_user_unit: bool = False,
) -> float | None:
    """Normalize a parser distance into canonical PDF points.

    Scalar lengths are invariant under page rotation. UserUnit is applied once
    unless the parser explicitly reports values in already-scaled PDF points.
    """

    try:
        parsed = float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return None
    if not math.isfinite(parsed) or parsed < 0:
        return None
    if not math.isfinite(user_unit) or not 1 <= user_unit <= 75_000:
        raise ValueError("UserUnit must be finite and between 1 and 75000")
    scale = 1.0 if source_applies_user_unit else float(user_unit)
    return parsed * scale


def source_affine_transform(
    matrix: object,
) -> PdfAffineTransform | None:
    """Validate a parser-source six-value affine transform without reinterpreting it."""

    if not isinstance(matrix, (tuple, list)) or len(matrix) != 6:
        return None
    try:
        values = tuple(float(value) for value in matrix)
    except (TypeError, ValueError):
        return None
    if not all(math.isfinite(value) for value in values):
        return None
    return PdfAffineTransform(
        a=values[0],
        b=values[1],
        c=values[2],
        d=values[3],
        e=values[4],
        f=values[5],
    )


def canonical_affine_scale_components(
    matrix: object,
    *,
    user_unit: float,
    source_applies_user_unit: bool = False,
) -> tuple[float, float] | None:
    """Return canonical x/y basis lengths for an affine transform.

    Page rotation and reflection do not alter these scalar lengths. UserUnit is
    applied exactly once. Translation is intentionally ignored.
    """

    transform = source_affine_transform(matrix)
    if transform is None:
        return None
    if not math.isfinite(user_unit) or not 1 <= user_unit <= 75_000:
        raise ValueError("UserUnit must be finite and between 1 and 75000")
    unit_scale = 1.0 if source_applies_user_unit else float(user_unit)
    return (
        math.hypot(transform.a, transform.b) * unit_scale,
        math.hypot(transform.c, transform.d) * unit_scale,
    )


def effective_affine_scalar_components(
    nominal_value: object,
    matrix: object,
    *,
    user_unit: float,
    source_applies_user_unit: bool = False,
) -> tuple[float, float] | None:
    """Apply an affine transform to a nominal scalar without collapsing x/y."""

    try:
        nominal = float(nominal_value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return None
    if not math.isfinite(nominal) or nominal < 0:
        return None
    scales = canonical_affine_scale_components(
        matrix,
        user_unit=user_unit,
        source_applies_user_unit=source_applies_user_unit,
    )
    if scales is None:
        return None
    return nominal * scales[0], nominal * scales[1]


def canonical_page_dimensions(
    *,
    original_width: float,
    original_height: float,
    page_rotation: int,
) -> tuple[float, float]:
    _validate_page_geometry(original_width, original_height, page_rotation)
    if page_rotation in (90, 270):
        return original_height, original_width
    return original_width, original_height


def transform_bbox_without_admission(
    *,
    bbox: tuple[float, float, float, float],
    original_width: float,
    original_height: float,
    page_rotation: int,
    source_space: PdfSourceCoordinateSpace,
    source_origin_x: float = 0,
    source_origin_y: float = 0,
    user_unit: float = 1,
    source_applies_user_unit: bool = False,
) -> PdfBoundingBox | None:
    """Convert parser coordinates to top-left, y-down visual PDF points."""

    _validate_page_geometry(original_width, original_height, page_rotation)
    if not math.isfinite(user_unit) or user_unit < 1:
        raise ValueError("UserUnit must be finite and at least 1")
    if not all(math.isfinite(value) for value in (source_origin_x, source_origin_y)):
        raise ValueError("source origin must be finite")
    if len(bbox) != 4 or not all(math.isfinite(float(value)) for value in bbox):
        return None

    x0, y0, x1, y1 = (float(value) for value in bbox)
    if x0 > x1 or y0 > y1:
        return None

    scale = 1.0 if source_applies_user_unit else float(user_unit)
    points = tuple(
        (
            (x - source_origin_x) * scale,
            (y - source_origin_y) * scale,
        )
        for x, y in (
            (x0, y0),
            (x0, y1),
            (x1, y0),
            (x1, y1),
        )
    )
    if source_space is PdfSourceCoordinateSpace.TOP_LEFT_Y_DOWN_VISUAL:
        transformed = points
    else:
        if source_space is PdfSourceCoordinateSpace.BOTTOM_LEFT_Y_UP_UNROTATED:
            top_left_points = tuple((x, original_height - y) for x, y in points)
        else:
            top_left_points = points
        transformed = tuple(
            _rotate_top_left_point(
                x=x,
                y=y,
                width=original_width,
                height=original_height,
                rotation=page_rotation,
            )
            for x, y in top_left_points
        )

    canonical_values = (
        min(point[0] for point in transformed),
        min(point[1] for point in transformed),
        max(point[0] for point in transformed),
        max(point[1] for point in transformed),
    )
    # Finite parser operands can overflow during origin translation or scaling.
    # Retain the existing invalid-box outcome instead of failing the entire page.
    if not all(math.isfinite(value) for value in canonical_values):
        return None
    return PdfBoundingBox(
        x0=canonical_values[0],
        y0=canonical_values[1],
        x1=canonical_values[2],
        y1=canonical_values[3],
    )


def normalize_bbox(
    *,
    bbox: tuple[float, float, float, float],
    original_width: float,
    original_height: float,
    page_rotation: int,
    source_space: PdfSourceCoordinateSpace,
    source_origin_x: float = 0,
    source_origin_y: float = 0,
    user_unit: float = 1,
    source_applies_user_unit: bool = False,
    tolerance: float = PDF_COORDINATE_TOLERANCE,
) -> PdfCoordinateNormalizationResult:
    """Transform and apply the existing strict page admission contract."""
    if tolerance < 0 or not math.isfinite(tolerance):
        raise ValueError("tolerance must be finite and non-negative")
    observed = transform_bbox_without_admission(
        bbox=bbox,
        original_width=original_width,
        original_height=original_height,
        page_rotation=page_rotation,
        source_space=source_space,
        source_origin_x=source_origin_x,
        source_origin_y=source_origin_y,
        user_unit=user_unit,
        source_applies_user_unit=source_applies_user_unit,
    )
    if observed is None:
        return PdfCoordinateNormalizationResult(None, None, PdfWarningCode.INVALID_BBOX)
    canonical_values = (observed.x0, observed.y0, observed.x1, observed.y1)
    canonical_width, canonical_height = canonical_page_dimensions(
        original_width=original_width,
        original_height=original_height,
        page_rotation=page_rotation,
    )
    if (
        canonical_values[0] < -tolerance
        or canonical_values[1] < -tolerance
        or canonical_values[2] > canonical_width + tolerance
        or canonical_values[3] > canonical_height + tolerance
    ):
        return PdfCoordinateNormalizationResult(None, None, PdfWarningCode.INVALID_BBOX)

    cx0 = min(max(canonical_values[0], 0.0), canonical_width)
    cy0 = min(max(canonical_values[1], 0.0), canonical_height)
    cx1 = min(max(canonical_values[2], 0.0), canonical_width)
    cy1 = min(max(canonical_values[3], 0.0), canonical_height)
    canonical_bbox = PdfBoundingBox(x0=cx0, y0=cy0, x1=cx1, y1=cy1)
    normalized_bbox = PdfNormalizedBoundingBox(
        x0=cx0 / canonical_width,
        y0=cy0 / canonical_height,
        x1=cx1 / canonical_width,
        y1=cy1 / canonical_height,
    )
    return PdfCoordinateNormalizationResult(
        canonical_bbox,
        normalized_bbox,
        None,
    )


def pdfminer_native_origin_to_canonical(
    *,
    parser_origin: tuple[float, float],
    media_box: tuple[float, float, float, float],
    effective_box: tuple[float, float, float, float],
    page_rotation: int,
    user_unit: float,
) -> tuple[float, float]:
    """Map an LTChar matrix origin to effective-page visual PDF points.

    pdfminer has already applied the page CTM: matrix translations are in
    rotated, MediaBox-relative, y-up user units. The retained unrotated page
    boxes have UserUnit applied already. Translate the rotated crop origin
    and apply UserUnit once; never rotate the matrix translation a second
    time, clip an outside anchor, or infer cell ownership from this mapping.
    """
    if (
        page_rotation not in (0, 90, 180, 270)
        or not 1 <= user_unit <= 75_000
        or not all(
            math.isfinite(v) for v in (*parser_origin, *media_box, *effective_box)
        )
        or not (
            media_box[0] <= effective_box[0] < effective_box[2] <= media_box[2]
            and media_box[1] <= effective_box[1] < effective_box[3] <= media_box[3]
        )
    ):
        raise ValueError("native origin requires valid bound page geometry")
    mx0, my0, mx1, my1 = media_box
    ex0, ey0, ex1, ey1 = effective_box
    if page_rotation == 0:
        dx, dy, height = ex0 - mx0, my1 - ey1, my1 - my0
    elif page_rotation == 90:
        dx, dy, height = ey0 - my0, ex0 - mx0, mx1 - mx0
    elif page_rotation == 180:
        dx, dy, height = mx1 - ex1, ey0 - my0, my1 - my0
    else:
        dx, dy, height = my1 - ey1, mx1 - ex1, mx1 - mx0
    return parser_origin[0] * user_unit - dx, height - parser_origin[1] * user_unit - dy


def normalize_point(
    *,
    point: tuple[float, float],
    original_width: float,
    original_height: float,
    page_rotation: int,
    source_space: PdfSourceCoordinateSpace,
    source_origin_x: float = 0,
    source_origin_y: float = 0,
    user_unit: float = 1,
    source_applies_user_unit: bool = False,
    tolerance: float = PDF_COORDINATE_TOLERANCE,
) -> PdfCoordinatePointNormalizationResult:
    """Normalize one point through the canonical bbox coordinate pipeline."""

    if len(point) != 2:
        return PdfCoordinatePointNormalizationResult(  # type: ignore[unreachable]
            None,
            PdfWarningCode.INVALID_BBOX,
        )
    normalized = normalize_bbox(
        bbox=(point[0], point[1], point[0], point[1]),
        original_width=original_width,
        original_height=original_height,
        page_rotation=page_rotation,
        source_space=source_space,
        source_origin_x=source_origin_x,
        source_origin_y=source_origin_y,
        user_unit=user_unit,
        source_applies_user_unit=source_applies_user_unit,
        tolerance=tolerance,
    )
    if normalized.bbox is None:
        return PdfCoordinatePointNormalizationResult(None, normalized.warning_code)
    return PdfCoordinatePointNormalizationResult(
        PdfPoint(x=normalized.bbox.x0, y=normalized.bbox.y0),
        None,
    )


def fact_bbox_dimension_warning(
    *,
    bbox: PdfBoundingBox,
    fact_kind: PdfBBoxFactKind,
    path_present: bool = False,
    tolerance: float = PDF_COORDINATE_TOLERANCE,
) -> PdfWarningCode | None:
    """Apply fact semantics after geometry-only coordinate normalization.

    A horizontal or vertical line has a valid one-dimensional bbox. Curves may
    also be flat when a parser independently confirms that path data exists.
    Text, rectangles, and image regions require a two-dimensional visual box.
    """

    if tolerance < 0 or not math.isfinite(tolerance):
        raise ValueError("tolerance must be finite and non-negative")
    width_zero = math.isclose(bbox.x0, bbox.x1, abs_tol=tolerance)
    height_zero = math.isclose(bbox.y0, bbox.y1, abs_tol=tolerance)
    if fact_kind == "line":
        invalid = width_zero and height_zero
    elif fact_kind == "curve":
        invalid = width_zero and height_zero and not path_present
    else:
        invalid = width_zero or height_zero
    return PdfWarningCode.ZERO_AREA_BBOX if invalid else None


def canonical_text_rotation(
    *,
    text_rotation: float,
    page_rotation: int,
    source: PdfTextRotationSource,
) -> float:
    """Return clockwise visual rotation where zero is left-to-right text."""

    if not math.isfinite(text_rotation):
        raise ValueError("text rotation must be finite")
    if page_rotation not in (0, 90, 180, 270):
        raise ValueError("page rotation must be 0, 90, 180, or 270")
    if source is PdfTextRotationSource.PDF_USER_SPACE_COUNTERCLOCKWISE:
        normalized = (page_rotation - text_rotation) % 360
    elif source is PdfTextRotationSource.VISUAL_SPACE_COUNTERCLOCKWISE:
        normalized = (-text_rotation) % 360
    elif source is PdfTextRotationSource.UNROTATED_VISUAL_CLOCKWISE:
        normalized = (page_rotation + text_rotation) % 360
    else:
        normalized = text_rotation % 360
    if math.isclose(normalized, 360, abs_tol=1e-5) or math.isclose(
        normalized,
        0,
        abs_tol=1e-5,
    ):
        return 0.0
    return normalized


def _rotate_top_left_point(
    *,
    x: float,
    y: float,
    width: float,
    height: float,
    rotation: int,
) -> tuple[float, float]:
    if rotation == 0:
        return x, y
    if rotation == 90:
        return height - y, x
    if rotation == 180:
        return width - x, height - y
    return y, width - x


def _ordered_page_box(
    value: tuple[float, float, float, float],
) -> tuple[float, float, float, float]:
    if len(value) != 4 or not all(math.isfinite(float(item)) for item in value):
        raise ValueError("page box must contain four finite coordinates")
    x0, y0, x1, y1 = (float(item) for item in value)
    ordered = (min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1))
    if ordered[0] >= ordered[2] or ordered[1] >= ordered[3]:
        raise ValueError("page box must have positive width and height")
    return ordered


def _scaled_page_box(
    value: tuple[float, float, float, float],
    scale: float,
) -> PdfPageBox:
    return PdfPageBox(
        x0=value[0] * scale,
        y0=value[1] * scale,
        x1=value[2] * scale,
        y1=value[3] * scale,
    )


def _boxes_close(
    first: tuple[float, float, float, float],
    second: tuple[float, float, float, float],
) -> bool:
    return all(
        math.isclose(left, right, abs_tol=PDF_COORDINATE_TOLERANCE)
        for left, right in zip(first, second, strict=True)
    )


def _validate_page_geometry(
    width: float,
    height: float,
    rotation: int,
) -> None:
    if (
        not math.isfinite(width)
        or not math.isfinite(height)
        or width <= 0
        or height <= 0
    ):
        raise ValueError("page dimensions must be finite and positive")
    if rotation not in (0, 90, 180, 270):
        raise ValueError("page rotation must be 0, 90, 180, or 270")

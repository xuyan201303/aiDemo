# ruff: noqa: C901, EM101, I001, PLR0912, PLR2004, SIM102, TRY003, UP040

from datetime import datetime
import hashlib
import json
import math
from typing import Literal, TypeAlias

from pydantic import (
    AwareDatetime,
    BaseModel,
    ConfigDict,
    Field,
    field_validator,
    model_validator,
    model_serializer,
    SerializerFunctionWrapHandler,
)

from document_sdk.pdf._structural_engine.facts.native_text_contracts import (
    PdfNativeTextEventEvidence,
)
from document_sdk.pdf._structural_engine.facts.capabilities import PdfParserCapabilities
from document_sdk.pdf._structural_engine.facts.limits import (
    PDF_EXTRACTION_SCOPE_SCHEMA_VERSION,
    PdfExtractionLimits,
    PdfExtractionOptions,
    PdfExtractionScopeMode,
    PdfResourceUsage,
)
from document_sdk.pdf._structural_engine.facts.status import (
    PdfExtractionStatus,
    PdfFactWarning,
    PdfWarningCode,
    PdfWarningSuppressionSummary,
)


PDF_FACTS_SCHEMA_VERSION = "pdf_facts.v2"
PDF_TEXT_MEMBER_METHOD_VERSION = "pdfplumber.member_pool.v2"
PDF_TEXT_MEMBER_LIGATURES = {
    "ﬀ": "ff",
    "ﬃ": "ffi",
    "ﬄ": "ffl",
    "ﬁ": "fi",
    "ﬂ": "fl",
    "ﬆ": "st",
    "ﬅ": "st",
}
PDF_DRAWING_PATH_GEOMETRY_VERSION = "pdf_drawing_path_geometry.v1"
PDF_EXTRACTION_SCOPE_RESULT_SCHEMA_VERSION = "pdf_extraction_scope_result.v1"
PdfMetadataScalar: TypeAlias = str | int | float | bool | None
PdfTextGranularity = Literal["character", "word", "text_span", "line_candidate"]
PdfWritingDirection = Literal[
    "left_to_right",
    "right_to_left",
    "top_to_bottom",
    "bottom_to_top",
    "unknown",
]
PdfDrawingKind = Literal["line", "rectangle", "curve"]
PdfDrawingPathSegmentKind = Literal[
    "move",
    "line",
    "cubic_bezier",
    "quadratic_or_unknown_curve",
    "close",
]
PdfPageBoxBasis = Literal[
    "media_box",
    "crop_box",
    "media_crop_intersection",
]
PdfParserCoordinateSpace = Literal[
    "pdf_user_space_absolute",
    "top_left_unrotated_absolute",
    "visual_top_left_absolute",
]
PdfGeometryCompleteness = Literal["complete", "partial", "assumed"]
PdfGeometryConfidence = Literal["high", "low"]
PdfScalarNativeSemantics = Literal[
    "nominal",
    "effective_visual",
    "effective_visual_aggregate",
    "unavailable",
]
PdfScalarNativeUnit = Literal[
    "pdf_user_space",
    "canonical_pdf_point",
    "unknown",
]
PdfScalarDerivation = Literal[
    "user_unit_normalized",
    "affine_derived",
    "parser_native_only",
    "unavailable",
]
PdfDrawingBBoxKind = Literal[
    "path_geometry",
    "parser_object_bounds",
    "painted_bounds",
    "unknown",
]
PdfDrawingBBoxQuality = Literal["precise", "approximate", "unknown"]
PdfStrokeInclusion = Literal["included", "excluded", "unknown"]
PdfClippingApplication = Literal["applied", "not_applied", "unknown"]
PdfPaintOperation = Literal[
    "stroke",
    "fill",
    "fill_stroke",
    "clip",
    "unknown",
]


class PdfAffineTransform(BaseModel):
    """Parser-source affine matrix using PDF's a/b/c/d/e/f convention."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    a: float
    b: float
    c: float
    d: float
    e: float
    f: float

    @model_validator(mode="after")
    def validate_finite(self) -> "PdfAffineTransform":
        if not all(
            math.isfinite(value)
            for value in (self.a, self.b, self.c, self.d, self.e, self.f)
        ):
            raise ValueError("affine transform values must be finite")
        return self


class PdfScalarProvenance(BaseModel):
    """Explains whether a canonical scalar is native, derived, or unavailable."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    parser_native_value: float | None = Field(default=None, ge=0)
    parser_native_semantics: PdfScalarNativeSemantics = "unavailable"
    parser_native_unit: PdfScalarNativeUnit = "unknown"
    canonical_derivation: PdfScalarDerivation = "unavailable"
    parser_applies_user_unit: bool = False
    affine_transform_available: bool = False
    source: str = Field(default="unavailable", min_length=1, max_length=64)

    @model_validator(mode="after")
    def validate_native_value(self) -> "PdfScalarProvenance":
        if self.parser_native_semantics == "unavailable":
            if self.parser_native_value is not None:
                raise ValueError("unavailable parser scalar cannot carry a value")
        elif self.parser_native_value is None:
            raise ValueError("available parser scalar requires a value")
        return self


class PdfDrawingBBoxSemantics(BaseModel):
    """Describes what a parser-provided drawing bbox actually bounds."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    kind: PdfDrawingBBoxKind = "unknown"
    quality: PdfDrawingBBoxQuality = "unknown"
    stroke_inclusion: PdfStrokeInclusion = "unknown"
    clipping_application: PdfClippingApplication = "unknown"


class PdfBoundingBox(BaseModel):
    """Canonical visual coordinates: top-left origin, y down, PDF points."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    x0: float
    y0: float
    x1: float
    y1: float

    @model_validator(mode="after")
    def validate_bounds(self) -> "PdfBoundingBox":
        values = (self.x0, self.y0, self.x1, self.y1)
        if not all(math.isfinite(value) for value in values):
            raise ValueError("bbox coordinates must be finite")
        if self.x0 > self.x1 or self.y0 > self.y1:
            raise ValueError("bbox coordinates must be ordered")
        return self


class PdfPoint(BaseModel):
    """A point in canonical visual PDF coordinates."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    x: float
    y: float

    @model_validator(mode="after")
    def validate_finite(self) -> "PdfPoint":
        if not math.isfinite(self.x) or not math.isfinite(self.y):
            raise ValueError("point coordinates must be finite")
        return self


class PdfDrawingPathSegment(BaseModel):
    """Bounded parser-neutral geometry for one drawing path segment."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    segment_index: int = Field(ge=0)
    subpath_index: int = Field(ge=0)
    kind: PdfDrawingPathSegmentKind
    start: PdfPoint
    end: PdfPoint
    control_points: list[PdfPoint] = Field(default_factory=list, max_length=2)
    closed: bool = False
    geometry_quality: PdfDrawingBBoxQuality = "unknown"
    source_order: int = Field(ge=0)
    warnings: list[PdfFactWarning] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_controls(self) -> "PdfDrawingPathSegment":
        if self.kind == "cubic_bezier" and len(self.control_points) != 2:
            raise ValueError("cubic path segments require two control points")
        if self.kind in {"move", "line", "close"} and self.control_points:
            raise ValueError("non-curve path segments cannot carry control points")
        return self


class PdfPageBox(BaseModel):
    """Unrotated PDF page box in canonical PDF points."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    x0: float
    y0: float
    x1: float
    y1: float

    @model_validator(mode="after")
    def validate_bounds(self) -> "PdfPageBox":
        values = (self.x0, self.y0, self.x1, self.y1)
        if not all(math.isfinite(value) for value in values):
            raise ValueError("page box coordinates must be finite")
        if self.x0 >= self.x1 or self.y0 >= self.y1:
            raise ValueError("page box must have positive width and height")
        return self

    @property
    def width(self) -> float:
        return self.x1 - self.x0

    @property
    def height(self) -> float:
        return self.y1 - self.y0


class PdfCoordinateTransformProvenance(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    parser_coordinate_space: PdfParserCoordinateSpace
    parser_page_box_basis: PdfPageBoxBasis
    parser_applies_page_rotation: bool
    parser_applies_user_unit: bool
    canonical_page_box_basis: PdfPageBoxBasis
    canonical_origin_translation_applied: bool
    canonical_page_rotation_applied: bool
    canonical_user_unit_applied: bool
    geometry_source: str = Field(min_length=1, max_length=64)
    geometry_completeness: PdfGeometryCompleteness = "complete"
    geometry_confidence: PdfGeometryConfidence = "high"
    assumed_origin: bool = False
    assumed_user_unit: bool = False
    fallback_provider: str | None = Field(default=None, min_length=1, max_length=64)


class PdfNormalizedBoundingBox(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    x0: float = Field(ge=0, le=1)
    y0: float = Field(ge=0, le=1)
    x1: float = Field(ge=0, le=1)
    y1: float = Field(ge=0, le=1)

    @model_validator(mode="after")
    def validate_bounds(self) -> "PdfNormalizedBoundingBox":
        if self.x0 > self.x1 or self.y0 > self.y1:
            raise ValueError("normalized bbox coordinates must be ordered")
        return self


class PdfFactConfidence(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    availability: Literal["available", "unavailable"] = "unavailable"
    value: float | None = Field(default=None, ge=0, le=1)

    @model_validator(mode="after")
    def validate_availability(self) -> "PdfFactConfidence":
        if (self.availability == "available") != (self.value is not None):
            raise ValueError("confidence value and availability must agree")
        return self


class PdfTextProjectionPart(BaseModel):
    """One explicit source-member or inserted-whitespace output interval."""

    model_config = ConfigDict(extra="forbid", frozen=True)
    member_id: str | None = Field(default=None, pattern=r"^PDFF-[0-9a-f]{24}$")
    output_start: int = Field(ge=0)
    output_end: int = Field(ge=0)
    transform: Literal[
        "IDENTITY", "LIGATURE_EXPANSION", "INSERTED_WHITESPACE", "OMITTED_WHITESPACE"
    ]

    @model_validator(mode="after")
    def validate_interval(self) -> "PdfTextProjectionPart":
        if self.output_start > self.output_end:
            raise ValueError("member projection interval is reversed")
        if (self.transform == "INSERTED_WHITESPACE") != (self.member_id is None):
            raise ValueError("source projection parts require an exact member")
        if (
            self.transform == "OMITTED_WHITESPACE"
            and self.output_start != self.output_end
        ):
            raise ValueError("omitted source whitespace cannot have output")
        return self


class PdfTextMember(BaseModel):
    """One bounded same-parser source occurrence, never a guessed glyph box."""

    model_config = ConfigDict(extra="forbid", frozen=True)
    member_id: str = Field(pattern=r"^PDFF-[0-9a-f]{24}$")
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    source_character_index: int = Field(ge=0)
    text: str = Field(min_length=1, max_length=1_000_000)
    parser_bbox: PdfBoundingBox | None = None
    bbox: PdfBoundingBox | None = None
    normalized_bbox: PdfNormalizedBoundingBox | None = None
    text_transform: PdfAffineTransform | None = None
    font_name: str | None = Field(default=None, max_length=256)
    parser_font_size: float | None = Field(default=None, ge=0)
    parser_advance: float | None = Field(default=None, ge=0, strict=True)
    source_writing_mode: Literal["HORIZONTAL", "VERTICAL", "UNKNOWN"] = "UNKNOWN"
    native_text_event_id: str | None = Field(
        default=None, pattern=r"^PDFTE-[0-9a-f]{64}$"
    )
    native_text_event_ordinal: int | None = Field(default=None, ge=0, strict=True)
    native_text_event_member_ordinal: int | None = Field(
        default=None, ge=0, strict=True
    )
    native_character_ordinal: int | None = Field(default=None, ge=0, strict=True)
    rotation: float | None = Field(default=None, ge=0, lt=360)
    geometry_status: Literal["INSIDE", "INTERSECTS", "OUTSIDE", "ZERO_AREA", "INVALID"]
    geometry_semantics: Literal["pdfminer_character_extent_not_ink"] = (
        "pdfminer_character_extent_not_ink"
    )
    selection_state: Literal["RETAINED", "DEDUPE_SUPPRESSED", "GEOMETRY_REJECTED"]
    duplicate_of_member_id: str | None = Field(
        default=None, pattern=r"^PDFF-[0-9a-f]{24}$"
    )
    warnings: list[PdfFactWarning] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_geometry(self) -> "PdfTextMember":
        if (self.geometry_status == "INVALID") != (self.bbox is None):
            raise ValueError("member geometry availability is inconsistent")
        if self.geometry_status in {"INSIDE", "ZERO_AREA"}:
            if self.normalized_bbox is None:
                raise ValueError("admitted member geometry requires normalized bounds")
        elif self.normalized_bbox is not None:
            raise ValueError("outside member cannot claim admitted normalized bounds")
        if (
            self.duplicate_of_member_id is not None
            and self.selection_state != "DEDUPE_SUPPRESSED"
        ):
            raise ValueError(
                "only a dedupe-suppressed member can link its representative"
            )
        if self.duplicate_of_member_id == self.member_id:
            raise ValueError("member cannot duplicate itself")
        admitted = self.geometry_status in {"INSIDE", "ZERO_AREA"}
        if self.selection_state == "RETAINED" and not admitted:
            raise ValueError("retained source member must have admitted geometry")
        if self.selection_state == "GEOMETRY_REJECTED" and admitted:
            raise ValueError("rejected source member cannot claim admitted geometry")
        native_refs = (
            self.native_text_event_ordinal,
            self.native_text_event_member_ordinal,
            self.native_character_ordinal,
        )
        if self.native_text_event_id is None:
            if (
                any(value is not None for value in native_refs)
                or self.source_writing_mode != "UNKNOWN"
            ):
                raise ValueError(
                    "native direction or ordinals require an observed event identity"
                )
        elif any(value is None for value in native_refs):
            raise ValueError("captured native member needs every execution ordinal")
        if self.parser_advance is not None and not math.isfinite(self.parser_advance):
            raise ValueError("native character advance must be finite")
        if self.parser_font_size is not None and not math.isfinite(
            self.parser_font_size
        ):
            raise ValueError("member font size must be finite")
        if self.rotation is not None and not math.isfinite(self.rotation):
            raise ValueError("member rotation must be finite")
        if any(0xD800 <= ord(char) <= 0xDFFF for char in self.text):
            raise ValueError("member text cannot contain unpaired Unicode surrogates")
        return self


class PdfTextFact(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    fact_id: str = Field(pattern=r"^PDFF-[0-9a-f]{24}$")
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    granularity: PdfTextGranularity
    member_ids: tuple[str, ...] = ()
    source_member_count: int = Field(default=0, ge=0)
    source_group_id: str | None = Field(default=None, pattern=r"^PDFTG-[0-9a-f]{64}$")
    member_inventory_status: Literal["COMPLETE", "PARTIAL", "NOT_CAPTURED"] = (
        "NOT_CAPTURED"
    )
    member_projection_status: Literal[
        "EXACT", "TRANSFORMED", "UNRESOLVED", "NOT_CAPTURED"
    ] = "NOT_CAPTURED"
    member_projection: tuple[PdfTextProjectionPart, ...] = ()
    text: str = Field(min_length=1, max_length=1_000_000)
    bbox: PdfBoundingBox
    normalized_bbox: PdfNormalizedBoundingBox
    source_order: int = Field(ge=0)
    font_name: str | None = Field(default=None, max_length=256)
    font_size: float | None = Field(
        default=None,
        ge=0,
        description=(
            "Nominal text-state size in canonical PDF points, with UserUnit "
            "applied exactly once and affine visual scaling excluded."
        ),
    )
    effective_font_scale_x: float | None = Field(default=None, ge=0)
    effective_font_scale_y: float | None = Field(default=None, ge=0)
    effective_font_size_x: float | None = Field(default=None, ge=0)
    effective_font_size_y: float | None = Field(default=None, ge=0)
    text_transform: PdfAffineTransform | None = None
    font_size_provenance: PdfScalarProvenance = Field(
        default_factory=PdfScalarProvenance
    )
    rotation: float | None = Field(default=None, ge=0, lt=360)
    writing_direction: PdfWritingDirection = "unknown"
    parser_metadata: dict[str, PdfMetadataScalar] = Field(default_factory=dict)
    warnings: list[PdfFactWarning] = Field(default_factory=list)
    confidence: PdfFactConfidence = Field(default_factory=PdfFactConfidence)

    @model_validator(mode="after")
    def validate_member_inventory(self) -> "PdfTextFact":
        _validate_text_membership(self)
        return self

    @model_validator(mode="after")
    def validate_effective_font_size(self) -> "PdfTextFact":
        if (self.effective_font_scale_x is None) != (
            self.effective_font_scale_y is None
        ):
            raise ValueError("effective font-scale x/y values must be paired")
        if (self.effective_font_size_x is None) != (self.effective_font_size_y is None):
            raise ValueError("effective font-size x/y values must be paired")
        if self.effective_font_size_x is not None and self.font_size is None:
            raise ValueError("effective font size requires a nominal font size")
        return self

    @field_validator("parser_metadata")
    @classmethod
    def bound_parser_metadata(
        cls,
        value: dict[str, PdfMetadataScalar],
    ) -> dict[str, PdfMetadataScalar]:
        if len(value) > 32:
            raise ValueError("parser metadata has too many entries")
        if any(len(key) > 64 for key in value):
            raise ValueError("parser metadata key is too long")
        if any(isinstance(item, str) and len(item) > 256 for item in value.values()):
            raise ValueError("parser metadata value is too long")
        return value


class PdfTextSourceGroup(BaseModel):
    """One bounded parser grouping, including groups rejected before Fact admission."""

    model_config = ConfigDict(extra="forbid", frozen=True)
    source_group_id: str = Field(pattern=r"^PDFTG-[0-9a-f]{64}$")
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    granularity: PdfTextGranularity
    source_group_order: int = Field(ge=0)
    parent_fact_id: str | None = Field(default=None, pattern=r"^PDFF-[0-9a-f]{24}$")
    derived_from_source_group_id: str | None = Field(
        default=None, pattern=r"^PDFTG-[0-9a-f]{64}$"
    )
    text: str = Field(min_length=1, max_length=1_000_000)
    parser_bbox: PdfBoundingBox | None
    bbox: PdfBoundingBox | None
    geometry_status: Literal["INSIDE", "INTERSECTS", "OUTSIDE", "ZERO_AREA", "INVALID"]
    disposition: Literal[
        "ADMITTED",
        "GEOMETRY_REJECTED",
        "FACT_LIMIT_REJECTED",
        "SEGMENTATION_SUPERSEDED",
    ]
    member_ids: tuple[str, ...]
    source_member_count: int = Field(ge=0)
    member_inventory_status: Literal["COMPLETE", "PARTIAL", "NOT_CAPTURED"]
    member_projection_status: Literal[
        "EXACT", "TRANSFORMED", "UNRESOLVED", "NOT_CAPTURED"
    ]
    member_projection: tuple[PdfTextProjectionPart, ...]

    @model_validator(mode="after")
    def validate_group(self) -> "PdfTextSourceGroup":
        _validate_text_membership(self)
        if (self.disposition == "ADMITTED") != (self.parent_fact_id is not None):
            raise ValueError("group disposition must agree with actual Fact admission")
        if (self.geometry_status == "INVALID") != (self.bbox is None):
            raise ValueError("group geometry availability is inconsistent")
        if self.derived_from_source_group_id == self.source_group_id:
            raise ValueError("source group cannot derive from itself")
        return self


def _validate_text_membership(value: "PdfTextFact | PdfTextSourceGroup") -> None:
    if len(value.member_ids) != len(set(value.member_ids)):
        raise ValueError("a source occurrence cannot repeat within one text Fact")
    if len(value.member_ids) > value.source_member_count:
        raise ValueError("retained members exceed source member count")
    if (
        value.member_inventory_status == "COMPLETE"
        and len(value.member_ids) != value.source_member_count
    ):
        raise ValueError(
            "complete member inventory must account for every source member"
        )
    if value.member_inventory_status == "NOT_CAPTURED":
        if (
            value.member_ids
            or value.source_group_id
            or value.member_projection
            or value.source_member_count
        ):
            raise ValueError("uncaptured member evidence cannot carry references")
        if value.member_projection_status != "NOT_CAPTURED":
            raise ValueError("uncaptured inventory cannot claim projected members")
    elif value.source_group_id is None:
        raise ValueError("captured member inventory requires a source group identity")
    if value.member_projection_status in {"EXACT", "TRANSFORMED"}:
        if value.member_inventory_status != "COMPLETE":
            raise ValueError("complete projection requires complete source membership")
        part_ids = tuple(
            part.member_id
            for part in value.member_projection
            if part.member_id is not None
        )
        if part_ids != value.member_ids:
            raise ValueError(
                "projection must account for ordered source members exactly once"
            )
        cursor = 0
        for part in value.member_projection:
            if part.output_start != cursor or part.output_end > len(value.text):
                raise ValueError("projection must cover output text contiguously")
            cursor = part.output_end
        if cursor != len(value.text):
            raise ValueError("projection does not cover the complete text")
        exact = all(part.transform == "IDENTITY" for part in value.member_projection)
        if (value.member_projection_status == "EXACT") != exact:
            raise ValueError("exact member projection cannot hide a transform")
    elif value.member_projection:
        raise ValueError("unresolved projection cannot expose a proven mapping")


def _validate_source_projection(
    fact: "PdfTextFact | PdfTextSourceGroup", members: dict[str, PdfTextMember]
) -> None:
    if fact.member_projection_status not in {"EXACT", "TRANSFORMED"}:
        return
    for part in fact.member_projection:
        value = fact.text[part.output_start : part.output_end]
        if part.transform == "INSERTED_WHITESPACE":
            if not value or not value.isspace():
                raise ValueError("inserted projection must be explicit whitespace")
            continue
        if part.member_id is None:
            raise ValueError("source projection member identity is missing")
        source = members[part.member_id].text
        if part.transform == "IDENTITY" and value != source:
            raise ValueError("member projection changed source text")
        if (
            part.transform == "LIGATURE_EXPANSION"
            and PDF_TEXT_MEMBER_LIGATURES.get(source) != value
        ):
            raise ValueError("member ligature projection is not the declared transform")
        if part.transform == "OMITTED_WHITESPACE" and (value or not source.isspace()):
            raise ValueError("omitted projection must be source whitespace")


class PdfDrawingFact(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    fact_id: str = Field(pattern=r"^PDFF-[0-9a-f]{24}$")
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    kind: PdfDrawingKind
    bbox: PdfBoundingBox
    normalized_bbox: PdfNormalizedBoundingBox
    stroke_width: float | None = Field(
        default=None,
        ge=0,
        description=(
            "Nominal graphics-state line width in canonical PDF points, with "
            "UserUnit applied exactly once and affine visual scaling excluded."
        ),
    )
    effective_stroke_scale_x: float | None = Field(default=None, ge=0)
    effective_stroke_scale_y: float | None = Field(default=None, ge=0)
    effective_stroke_width_x: float | None = Field(default=None, ge=0)
    effective_stroke_width_y: float | None = Field(default=None, ge=0)
    graphics_transform: PdfAffineTransform | None = None
    stroke_width_provenance: PdfScalarProvenance = Field(
        default_factory=PdfScalarProvenance
    )
    bbox_semantics: PdfDrawingBBoxSemantics = Field(
        default_factory=PdfDrawingBBoxSemantics
    )
    paint_operation: PdfPaintOperation = "unknown"
    is_clipping_path: bool = False
    path_geometry_version: str | None = Field(
        default=None,
        pattern=r"^pdf_drawing_path_geometry\.v[0-9]+$",
    )
    path_segments: list[PdfDrawingPathSegment] = Field(default_factory=list)
    path_segment_count: int = Field(default=0, ge=0)
    path_segment_count_is_lower_bound: bool = False
    path_segment_truncated: bool = False
    path_closed: bool | None = None
    path_geometry_complete: bool = False
    rotation: float | None = Field(default=None, ge=0, lt=360)
    source_order: int = Field(ge=0)
    parser_metadata: dict[str, PdfMetadataScalar] = Field(default_factory=dict)
    warnings: list[PdfFactWarning] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_effective_stroke_width(self) -> "PdfDrawingFact":
        if (self.effective_stroke_scale_x is None) != (
            self.effective_stroke_scale_y is None
        ):
            raise ValueError("effective stroke-scale x/y values must be paired")
        if (self.effective_stroke_width_x is None) != (
            self.effective_stroke_width_y is None
        ):
            raise ValueError("effective stroke-width x/y values must be paired")
        if self.effective_stroke_width_x is not None and self.stroke_width is None:
            raise ValueError("effective stroke width requires a nominal stroke width")
        indexes = [segment.segment_index for segment in self.path_segments]
        if indexes != sorted(indexes) or len(indexes) != len(set(indexes)):
            raise ValueError("path segment indexes must be unique and ordered")
        if len(self.path_segments) > self.path_segment_count:
            raise ValueError("retained path segments cannot exceed the source count")
        if (
            self.path_segment_truncated
            and len(self.path_segments) >= self.path_segment_count
        ):
            raise ValueError("truncated path geometry requires omitted source segments")
        if self.path_segment_count_is_lower_bound and not self.path_segment_truncated:
            raise ValueError("a lower-bound path count requires truncated geometry")
        if self.path_geometry_complete:
            if self.path_geometry_version is None:
                raise ValueError("complete path geometry requires a contract version")
            if self.path_segment_truncated:
                raise ValueError("complete path geometry cannot be truncated")
            if len(self.path_segments) != self.path_segment_count:
                raise ValueError("complete path geometry requires every source segment")
        if self.path_segments and self.path_geometry_version is None:
            raise ValueError("path segments require a path geometry contract version")
        return self


class PdfImageRegionFact(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    fact_id: str = Field(pattern=r"^PDFF-[0-9a-f]{24}$")
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    bbox: PdfBoundingBox
    normalized_bbox: PdfNormalizedBoundingBox
    pixel_width: int | None = Field(default=None, ge=1)
    pixel_height: int | None = Field(default=None, ge=1)
    image_type: str | None = Field(default=None, max_length=64)
    parser_available: bool
    source_order: int = Field(ge=0)
    warnings: list[PdfFactWarning] = Field(default_factory=list)


class PdfPageFacts(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    page_number: int = Field(ge=1)
    media_box: PdfPageBox
    crop_box: PdfPageBox
    effective_page_box: PdfPageBox
    effective_page_box_basis: PdfPageBoxBasis
    effective_origin_x: float
    effective_origin_y: float
    user_unit: float = Field(ge=1, le=75_000)
    coordinate_transform: PdfCoordinateTransformProvenance
    original_width: float = Field(gt=0)
    original_height: float = Field(gt=0)
    rotation: Literal[0, 90, 180, 270]
    canonical_width: float = Field(gt=0)
    canonical_height: float = Field(gt=0)
    text_spans: list[PdfTextFact] = Field(default_factory=list)
    words: list[PdfTextFact] = Field(default_factory=list)
    line_candidates: list[PdfTextFact] = Field(default_factory=list)
    characters: list[PdfTextFact] = Field(default_factory=list)
    text_members: list[PdfTextMember] = Field(default_factory=list)
    native_text_event_evidence: PdfNativeTextEventEvidence | None = None
    native_text_event_capture_status: Literal["NOT_CAPTURED", "COMPLETE", "PARTIAL"] = (
        "NOT_CAPTURED"
    )
    native_text_event_serialized_bytes: int = Field(default=0, ge=0)
    text_source_groups: list[PdfTextSourceGroup] = Field(default_factory=list)
    text_source_group_count: int = Field(default=0, ge=0)
    source_text_group_count: int = Field(default=0, ge=0)
    text_source_group_truncated: bool = False
    text_source_group_serialized_bytes: int = Field(default=0, ge=0)
    text_member_method_version: str = Field(
        default="unavailable", min_length=1, max_length=64
    )
    text_member_inventory_status: Literal[
        "COMPLETE", "TRUNCATED", "NOT_REQUESTED", "UNSUPPORTED"
    ] = "NOT_REQUESTED"
    text_member_count: int = Field(default=0, ge=0)
    source_text_member_count: int = Field(default=0, ge=0)
    text_member_serialized_bytes: int = Field(default=0, ge=0)
    text_member_reference_bytes: int = Field(default=0, ge=0)
    drawings: list[PdfDrawingFact] = Field(default_factory=list)
    image_regions: list[PdfImageRegionFact] = Field(default_factory=list)
    text_span_count: int = Field(ge=0)
    word_count: int = Field(ge=0)
    line_candidate_count: int = Field(ge=0)
    character_count: int = Field(ge=0)
    drawing_count: int = Field(ge=0)
    image_region_count: int = Field(ge=0)
    warnings: list[PdfFactWarning] = Field(default_factory=list)
    extraction_status: PdfExtractionStatus

    @model_validator(mode="after")
    def validate_text_members(self) -> "PdfPageFacts":
        if self.text_member_inventory_status in {"NOT_REQUESTED", "UNSUPPORTED"}:
            if (
                self.text_members
                or self.text_source_groups
                or self.text_source_group_serialized_bytes
                or self.text_member_count
                or self.source_text_member_count
                or self.text_member_serialized_bytes
                or self.text_member_reference_bytes
                or self.text_member_method_version != "unavailable"
            ):
                raise ValueError(
                    "unavailable member pool cannot carry captured evidence"
                )
        elif self.text_member_method_version == "unavailable":
            raise ValueError("captured member pool requires a method identity")
        members = {member.member_id: member for member in self.text_members}
        if (
            len(members) != len(self.text_members)
            or len(members) != self.text_member_count
        ):
            raise ValueError("member IDs and retained count must be unique and exact")
        indices = [member.source_character_index for member in self.text_members]
        if indices != sorted(set(indices)):
            raise ValueError("source character occurrences must be ordered and unique")
        if self.source_text_member_count < self.text_member_count:
            raise ValueError("source member count cannot be smaller than retention")
        if any(index >= self.source_text_member_count for index in indices):
            raise ValueError("native member ordinal exceeds the observed source count")
        if self.text_member_inventory_status == "COMPLETE" and indices != list(
            range(self.source_text_member_count)
        ):
            raise ValueError(
                "complete native inventory must retain every source ordinal"
            )
        if (
            self.text_member_inventory_status == "COMPLETE"
            and self.source_text_member_count != self.text_member_count
        ):
            raise ValueError(
                "complete pool must retain all original source occurrences"
            )
        if any(member.page_id != self.page_id for member in self.text_members):
            raise ValueError("member cannot cross source pages")
        for member in self.text_members:
            if (
                self.text_member_inventory_status == "COMPLETE"
                and member.selection_state == "DEDUPE_SUPPRESSED"
                and member.duplicate_of_member_id is None
            ):
                raise ValueError(
                    "complete inventory requires each dedupe representative"
                )
            if member.duplicate_of_member_id is not None:
                representative = members.get(member.duplicate_of_member_id)
                if (
                    representative is not None
                    and representative.selection_state == "DEDUPE_SUPPRESSED"
                ):
                    raise ValueError(
                        "dedupe representative cannot itself be suppressed"
                    )
            if (
                member.duplicate_of_member_id is not None
                and member.duplicate_of_member_id not in members
            ):
                raise ValueError(
                    "dedupe representative must be retained in the same pool"
                )
            if member.geometry_status in {"INSIDE", "ZERO_AREA"}:
                box = member.bbox
                normalized = member.normalized_bbox
                if box is None or normalized is None:
                    raise ValueError("admitted member geometry is missing")
                if (
                    box.x0 < -1e-6
                    or box.y0 < -1e-6
                    or box.x1 > self.canonical_width + 1e-6
                    or box.y1 > self.canonical_height + 1e-6
                ):
                    raise ValueError("admitted member exceeds the page")
                expected = (
                    box.x0 / self.canonical_width,
                    box.y0 / self.canonical_height,
                    box.x1 / self.canonical_width,
                    box.y1 / self.canonical_height,
                )
                observed = (normalized.x0, normalized.y0, normalized.x1, normalized.y1)
                if any(
                    not math.isclose(a, b, abs_tol=1e-6)
                    for a, b in zip(expected, observed, strict=True)
                ):
                    raise ValueError("member normalized geometry is inconsistent")
        self._validate_native_events(members)
        self._validate_member_references(members)
        self._validate_source_groups(members)
        return self

    def _validate_native_events(self, members: dict[str, PdfTextMember]) -> None:
        evidence = self.native_text_event_evidence
        if evidence is None:
            if (
                self.native_text_event_serialized_bytes
                or self.native_text_event_capture_status == "COMPLETE"
            ):
                raise ValueError(
                    "absent native event evidence cannot be complete or charged"
                )
            if any(
                member.native_text_event_id is not None for member in members.values()
            ):
                raise ValueError("native member reference has no captured event pool")
            return
        expected_bytes = evidence.wire_size()
        if (
            self.native_text_event_serialized_bytes != expected_bytes
            or self.native_text_event_capture_status != evidence.availability
        ):
            raise ValueError("native event status or byte accounting is inconsistent")
        events = {event.source_event_id: event for event in evidence.events}
        native_ordinals: set[int] = set()
        event_ordinals: set[tuple[str, int]] = set()
        event_counts: dict[str, int] = {}
        event_member_ordinals: dict[str, set[int]] = {}
        for member in members.values():
            event_id = member.native_text_event_id
            if event_id is None:
                continue
            event = events.get(event_id)
            ordinal = member.native_text_event_member_ordinal
            native_ordinal = member.native_character_ordinal
            if (
                event is None
                or ordinal is None
                or native_ordinal is None
                or member.native_text_event_ordinal != event.native_event_ordinal
                or ordinal >= event.source_member_count
                or native_ordinal >= evidence.source_member_count
            ):
                raise ValueError(
                    "member native event identity or ordinal is inconsistent"
                )
            if (
                native_ordinal in native_ordinals
                or (event_id, ordinal) in event_ordinals
            ):
                raise ValueError(
                    "native occurrence cannot be bound to multiple pool members"
                )
            native_ordinals.add(native_ordinal)
            event_ordinals.add((event_id, ordinal))
            event_counts[event_id] = event_counts.get(event_id, 0) + 1
            event_member_ordinals.setdefault(event_id, set()).add(ordinal)
        if any(
            count > events[event_id].retained_member_count
            for event_id, count in event_counts.items()
        ):
            raise ValueError(
                "pool references exceed native event retained observations"
            )
        if (
            evidence.availability == "COMPLETE"
            and self.text_member_inventory_status == "COMPLETE"
        ):
            if (
                evidence.source_member_count != self.source_text_member_count
                or evidence.retained_member_count != len(members)
                or len(native_ordinals) != len(members)
                or any(
                    member.native_text_event_id is None for member in members.values()
                )
            ):
                raise ValueError(
                    "complete native event evidence must bind every retained "
                    "source member"
                )
            ordered_members = sorted(
                members.values(), key=lambda member: member.source_character_index
            )
            if [member.native_character_ordinal for member in ordered_members] != list(
                range(evidence.source_member_count)
            ):
                raise ValueError(
                    "complete native member order must match source occurrence order"
                )
            for event_id, event in events.items():
                expected_ordinals = set(range(event.retained_member_count))
                if event_member_ordinals.get(event_id, set()) != expected_ordinals:
                    raise ValueError(
                        "complete native event must bind every retained event member"
                    )
                event_members = [
                    member
                    for member in ordered_members
                    if member.native_text_event_id == event_id
                ]
                if [
                    member.native_text_event_member_ordinal for member in event_members
                ] != list(range(event.retained_member_count)):
                    raise ValueError(
                        "complete native event member order must match source "
                        "occurrence order"
                    )

    def _validate_source_groups(self, members: dict[str, PdfTextMember]) -> None:
        groups = {group.source_group_id: group for group in self.text_source_groups}
        if (
            len(groups) != len(self.text_source_groups)
            or len(groups) != self.text_source_group_count
        ):
            raise ValueError("source group identity and count must be unique and exact")
        if self.source_text_group_count < self.text_source_group_count:
            raise ValueError("retained groups exceed observed groups")
        if (
            not self.text_source_group_truncated
            and self.source_text_group_count != self.text_source_group_count
        ):
            raise ValueError("untruncated source groups require complete retention")
        expected_bytes = (
            (
                2
                + max(0, len(groups) - 1)
                + sum(
                    len(
                        json.dumps(
                            group.model_dump(mode="json"),
                            ensure_ascii=False,
                            allow_nan=False,
                            sort_keys=True,
                            separators=(",", ":"),
                        ).encode("utf-8")
                    )
                    for group in self.text_source_groups
                )
            )
            if self.text_member_inventory_status in {"COMPLETE", "TRUNCATED"}
            else 0
        )
        if self.text_source_group_serialized_bytes != expected_bytes:
            raise ValueError("source group serialized bytes must be exact")
        facts = {
            fact.fact_id: fact
            for fact in (
                *self.words,
                *self.text_spans,
                *self.line_candidates,
                *self.characters,
            )
        }
        order = [group.source_group_order for group in self.text_source_groups]
        if order != sorted(set(order)):
            raise ValueError("source group orders must be ordered and unique")
        parent_indexes: dict[
            str, tuple[dict[str, int], dict[str, PdfTextProjectionPart]]
        ] = {}
        for group in self.text_source_groups:
            if group.source_member_count > self.source_text_member_count:
                raise ValueError(
                    "group member count exceeds the independent page source inventory"
                )
            if group.page_id != self.page_id or any(
                item not in members for item in group.member_ids
            ):
                raise ValueError("source group has a foreign page or dangling member")
            if group.parent_fact_id is not None:
                fact = facts.get(group.parent_fact_id)
                if fact is None or (
                    fact.source_group_id,
                    fact.text,
                    fact.member_ids,
                    fact.member_projection,
                    fact.source_member_count,
                    fact.member_inventory_status,
                    fact.member_projection_status,
                    fact.granularity,
                    fact.bbox,
                ) != (
                    group.source_group_id,
                    group.text,
                    group.member_ids,
                    group.member_projection,
                    group.source_member_count,
                    group.member_inventory_status,
                    group.member_projection_status,
                    group.granularity,
                    group.bbox,
                ):
                    raise ValueError("admitted source group must bind its actual Fact")
            origin = group.derived_from_source_group_id
            parent: PdfTextSourceGroup | None = None
            if origin is not None:
                parent = groups.get(origin)
                if parent is None or parent.disposition != "GEOMETRY_REJECTED":
                    raise ValueError(
                        "derived group must bind a rejected source group subset"
                    )
            if parent is not None:
                self._validate_derived_source_group(group, parent, parent_indexes)
            _validate_source_projection(group, members)
        for fact in facts.values():
            if fact.member_inventory_status == "NOT_CAPTURED":
                continue
            source_group = groups.get(fact.source_group_id or "")
            if source_group is None or source_group.parent_fact_id != fact.fact_id:
                raise ValueError(
                    "captured Fact must bind its unique admitted source group"
                )

    @staticmethod
    def _validate_derived_source_group(
        group: PdfTextSourceGroup,
        parent: PdfTextSourceGroup,
        parent_indexes: dict[
            str, tuple[dict[str, int], dict[str, PdfTextProjectionPart]]
        ],
    ) -> None:
        # One index per original grouping keeps validation linear in the
        # retained parent/child references, including many recovered runs.
        indexed = parent_indexes.get(parent.source_group_id)
        if indexed is None:
            positions: dict[str, int] = {}
            for index, identity in enumerate(parent.member_ids):
                positions.setdefault(identity, index)
            parts = {
                part.member_id: part
                for part in parent.member_projection
                if part.member_id is not None
            }
            indexed = positions, parts
            parent_indexes[parent.source_group_id] = indexed
        positions, parts = indexed
        if not set(group.member_ids).issubset(positions):
            raise ValueError("derived group must bind a rejected source group subset")
        if parent.source_group_order >= group.source_group_order:
            raise ValueError(
                "derived source group cannot precede its original grouping"
            )
        indices = [positions[identity] for identity in group.member_ids]
        if not indices or indices != list(range(indices[0], indices[-1] + 1)):
            raise ValueError(
                "derived source group must preserve a contiguous original run"
            )
        if parent.member_projection_status not in {
            "EXACT",
            "TRANSFORMED",
        } or any(identity not in parts for identity in group.member_ids):
            raise ValueError(
                "derived source group requires a proven original projection"
            )
        start = parts[group.member_ids[0]].output_start
        end = parts[group.member_ids[-1]].output_end
        if parent.text[start:end] != group.text:
            raise ValueError(
                "derived source group text differs from its original projection"
            )

    def _validate_member_references(self, members: dict[str, PdfTextMember]) -> None:
        all_text = (
            *self.text_spans,
            *self.words,
            *self.line_candidates,
            *self.characters,
        )
        if set(members).intersection(fact.fact_id for fact in all_text):
            raise ValueError("member and aggregate Fact identities must not alias")
        if self.text_member_inventory_status in {"COMPLETE", "TRUNCATED"}:

            def encoded_size(value: object) -> int:
                return len(
                    json.dumps(
                        value,
                        ensure_ascii=False,
                        allow_nan=False,
                        sort_keys=True,
                        separators=(",", ":"),
                    ).encode("utf-8")
                )

            expected_bytes = (
                2
                + max(0, len(self.text_members) - 1)
                + sum(
                    encoded_size(member.model_dump(mode="json"))
                    for member in self.text_members
                )
            )
            if self.text_member_serialized_bytes != expected_bytes:
                raise ValueError("member serialized-byte counter is not exact")
            reference_fields = {
                "member_ids",
                "source_member_count",
                "source_group_id",
                "member_inventory_status",
                "member_projection_status",
                "member_projection",
            }
            expected_reference_bytes = sum(
                encoded_size(fact.model_dump(mode="json", include=reference_fields))
                for fact in all_text
                if fact.member_inventory_status != "NOT_CAPTURED"
            )
            if self.text_member_reference_bytes != expected_reference_bytes:
                raise ValueError("member reference-byte counter is not exact")
        for fact in all_text:
            if any(member_id not in members for member_id in fact.member_ids):
                raise ValueError("text Fact has a dangling member reference")
            if fact.member_projection_status not in {"EXACT", "TRANSFORMED"}:
                continue
            _validate_source_projection(fact, members)

    @model_validator(mode="after")
    def validate_fact_integrity(self) -> "PdfPageFacts":
        tolerance = 1e-6
        if not math.isclose(
            self.effective_origin_x,
            self.effective_page_box.x0,
            abs_tol=tolerance,
        ) or not math.isclose(
            self.effective_origin_y,
            self.effective_page_box.y0,
            abs_tol=tolerance,
        ):
            raise ValueError("effective origin must match the effective page box")
        if not math.isclose(
            self.original_width,
            self.effective_page_box.width,
            abs_tol=tolerance,
        ) or not math.isclose(
            self.original_height,
            self.effective_page_box.height,
            abs_tol=tolerance,
        ):
            raise ValueError("original dimensions must match the effective page box")
        for page_box in (self.media_box, self.crop_box):
            if (
                self.effective_page_box.x0 < page_box.x0 - tolerance
                or self.effective_page_box.y0 < page_box.y0 - tolerance
                or self.effective_page_box.x1 > page_box.x1 + tolerance
                or self.effective_page_box.y1 > page_box.y1 + tolerance
            ):
                raise ValueError(
                    "effective page box must be within media and crop boxes"
                )
        expected_width, expected_height = (
            (self.original_height, self.original_width)
            if self.rotation in (90, 270)
            else (self.original_width, self.original_height)
        )
        if not math.isclose(
            self.canonical_width,
            expected_width,
            abs_tol=1e-6,
        ) or not math.isclose(
            self.canonical_height,
            expected_height,
            abs_tol=1e-6,
        ):
            raise ValueError("canonical page dimensions must reflect page rotation")
        counted = (
            (self.text_span_count, self.text_spans),
            (self.word_count, self.words),
            (self.line_candidate_count, self.line_candidates),
            (self.character_count, self.characters),
            (self.drawing_count, self.drawings),
            (self.image_region_count, self.image_regions),
        )
        if any(count != len(items) for count, items in counted):
            raise ValueError("page fact counts must match fact arrays")

        facts = [item for _count, items in counted for item in items]
        if any(item.page_id != self.page_id for item in facts):
            raise ValueError("page facts must reference their containing page")
        fact_ids = [item.fact_id for item in facts]
        if len(fact_ids) != len(set(fact_ids)):
            raise ValueError("page fact IDs must be unique")
        for item in facts:
            if (
                item.bbox.x0 < -tolerance
                or item.bbox.y0 < -tolerance
                or item.bbox.x1 > self.canonical_width + tolerance
                or item.bbox.y1 > self.canonical_height + tolerance
            ):
                raise ValueError("fact bbox must be within canonical page bounds")
            expected_normalized = (
                item.bbox.x0 / self.canonical_width,
                item.bbox.y0 / self.canonical_height,
                item.bbox.x1 / self.canonical_width,
                item.bbox.y1 / self.canonical_height,
            )
            actual_normalized = (
                item.normalized_bbox.x0,
                item.normalized_bbox.y0,
                item.normalized_bbox.x1,
                item.normalized_bbox.y1,
            )
            if any(
                not math.isclose(actual, expected, abs_tol=1e-6)
                for actual, expected in zip(
                    actual_normalized,
                    expected_normalized,
                    strict=True,
                )
            ):
                raise ValueError("normalized bbox must match canonical page geometry")
        return self


class PdfExtractionScopeResult(BaseModel):
    """Bounded, parser-neutral inventory for the requested extraction scope.

    Full-document requests use an implicit requested inventory, represented by
    an empty `requested_page_numbers` tuple plus `requested_page_count`.
    Selected-page requests retain their bounded canonical inventory explicitly.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    schema_version: Literal["pdf_extraction_scope_result.v1"] = (
        PDF_EXTRACTION_SCOPE_RESULT_SCHEMA_VERSION  # type: ignore[assignment]
    )
    request_schema_version: Literal["pdf_extraction_scope.v1"] = (
        PDF_EXTRACTION_SCOPE_SCHEMA_VERSION  # type: ignore[assignment]
    )
    mode: PdfExtractionScopeMode
    source_document_page_count: int = Field(ge=0)
    requested_page_numbers: tuple[int, ...] = ()
    requested_page_count: int = Field(ge=0)
    extracted_requested_page_numbers: tuple[int, ...] = ()
    extracted_requested_page_count: int = Field(ge=0)
    missing_requested_page_numbers: tuple[int, ...] = ()
    missing_requested_page_count: int = Field(ge=0)
    incomplete_requested_page_numbers: tuple[int, ...] = ()
    incomplete_requested_page_count: int = Field(ge=0)
    requested_scope_complete: bool
    scope_evaluation_available: bool = True
    source_document_fully_extracted: bool
    scope_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    selected_page_limit_applied: bool = False
    scope_truncated: bool = False
    scope_warning_codes: tuple[PdfWarningCode, ...] = ()

    @model_validator(mode="after")
    def validate_inventory(self) -> "PdfExtractionScopeResult":
        inventories = (
            self.requested_page_numbers,
            self.extracted_requested_page_numbers,
            self.missing_requested_page_numbers,
            self.incomplete_requested_page_numbers,
        )
        if any(tuple(sorted(set(items))) != items for items in inventories):
            raise ValueError("scope page inventories must be sorted and unique")
        if any(page_number <= 0 for items in inventories for page_number in items):
            raise ValueError("scope page inventories must be positive and 1-based")
        if self.mode is PdfExtractionScopeMode.FULL_DOCUMENT:
            if self.requested_page_numbers:
                raise ValueError("full-document requested inventory must be implicit")
            if self.requested_page_count != self.source_document_page_count:
                raise ValueError(
                    "full-document requested count must equal source count"
                )
            if self.missing_requested_page_numbers:
                raise ValueError("full-document missing inventory must remain implicit")
        else:
            if self.requested_page_count != len(self.requested_page_numbers):
                raise ValueError("selected requested count must match its inventory")
            requested = set(self.requested_page_numbers)
            if not set(self.extracted_requested_page_numbers) <= requested:
                raise ValueError("extracted pages must belong to the selected scope")
            expected_missing = tuple(
                sorted(requested - set(self.extracted_requested_page_numbers))
            )
            if self.missing_requested_page_numbers != expected_missing:
                raise ValueError("selected missing inventory must be exact")
            if self.missing_requested_page_count != len(expected_missing):
                raise ValueError("selected missing count must match its inventory")
        if self.extracted_requested_page_count != len(
            self.extracted_requested_page_numbers
        ):
            raise ValueError("extracted requested count must match its inventory")
        if self.mode is PdfExtractionScopeMode.FULL_DOCUMENT:
            expected_missing_count = max(
                self.requested_page_count - self.extracted_requested_page_count,
                0,
            )
            if self.missing_requested_page_count != expected_missing_count:
                raise ValueError("full-document missing count must be exact")
        if self.incomplete_requested_page_count != len(
            self.incomplete_requested_page_numbers
        ):
            raise ValueError("incomplete requested count must match its inventory")
        if not set(self.incomplete_requested_page_numbers) <= set(
            self.extracted_requested_page_numbers
        ):
            raise ValueError("incomplete pages must have retained page facts")
        expected_complete = self.scope_evaluation_available and not (
            self.missing_requested_page_count or self.incomplete_requested_page_count
        )
        if self.requested_scope_complete != expected_complete:
            raise ValueError("scope completeness must match missing and partial pages")
        expected_source_complete = (
            self.requested_scope_complete
            and self.extracted_requested_page_count == self.source_document_page_count
        )
        if self.source_document_fully_extracted != expected_source_complete:
            raise ValueError("source-document completeness is inconsistent")
        if (
            self.selected_page_limit_applied
            and self.mode is not PdfExtractionScopeMode.SELECTED_PAGES
        ):
            raise ValueError("selected-page limit applies only to selected scope")
        if tuple(
            sorted(set(self.scope_warning_codes), key=lambda item: item.value)
        ) != (self.scope_warning_codes):
            raise ValueError("scope warning codes must be unique and ordered")
        expected_digest = hashlib.sha256(
            json.dumps(
                {
                    "schema_version": self.request_schema_version,
                    "mode": self.mode.value,
                    "source_document_page_count": self.source_document_page_count,
                    "requested_page_numbers": list(self.requested_page_numbers),
                },
                separators=(",", ":"),
                sort_keys=True,
            ).encode("utf-8")
        ).hexdigest()
        if self.scope_digest != expected_digest:
            raise ValueError("scope digest does not match the canonical request")
        return self


class PdfFactArtifact(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    schema_version: Literal["pdf_facts.v1", "pdf_facts.v2"]
    document_id: str = Field(pattern=r"^PDFD-[0-9a-f]{24}$")
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    parser_name: str = Field(min_length=1, max_length=64)
    parser_version: str = Field(min_length=1, max_length=64)
    extracted_at: AwareDatetime
    extraction_status: PdfExtractionStatus
    page_count: int = Field(ge=0)
    extracted_page_count: int = Field(ge=0)
    parser_capabilities: PdfParserCapabilities
    warnings: list[PdfFactWarning] = Field(default_factory=list)
    warning_suppression: PdfWarningSuppressionSummary = Field(
        default_factory=PdfWarningSuppressionSummary
    )
    applied_resource_limits: PdfExtractionLimits
    extraction_options: PdfExtractionOptions
    extraction_scope_result: PdfExtractionScopeResult
    partial_extraction: bool
    resource_usage: PdfResourceUsage
    pages: list[PdfPageFacts] = Field(default_factory=list)

    @model_serializer(mode="wrap")
    def serialize_fact_schema(
        self, handler: SerializerFunctionWrapHandler
    ) -> dict[str, object]:
        """Preserve the explicit old v1 wire without suppressing v2 evidence."""
        payload: dict[str, object] = handler(self)
        if self.schema_version == "pdf_facts.v1":
            self._validate_legacy_member_defaults()
            from document_sdk.pdf._structural_engine.facts.legacy_serialization import (
                strip_legacy_fact_payload,
            )

            return strip_legacy_fact_payload(payload)
        return payload

    def _validate_legacy_member_defaults(self) -> None:
        from document_sdk.pdf._structural_engine.facts.legacy_serialization import (
            legacy_fact_model_excluded_fields,
        )

        models = (
            self.parser_capabilities,
            self.extraction_options,
            self.applied_resource_limits,
            self.resource_usage,
        )
        for model in models:
            legacy_fact_model_excluded_fields(model, legacy_facts_v1=True)
        for page in self.pages:
            legacy_fact_model_excluded_fields(page, legacy_facts_v1=True)
            for fact in (
                *page.words,
                *page.text_spans,
                *page.line_candidates,
                *page.characters,
            ):
                legacy_fact_model_excluded_fields(fact, legacy_facts_v1=True)

    @model_validator(mode="before")
    @classmethod
    def apply_additive_scope_default(cls, value: object) -> object:
        if not isinstance(value, dict) or "extraction_scope_result" in value:
            return value
        payload = dict(value)
        options = PdfExtractionOptions.model_validate(
            payload.get("extraction_options", {})
        )
        scope = options.extraction_scope
        page_count = int(payload.get("page_count", 0))
        raw_pages = payload.get("pages", [])
        page_numbers = tuple(
            sorted(
                int(
                    page.page_number
                    if isinstance(page, PdfPageFacts)
                    else page["page_number"]
                )
                for page in raw_pages
            )
        )
        incomplete_page_numbers = tuple(
            sorted(
                int(
                    page.page_number
                    if isinstance(page, PdfPageFacts)
                    else page["page_number"]
                )
                for page in raw_pages
                if PdfExtractionStatus(
                    page.extraction_status
                    if isinstance(page, PdfPageFacts)
                    else page["extraction_status"]
                )
                is not PdfExtractionStatus.SUCCESS
            )
        )
        if scope.mode is PdfExtractionScopeMode.SELECTED_PAGES:
            requested_page_numbers = scope.requested_page_numbers
            requested_page_count = len(requested_page_numbers)
            missing_page_numbers = tuple(
                sorted(set(requested_page_numbers) - set(page_numbers))
            )
            missing_page_count = len(missing_page_numbers)
        else:
            requested_page_numbers = ()
            requested_page_count = page_count
            missing_page_numbers = ()
            missing_page_count = max(page_count - len(page_numbers), 0)
        status = PdfExtractionStatus(payload.get("extraction_status"))
        partial = bool(payload.get("partial_extraction", False))
        complete = (
            status in {PdfExtractionStatus.SUCCESS, PdfExtractionStatus.NO_TEXT_LAYER}
            and not partial
            and missing_page_count == 0
            and not incomplete_page_numbers
        )
        digest = hashlib.sha256(
            json.dumps(
                {
                    "schema_version": scope.schema_version,
                    "mode": scope.mode.value,
                    "source_document_page_count": page_count,
                    "requested_page_numbers": list(requested_page_numbers),
                },
                separators=(",", ":"),
                sort_keys=True,
            ).encode("utf-8")
        ).hexdigest()
        payload["extraction_scope_result"] = PdfExtractionScopeResult(
            mode=scope.mode,
            source_document_page_count=page_count,
            requested_page_numbers=requested_page_numbers,
            requested_page_count=requested_page_count,
            extracted_requested_page_numbers=page_numbers,
            extracted_requested_page_count=len(page_numbers),
            missing_requested_page_numbers=missing_page_numbers,
            missing_requested_page_count=missing_page_count,
            incomplete_requested_page_numbers=incomplete_page_numbers,
            incomplete_requested_page_count=len(incomplete_page_numbers),
            requested_scope_complete=complete,
            scope_evaluation_available=(
                status
                not in {
                    PdfExtractionStatus.UNSUPPORTED,
                    PdfExtractionStatus.ENCRYPTED,
                    PdfExtractionStatus.MALFORMED,
                    PdfExtractionStatus.PARSER_ERROR,
                    PdfExtractionStatus.INTERNAL_ERROR,
                }
            ),
            source_document_fully_extracted=(
                complete and len(page_numbers) == page_count
            ),
            scope_digest=digest,
            scope_truncated=(status is PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED),
        )
        return payload

    @field_validator("extracted_at")
    @classmethod
    def require_timezone(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("extracted_at must be timezone-aware")
        return value

    def _validate_member_source_identity(self) -> None:
        if self.schema_version == "pdf_facts.v1" and any(
            page.text_members
            or page.text_member_inventory_status not in {"NOT_REQUESTED", "UNSUPPORTED"}
            for page in self.pages
        ):
            raise ValueError("legacy Facts v1 cannot carry v2 member evidence")
        from document_sdk.pdf._structural_engine.facts.identifiers import (
            text_member_identifier,
            text_source_group_identifier,
        )

        native_configuration = hashlib.sha256(
            json.dumps(
                {
                    "unicode_norm": "NFC",
                    "strict_metadata": False,
                    "parser_version": self.parser_version,
                    "extraction_options": self.extraction_options.model_dump(
                        mode="json"
                    ),
                    "resource_limits": self.applied_resource_limits.model_dump(
                        mode="json"
                    ),
                },
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
                allow_nan=False,
            ).encode()
        ).hexdigest()
        for page in self.pages:
            if page.native_text_event_evidence is not None:
                for event in page.native_text_event_evidence.events:
                    if (
                        event.source_sha256 != self.source_sha256
                        or event.page_number != page.page_number
                        or event.parser_configuration_identity != native_configuration
                        or not event.parser_identity.startswith(
                            f"{self.parser_name}:{self.parser_version}|pdfminer:"
                        )
                    ):
                        raise ValueError(
                            "native text-show event belongs to a different source page"
                        )
                if (
                    len(page.native_text_event_evidence.events)
                    > self.applied_resource_limits.max_text_members_per_page
                ):
                    raise ValueError(
                        "native event count exceeds the shared finite inventory limit"
                    )
            for group in page.text_source_groups:
                expected_group_id = text_source_group_identifier(
                    source_hash=self.source_sha256,
                    page_id=page.page_id,
                    method_version=page.text_member_method_version,
                    granularity=group.granularity,
                    source_group_order=group.source_group_order,
                    text=group.text,
                )
                if group.source_group_id != expected_group_id:
                    raise ValueError(
                        "source group identity is not bound to this invocation"
                    )
            for member in page.text_members:
                raw = member.parser_bbox
                matrix = member.text_transform
                expected_member_id = text_member_identifier(
                    source_hash=self.source_sha256,
                    parser_name=self.parser_name,
                    parser_version=self.parser_version,
                    method_version=page.text_member_method_version,
                    page_number=page.page_number,
                    source_character_index=member.source_character_index,
                    text=member.text,
                    parser_bbox=(raw.x0, raw.y0, raw.x1, raw.y1)
                    if raw is not None
                    else None,
                    matrix=(matrix.a, matrix.b, matrix.c, matrix.d, matrix.e, matrix.f)
                    if matrix is not None
                    else None,
                    parser_advance=member.parser_advance,
                    source_writing_mode=member.source_writing_mode,
                    native_text_event_id=member.native_text_event_id,
                    native_text_event_ordinal=member.native_text_event_ordinal,
                    native_text_event_member_ordinal=member.native_text_event_member_ordinal,
                    native_character_ordinal=member.native_character_ordinal,
                )
                if member.member_id != expected_member_id:
                    raise ValueError(
                        "member identity is not bound to this source/parser/page"
                    )
            if (
                page.text_member_count
                > self.applied_resource_limits.max_text_members_per_page
            ):
                raise ValueError("member count exceeds the applied resource limit")
            if (
                page.text_member_serialized_bytes
                + page.text_member_reference_bytes
                + page.text_source_group_serialized_bytes
                + page.native_text_event_serialized_bytes
                > self.applied_resource_limits.max_text_member_bytes_per_page
            ):
                raise ValueError("member evidence bytes exceed the applied limit")

    def _validate_member_resource_usage(self) -> None:
        if self.schema_version != "pdf_facts.v2":
            return
        count = sum(page.text_member_count for page in self.pages)
        byte_count = sum(
            page.text_member_serialized_bytes
            + page.text_member_reference_bytes
            + page.text_source_group_serialized_bytes
            + page.native_text_event_serialized_bytes
            for page in self.pages
        )
        if (
            self.resource_usage.text_member_count,
            self.resource_usage.text_member_evidence_bytes,
        ) != (count, byte_count):
            raise ValueError(
                "member resource usage is not the exact retained inventory"
            )
        if self.extraction_options.include_text_members:
            from document_sdk.pdf._structural_engine.facts.normalization import (
                page_total_facts,
            )

            total = sum(page_total_facts(page) for page in self.pages)
            if (
                self.resource_usage.total_facts != total
                or total > self.applied_resource_limits.max_total_facts
            ):
                raise ValueError("member-enabled global fact usage is inconsistent")

    @model_validator(mode="after")
    def validate_document_integrity(self) -> "PdfFactArtifact":
        if self.extracted_page_count != len(self.pages):
            raise ValueError("extracted page count must match pages")
        if self.extracted_page_count > self.page_count:
            raise ValueError("extracted page count cannot exceed source page count")
        scope = self.extraction_scope_result
        if scope.mode is not self.extraction_options.extraction_scope.mode:
            raise ValueError("scope result mode must match extraction options")
        if (
            scope.mode is PdfExtractionScopeMode.SELECTED_PAGES
            and scope.requested_page_numbers
            != self.extraction_options.extraction_scope.requested_page_numbers
        ):
            raise ValueError("scope result inventory must match extraction options")
        if scope.source_document_page_count != self.page_count:
            raise ValueError("scope source page count must match the artifact")
        page_numbers = [page.page_number for page in self.pages]
        page_ids = [page.page_id for page in self.pages]
        if len(page_numbers) != len(set(page_numbers)):
            raise ValueError("page numbers must be unique")
        if len(page_ids) != len(set(page_ids)):
            raise ValueError("page IDs must be unique")
        if any(page_number > self.page_count for page_number in page_numbers):
            raise ValueError("page number cannot exceed source page count")
        if tuple(sorted(page_numbers)) != scope.extracted_requested_page_numbers:
            raise ValueError("scope extracted inventory must match artifact pages")
        if self.extraction_status is PdfExtractionStatus.SUCCESS:
            if self.partial_extraction or not scope.requested_scope_complete:
                raise ValueError("success requires complete requested-scope extraction")
        if self.extraction_status is PdfExtractionStatus.NO_TEXT_LAYER:
            if self.partial_extraction or not scope.requested_scope_complete:
                raise ValueError("no-text result requires a complete requested scope")
        if self.extraction_status in {
            PdfExtractionStatus.PARTIAL,
            PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED,
        }:
            if not self.partial_extraction or scope.requested_scope_complete:
                raise ValueError(
                    "partial status requires an incomplete requested scope"
                )
        if (
            self.extraction_status is PdfExtractionStatus.INVALID_REQUEST
            and scope.requested_scope_complete
        ):
            raise ValueError("invalid request cannot have a complete requested scope")
        self._validate_member_source_identity()
        self._validate_member_resource_usage()
        if self.schema_version == "pdf_facts.v1":
            self._validate_legacy_member_defaults()
        warning_occurrences = len(self.warnings)
        for page in self.pages:
            warning_occurrences += len(page.warnings)
            warning_occurrences += sum(
                len(fact.warnings)  # type: ignore[misc, attr-defined]
                for fact in (
                    *page.text_spans,
                    *page.words,
                    *page.line_candidates,
                    *page.characters,
                    *page.text_members,
                    *page.drawings,
                    *page.image_regions,
                )
            )
        if warning_occurrences > self.applied_resource_limits.max_warning_count:
            raise ValueError(
                "stored warning occurrences exceed the global warning limit"
            )
        warning_limit_markers = sum(
            warning.code is PdfWarningCode.WARNING_LIMIT_REACHED
            for warning in self.warnings
        )
        if self.warning_suppression.suppressed_warning_count:
            if warning_limit_markers != 1:
                raise ValueError("warning suppression requires one artifact marker")
        elif warning_limit_markers:
            raise ValueError("warning-limit marker requires a suppression summary")
        return self

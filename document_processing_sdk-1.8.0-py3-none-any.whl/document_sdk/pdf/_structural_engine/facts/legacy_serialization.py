"""Explicit v1 Facts wire compatibility for empty v2-only member evidence.

A v1 parent supplies context. A v2 object with empty members is still v2 and
keeps its new fields. Non-default v2 values can never be silently hidden.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pydantic import BaseModel

_FACT_MODULE = "document_sdk.pdf._structural_engine.facts."
LEGACY_FACT_MODEL_DEFAULTS: dict[tuple[str, str], dict[str, Any]] = {
    (_FACT_MODULE + "contracts", "PdfTextFact"): {
        "member_ids": (),
        "source_member_count": 0,
        "source_group_id": None,
        "member_inventory_status": "NOT_CAPTURED",
        "member_projection_status": "NOT_CAPTURED",
        "member_projection": (),
    },
    (_FACT_MODULE + "contracts", "PdfPageFacts"): {
        "text_members": [],
        "native_text_event_evidence": None,
        "native_text_event_capture_status": "NOT_CAPTURED",
        "native_text_event_serialized_bytes": 0,
        "text_source_groups": [],
        "text_source_group_count": 0,
        "source_text_group_count": 0,
        "text_source_group_truncated": False,
        "text_source_group_serialized_bytes": 0,
        "text_member_method_version": "unavailable",
        "text_member_inventory_status": "NOT_REQUESTED",
        "text_member_count": 0,
        "source_text_member_count": 0,
        "text_member_serialized_bytes": 0,
        "text_member_reference_bytes": 0,
    },
    (_FACT_MODULE + "capabilities", "PdfParserCapabilities"): {"text_members": False},
    (_FACT_MODULE + "limits", "PdfExtractionOptions"): {"include_text_members": False},
    (_FACT_MODULE + "limits", "PdfExtractionLimits"): {
        "max_text_members_per_page": 250_000,
        "max_text_member_bytes_per_page": 32 * 1024 * 1024,
    },
    (_FACT_MODULE + "limits", "PdfResourceUsage"): {
        "text_member_count": 0,
        "text_member_evidence_bytes": 0,
    },
}


def is_legacy_fact_artifact(value: object) -> bool:
    """Recognize the explicit versioned parent, never an unversioned child guess."""
    return (type(value).__module__, type(value).__name__) == (
        _FACT_MODULE + "contracts",
        "PdfFactArtifact",
    ) and getattr(value, "schema_version", None) == "pdf_facts.v1"


def legacy_fact_model_excluded_fields(
    value: BaseModel, *, legacy_facts_v1: bool
) -> frozenset[str]:
    """Select exactly v2-added fields only beneath an explicit v1 artifact."""
    if not legacy_facts_v1:
        return frozenset()
    defaults = LEGACY_FACT_MODEL_DEFAULTS.get(
        (type(value).__module__, type(value).__name__), {}
    )
    for field, expected in defaults.items():
        if getattr(value, field) != expected:
            message = "Facts v1 cannot hide non-default v2 member evidence"
            raise ValueError(message)
    return frozenset(defaults)


def strip_legacy_fact_payload(payload: dict[str, Any]) -> dict[str, Any]:
    """Remove known additive keys after model-level legacy validation only."""

    def strip(value: object, name: str, module: str = "contracts") -> None:
        if isinstance(value, dict):
            for field in LEGACY_FACT_MODEL_DEFAULTS.get(
                (_FACT_MODULE + module, name), {}
            ):
                value.pop(field, None)

    strip(payload.get("parser_capabilities"), "PdfParserCapabilities", "capabilities")
    strip(payload.get("extraction_options"), "PdfExtractionOptions", "limits")
    strip(payload.get("applied_resource_limits"), "PdfExtractionLimits", "limits")
    strip(payload.get("resource_usage"), "PdfResourceUsage", "limits")
    for page in payload.get("pages", []):
        if not isinstance(page, dict):
            continue
        strip(page, "PdfPageFacts")
        for kind in ("words", "text_spans", "line_candidates", "characters"):
            for fact in page.get(kind, []):
                strip(fact, "PdfTextFact")
    return payload

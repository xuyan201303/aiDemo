"""Bounded same-parser text-show execution evidence; never original byte offsets."""

from __future__ import annotations

import json
from hashlib import sha256
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

_MAX_LIMITATION_CODE_LENGTH = 128


def native_event_identifier(payload: dict[str, object]) -> str:
    """Bind fixed invocation inputs independently from mutable capture counters."""
    excluded = {
        "source_event_id",
        "source_member_count",
        "retained_member_count",
        "completeness",
        "limitation_codes",
    }
    encoded = json.dumps(
        {key: value for key, value in payload.items() if key not in excluded},
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode()
    return "PDFTE-" + sha256(encoded).hexdigest()


class PdfNativeTextShowEvent(BaseModel):
    """One executed native text-show occurrence, including distinct Form invocations."""

    model_config = ConfigDict(extra="forbid", frozen=True)
    schema_version: Literal["pdf_native_text_show_event.v1"] = (
        "pdf_native_text_show_event.v1"
    )
    source_event_id: str = Field(pattern=r"^PDFTE-[0-9a-f]{64}$")
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_number: int = Field(ge=1, strict=True)
    parser_identity: str = Field(min_length=1, max_length=256)
    parser_configuration_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    native_event_ordinal: int = Field(ge=0, strict=True)
    invocation_path: tuple[int, ...] = Field(max_length=256)
    operator: Literal["Tj", "TJ", "'", '"']
    operand_sequence_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    operand_count: int = Field(ge=0, strict=True)
    string_segment_count: int = Field(ge=0, strict=True)
    numeric_adjustment_count: int = Field(ge=0, strict=True)
    source_member_count: int = Field(ge=0, strict=True)
    retained_member_count: int = Field(ge=0, strict=True)
    completeness: Literal["COMPLETE", "TRUNCATED"]
    limitation_codes: tuple[str, ...] = Field(max_length=64)

    @model_validator(mode="after")
    def validate_native_event(self) -> PdfNativeTextShowEvent:
        if any(value < 0 for value in self.invocation_path):
            message = "native invocation ordinals must be nonnegative"
            raise ValueError(message)
        if self.retained_member_count > self.source_member_count:
            message = "native retained members exceed actual render observations"
            raise ValueError(message)
        if (
            self.completeness == "COMPLETE"
            and self.retained_member_count != self.source_member_count
        ):
            message = "complete native event must retain every observed member"
            raise ValueError(message)
        if any(
            len(code) > _MAX_LIMITATION_CODE_LENGTH for code in self.limitation_codes
        ):
            message = "native limitation code is unbounded"
            raise ValueError(message)
        if self.source_event_id != native_event_identifier(
            self.model_dump(mode="json")
        ):
            message = "native text-show identity does not bind the event"
            raise ValueError(message)
        return self


class PdfNativeTextEventEvidence(BaseModel):
    """Shared finite event inventory from the same parser invocation."""

    model_config = ConfigDict(extra="forbid", frozen=True)
    method_version: Literal["pdfplumber.native_text_events.v1"]
    availability: Literal["COMPLETE", "PARTIAL", "NOT_CAPTURED"]
    events: tuple[PdfNativeTextShowEvent, ...]
    source_event_count: int = Field(ge=0, strict=True)
    retained_event_count: int = Field(ge=0, strict=True)
    source_member_count: int = Field(ge=0, strict=True)
    retained_member_count: int = Field(ge=0, strict=True)
    serialized_bytes: int = Field(ge=0, strict=True)
    truncated: bool
    limitation_codes: tuple[str, ...] = Field(max_length=64)

    def wire_size(self) -> int:
        """Count one event record at a time without materializing a pool copy."""
        metadata = self.model_dump(mode="json", exclude={"events"})
        metadata_bytes = len(
            json.dumps(
                metadata,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
                allow_nan=False,
            ).encode()
        )
        events_bytes = (
            2
            + max(0, len(self.events) - 1)
            + sum(
                len(
                    json.dumps(
                        event.model_dump(mode="json"),
                        ensure_ascii=False,
                        sort_keys=True,
                        separators=(",", ":"),
                        allow_nan=False,
                    ).encode()
                )
                for event in self.events
            )
        )
        return metadata_bytes + len('"events":') + 1 + events_bytes

    @model_validator(mode="after")
    def validate_event_inventory(self) -> PdfNativeTextEventEvidence:
        ids = [event.source_event_id for event in self.events]
        ordinals = [event.native_event_ordinal for event in self.events]
        if len(set(ids)) != len(ids) or ordinals != sorted(set(ordinals)):
            message = "native events must have unique ordered identities"
            raise ValueError(message)
        if self.retained_event_count != len(
            self.events
        ) or self.source_event_count < len(self.events):
            message = "native event inventory counts are inconsistent"
            raise ValueError(message)
        if any(index >= self.source_event_count for index in ordinals):
            message = "native event ordinal exceeds observed event count"
            raise ValueError(message)
        if (
            sum(event.retained_member_count for event in self.events)
            != self.retained_member_count
            or self.retained_member_count > self.source_member_count
        ):
            message = "native member retention accounting is inconsistent"
            raise ValueError(message)
        cost = (
            2
            + max(0, len(self.events) - 1)
            + sum(
                len(
                    json.dumps(
                        event.model_dump(mode="json"),
                        ensure_ascii=False,
                        sort_keys=True,
                        separators=(",", ":"),
                        allow_nan=False,
                    ).encode()
                )
                for event in self.events
            )
        )
        if self.availability == "NOT_CAPTURED":
            cost = 0
        if cost != self.serialized_bytes:
            message = "native event serialized-byte counter must be exact"
            raise ValueError(message)
        self._validate_completeness(ordinals)
        if any(
            len(code) > _MAX_LIMITATION_CODE_LENGTH for code in self.limitation_codes
        ):
            message = "native limitation code is unbounded"
            raise ValueError(message)
        return self

    def _validate_completeness(self, ordinals: list[int]) -> None:
        if self.availability == "COMPLETE":
            if (
                self.truncated
                or self.source_event_count != self.retained_event_count
                or self.source_member_count != self.retained_member_count
                or ordinals != list(range(self.source_event_count))
                or any(event.completeness != "COMPLETE" for event in self.events)
            ):
                message = "complete native inventory cannot conceal truncation"
                raise ValueError(message)
        elif self.availability == "NOT_CAPTURED" and (
            self.events or self.source_event_count or self.source_member_count
        ):
            message = "uncaptured native inventory cannot claim observations"
            raise ValueError(message)

# ruff: noqa: EM101, TRY003, UP042

from enum import Enum
from typing import Literal

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    field_validator,
    model_validator,
)


class PdfExtractionStatus(str, Enum):
    SUCCESS = "success"
    PARTIAL = "partial"
    UNSUPPORTED = "unsupported"
    NO_TEXT_LAYER = "no_text_layer"
    ENCRYPTED = "encrypted"
    RESOURCE_LIMIT_EXCEEDED = "resource_limit_exceeded"
    MALFORMED = "malformed"
    PARSER_ERROR = "parser_error"
    INTERNAL_ERROR = "internal_error"
    INVALID_REQUEST = "invalid_request"


PDF_COMPLETE_SCOPE_EXTRACTION_STATUSES = frozenset(
    {
        PdfExtractionStatus.SUCCESS,
        PdfExtractionStatus.NO_TEXT_LAYER,
    }
)
PDF_PARTIAL_SCOPE_EXTRACTION_STATUSES = frozenset(
    {
        PdfExtractionStatus.PARTIAL,
        PdfExtractionStatus.UNSUPPORTED,
        PdfExtractionStatus.ENCRYPTED,
        PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED,
        PdfExtractionStatus.MALFORMED,
        PdfExtractionStatus.PARSER_ERROR,
        PdfExtractionStatus.INTERNAL_ERROR,
    }
)


class PdfWarningSeverity(str, Enum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"


class PdfWarningCode(str, Enum):
    TEXT_LAYER_MISSING = "text_layer_missing"
    MALFORMED_TEXT_OBJECT = "malformed_text_object"
    INVALID_BBOX = "invalid_bbox"
    ZERO_AREA_BBOX = "zero_area_bbox"
    APPROXIMATE_BBOX = "approximate_bbox"
    APPROXIMATE_GRAPHICS_STATE = "approximate_graphics_state"
    ROTATION_UNAVAILABLE = "rotation_unavailable"
    PAGE_PARTIALLY_PARSED = "page_partially_parsed"
    UNSUPPORTED_ROTATION = "unsupported_rotation"
    UNSUPPORTED_WRITING_MODE = "unsupported_writing_mode"
    CONTENT_STREAM_TOO_LARGE = "content_stream_too_large"
    FILE_SIZE_LIMIT_REACHED = "file_size_limit_reached"
    PAGE_LIMIT_REACHED = "page_limit_reached"
    SELECTED_PAGE_LIMIT_REACHED = "selected_page_limit_reached"
    INVALID_EXTRACTION_SCOPE = "invalid_extraction_scope"
    TEXT_FACT_LIMIT_REACHED = "text_fact_limit_reached"
    CHARACTER_LIMIT_REACHED = "character_limit_reached"
    TEXT_MEMBER_LIMIT_REACHED = "text_member_limit_reached"
    TEXT_MEMBER_BYTES_LIMIT_REACHED = "text_member_bytes_limit_reached"
    TEXT_MEMBER_PROJECTION_INCOMPLETE = "text_member_projection_incomplete"
    DRAWING_LIMIT_REACHED = "drawing_limit_reached"
    PATH_SEGMENT_LIMIT_REACHED = "path_segment_limit_reached"
    IMAGE_LIMIT_REACHED = "image_limit_reached"
    TOTAL_FACT_LIMIT_REACHED = "total_fact_limit_reached"
    ARTIFACT_SIZE_LIMIT_REACHED = "artifact_size_limit_reached"
    WARNING_LIMIT_REACHED = "warning_limit_reached"
    EXTRACTION_TIMEOUT = "extraction_timeout"
    PARSER_CAPABILITY_UNAVAILABLE = "parser_capability_unavailable"
    PARSER_EXCEPTION = "parser_exception"
    ENCRYPTED_DOCUMENT = "encrypted_document"
    MALFORMED_DOCUMENT = "malformed_document"
    NO_TEXT_LAYER = "no_text_layer"
    PARTIAL_PAGE_FAILURE = "partial_page_failure"
    GEOMETRY_PROVIDER_UNAVAILABLE = "geometry_provider_unavailable"
    GEOMETRY_FALLBACK_ASSUMPTION = "geometry_fallback_assumption"
    UNSUPPORTED_SOURCE = "unsupported_source"


class PdfFactWarning(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    code: PdfWarningCode
    severity: PdfWarningSeverity
    page_number: int | None = Field(default=None, ge=1)
    fact_id: str | None = Field(default=None, pattern=r"^PDFF-[0-9a-f]{24}$")
    message: str = Field(min_length=1, max_length=240)
    parser_name: str = Field(min_length=1, max_length=64)
    recoverable: bool

    @field_validator("message", "parser_name")
    @classmethod
    def reject_multiline_or_untrimmed_text(cls, value: str) -> str:
        if value != value.strip() or "\n" in value or "\r" in value:
            raise ValueError("warning text must be trimmed and single-line")
        return value


PdfWarningScope = Literal["artifact", "page", "fact"]


class PdfWarningSuppressionSummary(BaseModel):
    """Bounded counts for warning occurrences omitted from an artifact."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    suppressed_warning_count: int = Field(default=0, ge=0)
    suppressed_warning_count_by_code: dict[PdfWarningCode, int] = Field(
        default_factory=dict
    )
    suppressed_warning_count_by_scope: dict[PdfWarningScope, int] = Field(
        default_factory=dict
    )
    suppressed_affected_page_count: int = Field(
        default=0,
        ge=0,
        description="Suppressed occurrences carrying a page number.",
    )
    suppressed_affected_fact_count: int = Field(
        default=0,
        ge=0,
        description="Suppressed occurrences carrying a fact identifier.",
    )

    @model_validator(mode="after")
    def validate_counts(self) -> "PdfWarningSuppressionSummary":
        if any(count <= 0 for count in self.suppressed_warning_count_by_code.values()):
            raise ValueError("suppressed warning code counts must be positive")
        if any(count <= 0 for count in self.suppressed_warning_count_by_scope.values()):
            raise ValueError("suppressed warning scope counts must be positive")
        if (
            sum(self.suppressed_warning_count_by_code.values())
            != self.suppressed_warning_count
        ):
            raise ValueError("suppressed warning code counts must match the total")
        if (
            sum(self.suppressed_warning_count_by_scope.values())
            != self.suppressed_warning_count
        ):
            raise ValueError("suppressed warning scope counts must match the total")
        if self.suppressed_affected_page_count > self.suppressed_warning_count:
            raise ValueError("suppressed affected-page count cannot exceed the total")
        if self.suppressed_affected_fact_count > self.suppressed_warning_count:
            raise ValueError("suppressed affected-fact count cannot exceed the total")
        return self

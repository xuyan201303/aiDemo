from typing import Literal

from pydantic import BaseModel, ConfigDict


class PdfParserCapabilities(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    page_geometry: bool
    text_spans: bool
    words: bool
    line_candidates: bool
    text_members: bool = False
    optional_characters: bool
    font_name: bool
    font_size: bool
    text_rotation: bool
    writing_direction: bool
    drawings: bool
    drawing_lines: bool
    drawing_rectangles: bool
    drawing_curves: bool
    image_regions: bool
    text_bbox_quality: Literal["unavailable", "anchor", "precise"]
    native_engine: bool
    selected_page_extraction: bool = False
    text_affine_transform: bool = False
    effective_font_size: bool = False
    nominal_stroke_width: bool = False
    drawing_affine_transform: bool = False
    drawing_paint_operation: bool = False
    drawing_path_segments: bool = False
    character_rotation: bool = False
    drawing_bbox_quality: Literal["unavailable", "approximate", "precise"] = (
        "unavailable"
    )
    graphics_state_fidelity: Literal["unavailable", "partial", "renderer"] = (
        "unavailable"
    )

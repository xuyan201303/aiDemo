# ruff: noqa: C901, EM101, PLR0912, PLR0915, TRY003

from __future__ import annotations

from . import document_table_contracts as _contracts

PdfDocumentTable = _contracts.PdfDocumentTable
PdfDocumentTablePageReference = _contracts.PdfDocumentTablePageReference
PdfPhase3DTableEndpoint = _contracts.PdfPhase3DTableEndpoint
PdfTablePageTransition = _contracts.PdfTablePageTransition
build_document_logical_row = _contracts.build_document_logical_row
build_document_table = _contracts.build_document_table

_LINKED_OUTCOMES = {
    "CONTINUATION_PROVEN",
    "REPEATED_HEADER_CONTINUATION",
    "SPLIT_ROW_CONTINUATION",
}


def _row_cells(endpoint: PdfPhase3DTableEndpoint) -> dict[str, tuple[str, ...]]:
    return dict(endpoint.row_cell_membership)


def assemble_document_tables(
    transitions: tuple[PdfTablePageTransition, ...],
) -> tuple[PdfDocumentTable, ...]:
    linked = tuple(item for item in transitions if item.outcome in _LINKED_OUTCOMES)
    if not linked:
        return ()
    successors: dict[str, PdfTablePageTransition] = {}
    predecessors: dict[str, PdfTablePageTransition] = {}
    for item in linked:
        if item.left.table_id in successors:
            raise ValueError("one-to-many document table branching is unsupported")
        if item.right.table_id in predecessors:
            raise ValueError("many-to-one document table merging is unsupported")
        successors[item.left.table_id] = item
        predecessors[item.right.table_id] = item
    starts = sorted(
        (item for item in linked if item.left.table_id not in predecessors),
        key=lambda item: (item.left.page_index, item.left.table_id),
    )
    if not starts:
        raise ValueError("cyclic document table chain is unsupported")
    consumed: set[str] = set()
    result = []
    for start in starts:
        chain = [start]
        consumed.add(start.transition_id)
        while chain[-1].right.table_id in successors:
            following = successors[chain[-1].right.table_id]
            if following.transition_id in consumed:
                raise ValueError("cyclic document table chain is unsupported")
            if following.left != chain[-1].right:
                raise ValueError(
                    "document table chain has inconsistent intermediate authority"
                )
            if following.left.page_index != chain[-1].right.page_index:
                raise ValueError("document table chain contains a non-adjacent link")
            chain.append(following)
            consumed.add(following.transition_id)
        endpoints = [chain[0].left, *(item.right for item in chain)]
        binding = {
            (
                item.source_sha256,
                item.document_identity,
                item.page_table_manifest_sha256,
            )
            for item in endpoints
        }
        if len(binding) != 1:
            raise ValueError("document table chain crosses source or document identity")
        page_refs = tuple(
            PdfDocumentTablePageReference(
                page_index=item.page_index,
                page_id=item.page_id,
                table_id=item.table_id,
                table_sidecar_id=item.table_sidecar_id,
                source_row_ids=item.table_row_ids,
                source_cell_ids=item.table_cell_ids,
            )
            for item in endpoints
        )
        repeated_right_rows = {
            row_id
            for transition in chain
            for mapping in transition.repeated_header_mappings
            for row_id in mapping.right_row_ids
        }
        fragments_by_left = {
            fragment.left_row_id: fragment
            for transition in chain
            for fragment in transition.row_fragment_links
        }
        fragment_right_rows = {
            fragment.right_row_id for fragment in fragments_by_left.values()
        }
        logical_rows = []
        for endpoint in endpoints:
            cells_by_row = _row_cells(endpoint)
            for row_id in endpoint.table_row_ids:
                if row_id in repeated_right_rows or row_id in fragment_right_rows:
                    continue
                fragment = fragments_by_left.get(row_id)
                if fragment is not None:
                    logical_rows.append(
                        build_document_logical_row(
                            fragment_row_ids=(
                                fragment.left_row_id,
                                fragment.right_row_id,
                            ),
                            fragment_cell_ids=(
                                fragment.left_cell_ids + fragment.right_cell_ids
                            ),
                            source_page_indexes=(
                                endpoint.page_index,
                                endpoint.page_index + 1,
                            ),
                        )
                    )
                    continue
                row_cells = cells_by_row.get(row_id, ())
                if not row_cells:
                    continue
                logical_rows.append(
                    build_document_logical_row(
                        fragment_row_ids=(row_id,),
                        fragment_cell_ids=row_cells,
                        source_page_indexes=(endpoint.page_index,),
                        repeated_header_occurrence=False,
                    )
                )
        header_ids = tuple(
            mapping.logical_header_identity
            for transition in chain
            for mapping in transition.repeated_header_mappings
        )
        source_sha, document_identity, page_manifest_sha = next(iter(binding))
        partial = any(item.outcome == "CONTINUATION_PARTIAL" for item in chain)
        result.append(
            build_document_table(
                source_sha256=source_sha,
                document_identity=document_identity,
                page_table_manifest_sha256=page_manifest_sha,
                page_table_references=page_refs,
                transition_ids=tuple(item.transition_id for item in chain),
                logical_rows=tuple(logical_rows),
                canonical_header_identity=header_ids[0] if header_ids else None,
                repeated_header_identities=header_ids,
                status="PARTIAL" if partial else "COMPLETE",
                limitation_codes=("PARTIAL_TRANSITION",) if partial else (),
            )
        )
    if len(consumed) != len(linked):
        raise ValueError(
            "document table transition graph contains an unreachable cycle"
        )
    return tuple(result)

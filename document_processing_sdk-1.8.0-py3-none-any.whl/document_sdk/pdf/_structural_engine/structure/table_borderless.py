# ruff: noqa: ARG001, B905, C409, C901, PLR0911, PLR0912, PLR0913, PLR0915, PLR2004, PLW2901, RUF007, TC001, UP035

from __future__ import annotations

from dataclasses import dataclass
from math import isfinite
from statistics import median
from typing import Any, Iterable, Literal, Sequence

from pydantic import BaseModel

from document_sdk.pdf._structural_engine.facts.contracts import (
    PdfBoundingBox,
    PdfTextFact,
)
from document_sdk.pdf._structural_engine.layout.contracts import PdfLayoutNode

from .table_contracts import (
    PdfTable,
    PdfTableAxisBoundary,
    PdfTableCell,
    PdfTableColumn,
    PdfTableEvidence,
    PdfTableRow,
    table_structure_identifier,
)
from .table_member_contracts import PdfTableCellTextPart, PdfTableCellTextProjection
from .table_member_views import TableTextView
from .table_text_evidence import TableTextEvidenceCollector


@dataclass(frozen=True)
class BorderlessTableBindings:
    source_sha256: str
    page_id: str
    page_index: int
    page_width: float
    page_height: float
    inherited_page_sidecar_id: str
    inherited_page_sidecar_sha256: str
    inherited_manifest_id: str
    reading_page_sidecar_id: str | None
    reading_page_sidecar_sha256: str | None
    text_evidence: TableTextEvidenceCollector | None = None


@dataclass(frozen=True)
class BorderlessTableOptions:
    coordinate_tolerance: float
    minimum_rows: int
    minimum_columns: int
    minimum_occupancy: float
    maximum_text_width_ratio: float


@dataclass(frozen=True)
class _Item:
    fact: PdfTextFact
    node: PdfLayoutNode
    view: TableTextView | None = None

    @property
    def geometry(self) -> PdfBoundingBox:
        return self.view.geometry if self.view is not None else self.node.bbox

    @property
    def text(self) -> str:
        return self.view.text if self.view is not None else self.fact.text

    def as_input(self) -> tuple[PdfTextFact, PdfLayoutNode] | TableTextView:
        return self.view if self.view is not None else (self.fact, self.node)


def _text_items(
    inputs: Sequence[tuple[PdfTextFact, PdfLayoutNode] | TableTextView],
) -> tuple[_Item, ...]:
    return tuple(
        _Item(value.fact, value.node, value)
        if isinstance(value, TableTextView)
        else _Item(*value)
        for value in inputs
        if isinstance(value, TableTextView) or value[1].node_type == "word"
    )


def build_borderless_aligned_tables(
    *,
    bindings: BorderlessTableBindings,
    text_items: Sequence[tuple[PdfTextFact, PdfLayoutNode] | TableTextView],
    options: BorderlessTableOptions,
) -> tuple[PdfTable, ...]:
    items = _text_items(text_items)
    partitioning = _independent_horizontal_partitions(items, options=options)
    if partitioning is None:
        side_by_side_nested = _side_by_side_nested_runs(items, options=options)
        if not side_by_side_nested:
            side_by_side_nested = _independently_proven_nested_region_runs(
                items, options=options
            )
        if side_by_side_nested:
            tables: list[PdfTable] = []
            text_height = median(
                tuple(max(0.1, _height(item.geometry)) for item in items)
            )
            inset = text_height * 0.42
            for selected_run in side_by_side_nested:
                selected_items = tuple(
                    item for row, _cells in selected_run for item in row
                )
                table = build_borderless_aligned_table(
                    bindings=bindings,
                    text_items=tuple(item.as_input() for item in selected_items),
                    options=options,
                    table_index=len(tables),
                    region_x0=(
                        min(item.geometry.x0 for item in selected_items) - inset
                    ),
                    region_x1=(
                        max(item.geometry.x1 for item in selected_items) + inset
                    ),
                    selected_run=selected_run,
                    shared_row_envelope_height=text_height,
                )
                if table is None:
                    return ()
                tables.append(table)
            return tuple(tables)
    if partitioning is not None:
        partitions, separating_gutter_center = partitioning
        nested_runs = _nested_detail_partition_runs(
            partitions[0], partitions[1], options=options
        )
        if nested_runs:
            nested_tables: list[PdfTable] = []
            text_height = median(
                tuple(max(0.1, _height(item.geometry)) for item in items)
            )
            inset = text_height * 0.42
            for nested_run in nested_runs:
                nested_items = tuple(item for row, _cells in nested_run for item in row)
                nested_table = build_borderless_aligned_table(
                    bindings=bindings,
                    text_items=tuple(item.as_input() for item in nested_items),
                    options=options,
                    table_index=len(nested_tables),
                    region_x0=(min(item.geometry.x0 for item in nested_items) - inset),
                    region_x1=(max(item.geometry.x1 for item in nested_items) + inset),
                    selected_run=nested_run,
                    shared_row_envelope_height=text_height,
                )
                if nested_table is None:
                    return ()
                nested_tables.append(nested_table)
            return tuple(nested_tables)
        tables = []
        text_height = median(tuple(max(0.1, _height(item.geometry)) for item in items))
        inset = text_height * 0.42
        stable_partition_runs = tuple(
            _stable_aligned_runs(partition, options=options)[0]
            for partition in partitions
        )
        bilateral_stable_sections = all(len(runs) > 1 for runs in stable_partition_runs)
        for partition_index, partition in enumerate(partitions):
            runs, _ = _partition_aligned_runs(partition, options=options)
            if not runs:
                return ()
            selected_runs = (
                stable_partition_runs[partition_index]
                if bilateral_stable_sections
                else (max(runs, key=lambda run: len(run) * len(run[0][1])),)
            )
            for selected_run in selected_runs:
                selected_items = tuple(
                    item for row, _cells in selected_run for item in row
                )
                table = build_borderless_aligned_table(
                    bindings=bindings,
                    text_items=tuple(item.as_input() for item in selected_items),
                    options=options,
                    table_index=len(tables),
                    region_x0=(
                        min(item.geometry.x0 for item in selected_items) - inset
                    ),
                    region_x1=(
                        _partition_right_extent(
                            selected_run,
                            separating_gutter_center=separating_gutter_center,
                            text_height=text_height,
                            inset=inset,
                        )
                        if partition_index == 0
                        else _aligned_run_right_extent(
                            selected_run,
                            text_height=text_height,
                            inset=inset,
                        )
                    ),
                    selected_run=selected_run,
                    shared_row_envelope_height=text_height,
                )
                if table is None:
                    return ()
                tables.append(table)
        return tuple(tables)
    stable, _text_height = _stable_aligned_runs(items, options=options)
    if not stable and items and all(item.view is not None for item in items):
        rows = _cluster_items(items, axis="row", tolerance=options.coordinate_tolerance)
        selected_member_run = tuple(
            (
                row,
                tuple(
                    (item,) for item in sorted(row, key=lambda value: value.geometry.x0)
                ),
            )
            for row in rows
        )
        if (
            len(rows) >= options.minimum_rows
            and len({len(row) for row in rows}) == 1
            and len(rows[0]) >= options.minimum_columns
        ):
            stable = (selected_member_run,)
    adaptive, _ = _partition_aligned_runs(items, options=options)
    if (
        len(adaptive) == 1
        and stable
        and len(adaptive[0]) > max(len(run) for run in stable)
        and {len(run[0][1]) for run in stable} == {len(adaptive[0][0][1])}
    ):
        stable = adaptive
    if not stable:
        narrow = _narrow_aligned_run(items, bindings=bindings, options=options)
        if narrow:
            stable = (narrow,)
    tables = []
    for run in stable:
        selected = tuple(item for row, _cells in run for item in row)
        table = build_borderless_aligned_table(
            bindings=bindings,
            text_items=tuple(item.as_input() for item in selected),
            options=options,
            table_index=len(tables),
            selected_run=run,
        )
        if table is not None:
            tables.append(table)
    return tuple(tables)


def _narrow_aligned_run(
    items: Sequence[_Item],
    *,
    bindings: BorderlessTableBindings,
    options: BorderlessTableOptions,
) -> tuple[tuple[tuple[_Item, ...], tuple[tuple[_Item, ...], ...]], ...]:
    """Require independent row, column and source-flow support for a narrow grid.

    Two prose columns can share all left edges. Unlike the wider stable-grid
    path, this conservative fallback therefore requires compact cells, separated
    physical rows, repeated column anchors and source flow contiguous by row.
    Every item must participate; a heading or conflicting paragraph is not
    discarded to make a candidate fit. The existing cell builder still applies
    occupancy, containment and page bounds, including explicit missing cells.
    """
    if not items or any(
        not all(
            isfinite(value)
            for value in (
                item.geometry.x0,
                item.geometry.y0,
                item.geometry.x1,
                item.geometry.y1,
            )
        )
        or _width(item.geometry) <= 0
        or _height(item.geometry) <= 0
        or item.fact.rotation != 0
        or item.fact.warnings
        for item in items
    ):
        return ()
    text_height = median(tuple(_height(item.geometry) for item in items))
    rows = _cluster_items(
        items,
        axis="row",
        tolerance=max(options.coordinate_tolerance, text_height * 0.6),
    )
    if len(rows) < options.minimum_rows:
        return ()
    selected = tuple(
        (row, _logical_row_cells(row, maximum_gap=text_height * 0.75)) for row in rows
    )
    column_count = max(len(cells) for _row, cells in selected)
    if not options.minimum_columns <= column_count < 4:
        return ()
    complete_rows = tuple(
        cells for _row, cells in selected if len(cells) == column_count
    )
    if len(complete_rows) < 2:
        return ()
    anchor_tolerance = max(options.coordinate_tolerance, text_height * 0.25)
    anchors = tuple(
        median(
            tuple(
                min(item.geometry.x0 for item in cells[column])
                for cells in complete_rows
            )
        )
        for column in range(column_count)
    )
    for row, cells in selected:
        if len(cells) < column_count - 1:
            return ()
        if (
            min(item.geometry.y1 for item in row)
            - max(item.geometry.y0 for item in row)
            < min(_height(item.geometry) for item in row) * 0.55
        ):
            return ()
        assigned = set()
        for cell in cells:
            left = min(item.geometry.x0 for item in cell)
            right = max(item.geometry.x1 for item in cell)
            if right - left > bindings.page_width * options.maximum_text_width_ratio:
                return ()
            matches = tuple(
                index
                for index, anchor in enumerate(anchors)
                if abs(left - anchor) <= anchor_tolerance
            )
            if len(matches) != 1 or matches[0] in assigned:
                return ()
            assigned.add(matches[0])
    starts = tuple(min(item.geometry.y0 for item in row) for row in rows)
    pitches = tuple(right - left for left, right in zip(starts, starts[1:]))
    if (
        min(pitches) < text_height * 1.5
        or max(pitches) - min(pitches) > anchor_tolerance
    ):
        return ()
    physical_order = tuple(
        item.fact.fact_id
        for _row, cells in selected
        for cell in cells
        for item in sorted(cell, key=lambda item: item.geometry.x0)
    )
    source_order = tuple(
        item.fact.fact_id
        for item in sorted(
            items, key=lambda item: (item.fact.source_order, item.fact.fact_id)
        )
    )
    if physical_order != source_order:
        return ()
    return selected


def _partition_right_extent(
    run: Sequence[tuple[tuple[_Item, ...], tuple[tuple[_Item, ...], ...]]],
    *,
    separating_gutter_center: float,
    text_height: float,
    inset: float,
) -> float:
    column_count = max(len(cells) for _row, cells in run)
    complete_rows = tuple(cells for _row, cells in run if len(cells) == column_count)
    right_edges = tuple(
        max(item.geometry.x1 for item in cells[-1]) for cells in complete_rows
    )
    stable_physical_extent = separating_gutter_center
    if max(right_edges) - min(right_edges) <= text_height * 0.6:
        stable_physical_extent = round(median(right_edges) + inset, 6)
    return min(
        separating_gutter_center,
        stable_physical_extent,
        _aligned_run_right_extent(
            run,
            text_height=text_height,
            inset=inset,
        ),
    )


def _aligned_run_right_extent(
    run: Sequence[tuple[tuple[_Item, ...], tuple[tuple[_Item, ...], ...]]],
    *,
    text_height: float,
    inset: float,
) -> float:
    column_count = max(len(cells) for _row, cells in run)
    complete_rows = tuple(cells for _row, cells in run if len(cells) == column_count)
    starts = tuple(
        median(
            tuple(
                min(item.geometry.x0 for item in cells[column])
                for cells in complete_rows
            )
        )
        for column in range(column_count)
    )
    gaps = tuple(right - left for left, right in zip(starts, starts[1:]))
    if not gaps:
        return max(item.geometry.x1 for row, _cells in run for item in row) + inset
    return round(starts[-1] + median(gaps) - inset, 6)


def build_borderless_aligned_table(
    *,
    bindings: BorderlessTableBindings,
    text_items: Sequence[tuple[PdfTextFact, PdfLayoutNode] | TableTextView],
    options: BorderlessTableOptions,
    table_index: int = 0,
    region_x0: float | None = None,
    region_x1: float | None = None,
    selected_run: Sequence[tuple[tuple[_Item, ...], tuple[tuple[_Item, ...], ...]]]
    | None = None,
    shared_row_envelope_height: float | None = None,
) -> PdfTable | None:
    """Reconstruct a page-local table from stable word alignment and whitespace."""
    items = _text_items(text_items)
    minimum_items = options.minimum_rows * options.minimum_columns
    if len(items) < minimum_items:
        return None
    stable, text_height = _stable_aligned_runs(items, options=options)
    if selected_run is None:
        if not stable:
            return None
        selected = max(stable, key=lambda run: (len(run), len(run[0][1])))
    else:
        selected = tuple(selected_run)
    row_groups = tuple(row for row, _cells in selected)
    column_count = max(len(cells) for _row, cells in selected)
    complete_rows = tuple(
        cells for _row, cells in selected if len(cells) == column_count
    )
    if not complete_rows:
        return None
    row_count = len(row_groups)
    row_coordinates = _aligned_row_boundaries(
        row_groups,
        text_height=(
            text_height
            if shared_row_envelope_height is None
            else shared_row_envelope_height
        ),
    )
    column_coordinates = _aligned_column_boundaries(
        complete_rows,
        text_height=text_height,
        page_width=bindings.page_width,
        selected_right_edge=max(
            item.geometry.x1 for row, _cells in selected for item in row
        ),
        region_x0=region_x0,
        region_x1=region_x1,
    )
    if row_coordinates is None or column_coordinates is None:
        return None
    assignments: dict[tuple[int, int], list[_Item]] = {}
    for row_index, (_row, cells) in enumerate(selected):
        for cell in cells:
            center = _mean((item.geometry.x0 + item.geometry.x1) / 2 for item in cell)
            matches = tuple(
                column
                for column, (left, right) in enumerate(
                    zip(column_coordinates, column_coordinates[1:])
                )
                if left <= center <= right
            )
            if len(matches) != 1 or (row_index, matches[0]) in assignments:
                return None
            assignments[(row_index, matches[0])] = list(cell)
    adjusted_boundaries = [column_coordinates[0]]
    for column in range(column_count - 1):
        left_items = tuple(
            item
            for (row, assigned_column), values in assignments.items()
            if assigned_column == column
            for item in values
        )
        right_items = tuple(
            item
            for (row, assigned_column), values in assignments.items()
            if assigned_column == column + 1
            for item in values
        )
        if not left_items or not right_items:
            return None
        left_end = max(item.geometry.x1 for item in left_items)
        right_start = min(item.geometry.x0 for item in right_items)
        if left_end >= right_start:
            return None
        adjusted_boundaries.append(round((left_end + right_start) / 2, 6))
    adjusted_boundaries.append(column_coordinates[-1])
    column_coordinates = tuple(adjusted_boundaries)
    occupancy = len(assignments) / (row_count * column_count)
    if occupancy < options.minimum_occupancy:
        return None
    sparse_columns = sum(
        sum((row, column) in assignments for row in range(row_count)) < row_count - 1
        for column in range(column_count)
    )
    if sparse_columns > 1:
        return None
    table_geometry = PdfBoundingBox(
        x0=column_coordinates[0],
        y0=row_coordinates[0],
        x1=column_coordinates[-1],
        y1=row_coordinates[-1],
    )
    if not _within_page(table_geometry, bindings=bindings):
        return None

    items = tuple(item for row in row_groups for item in row)
    all_items = tuple(
        sorted(
            items,
            key=lambda item: (
                item.geometry.y0,
                item.geometry.x0,
                item.node.source_order,
                item.node.node_id,
            ),
        )
    )
    table_evidence = _evidence(
        bindings,
        geometry=table_geometry,
        items=all_items,
        categories=(
            "intercell_whitespace",
            "repeated_row_alignment",
            "stable_borderless_column_anchors",
        ),
    )

    complete = len(assignments) == row_count * column_count
    table_cells: list[PdfTableCell] = []
    for row in range(row_count):
        for column in range(column_count):
            assigned = tuple(
                sorted(
                    assignments.get((row, column), ()),
                    key=lambda item: (
                        item.geometry.y0,
                        item.geometry.x0,
                        item.node.source_order,
                        item.node.node_id,
                    ),
                )
            )
            geometry = PdfBoundingBox(
                x0=column_coordinates[column],
                y0=row_coordinates[row],
                x1=column_coordinates[column + 1],
                y1=row_coordinates[row + 1],
            )
            if any(
                not _bbox_inside(item.geometry, geometry, options.coordinate_tolerance)
                for item in assigned
            ):
                return None
            observed = assigned
            ownership_unproven = any(
                not _bbox_inside(item.geometry, geometry, 0.0) for item in observed
            )
            if ownership_unproven:
                # Alignment selects a candidate cell, not physical ownership.
                # Retain the candidate's source evidence without projecting its
                # text into a cell that does not contain every selected item.
                assigned = ()
                complete = False
            role, role_status, role_evidence = _role(
                row=row,
                column=column,
                row_count=row_count,
                column_count=column_count,
                assigned=assigned,
            )
            if not assigned:
                role_status = "CANDIDATE"
            evidence = _evidence(
                bindings,
                geometry=geometry,
                items=observed,
                categories=(
                    "borderless_alignment_cell",
                    "intercell_whitespace",
                    "text_cell_ownership_unproven"
                    if ownership_unproven
                    else "text_inside_cell"
                    if assigned
                    else "unoccupied_grid_position",
                ),
            )
            values = {
                "row_start": row,
                "row_span": 1,
                "column_start": column,
                "column_span": 1,
                "geometry": geometry,
                "text": _project_text(assigned),
                "text_fact_ids": tuple(
                    sorted({item.fact.fact_id for item in assigned})
                ),
                "text_layout_node_ids": tuple(
                    sorted({item.node.node_id for item in assigned})
                ),
                "text_assignment_evidence": (
                    tuple(
                        sorted(
                            {
                                "stable_column_anchor",
                                "stable_row_band",
                                *(
                                    "member_selection:" + item.view.binding.binding_id
                                    for item in assigned
                                    if item.view is not None
                                ),
                            }
                        )
                    )
                    if assigned
                    else ()
                ),
                "state": "PROVEN" if assigned else "AMBIGUOUS",
                "role": role,
                "role_status": role_status,
                "role_evidence": role_evidence,
                "empty_cell_evidence": (),
                "evidence": evidence,
                "limitation_codes": (
                    ("borderless_cell_ownership_unproven",)
                    if ownership_unproven
                    else ()
                    if assigned
                    else ("borderless_empty_position_unproven",)
                ),
            }
            projected_cell = _identified(PdfTableCell, "cell_id", "cell", values)
            if (
                bindings.text_evidence is not None
                and not bindings.text_evidence.reserve_projection(
                    PdfTableCellTextProjection(
                        cell_id=projected_cell.cell_id,
                        method="borderless_cell_text.v1",
                        parts=_text_projection_parts(assigned),
                    )
                )
            ):
                return None
            table_cells.append(projected_cell)
    cells_tuple = tuple(table_cells)

    rows = tuple(
        _identified(
            PdfTableRow,
            "row_id",
            "row",
            {
                "row_index": row,
                "geometry": PdfBoundingBox(
                    x0=column_coordinates[0],
                    y0=row_coordinates[row],
                    x1=column_coordinates[-1],
                    y1=row_coordinates[row + 1],
                ),
                "anchor_cell_ids": tuple(
                    sorted(
                        cell.cell_id for cell in cells_tuple if cell.row_start == row
                    )
                ),
                "evidence": table_evidence,
            },
        )
        for row in range(row_count)
    )
    columns = tuple(
        _identified(
            PdfTableColumn,
            "column_id",
            "column",
            {
                "column_index": column,
                "geometry": PdfBoundingBox(
                    x0=column_coordinates[column],
                    y0=row_coordinates[0],
                    x1=column_coordinates[column + 1],
                    y1=row_coordinates[-1],
                ),
                "anchor_cell_ids": tuple(
                    sorted(
                        cell.cell_id
                        for cell in cells_tuple
                        if cell.column_start == column
                    )
                ),
                "evidence": table_evidence,
            },
        )
        for column in range(column_count)
    )
    row_boundaries = tuple(
        _identified(
            PdfTableAxisBoundary,
            "boundary_id",
            "axis-boundary",
            {
                "axis": "ROW",
                "boundary_index": index,
                "coordinate": coordinate,
                "evidence": table_evidence,
                "state": "PROVEN",
            },
        )
        for index, coordinate in enumerate(row_coordinates)
    )
    column_boundaries = tuple(
        _identified(
            PdfTableAxisBoundary,
            "boundary_id",
            "axis-boundary",
            {
                "axis": "COLUMN",
                "boundary_index": index,
                "coordinate": coordinate,
                "evidence": table_evidence,
                "state": "PROVEN",
            },
        )
        for index, coordinate in enumerate(column_coordinates)
    )
    values = {
        "table_index": table_index,
        "geometry": table_geometry,
        "state": "COMPLETE" if complete else "PARTIAL",
        "row_boundaries": row_boundaries,
        "column_boundaries": column_boundaries,
        "rows": rows,
        "columns": columns,
        "cells": cells_tuple,
        "evidence": table_evidence,
        "limitation_codes": tuple(
            sorted(
                {"borderless_table_intent_not_independently_proven"}
                | {code for cell in cells_tuple for code in cell.limitation_codes}
            )
        ),
    }
    return _identified(PdfTable, "table_id", "table", values)


def _independent_horizontal_partitions(
    items: Sequence[_Item], *, options: BorderlessTableOptions
) -> tuple[tuple[tuple[_Item, ...], tuple[_Item, ...]], float] | None:
    if not items:
        return None
    text_height = median(tuple(max(0.1, _height(item.geometry)) for item in items))
    ordered = tuple(sorted(items, key=lambda item: item.geometry.x0))
    cuts = tuple(
        (left.geometry.x1 + right.geometry.x0) / 2
        for left, right in zip(ordered, ordered[1:])
        if right.geometry.x0 - left.geometry.x1 > text_height * 1.5
    )
    accepted = []
    for cut in cuts:
        if any(item.geometry.x0 < cut < item.geometry.x1 for item in items):
            continue
        left = tuple(item for item in items if item.geometry.x1 <= cut)
        right = tuple(item for item in items if item.geometry.x0 >= cut)
        left_runs, _ = _partition_aligned_runs(left, options=options)
        right_runs, _ = _partition_aligned_runs(right, options=options)
        if not left_runs or not right_runs:
            continue
        left_best = max(left_runs, key=lambda run: len(run) * len(run[0][1]))
        right_best = max(right_runs, key=lambda run: len(run) * len(run[0][1]))
        if abs(len(left_best) - len(right_best)) < 3:
            continue
        score = len(left_best) * len(left_best[0][1]) + len(right_best) * len(
            right_best[0][1]
        )
        shared_capacity = (len(left_best) + len(right_best)) * min(
            len(left_best[0][1]), len(right_best[0][1])
        )
        accepted.append((shared_capacity, score, cut, left, right))
    if not accepted:
        return None
    _shared_capacity, _score, cut, left, right = max(
        accepted,
        key=lambda value: (value[0], value[1], value[2]),
    )
    return (left, right), cut


def _nested_detail_partition_runs(
    coarse_items: Sequence[_Item],
    detail_items: Sequence[_Item],
    *,
    options: BorderlessTableOptions,
) -> tuple[tuple[tuple[tuple[_Item, ...], tuple[tuple[_Item, ...], ...]], ...], ...]:
    coarse_runs, text_height = _partition_aligned_runs(coarse_items, options=options)
    detail_runs, _ = _partition_aligned_runs(detail_items, options=options)
    if not coarse_runs or not detail_runs:
        return ()
    all_items = tuple((*coarse_items, *detail_items))
    paired: list[
        tuple[tuple[tuple[_Item, ...], tuple[tuple[_Item, ...], ...]], ...]
    ] = []
    used_detail_runs: set[int] = set()
    for coarse in coarse_runs:
        coarse_y0 = min(item.geometry.y0 for row, _cells in coarse for item in row)
        coarse_y1 = max(item.geometry.y1 for row, _cells in coarse for item in row)
        candidates = tuple(
            (index, detail)
            for index, detail in enumerate(detail_runs)
            if index not in used_detail_runs
            and min(item.geometry.y0 for row, _cells in detail for item in row)
            < coarse_y1
            and max(item.geometry.y1 for row, _cells in detail for item in row)
            > coarse_y0
        )
        folded = None
        selected_index = None
        for index, detail in candidates:
            detail = _include_sparse_nested_detail_rows(
                detail_items,
                coarse=coarse,
                detail=detail,
                text_height=text_height,
                options=options,
            )
            folded = _fold_nested_detail_run(
                coarse,
                detail,
                all_items=all_items,
                text_height=text_height,
                options=options,
            )
            if folded is not None:
                selected_index = index
                break
        if folded is None or selected_index is None:
            return ()
        paired.append(folded)
        used_detail_runs.add(selected_index)
    if len(paired) != len(detail_runs):
        return ()
    return tuple(paired)


def _include_sparse_nested_detail_rows(
    detail_items: Sequence[_Item],
    *,
    coarse: Sequence[tuple[tuple[_Item, ...], tuple[tuple[_Item, ...], ...]]],
    detail: Sequence[tuple[tuple[_Item, ...], tuple[tuple[_Item, ...], ...]]],
    text_height: float,
    options: BorderlessTableOptions,
) -> tuple[tuple[tuple[_Item, ...], tuple[tuple[_Item, ...], ...]], ...]:
    """Retain wrapped detail lines that temporarily lose one column anchor."""
    if not coarse or not detail or len(detail[0][1]) != 2:
        return tuple(detail)
    coarse_centers = tuple(
        _mean(_center_y(item.geometry) for item in row) for row, _cells in coarse
    )
    if len(coarse_centers) < 2:
        return tuple(detail)
    dominant_coarse_count = max(len(cells) for _row, cells in coarse)
    body_centers = (
        coarse_centers[1:]
        if len(coarse[0][1]) < dominant_coarse_count
        else coarse_centers
    )
    typical_gap = median(
        tuple(right - left for left, right in zip(body_centers, body_centers[1:]))
    )
    lower = body_centers[0] - text_height
    upper = body_centers[-1] + typical_gap - text_height
    raw_rows = _cluster_items(
        detail_items,
        axis="row",
        tolerance=max(options.coordinate_tolerance, text_height * 0.6),
    )
    physical_rows: list[tuple[_Item, ...]] = []
    for row in raw_rows:
        if physical_rows and (
            _mean(_center_y(item.geometry) for item in row)
            - _mean(_center_y(item.geometry) for item in physical_rows[-1])
            <= text_height * 1.5
        ):
            physical_rows[-1] = tuple((*physical_rows[-1], *row))
        else:
            physical_rows.append(row)
    expanded = tuple(
        (row, cells)
        for row in physical_rows
        if lower <= _mean(_center_y(item.geometry) for item in row) < upper
        and 1
        <= len(cells := _logical_row_cells(row, maximum_gap=text_height * 0.75))
        <= len(detail[0][1])
    )
    if len(expanded) <= len(detail) or sum(len(row) for row, _cells in expanded) != len(
        {item.node.node_id for row, _cells in expanded for item in row}
    ):
        return tuple(detail)
    return expanded


def _side_by_side_nested_runs(
    items: Sequence[_Item], *, options: BorderlessTableOptions
) -> tuple[tuple[tuple[tuple[_Item, ...], tuple[tuple[_Item, ...], ...]], ...], ...]:
    if not items:
        return ()
    text_height = median(tuple(max(0.1, _height(item.geometry)) for item in items))
    ordered = tuple(sorted(items, key=lambda item: item.geometry.x0))
    cuts = tuple(
        (left.geometry.x1 + right.geometry.x0) / 2
        for left, right in zip(ordered, ordered[1:])
        if right.geometry.x0 - left.geometry.x1 > text_height * 1.5
    )
    candidates = []
    for cut in cuts:
        if any(item.geometry.x0 < cut < item.geometry.x1 for item in items):
            continue
        left = tuple(item for item in items if item.geometry.x1 <= cut)
        right = tuple(item for item in items if item.geometry.x0 >= cut)
        nested_sections = []
        for partition in (left, right):
            inner = _independent_horizontal_partitions(partition, options=options)
            if inner is None:
                break
            folded = _nested_detail_partition_runs(*inner[0], options=options)
            if len(folded) != 1:
                break
            nested_sections.append(folded[0])
        if len(nested_sections) == 2:
            candidates.append((len(left) + len(right), cut, tuple(nested_sections)))
    if not candidates:
        return ()
    return max(candidates, key=lambda value: (value[0], value[1]))[2]


def _independently_proven_nested_region_runs(
    items: Sequence[_Item], *, options: BorderlessTableOptions
) -> tuple[tuple[tuple[tuple[_Item, ...], tuple[tuple[_Item, ...], ...]], ...], ...]:
    if not items:
        return ()
    text_height = median(tuple(max(0.1, _height(item.geometry)) for item in items))
    ordered = tuple(sorted(items, key=lambda item: item.geometry.x0))
    cuts = tuple(
        (left.geometry.x1 + right.geometry.x0) / 2
        for left, right in zip(ordered, ordered[1:])
        if right.geometry.x0 - left.geometry.x1 > text_height * 1.5
    )
    candidates = []
    for cut in cuts:
        if any(item.geometry.x0 < cut < item.geometry.x1 for item in items):
            continue
        partitions = (
            tuple(item for item in items if item.geometry.x1 <= cut),
            tuple(item for item in items if item.geometry.x0 >= cut),
        )
        proven = []
        for partition in partitions:
            inner = _independent_horizontal_partitions(partition, options=options)
            if inner is None:
                continue
            folded = _nested_detail_partition_runs(*inner[0], options=options)
            if len(folded) == 1:
                proven.append(folded[0])
        if len(proven) == 1:
            member_count = sum(len(row) for row, _cells in proven[0])
            candidates.append((member_count, cut, tuple(proven)))
    if not candidates:
        return ()
    return max(candidates, key=lambda value: (value[0], value[1]))[2]


def _fold_nested_detail_run(
    coarse: Sequence[tuple[tuple[_Item, ...], tuple[tuple[_Item, ...], ...]]],
    detail: Sequence[tuple[tuple[_Item, ...], tuple[tuple[_Item, ...], ...]]],
    *,
    all_items: Sequence[_Item],
    text_height: float,
    options: BorderlessTableOptions,
) -> tuple[tuple[tuple[_Item, ...], tuple[tuple[_Item, ...], ...]], ...] | None:
    embedded_header = None
    initial_coarse_centers = tuple(
        _mean(_center_y(item.geometry) for item in row) for row, _cells in coarse
    )
    detail_centers = tuple(
        _mean(_center_y(item.geometry) for item in row) for row, _cells in detail
    )
    initial_coarse_gap = (
        median(
            tuple(
                right - left
                for left, right in zip(
                    initial_coarse_centers, initial_coarse_centers[1:]
                )
            )
        )
        if len(initial_coarse_centers) > 1
        else 0.0
    )
    dominant_coarse_count = max(
        (len(cells) for _row, cells in coarse),
        default=0,
    )
    if (
        len(coarse) > options.minimum_rows
        and initial_coarse_centers
        and detail_centers
        and initial_coarse_gap > 0
        and (
            detail_centers[0] - initial_coarse_centers[0] > initial_coarse_gap * 0.5
            or (
                len(coarse[0][1]) < dominant_coarse_count
                and detail_centers[0] > initial_coarse_centers[0]
            )
        )
    ):
        embedded_header = coarse[0]
        coarse = coarse[1:]
    coarse_count = len(coarse[0][1])
    if (
        coarse_count < 3
        or len(detail[0][1]) >= coarse_count
        or len(detail) < len(coarse) * 2
    ):
        return None
    coarse_centers = tuple(
        _mean(_center_y(item.geometry) for item in row) for row, _cells in coarse
    )
    if len(coarse_centers) < 2:
        return None
    typical_gap = median(
        tuple(right - left for left, right in zip(coarse_centers, coarse_centers[1:]))
    )
    grouped_detail: list[tuple[_Item, ...]] = []
    grouped_detail_row_counts: list[int] = []
    for index, center in enumerate(coarse_centers):
        lower = center - text_height
        upper = (
            coarse_centers[index + 1] - text_height
            if index + 1 < len(coarse_centers)
            else center + typical_gap - text_height
        )
        members = tuple(
            item
            for (row, _cells), detail_center in zip(detail, detail_centers)
            if lower <= detail_center < upper
            for item in row
        )
        if not members:
            return None
        grouped_detail.append(members)
        grouped_detail_row_counts.append(
            sum(lower <= detail_center < upper for detail_center in detail_centers)
        )
    if any(count < 2 for count in grouped_detail_row_counts) or sum(
        grouped_detail_row_counts
    ) != len(detail):
        return None
    raw_rows = _cluster_items(
        all_items,
        axis="row",
        tolerance=max(options.coordinate_tolerance, text_height * 0.6),
    )
    if embedded_header is not None:
        header = embedded_header
    else:
        header_candidates = tuple(
            (row, _logical_row_cells(row, maximum_gap=text_height * 0.75))
            for row in raw_rows
            if _mean(_center_y(item.geometry) for item in row) < coarse_centers[0]
        )
        header_candidates = tuple(
            (row, cells)
            for row, cells in header_candidates
            if len(cells) == coarse_count
        )
        if not header_candidates:
            return None
        header = max(
            header_candidates,
            key=lambda value: _mean(_center_y(item.geometry) for item in value[0]),
        )
    combined = [header]
    for (coarse_row, coarse_cells), detail_members in zip(coarse, grouped_detail):
        if len(coarse_cells) not in {coarse_count, coarse_count - 1}:
            return None
        last_cell = tuple(
            sorted(
                (*coarse_cells[-1], *detail_members),
                key=lambda item: (
                    item.geometry.y0,
                    item.geometry.x0,
                    item.node.source_order,
                ),
            )
        )
        row = tuple((*coarse_row, *detail_members))
        combined.append((row, tuple((*coarse_cells[:-1], last_cell))))
    return tuple(combined)


def _partition_aligned_runs(
    items: Sequence[_Item], *, options: BorderlessTableOptions
) -> tuple[
    tuple[
        tuple[tuple[tuple[_Item, ...], tuple[tuple[_Item, ...], ...]], ...],
        ...,
    ],
    float,
]:
    heights = tuple(max(0.1, _height(item.geometry)) for item in items)
    if not heights:
        return (), 0.0
    text_height = median(heights)
    raw_rows = _cluster_items(
        items,
        axis="row",
        tolerance=max(options.coordinate_tolerance, text_height * 0.6),
    )
    physical_rows: list[tuple[_Item, ...]] = []
    for row in raw_rows:
        if physical_rows and (
            _mean(_center_y(item.geometry) for item in row)
            - _mean(_center_y(item.geometry) for item in physical_rows[-1])
            <= text_height * 1.5
        ):
            physical_rows[-1] = tuple((*physical_rows[-1], *row))
        else:
            physical_rows.append(row)
    eligible = tuple(
        (row, cells)
        for row in physical_rows
        if len(cells := _logical_row_cells(row, maximum_gap=text_height * 0.75))
        >= options.minimum_columns
    )
    if not eligible:
        return (), text_height
    counts = tuple(len(cells) for _row, cells in eligible)
    dominant_count = max(set(counts), key=lambda count: (counts.count(count), count))
    anchors = tuple(item for item in eligible if len(item[1]) == dominant_count)
    if len(anchors) < options.minimum_rows:
        return (), text_height
    centers = tuple(
        _mean(_center_y(item.geometry) for item in row) for row, _cells in eligible
    )
    local_gaps = tuple(
        right - left for left, right in zip(centers, centers[1:]) if right > left
    )
    typical_gap = median(local_gaps) if local_gaps else text_height * 3
    runs: list[list[tuple[tuple[_Item, ...], tuple[tuple[_Item, ...], ...]]]] = []
    previous_center: float | None = None
    for (row, cells), center in zip(eligible, centers):
        aligned = len(cells) == dominant_count or (
            len(cells) == dominant_count - 1
            and _row_cells_align_to_run_columns(
                cells,
                run=anchors,
                text_height=text_height,
                allow_right_edge_alignment=True,
            )
        )
        if not aligned:
            previous_center = None
            continue
        if previous_center is None or center - previous_center > typical_gap * 1.5:
            runs.append([])
        runs[-1].append((row, cells))
        previous_center = center
    return (
        tuple(tuple(run) for run in runs if len(run) >= options.minimum_rows),
        text_height,
    )


def _stable_aligned_runs(
    items: Sequence[_Item], *, options: BorderlessTableOptions
) -> tuple[
    tuple[
        tuple[tuple[tuple[_Item, ...], tuple[tuple[_Item, ...], ...]], ...],
        ...,
    ],
    float,
]:
    heights = tuple(max(0.1, _height(item.geometry)) for item in items)
    if not heights:
        return (), 0.0
    text_height = median(heights)
    row_tolerance = max(options.coordinate_tolerance, text_height * 0.6)
    raw_rows = _cluster_items(items, axis="row", tolerance=row_tolerance)
    eligible = tuple(
        (row, cells)
        for row in raw_rows
        if len(cells := _logical_row_cells(row, maximum_gap=text_height * 0.75)) >= 4
    )
    runs: list[list[tuple[tuple[_Item, ...], tuple[tuple[_Item, ...], ...]]]] = []
    for row, cells in eligible:
        if runs and len(runs[-1][-1][1]) == len(cells):
            runs[-1].append((row, cells))
        else:
            runs.append([(row, cells)])
    stable = tuple(
        tuple(run)
        for run in runs
        if len(run) >= options.minimum_rows
        and len(run[0][1]) >= options.minimum_columns
    )
    expanded = []
    for run in stable:
        first_row = run[0][0]
        first_index = next(
            index for index, (row, _cells) in enumerate(eligible) if row is first_row
        )
        centers: list[float] = [
            _mean(_center_y(item.geometry) for item in row) for row, _cells in run
        ]
        if not centers:
            continue
        typical_gap = (
            median(tuple(right - left for left, right in zip(centers, centers[1:])))
            if len(centers) > 1
            else text_height * 3
        )
        prefix = []
        next_center = centers[0]
        for row, cells in reversed(eligible[:first_index]):
            center = _mean(_center_y(item.geometry) for item in row)
            if next_center - center > typical_gap * 1.5:
                break
            if not _row_cells_align_to_run_columns(
                cells,
                run=run,
                text_height=text_height,
            ):
                continue
            prefix.append((row, cells))
            next_center = center
        suffix = []
        last_row = run[-1][0]
        last_index = next(
            index for index, (row, _cells) in enumerate(eligible) if row is last_row
        )
        candidate_index = last_index + 1
        if candidate_index < len(eligible):
            candidate_row, candidate_cells = eligible[candidate_index]
            candidate_center = _mean(_center_y(item.geometry) for item in candidate_row)
            reaches_section_end = candidate_index + 1 == len(eligible)
            if not reaches_section_end:
                following_row = eligible[candidate_index + 1][0]
                following_center = _mean(
                    _center_y(item.geometry) for item in following_row
                )
                reaches_section_end = (
                    following_center - candidate_center > typical_gap * 1.5
                )
            if (
                len(candidate_cells) < len(run[0][1])
                and candidate_center - centers[-1] <= typical_gap * 1.5
                and reaches_section_end
                and _row_cells_align_to_run_columns(
                    candidate_cells,
                    run=run,
                    text_height=text_height,
                    allow_right_edge_alignment=True,
                )
            ):
                suffix.append((candidate_row, candidate_cells))
        expanded.append(tuple((*reversed(prefix), *run, *suffix)))
    maximal = tuple(
        run
        for run in expanded
        if not any(
            run is not other
            and {id(row) for row, _cells in run} < {id(row) for row, _cells in other}
            for other in expanded
        )
    )
    return maximal, text_height


def _row_cells_align_to_run_columns(
    cells: Sequence[tuple[_Item, ...]],
    *,
    run: Sequence[tuple[tuple[_Item, ...], tuple[tuple[_Item, ...], ...]]],
    text_height: float,
    allow_right_edge_alignment: bool = False,
) -> bool:
    column_count = len(run[0][1])
    if len(cells) > column_count:
        return False
    if len(cells) == column_count:
        return True
    anchors = tuple(
        (
            median(
                tuple(
                    min(item.geometry.x0 for item in row_cells[column_index])
                    for _row, row_cells in run
                )
            ),
            median(
                tuple(
                    max(item.geometry.x1 for item in row_cells[column_index])
                    for _row, row_cells in run
                )
            ),
        )
        for column_index in range(column_count)
    )
    matched: set[int] = set()
    for cell in cells:
        start = min(item.geometry.x0 for item in cell)
        end = max(item.geometry.x1 for item in cell)
        center = (start + end) / 2
        candidates = tuple(
            (
                index,
                min(
                    abs(start - left_anchor),
                    abs(end - right_anchor)
                    if allow_right_edge_alignment
                    else float("inf"),
                    abs(center - (left_anchor + right_anchor) / 2),
                ),
            )
            for index, (left_anchor, right_anchor) in enumerate(anchors)
            if index not in matched
            and (
                abs(start - left_anchor) <= text_height
                or (
                    allow_right_edge_alignment
                    and abs(end - right_anchor) <= text_height
                )
                or start <= left_anchor <= end
                or (
                    (index == 0 or center >= (anchors[index - 1][1] + left_anchor) / 2)
                    and (
                        index + 1 == column_count
                        or center <= (right_anchor + anchors[index + 1][0]) / 2
                    )
                )
            )
        )
        if not candidates:
            return False
        column_index, _distance = min(
            candidates, key=lambda value: (value[1], value[0])
        )
        matched.add(column_index)
    return True


def _logical_row_cells(
    row: Sequence[_Item], *, maximum_gap: float
) -> tuple[tuple[_Item, ...], ...]:
    groups: list[list[_Item]] = []
    for item in sorted(row, key=lambda value: (value.geometry.x0, value.geometry.x1)):
        if (
            groups
            and item.geometry.x0 - max(member.geometry.x1 for member in groups[-1])
            <= maximum_gap
            and not (
                item.view is not None
                and all(member.view is not None for member in groups[-1])
                and all(
                    member.view.binding.binding_id != item.view.binding.binding_id
                    for member in groups[-1]
                    if member.view is not None
                )
            )
        ):
            groups[-1].append(item)
        else:
            groups.append([item])
    return tuple(tuple(group) for group in groups)


def _aligned_row_boundaries(
    groups: tuple[tuple[_Item, ...], ...], *, text_height: float
) -> tuple[float, ...] | None:
    starts = tuple(min(item.geometry.y0 for item in group) for group in groups)
    if len(starts) < 2:
        return None
    gaps = tuple(right - left for left, right in zip(starts, starts[1:]))
    if min(gaps) <= text_height:
        return None
    inset = text_height * 0.55
    return (
        round(starts[0] - inset, 6),
        *(round(start - inset, 6) for start in starts[1:]),
        round(starts[-1] + median(gaps) - inset, 6),
    )


def _aligned_column_boundaries(
    rows: tuple[tuple[tuple[_Item, ...], ...], ...],
    *,
    text_height: float,
    page_width: float,
    selected_right_edge: float,
    region_x0: float | None = None,
    region_x1: float | None = None,
) -> tuple[float, ...] | None:
    column_count = len(rows[0])
    starts = tuple(
        median(tuple(min(item.geometry.x0 for item in row[column]) for row in rows))
        for column in range(column_count)
    )
    ends = tuple(
        median(tuple(max(item.geometry.x1 for item in row[column]) for row in rows))
        for column in range(column_count)
    )
    if any(left >= right for left, right in zip(starts, starts[1:])):
        return None
    inset = text_height * 0.42
    x0 = round(starts[0] - inset if region_x0 is None else region_x0, 6)
    # A table's location on the page is not evidence for a mirrored right
    # margin. Bound the inferred final column from its actual members; explicit
    # partition bounds remain authoritative.
    right_edge = (
        min(page_width, selected_right_edge + inset) if region_x1 is None else region_x1
    )
    return (
        x0,
        *(round((left + right) / 2, 6) for left, right in zip(ends, starts[1:])),
        round(right_edge, 6),
    )


def _cluster_items(
    items: Sequence[_Item], *, axis: str, tolerance: float
) -> tuple[tuple[_Item, ...], ...]:
    coordinate = _center_y if axis == "row" else lambda bbox: bbox.x0
    groups: list[list[_Item]] = []
    for item in sorted(
        items,
        key=lambda value: (
            coordinate(value.geometry),
            value.node.source_order,
            value.node.node_id,
        ),
    ):
        if (
            groups
            and abs(
                coordinate(item.geometry)
                - _mean(coordinate(member.geometry) for member in groups[-1])
            )
            <= tolerance
        ):
            groups[-1].append(item)
        else:
            groups.append([item])
    return tuple(tuple(group) for group in groups)


def _row_boundaries(groups: tuple[tuple[_Item, ...], ...]) -> tuple[float, ...] | None:
    extents = tuple(
        (
            min(item.geometry.y0 for item in group),
            max(item.geometry.y1 for item in group),
        )
        for group in groups
    )
    if any(left[1] >= right[0] for left, right in zip(extents, extents[1:])):
        return None
    return (
        round(extents[0][0], 6),
        *(
            round((left[1] + right[0]) / 2, 6)
            for left, right in zip(extents, extents[1:])
        ),
        round(extents[-1][1], 6),
    )


def _column_boundaries(
    groups: tuple[tuple[_Item, ...], ...],
) -> tuple[float, ...] | None:
    ordered = tuple(
        sorted(groups, key=lambda group: _mean(item.geometry.x0 for item in group))
    )
    extents = tuple(
        (
            min(item.geometry.x0 for item in group),
            max(item.geometry.x1 for item in group),
        )
        for group in ordered
    )
    if any(left[1] >= right[0] for left, right in zip(extents, extents[1:])):
        return None
    return (
        round(extents[0][0], 6),
        *(
            round((left[1] + right[0]) / 2, 6)
            for left, right in zip(extents, extents[1:])
        ),
        round(extents[-1][1], 6),
    )


def _nearest_unique(
    value: float, coordinates: tuple[float, ...], *, tolerance: float
) -> int | None:
    matches = tuple(
        (abs(value - coordinate), index)
        for index, coordinate in enumerate(coordinates)
        if abs(value - coordinate) <= tolerance
    )
    if not matches:
        return None
    ordered = sorted(matches)
    if len(ordered) > 1 and ordered[0][0] == ordered[1][0]:
        return None
    return ordered[0][1]


def _evidence(
    bindings: BorderlessTableBindings,
    *,
    geometry: PdfBoundingBox,
    items: Sequence[_Item],
    categories: tuple[str, ...],
) -> PdfTableEvidence:
    return PdfTableEvidence(
        source_sha256=bindings.source_sha256,
        page_id=bindings.page_id,
        page_index=bindings.page_index,
        inherited_page_sidecar_id=bindings.inherited_page_sidecar_id,
        inherited_page_sidecar_sha256=bindings.inherited_page_sidecar_sha256,
        inherited_manifest_id=bindings.inherited_manifest_id,
        reading_page_sidecar_id=bindings.reading_page_sidecar_id,
        reading_page_sidecar_sha256=bindings.reading_page_sidecar_sha256,
        source_fact_ids=tuple(sorted({item.fact.fact_id for item in items})),
        source_layout_node_ids=tuple(sorted({item.node.node_id for item in items})),
        drawing_fact_ids=(),
        separator_candidate_ids=(),
        evidence_categories=tuple(sorted(set(categories))),
        geometry=geometry,
    )


def _role(
    *,
    row: int,
    column: int,
    row_count: int,
    column_count: int,
    assigned: Sequence[_Item],
) -> tuple[str, str, tuple[str, ...]]:
    if row == 0 and column_count >= 2:
        proven = bool(assigned) and all(
            _font_emphasized(item.fact) for item in assigned
        )
        return (
            "COLUMN_HEADER_LIKE",
            "PROVEN" if proven else "CANDIDATE",
            tuple(
                sorted(
                    {
                        "first_row_repeated_column_alignment",
                        *(("font_emphasis",) if proven else ()),
                    }
                )
            ),
        )
    if column == 0 and row_count >= 2:
        proven = bool(assigned) and all(
            _font_emphasized(item.fact) for item in assigned
        )
        return (
            "ROW_HEADER_LIKE",
            "PROVEN" if proven else "CANDIDATE",
            tuple(
                sorted(
                    {
                        "first_column_repeated_row_alignment",
                        *(("font_emphasis",) if proven else ()),
                    }
                )
            ),
        )
    return (
        "BODY_LIKE",
        "PROVEN" if assigned else "CANDIDATE",
        ("interior_table_position",),
    )


def _font_emphasized(fact: PdfTextFact) -> bool:
    font_name = (fact.font_name or "").casefold()
    return any(token in font_name for token in ("bold", "semibold", "demibold"))


def _ordered_text(
    items: Sequence[_Item],
) -> tuple[tuple[_Item, Literal["", " ", "\n"]], ...]:
    ordered = sorted(
        items,
        key=lambda item: (
            item.geometry.y0,
            item.geometry.x0,
            item.node.source_order,
            item.node.node_id,
        ),
    )
    result: list[tuple[_Item, Literal["", " ", "\n"]]] = []
    previous: _Item | None = None
    for current in ordered:
        separator: Literal["", " ", "\n"] = ""
        if previous is not None:
            same_line = abs(
                _center_y(previous.geometry) - _center_y(current.geometry)
            ) <= (max(_height(previous.geometry), _height(current.geometry)) * 0.6)
            separator = " " if same_line else "\n"
        result.append((current, separator))
        previous = current
    return tuple(result)


def _text_projection_parts(items: Sequence[_Item]) -> tuple[PdfTableCellTextPart, ...]:
    return tuple(
        PdfTableCellTextPart(
            source_fact_id=item.fact.fact_id,
            source_layout_node_id=item.node.node_id,
            member_binding_id=item.view.binding.binding_id
            if item.view is not None
            else None,
            separator_before=separator,
        )
        for item, separator in _ordered_text(items)
    )


def _project_text(items: Sequence[_Item]) -> str:
    return "".join(separator + item.text for item, separator in _ordered_text(items))


def _identified[ModelT: BaseModel](
    model: type[ModelT], field: str, kind: str, values: dict[str, Any]
) -> ModelT:
    complete = {
        name: definition.default
        for name, definition in model.model_fields.items()
        if name != field and not definition.is_required()
    } | values
    return model(**{field: table_structure_identifier(kind, complete), **complete})


def _bbox_inside(
    bbox: PdfBoundingBox, geometry: PdfBoundingBox, tolerance: float
) -> bool:
    return bool(
        bbox.x0 >= geometry.x0 - tolerance
        and bbox.y0 >= geometry.y0 - tolerance
        and bbox.x1 <= geometry.x1 + tolerance
        and bbox.y1 <= geometry.y1 + tolerance
    )


def _within_page(
    geometry: PdfBoundingBox, *, bindings: BorderlessTableBindings
) -> bool:
    return bool(
        geometry.x0 >= 0
        and geometry.y0 >= 0
        and geometry.x1 <= bindings.page_width
        and geometry.y1 <= bindings.page_height
    )


def _center_y(bbox: PdfBoundingBox) -> float:
    return (bbox.y0 + bbox.y1) / 2


def _width(bbox: PdfBoundingBox) -> float:
    return bbox.x1 - bbox.x0


def _height(bbox: PdfBoundingBox) -> float:
    return bbox.y1 - bbox.y0


def _mean(values: Iterable[float]) -> float:
    materialized = tuple(values)
    return sum(materialized) / len(materialized)

"""Exact member subsets used by a table, without inventing parent Facts."""

from __future__ import annotations

from typing import Any, Literal, cast

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    SerializerFunctionWrapHandler,
    model_serializer,
    model_validator,
)

from document_sdk.pdf._structural_engine.facts import (
    contracts as _facts,  # noqa: TC001 - Pydantic runtime fields.
)
from document_sdk.pdf._structural_engine.structure.identity import canonical_sha256


class PdfTableMemberBinding(BaseModel):
    """A same-parser, page-local selection under actual Fact and Layout IDs."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    schema_version: Literal["pdf_table_member_binding.v1"] = (
        "pdf_table_member_binding.v1"
    )
    binding_id: str = Field(pattern=r"^P3C-member-selection-[0-9a-f]{64}$")
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    parent_fact_id: str = Field(pattern=r"^PDFF-[0-9a-f]{24}$")
    parent_layout_node_id: str = Field(pattern=r"^PDFLN-[0-9a-f]{24}$")
    source_group_id: str
    member_ids: tuple[str, ...] = Field(min_length=1, max_length=100_000)
    text: str = Field(min_length=1, max_length=1_000_000)
    geometry: _facts.PdfBoundingBox
    partition_basis: Literal[
        "closed_physical_separator_grid", "repeated_member_whitespace_grid"
    ]
    projection: Literal["exact_member_concatenation"] = "exact_member_concatenation"

    @model_validator(mode="after")
    def validate_binding(self) -> PdfTableMemberBinding:
        if len(set(self.member_ids)) != len(self.member_ids):
            message = "table member selection contains duplicate occurrences"
            raise ValueError(message)
        if any(not value.startswith("PDFF-") for value in self.member_ids):
            message = "table member selection requires source member IDs"
            raise ValueError(message)
        expected = "P3C-member-selection-" + canonical_sha256(
            self.model_dump(exclude={"binding_id"})
        )
        if self.binding_id != expected:
            message = "table member selection identity mismatch"
            raise ValueError(message)
        return self


def make_member_binding(**values: object) -> PdfTableMemberBinding:
    """Include explicit schema/projection defaults in the content identity."""
    payload = {
        "schema_version": "pdf_table_member_binding.v1",
        "projection": "exact_member_concatenation",
        **values,
    }
    return PdfTableMemberBinding.model_validate(
        {
            **payload,
            "binding_id": "P3C-member-selection-" + canonical_sha256(payload),
        }
    )


class PdfTableCellTextPart(BaseModel):
    """One ordered source occurrence and its production-inserted separator."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    source_fact_id: str = Field(pattern=r"^PDFF-[0-9a-f]{24}$")
    source_layout_node_id: str = Field(pattern=r"^PDFLN-[0-9a-f]{24}$")
    member_binding_id: str | None = Field(
        default=None, pattern=r"^P3C-member-selection-[0-9a-f]{64}$"
    )
    source_anchored_overflow_id: str | None = Field(
        default=None, pattern=r"^P3C-source-anchored-overflow-[0-9a-f]{64}$"
    )
    separator_before: Literal["", " ", "\n"] = ""

    @model_serializer(mode="wrap")
    def serialize_legacy_part(
        self, handler: SerializerFunctionWrapHandler
    ) -> dict[str, Any]:
        """Keep earlier part bytes exact when no overflow proof is carried."""
        values = cast("dict[str, Any]", handler(self))
        if self.source_anchored_overflow_id is None:
            values.pop("source_anchored_overflow_id", None)
        return values

    @model_validator(mode="after")
    def validate_projection_kind(self) -> PdfTableCellTextPart:
        """A source occurrence uses either containment or explicit overflow proof."""
        if (
            self.source_anchored_overflow_id is not None
            and self.member_binding_id is not None
        ):
            message = "table text part cannot mix strict and overflow selections"
            raise ValueError(message)
        return self


class PdfTableCellTextProjection(BaseModel):
    """The actual ordered projection, independently replayable from its sources."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    cell_id: str = Field(pattern=r"^P3C-cell-[0-9a-f]{64}$")
    method: Literal[
        "ruled_cell_text.v1", "borderless_cell_text.v1", "source_anchored_cell_text.v1"
    ]
    parts: tuple[PdfTableCellTextPart, ...] = Field(max_length=65_536)

    @model_validator(mode="after")
    def validate_parts(self) -> PdfTableCellTextProjection:
        if self.parts and self.parts[0].separator_before:
            message = "table text projection cannot start with inserted whitespace"
            raise ValueError(message)
        identities = [
            (
                part.source_fact_id,
                part.source_layout_node_id,
                part.member_binding_id,
                part.source_anchored_overflow_id,
            )
            for part in self.parts
        ]
        if len(identities) != len(set(identities)):
            message = "table cell text projection repeats a source occurrence"
            raise ValueError(message)
        return self

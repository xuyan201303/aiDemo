# ruff: noqa: B905, C409, C901, D202, PERF401, PLR0911, PLR0912, PLR0913, PLR0915, PLR2004, PLW2901, PT018, RUF005, RUF007, S101, TC001, UP035, UP037, UP040

from __future__ import annotations

from collections import Counter
from dataclasses import asdict, dataclass
from hashlib import sha256
from math import isfinite
from statistics import median
from typing import Any, Callable, Final, Iterable, Literal, Sequence, TypeAlias, cast

from pydantic import BaseModel

from document_sdk.pdf._structural_engine.facts.contracts import (
    PdfBoundingBox,
    PdfDrawingFact,
    PdfPageFacts,
    PdfTextFact,
)
from document_sdk.pdf._structural_engine.layout.contracts import (
    PdfLayoutNode,
    PdfLayoutPageGraph,
    PdfLayoutSeparatorCandidate,
)

from . import table_borderless as _table_borderless
from . import table_contracts as _table_contracts
from .identity import canonical_sha256
from .native_event_ownership import SourceAnchoredOverflowProof
from .reading_contracts import (
    PdfReadingStructurePageReference,
    PdfReadingStructurePageSidecar,
)
from .reading_input import (
    PdfReadingPageAuthority,
    PdfReadingPageEvidence,
    validate_reference_sidecar,
)
from .table_member_contracts import (
    PdfTableCellTextPart,
    PdfTableCellTextProjection,
    PdfTableMemberBinding,
)
from .table_member_views import (
    TableTextView,
    partition_parent_at_grid,
    repeated_member_grid,
)
from .table_overflow_integration import try_source_anchored_table
from .table_text_evidence import TableTextEvidenceCollector

BorderlessTableBindings: TypeAlias = _table_borderless.BorderlessTableBindings
BorderlessTableOptions: TypeAlias = _table_borderless.BorderlessTableOptions
PdfTable: TypeAlias = _table_contracts.PdfTable
PdfTableAxisBoundary: TypeAlias = _table_contracts.PdfTableAxisBoundary
PdfTableCell: TypeAlias = _table_contracts.PdfTableCell
PdfTableColumn: TypeAlias = _table_contracts.PdfTableColumn
PdfTableEvidence: TypeAlias = _table_contracts.PdfTableEvidence
PdfTableRow: TypeAlias = _table_contracts.PdfTableRow
PdfTableStructurePageSidecar: TypeAlias = _table_contracts.PdfTableStructurePageSidecar
build_borderless_aligned_tables = _table_borderless.build_borderless_aligned_tables
build_table_page_sidecar = _table_contracts.build_table_page_sidecar
table_structure_identifier = _table_contracts.table_structure_identifier

_P3_T1_SDK_TABLE_DESIGN_VERSION: Final = (
    "document_sdk.pdf.phase3.table.algorithm_design.v7"
)


@dataclass(frozen=True)
class PdfTableAlgorithmConfig:
    """Publisher-neutral physical tolerances for the Phase 3C v1 detector."""

    coordinate_tolerance_page_ratio: float = 0.0015
    coordinate_tolerance_floor_points: float = 0.25
    coordinate_tolerance_ceiling_points: float = 2.0
    minimum_separator_confidence: float = 0.5
    minimum_atomic_cell_count: int = 2
    borderless_minimum_rows: int = 3
    borderless_minimum_columns: int = 2
    borderless_minimum_occupancy: float = 0.8
    borderless_maximum_text_width_ratio: float = 0.3
    thin_rule_maximum_thickness_multiplier: float = 1.25
    thin_rule_minimum_length_multiplier: float = 4.0
    implied_column_minimum_repeated_boundaries: int = 3
    weak_internal_axis_maximum_coverage: float = 0.5
    weak_axis_cluster_maximum_text_height_multiplier: float = 2.0
    rule_endpoint_connection_tolerance_multiplier: float = 2.0
    bevel_pair_maximum_tolerance_multiplier: float = 4.0
    header_dark_fill_maximum_luminance: float = 0.5
    header_fill_minimum_cell_coverage: float = 0.8
    maximum_member_views_per_page: int = 4096
    maximum_member_references_per_page: int = 100_000
    maximum_member_selection_bytes_per_page: int = 8 * 1024 * 1024

    @property
    def identity(self) -> str:
        return canonical_sha256(
            {
                "design_version": _P3_T1_SDK_TABLE_DESIGN_VERSION,
                "domain": "document_sdk.pdf.phase3.table.algorithm_config.v4",
                "values": asdict(self),
            }
        )


@dataclass(frozen=True)
class PdfTablePageInput:
    source_sha256: str
    facts: PdfPageFacts
    layout: "PdfTableLayoutEvidence"
    inherited_page_sidecar_id: str
    inherited_page_sidecar_sha256: str
    inherited_manifest_id: str
    reading_page_sidecar_id: str | None
    reading_page_sidecar_sha256: str | None
    dependency_identity: str

    @property
    def page_id(self) -> str:
        return self.facts.page_id

    @property
    def page_index(self) -> int:
        return self.facts.page_number - 1


@dataclass(frozen=True)
class PdfTableLayoutEvidence:
    page_id: str
    page_number: int
    canonical_width: float
    canonical_height: float
    rotation: int
    nodes: tuple[PdfLayoutNode, ...]
    separator_candidates: tuple[PdfLayoutSeparatorCandidate, ...]
    build_status: str
    resource_truncation: bool
    source_geometry_completeness: float
    invalid_geometry_fact_ids: tuple[str, ...]


@dataclass(frozen=True)
class _Segment:
    orientation: str
    coordinate: float
    start: float
    end: float
    separator_candidate_ids: tuple[str, ...]
    drawing_node_ids: tuple[str, ...]
    drawing_fact_ids: tuple[str, ...]
    derivations: tuple[str, ...]
    physical_intervals: tuple[tuple[float, float], ...] = ()

    def __post_init__(self) -> None:
        if self.physical_intervals:
            return
        if any(
            derivation
            in {
                "layout_separator_candidate",
                "thin_line_rule",
                "thin_rectangle_rule",
            }
            for derivation in self.derivations
        ):
            object.__setattr__(self, "physical_intervals", ((self.start, self.end),))


@dataclass(frozen=True)
class _TextItem:
    fact: PdfTextFact
    node: PdfLayoutNode
    geometry: PdfBoundingBox
    view: TableTextView | None = None

    @property
    def text(self) -> str:
        return self.view.text if self.view is not None else self.fact.text


@dataclass(frozen=True)
class _GridCandidate:
    horizontals: tuple[_Segment, ...]
    verticals: tuple[_Segment, ...]
    row_coordinates: tuple[float, ...]
    column_coordinates: tuple[float, ...]

    @property
    def geometry(self) -> PdfBoundingBox:
        return PdfBoundingBox(
            x0=self.column_coordinates[0],
            y0=self.row_coordinates[0],
            x1=self.column_coordinates[-1],
            y1=self.row_coordinates[-1],
        )


class _UnionFind:
    def __init__(self, size: int) -> None:
        self.parent = list(range(size))

    def find(self, value: int) -> int:
        while self.parent[value] != value:
            self.parent[value] = self.parent[self.parent[value]]
            value = self.parent[value]
        return value

    def union(self, left: int, right: int) -> None:
        left_root = self.find(left)
        right_root = self.find(right)
        if left_root != right_root:
            self.parent[max(left_root, right_root)] = min(left_root, right_root)


def build_table_page_input(
    *,
    source_sha256: str,
    facts: PdfPageFacts,
    layout: PdfLayoutPageGraph | Any,
    inherited_page_sidecar_id: str,
    inherited_page_sidecar_sha256: str,
    inherited_manifest_id: str,
    reading_page_sidecar_id: str | None = None,
    reading_page_sidecar_sha256: str | None = None,
    dependency_identity: str,
) -> PdfTablePageInput:
    """Bind authoritative page-local Fact/Layout evidence for table analysis."""

    normalized_layout = _normalize_layout_evidence(layout)
    if (
        facts.page_id != normalized_layout.page_id
        or facts.page_number != normalized_layout.page_number
    ):
        message = "Phase 3C Fact/Layout physical-page identity mismatch"
        raise ValueError(message)
    if (
        facts.canonical_width != normalized_layout.canonical_width
        or facts.canonical_height != normalized_layout.canonical_height
        or facts.rotation != normalized_layout.rotation
    ):
        message = "Phase 3C Fact/Layout canonical geometry mismatch"
        raise ValueError(message)
    if len(source_sha256) != 64 or any(
        character not in "0123456789abcdef" for character in source_sha256
    ):
        message = "Phase 3C source SHA-256 is invalid"
        raise ValueError(message)
    reading_pair = (
        reading_page_sidecar_id is not None,
        reading_page_sidecar_sha256 is not None,
    )
    if reading_pair[0] != reading_pair[1]:
        message = "Phase 3B auxiliary reading association must be an exact pair"
        raise ValueError(message)
    return PdfTablePageInput(
        source_sha256=source_sha256,
        facts=facts,
        layout=normalized_layout,
        inherited_page_sidecar_id=inherited_page_sidecar_id,
        inherited_page_sidecar_sha256=inherited_page_sidecar_sha256,
        inherited_manifest_id=inherited_manifest_id,
        reading_page_sidecar_id=reading_page_sidecar_id,
        reading_page_sidecar_sha256=reading_page_sidecar_sha256,
        dependency_identity=dependency_identity,
    )


def build_table_structure_page_from_inherited(
    *,
    inherited: PdfReadingPageEvidence,
    inherited_manifest: PdfReadingPageAuthority,
    inherited_sidecar_bytes: bytes,
    reading: PdfReadingStructurePageSidecar | None = None,
    reading_reference: PdfReadingStructurePageReference | None = None,
    reading_sidecar_bytes: bytes | None = None,
    config: PdfTableAlgorithmConfig | None = None,
) -> PdfTableStructurePageSidecar:
    """Validate frozen inputs and build an additive Phase 3C page sidecar."""

    if inherited_manifest.source_sha256 != inherited.source_sha256:
        message = "Phase 3C inherited manifest source mismatch"
        raise ValueError(message)
    references = tuple(
        reference
        for reference in inherited_manifest.page_references
        if reference.page_index == inherited.page_index
    )
    if len(references) != 1:
        message = "Phase 3C inherited manifest page reference is not unique"
        raise ValueError(message)
    reference = references[0]
    validate_reference_sidecar(
        reference=reference,
        sidecar=inherited,
        content=inherited_sidecar_bytes,
        expected_source_sha256=inherited_manifest.source_sha256,
    )

    reading_values = (reading, reading_reference, reading_sidecar_bytes)
    if any(value is not None for value in reading_values) and not all(
        value is not None for value in reading_values
    ):
        message = "Phase 3B auxiliary reading association must be all-or-none"
        raise ValueError(message)
    reading_id: str | None = None
    reading_sha: str | None = None
    if reading is not None:
        assert reading_reference is not None and reading_sidecar_bytes is not None
        observed_reading_sha = sha256(reading_sidecar_bytes).hexdigest()
        expected = {
            "source_sha256": inherited.source_sha256,
            "page_id": inherited.page_id,
            "page_index": inherited.page_index,
            "sidecar_id": reading.sidecar_id,
            "sidecar_sha256": observed_reading_sha,
            "sidecar_bytes": len(reading_sidecar_bytes),
            "inherited_page_sidecar_id": inherited.sidecar_id,
            "inherited_page_sidecar_sha256": reference.sidecar_file_sha256,
            "inherited_manifest_id": inherited_manifest.manifest_id,
        }
        observed = {
            "source_sha256": reading.source_sha256,
            "page_id": reading.page_id,
            "page_index": reading.page_index,
            "sidecar_id": reading_reference.sidecar_id,
            "sidecar_sha256": reading_reference.sidecar_sha256,
            "sidecar_bytes": reading_reference.sidecar_bytes,
            "inherited_page_sidecar_id": (reading.provenance.inherited_page_sidecar_id),
            "inherited_page_sidecar_sha256": (
                reading.provenance.inherited_page_sidecar_sha256
            ),
            "inherited_manifest_id": reading.provenance.inherited_manifest_id,
        }
        if observed != expected or (
            reading_reference.page_id != inherited.page_id
            or reading_reference.page_index != inherited.page_index
        ):
            message = "Phase 3B auxiliary reading association mismatch"
            raise ValueError(message)
        reading_id = reading.sidecar_id
        reading_sha = observed_reading_sha

    dependency_identity = canonical_sha256(
        {
            "domain": "document_sdk.pdf.phase3.table.page_dependency.v1",
            "inherited_manifest_id": inherited_manifest.manifest_id,
            "inherited_manifest_dependency_identity": (
                inherited_manifest.dependency_identity
            ),
            "inherited_page_sidecar_id": inherited.sidecar_id,
            "inherited_page_sidecar_sha256": reference.sidecar_file_sha256,
            "reading_page_sidecar_id": reading_id,
            "reading_page_sidecar_sha256": reading_sha,
        }
    )
    page_input = build_table_page_input(
        source_sha256=inherited.source_sha256,
        facts=inherited.payload.facts.page,
        layout=inherited.payload.layout,
        inherited_page_sidecar_id=inherited.sidecar_id,
        inherited_page_sidecar_sha256=reference.sidecar_file_sha256,
        inherited_manifest_id=inherited_manifest.manifest_id,
        reading_page_sidecar_id=reading_id,
        reading_page_sidecar_sha256=reading_sha,
        dependency_identity=dependency_identity,
    )
    return analyze_table_page(page_input, config=config)


def _normalize_layout_evidence(layout: Any) -> PdfTableLayoutEvidence:
    page_id = getattr(layout, "source_page_id", None) or getattr(
        layout, "page_id", None
    )
    if page_id is None:
        message = "Phase 3C Layout evidence lacks physical Page identity"
        raise ValueError(message)
    return PdfTableLayoutEvidence(
        page_id=page_id,
        page_number=layout.page_number,
        canonical_width=layout.canonical_width,
        canonical_height=layout.canonical_height,
        rotation=layout.rotation,
        nodes=tuple(layout.nodes),
        separator_candidates=tuple(layout.separator_candidates),
        build_status=getattr(layout.build_status, "value", layout.build_status),
        resource_truncation=layout.quality_signals.resource_truncation,
        source_geometry_completeness=(
            layout.quality_signals.source_geometry_completeness
        ),
        invalid_geometry_fact_ids=tuple(
            sorted(
                warning.fact_id
                for warning in layout.warnings
                if getattr(warning.code, "value", warning.code) == "invalid_bbox"
                and warning.fact_id is not None
            )
        ),
    )


def analyze_table_page(
    page: PdfTablePageInput,
    *,
    config: PdfTableAlgorithmConfig | None = None,
) -> PdfTableStructurePageSidecar:
    """Derive conservative single-page table structure from physical evidence."""

    selected = config or PdfTableAlgorithmConfig()
    tolerance = _coordinate_tolerance(page, selected)
    connection_tolerance = (
        tolerance * selected.rule_endpoint_connection_tolerance_multiplier
    )
    text_items = _primary_text_items(page)
    text_evidence = TableTextEvidenceCollector(
        maximum_selections=selected.maximum_member_views_per_page,
        maximum_references=selected.maximum_member_references_per_page,
        maximum_bytes=selected.maximum_member_selection_bytes_per_page,
    )
    member_limitations: set[str] = set()
    segments = _separator_segments(page, selected, tolerance=tolerance)
    segments = _collapse_parallel_rule_bands(
        page,
        segments,
        text_items=text_items,
        config=selected,
        tolerance=tolerance,
    )
    candidates, incomplete_component_count = _grid_candidates(
        segments,
        text_items=text_items,
        tolerance=tolerance,
        connection_tolerance=connection_tolerance,
        minimum_cells=selected.minimum_atomic_cell_count,
    )
    recovered_fragmented = _fragmented_horizontal_rule_candidates(
        segments,
        tolerance=tolerance,
        connection_tolerance=connection_tolerance,
        minimum_cells=selected.minimum_atomic_cell_count,
    )
    candidates = tuple(
        (
            *candidates,
            *(
                recovered
                for recovered in recovered_fragmented
                if not any(
                    abs(recovered.geometry.x0 - candidate.geometry.x0)
                    <= connection_tolerance
                    and abs(recovered.geometry.x1 - candidate.geometry.x1)
                    <= connection_tolerance
                    and min(recovered.geometry.y1, candidate.geometry.y1)
                    > max(recovered.geometry.y0, candidate.geometry.y0)
                    for candidate in candidates
                )
            ),
        )
    )
    if not _source_inventory_usable(page):
        return _noncomplete_sidecar(
            page,
            config=selected,
            outcome="PARTIAL",
            limitation_codes=("source_geometry_inventory_incomplete",),
            evidence_categories=("bounded_incomplete_source_inventory",),
            segments=segments,
        )
    source_inventory_complete = _source_inventory_complete(page)

    built: list[tuple[PdfBoundingBox, PdfTable]] = []
    ambiguous_grid_count = incomplete_component_count
    out_of_page_candidate_count = 0
    expanded_candidates: list[_GridCandidate] = []
    for candidate in candidates:
        if not any(
            derivation
            in {
                "wide_zero_occupancy_gutter_partition_clip",
                "bilateral_zero_occupancy_gutter_partition_clip",
            }
            for segment in candidate.horizontals
            for derivation in segment.derivations
        ):
            candidate = _extend_candidate_outer_rows_from_text(
                candidate,
                text_items=text_items,
                tolerance=connection_tolerance,
            )
        candidate = _split_large_text_separation_rows(
            candidate,
            text_items=text_items,
            tolerance=connection_tolerance,
        )
        topology_pieces = _split_candidate_by_row_topology(
            candidate,
            text_items=text_items,
            tolerance=connection_tolerance,
            minimum_cells=selected.minimum_atomic_cell_count,
        )
        for topology_piece in topology_pieces:
            expanded_candidates.extend(
                _split_candidate_by_same_topology_section_restart(
                    topology_piece,
                    text_items=text_items,
                    tolerance=connection_tolerance,
                    minimum_cells=selected.minimum_atomic_cell_count,
                )
            )

    for candidate in expanded_candidates:
        candidate_items, candidate_views, candidate_limits = _member_candidate_items(
            page, candidate, text_items=text_items, config=selected
        )
        member_limitations.update(candidate_limits)
        if candidate_limits:
            # A failed strict partition never becomes a PROVEN cell. A separate
            # native-event proof may preserve source text with explicit overflow.
            recovered, recovery_limit = try_source_anchored_table(
                page, candidate, text_evidence
            )
            if recovered is not None:
                built.append((candidate.geometry, recovered))
            else:
                ambiguous_grid_count += 1
                if recovery_limit:
                    member_limitations.add(recovery_limit)
            continue
        if not text_evidence.reserve_selections(
            tuple(view.binding for view in candidate_views)
        ):
            member_limitations.add("table_member_selection_resource_limit")
            ambiguous_grid_count += 1
            continue
        candidate = _prune_weak_internal_axes(
            candidate,
            text_items=candidate_items,
            config=selected,
            tolerance=tolerance,
        )
        result = _build_candidate_table(
            page,
            candidate,
            text_items=candidate_items,
            config=selected,
            tolerance=tolerance,
            connection_tolerance=connection_tolerance,
            table_index=0,
            text_evidence=text_evidence,
        )
        if result is None:
            ambiguous_grid_count += 1
        elif not _table_geometry_within_physical_page(
            result,
            width=page.facts.canonical_width,
            height=page.facts.canonical_height,
        ):
            ambiguous_grid_count += 1
            out_of_page_candidate_count += 1
        else:
            built.append((candidate.geometry, result))

    if text_evidence.limit_exceeded:
        member_limitations.add("table_text_evidence_resource_limit")
    built.sort(
        key=lambda item: (
            item[0].y0,
            item[0].x0,
            item[0].y1,
            item[0].x1,
            item[1].table_id,
        )
    )
    tables = tuple(
        _with_table_limitation(
            _reindex_table(table, table_index=index),
            "source_geometry_inventory_incomplete",
        )
        if not source_inventory_complete
        else _reindex_table(table, table_index=index)
        for index, (_geometry, table) in enumerate(built)
    )
    if tables:
        remaining_text_items = tuple(
            item
            for item in text_items
            if not any(
                table.geometry.x0
                <= (item.node.bbox.x0 + item.node.bbox.x1) / 2
                <= table.geometry.x1
                and table.geometry.y0
                <= (item.node.bbox.y0 + item.node.bbox.y1) / 2
                <= table.geometry.y1
                for table in tables
            )
        )
        complementary = build_borderless_aligned_tables(
            bindings=BorderlessTableBindings(
                text_evidence=text_evidence,
                source_sha256=page.source_sha256,
                page_id=page.page_id,
                page_index=page.page_index,
                page_width=page.facts.canonical_width,
                page_height=page.facts.canonical_height,
                inherited_page_sidecar_id=page.inherited_page_sidecar_id,
                inherited_page_sidecar_sha256=(page.inherited_page_sidecar_sha256),
                inherited_manifest_id=page.inherited_manifest_id,
                reading_page_sidecar_id=page.reading_page_sidecar_id,
                reading_page_sidecar_sha256=page.reading_page_sidecar_sha256,
            ),
            text_items=tuple((item.fact, item.node) for item in remaining_text_items),
            options=BorderlessTableOptions(
                coordinate_tolerance=tolerance,
                minimum_rows=selected.borderless_minimum_rows,
                minimum_columns=selected.borderless_minimum_columns,
                minimum_occupancy=selected.borderless_minimum_occupancy,
                maximum_text_width_ratio=(selected.borderless_maximum_text_width_ratio),
            ),
        )
        complementary = tuple(
            candidate
            for candidate in complementary
            if not any(
                min(candidate.geometry.x1, table.geometry.x1)
                > max(candidate.geometry.x0, table.geometry.x0)
                and min(candidate.geometry.y1, table.geometry.y1)
                > max(candidate.geometry.y0, table.geometry.y0)
                for table in tables
            )
        )
        if complementary:
            vertical_groups: list[list[PdfTable]] = []
            for table in sorted(
                (*tables, *complementary),
                key=lambda item: (
                    item.geometry.y0,
                    item.geometry.x0,
                    item.table_id,
                ),
            ):
                if vertical_groups and table.geometry.y0 < max(
                    item.geometry.y1 for item in vertical_groups[-1]
                ):
                    vertical_groups[-1].append(table)
                else:
                    vertical_groups.append([table])
            combined = tuple(
                table
                for group in vertical_groups
                for table in sorted(
                    group,
                    key=lambda item: (
                        item.geometry.x0,
                        item.geometry.y0,
                        item.table_id,
                    ),
                )
            )
            tables = tuple(
                _reindex_table(table, table_index=index)
                for index, table in enumerate(combined)
            )
    # Complementary detection uses the same collector and may exhaust it after
    # the ruled-table pass. Never hide an omitted region behind complete survivors.
    if text_evidence.limit_exceeded:
        member_limitations.add("table_text_evidence_resource_limit")
    if (
        tables
        and not ambiguous_grid_count
        and not text_evidence.limit_exceeded
        and all(table.state == "COMPLETE" for table in tables)
    ):
        return build_table_page_sidecar(
            source_sha256=page.source_sha256,
            page_id=page.page_id,
            page_index=page.page_index,
            canonical_width=page.facts.canonical_width,
            canonical_height=page.facts.canonical_height,
            outcome="COMPLETE",
            tables=tables,
            member_bindings=_used_member_bindings(tables, text_evidence.selections),
            cell_text_projections=_used_text_projections(tables, text_evidence),
            source_anchored_overflow_proofs=_used_overflow_proofs(
                tables, text_evidence
            ),
            negative_evidence=(),
            inherited_page_sidecar_id=page.inherited_page_sidecar_id,
            inherited_page_sidecar_sha256=page.inherited_page_sidecar_sha256,
            inherited_manifest_id=page.inherited_manifest_id,
            reading_page_sidecar_id=page.reading_page_sidecar_id,
            reading_page_sidecar_sha256=page.reading_page_sidecar_sha256,
            configuration_identity=selected.identity,
            dependency_identity=page.dependency_identity,
        )
    if tables:
        limitations = {
            limitation for table in tables for limitation in table.limitation_codes
        }
        if ambiguous_grid_count:
            limitations.add("additional_ambiguous_table_region")
        if out_of_page_candidate_count:
            limitations.add("table_candidate_geometry_outside_physical_page")
        limitations.update(member_limitations)
        return build_table_page_sidecar(
            source_sha256=page.source_sha256,
            page_id=page.page_id,
            page_index=page.page_index,
            canonical_width=page.facts.canonical_width,
            canonical_height=page.facts.canonical_height,
            outcome="PARTIAL",
            tables=tables,
            member_bindings=_used_member_bindings(tables, text_evidence.selections),
            cell_text_projections=_used_text_projections(tables, text_evidence),
            source_anchored_overflow_proofs=_used_overflow_proofs(
                tables, text_evidence
            ),
            negative_evidence=(),
            inherited_page_sidecar_id=page.inherited_page_sidecar_id,
            inherited_page_sidecar_sha256=page.inherited_page_sidecar_sha256,
            inherited_manifest_id=page.inherited_manifest_id,
            reading_page_sidecar_id=page.reading_page_sidecar_id,
            reading_page_sidecar_sha256=page.reading_page_sidecar_sha256,
            configuration_identity=selected.identity,
            dependency_identity=page.dependency_identity,
            limitation_codes=tuple(sorted(limitations)),
        )
    borderless = build_borderless_aligned_tables(
        bindings=BorderlessTableBindings(
            text_evidence=text_evidence,
            source_sha256=page.source_sha256,
            page_id=page.page_id,
            page_index=page.page_index,
            page_width=page.facts.canonical_width,
            page_height=page.facts.canonical_height,
            inherited_page_sidecar_id=page.inherited_page_sidecar_id,
            inherited_page_sidecar_sha256=page.inherited_page_sidecar_sha256,
            inherited_manifest_id=page.inherited_manifest_id,
            reading_page_sidecar_id=page.reading_page_sidecar_id,
            reading_page_sidecar_sha256=page.reading_page_sidecar_sha256,
        ),
        text_items=tuple((item.fact, item.node) for item in text_items),
        options=BorderlessTableOptions(
            coordinate_tolerance=tolerance,
            minimum_rows=selected.borderless_minimum_rows,
            minimum_columns=selected.borderless_minimum_columns,
            minimum_occupancy=selected.borderless_minimum_occupancy,
            maximum_text_width_ratio=(selected.borderless_maximum_text_width_ratio),
        ),
    )
    if not borderless and not segments and page.facts.text_members:
        member_grid = repeated_member_grid(
            source_sha256=page.source_sha256,
            page=page.facts,
            parents=tuple((item.fact, item.node) for item in text_items),
            minimum_rows=selected.borderless_minimum_rows,
            # Member-only recovery retains the original stable-grid minimum.
            # It must not bypass the separate narrow-table/prose safeguards.
            minimum_columns=max(4, selected.borderless_minimum_columns),
        )
        if member_grid.limitation:
            member_limitations.add(member_grid.limitation)
        if member_grid.views and text_evidence.reserve_selections(
            tuple(view.binding for view in member_grid.views)
        ):
            borderless = build_borderless_aligned_tables(
                bindings=BorderlessTableBindings(
                    text_evidence=text_evidence,
                    source_sha256=page.source_sha256,
                    page_id=page.page_id,
                    page_index=page.page_index,
                    page_width=page.facts.canonical_width,
                    page_height=page.facts.canonical_height,
                    inherited_page_sidecar_id=page.inherited_page_sidecar_id,
                    inherited_page_sidecar_sha256=page.inherited_page_sidecar_sha256,
                    inherited_manifest_id=page.inherited_manifest_id,
                    reading_page_sidecar_id=page.reading_page_sidecar_id,
                    reading_page_sidecar_sha256=page.reading_page_sidecar_sha256,
                ),
                text_items=member_grid.views,
                options=BorderlessTableOptions(
                    coordinate_tolerance=tolerance,
                    minimum_rows=selected.borderless_minimum_rows,
                    minimum_columns=selected.borderless_minimum_columns,
                    minimum_occupancy=selected.borderless_minimum_occupancy,
                    maximum_text_width_ratio=selected.borderless_maximum_text_width_ratio,
                ),
            )
        elif member_grid.views:
            member_limitations.add("table_member_selection_resource_limit")
    if text_evidence.limit_exceeded:
        member_limitations.add("table_text_evidence_resource_limit")
    if borderless:
        if not source_inventory_complete:
            borderless = tuple(
                _with_table_limitation(table, "source_geometry_inventory_incomplete")
                for table in borderless
            )
        outcome: Literal["COMPLETE", "PARTIAL"] = (
            "COMPLETE"
            if not ambiguous_grid_count
            and not text_evidence.limit_exceeded
            and all(table.state == "COMPLETE" for table in borderless)
            else "PARTIAL"
        )
        limitations = {
            limitation for table in borderless for limitation in table.limitation_codes
        }
        if ambiguous_grid_count:
            limitations.add("incomplete_orthogonal_separator_enclosure")
        if out_of_page_candidate_count:
            limitations.add("table_candidate_geometry_outside_physical_page")
        limitations.update(member_limitations)
        return build_table_page_sidecar(
            source_sha256=page.source_sha256,
            page_id=page.page_id,
            page_index=page.page_index,
            canonical_width=page.facts.canonical_width,
            canonical_height=page.facts.canonical_height,
            outcome=outcome,
            tables=borderless,
            member_bindings=_used_member_bindings(borderless, text_evidence.selections),
            cell_text_projections=_used_text_projections(borderless, text_evidence),
            source_anchored_overflow_proofs=_used_overflow_proofs(
                borderless, text_evidence
            ),
            negative_evidence=(),
            inherited_page_sidecar_id=page.inherited_page_sidecar_id,
            inherited_page_sidecar_sha256=page.inherited_page_sidecar_sha256,
            inherited_manifest_id=page.inherited_manifest_id,
            reading_page_sidecar_id=page.reading_page_sidecar_id,
            reading_page_sidecar_sha256=page.reading_page_sidecar_sha256,
            configuration_identity=selected.identity,
            dependency_identity=page.dependency_identity,
            limitation_codes=tuple(sorted(limitations)),
        )
    if text_evidence.limit_exceeded:
        return _noncomplete_sidecar(
            page,
            config=selected,
            outcome="PARTIAL",
            limitation_codes=("table_text_evidence_resource_limit",),
            evidence_categories=("bounded_table_text_evidence",),
            segments=segments,
        )
    if not source_inventory_complete:
        return _noncomplete_sidecar(
            page,
            config=selected,
            outcome="PARTIAL",
            limitation_codes=("source_geometry_inventory_incomplete",),
            evidence_categories=("bounded_incomplete_source_inventory",),
            segments=segments,
        )
    if not segments and _two_row_alignment_candidate(
        page, text_items, selected, tolerance
    ):
        return _noncomplete_sidecar(
            page,
            config=selected,
            outcome="AMBIGUOUS",
            limitation_codes=("borderless_two_row_structure_not_supported",),
            evidence_categories=("two_row_alignment_does_not_prove_table_intent",),
            segments=segments,
        )
    if (
        member_limitations
        or ambiguous_grid_count
        or _looks_like_borderless_table(
            text_items, page=page, config=selected, tolerance=tolerance
        )
    ):
        limitations = {
            (
                "incomplete_orthogonal_separator_enclosure"
                if ambiguous_grid_count
                else "borderless_table_candidate_requires_stronger_physical_evidence"
            )
        }
        if out_of_page_candidate_count:
            limitations.add("table_candidate_geometry_outside_physical_page")
        limitations.update(member_limitations)
        return _noncomplete_sidecar(
            page,
            config=selected,
            outcome="AMBIGUOUS",
            limitation_codes=tuple(sorted(limitations)),
            evidence_categories=(
                "incomplete_orthogonal_separator_grid"
                if ambiguous_grid_count
                else "repeated_text_alignment_candidate",
            ),
            segments=segments,
        )
    return _noncomplete_sidecar(
        page,
        config=selected,
        outcome="NO_TABLE",
        limitation_codes=(),
        evidence_categories=(
            "complete_separator_inventory",
            "no_repeated_orthogonal_separator_enclosure",
            "no_proven_borderless_grid",
        ),
        segments=segments,
    )


def _member_candidate_items(
    page: PdfTablePageInput,
    candidate: _GridCandidate,
    *,
    text_items: tuple[_TextItem, ...],
    config: PdfTableAlgorithmConfig,
) -> tuple[tuple[_TextItem, ...], tuple[TableTextView, ...], tuple[str, ...]]:
    if not page.facts.text_members:
        return text_items, (), ()
    by_id = {member.member_id: member for member in page.facts.text_members}
    selected: list[_TextItem] = []
    views: list[TableTextView] = []
    limitations: set[str] = set()
    for item in text_items:
        box = item.geometry
        intersects = min(box.x1, candidate.geometry.x1) > max(
            box.x0, candidate.geometry.x0
        ) and min(box.y1, candidate.geometry.y1) > max(box.y0, candidate.geometry.y0)
        if not intersects:
            selected.append(item)
            continue
        result = partition_parent_at_grid(
            source_sha256=page.source_sha256,
            page=page.facts,
            fact=item.fact,
            node=item.node,
            row_coordinates=candidate.row_coordinates,
            column_coordinates=candidate.column_coordinates,
            members_by_id=by_id,
        )
        if result.limitation:
            limitations.add(result.limitation)
        if not result.views:
            selected.append(item)
            continue
        views.extend(result.views)
        if len(views) > config.maximum_member_views_per_page:
            return text_items, (), ("table_member_selection_resource_limit",)
        selected.extend(
            _TextItem(view.fact, view.node, view.geometry, view)
            for view in result.views
        )
    return tuple(selected), tuple(views), tuple(sorted(limitations))


def _used_member_bindings(
    tables: tuple[PdfTable, ...],
    selections: dict[str, PdfTableMemberBinding],
) -> tuple[PdfTableMemberBinding, ...]:
    ids = {
        value.removeprefix("member_selection:")
        for table in tables
        for cell in table.cells
        for value in cell.text_assignment_evidence
        if value.startswith("member_selection:")
    }
    return tuple(selections[value] for value in sorted(ids))


def _used_text_projections(
    tables: tuple[PdfTable, ...], collector: TableTextEvidenceCollector
) -> tuple[PdfTableCellTextProjection, ...]:
    cell_ids = {cell.cell_id for table in tables for cell in table.cells}
    return tuple(collector.projections[key] for key in sorted(cell_ids))


def _used_overflow_proofs(
    tables: tuple[PdfTable, ...],
    collector: TableTextEvidenceCollector,
) -> tuple[SourceAnchoredOverflowProof, ...]:
    ids = {
        part.source_anchored_overflow_id
        for projection in _used_text_projections(tables, collector)
        for part in projection.parts
        if part.source_anchored_overflow_id is not None
    }
    return tuple(collector.overflow_proofs[key] for key in sorted(ids))


def _source_inventory_complete(page: PdfTablePageInput) -> bool:
    return bool(
        page.facts.extraction_status.value == "success"
        and page.layout.build_status in {"success", "partial"}
        and not page.layout.resource_truncation
        and page.layout.source_geometry_completeness == 1.0
    )


def _table_geometry_within_physical_page(
    table: PdfTable, *, width: float, height: float
) -> bool:
    geometry = table.geometry
    return bool(
        geometry.x0 >= 0
        and geometry.y0 >= 0
        and geometry.x1 <= width
        and geometry.y1 <= height
    )


def _source_inventory_usable(page: PdfTablePageInput) -> bool:
    return bool(
        page.facts.extraction_status.value in {"success", "partial"}
        and page.layout.build_status in {"success", "partial"}
        and not page.layout.resource_truncation
        and (
            page.layout.source_geometry_completeness == 1.0
            or _only_proven_degenerate_noop_drawings_are_geometry_invalid(page)
        )
    )


def _only_proven_degenerate_noop_drawings_are_geometry_invalid(
    page: PdfTablePageInput,
) -> bool:
    invalid_ids = set(page.layout.invalid_geometry_fact_ids)
    if not invalid_ids:
        return False
    drawings = {
        drawing.fact_id: drawing
        for drawing in page.facts.drawings
        if drawing.fact_id in invalid_ids
    }
    if set(drawings) != invalid_ids:
        return False
    return all(
        _is_degenerate_noop_drawing_path(drawing) for drawing in drawings.values()
    )


def _is_degenerate_noop_drawing_path(drawing: PdfDrawingFact) -> bool:
    if (
        not drawing.path_geometry_complete
        or drawing.path_segment_truncated
        or drawing.bbox.x0 != drawing.bbox.x1
        or drawing.bbox.y0 != drawing.bbox.y1
        or not drawing.path_segments
        or drawing.is_clipping_path
        or getattr(drawing, "paint_operation", "stroke")
        in {"clip", "fill", "fill_stroke"}
    ):
        return False
    segment_kinds = {
        getattr(segment, "kind", None) for segment in drawing.path_segments
    }
    if getattr(drawing, "kind", None) == "curve" and segment_kinds <= {
        "move",
        "line",
        "cubic_bezier",
        "close",
    }:
        return all(
            getattr(segment, "geometry_quality", "unknown")
            in {"precise", "approximate"}
            for segment in drawing.path_segments
        )
    return all(
        _is_degenerate_noop_path_segment(segment) for segment in drawing.path_segments
    )


def _is_degenerate_noop_path_segment(segment: object) -> bool:
    kind = getattr(segment, "kind", None)
    if kind in {"move", "close"}:
        return True
    if kind not in {"line", "cubic_bezier"}:
        return False
    start = getattr(segment, "start", None)
    end = getattr(segment, "end", None)
    if start is None or end is None:
        return False
    start_point = (getattr(start, "x", None), getattr(start, "y", None))
    if start_point != (getattr(end, "x", None), getattr(end, "y", None)):
        return False
    for point in getattr(segment, "control_points", ()) or ():
        if start_point != (getattr(point, "x", None), getattr(point, "y", None)):
            return False
    return True


def _coordinate_tolerance(
    page: PdfTablePageInput, config: PdfTableAlgorithmConfig
) -> float:
    scaled = min(page.facts.canonical_width, page.facts.canonical_height) * (
        config.coordinate_tolerance_page_ratio
    )
    return min(
        config.coordinate_tolerance_ceiling_points,
        max(config.coordinate_tolerance_floor_points, scaled),
    )


def _all_text_facts(page: PdfPageFacts) -> dict[str, PdfTextFact]:
    return {
        fact.fact_id: fact
        for layer in (
            page.words,
            page.text_spans,
            page.line_candidates,
            page.characters,
        )
        for fact in layer
    }


def _primary_text_items(page: PdfTablePageInput) -> tuple[_TextItem, ...]:
    facts = _all_text_facts(page.facts)
    primary_nodes = tuple(
        node for node in page.layout.nodes if node.text_layer_role == "primary"
    )
    result: list[_TextItem] = []
    for node in page.layout.nodes:
        if node.text_layer_role != "primary":
            continue
        fact = facts.get(node.source_fact_id)
        if fact is None:
            message = "Phase 3C primary Layout node lacks its Canonical Fact"
            raise ValueError(message)
        result.append(_TextItem(fact=fact, node=node, geometry=node.bbox))
    if page.facts.words and not any(node.node_type == "word" for node in primary_nodes):
        unique_words: dict[tuple[str, float, float, float, float], PdfTextFact] = {}
        for word in sorted(
            page.facts.words,
            key=lambda fact: (fact.source_order, fact.fact_id),
        ):
            key = (
                word.text,
                word.bbox.x0,
                word.bbox.y0,
                word.bbox.x1,
                word.bbox.y1,
            )
            unique_words.setdefault(key, word)
        word_items = []
        for word in unique_words.values():
            center_x = (word.bbox.x0 + word.bbox.x1) / 2
            center_y = (word.bbox.y0 + word.bbox.y1) / 2
            covering = tuple(
                node
                for node in primary_nodes
                if node.bbox.x0 <= center_x <= node.bbox.x1
                and node.bbox.y0 <= center_y <= node.bbox.y1
            )
            if not covering:
                continue
            minimum_area = min(
                (node.bbox.x1 - node.bbox.x0) * (node.bbox.y1 - node.bbox.y0)
                for node in covering
            )
            smallest = tuple(
                node
                for node in covering
                if abs(
                    (node.bbox.x1 - node.bbox.x0) * (node.bbox.y1 - node.bbox.y0)
                    - minimum_area
                )
                <= 1e-9
            )
            geometries = {
                (node.bbox.x0, node.bbox.y0, node.bbox.x1, node.bbox.y1)
                for node in smallest
            }
            if len(geometries) != 1:
                continue
            node = min(smallest, key=lambda item: item.node_id)
            word_items.append(_TextItem(fact=word, node=node, geometry=word.bbox))
        if word_items:
            result = word_items
    return tuple(
        sorted(
            result,
            key=lambda item: (
                item.geometry.y0,
                item.geometry.x0,
                item.fact.source_order,
                item.node.node_id,
            ),
        )
    )


def _separator_segments(
    page: PdfTablePageInput,
    config: PdfTableAlgorithmConfig,
    *,
    tolerance: float,
) -> tuple[_Segment, ...]:
    thickness_limit = tolerance * config.thin_rule_maximum_thickness_multiplier
    minimum_length = tolerance * config.thin_rule_minimum_length_multiplier
    drawing_by_fact = {drawing.fact_id: drawing for drawing in page.facts.drawings}
    drawing_fact_by_node = {
        node.node_id: node.source_fact_id
        for node in page.layout.nodes
        if node.node_type == "drawing"
    }
    drawing_node_by_fact = {
        node.source_fact_id: node.node_id
        for node in page.layout.nodes
        if node.node_type == "drawing"
    }
    primitives: list[_Segment] = []
    for candidate in page.layout.separator_candidates:
        if (
            candidate.evidence_kind != "drawing_separator"
            or candidate.geometry_quality != "precise"
            or candidate.confidence < config.minimum_separator_confidence
            or candidate.paint_operation in {"clip", "none"}
            or candidate.quality_metadata_truncated
            or candidate.drawing_node_id is None
        ):
            continue
        fact_id = drawing_fact_by_node.get(candidate.drawing_node_id)
        if fact_id is None:
            message = "Phase 3C separator lacks its drawing Fact binding"
            raise ValueError(message)
        drawing = drawing_by_fact.get(fact_id)
        if (
            drawing is not None
            and drawing.kind == "rectangle"
            and drawing.paint_operation in {"fill", "fill_stroke"}
            and drawing.bbox.x1 - drawing.bbox.x0 > thickness_limit
            and drawing.bbox.y1 - drawing.bbox.y0 > thickness_limit
        ):
            continue
        if candidate.orientation == "horizontal":
            coordinate = (candidate.bbox.y0 + candidate.bbox.y1) / 2
            start, end = candidate.bbox.x0, candidate.bbox.x1
        else:
            coordinate = (candidate.bbox.x0 + candidate.bbox.x1) / 2
            start, end = candidate.bbox.y0, candidate.bbox.y1
        primitives.append(
            _Segment(
                orientation=candidate.orientation,
                coordinate=coordinate,
                start=start,
                end=end,
                separator_candidate_ids=(candidate.separator_candidate_id,),
                drawing_node_ids=(candidate.drawing_node_id,),
                drawing_fact_ids=(fact_id,),
                derivations=("layout_separator_candidate",),
            )
        )
    for drawing in page.facts.drawings:
        node_id = drawing_node_by_fact.get(drawing.fact_id)
        bbox_quality = getattr(
            getattr(drawing, "bbox_semantics", None), "quality", None
        )
        if (
            node_id is None
            or drawing.paint_operation in {"clip", "none"}
            or bbox_quality != "precise"
        ):
            continue
        width = drawing.bbox.x1 - drawing.bbox.x0
        height = drawing.bbox.y1 - drawing.bbox.y0
        if drawing.kind == "line":
            derivation = "thin_line_rule"
        elif drawing.kind == "rectangle":
            derivation = "thin_rectangle_rule"
        else:
            continue
        if width >= minimum_length and 0 <= height <= thickness_limit:
            orientation = "horizontal"
            coordinate = (drawing.bbox.y0 + drawing.bbox.y1) / 2
            start, end = drawing.bbox.x0, drawing.bbox.x1
        elif height >= minimum_length and 0 <= width <= thickness_limit:
            orientation = "vertical"
            coordinate = (drawing.bbox.x0 + drawing.bbox.x1) / 2
            start, end = drawing.bbox.y0, drawing.bbox.y1
        else:
            continue
        primitives.append(
            _Segment(
                orientation=orientation,
                coordinate=coordinate,
                start=start,
                end=end,
                separator_candidate_ids=(),
                drawing_node_ids=(node_id,),
                drawing_fact_ids=(drawing.fact_id,),
                derivations=(derivation,),
            )
        )
    primitives.extend(
        _filled_row_band_edges(
            page,
            primitives,
            drawing_node_by_fact=drawing_node_by_fact,
            tolerance=tolerance,
            minimum_boundaries=(config.implied_column_minimum_repeated_boundaries),
        )
    )
    explicit_horizontal_coordinates = _explicit_axis_coordinates(
        primitives, orientation="horizontal", tolerance=tolerance
    )
    explicit_vertical_coordinates = _explicit_axis_coordinates(
        primitives, orientation="vertical", tolerance=tolerance
    )
    explicit_horizontals = tuple(
        segment for segment in primitives if segment.orientation == "horizontal"
    )
    explicit_verticals = tuple(
        segment for segment in primitives if segment.orientation == "vertical"
    )
    primitives.extend(
        _endpoint_segments_aligned_to_explicit_axes(
            _implied_endpoint_verticals(
                primitives,
                tolerance=tolerance,
                minimum_boundaries=(config.implied_column_minimum_repeated_boundaries),
            ),
            explicit_axis_coordinates=explicit_vertical_coordinates,
            explicit_axis_segments=explicit_verticals,
            tolerance=tolerance,
        )
    )
    primitives.extend(
        _endpoint_segments_aligned_to_explicit_axes(
            _implied_endpoint_horizontals(
                primitives,
                tolerance=tolerance,
                minimum_boundaries=(config.implied_column_minimum_repeated_boundaries),
            ),
            explicit_axis_coordinates=explicit_horizontal_coordinates,
            explicit_axis_segments=explicit_horizontals,
            tolerance=tolerance,
        )
    )
    return _merge_collinear_segments(primitives, tolerance=tolerance)


def _explicit_axis_coordinates(
    segments: Sequence[_Segment], *, orientation: str, tolerance: float
) -> tuple[float, ...]:
    return _cluster_coordinates(
        (
            segment.coordinate
            for segment in segments
            if segment.orientation == orientation
        ),
        tolerance=tolerance,
    )


def _endpoint_segments_aligned_to_explicit_axes(
    segments: Sequence[_Segment],
    *,
    explicit_axis_coordinates: Sequence[float],
    explicit_axis_segments: Sequence[_Segment],
    tolerance: float,
) -> tuple[_Segment, ...]:
    if len(explicit_axis_coordinates) < 3:
        return tuple(segments)
    result = []
    for segment in segments:
        if not any(
            abs(segment.coordinate - coordinate) <= tolerance
            for coordinate in explicit_axis_coordinates
        ):
            continue
        support = tuple(
            explicit
            for explicit in explicit_axis_segments
            if abs(explicit.coordinate - segment.coordinate) <= tolerance
        )
        if not support:
            continue
        start = max(segment.start, min(item.start for item in support))
        end = min(segment.end, max(item.end for item in support))
        if end <= start:
            continue
        result.append(
            _Segment(
                orientation=segment.orientation,
                coordinate=segment.coordinate,
                start=start,
                end=end,
                separator_candidate_ids=segment.separator_candidate_ids,
                drawing_node_ids=segment.drawing_node_ids,
                drawing_fact_ids=segment.drawing_fact_ids,
                derivations=tuple(
                    sorted(
                        {
                            *segment.derivations,
                            "explicit_axis_bounded_endpoint_boundary",
                        }
                    )
                ),
            )
        )
    return tuple(result)


def _filled_row_band_edges(
    page: PdfTablePageInput,
    segments: Sequence[_Segment],
    *,
    drawing_node_by_fact: dict[str, str],
    tolerance: float,
    minimum_boundaries: int,
) -> tuple[_Segment, ...]:
    verticals = tuple(
        segment for segment in segments if segment.orientation == "vertical"
    )
    repeated_verticals = tuple(
        coordinate
        for coordinate in _cluster_coordinates(
            (segment.coordinate for segment in verticals), tolerance=tolerance
        )
        if sum(
            1
            for segment in verticals
            if abs(segment.coordinate - coordinate) <= tolerance
        )
        >= minimum_boundaries
    )
    if len(repeated_verticals) < 2:
        return ()

    result: list[_Segment] = []
    eligible_bands: list[tuple[float, float, float, float, str, str]] = []
    for drawing in page.facts.drawings:
        node_id = drawing_node_by_fact.get(drawing.fact_id)
        bbox_quality = getattr(
            getattr(drawing, "bbox_semantics", None), "quality", None
        )
        if (
            drawing.kind != "rectangle"
            or drawing.paint_operation not in {"fill", "fill_stroke"}
            or drawing.is_clipping_path
            or node_id is None
            or bbox_quality != "precise"
        ):
            continue
        x0, y0, x1, y1 = (
            drawing.bbox.x0,
            drawing.bbox.y0,
            drawing.bbox.x1,
            drawing.bbox.y1,
        )
        if x1 <= x0 or y1 <= y0:
            continue
        if y1 - y0 <= tolerance * minimum_boundaries * 2:
            continue
        covered_verticals = tuple(
            coordinate
            for coordinate in repeated_verticals
            if x0 + tolerance < coordinate < x1 - tolerance
        )
        if len(covered_verticals) < 2:
            continue
        eligible_bands.append((x0, y0, x1, y1, node_id, drawing.fact_id))
        for y in (y0, y1):
            result.append(
                _Segment(
                    orientation="horizontal",
                    coordinate=y,
                    start=x0,
                    end=x1,
                    separator_candidate_ids=(),
                    drawing_node_ids=(node_id,),
                    drawing_fact_ids=(drawing.fact_id,),
                    derivations=("filled_row_band_edge",),
                )
            )
        for x in (x0, x1):
            result.append(
                _Segment(
                    orientation="vertical",
                    coordinate=x,
                    start=y0,
                    end=y1,
                    separator_candidate_ids=(),
                    drawing_node_ids=(node_id,),
                    drawing_fact_ids=(drawing.fact_id,),
                    derivations=("filled_row_band_edge",),
                )
            )
    band_groups: dict[
        tuple[float, float], list[tuple[float, float, float, float, str, str]]
    ] = {}
    for band in eligible_bands:
        band_groups.setdefault((band[0], band[2]), []).append(band)
    for (x0, x1), bands in band_groups.items():
        if len(bands) < minimum_boundaries:
            continue
        supporting_verticals = tuple(
            segment
            for segment in verticals
            if x0 + tolerance < segment.coordinate < x1 - tolerance
        )
        if not supporting_verticals:
            continue
        start = min(segment.start for segment in supporting_verticals)
        end = max(segment.end for segment in supporting_verticals)
        node_ids = tuple(sorted({band[4] for band in bands}))
        fact_ids = tuple(sorted({band[5] for band in bands}))
        for x in (x0, x1):
            result.append(
                _Segment(
                    orientation="vertical",
                    coordinate=x,
                    start=start,
                    end=end,
                    separator_candidate_ids=(),
                    drawing_node_ids=node_ids,
                    drawing_fact_ids=fact_ids,
                    derivations=("filled_row_band_outer_boundary",),
                )
            )
    return tuple(result)


def _implied_endpoint_verticals(
    segments: Sequence[_Segment],
    *,
    tolerance: float,
    minimum_boundaries: int,
) -> tuple[_Segment, ...]:
    horizontals = tuple(
        segment for segment in segments if segment.orientation == "horizontal"
    )
    endpoints: list[tuple[float, float, str, _Segment]] = []
    for segment in horizontals:
        endpoints.append((segment.start, segment.coordinate, "start", segment))
        endpoints.append((segment.end, segment.coordinate, "end", segment))
    endpoint_groups: list[list[tuple[float, float, str, _Segment]]] = []
    for endpoint in sorted(endpoints, key=lambda item: (item[0], item[1], item[2])):
        if (
            endpoint_groups
            and abs(
                endpoint[0]
                - sum(item[0] for item in endpoint_groups[-1])
                / len(endpoint_groups[-1])
            )
            <= tolerance
        ):
            endpoint_groups[-1].append(endpoint)
        else:
            endpoint_groups.append([endpoint])

    def boundary_rows(
        group: Sequence[tuple[float, float, str, _Segment]],
    ) -> tuple[float, ...]:
        return _cluster_coordinates((item[1] for item in group), tolerance=tolerance)

    interior_groups = []
    for group in endpoint_groups:
        repeated_rows = []
        for row in boundary_rows(group):
            incident = {
                kind for _x, y, kind, _segment in group if abs(y - row) <= tolerance
            }
            if incident == {"start", "end"}:
                repeated_rows.append(row)
        if len(repeated_rows) >= minimum_boundaries:
            interior_groups.append((group, tuple(repeated_rows)))
    if not interior_groups:
        return ()
    qualifying_rows = {row for _group, rows in interior_groups for row in rows}
    result = []
    for group in endpoint_groups:
        all_rows = boundary_rows(group)
        if len(all_rows) < minimum_boundaries:
            continue
        outer_rows = {all_rows[0], all_rows[-1]}
        rows = tuple(
            row
            for row in all_rows
            if row in outer_rows
            or any(abs(row - allowed) <= tolerance for allowed in qualifying_rows)
        )
        if len(rows) < minimum_boundaries:
            continue
        members = tuple(item[3] for item in group)
        result.append(
            _Segment(
                orientation="vertical",
                coordinate=round(sum(item[0] for item in group) / len(group), 6),
                start=min(rows),
                end=max(rows),
                separator_candidate_ids=tuple(
                    sorted(
                        {
                            candidate
                            for member in members
                            for candidate in member.separator_candidate_ids
                        }
                    )
                ),
                drawing_node_ids=tuple(
                    sorted(
                        {node for member in members for node in member.drawing_node_ids}
                    )
                ),
                drawing_fact_ids=tuple(
                    sorted(
                        {fact for member in members for fact in member.drawing_fact_ids}
                    )
                ),
                derivations=("repeated_horizontal_endpoint_boundary",),
            )
        )
    return tuple(result)


def _implied_endpoint_horizontals(
    segments: Sequence[_Segment],
    *,
    tolerance: float,
    minimum_boundaries: int,
) -> tuple[_Segment, ...]:
    verticals = tuple(
        segment for segment in segments if segment.orientation == "vertical"
    )
    endpoints: list[tuple[float, float, str, _Segment]] = []
    for segment in verticals:
        endpoints.append((segment.start, segment.coordinate, "start", segment))
        endpoints.append((segment.end, segment.coordinate, "end", segment))
    endpoint_groups: list[list[tuple[float, float, str, _Segment]]] = []
    for endpoint in sorted(endpoints, key=lambda item: (item[0], item[1], item[2])):
        if (
            endpoint_groups
            and abs(
                endpoint[0]
                - sum(item[0] for item in endpoint_groups[-1])
                / len(endpoint_groups[-1])
            )
            <= tolerance
        ):
            endpoint_groups[-1].append(endpoint)
        else:
            endpoint_groups.append([endpoint])

    def boundary_columns(
        group: Sequence[tuple[float, float, str, _Segment]],
    ) -> tuple[float, ...]:
        return _cluster_coordinates((item[1] for item in group), tolerance=tolerance)

    interior_groups = []
    for group in endpoint_groups:
        repeated_columns = []
        for column in boundary_columns(group):
            incident = {
                kind for _y, x, kind, _segment in group if abs(x - column) <= tolerance
            }
            if incident == {"start", "end"}:
                repeated_columns.append(column)
        if len(repeated_columns) >= minimum_boundaries:
            interior_groups.append((group, tuple(repeated_columns)))
    if not interior_groups:
        return ()
    qualifying_columns = {
        column for _group, columns in interior_groups for column in columns
    }
    result = []
    for group in endpoint_groups:
        all_columns = boundary_columns(group)
        if len(all_columns) < minimum_boundaries:
            continue
        outer_columns = {all_columns[0], all_columns[-1]}
        columns = tuple(
            column
            for column in all_columns
            if column in outer_columns
            or any(abs(column - allowed) <= tolerance for allowed in qualifying_columns)
        )
        if len(columns) < minimum_boundaries:
            continue
        members = tuple(item[3] for item in group)
        result.append(
            _Segment(
                orientation="horizontal",
                coordinate=round(sum(item[0] for item in group) / len(group), 6),
                start=min(columns),
                end=max(columns),
                separator_candidate_ids=tuple(
                    sorted(
                        {
                            candidate
                            for member in members
                            for candidate in member.separator_candidate_ids
                        }
                    )
                ),
                drawing_node_ids=tuple(
                    sorted(
                        {node for member in members for node in member.drawing_node_ids}
                    )
                ),
                drawing_fact_ids=tuple(
                    sorted(
                        {fact for member in members for fact in member.drawing_fact_ids}
                    )
                ),
                derivations=("repeated_vertical_endpoint_boundary",),
            )
        )
    return tuple(result)


def _merge_collinear_segments(
    segments: Sequence[_Segment], *, tolerance: float
) -> tuple[_Segment, ...]:
    pending = sorted(
        segments,
        key=lambda item: (
            item.orientation,
            item.coordinate,
            item.start,
            item.end,
            item.separator_candidate_ids,
            item.derivations,
        ),
    )
    merged: list[_Segment] = []
    for item in pending:
        match_index = next(
            (
                index
                for index in range(len(merged) - 1, -1, -1)
                if merged[index].orientation == item.orientation
                and abs(merged[index].coordinate - item.coordinate) <= tolerance
                and item.start <= merged[index].end + tolerance
                and item.end >= merged[index].start - tolerance
            ),
            None,
        )
        if match_index is None:
            merged.append(item)
            continue
        current = merged[match_index]
        merged[match_index] = _Segment(
            orientation=current.orientation,
            coordinate=round((current.coordinate + item.coordinate) / 2, 6),
            start=min(current.start, item.start),
            end=max(current.end, item.end),
            separator_candidate_ids=tuple(
                sorted(
                    set(current.separator_candidate_ids + item.separator_candidate_ids)
                )
            ),
            drawing_node_ids=tuple(
                sorted(set(current.drawing_node_ids + item.drawing_node_ids))
            ),
            drawing_fact_ids=tuple(
                sorted(set(current.drawing_fact_ids + item.drawing_fact_ids))
            ),
            derivations=tuple(sorted(set(current.derivations + item.derivations))),
            physical_intervals=_merge_interval_sequences(
                current.physical_intervals + item.physical_intervals,
                tolerance=tolerance,
            ),
        )
    return tuple(
        sorted(
            merged,
            key=lambda item: (
                item.orientation,
                item.coordinate,
                item.start,
                item.end,
                item.separator_candidate_ids,
                item.derivations,
            ),
        )
    )


def _interval_union(
    segments: Sequence[_Segment],
    *,
    tolerance: float,
) -> tuple[tuple[float, float], ...]:
    return _merge_interval_sequences(
        tuple((segment.start, segment.end) for segment in segments),
        tolerance=tolerance,
    )


def _merge_interval_sequences(
    intervals: Sequence[tuple[float, float]],
    *,
    tolerance: float,
) -> tuple[tuple[float, float], ...]:
    merged: list[tuple[float, float]] = []
    for start, end in sorted(
        intervals,
        key=lambda item: (item[0], item[1]),
    ):
        if merged and start <= merged[-1][1] + tolerance:
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))
    return tuple(merged)


def _interval_intersection(
    first: Sequence[_Segment],
    second: Sequence[_Segment],
    *,
    tolerance: float,
) -> tuple[tuple[float, float], ...]:
    left = _interval_union(first, tolerance=tolerance)
    right = _interval_union(second, tolerance=tolerance)
    return _intersect_interval_sequences(left, right)


def _intersect_interval_sequences(
    left: Sequence[tuple[float, float]],
    right: Sequence[tuple[float, float]],
) -> tuple[tuple[float, float], ...]:
    result: list[tuple[float, float]] = []
    left_index = 0
    right_index = 0
    while left_index < len(left) and right_index < len(right):
        start = max(left[left_index][0], right[right_index][0])
        end = min(left[left_index][1], right[right_index][1])
        if end > start:
            result.append((start, end))
        if left[left_index][1] < right[right_index][1]:
            left_index += 1
        else:
            right_index += 1
    return tuple(result)


def _interval_length(intervals: Sequence[tuple[float, float]]) -> float:
    return sum(end - start for start, end in intervals)


def _subtract_intervals(
    intervals: Sequence[tuple[float, float]],
    blockers: Sequence[tuple[float, float]],
) -> tuple[tuple[float, float], ...]:
    result = list(intervals)
    for blocker_start, blocker_end in blockers:
        next_result: list[tuple[float, float]] = []
        for start, end in result:
            if blocker_end <= start or blocker_start >= end:
                next_result.append((start, end))
                continue
            if blocker_start > start:
                next_result.append((start, min(end, blocker_start)))
            if blocker_end < end:
                next_result.append((max(start, blocker_end), end))
        result = next_result
    return tuple((start, end) for start, end in result if end - start > 0)


def _collapse_parallel_rule_bands(
    page: PdfTablePageInput,
    segments: tuple[_Segment, ...],
    *,
    text_items: Sequence[_TextItem],
    config: PdfTableAlgorithmConfig,
    tolerance: float,
) -> tuple[_Segment, ...]:
    """Collapse physically painted bevel/band edges to one logical centerline."""
    if not segments or not text_items:
        return segments
    drawing_by_id = {drawing.fact_id: drawing for drawing in page.facts.drawings}
    occlusion_adjusted: list[_Segment] = []
    for segment in segments:
        if not segment.physical_intervals:
            occlusion_adjusted.append(segment)
            continue
        source_orders = tuple(
            drawing_by_id[fact_id].source_order
            for fact_id in segment.drawing_fact_ids
            if fact_id in drawing_by_id
        )
        if not source_orders:
            occlusion_adjusted.append(segment)
            continue
        latest_source_order = max(source_orders)
        blockers = tuple(
            (
                (drawing.bbox.y0, drawing.bbox.y1)
                if segment.orientation == "vertical"
                else (drawing.bbox.x0, drawing.bbox.x1)
            )
            for drawing in page.facts.drawings
            if drawing.kind == "rectangle"
            and drawing.paint_operation == "fill"
            and drawing.source_order > latest_source_order
            and (
                (
                    segment.orientation == "vertical"
                    and drawing.bbox.x0 < segment.coordinate - tolerance
                    and drawing.bbox.x1 > segment.coordinate + tolerance
                )
                or (
                    segment.orientation == "horizontal"
                    and drawing.bbox.y0 < segment.coordinate - tolerance
                    and drawing.bbox.y1 > segment.coordinate + tolerance
                )
            )
        )
        physical_intervals = (
            segment.physical_intervals
            if {"thin_line_rule", "thin_rectangle_rule"} & set(segment.derivations)
            else _subtract_intervals(
                segment.physical_intervals,
                _merge_interval_sequences(blockers, tolerance=tolerance),
            )
        )
        if not physical_intervals:
            continue
        intervals_changed = physical_intervals != segment.physical_intervals
        occlusion_adjusted.append(
            _Segment(
                orientation=segment.orientation,
                coordinate=segment.coordinate,
                start=segment.start,
                end=segment.end,
                separator_candidate_ids=segment.separator_candidate_ids,
                drawing_node_ids=segment.drawing_node_ids,
                drawing_fact_ids=segment.drawing_fact_ids,
                derivations=tuple(
                    sorted(
                        {
                            *segment.derivations,
                            *(("later_fill_occlusion",) if intervals_changed else ()),
                        }
                    )
                ),
                physical_intervals=physical_intervals,
            )
        )
    segments = tuple(occlusion_adjusted)
    text_height = median(
        max(0.1, item.geometry.y1 - item.geometry.y0) for item in text_items
    )
    maximum_triplet_width = (
        text_height * config.weak_axis_cluster_maximum_text_height_multiplier
    )
    maximum_pair_width = tolerance * config.bevel_pair_maximum_tolerance_multiplier
    collapsed_intervals: dict[tuple[str, float], list[tuple[float, float]]] = {}
    replacements: list[_Segment] = []

    def members(orientation: str, coordinate: float) -> tuple[_Segment, ...]:
        return tuple(
            segment
            for segment in segments
            if segment.orientation == orientation
            and abs(segment.coordinate - coordinate) <= tolerance
        )

    def fill_supported(values: Sequence[_Segment]) -> bool:
        fact_ids = {
            fact_id for segment in values for fact_id in segment.drawing_fact_ids
        }
        return bool(fact_ids) and all(
            fact_id in drawing_by_id
            and drawing_by_id[fact_id].paint_operation == "fill"
            for fact_id in fact_ids
        )

    def rule_supported(values: Sequence[_Segment]) -> bool:
        fact_ids = {
            fact_id for segment in values for fact_id in segment.drawing_fact_ids
        }
        return bool(fact_ids) and all(
            fact_id in drawing_by_id
            and drawing_by_id[fact_id].kind in {"line", "rectangle"}
            and drawing_by_id[fact_id].paint_operation
            in {
                "fill",
                "fill_stroke",
                "stroke",
            }
            for fact_id in fact_ids
        )

    def overlap_ratio(first: Sequence[_Segment], second: Sequence[_Segment]) -> float:
        first_intervals = _interval_union(first, tolerance=tolerance)
        second_intervals = _interval_union(second, tolerance=tolerance)
        denominator = min(
            _interval_length(first_intervals),
            _interval_length(second_intervals),
        )
        if denominator <= 0:
            return 0.0
        return (
            _interval_length(_interval_intersection(first, second, tolerance=tolerance))
            / denominator
        )

    def text_free(
        orientation: str,
        low: float,
        high: float,
        intervals: Sequence[tuple[float, float]],
    ) -> bool:
        for item in text_items:
            center_x = (item.geometry.x0 + item.geometry.x1) / 2
            center_y = (item.geometry.y0 + item.geometry.y1) / 2
            cross = center_x if orientation == "vertical" else center_y
            along = center_y if orientation == "vertical" else center_x
            if low < cross < high and any(
                start - tolerance <= along <= end + tolerance
                for start, end in intervals
            ):
                return False
        return True

    def text_is_absent_or_crosses_band(
        orientation: str,
        low: float,
        high: float,
        intervals: Sequence[tuple[float, float]],
    ) -> bool:
        for item in text_items:
            center_x = (item.geometry.x0 + item.geometry.x1) / 2
            center_y = (item.geometry.y0 + item.geometry.y1) / 2
            cross = center_x if orientation == "vertical" else center_y
            along = center_y if orientation == "vertical" else center_x
            if not (
                low < cross < high
                and any(
                    start - tolerance <= along <= end + tolerance
                    for start, end in intervals
                )
            ):
                continue
            cross_start = (
                item.geometry.x0 if orientation == "vertical" else item.geometry.y0
            )
            cross_end = (
                item.geometry.x1 if orientation == "vertical" else item.geometry.y1
            )
            if not (cross_start < low - tolerance and cross_end > high + tolerance):
                return False
        return True

    def add_replacement(
        orientation: str,
        coordinates: tuple[float, ...],
    ) -> None:
        member_groups = tuple(
            members(orientation, coordinate) for coordinate in coordinates
        )
        all_members = tuple(
            segment for group_members in member_groups for segment in group_members
        )
        member_source_orders = tuple(
            drawing_by_id[fact_id].source_order
            for segment in all_members
            for fact_id in segment.drawing_fact_ids
            if fact_id in drawing_by_id
        )
        latest_member_source_order = (
            max(member_source_orders) if member_source_orders else None
        )
        intervals = _interval_intersection(
            member_groups[0],
            member_groups[-1],
            tolerance=tolerance,
        )
        low, high = coordinates[0], coordinates[-1]
        blockers = []
        for drawing in page.facts.drawings:
            if drawing.kind != "rectangle" or drawing.paint_operation != "fill":
                continue
            later_fill = bool(
                latest_member_source_order is not None
                and drawing.source_order > latest_member_source_order
            )
            if orientation == "vertical" and (
                drawing.bbox.x0 < low - maximum_triplet_width
                and drawing.bbox.x1 > high + maximum_triplet_width
                and (
                    later_fill
                    or drawing.bbox.y1 - drawing.bbox.y0 <= maximum_triplet_width * 4
                )
            ):
                blockers.append((drawing.bbox.y0, drawing.bbox.y1))
            elif orientation == "horizontal" and (
                drawing.bbox.y0 < low - maximum_triplet_width
                and drawing.bbox.y1 > high + maximum_triplet_width
                and (
                    later_fill
                    or drawing.bbox.x1 - drawing.bbox.x0 <= maximum_triplet_width * 4
                )
            ):
                blockers.append((drawing.bbox.x0, drawing.bbox.x1))
        for item in text_items:
            if orientation == "vertical" and (
                item.geometry.x0 < low - tolerance
                and item.geometry.x1 > high + tolerance
            ):
                blockers.append((item.geometry.y0, item.geometry.y1))
            elif orientation == "horizontal" and (
                item.geometry.y0 < low - tolerance
                and item.geometry.y1 > high + tolerance
            ):
                blockers.append((item.geometry.x0, item.geometry.x1))
        intervals = _subtract_intervals(
            intervals,
            _merge_interval_sequences(
                blockers,
                tolerance=tolerance,
            ),
        )
        center = round((coordinates[0] + coordinates[-1]) / 2, 6)
        for start, end in intervals:
            evidence_members = tuple(
                segment
                for segment in all_members
                if segment.end >= start - tolerance and segment.start <= end + tolerance
            )
            replacements.append(
                _Segment(
                    orientation=orientation,
                    coordinate=center,
                    start=start,
                    end=end,
                    separator_candidate_ids=tuple(
                        sorted(
                            {
                                value
                                for segment in evidence_members
                                for value in segment.separator_candidate_ids
                            }
                        )
                    ),
                    drawing_node_ids=tuple(
                        sorted(
                            {
                                value
                                for segment in evidence_members
                                for value in segment.drawing_node_ids
                            }
                        )
                    ),
                    drawing_fact_ids=tuple(
                        sorted(
                            {
                                value
                                for segment in evidence_members
                                for value in segment.drawing_fact_ids
                            }
                        )
                    ),
                    derivations=tuple(
                        sorted(
                            {
                                "parallel_rule_band_centerline",
                                *(
                                    value
                                    for segment in evidence_members
                                    for value in segment.derivations
                                ),
                            }
                        )
                    ),
                    physical_intervals=((start, end),),
                )
            )
        for coordinate in coordinates:
            collapsed_intervals.setdefault((orientation, coordinate), []).extend(
                intervals
            )

    for orientation in ("horizontal", "vertical"):
        coordinates = tuple(
            sorted(
                {
                    segment.coordinate
                    for segment in segments
                    if segment.orientation == orientation
                }
            )
        )
        used: set[float] = set()
        for index in range(len(coordinates) - 2):
            group = coordinates[index : index + 3]
            if any(coordinate in used for coordinate in group):
                continue
            outer_first = members(orientation, group[0])
            middle = members(orientation, group[1])
            outer_second = members(orientation, group[2])
            intervals = _interval_intersection(
                outer_first,
                outer_second,
                tolerance=tolerance,
            )
            if not (
                group[2] - group[0] <= maximum_triplet_width
                and group[1] - group[0] > tolerance
                and group[2] - group[1] > tolerance
                and abs(group[1] - (group[0] + group[2]) / 2) <= maximum_pair_width
                and overlap_ratio(outer_first, outer_second) >= 0.8
                and intervals
                and text_is_absent_or_crosses_band(
                    orientation, group[0], group[2], intervals
                )
                and fill_supported((*outer_first, *middle, *outer_second))
            ):
                continue
            add_replacement(orientation, group)
            used.update(group)
        for left, right in zip(coordinates, coordinates[1:]):
            if left in used or right in used:
                continue
            first = members(orientation, left)
            second = members(orientation, right)
            intervals = _interval_intersection(
                first,
                second,
                tolerance=tolerance,
            )
            if not (
                right - left <= maximum_pair_width
                and overlap_ratio(first, second) >= 0.8
                and intervals
                and text_free(orientation, left, right, intervals)
                and (
                    fill_supported((*first, *second))
                    or rule_supported((*first, *second))
                )
            ):
                continue
            add_replacement(orientation, (left, right))
            used.update((left, right))

    if not collapsed_intervals:
        return segments
    retained_parts: list[_Segment] = []
    for segment in segments:
        removed = tuple(
            interval
            for (orientation, coordinate), intervals in collapsed_intervals.items()
            if orientation == segment.orientation
            and abs(segment.coordinate - coordinate) <= tolerance
            for interval in intervals
        )
        if not removed:
            retained_parts.append(segment)
            continue
        residuals = _subtract_intervals(
            ((segment.start, segment.end),),
            _merge_interval_sequences(removed, tolerance=tolerance),
        )
        for start, end in residuals:
            if end - start <= max(tolerance, maximum_triplet_width):
                continue
            retained_parts.append(
                _Segment(
                    orientation=segment.orientation,
                    coordinate=segment.coordinate,
                    start=start,
                    end=end,
                    separator_candidate_ids=segment.separator_candidate_ids,
                    drawing_node_ids=segment.drawing_node_ids,
                    drawing_fact_ids=segment.drawing_fact_ids,
                    derivations=segment.derivations,
                    physical_intervals=tuple(
                        (max(start, interval_start), min(end, interval_end))
                        for interval_start, interval_end in segment.physical_intervals
                        if min(end, interval_end) > max(start, interval_start)
                    ),
                )
            )
    normalized = _merge_collinear_segments(
        (*retained_parts, *replacements),
        tolerance=tolerance,
    )
    return _snap_rule_endpoints_to_band_centerlines(
        normalized,
        tolerance=(tolerance * config.rule_endpoint_connection_tolerance_multiplier),
    )


def _snap_rule_endpoints_to_band_centerlines(
    segments: tuple[_Segment, ...],
    *,
    tolerance: float,
) -> tuple[_Segment, ...]:
    centerlines = tuple(
        segment
        for segment in segments
        if "parallel_rule_band_centerline" in segment.derivations
    )
    snapped: list[_Segment] = []
    for segment in segments:
        perpendicular = tuple(
            candidate
            for candidate in centerlines
            if candidate.orientation != segment.orientation
            and candidate.start - tolerance
            <= segment.coordinate
            <= candidate.end + tolerance
            and (
                abs(segment.start - candidate.coordinate) <= tolerance
                or abs(segment.end - candidate.coordinate) <= tolerance
            )
        )
        if not perpendicular:
            snapped.append(segment)
            continue
        start = segment.start
        end = segment.end
        for candidate in perpendicular:
            if abs(start - candidate.coordinate) <= tolerance:
                start = candidate.coordinate
            if abs(end - candidate.coordinate) <= tolerance:
                end = candidate.coordinate
        physical_intervals = tuple(
            (
                (
                    start
                    if abs(interval_start - segment.start) <= tolerance
                    else interval_start
                ),
                (end if abs(interval_end - segment.end) <= tolerance else interval_end),
            )
            for interval_start, interval_end in segment.physical_intervals
        )
        snapped.append(
            _Segment(
                orientation=segment.orientation,
                coordinate=segment.coordinate,
                start=start,
                end=end,
                separator_candidate_ids=tuple(
                    sorted(
                        {
                            *segment.separator_candidate_ids,
                            *(
                                value
                                for candidate in perpendicular
                                for value in candidate.separator_candidate_ids
                            ),
                        }
                    )
                ),
                drawing_node_ids=tuple(
                    sorted(
                        {
                            *segment.drawing_node_ids,
                            *(
                                value
                                for candidate in perpendicular
                                for value in candidate.drawing_node_ids
                            ),
                        }
                    )
                ),
                drawing_fact_ids=tuple(
                    sorted(
                        {
                            *segment.drawing_fact_ids,
                            *(
                                value
                                for candidate in perpendicular
                                for value in candidate.drawing_fact_ids
                            ),
                        }
                    )
                ),
                derivations=tuple(
                    sorted(
                        {
                            *segment.derivations,
                            "parallel_rule_band_endpoint_snap",
                        }
                    )
                ),
                physical_intervals=physical_intervals,
            )
        )
    return _merge_collinear_segments(snapped, tolerance=tolerance / 2)


def _grid_candidates(
    segments: tuple[_Segment, ...],
    *,
    text_items: Sequence[_TextItem],
    tolerance: float,
    connection_tolerance: float,
    minimum_cells: int,
) -> tuple[tuple[_GridCandidate, ...], int]:
    horizontals = tuple(item for item in segments if item.orientation == "horizontal")
    verticals = tuple(item for item in segments if item.orientation == "vertical")
    total = len(horizontals) + len(verticals)
    union = _UnionFind(total)
    intersection_count = 0
    for h_index, horizontal in enumerate(horizontals):
        for v_index, vertical in enumerate(verticals):
            if _intersects(
                horizontal,
                vertical,
                tolerance=connection_tolerance,
            ):
                union.union(h_index, len(horizontals) + v_index)
                intersection_count += 1
    if not intersection_count:
        return (), 0
    components: dict[int, tuple[list[_Segment], list[_Segment]]] = {}
    for index, horizontal in enumerate(horizontals):
        component = components.setdefault(union.find(index), ([], []))
        component[0].append(horizontal)
    for index, vertical in enumerate(verticals):
        root = union.find(len(horizontals) + index)
        component = components.setdefault(root, ([], []))
        component[1].append(vertical)

    accepted: list[_GridCandidate] = []
    incomplete = 0
    for component_h, component_v in components.values():
        if not component_h or not component_v:
            continue
        rows = _cluster_coordinates(
            (item.coordinate for item in component_h), tolerance=tolerance
        )
        columns = _cluster_coordinates(
            (item.coordinate for item in component_v), tolerance=tolerance
        )
        if len(rows) < 2 or len(columns) < 2:
            continue
        atomic_cells = (len(rows) - 1) * (len(columns) - 1)
        candidate = _GridCandidate(
            horizontals=tuple(component_h),
            verticals=tuple(component_v),
            row_coordinates=rows,
            column_coordinates=columns,
        )
        if atomic_cells < minimum_cells:
            incomplete += 1
            continue
        partitions = _partition_closed_column_ranges(
            candidate,
            text_items=text_items,
            tolerance=tolerance,
            connection_tolerance=connection_tolerance,
            minimum_cells=minimum_cells,
        )
        if not partitions:
            partitions = _partition_closed_row_ranges(
                candidate,
                text_items=text_items,
                tolerance=tolerance,
                connection_tolerance=connection_tolerance,
                minimum_cells=minimum_cells,
            )
        if not partitions:
            incomplete += 1
            continue
        for partition in partitions:
            deduped = _dedupe_close_candidate_axes(
                partition,
                text_items=text_items,
                tolerance=tolerance,
                connection_tolerance=connection_tolerance,
                minimum_cells=minimum_cells,
            )
            if (len(deduped.row_coordinates) - 1) * (
                len(deduped.column_coordinates) - 1
            ) < minimum_cells:
                incomplete += 1
                continue
            accepted.append(deduped)
    return tuple(accepted), incomplete


def _fragmented_horizontal_rule_candidates(
    segments: Sequence[_Segment],
    *,
    tolerance: float,
    connection_tolerance: float,
    minimum_cells: int,
) -> tuple[_GridCandidate, ...]:
    """Recover local grids whose repeated horizontal rules lost their middles."""

    horizontals = tuple(
        segment for segment in segments if segment.orientation == "horizontal"
    )
    verticals = tuple(
        segment for segment in segments if segment.orientation == "vertical"
    )
    vertical_coordinates = _cluster_coordinates(
        (segment.coordinate for segment in verticals),
        tolerance=tolerance,
    )
    if len(vertical_coordinates) < 2 or not horizontals:
        return ()
    gaps = tuple(
        right - left
        for left, right in zip(vertical_coordinates, vertical_coordinates[1:])
        if right > left
    )
    if not gaps:
        return ()
    local_gap = median(gaps)
    if local_gap <= 0:
        return ()

    coordinate_runs: list[list[float]] = []
    for coordinate in vertical_coordinates:
        if coordinate_runs and coordinate - coordinate_runs[-1][-1] <= local_gap * 1.5:
            coordinate_runs[-1].append(coordinate)
        else:
            coordinate_runs.append([coordinate])

    recovered: list[_GridCandidate] = []
    for coordinate_run in coordinate_runs:
        if len(coordinate_run) < 2:
            continue
        run_gaps = tuple(
            right - left for left, right in zip(coordinate_run, coordinate_run[1:])
        )
        run_gap = median(run_gaps)
        inferred_left = coordinate_run[0] - run_gap
        inferred_right = coordinate_run[-1] + run_gap
        row_groups: dict[float, list[_Segment]] = {}
        for horizontal in horizontals:
            if (
                horizontal.end < inferred_left - connection_tolerance
                or horizontal.start > inferred_right + connection_tolerance
            ):
                continue
            coordinate = min(
                (
                    existing
                    for existing in row_groups
                    if abs(existing - horizontal.coordinate) <= tolerance
                ),
                default=horizontal.coordinate,
                key=lambda value: abs(value - horizontal.coordinate),
            )
            row_groups.setdefault(coordinate, []).append(horizontal)

        derived_horizontals: list[_Segment] = []
        for coordinate, members in sorted(row_groups.items()):
            left_members = tuple(
                member
                for member in members
                if abs(member.start - inferred_left) <= connection_tolerance
            )
            right_members = tuple(
                member
                for member in members
                if abs(member.end - inferred_right) <= connection_tolerance
            )
            if not left_members or not right_members:
                continue
            support = tuple((*left_members, *right_members))
            derived_horizontals.append(
                _Segment(
                    orientation="horizontal",
                    coordinate=coordinate,
                    start=min(member.start for member in left_members),
                    end=max(member.end for member in right_members),
                    separator_candidate_ids=tuple(
                        sorted(
                            {
                                value
                                for member in support
                                for value in member.separator_candidate_ids
                            }
                        )
                    ),
                    drawing_node_ids=tuple(
                        sorted(
                            {
                                value
                                for member in support
                                for value in member.drawing_node_ids
                            }
                        )
                    ),
                    drawing_fact_ids=tuple(
                        sorted(
                            {
                                value
                                for member in support
                                for value in member.drawing_fact_ids
                            }
                        )
                    ),
                    derivations=tuple(
                        sorted(
                            {
                                *(
                                    value
                                    for member in support
                                    for value in member.derivations
                                ),
                                "shared_horizontal_rule_damage_band_continuity",
                            }
                        )
                    ),
                    physical_intervals=_merge_interval_sequences(
                        tuple(
                            interval
                            for member in support
                            for interval in member.physical_intervals
                        ),
                        tolerance=tolerance,
                    ),
                )
            )
        rows = tuple(horizontal.coordinate for horizontal in derived_horizontals)
        if len(rows) < 2 or (len(rows) - 1) * (len(coordinate_run) - 1) < minimum_cells:
            continue
        candidate = _GridCandidate(
            horizontals=tuple(derived_horizontals),
            verticals=tuple(
                vertical
                for vertical in verticals
                if any(
                    abs(vertical.coordinate - coordinate) <= tolerance
                    for coordinate in coordinate_run
                )
            ),
            row_coordinates=rows,
            column_coordinates=tuple(coordinate_run),
        )
        candidate = _restore_horizontal_bounded_outer_columns(
            candidate,
            tolerance=connection_tolerance,
        )
        if _outer_enclosure_complete(
            candidate,
            tolerance=connection_tolerance,
        ):
            recovered.append(candidate)
    return tuple(recovered)


def _dedupe_close_candidate_axes(
    candidate: _GridCandidate,
    *,
    text_items: Sequence[_TextItem],
    tolerance: float,
    connection_tolerance: float,
    minimum_cells: int,
) -> _GridCandidate:
    rows = _dedupe_close_axis_coordinates(
        "row",
        candidate.row_coordinates,
        candidate.horizontals,
        text_items=text_items,
        span=(candidate.column_coordinates[0], candidate.column_coordinates[-1]),
        tolerance=tolerance,
        connection_tolerance=connection_tolerance,
    )
    columns = _dedupe_close_axis_coordinates(
        "column",
        candidate.column_coordinates,
        candidate.verticals,
        text_items=text_items,
        span=(rows[0], rows[-1]),
        tolerance=tolerance,
        connection_tolerance=connection_tolerance,
    )
    if (len(rows) - 1) * (len(columns) - 1) < minimum_cells:
        return candidate
    return _GridCandidate(
        horizontals=candidate.horizontals,
        verticals=candidate.verticals,
        row_coordinates=rows,
        column_coordinates=columns,
    )


def _dedupe_close_axis_coordinates(
    axis: str,
    coordinates: Sequence[float],
    segments: Sequence[_Segment],
    *,
    text_items: Sequence[_TextItem],
    span: tuple[float, float],
    tolerance: float,
    connection_tolerance: float,
) -> tuple[float, ...]:
    if len(coordinates) < 2:
        return tuple(coordinates)

    groups: list[list[float]] = []
    for coordinate in sorted(coordinates):
        if groups and coordinate - groups[-1][-1] <= connection_tolerance:
            groups[-1].append(coordinate)
        else:
            groups.append([coordinate])

    result: list[float] = []
    for group in groups:
        if len(group) == 1:
            result.append(group[0])
            continue
        low, high = group[0], group[-1]
        if _close_axis_band_contains_text(
            axis,
            low,
            high,
            span,
            text_items=text_items,
            tolerance=tolerance,
        ):
            result.extend(group)
            continue
        result.append(
            _preferred_close_axis_coordinate(
                axis,
                group,
                segments,
                span=span,
                tolerance=tolerance,
            )
        )
    return tuple(result)


def _close_axis_band_contains_text(
    axis: str,
    low: float,
    high: float,
    span: tuple[float, float],
    *,
    text_items: Sequence[_TextItem],
    tolerance: float,
) -> bool:
    for item in text_items:
        center_x = (item.geometry.x0 + item.geometry.x1) / 2
        center_y = (item.geometry.y0 + item.geometry.y1) / 2
        cross = center_y if axis == "row" else center_x
        along_start, along_end = (
            (item.geometry.x0, item.geometry.x1)
            if axis == "row"
            else (item.geometry.y0, item.geometry.y1)
        )
        if not (low + tolerance < cross < high - tolerance):
            continue
        if along_end >= span[0] - tolerance and along_start <= span[1] + tolerance:
            return True
    return False


def _preferred_close_axis_coordinate(
    axis: str,
    group: Sequence[float],
    segments: Sequence[_Segment],
    *,
    span: tuple[float, float],
    tolerance: float,
) -> float:
    orientation = "horizontal" if axis == "row" else "vertical"

    def score(coordinate: float) -> tuple[int, float, float]:
        candidates = tuple(
            segment
            for segment in segments
            if segment.orientation == orientation
            and abs(segment.coordinate - coordinate) <= tolerance
        )
        coverage = _interval_length(
            _intersect_interval_sequences(
                _merge_interval_sequences(
                    tuple((segment.start, segment.end) for segment in candidates),
                    tolerance=tolerance,
                ),
                (span,),
            )
        )
        has_centerline = any(
            "parallel_rule_band_centerline" in segment.derivations
            for segment in candidates
        )
        return (1 if has_centerline else 0, coverage, -abs(coordinate - median(group)))

    return max(group, key=score)


def _partition_closed_column_ranges(
    candidate: _GridCandidate,
    *,
    text_items: Sequence[_TextItem],
    tolerance: float,
    connection_tolerance: float,
    minimum_cells: int,
) -> tuple[_GridCandidate, ...]:
    if len(candidate.column_coordinates) < 5 or not text_items:
        return ()
    y0, y1 = candidate.row_coordinates[0], candidate.row_coordinates[-1]
    intervals = tuple(
        zip(candidate.column_coordinates, candidate.column_coordinates[1:])
    )

    def interval_text_count(left: float, right: float) -> int:
        return sum(
            1
            for item in text_items
            if left + tolerance
            <= (item.geometry.x0 + item.geometry.x1) / 2
            <= right - tolerance
            and y0 + tolerance
            <= (item.geometry.y0 + item.geometry.y1) / 2
            <= y1 - tolerance
        )

    counts = tuple(interval_text_count(left, right) for left, right in intervals)
    text_widths = tuple(
        right - left
        for (left, right), count in zip(intervals, counts)
        if count > 0 and right > left
    )
    if len(text_widths) < 2:
        return ()
    local_width = median(text_widths)
    if local_width <= 0:
        return ()

    gutter_indexes: list[int] = []
    wide_zero_occupancy_indexes: list[int] = []
    bilateral_zero_occupancy_indexes: list[int] = []
    fill_bounded_zero_occupancy_indexes: list[int] = []
    for index, ((left, right), count) in enumerate(zip(intervals, counts)):
        if count > 1:
            continue
        if index < 1 or index > len(intervals) - 2:
            continue
        if not any(counts[:index]) or not any(counts[index + 1 :]):
            continue
        bilateral_zero_occupancy = count == 0 and _has_bilateral_unbridged_gutter_edges(
            candidate,
            left=left,
            right=right,
            tolerance=connection_tolerance,
        )
        bilateral_fill_bounded = bilateral_zero_occupancy and _has_unbridged_gutter_run(
            candidate,
            edge_intervals=tuple(
                _local_physical_gutter_edge_support(
                    candidate,
                    coordinate=coordinate,
                    tolerance=connection_tolerance,
                )[1]
                for coordinate in (left, right)
            ),
            left=left,
            right=right,
            tolerance=connection_tolerance,
        )
        width_multiplier = 0.55 if count else 0.65
        if right - left <= local_width * width_multiplier:
            if bilateral_zero_occupancy:
                gutter_indexes.append(index)
                bilateral_zero_occupancy_indexes.append(index)
                if bilateral_fill_bounded:
                    fill_bounded_zero_occupancy_indexes.append(index)
            continue
        if bilateral_zero_occupancy:
            wide_zero_occupancy_indexes.append(index)
            if bilateral_fill_bounded:
                fill_bounded_zero_occupancy_indexes.append(index)
    if not gutter_indexes and len(wide_zero_occupancy_indexes) == 1:
        gutter_indexes = wide_zero_occupancy_indexes
    if len(gutter_indexes) != 1:
        return ()
    wide_zero_occupancy_partition = gutter_indexes == wide_zero_occupancy_indexes
    bilateral_zero_occupancy_partition = (
        len(gutter_indexes) == 1 and gutter_indexes == bilateral_zero_occupancy_indexes
    )
    fill_bounded_zero_occupancy_partition = (
        len(gutter_indexes) == 1
        and gutter_indexes == fill_bounded_zero_occupancy_indexes
    )

    column_runs: list[tuple[int, int]] = []
    start = 0
    for gutter_index in gutter_indexes:
        if gutter_index + 1 - start >= 2:
            column_runs.append((start, gutter_index + 1))
        start = gutter_index + 1
    if len(candidate.column_coordinates) - start >= 2:
        column_runs.append((start, len(candidate.column_coordinates)))
    if len(column_runs) < 2:
        return ()

    pieces: list[_GridCandidate] = []
    for start_column, end_column in column_runs:
        column_coordinates = candidate.column_coordinates[start_column:end_column]
        if len(column_coordinates) < 2:
            continue
        x0, x1 = column_coordinates[0], column_coordinates[-1]
        piece_horizontals = tuple(
            clipped
            for segment in candidate.horizontals
            for clipped in (
                _clip_segment_interval(
                    segment,
                    start=x0,
                    end=x1,
                    derivation=(
                        "wide_zero_occupancy_gutter_partition_clip"
                        if wide_zero_occupancy_partition
                        else (
                            "bilateral_zero_occupancy_gutter_partition_clip"
                            if bilateral_zero_occupancy_partition
                            else "column_range_partition_clip"
                        )
                    ),
                ),
            )
            if clipped is not None
            and y0 - tolerance <= clipped.coordinate <= y1 + tolerance
            and clipped.start <= x1 + tolerance
            and clipped.end >= x0 - tolerance
        )
        row_coordinates = _cluster_coordinates(
            (segment.coordinate for segment in piece_horizontals),
            tolerance=tolerance,
        )
        if len(row_coordinates) < 2:
            continue
        column_piece = _GridCandidate(
            horizontals=piece_horizontals,
            verticals=tuple(
                segment
                for segment in candidate.verticals
                if any(
                    abs(segment.coordinate - column) <= tolerance
                    for column in column_coordinates
                )
                and segment.start <= y1 + tolerance
                and segment.end >= y0 - tolerance
            ),
            row_coordinates=row_coordinates,
            column_coordinates=column_coordinates,
        )
        pieces.extend(
            _partition_closed_row_ranges(
                column_piece,
                text_items=text_items,
                tolerance=tolerance,
                connection_tolerance=connection_tolerance,
                minimum_cells=minimum_cells,
            )
        )
    if len(pieces) < 2:
        return ()
    if fill_bounded_zero_occupancy_partition:
        pieces = [
            _extend_candidate_outer_rows_from_text(
                piece,
                text_items=text_items,
                tolerance=connection_tolerance,
            )
            for piece in pieces
        ]
        if not all(
            _outer_enclosure_complete(piece, tolerance=connection_tolerance)
            and not _has_unresolved_horizontal_extension(
                piece,
                tolerance=tolerance,
            )
            for piece in pieces
        ):
            return ()
    spans = {
        (round(piece.geometry.y0, 6), round(piece.geometry.y1, 6)) for piece in pieces
    }
    if len(spans) < 2 and not (
        wide_zero_occupancy_partition or bilateral_zero_occupancy_partition
    ):
        return ()
    return tuple(
        sorted(
            pieces,
            key=lambda item: (
                item.geometry.y0,
                item.geometry.x0,
                item.geometry.y1,
                item.geometry.x1,
            ),
        )
    )


def _has_bilateral_unbridged_gutter_edges(
    candidate: _GridCandidate,
    *,
    left: float,
    right: float,
    tolerance: float,
) -> bool:
    edge_intervals = tuple(
        _local_physical_gutter_edge_support(
            candidate,
            coordinate=coordinate,
            tolerance=tolerance,
        )[0]
        for coordinate in (left, right)
    )
    return _has_unbridged_gutter_run(
        candidate,
        edge_intervals=edge_intervals,
        left=left,
        right=right,
        tolerance=tolerance,
    )


def _local_physical_gutter_edge_support(
    candidate: _GridCandidate,
    *,
    coordinate: float,
    tolerance: float,
) -> tuple[
    tuple[tuple[float, float], ...],
    tuple[tuple[float, float], ...],
]:
    """Return local physical and repeated precise-fill support for one edge."""

    physical_intervals: list[tuple[float, float]] = []
    fill_intervals: list[tuple[float, float]] = []
    for segment in candidate.verticals:
        if abs(segment.coordinate - coordinate) > tolerance:
            continue
        physical_intervals.extend(segment.physical_intervals)
        if (
            {
                "filled_row_band_edge",
                "filled_row_band_outer_boundary",
            }
            <= set(segment.derivations)
            and len(segment.drawing_fact_ids) >= 2
            and len(segment.drawing_node_ids) >= 2
        ):
            fill_intervals.append((segment.start, segment.end))
    merged_fill = _merge_interval_sequences(
        tuple(fill_intervals),
        tolerance=tolerance,
    )
    return (
        _merge_interval_sequences(
            (*physical_intervals, *merged_fill),
            tolerance=tolerance,
        ),
        merged_fill,
    )


def _has_unbridged_gutter_run(
    candidate: _GridCandidate,
    *,
    edge_intervals: tuple[tuple[tuple[float, float], ...], ...],
    left: float,
    right: float,
    tolerance: float,
) -> bool:
    """Accept one complete local bilateral run only when that run is unbridged."""

    bilateral_intervals = _intersect_interval_sequences(*edge_intervals)
    eligible_intervals = tuple(
        (interval_start, interval_end)
        for interval_start, interval_end in bilateral_intervals
        if any(
            interval_start <= row_start + tolerance
            and interval_end >= row_end - tolerance
            for row_start, row_end in zip(
                candidate.row_coordinates,
                candidate.row_coordinates[1:],
            )
        )
    )
    if not eligible_intervals:
        return False
    bridge_coordinates = tuple(
        segment.coordinate
        for segment in candidate.horizontals
        if any(
            interval_start < left - tolerance and interval_end > right + tolerance
            for interval_start, interval_end in segment.physical_intervals
        )
    )
    for interval_start, interval_end in eligible_intervals:
        local_bridge_coordinates = tuple(
            coordinate
            for coordinate in bridge_coordinates
            if interval_start - tolerance <= coordinate <= interval_end + tolerance
        )
        if not local_bridge_coordinates:
            return True
        if (
            len(local_bridge_coordinates) == 1
            and abs(local_bridge_coordinates[0] - interval_end) <= tolerance
            and abs(interval_end - candidate.row_coordinates[-1]) <= tolerance
        ):
            return True
    return False


def _clip_segment_interval(
    segment: _Segment,
    *,
    start: float,
    end: float,
    derivation: str,
) -> _Segment | None:
    clipped_start = max(segment.start, start)
    clipped_end = min(segment.end, end)
    if clipped_end <= clipped_start:
        return None
    if clipped_start == segment.start and clipped_end == segment.end:
        return segment
    return _Segment(
        orientation=segment.orientation,
        coordinate=segment.coordinate,
        start=clipped_start,
        end=clipped_end,
        separator_candidate_ids=segment.separator_candidate_ids,
        drawing_node_ids=segment.drawing_node_ids,
        drawing_fact_ids=segment.drawing_fact_ids,
        derivations=tuple(sorted({*segment.derivations, derivation})),
        physical_intervals=tuple(
            (max(clipped_start, interval_start), min(clipped_end, interval_end))
            for interval_start, interval_end in segment.physical_intervals
            if min(clipped_end, interval_end) > max(clipped_start, interval_start)
        ),
    )


def _partition_closed_row_ranges(
    candidate: _GridCandidate,
    *,
    text_items: Sequence[_TextItem],
    tolerance: float,
    connection_tolerance: float,
    minimum_cells: int,
) -> tuple[_GridCandidate, ...]:
    candidate = _restore_horizontal_bounded_outer_columns(
        candidate,
        tolerance=connection_tolerance,
    )
    candidate = _restore_shared_vertical_rule_continuity(
        candidate,
        text_items=text_items,
        tolerance=connection_tolerance,
    )
    if _outer_enclosure_complete(
        candidate,
        tolerance=connection_tolerance,
    ):
        return (
            ()
            if _has_unresolved_horizontal_extension(candidate, tolerance=tolerance)
            else (candidate,)
        )
    left = candidate.column_coordinates[0]
    right = candidate.column_coordinates[-1]
    covered = []
    for y0, y1 in zip(candidate.row_coordinates, candidate.row_coordinates[1:]):
        covered.append(
            _covers_interval(
                candidate.verticals,
                coordinate=left,
                start=y0,
                end=y1,
                tolerance=connection_tolerance,
            )
            and _covers_interval(
                candidate.verticals,
                coordinate=right,
                start=y0,
                end=y1,
                tolerance=connection_tolerance,
            )
        )
    runs: list[tuple[int, int]] = []
    start: int | None = None
    for index, is_covered in enumerate(covered + [False]):
        if is_covered and start is None:
            start = index
        elif not is_covered and start is not None:
            runs.append((start, index))
            start = None
    result = []
    column_count = len(candidate.column_coordinates) - 1
    for start, end in runs:
        if (end - start) * column_count < minimum_cells:
            continue
        partition = _GridCandidate(
            horizontals=candidate.horizontals,
            verticals=candidate.verticals,
            row_coordinates=candidate.row_coordinates[start : end + 1],
            column_coordinates=candidate.column_coordinates,
        )
        if _outer_enclosure_complete(
            partition,
            tolerance=connection_tolerance,
        ) and not _has_unresolved_horizontal_extension(partition, tolerance=tolerance):
            result.append(partition)
    return tuple(result)


def _restore_horizontal_bounded_outer_columns(
    candidate: _GridCandidate,
    *,
    tolerance: float,
) -> _GridCandidate:
    """Recover missing outer columns from repeated full-width horizontal rules."""

    columns = candidate.column_coordinates
    rows = candidate.row_coordinates
    if len(columns) < 3 or len(rows) < 3:
        return candidate
    column_gaps = tuple(
        right - left for left, right in zip(columns, columns[1:]) if right > left
    )
    if not column_gaps:
        return candidate
    local_gap = median(column_gaps)
    if local_gap <= 0:
        return candidate

    left = columns[0]
    right = columns[-1]
    spanning = tuple(
        segment
        for segment in candidate.horizontals
        if segment.start < left - tolerance or segment.end > right + tolerance
    )
    if len(spanning) < 2:
        return candidate
    inferred_left = min(segment.start for segment in spanning)
    inferred_right = max(segment.end for segment in spanning)
    additions: list[_Segment] = []
    restored_columns = list(columns)

    def repeated_endpoint(coordinate: float, *, start: bool) -> bool:
        return (
            sum(
                abs((segment.start if start else segment.end) - coordinate) <= tolerance
                for segment in candidate.horizontals
            )
            >= 2
        )

    if (
        inferred_left < left - tolerance
        and abs((left - inferred_left) - local_gap) <= tolerance * 2
        and repeated_endpoint(inferred_left, start=True)
    ):
        additions.append(
            _Segment(
                orientation="vertical",
                coordinate=inferred_left,
                start=rows[0],
                end=rows[-1],
                separator_candidate_ids=tuple(
                    sorted(
                        {
                            candidate_id
                            for segment in spanning
                            for candidate_id in segment.separator_candidate_ids
                        }
                    )
                ),
                drawing_node_ids=tuple(
                    sorted(
                        {
                            node_id
                            for segment in spanning
                            for node_id in segment.drawing_node_ids
                        }
                    )
                ),
                drawing_fact_ids=tuple(
                    sorted(
                        {
                            fact_id
                            for segment in spanning
                            for fact_id in segment.drawing_fact_ids
                        }
                    )
                ),
                derivations=("horizontal_bounded_outer_column_boundary",),
            )
        )
        restored_columns.insert(0, inferred_left)
    if (
        inferred_right > right + tolerance
        and abs((inferred_right - right) - local_gap) <= tolerance * 2
        and repeated_endpoint(inferred_right, start=False)
    ):
        additions.append(
            _Segment(
                orientation="vertical",
                coordinate=inferred_right,
                start=rows[0],
                end=rows[-1],
                separator_candidate_ids=tuple(
                    sorted(
                        {
                            candidate_id
                            for segment in spanning
                            for candidate_id in segment.separator_candidate_ids
                        }
                    )
                ),
                drawing_node_ids=tuple(
                    sorted(
                        {
                            node_id
                            for segment in spanning
                            for node_id in segment.drawing_node_ids
                        }
                    )
                ),
                drawing_fact_ids=tuple(
                    sorted(
                        {
                            fact_id
                            for segment in spanning
                            for fact_id in segment.drawing_fact_ids
                        }
                    )
                ),
                derivations=("horizontal_bounded_outer_column_boundary",),
            )
        )
        restored_columns.append(inferred_right)
    if not additions:
        return candidate
    return _GridCandidate(
        horizontals=candidate.horizontals,
        verticals=tuple((*candidate.verticals, *additions)),
        row_coordinates=rows,
        column_coordinates=tuple(restored_columns),
    )


def _restore_shared_vertical_rule_continuity(
    candidate: _GridCandidate,
    *,
    text_items: Sequence[_TextItem],
    tolerance: float,
) -> _GridCandidate:
    """Restore bounded broken rules in a physically row-complete dense grid."""

    rows = candidate.row_coordinates
    columns = candidate.column_coordinates
    if len(rows) < 5 or len(columns) < 4:
        return candidate
    left = columns[0]
    right = columns[-1]
    if not all(
        _covers_interval(
            candidate.horizontals,
            coordinate=row,
            start=left,
            end=right,
            tolerance=tolerance,
        )
        for row in rows
    ):
        return candidate

    def physically_covers(*, coordinate: float, start: float, end: float) -> bool:
        return any(
            abs(segment.coordinate - coordinate) <= tolerance
            and any(
                interval_start <= start + tolerance and interval_end >= end - tolerance
                for interval_start, interval_end in segment.physical_intervals
            )
            for segment in candidate.verticals
        )

    coverage = tuple(
        tuple(
            physically_covers(coordinate=column, start=y0, end=y1) for column in columns
        )
        for y0, y1 in zip(rows, rows[1:])
    )
    occupied = {
        (row_index, column_index)
        for item in text_items
        for row_index in _possible_containing_intervals(
            (item.geometry.y0 + item.geometry.y1) / 2,
            rows,
            tolerance=tolerance,
        )
        for column_index in _possible_containing_intervals(
            (item.geometry.x0 + item.geometry.x1) / 2,
            columns,
            tolerance=tolerance,
        )
    }
    if len(occupied) != (len(rows) - 1) * (len(columns) - 1):
        return candidate

    physical_columns = tuple(
        column_index
        for column_index, coordinate in enumerate(columns)
        if any(
            abs(segment.coordinate - coordinate) <= tolerance
            and segment.physical_intervals
            for segment in candidate.verticals
        )
    )
    fragmented_columns: list[int] = []
    for column_index in physical_columns:
        missing_rows = tuple(
            row_index
            for row_index, row_coverage in enumerate(coverage)
            if not row_coverage[column_index]
        )
        if (
            not missing_rows
            or missing_rows != tuple(range(missing_rows[0], missing_rows[-1] + 1))
            or missing_rows[0] == 0
            or missing_rows[-1] == len(coverage) - 1
        ):
            continue
        fragmented_columns.append(column_index)
    if not physical_columns or len(fragmented_columns) != len(physical_columns):
        return candidate

    derived_verticals = list(candidate.verticals)
    for column_index in fragmented_columns:
        coordinate = columns[column_index]
        support = tuple(
            segment
            for segment in candidate.verticals
            if abs(segment.coordinate - coordinate) <= tolerance
        )
        derived_verticals.append(
            _Segment(
                orientation="vertical",
                coordinate=coordinate,
                start=rows[0],
                end=rows[-1],
                separator_candidate_ids=tuple(
                    sorted(
                        {
                            candidate_id
                            for segment in support
                            for candidate_id in segment.separator_candidate_ids
                        }
                    )
                ),
                drawing_node_ids=tuple(
                    sorted(
                        {
                            node_id
                            for segment in support
                            for node_id in segment.drawing_node_ids
                        }
                    )
                ),
                drawing_fact_ids=tuple(
                    sorted(
                        {
                            fact_id
                            for segment in support
                            for fact_id in segment.drawing_fact_ids
                        }
                    )
                ),
                derivations=("shared_vertical_rule_damage_band_continuity",),
            )
        )
    return _GridCandidate(
        horizontals=candidate.horizontals,
        verticals=tuple(derived_verticals),
        row_coordinates=rows,
        column_coordinates=columns,
    )


def _split_candidate_by_row_topology(
    candidate: _GridCandidate,
    *,
    text_items: Sequence[_TextItem] = (),
    tolerance: float,
    minimum_cells: int,
) -> tuple[_GridCandidate, ...]:
    """Split stacked table regions when internal column topology changes."""

    row_count = len(candidate.row_coordinates) - 1
    if row_count < 2 or len(candidate.column_coordinates) < 3:
        return (candidate,)
    disjoint_physical_runs = _split_disjoint_closed_physical_row_runs(
        candidate,
        text_items=text_items,
        tolerance=tolerance,
        minimum_cells=minimum_cells,
    )
    if len(disjoint_physical_runs) > 1:
        return disjoint_physical_runs
    internal_columns = candidate.column_coordinates[1:-1]
    if not internal_columns:
        return (candidate,)
    signatures: list[tuple[float, ...]] = []
    for row_index in range(row_count):
        y0 = candidate.row_coordinates[row_index]
        y1 = candidate.row_coordinates[row_index + 1]
        signatures.append(
            tuple(
                column
                for column in internal_columns
                if _covers_interval(
                    candidate.verticals,
                    coordinate=column,
                    start=y0,
                    end=y1,
                    tolerance=tolerance,
                )
            )
        )
    if len({signature for signature in signatures if signature}) < 2:
        return (candidate,)

    def text_in_interval(index: int) -> bool:
        y0 = candidate.row_coordinates[index]
        y1 = candidate.row_coordinates[index + 1]
        x0 = candidate.column_coordinates[0]
        x1 = candidate.column_coordinates[-1]
        return any(
            x0 + tolerance
            <= (item.geometry.x0 + item.geometry.x1) / 2
            <= x1 - tolerance
            and y0 + tolerance
            <= (item.geometry.y0 + item.geometry.y1) / 2
            <= y1 - tolerance
            for item in text_items
        )

    def nearest_nonempty_before(index: int) -> tuple[float, ...]:
        for candidate_index in range(index - 1, -1, -1):
            if signatures[candidate_index]:
                return signatures[candidate_index]
        return ()

    def nearest_nonempty_after(index: int) -> tuple[float, ...]:
        for candidate_index in range(index + 1, len(signatures)):
            if signatures[candidate_index]:
                return signatures[candidate_index]
        return ()

    def dominant_run_signature(start: int, end: int) -> tuple[float, ...]:
        counts = Counter(signature for signature in signatures[start:end] if signature)
        if not counts:
            return ()
        return max(counts, key=lambda signature: (counts[signature], len(signature)))

    split_intervals: list[tuple[int, bool]] = []
    for index, signature in enumerate(signatures):
        if signature:
            continue
        has_text = text_in_interval(index)
        if (
            has_text
            and index > 0
            and not signatures[index - 1]
            and not text_in_interval(index - 1)
        ):
            continue
        before = nearest_nonempty_before(index)
        after = nearest_nonempty_after(index)
        if not before or not after:
            continue
        shared = len(set(before) & set(after))
        overlap = shared / max(min(len(before), len(after)), 1)
        if overlap < 0.5:
            split_intervals.append((index, has_text))
    if not split_intervals:
        return (candidate,)

    runs: list[tuple[int, int, tuple[float, ...]]] = []
    start = 0
    for split_index, include_in_previous in split_intervals:
        end = split_index + 1 if include_in_previous else split_index
        if end > start:
            signature = dominant_run_signature(start, end)
            if signature:
                runs.append((start, end, signature))
        start = split_index + 1
    if start < len(signatures):
        signature = dominant_run_signature(start, len(signatures))
        if signature:
            runs.append((start, len(signatures), signature))

    pieces: list[_GridCandidate] = []
    for start_row, end_row, signature in runs:
        row_coordinates = candidate.row_coordinates[start_row : end_row + 1]
        column_coordinates = (
            candidate.column_coordinates[0],
            *signature,
            candidate.column_coordinates[-1],
        )
        if (len(row_coordinates) - 1) * (len(column_coordinates) - 1) < minimum_cells:
            continue
        y0, y1 = row_coordinates[0], row_coordinates[-1]
        x0, x1 = column_coordinates[0], column_coordinates[-1]
        piece = _GridCandidate(
            horizontals=tuple(
                segment
                for segment in candidate.horizontals
                if y0 - tolerance <= segment.coordinate <= y1 + tolerance
                and segment.start <= x1 + tolerance
                and segment.end >= x0 - tolerance
            ),
            verticals=tuple(
                segment
                for segment in candidate.verticals
                if any(
                    abs(segment.coordinate - column) <= tolerance
                    for column in column_coordinates
                )
                and segment.start <= y1 + tolerance
                and segment.end >= y0 - tolerance
            ),
            row_coordinates=row_coordinates,
            column_coordinates=column_coordinates,
        )
        if _outer_enclosure_complete(piece, tolerance=tolerance):
            pieces.append(piece)
    if len(pieces) < 2:
        return (candidate,)
    return tuple(
        sorted(
            pieces,
            key=lambda item: (
                item.geometry.y0,
                item.geometry.x0,
                item.geometry.y1,
                item.geometry.x1,
            ),
        )
    )


def _split_disjoint_closed_physical_row_runs(
    candidate: _GridCandidate,
    *,
    text_items: Sequence[_TextItem],
    tolerance: float,
    minimum_cells: int,
) -> tuple[_GridCandidate, ...]:
    if any(
        {
            "shared_vertical_rule_damage_band_continuity",
            "later_fill_occlusion",
        }
        & set(segment.derivations)
        for segment in candidate.verticals
    ):
        return (candidate,)
    internal_columns = candidate.column_coordinates[1:-1]
    if not internal_columns:
        return (candidate,)

    def physically_covers(*, coordinate: float, start: float, end: float) -> bool:
        return any(
            abs(segment.coordinate - coordinate) <= tolerance
            and any(
                interval_start <= start + tolerance and interval_end >= end - tolerance
                for interval_start, interval_end in segment.physical_intervals
            )
            for segment in candidate.verticals
        )

    complete_rows = tuple(
        all(
            physically_covers(coordinate=column, start=y0, end=y1)
            for column in internal_columns
        )
        for y0, y1 in zip(candidate.row_coordinates, candidate.row_coordinates[1:])
    )
    runs: list[tuple[int, int]] = []
    start: int | None = None
    for index, complete in enumerate((*complete_rows, False)):
        if complete and start is None:
            start = index
        elif not complete and start is not None:
            runs.append((start, index))
            start = None
    if len(runs) < 2 or any(
        next_start - previous_end < 2
        for (_previous_start, previous_end), (next_start, _next_end) in zip(
            runs, runs[1:]
        )
    ):
        return (candidate,)
    if any(
        any(
            candidate.geometry.x0 + tolerance
            <= (item.geometry.x0 + item.geometry.x1) / 2
            <= candidate.geometry.x1 - tolerance
            and candidate.row_coordinates[previous_end] + tolerance
            <= (item.geometry.y0 + item.geometry.y1) / 2
            <= candidate.row_coordinates[next_start] - tolerance
            and any(
                item.geometry.x0 < column - tolerance
                and item.geometry.x1 > column + tolerance
                for column in internal_columns
            )
            for item in text_items
        )
        for (_previous_start, previous_end), (next_start, _next_end) in zip(
            runs, runs[1:]
        )
    ):
        return (candidate,)

    column_count = len(candidate.column_coordinates) - 1
    pieces: list[_GridCandidate] = []
    for start_row, end_row in runs:
        if (end_row - start_row) * column_count < minimum_cells:
            return (candidate,)
        y0 = candidate.row_coordinates[start_row]
        y1 = candidate.row_coordinates[end_row]
        piece = _GridCandidate(
            horizontals=tuple(
                segment
                for segment in candidate.horizontals
                if y0 - tolerance <= segment.coordinate <= y1 + tolerance
            ),
            verticals=tuple(
                segment
                for segment in candidate.verticals
                if segment.start <= y1 + tolerance and segment.end >= y0 - tolerance
            ),
            row_coordinates=candidate.row_coordinates[start_row : end_row + 1],
            column_coordinates=candidate.column_coordinates,
        )
        if not _outer_enclosure_complete(piece, tolerance=tolerance):
            return (candidate,)
        pieces.append(piece)
    return tuple(pieces)


def _extend_candidate_outer_rows_from_text(
    candidate: _GridCandidate,
    *,
    text_items: Sequence[_TextItem],
    tolerance: float,
) -> _GridCandidate:
    if len(candidate.row_coordinates) < 3 or not text_items:
        return candidate
    row_gaps = tuple(
        next_value - value
        for value, next_value in zip(
            candidate.row_coordinates, candidate.row_coordinates[1:]
        )
        if next_value > value
    )
    if not row_gaps:
        return candidate
    local_gap = median(row_gaps)
    if local_gap <= 0:
        return candidate
    x0, x1 = candidate.column_coordinates[0], candidate.column_coordinates[-1]
    column_count = len(candidate.column_coordinates) - 1
    inside_x = tuple(
        item
        for item in text_items
        if x0 + tolerance <= (item.geometry.x0 + item.geometry.x1) / 2 <= x1 - tolerance
    )
    if not inside_x:
        return candidate
    text_height = median(
        max(0.1, item.geometry.y1 - item.geometry.y0) for item in inside_x
    )
    first_row = candidate.row_coordinates[0]
    last_row = candidate.row_coordinates[-1]

    additions: list[_Segment] = []
    vertical_additions: list[_Segment] = []
    rows = list(candidate.row_coordinates)

    def occupied_columns(items: Sequence[_TextItem]) -> set[int]:
        result = set()
        for item in items:
            center_x = (item.geometry.x0 + item.geometry.x1) / 2
            column = _containing_interval(
                center_x, candidate.column_coordinates, tolerance=tolerance
            )
            if column is not None:
                result.add(column)
        return result

    minimum_occupied_columns = max(2, min(3, column_count))

    def sufficient_column_coverage(items: Sequence[_TextItem]) -> bool:
        columns = occupied_columns(items)
        return len(columns) >= minimum_occupied_columns or (
            len(columns) >= 2 and max(columns) - min(columns) >= 2
        )

    def nearest_text_band(
        items: Sequence[_TextItem], *, before: bool
    ) -> tuple[_TextItem, ...]:
        if not items:
            return ()
        line_tolerance = max(0.5, text_height * 0.75)
        ordered = sorted(
            items,
            key=lambda item: (item.geometry.y0 + item.geometry.y1) / 2,
        )
        lines: list[list[_TextItem]] = []
        for item in ordered:
            center = (item.geometry.y0 + item.geometry.y1) / 2
            if not lines:
                lines.append([item])
                continue
            previous = sum(
                (member.geometry.y0 + member.geometry.y1) / 2 for member in lines[-1]
            ) / len(lines[-1])
            if abs(center - previous) <= line_tolerance:
                lines[-1].append(item)
            else:
                lines.append([item])
        if not lines:
            return ()
        index = len(lines) - 1 if before else 0
        selected = list(lines[index])

        def line_center(line: Sequence[_TextItem]) -> float:
            return sum(
                (member.geometry.y0 + member.geometry.y1) / 2 for member in line
            ) / len(line)

        def band_within_local_row(
            selected_items: Sequence[_TextItem],
        ) -> bool:
            if before:
                band_top = min(item.geometry.y0 for item in selected_items)
                return first_row - band_top <= local_gap * 0.95
            band_bottom = max(item.geometry.y1 for item in selected_items)
            return band_bottom - last_row <= local_gap * 0.95

        if sufficient_column_coverage(selected):
            # A sufficiently wide nearest line can still be only the lower half
            # of a multiline header band in horizontal-only tables.  When an
            # adjacent line is close, remains inside the same local row band,
            # and shares physical column ownership, include it before deriving
            # the text-bounded outer row.  This keeps the boundary tied to the
            # full local header band instead of the nearest text line alone.
            selected_columns = occupied_columns(selected)
            while selected_columns:
                next_index = index - 1 if before else index + 1
                if next_index < 0 or next_index >= len(lines):
                    break
                current_center = line_center(lines[index])
                candidate_center = line_center(lines[next_index])
                if abs(candidate_center - current_center) > max(
                    text_height * 1.5,
                    tolerance * 2,
                ):
                    break
                candidate_columns = occupied_columns(lines[next_index])
                if not candidate_columns:
                    break
                proposed = [*selected, *lines[next_index]]
                if selected_columns.isdisjoint(
                    candidate_columns
                ) and not sufficient_column_coverage(proposed):
                    break
                if not band_within_local_row(proposed):
                    break
                selected = proposed
                selected_columns = occupied_columns(selected)
                index = next_index
            return tuple(selected)

        while not sufficient_column_coverage(selected):
            next_index = index - 1 if before else index + 1
            if next_index < 0 or next_index >= len(lines):
                break
            current_center = line_center(lines[index])
            candidate_center = line_center(lines[next_index])
            if abs(candidate_center - current_center) > max(
                text_height * 1.5,
                tolerance * 2,
            ):
                break
            selected.extend(lines[next_index])
            if not band_within_local_row(selected):
                break
            index = next_index
        if sufficient_column_coverage(selected):
            return tuple(selected)
        return ()

    above = tuple(
        item
        for item in inside_x
        if first_row - local_gap * 1.25
        <= (item.geometry.y0 + item.geometry.y1) / 2
        < first_row - tolerance
    )
    above_line = nearest_text_band(above, before=True)
    if (
        above_line
        and sufficient_column_coverage(above_line)
        and first_row
        - max((item.geometry.y0 + item.geometry.y1) / 2 for item in above_line)
        <= local_gap * 0.95
    ):
        inferred_top = round(
            min(item.geometry.y0 for item in above_line) - text_height * 0.5,
            6,
        )
        if (
            inferred_top < first_row - tolerance
            and first_row - inferred_top <= local_gap * 1.25
        ):
            support = _segments_for_interval(
                candidate.horizontals,
                coordinate=first_row,
                start=x0,
                end=x1,
                tolerance=tolerance,
            )
            additions.append(
                _inferred_outer_row_segment(
                    coordinate=inferred_top,
                    start=x0,
                    end=x1,
                    support=support,
                )
            )
            vertical_additions.extend(
                _inferred_outer_column_extensions(
                    candidate,
                    start=inferred_top,
                    end=first_row,
                    tolerance=tolerance,
                )
            )
            rows.insert(0, inferred_top)

    below = tuple(
        item
        for item in inside_x
        if last_row + tolerance
        < (item.geometry.y0 + item.geometry.y1) / 2
        <= last_row + local_gap * 1.25
    )
    below_line = nearest_text_band(below, before=False)
    if (
        below_line
        and len(occupied_columns(below_line)) >= minimum_occupied_columns
        and min((item.geometry.y0 + item.geometry.y1) / 2 for item in below_line)
        - last_row
        <= local_gap * 0.5
    ):
        inferred_gap = local_gap
        previous_inside = tuple(
            item
            for item in inside_x
            if (item.geometry.y0 + item.geometry.y1) / 2 < last_row - tolerance
        )
        if previous_inside:
            previous_center = max(
                (item.geometry.y0 + item.geometry.y1) / 2 for item in previous_inside
            )
            below_center = min(
                (item.geometry.y0 + item.geometry.y1) / 2 for item in below_line
            )
            if below_center > previous_center:
                inferred_gap = max(
                    local_gap,
                    min(below_center - previous_center, local_gap * 1.5),
                )
        inferred_bottom = round(last_row + inferred_gap, 6)
        if (
            inferred_bottom > last_row + tolerance
            and inferred_bottom - last_row <= local_gap * 1.5
        ):
            support = _segments_for_interval(
                candidate.horizontals,
                coordinate=last_row,
                start=x0,
                end=x1,
                tolerance=tolerance,
            )
            additions.append(
                _inferred_outer_row_segment(
                    coordinate=inferred_bottom,
                    start=x0,
                    end=x1,
                    support=support,
                )
            )
            vertical_additions.extend(
                _inferred_outer_column_extensions(
                    candidate,
                    start=last_row,
                    end=inferred_bottom,
                    tolerance=tolerance,
                )
            )
            rows.append(inferred_bottom)

    if not additions:
        return candidate
    return _GridCandidate(
        horizontals=tuple((*candidate.horizontals, *additions)),
        verticals=tuple((*candidate.verticals, *vertical_additions)),
        row_coordinates=tuple(rows),
        column_coordinates=candidate.column_coordinates,
    )


def _split_large_text_separation_rows(
    candidate: _GridCandidate,
    *,
    text_items: Sequence[_TextItem],
    tolerance: float,
) -> _GridCandidate:
    if len(candidate.row_coordinates) < 3 or not text_items:
        return candidate
    row_gaps = tuple(
        next_value - value
        for value, next_value in zip(
            candidate.row_coordinates, candidate.row_coordinates[1:]
        )
        if next_value > value
    )
    if not row_gaps:
        return candidate
    local_gap = median(row_gaps)
    if local_gap <= 0:
        return candidate
    x0, x1 = candidate.column_coordinates[0], candidate.column_coordinates[-1]
    inside = tuple(
        item
        for item in text_items
        if x0 + tolerance <= (item.geometry.x0 + item.geometry.x1) / 2 <= x1 - tolerance
        and candidate.row_coordinates[0] - tolerance
        <= (item.geometry.y0 + item.geometry.y1) / 2
        <= candidate.row_coordinates[-1] + tolerance
    )
    if not inside:
        return candidate
    text_height = median(
        max(0.1, item.geometry.y1 - item.geometry.y0) for item in inside
    )
    line_tolerance = max(0.5, text_height * 0.75)

    def line_center(line: Sequence[_TextItem]) -> float:
        return sum((item.geometry.y0 + item.geometry.y1) / 2 for item in line) / len(
            line
        )

    def occupied_columns(line: Sequence[_TextItem]) -> set[int]:
        result = set()
        for item in line:
            column = _containing_interval(
                (item.geometry.x0 + item.geometry.x1) / 2,
                candidate.column_coordinates,
                tolerance=tolerance,
            )
            if column is not None:
                result.add(column)
        return result

    minimum_occupied_columns = max(2, min(3, len(candidate.column_coordinates) - 1))
    internal_columns = candidate.column_coordinates[1:-1]
    row_signatures = tuple(
        tuple(
            column
            for column in internal_columns
            if _covers_interval(
                candidate.verticals,
                coordinate=column,
                start=y0,
                end=y1,
                tolerance=tolerance,
            )
        )
        for y0, y1 in zip(candidate.row_coordinates, candidate.row_coordinates[1:])
    )

    def topology_changes_across(index: int) -> bool:
        before: tuple[float, ...] = ()
        after: tuple[float, ...] = ()
        for candidate_index in range(index - 1, -1, -1):
            if row_signatures[candidate_index]:
                before = row_signatures[candidate_index]
                break
        for candidate_index in range(index + 1, len(row_signatures)):
            if row_signatures[candidate_index]:
                after = row_signatures[candidate_index]
                break
        if not before or not after:
            return False
        shared = len(set(before) & set(after))
        overlap = shared / max(min(len(before), len(after)), 1)
        return overlap < 0.5

    rows = list(candidate.row_coordinates)
    additions: list[_Segment] = []
    inserted: set[float] = set()
    for row_index, (y0, y1) in enumerate(
        zip(candidate.row_coordinates, candidate.row_coordinates[1:])
    ):
        if y1 - y0 <= local_gap * 1.75:
            continue
        interval_items = tuple(
            item
            for item in inside
            if y0 + tolerance
            <= (item.geometry.y0 + item.geometry.y1) / 2
            <= y1 - tolerance
        )
        if len(interval_items) < minimum_occupied_columns * 2:
            continue
        lines: list[list[_TextItem]] = []
        for item in sorted(
            interval_items,
            key=lambda value: (value.geometry.y0 + value.geometry.y1) / 2,
        ):
            center = (item.geometry.y0 + item.geometry.y1) / 2
            if not lines:
                lines.append([item])
                continue
            previous = line_center(lines[-1])
            if abs(center - previous) <= line_tolerance:
                lines[-1].append(item)
            else:
                lines.append([item])
        if len(lines) < 2:
            if (
                len(lines) == 1
                and topology_changes_across(row_index)
                and len(occupied_columns(lines[0])) >= minimum_occupied_columns
            ):
                boundary = round(y0 + local_gap, 6)
                if (
                    y0 + tolerance < boundary < y1 - tolerance
                    and line_center(lines[0]) < boundary - tolerance
                    and not any(
                        abs(boundary - existing) <= tolerance for existing in rows
                    )
                ):
                    support = tuple(
                        segment
                        for segment in _segments_for_interval(
                            candidate.horizontals,
                            coordinate=y0,
                            start=x0,
                            end=x1,
                            tolerance=tolerance,
                        )
                    )
                    inserted.add(boundary)
                    additions.append(
                        _Segment(
                            orientation="horizontal",
                            coordinate=boundary,
                            start=x0,
                            end=x1,
                            separator_candidate_ids=tuple(
                                sorted(
                                    candidate_id
                                    for segment in support
                                    for candidate_id in segment.separator_candidate_ids
                                )
                            ),
                            drawing_node_ids=tuple(
                                sorted(
                                    node
                                    for segment in support
                                    for node in segment.drawing_node_ids
                                )
                            ),
                            drawing_fact_ids=tuple(
                                sorted(
                                    fact
                                    for segment in support
                                    for fact in segment.drawing_fact_ids
                                )
                            ),
                            derivations=("text_bounded_internal_section_boundary",),
                        )
                    )
                    rows.append(boundary)
            continue
        for first, second in zip(lines, lines[1:]):
            first_center = line_center(first)
            second_center = line_center(second)
            if second_center - first_center <= local_gap * 1.25:
                continue
            if (
                len(occupied_columns(first)) < minimum_occupied_columns
                or len(occupied_columns(second)) < minimum_occupied_columns
            ):
                continue
            first_boundary = round(y0 + local_gap, 6)
            second_boundary = round(
                min(item.geometry.y0 for item in second) - text_height * 0.5,
                6,
            )
            if not (y0 + tolerance < first_boundary < second_boundary < y1 - tolerance):
                continue
            support = tuple(
                segment
                for boundary in (y0, y1)
                for segment in _segments_for_interval(
                    candidate.horizontals,
                    coordinate=boundary,
                    start=x0,
                    end=x1,
                    tolerance=tolerance,
                )
            )
            for boundary in (first_boundary, second_boundary):
                if any(abs(boundary - existing) <= tolerance for existing in rows):
                    continue
                if boundary in inserted:
                    continue
                inserted.add(boundary)
                additions.append(
                    _Segment(
                        orientation="horizontal",
                        coordinate=boundary,
                        start=x0,
                        end=x1,
                        separator_candidate_ids=tuple(
                            sorted(
                                candidate_id
                                for segment in support
                                for candidate_id in segment.separator_candidate_ids
                            )
                        ),
                        drawing_node_ids=tuple(
                            sorted(
                                node
                                for segment in support
                                for node in segment.drawing_node_ids
                            )
                        ),
                        drawing_fact_ids=tuple(
                            sorted(
                                fact
                                for segment in support
                                for fact in segment.drawing_fact_ids
                            )
                        ),
                        derivations=("text_bounded_internal_section_boundary",),
                    )
                )
                rows.append(boundary)
            break
    if not additions:
        return candidate
    return _GridCandidate(
        horizontals=tuple((*candidate.horizontals, *additions)),
        verticals=candidate.verticals,
        row_coordinates=tuple(sorted(rows)),
        column_coordinates=candidate.column_coordinates,
    )


def _inferred_outer_row_segment(
    *,
    coordinate: float,
    start: float,
    end: float,
    support: Sequence[_Segment],
) -> _Segment:
    return _Segment(
        orientation="horizontal",
        coordinate=coordinate,
        start=start,
        end=end,
        separator_candidate_ids=tuple(
            sorted(
                candidate
                for segment in support
                for candidate in segment.separator_candidate_ids
            )
        ),
        drawing_node_ids=tuple(
            sorted(node for segment in support for node in segment.drawing_node_ids)
        ),
        drawing_fact_ids=tuple(
            sorted(fact for segment in support for fact in segment.drawing_fact_ids)
        ),
        derivations=("text_bounded_outer_row_boundary",),
    )


def _inferred_outer_column_extensions(
    candidate: _GridCandidate,
    *,
    start: float,
    end: float,
    tolerance: float,
) -> tuple[_Segment, ...]:
    result = []
    for coordinate in candidate.column_coordinates:
        support = _segments_for_interval(
            candidate.verticals,
            coordinate=coordinate,
            start=min(candidate.row_coordinates),
            end=max(candidate.row_coordinates),
            tolerance=tolerance,
        )
        result.append(
            _Segment(
                orientation="vertical",
                coordinate=coordinate,
                start=start,
                end=end,
                separator_candidate_ids=tuple(
                    sorted(
                        candidate_id
                        for segment in support
                        for candidate_id in segment.separator_candidate_ids
                    )
                ),
                drawing_node_ids=tuple(
                    sorted(
                        node for segment in support for node in segment.drawing_node_ids
                    )
                ),
                drawing_fact_ids=tuple(
                    sorted(
                        fact for segment in support for fact in segment.drawing_fact_ids
                    )
                ),
                derivations=("text_bounded_outer_column_extension",),
            )
        )
    return tuple(result)


def _split_candidate_by_same_topology_section_restart(
    candidate: _GridCandidate,
    *,
    text_items: Sequence[_TextItem],
    tolerance: float,
    minimum_cells: int,
) -> tuple[_GridCandidate, ...]:
    """Split stacked sections with a physical restart and near-same topology."""

    if any(
        {
            "shared_vertical_rule_damage_band_continuity",
            "later_fill_occlusion",
        }
        & set(segment.derivations)
        for segment in candidate.verticals
    ):
        return (candidate,)
    row_count = len(candidate.row_coordinates) - 1
    column_count = len(candidate.column_coordinates) - 1
    if row_count < 6 or column_count < 2:
        return (candidate,)
    internal_columns = candidate.column_coordinates[1:-1]
    if not internal_columns:
        return (candidate,)

    def has_physical_column_coverage(
        *, coordinate: float, start: float, end: float
    ) -> bool:
        return any(
            abs(segment.coordinate - coordinate) <= tolerance
            and any(
                interval_start <= start + tolerance and interval_end >= end - tolerance
                for interval_start, interval_end in segment.physical_intervals
            )
            for segment in candidate.verticals
        )

    row_signatures: list[tuple[float, ...]] = []
    for row_index in range(row_count):
        y0 = candidate.row_coordinates[row_index]
        y1 = candidate.row_coordinates[row_index + 1]
        row_signatures.append(
            tuple(
                column
                for column in internal_columns
                if has_physical_column_coverage(
                    coordinate=column,
                    start=y0,
                    end=y1,
                )
            )
        )

    def horizontal_coverage(coordinate: float) -> float:
        covered = sum(
            _covers_interval(
                candidate.horizontals,
                coordinate=coordinate,
                start=candidate.column_coordinates[column],
                end=candidate.column_coordinates[column + 1],
                tolerance=tolerance,
            )
            for column in range(column_count)
        )
        return covered / column_count

    def text_in_interval(row_index: int) -> bool:
        y0 = candidate.row_coordinates[row_index]
        y1 = candidate.row_coordinates[row_index + 1]
        x0 = candidate.column_coordinates[0]
        x1 = candidate.column_coordinates[-1]
        return any(
            x0 + tolerance
            <= (item.geometry.x0 + item.geometry.x1) / 2
            <= x1 - tolerance
            and y0 + tolerance
            <= (item.geometry.y0 + item.geometry.y1) / 2
            <= y1 - tolerance
            for item in text_items
        )

    def dominant_signature(start: int, end: int) -> tuple[float, ...]:
        return max(
            (signature for signature in row_signatures[start:end] if signature),
            key=len,
            default=(),
        )

    def has_rows_with_text(start: int, end: int) -> bool:
        return any(text_in_interval(index) for index in range(start, end))

    def has_section_restart_after(index: int) -> bool:
        if index + 2 >= row_count:
            return False
        if not text_in_interval(index + 1):
            return False
        return any(
            row_signatures[next_index]
            for next_index in range(index + 2, min(row_count, index + 5))
        )

    split_index: int | None = None
    for row_index in range(1, row_count - 2):
        if row_signatures[row_index] or text_in_interval(row_index):
            continue
        if horizontal_coverage(candidate.row_coordinates[row_index]) < 0.8:
            continue
        if horizontal_coverage(candidate.row_coordinates[row_index + 1]) < 0.8:
            continue
        if row_index < 3 or row_count - (row_index + 1) < 3:
            continue
        if not has_rows_with_text(0, row_index):
            continue
        if not has_rows_with_text(row_index + 1, row_count):
            continue
        if not has_section_restart_after(row_index):
            continue
        if not dominant_signature(0, row_index) or not dominant_signature(
            row_index + 1, row_count
        ):
            continue
        split_index = row_index
        break

    if split_index is None:
        return (candidate,)

    runs = (
        (0, split_index, dominant_signature(0, split_index)),
        (
            split_index + 1,
            row_count,
            dominant_signature(split_index + 1, row_count),
        ),
    )
    pieces: list[_GridCandidate] = []
    for start_row, end_row, signature in runs:
        row_coordinates = candidate.row_coordinates[start_row : end_row + 1]
        column_coordinates = (
            candidate.column_coordinates[0],
            *signature,
            candidate.column_coordinates[-1],
        )
        if start_row == 0:
            row_coordinates = _exclude_text_derived_outer_row_from_physical_piece(
                candidate,
                row_coordinates=row_coordinates,
                column_coordinates=column_coordinates,
                tolerance=tolerance,
            )
        if (len(row_coordinates) - 1) * (len(column_coordinates) - 1) < minimum_cells:
            return (candidate,)
        y0, y1 = row_coordinates[0], row_coordinates[-1]
        x0, x1 = column_coordinates[0], column_coordinates[-1]
        piece = _GridCandidate(
            horizontals=tuple(
                segment
                for segment in candidate.horizontals
                if y0 - tolerance <= segment.coordinate <= y1 + tolerance
                and segment.start <= x1 + tolerance
                and segment.end >= x0 - tolerance
            ),
            verticals=tuple(
                segment
                for segment in candidate.verticals
                if any(
                    abs(segment.coordinate - column) <= tolerance
                    for column in column_coordinates
                )
                and segment.start <= y1 + tolerance
                and segment.end >= y0 - tolerance
            ),
            row_coordinates=row_coordinates,
            column_coordinates=column_coordinates,
        )
        if not _outer_enclosure_complete(piece, tolerance=tolerance):
            return (candidate,)
        pieces.append(piece)
    return tuple(pieces) if len(pieces) == 2 else (candidate,)


def _exclude_text_derived_outer_row_from_physical_piece(
    candidate: _GridCandidate,
    *,
    row_coordinates: tuple[float, ...],
    column_coordinates: tuple[float, ...],
    tolerance: float,
) -> tuple[float, ...]:
    """Exclude one proven text-derived row outside a physical enclosure."""

    if len(row_coordinates) < 3:
        return row_coordinates
    outer_boundary, physical_boundary = row_coordinates[:2]
    x0, x1 = column_coordinates[0], column_coordinates[-1]
    outer_segments = tuple(
        segment
        for segment in candidate.horizontals
        if abs(segment.coordinate - outer_boundary) <= tolerance
        and segment.start <= x0 + tolerance
        and segment.end >= x1 - tolerance
    )
    if not outer_segments or not any(
        "text_bounded_outer_row_boundary" in segment.derivations
        for segment in outer_segments
    ):
        return row_coordinates
    if any(segment.physical_intervals for segment in outer_segments):
        return row_coordinates

    def physically_covers_horizontal(coordinate: float) -> bool:
        return any(
            abs(segment.coordinate - coordinate) <= tolerance
            and any(
                interval_start <= x0 + tolerance and interval_end >= x1 - tolerance
                for interval_start, interval_end in segment.physical_intervals
            )
            for segment in candidate.horizontals
        )

    def physically_covers_vertical(
        coordinate: float, *, start: float, end: float
    ) -> bool:
        return any(
            abs(segment.coordinate - coordinate) <= tolerance
            and any(
                interval_start <= start + tolerance and interval_end >= end - tolerance
                for interval_start, interval_end in segment.physical_intervals
            )
            for segment in candidate.verticals
        )

    if not physically_covers_horizontal(physical_boundary):
        return row_coordinates
    if any(
        physically_covers_vertical(
            coordinate,
            start=outer_boundary,
            end=physical_boundary,
        )
        for coordinate in column_coordinates
    ):
        return row_coordinates
    next_boundary = row_coordinates[2]
    if not all(
        physically_covers_vertical(
            coordinate,
            start=physical_boundary,
            end=next_boundary,
        )
        for coordinate in column_coordinates
    ):
        return row_coordinates
    return row_coordinates[1:]


def _has_unresolved_horizontal_extension(
    candidate: _GridCandidate, *, tolerance: float
) -> bool:
    x0, x1 = candidate.column_coordinates[0], candidate.column_coordinates[-1]
    permitted = tolerance * 2
    return any(
        item.start < x0 - permitted or item.end > x1 + permitted
        for item in candidate.horizontals
    )


def _prune_weak_internal_axes(
    candidate: _GridCandidate,
    *,
    text_items: Sequence[_TextItem],
    config: PdfTableAlgorithmConfig,
    tolerance: float,
) -> _GridCandidate:
    if len(candidate.column_coordinates) < 4 or not text_items:
        return candidate
    text_height = median(
        max(0.1, item.geometry.y1 - item.geometry.y0) for item in text_items
    )
    maximum_cluster_width = (
        text_height * config.weak_axis_cluster_maximum_text_height_multiplier
    )
    row_intervals = tuple(zip(candidate.row_coordinates, candidate.row_coordinates[1:]))

    def coverage(coordinate: float) -> float:
        return sum(
            _covers_interval(
                candidate.verticals,
                coordinate=coordinate,
                start=y0,
                end=y1,
                tolerance=tolerance,
            )
            for y0, y1 in row_intervals
        ) / len(row_intervals)

    removed = set()
    coordinates = candidate.column_coordinates
    for index in range(1, len(coordinates) - 1):
        left, coordinate, right = coordinates[index - 1 : index + 2]
        if right - left > maximum_cluster_width:
            continue
        if any(
            left < (item.geometry.x0 + item.geometry.x1) / 2 < right
            and candidate.row_coordinates[0]
            < (item.geometry.y0 + item.geometry.y1) / 2
            < candidate.row_coordinates[-1]
            for item in text_items
        ):
            continue
        if (
            coverage(coordinate) <= config.weak_internal_axis_maximum_coverage
            and coverage(left) == 1.0
            and coverage(right) == 1.0
        ):
            removed.add(coordinate)
    if not removed:
        return candidate
    retained = tuple(
        coordinate for coordinate in coordinates if coordinate not in removed
    )
    if len(retained) < 2:
        return candidate
    return _GridCandidate(
        horizontals=candidate.horizontals,
        verticals=candidate.verticals,
        row_coordinates=candidate.row_coordinates,
        column_coordinates=retained,
    )


def _intersects(horizontal: _Segment, vertical: _Segment, *, tolerance: float) -> bool:
    return bool(
        horizontal.start - tolerance
        <= vertical.coordinate
        <= horizontal.end + tolerance
        and vertical.start - tolerance
        <= horizontal.coordinate
        <= vertical.end + tolerance
    )


def _cluster_coordinates(
    values: Iterable[float], *, tolerance: float
) -> tuple[float, ...]:
    clusters: list[list[float]] = []
    for value in sorted(values):
        if clusters and abs(value - sum(clusters[-1]) / len(clusters[-1])) <= tolerance:
            clusters[-1].append(value)
        else:
            clusters.append([value])
    return tuple(round(sum(cluster) / len(cluster), 6) for cluster in clusters)


def _covers_interval(
    segments: Sequence[_Segment],
    *,
    coordinate: float,
    start: float,
    end: float,
    tolerance: float,
) -> bool:
    intervals = sorted(
        (
            (max(start, item.start), min(end, item.end))
            for item in segments
            if abs(item.coordinate - coordinate) <= tolerance
            and item.end >= start - tolerance
            and item.start <= end + tolerance
        ),
        key=lambda item: (item[0], item[1]),
    )
    if not intervals or intervals[0][0] > start + tolerance:
        return False
    covered = intervals[0][1]
    for interval_start, interval_end in intervals[1:]:
        if interval_start > covered + tolerance:
            return False
        covered = max(covered, interval_end)
    return covered >= end - tolerance


def _segments_for_interval(
    segments: Sequence[_Segment],
    *,
    coordinate: float,
    start: float,
    end: float,
    tolerance: float,
) -> tuple[_Segment, ...]:
    return tuple(
        item
        for item in segments
        if abs(item.coordinate - coordinate) <= tolerance
        and item.end >= start - tolerance
        and item.start <= end + tolerance
    )


def _covers_cell_boundary(
    segments: Sequence[_Segment],
    *,
    coordinate: float,
    start: float,
    end: float,
    tolerance: float,
) -> bool:
    continuity_segments = tuple(
        segment
        for segment in segments
        if {
            "shared_vertical_rule_damage_band_continuity",
            "shared_horizontal_rule_damage_band_continuity",
            "horizontal_bounded_outer_column_boundary",
        }
        & set(segment.derivations)
    )
    if continuity_segments and _covers_interval(
        continuity_segments,
        coordinate=coordinate,
        start=start,
        end=end,
        tolerance=tolerance,
    ):
        return True
    if not any(segment.physical_intervals for segment in segments):
        return _covers_interval(
            segments,
            coordinate=coordinate,
            start=start,
            end=end,
            tolerance=tolerance,
        )
    intervals = tuple(
        interval
        for segment in segments
        if abs(segment.coordinate - coordinate) <= tolerance
        for interval in segment.physical_intervals
    )
    return _interval_sequence_covers(
        intervals, start=start, end=end, tolerance=tolerance
    )


def _physically_covers_cell_boundary(
    segments: Sequence[_Segment],
    *,
    coordinate: float,
    start: float,
    end: float,
    tolerance: float,
) -> bool:
    """Require physical intervals; logical continuity is not affirmative proof."""

    intervals = tuple(
        interval
        for segment in segments
        if abs(segment.coordinate - coordinate) <= tolerance
        for interval in segment.physical_intervals
    )
    return bool(intervals) and _interval_sequence_covers(
        intervals,
        start=start,
        end=end,
        tolerance=tolerance,
    )


def _has_partial_cell_boundary(
    segments: Sequence[_Segment],
    *,
    coordinate: float,
    start: float,
    end: float,
    tolerance: float,
) -> bool:
    """Exclude endpoint-only contact from partial cell-boundary evidence."""
    if not any(segment.physical_intervals for segment in segments):
        return bool(
            _segments_for_interval(
                segments,
                coordinate=coordinate,
                start=start,
                end=end,
                tolerance=tolerance,
            )
        )
    return any(
        min(end, interval_end) - max(start, interval_start) > tolerance
        for segment in segments
        if abs(segment.coordinate - coordinate) <= tolerance
        for interval_start, interval_end in segment.physical_intervals
    )


def _interval_sequence_covers(
    intervals: Sequence[tuple[float, float]],
    *,
    start: float,
    end: float,
    tolerance: float,
) -> bool:
    clipped = sorted(
        (max(start, left), min(end, right))
        for left, right in intervals
        if right >= start - tolerance and left <= end + tolerance
    )
    if not clipped or clipped[0][0] > start + tolerance:
        return False
    covered = clipped[0][1]
    for interval_start, interval_end in clipped[1:]:
        if interval_start > covered + tolerance:
            return False
        covered = max(covered, interval_end)
    return covered >= end - tolerance


def _leading_later_fill_span_evidence(
    page: PdfTablePageInput,
    candidate: _GridCandidate,
    segments: Sequence[_Segment],
    text_items: Sequence[_TextItem],
    *,
    axis: str,
    coordinate: float,
    start: float,
    end: float,
    tolerance: float,
) -> bool:
    """Prove a leading-header thin rule was visibly interrupted by local paint."""

    leading_end = candidate.row_coordinates[min(2, len(candidate.row_coordinates) - 1)]
    if axis == "vertical":
        if end > leading_end + tolerance:
            return False
    elif coordinate > leading_end + tolerance:
        return False

    drawing_by_id = {drawing.fact_id: drawing for drawing in page.facts.drawings}
    thin_supporting = tuple(
        segment
        for segment in segments
        if segment.orientation == axis
        and abs(segment.coordinate - coordinate) <= tolerance
        and segment.start <= end + tolerance
        and segment.end >= start - tolerance
        and {"thin_line_rule", "thin_rectangle_rule"} & set(segment.derivations)
    )
    if not thin_supporting or not _physically_covers_cell_boundary(
        thin_supporting,
        coordinate=coordinate,
        start=start,
        end=end,
        tolerance=tolerance,
    ):
        return False
    source_orders = tuple(
        drawing_by_id[fact_id].source_order
        for segment in thin_supporting
        for fact_id in segment.drawing_fact_ids
        if fact_id in drawing_by_id
    )
    if not source_orders:
        return False
    latest_rule_order = max(source_orders)

    def candidate_local_owned_fill(drawing: PdfDrawingFact) -> bool:
        minimum_column_width = min(
            x1 - x0
            for x0, x1 in zip(
                candidate.column_coordinates,
                candidate.column_coordinates[1:],
            )
        )
        return (
            _bbox_inside(drawing.bbox, candidate.geometry, tolerance=tolerance)
            and drawing.bbox.y1 <= leading_end + tolerance
            and drawing.bbox.x1 - drawing.bbox.x0 >= minimum_column_width - tolerance
            and any(
                _bbox_inside(item.geometry, drawing.bbox, tolerance=tolerance)
                for item in text_items
            )
        )

    blockers = tuple(
        (
            (drawing.bbox.y0, drawing.bbox.y1)
            if axis == "vertical"
            else (drawing.bbox.x0, drawing.bbox.x1)
        )
        for drawing in page.facts.drawings
        if drawing.kind == "rectangle"
        and drawing.paint_operation == "fill"
        and drawing.source_order > latest_rule_order
        and candidate_local_owned_fill(drawing)
        and (
            drawing.bbox.x0 > candidate.geometry.x0 + tolerance
            or drawing.bbox.x1 < candidate.geometry.x1 - tolerance
        )
        and (
            drawing.bbox.x0 < coordinate - tolerance
            and drawing.bbox.x1 > coordinate + tolerance
            if axis == "vertical"
            else drawing.bbox.y0 < coordinate - tolerance
            and drawing.bbox.y1 > coordinate + tolerance
        )
    )
    if not blockers:
        return False
    physical_intervals = tuple(
        interval
        for segment in thin_supporting
        for interval in segment.physical_intervals
    )
    visible_intervals = _subtract_intervals(
        physical_intervals,
        _merge_interval_sequences(blockers, tolerance=tolerance),
    )
    return not _interval_sequence_covers(
        visible_intervals,
        start=start,
        end=end,
        tolerance=tolerance,
    )


def _rectangular_leading_fill_edges(
    vertical_edges: set[tuple[int, int]],
    horizontal_edges: set[tuple[int, int]],
) -> tuple[set[tuple[int, int]], set[tuple[int, int]]]:
    """Retain only complete rectangular components of fill-occluded edges."""

    adjacency: dict[tuple[int, int], set[tuple[int, int]]] = {}
    for row, column in vertical_edges:
        first = (row, column)
        second = (row, column + 1)
        adjacency.setdefault(first, set()).add(second)
        adjacency.setdefault(second, set()).add(first)
    for row, column in horizontal_edges:
        first = (row, column)
        second = (row + 1, column)
        adjacency.setdefault(first, set()).add(second)
        adjacency.setdefault(second, set()).add(first)

    accepted_vertical: set[tuple[int, int]] = set()
    accepted_horizontal: set[tuple[int, int]] = set()
    remaining = set(adjacency)
    while remaining:
        pending = [min(remaining)]
        component: set[tuple[int, int]] = set()
        while pending:
            position = pending.pop()
            if position in component:
                continue
            component.add(position)
            pending.extend(adjacency[position] - component)
        remaining -= component
        component_rows = {row for row, _column in component}
        component_columns = {column for _row, column in component}
        rectangle = {
            (row, column)
            for row in range(min(component_rows), max(component_rows) + 1)
            for column in range(min(component_columns), max(component_columns) + 1)
        }
        if component != rectangle:
            continue
        expected_vertical = {
            (row, column)
            for row in component_rows
            for column in range(min(component_columns), max(component_columns))
        }
        expected_horizontal = {
            (row, column)
            for row in range(min(component_rows), max(component_rows))
            for column in component_columns
        }
        if not (
            expected_vertical <= vertical_edges
            and expected_horizontal <= horizontal_edges
        ):
            continue
        accepted_vertical.update(expected_vertical)
        accepted_horizontal.update(expected_horizontal)
    return accepted_vertical, accepted_horizontal


def _cell_has_independent_contained_owner(
    text_items: Sequence[_TextItem],
    *,
    candidate: _GridCandidate,
    row: int,
    column: int,
    excluded_item_ids: frozenset[int],
    tolerance: float,
) -> bool:
    if not (
        0 <= row < len(candidate.row_coordinates) - 1
        and 0 <= column < len(candidate.column_coordinates) - 1
    ):
        return False
    cell_geometry = PdfBoundingBox(
        x0=candidate.column_coordinates[column],
        y0=candidate.row_coordinates[row],
        x1=candidate.column_coordinates[column + 1],
        y1=candidate.row_coordinates[row + 1],
    )
    return any(
        id(item) not in excluded_item_ids
        and _bbox_inside(item.geometry, cell_geometry, tolerance=tolerance)
        for item in text_items
    )


def _unique_largest_physical_unit_group_match(
    item: _TextItem,
    *,
    candidate: _GridCandidate,
    groups: Sequence[tuple[int, int, int, int, set[tuple[int, int]]]],
    matches: set[int],
    text_items: Sequence[_TextItem],
    tolerance: float,
) -> int | None:
    """Narrow final unit ownership only with strict local physical proof."""

    if len(matches) < 2 or any(
        groups[group_index][2:4] != (1, 1) for group_index in matches
    ):
        return None
    positions = {
        (groups[group_index][0], groups[group_index][1]) for group_index in matches
    }
    position_rows = {row for row, _column in positions}
    position_columns = {column for _row, column in positions}
    if not all(
        _physically_covers_cell_boundary(
            candidate.verticals,
            coordinate=candidate.column_coordinates[boundary_column],
            start=candidate.row_coordinates[row],
            end=candidate.row_coordinates[row + 1],
            tolerance=tolerance,
        )
        for row in position_rows
        for boundary_column in range(
            min(position_columns) + 1,
            max(position_columns) + 1,
        )
    ) or not all(
        _physically_covers_cell_boundary(
            candidate.horizontals,
            coordinate=candidate.row_coordinates[boundary_row],
            start=candidate.column_coordinates[column],
            end=candidate.column_coordinates[column + 1],
            tolerance=tolerance,
        )
        for column in position_columns
        for boundary_row in range(
            min(position_rows) + 1,
            max(position_rows) + 1,
        )
    ):
        return None

    ranked = sorted(
        (
            (
                group_index,
                max(
                    0.0,
                    min(
                        item.geometry.x1,
                        candidate.column_coordinates[groups[group_index][1] + 1],
                    )
                    - max(
                        item.geometry.x0,
                        candidate.column_coordinates[groups[group_index][1]],
                    ),
                )
                * max(
                    0.0,
                    min(
                        item.geometry.y1,
                        candidate.row_coordinates[groups[group_index][0] + 1],
                    )
                    - max(
                        item.geometry.y0,
                        candidate.row_coordinates[groups[group_index][0]],
                    ),
                ),
            )
            for group_index in matches
        ),
        key=lambda value: (-value[1], value[0]),
    )
    if ranked[0][1] <= ranked[1][1] + tolerance**2:
        return None
    selected = ranked[0][0]
    return (
        selected
        if all(
            _cell_has_independent_contained_owner(
                text_items,
                candidate=candidate,
                row=groups[group_index][0],
                column=groups[group_index][1],
                excluded_item_ids=frozenset({id(item)}),
                tolerance=tolerance,
            )
            for group_index in matches - {selected}
        )
        else None
    )


def _repeated_bilateral_body_ownership(
    candidate: _GridCandidate,
    atomic_assignments: dict[tuple[int, int], tuple[_TextItem, ...]],
    *,
    row: int,
    column: int,
    minimum_repetitions: int,
    tolerance: float,
) -> bool:
    """Corroborate one leading shared crossing with repeated ruled body cells."""

    if row != 0:
        return False
    coordinate = candidate.column_coordinates[column + 1]
    leading_first = atomic_assignments.get((0, column), ())
    leading_second = atomic_assignments.get((0, column + 1), ())
    second_ids = {id(item) for item in leading_second}
    shared_crossing_ids = frozenset(
        id(item)
        for item in leading_first
        if id(item) in second_ids
        and item.geometry.x0 < coordinate - tolerance
        and item.geometry.x1 > coordinate + tolerance
    )
    if not shared_crossing_ids:
        return False
    candidate_items = tuple(
        {
            id(item): item for items in atomic_assignments.values() for item in items
        }.values()
    )
    if not any(
        _cell_has_independent_contained_owner(
            candidate_items,
            candidate=candidate,
            row=0,
            column=peer_column,
            excluded_item_ids=shared_crossing_ids,
            tolerance=tolerance,
        )
        for peer_column in range(len(candidate.column_coordinates) - 1)
        if peer_column not in {column, column + 1}
    ):
        return False

    corroborated_rows = 0
    for body_row in range(1, len(candidate.row_coordinates) - 1):
        if (
            _cell_has_independent_contained_owner(
                candidate_items,
                candidate=candidate,
                row=body_row,
                column=column,
                excluded_item_ids=shared_crossing_ids,
                tolerance=tolerance,
            )
            and _cell_has_independent_contained_owner(
                candidate_items,
                candidate=candidate,
                row=body_row,
                column=column + 1,
                excluded_item_ids=shared_crossing_ids,
                tolerance=tolerance,
            )
            and _physically_covers_cell_boundary(
                candidate.verticals,
                coordinate=coordinate,
                start=candidate.row_coordinates[body_row],
                end=candidate.row_coordinates[body_row + 1],
                tolerance=tolerance,
            )
        ):
            corroborated_rows += 1
    return corroborated_rows >= minimum_repetitions


def _build_candidate_table(
    page: PdfTablePageInput,
    candidate: _GridCandidate,
    *,
    text_items: tuple[_TextItem, ...],
    config: PdfTableAlgorithmConfig,
    tolerance: float,
    connection_tolerance: float,
    table_index: int,
    text_evidence: TableTextEvidenceCollector | None = None,
) -> PdfTable | None:
    rows = len(candidate.row_coordinates) - 1
    columns = len(candidate.column_coordinates) - 1
    if not _outer_enclosure_complete(
        candidate,
        tolerance=connection_tolerance,
    ):
        return None

    raw_atomic_assignments = _atomic_text_assignments(
        text_items,
        candidate=candidate,
        tolerance=tolerance,
    )
    leading_fill_vertical_edges = {
        (row, column)
        for row in range(rows)
        for column in range(columns - 1)
        if _leading_later_fill_span_evidence(
            page,
            candidate,
            candidate.verticals,
            text_items,
            axis="vertical",
            coordinate=candidate.column_coordinates[column + 1],
            start=candidate.row_coordinates[row],
            end=candidate.row_coordinates[row + 1],
            tolerance=tolerance,
        )
    }
    leading_fill_horizontal_edges = {
        (row, column)
        for row in range(rows - 1)
        for column in range(columns)
        if _leading_later_fill_span_evidence(
            page,
            candidate,
            candidate.horizontals,
            text_items,
            axis="horizontal",
            coordinate=candidate.row_coordinates[row + 1],
            start=candidate.column_coordinates[column],
            end=candidate.column_coordinates[column + 1],
            tolerance=tolerance,
        )
    }
    (
        leading_fill_vertical_edges,
        leading_fill_horizontal_edges,
    ) = _rectangular_leading_fill_edges(
        leading_fill_vertical_edges,
        leading_fill_horizontal_edges,
    )
    leading_span_fact_ids = {
        item.fact.fact_id
        for row, column in leading_fill_vertical_edges
        for item in (
            *raw_atomic_assignments.get((row, column), ()),
            *raw_atomic_assignments.get((row, column + 1), ()),
        )
        if item.geometry.x0 < candidate.column_coordinates[column + 1] - tolerance
        and item.geometry.x1 > candidate.column_coordinates[column + 1] + tolerance
    } | {
        item.fact.fact_id
        for row, column in leading_fill_horizontal_edges
        for item in (
            *raw_atomic_assignments.get((row, column), ()),
            *raw_atomic_assignments.get((row + 1, column), ()),
        )
        if item.geometry.y0 < candidate.row_coordinates[row + 1] - tolerance
        and item.geometry.y1 > candidate.row_coordinates[row + 1] + tolerance
    }
    overlay_fact_ids = (
        _decorative_overlay_text_fact_ids(
            text_items,
            candidate=candidate,
            tolerance=tolerance,
        )
        - leading_span_fact_ids
    )
    candidate_text_items = tuple(
        item for item in text_items if item.fact.fact_id not in overlay_fact_ids
    )
    atomic_assignments = _atomic_text_assignments(
        candidate_text_items,
        candidate=candidate,
        tolerance=tolerance,
    )
    missing_vertical_edges = {
        (row, column)
        for row in range(rows)
        for column in range(columns - 1)
        if (row, column) in leading_fill_vertical_edges
        or not _covers_cell_boundary(
            candidate.verticals,
            coordinate=candidate.column_coordinates[column + 1],
            start=candidate.row_coordinates[row],
            end=candidate.row_coordinates[row + 1],
            tolerance=connection_tolerance,
        )
    }
    missing_horizontal_edges = {
        (row, column)
        for row in range(rows - 1)
        for column in range(columns)
        if (row, column) in leading_fill_horizontal_edges
        or not _covers_cell_boundary(
            candidate.horizontals,
            coordinate=candidate.row_coordinates[row + 1],
            start=candidate.column_coordinates[column],
            end=candidate.column_coordinates[column + 1],
            tolerance=connection_tolerance,
        )
    }

    def adjacent_missing_run(
        edge: tuple[int, int], edges: set[tuple[int, int]]
    ) -> bool:
        row, column = edge
        return any(
            neighbor in edges
            for neighbor in (
                (row - 1, column),
                (row + 1, column),
                (row, column - 1),
                (row, column + 1),
            )
        )

    union = _UnionFind(rows * columns)

    def position(row: int, column: int) -> int:
        return row * columns + column

    partial_edges: set[tuple[tuple[int, int], tuple[int, int]]] = set()
    merge_edges: list[
        tuple[
            int,
            int,
            str,
            tuple[int, int],
            tuple[int, int],
            bool,
        ]
    ] = []

    def merge_priority(
        *,
        axis: str,
        first: Sequence[_TextItem],
        second: Sequence[_TextItem],
        coordinate: float,
    ) -> int:
        items = tuple(first) + tuple(second)
        crossing = any(
            item.geometry.x0 < coordinate - tolerance
            and item.geometry.x1 > coordinate + tolerance
            if axis == "vertical"
            else item.geometry.y0 < coordinate - tolerance
            and item.geometry.y1 > coordinate + tolerance
            for item in items
        )
        if crossing:
            return 0
        if not items:
            return 3
        if axis == "horizontal":
            return 1
        return 2

    def component_positions_after(
        left: tuple[int, int], right: tuple[int, int]
    ) -> set[tuple[int, int]]:
        roots = {union.find(position(*left)), union.find(position(*right))}
        return {
            (row, column)
            for row in range(rows)
            for column in range(columns)
            if union.find(position(row, column)) in roots
        }

    def rectangular(positions: set[tuple[int, int]]) -> bool:
        row_indexes = {item[0] for item in positions}
        column_indexes = {item[1] for item in positions}
        expected = {
            (row, column)
            for row in range(min(row_indexes), max(row_indexes) + 1)
            for column in range(min(column_indexes), max(column_indexes) + 1)
        }
        return positions == expected

    def apply_merge(left: tuple[int, int], right: tuple[int, int]) -> None:
        if union.find(position(*left)) == union.find(position(*right)):
            return
        if rectangular(component_positions_after(left, right)):
            union.union(position(*left), position(*right))
        else:
            partial_edges.add((left, right))

    for row in range(rows):
        y0, y1 = candidate.row_coordinates[row : row + 2]
        for column in range(columns - 1):
            x = candidate.column_coordinates[column + 1]
            if (row, column) in missing_vertical_edges:
                left = (row, column)
                right = (row, column + 1)
                terminated = any(
                    other_row != row
                    and _covers_cell_boundary(
                        candidate.verticals,
                        coordinate=x,
                        start=candidate.row_coordinates[other_row],
                        end=candidate.row_coordinates[other_row + 1],
                        tolerance=connection_tolerance,
                    )
                    for other_row in range(rows)
                )
                decision = _absent_boundary_decision(
                    atomic_assignments.get(left, ()),
                    atomic_assignments.get(right, ()),
                    axis="vertical",
                    coordinate=x,
                    tolerance=tolerance,
                    partial_physical_boundary=(
                        (row, column) not in leading_fill_vertical_edges
                        and _has_partial_cell_boundary(
                            candidate.verticals,
                            coordinate=x,
                            start=y0,
                            end=y1,
                            tolerance=connection_tolerance,
                        )
                    ),
                    repeated_terminated_run=(
                        terminated
                        and adjacent_missing_run((row, column), missing_vertical_edges)
                    ),
                    isolated_terminated=terminated,
                    first_region_center=(candidate.column_coordinates[column] + x) / 2,
                    second_region_center=(x + candidate.column_coordinates[column + 2])
                    / 2,
                    leading_partition=(row == 0 and terminated),
                    leading_fill_span_evidence=(
                        (row, column) in leading_fill_vertical_edges
                    ),
                    repeated_bilateral_body_proof=(
                        _repeated_bilateral_body_ownership(
                            candidate,
                            atomic_assignments,
                            row=row,
                            column=column,
                            minimum_repetitions=config.minimum_atomic_cell_count,
                            tolerance=connection_tolerance,
                        )
                    ),
                    dark_full_width_band=_has_dark_full_width_fill(
                        page,
                        geometry=PdfBoundingBox(
                            x0=candidate.column_coordinates[0],
                            y0=y0,
                            x1=candidate.column_coordinates[-1],
                            y1=y1,
                        ),
                        column_start=0,
                        column_span=columns,
                        column_count=columns,
                        config=config,
                    ),
                )
                if decision == "merge":
                    merge_edges.append(
                        (
                            merge_priority(
                                axis="vertical",
                                first=atomic_assignments.get(left, ()),
                                second=atomic_assignments.get(right, ()),
                                coordinate=x,
                            ),
                            row * columns + column,
                            "vertical",
                            left,
                            right,
                            bool(atomic_assignments.get(left, ()))
                            or bool(atomic_assignments.get(right, ())),
                        )
                    )
                elif decision == "partial":
                    partial_edges.add((left, right))
                else:
                    return None
    for row in range(rows - 1):
        y = candidate.row_coordinates[row + 1]
        for column in range(columns):
            x0, x1 = candidate.column_coordinates[column : column + 2]
            if (row, column) in missing_horizontal_edges:
                above = (row, column)
                below = (row + 1, column)
                terminated = any(
                    other_column != column
                    and _covers_cell_boundary(
                        candidate.horizontals,
                        coordinate=y,
                        start=candidate.column_coordinates[other_column],
                        end=candidate.column_coordinates[other_column + 1],
                        tolerance=connection_tolerance,
                    )
                    for other_column in range(columns)
                )
                decision = _absent_boundary_decision(
                    atomic_assignments.get(above, ()),
                    atomic_assignments.get(below, ()),
                    axis="horizontal",
                    coordinate=y,
                    tolerance=tolerance,
                    partial_physical_boundary=(
                        (row, column) not in leading_fill_horizontal_edges
                        and _has_partial_cell_boundary(
                            candidate.horizontals,
                            coordinate=y,
                            start=x0,
                            end=x1,
                            tolerance=connection_tolerance,
                        )
                    ),
                    repeated_terminated_run=(
                        terminated
                        and adjacent_missing_run(
                            (row, column), missing_horizontal_edges
                        )
                    ),
                    isolated_terminated=terminated,
                    first_region_center=(candidate.row_coordinates[row] + y) / 2,
                    second_region_center=(y + candidate.row_coordinates[row + 2]) / 2,
                    leading_fill_span_evidence=(
                        (row, column) in leading_fill_horizontal_edges
                    ),
                )
                if decision == "merge":
                    merge_edges.append(
                        (
                            merge_priority(
                                axis="horizontal",
                                first=atomic_assignments.get(above, ()),
                                second=atomic_assignments.get(below, ()),
                                coordinate=y,
                            ),
                            row * columns + column,
                            "horizontal",
                            above,
                            below,
                            bool(atomic_assignments.get(above, ()))
                            or bool(atomic_assignments.get(below, ())),
                        )
                    )
                elif decision == "partial":
                    partial_edges.add((above, below))
                else:
                    return None

    for _priority, _order, _axis, first, second, _has_atomic_content in sorted(
        merge_edges
    ):
        apply_merge(first, second)

    semantic_hierarchy_groups: list[tuple[int, int, int, int]] = []
    for row in range(rows - 1):
        for column in range(columns):
            if not atomic_assignments.get((row, column)):
                continue
            column_end = column + 1
            while column_end < columns and not atomic_assignments.get(
                (row, column_end)
            ):
                column_end += 1
            row_end = row + 1
            while row_end < rows and all(
                not atomic_assignments.get((row_end, candidate_column))
                for candidate_column in range(column, column_end)
            ):
                row_end += 1
            area = (row_end - row) * (column_end - column)
            internal_boundaries_missing = all(
                (candidate_row, boundary_column - 1) in missing_vertical_edges
                for candidate_row in range(row, row_end)
                for boundary_column in range(column + 1, column_end)
            ) and all(
                (boundary_row - 1, candidate_column) in missing_horizontal_edges
                for boundary_row in range(row + 1, row_end)
                for candidate_column in range(column, column_end)
            )
            if (
                row_end <= row + 1
                or area < config.minimum_atomic_cell_count
                or (
                    row_end < rows
                    and not all(
                        atomic_assignments.get((row_end, candidate_column))
                        for candidate_column in range(column, column_end)
                    )
                )
                or (
                    row > 0
                    and not all(
                        atomic_assignments.get((row - 1, candidate_column))
                        for candidate_column in range(column, column_end)
                    )
                )
                or (row_end == row + 2 and not internal_boundaries_missing)
            ):
                continue
            semantic_hierarchy_groups.append((row, column, row_end, column_end))
    claimed_hierarchy_positions: set[tuple[int, int]] = set()
    for row, column, row_end, column_end in sorted(
        semantic_hierarchy_groups,
        key=lambda item: (
            -((item[2] - item[0]) * (item[3] - item[1])),
            item,
        ),
    ):
        positions = {
            (candidate_row, candidate_column)
            for candidate_row in range(row, row_end)
            for candidate_column in range(column, column_end)
        }
        if positions & claimed_hierarchy_positions:
            continue
        if any(
            first in positions and second in positions
            for first, second in partial_edges
        ):
            continue
        intersecting_roots = {
            union.find(position(*candidate_position))
            for candidate_position in positions
        }
        expanded_positions = {
            (candidate_row, candidate_column)
            for candidate_row in range(rows)
            for candidate_column in range(columns)
            if union.find(position(candidate_row, candidate_column))
            in intersecting_roots
        } | positions
        if not rectangular(expanded_positions):
            continue
        anchor = (row, column)
        for position_to_merge in sorted(expanded_positions - {anchor}):
            union.union(
                position(*anchor),
                position(*position_to_merge),
            )
        claimed_hierarchy_positions.update(positions)

    positions_by_root: dict[int, set[tuple[int, int]]] = {}
    for row in range(rows):
        for column in range(columns):
            positions_by_root.setdefault(union.find(position(row, column)), set()).add(
                (row, column)
            )
    groups: list[tuple[int, int, int, int, set[tuple[int, int]]]] = []
    for positions in positions_by_root.values():
        row_indexes = {item[0] for item in positions}
        column_indexes = {item[1] for item in positions}
        expected = {
            (row, column)
            for row in range(min(row_indexes), max(row_indexes) + 1)
            for column in range(min(column_indexes), max(column_indexes) + 1)
        }
        if positions != expected:
            return None
        groups.append(
            (
                min(row_indexes),
                min(column_indexes),
                len(row_indexes),
                len(column_indexes),
                positions,
            )
        )
    groups.sort(key=lambda item: (item[0], item[1], item[2], item[3]))

    row_partition_counts = tuple(
        sum(
            1
            for row_start, _column_start, row_span, _column_span, _positions in groups
            if row_start <= row < row_start + row_span
        )
        for row in range(rows)
    )

    assignments: dict[int, list[_TextItem]] = {
        index: [] for index in range(len(groups))
    }
    assignment_ambiguous = False
    table_geometry = candidate.geometry
    for item in candidate_text_items:
        uniquely_resolved_axis: Literal["row", "column"] | None = None
        center_x = (item.geometry.x0 + item.geometry.x1) / 2
        center_y = (item.geometry.y0 + item.geometry.y1) / 2
        if not _point_inside(center_x, center_y, table_geometry, tolerance=tolerance):
            continue
        atomic_rows = _possible_containing_intervals(
            center_y, candidate.row_coordinates, tolerance=tolerance
        )
        atomic_columns = _possible_containing_intervals(
            center_x, candidate.column_coordinates, tolerance=tolerance
        )
        if not atomic_rows or not atomic_columns:
            assignment_ambiguous = True
            continue
        matches = {
            index
            for index, group in enumerate(groups)
            for atomic_row in atomic_rows
            for atomic_column in atomic_columns
            if (atomic_row, atomic_column) in group[4]
        }
        if len(matches) != 1:
            original_matches = set(matches)
            narrowed_match = _unique_largest_physical_unit_group_match(
                item,
                candidate=candidate,
                groups=groups,
                matches=matches,
                text_items=candidate_text_items,
                tolerance=tolerance,
            )
            if narrowed_match is not None:
                matches = {narrowed_match}
                original_positions = {
                    (groups[group_index][0], groups[group_index][1])
                    for group_index in original_matches
                }
                original_rows = {row for row, _column in original_positions}
                original_columns = {column for _row, column in original_positions}
                if len(original_rows) > 1 and len(original_columns) == 1:
                    uniquely_resolved_axis = "row"
                elif len(original_columns) > 1 and len(original_rows) == 1:
                    uniquely_resolved_axis = "column"
            else:
                assignment_ambiguous = True
                continue
        matched_group = next(iter(matches))
        row_start, column_start, row_span, column_span, _positions = groups[
            matched_group
        ]
        group_geometry = PdfBoundingBox(
            x0=candidate.column_coordinates[column_start],
            y0=candidate.row_coordinates[row_start],
            x1=candidate.column_coordinates[column_start + column_span],
            y1=candidate.row_coordinates[row_start + row_span],
        )
        partition_clipped_outer_overflow = (
            any(
                derivation
                in {
                    "wide_zero_occupancy_gutter_partition_clip",
                    "bilateral_zero_occupancy_gutter_partition_clip",
                }
                for segment in candidate.horizontals
                for derivation in segment.derivations
            )
            and group_geometry.x1 == table_geometry.x1
            and item.geometry.x0 >= group_geometry.x0 - tolerance
            and item.geometry.y0 >= group_geometry.y0 - tolerance
            and item.geometry.y1 <= group_geometry.y1 + tolerance
            and group_geometry.x0 - tolerance <= center_x <= group_geometry.x1
        )
        independently_owned_partial_overflow = (
            row_span == 1
            and column_span == 1
            and item.geometry.y0 >= group_geometry.y0 - tolerance
            and item.geometry.y1 <= group_geometry.y1 + tolerance
            and (
                (
                    item.geometry.x1 > group_geometry.x1 + tolerance
                    and column_start + 1 < columns
                    and (
                        ((row_start, column_start), (row_start, column_start + 1))
                        in partial_edges
                    )
                    and bool(atomic_assignments.get((row_start, column_start + 1)))
                )
                or (
                    item.geometry.x0 < group_geometry.x0 - tolerance
                    and column_start > 0
                    and (
                        ((row_start, column_start - 1), (row_start, column_start))
                        in partial_edges
                    )
                    and bool(atomic_assignments.get((row_start, column_start - 1)))
                )
            )
        )
        independently_owned_neighbor_overflow = (
            row_span == 1
            and column_span == 1
            and _independently_owned_neighbor_overflow(
                item,
                candidate=candidate,
                text_items=candidate_text_items,
                row=row_start,
                column=column_start,
                tolerance=tolerance,
                uniquely_resolved_axis=uniquely_resolved_axis,
            )
        )
        if not (
            _bbox_inside(item.geometry, group_geometry, tolerance=tolerance)
            or partition_clipped_outer_overflow
            or independently_owned_partial_overflow
            or independently_owned_neighbor_overflow
        ):
            assignment_ambiguous = True
            continue
        assignments[matched_group].append(item)
    if assignment_ambiguous:
        return None

    all_segments = candidate.horizontals + candidate.verticals
    table_evidence = _evidence(
        page,
        geometry=table_geometry,
        text_items=tuple(item for values in assignments.values() for item in values),
        segments=all_segments,
        categories=(
            "orthogonal_separator_grid",
            "page_local_physical_geometry",
            *(("partial_internal_ruling",) if partial_edges else ()),
        ),
    )
    body_font_sizes = tuple(
        item.fact.effective_font_size_y or item.fact.font_size
        for group_index, group in enumerate(groups)
        if group[0] > 0 and group[1] > 0
        for item in assignments[group_index]
        if (item.fact.effective_font_size_y or item.fact.font_size) is not None
    )
    body_font_baseline = (
        median(cast("tuple[float, ...]", body_font_sizes)) if body_font_sizes else None
    )
    dark_full_width_group_indexes = {
        group_index
        for group_index, group in enumerate(groups)
        if _has_dark_full_width_fill(
            page,
            geometry=PdfBoundingBox(
                x0=candidate.column_coordinates[group[1]],
                y0=candidate.row_coordinates[group[0]],
                x1=candidate.column_coordinates[group[1] + group[3]],
                y1=candidate.row_coordinates[group[0] + group[2]],
            ),
            column_start=group[1],
            column_span=group[3],
            column_count=columns,
            config=config,
        )
    }
    later_dark_header_band = any(
        groups[group_index][0] > 0 for group_index in dark_full_width_group_indexes
    )
    row_zero_group_indexes = tuple(
        group_index for group_index, group in enumerate(groups) if group[0] == 0
    )
    emphasized_row_zero = bool(row_zero_group_indexes) and all(
        assignments[group_index]
        and all(
            _font_emphasized(
                item.fact,
                body_font_baseline=body_font_baseline,
            )
            for item in assignments[group_index]
        )
        for group_index in row_zero_group_indexes
    )
    leading_header_rows: set[int] = set()
    if not later_dark_header_band or emphasized_row_zero:
        leading_header_rows.add(0)
    if (
        0 in leading_header_rows
        and rows > 1
        and row_partition_counts[1] > row_partition_counts[0]
    ):
        leading_header_rows.add(1)
    cells: list[PdfTableCell] = []
    for group_index, group in enumerate(groups):
        row_start, column_start, row_span, column_span, _positions = group
        geometry = PdfBoundingBox(
            x0=candidate.column_coordinates[column_start],
            y0=candidate.row_coordinates[row_start],
            x1=candidate.column_coordinates[column_start + column_span],
            y1=candidate.row_coordinates[row_start + row_span],
        )
        perimeter, perimeter_complete = _perimeter_segments(
            candidate,
            row_start=row_start,
            row_span=row_span,
            column_start=column_start,
            column_span=column_span,
            tolerance=connection_tolerance,
        )
        assigned = tuple(
            sorted(
                assignments[group_index],
                key=lambda item: (
                    item.geometry.y0,
                    item.geometry.x0,
                    item.fact.source_order,
                    item.node.node_id,
                ),
            )
        )
        role, role_status, role_evidence = _cell_role(
            page=page,
            geometry=geometry,
            row_start=row_start,
            column_start=column_start,
            column_span=column_span,
            row_count=rows,
            column_count=columns,
            leading_header_rows=frozenset(leading_header_rows),
            assigned=assigned,
            body_font_baseline=body_font_baseline,
            config=config,
        )
        if not perimeter_complete:
            role_status = "CANDIDATE"
        cell_evidence = _evidence(
            page,
            geometry=geometry,
            text_items=assigned,
            segments=perimeter,
            categories=(
                "closed_cell_enclosure" if perimeter_complete else "open_cell_boundary",
                "separator_intersection",
                (
                    "text_inside_cell"
                    if assigned
                    else (
                        "physical_empty_cell"
                        if perimeter_complete
                        else "empty_position_not_physically_proven"
                    )
                ),
            ),
        )
        values = {
            "row_start": row_start,
            "row_span": row_span,
            "column_start": column_start,
            "column_span": column_span,
            "geometry": geometry,
            "text": _project_text(assigned),
            "text_fact_ids": tuple(sorted({item.fact.fact_id for item in assigned})),
            "text_layout_node_ids": tuple(
                sorted({item.node.node_id for item in assigned})
            ),
            "text_assignment_evidence": (
                tuple(
                    sorted(
                        {
                            "bbox_inside_cell",
                            "center_inside_cell",
                            *(
                                "member_selection:" + item.view.binding.binding_id
                                for item in assigned
                                if item.view is not None
                            ),
                        }
                    )
                )
                if assigned
                else ()
            ),
            "state": (
                ("PROVEN" if assigned else "PROVEN_EMPTY")
                if perimeter_complete
                else "AMBIGUOUS"
            ),
            "role": role,
            "role_status": role_status,
            "role_evidence": role_evidence,
            "empty_cell_evidence": (
                ("closed_cell_enclosure",)
                if perimeter_complete and not assigned
                else ()
            ),
            "evidence": cell_evidence,
            "limitation_codes": (() if perimeter_complete else ("open_cell_boundary",)),
        }
        cell = _identified(PdfTableCell, "cell_id", "cell", values)
        if text_evidence is not None and not text_evidence.reserve_projection(
            PdfTableCellTextProjection(
                cell_id=cell.cell_id,
                method="ruled_cell_text.v1",
                parts=_text_projection_parts(assigned),
            )
        ):
            return None
        cells.append(cell)
    cells_tuple = tuple(cells)

    row_models = tuple(
        _identified(
            PdfTableRow,
            "row_id",
            "row",
            {
                "row_index": row,
                "geometry": PdfBoundingBox(
                    x0=candidate.column_coordinates[0],
                    y0=candidate.row_coordinates[row],
                    x1=candidate.column_coordinates[-1],
                    y1=candidate.row_coordinates[row + 1],
                ),
                "anchor_cell_ids": tuple(
                    sorted(
                        cell.cell_id for cell in cells_tuple if cell.row_start == row
                    )
                ),
                "evidence": table_evidence,
            },
        )
        for row in range(rows)
    )
    column_models = tuple(
        _identified(
            PdfTableColumn,
            "column_id",
            "column",
            {
                "column_index": column,
                "geometry": PdfBoundingBox(
                    x0=candidate.column_coordinates[column],
                    y0=candidate.row_coordinates[0],
                    x1=candidate.column_coordinates[column + 1],
                    y1=candidate.row_coordinates[-1],
                ),
                "anchor_cell_ids": tuple(
                    sorted(
                        cell.cell_id
                        for cell in cells_tuple
                        if cell.column_start == column
                    )
                ),
                "evidence": table_evidence,
            },
        )
        for column in range(columns)
    )
    row_boundaries = tuple(
        _identified(
            PdfTableAxisBoundary,
            "boundary_id",
            "axis-boundary",
            {
                "axis": "ROW",
                "boundary_index": index,
                "coordinate": coordinate,
                "evidence": _evidence(
                    page,
                    geometry=table_geometry,
                    text_items=(),
                    segments=_segments_for_interval(
                        candidate.horizontals,
                        coordinate=coordinate,
                        start=candidate.column_coordinates[0],
                        end=candidate.column_coordinates[-1],
                        tolerance=tolerance,
                    ),
                    categories=("horizontal_separator_boundary",),
                ),
                "state": (
                    "PROVEN"
                    if _covers_interval(
                        candidate.horizontals,
                        coordinate=coordinate,
                        start=candidate.column_coordinates[0],
                        end=candidate.column_coordinates[-1],
                        tolerance=tolerance,
                    )
                    else "AMBIGUOUS"
                ),
            },
        )
        for index, coordinate in enumerate(candidate.row_coordinates)
    )
    column_boundaries = tuple(
        _identified(
            PdfTableAxisBoundary,
            "boundary_id",
            "axis-boundary",
            {
                "axis": "COLUMN",
                "boundary_index": index,
                "coordinate": coordinate,
                "evidence": _evidence(
                    page,
                    geometry=table_geometry,
                    text_items=(),
                    segments=_segments_for_interval(
                        candidate.verticals,
                        coordinate=coordinate,
                        start=candidate.row_coordinates[0],
                        end=candidate.row_coordinates[-1],
                        tolerance=tolerance,
                    ),
                    categories=("vertical_separator_boundary",),
                ),
                "state": (
                    "PROVEN"
                    if _covers_interval(
                        candidate.verticals,
                        coordinate=coordinate,
                        start=candidate.row_coordinates[0],
                        end=candidate.row_coordinates[-1],
                        tolerance=tolerance,
                    )
                    else "AMBIGUOUS"
                ),
            },
        )
        for index, coordinate in enumerate(candidate.column_coordinates)
    )
    values = {
        "table_index": table_index,
        "geometry": table_geometry,
        "state": "PARTIAL" if partial_edges else "COMPLETE",
        "row_boundaries": row_boundaries,
        "column_boundaries": column_boundaries,
        "rows": row_models,
        "columns": column_models,
        "cells": cells_tuple,
        "evidence": table_evidence,
        "limitation_codes": (("partial_internal_ruling",) if partial_edges else ()),
    }
    return _identified(PdfTable, "table_id", "table", values)


def _atomic_text_assignments(
    text_items: tuple[_TextItem, ...],
    *,
    candidate: _GridCandidate,
    tolerance: float,
) -> dict[tuple[int, int], tuple[_TextItem, ...]]:
    assignments: dict[tuple[int, int], list[_TextItem]] = {}
    for item in text_items:
        center_x = (item.geometry.x0 + item.geometry.x1) / 2
        center_y = (item.geometry.y0 + item.geometry.y1) / 2
        if not _point_inside(
            center_x, center_y, candidate.geometry, tolerance=tolerance
        ):
            continue
        rows = _possible_containing_intervals(
            center_y, candidate.row_coordinates, tolerance=tolerance
        )
        columns = _possible_containing_intervals(
            center_x, candidate.column_coordinates, tolerance=tolerance
        )
        for row in rows:
            for column in columns:
                assignments.setdefault((row, column), []).append(item)
    return {
        position: tuple(
            sorted(
                items,
                key=lambda item: (
                    item.geometry.y0,
                    item.geometry.x0,
                    item.fact.source_order,
                    item.node.node_id,
                ),
            )
        )
        for position, items in assignments.items()
    }


def _independently_owned_neighbor_overflow(
    item: _TextItem,
    *,
    candidate: _GridCandidate,
    text_items: Sequence[_TextItem],
    row: int,
    column: int,
    tolerance: float,
    uniquely_resolved_axis: Literal["row", "column"] | None = None,
) -> bool:
    """Accept single-axis overflow only across complete, independently owned cells."""

    x0, x1 = candidate.column_coordinates[column : column + 2]
    y0, y1 = candidate.row_coordinates[row : row + 2]
    overflow_left = item.geometry.x0 < x0 - tolerance
    overflow_right = item.geometry.x1 > x1 + tolerance
    overflow_top = item.geometry.y0 < y0 - tolerance
    overflow_bottom = item.geometry.y1 > y1 + tolerance
    horizontal_overflow = overflow_left or overflow_right
    vertical_overflow = overflow_top or overflow_bottom
    combined_unique_resolution = (
        horizontal_overflow and vertical_overflow and uniquely_resolved_axis is not None
    )
    if combined_unique_resolution:
        if not _bbox_inside(
            item.geometry,
            candidate.geometry,
            tolerance=tolerance,
        ):
            return False
        if uniquely_resolved_axis == "row":
            crossed_columns = tuple(
                candidate_column
                for candidate_column, (column_start, column_end) in enumerate(
                    zip(
                        candidate.column_coordinates,
                        candidate.column_coordinates[1:],
                    )
                )
                if candidate_column != column
                and min(item.geometry.x1, column_end)
                - max(item.geometry.x0, column_start)
                > tolerance
            )
            overlapped_rows = tuple(
                candidate_row
                for candidate_row, (row_start, row_end) in enumerate(
                    zip(
                        candidate.row_coordinates,
                        candidate.row_coordinates[1:],
                    )
                )
                if min(item.geometry.y1, row_end) - max(item.geometry.y0, row_start)
                > tolerance
            )
            if not crossed_columns or not overlapped_rows:
                return False
            boundary_columns = range(
                min(column, *crossed_columns) + 1,
                max(column, *crossed_columns) + 1,
            )
            return all(
                _physically_covers_cell_boundary(
                    candidate.verticals,
                    coordinate=candidate.column_coordinates[boundary_column],
                    start=candidate.row_coordinates[overlapped_row],
                    end=candidate.row_coordinates[overlapped_row + 1],
                    tolerance=tolerance,
                )
                for boundary_column in boundary_columns
                for overlapped_row in overlapped_rows
            ) and all(
                _cell_has_independent_contained_owner(
                    text_items,
                    candidate=candidate,
                    row=overlapped_row,
                    column=crossed_column,
                    excluded_item_ids=frozenset({id(item)}),
                    tolerance=tolerance,
                )
                for crossed_column in crossed_columns
                for overlapped_row in overlapped_rows
            )

        crossed_rows = tuple(
            candidate_row
            for candidate_row, (row_start, row_end) in enumerate(
                zip(
                    candidate.row_coordinates,
                    candidate.row_coordinates[1:],
                )
            )
            if candidate_row != row
            and min(item.geometry.y1, row_end) - max(item.geometry.y0, row_start)
            > tolerance
        )
        overlapped_columns = tuple(
            candidate_column
            for candidate_column, (column_start, column_end) in enumerate(
                zip(
                    candidate.column_coordinates,
                    candidate.column_coordinates[1:],
                )
            )
            if min(item.geometry.x1, column_end) - max(item.geometry.x0, column_start)
            > tolerance
        )
        if not crossed_rows or not overlapped_columns:
            return False
        boundary_rows = range(
            min(row, *crossed_rows) + 1,
            max(row, *crossed_rows) + 1,
        )
        return all(
            _physically_covers_cell_boundary(
                candidate.horizontals,
                coordinate=candidate.row_coordinates[boundary_row],
                start=candidate.column_coordinates[overlapped_column],
                end=candidate.column_coordinates[overlapped_column + 1],
                tolerance=tolerance,
            )
            for boundary_row in boundary_rows
            for overlapped_column in overlapped_columns
        ) and all(
            _cell_has_independent_contained_owner(
                text_items,
                candidate=candidate,
                row=crossed_row,
                column=overlapped_column,
                excluded_item_ids=frozenset({id(item)}),
                tolerance=tolerance,
            )
            for crossed_row in crossed_rows
            for overlapped_column in overlapped_columns
        )
    if horizontal_overflow == vertical_overflow:
        return False

    if horizontal_overflow:
        if (
            item.geometry.x0 < candidate.geometry.x0 - tolerance
            or item.geometry.x1 > candidate.geometry.x1 + tolerance
            or item.geometry.y0 < y0 - tolerance
            or item.geometry.y1 > y1 + tolerance
        ):
            return False
        crossed_columns = tuple(
            candidate_column
            for candidate_column, (column_start, column_end) in enumerate(
                zip(
                    candidate.column_coordinates,
                    candidate.column_coordinates[1:],
                )
            )
            if candidate_column != column
            and min(item.geometry.x1, column_end) - max(item.geometry.x0, column_start)
            > tolerance
        )
        if not crossed_columns:
            return False
        boundary_columns = range(
            min(column, *crossed_columns) + 1,
            max(column, *crossed_columns) + 1,
        )
        return all(
            _physically_covers_cell_boundary(
                candidate.verticals,
                coordinate=candidate.column_coordinates[boundary_column],
                start=y0,
                end=y1,
                tolerance=tolerance,
            )
            for boundary_column in boundary_columns
        ) and all(
            _cell_has_independent_contained_owner(
                text_items,
                candidate=candidate,
                row=row,
                column=crossed_column,
                excluded_item_ids=frozenset({id(item)}),
                tolerance=tolerance,
            )
            for crossed_column in crossed_columns
        )

    if (
        item.geometry.y0 < candidate.geometry.y0 - tolerance
        or item.geometry.y1 > candidate.geometry.y1 + tolerance
        or item.geometry.x0 < x0 - tolerance
        or item.geometry.x1 > x1 + tolerance
    ):
        return False
    crossed_rows = tuple(
        candidate_row
        for candidate_row, (row_start, row_end) in enumerate(
            zip(candidate.row_coordinates, candidate.row_coordinates[1:])
        )
        if candidate_row != row
        and min(item.geometry.y1, row_end) - max(item.geometry.y0, row_start)
        > tolerance
    )
    if not crossed_rows:
        return False
    boundary_rows = range(
        min(row, *crossed_rows) + 1,
        max(row, *crossed_rows) + 1,
    )
    return all(
        _physically_covers_cell_boundary(
            candidate.horizontals,
            coordinate=candidate.row_coordinates[boundary_row],
            start=x0,
            end=x1,
            tolerance=tolerance,
        )
        for boundary_row in boundary_rows
    ) and all(
        _cell_has_independent_contained_owner(
            text_items,
            candidate=candidate,
            row=crossed_row,
            column=column,
            excluded_item_ids=frozenset({id(item)}),
            tolerance=tolerance,
        )
        for crossed_row in crossed_rows
    )


def _decorative_overlay_text_fact_ids(
    text_items: tuple[_TextItem, ...],
    *,
    candidate: _GridCandidate,
    tolerance: float,
) -> frozenset[str]:
    """Identify large overlay glyphs that cross a proven grid as page noise.

    The rule is deliberately physical and page-local: it does not inspect text
    content, document identity, or coordinates.  A text item is ignored only
    when it is much larger than the local table text, its center falls inside
    the candidate, it crosses at least one internal grid boundary, and it
    cannot fit within the atomic cell containing its center.
    """

    inside_items = tuple(
        item
        for item in text_items
        if _point_inside(
            (item.geometry.x0 + item.geometry.x1) / 2,
            (item.geometry.y0 + item.geometry.y1) / 2,
            candidate.geometry,
            tolerance=tolerance,
        )
    )
    heights = tuple(
        max(0.1, item.geometry.y1 - item.geometry.y0) for item in inside_items
    )
    if not heights:
        return frozenset()
    local_text_height = median(heights)
    if local_text_height <= 0:
        return frozenset()
    overlay_ids: set[str] = set()
    internal_x = candidate.column_coordinates[1:-1]
    internal_y = candidate.row_coordinates[1:-1]
    for item in inside_items:
        height = item.geometry.y1 - item.geometry.y0
        width = item.geometry.x1 - item.geometry.x0
        if height < local_text_height * 3:
            continue
        center_x = (item.geometry.x0 + item.geometry.x1) / 2
        center_y = (item.geometry.y0 + item.geometry.y1) / 2
        rows = _possible_containing_intervals(
            center_y, candidate.row_coordinates, tolerance=tolerance
        )
        columns = _possible_containing_intervals(
            center_x, candidate.column_coordinates, tolerance=tolerance
        )
        if not rows or not columns:
            continue
        containing_cells = tuple(
            PdfBoundingBox(
                x0=candidate.column_coordinates[column],
                y0=candidate.row_coordinates[row],
                x1=candidate.column_coordinates[column + 1],
                y1=candidate.row_coordinates[row + 1],
            )
            for row in rows
            for column in columns
        )
        if any(
            _bbox_inside(item.geometry, cell, tolerance=tolerance)
            for cell in containing_cells
        ):
            continue
        crossed_verticals = tuple(
            (boundary_column, x)
            for boundary_column, x in enumerate(internal_x, start=1)
            if item.geometry.x0 + tolerance < x < item.geometry.x1 - tolerance
        )
        crossed_horizontals = tuple(
            (boundary_row, y)
            for boundary_row, y in enumerate(internal_y, start=1)
            if item.geometry.y0 + tolerance < y < item.geometry.y1 - tolerance
        )
        crosses_vertical = bool(crossed_verticals)
        crosses_horizontal = bool(crossed_horizontals)
        if not (crosses_vertical or crosses_horizontal):
            continue
        overlapped_rows = tuple(
            row
            for row, (row_start, row_end) in enumerate(
                zip(candidate.row_coordinates, candidate.row_coordinates[1:])
            )
            if min(item.geometry.y1, row_end) - max(item.geometry.y0, row_start)
            > tolerance
        )
        overlapped_columns = tuple(
            column
            for column, (column_start, column_end) in enumerate(
                zip(candidate.column_coordinates, candidate.column_coordinates[1:])
            )
            if min(item.geometry.x1, column_end) - max(item.geometry.x0, column_start)
            > tolerance
        )
        complete_crossings = all(
            _physically_covers_cell_boundary(
                candidate.verticals,
                coordinate=x,
                start=candidate.row_coordinates[row],
                end=candidate.row_coordinates[row + 1],
                tolerance=tolerance,
            )
            for _boundary_column, x in crossed_verticals
            for row in overlapped_rows
        ) and all(
            _physically_covers_cell_boundary(
                candidate.horizontals,
                coordinate=y,
                start=candidate.column_coordinates[column],
                end=candidate.column_coordinates[column + 1],
                tolerance=tolerance,
            )
            for _boundary_row, y in crossed_horizontals
            for column in overlapped_columns
        )
        if not complete_crossings:
            continue
        if crosses_vertical != crosses_horizontal:
            independent_ordinary_owners = all(
                _cell_has_independent_contained_owner(
                    inside_items,
                    candidate=candidate,
                    row=row,
                    column=adjacent_column,
                    excluded_item_ids=frozenset({id(item)}),
                    tolerance=tolerance,
                )
                for boundary_column, _x in crossed_verticals
                for row in overlapped_rows
                for adjacent_column in (boundary_column - 1, boundary_column)
            ) and all(
                _cell_has_independent_contained_owner(
                    inside_items,
                    candidate=candidate,
                    row=adjacent_row,
                    column=column,
                    excluded_item_ids=frozenset({id(item)}),
                    tolerance=tolerance,
                )
                for boundary_row, _y in crossed_horizontals
                for column in overlapped_columns
                for adjacent_row in (boundary_row - 1, boundary_row)
            )
            if not independent_ordinary_owners:
                nonorthogonal_candidate_local_overlay = (
                    item.fact.rotation is not None
                    and item.fact.rotation % 90 != 0
                    and _bbox_inside(
                        item.geometry,
                        candidate.geometry,
                        tolerance=tolerance,
                    )
                )
                if not nonorthogonal_candidate_local_overlay:
                    continue
                if crosses_vertical:
                    independent_ordinary_owners = all(
                        any(
                            _cell_has_independent_contained_owner(
                                inside_items,
                                candidate=candidate,
                                row=row,
                                column=adjacent_column,
                                excluded_item_ids=frozenset({id(item)}),
                                tolerance=tolerance,
                            )
                            for row in range(len(candidate.row_coordinates) - 1)
                        )
                        for boundary_column, _x in crossed_verticals
                        for adjacent_column in (
                            boundary_column - 1,
                            boundary_column,
                        )
                    )
                else:
                    independent_ordinary_owners = all(
                        any(
                            _cell_has_independent_contained_owner(
                                inside_items,
                                candidate=candidate,
                                row=adjacent_row,
                                column=column,
                                excluded_item_ids=frozenset({id(item)}),
                                tolerance=tolerance,
                            )
                            for column in range(len(candidate.column_coordinates) - 1)
                        )
                        for boundary_row, _y in crossed_horizontals
                        for adjacent_row in (boundary_row - 1, boundary_row)
                    )
                if not independent_ordinary_owners:
                    continue
        cell_height = max(0.1, min(cell.y1 - cell.y0 for cell in containing_cells))
        cell_width = max(0.1, min(cell.x1 - cell.x0 for cell in containing_cells))
        if height >= cell_height * 0.9 or width >= cell_width * 0.9:
            overlay_ids.add(item.fact.fact_id)
    return frozenset(overlay_ids)


def _absent_boundary_decision(
    first: Sequence[_TextItem],
    second: Sequence[_TextItem],
    *,
    axis: str,
    coordinate: float,
    tolerance: float,
    partial_physical_boundary: bool = False,
    repeated_terminated_run: bool = False,
    isolated_terminated: bool = False,
    first_region_center: float | None = None,
    second_region_center: float | None = None,
    leading_partition: bool = False,
    leading_fill_span_evidence: bool = False,
    repeated_bilateral_body_proof: bool = False,
    dark_full_width_band: bool = False,
) -> str:
    if leading_fill_span_evidence:
        return "merge"
    items = tuple(first) + tuple(second)
    crossing = tuple(
        item
        for item in items
        if (
            item.geometry.x0 < coordinate - tolerance
            and item.geometry.x1 > coordinate + tolerance
            if axis == "vertical"
            else item.geometry.y0 < coordinate - tolerance
            and item.geometry.y1 > coordinate + tolerance
        )
    )
    distinct_adjacent_content = bool(first) and bool(second)
    if (
        crossing
        and distinct_adjacent_content
        and any(item not in crossing for item in first)
        and any(item not in crossing for item in second)
    ):
        return "merge"
    if crossing:
        if repeated_bilateral_body_proof:
            return "merge"
        if axis == "horizontal":
            return "merge"
        if (
            first_region_center is not None
            and second_region_center is not None
            and any(
                item.geometry.x0 <= first_region_center + tolerance
                and item.geometry.x1 >= second_region_center - tolerance
                for item in crossing
            )
        ):
            return "merge"
        return "ambiguous"
    if distinct_adjacent_content and not crossing:
        return "partial"
    if repeated_terminated_run:
        return "merge"
    if dark_full_width_band or leading_partition:
        return "merge"
    if partial_physical_boundary:
        return "partial"
    if isolated_terminated and not (first or second):
        return "ambiguous"
    if isolated_terminated and bool(first) != bool(second):
        if axis != "horizontal":
            return "partial"
        if (
            first
            and first_region_center is not None
            and any(
                (item.geometry.y0 + item.geometry.y1) / 2
                <= first_region_center
                + (item.geometry.y1 - item.geometry.y0) / 2
                + tolerance
                for item in first
            )
        ):
            return "merge"
        if (
            second
            and second_region_center is not None
            and any(
                (item.geometry.y0 + item.geometry.y1) / 2
                >= second_region_center
                - (item.geometry.y1 - item.geometry.y0) / 2
                - tolerance
                for item in second
            )
        ):
            return "merge"
        return "ambiguous"
    return "ambiguous"


def _outer_enclosure_complete(candidate: _GridCandidate, *, tolerance: float) -> bool:
    x0, x1 = candidate.column_coordinates[0], candidate.column_coordinates[-1]
    y0, y1 = candidate.row_coordinates[0], candidate.row_coordinates[-1]
    return all(
        (
            _covers_interval(
                candidate.horizontals,
                coordinate=y0,
                start=x0,
                end=x1,
                tolerance=tolerance,
            ),
            _covers_interval(
                candidate.horizontals,
                coordinate=y1,
                start=x0,
                end=x1,
                tolerance=tolerance,
            ),
            _covers_interval(
                candidate.verticals,
                coordinate=x0,
                start=y0,
                end=y1,
                tolerance=tolerance,
            ),
            _covers_interval(
                candidate.verticals,
                coordinate=x1,
                start=y0,
                end=y1,
                tolerance=tolerance,
            ),
        )
    )


def _perimeter_segments(
    candidate: _GridCandidate,
    *,
    row_start: int,
    row_span: int,
    column_start: int,
    column_span: int,
    tolerance: float,
) -> tuple[tuple[_Segment, ...], bool]:
    x0 = candidate.column_coordinates[column_start]
    x1 = candidate.column_coordinates[column_start + column_span]
    y0 = candidate.row_coordinates[row_start]
    y1 = candidate.row_coordinates[row_start + row_span]
    checks = (
        (candidate.horizontals, y0, x0, x1),
        (candidate.horizontals, y1, x0, x1),
        (candidate.verticals, x0, y0, y1),
        (candidate.verticals, x1, y0, y1),
    )
    complete = all(
        _covers_interval(
            segments,
            coordinate=coordinate,
            start=start,
            end=end,
            tolerance=tolerance,
        )
        for segments, coordinate, start, end in checks
    )
    retained = tuple(
        sorted(
            {
                segment
                for segments, coordinate, start, end in checks
                for segment in _segments_for_interval(
                    segments,
                    coordinate=coordinate,
                    start=start,
                    end=end,
                    tolerance=tolerance,
                )
            },
            key=lambda item: (
                item.orientation,
                item.coordinate,
                item.start,
                item.end,
                item.separator_candidate_ids,
            ),
        )
    )
    return retained, complete


def _evidence(
    page: PdfTablePageInput,
    *,
    geometry: PdfBoundingBox,
    text_items: tuple[_TextItem, ...],
    segments: Sequence[_Segment],
    categories: tuple[str, ...],
) -> PdfTableEvidence:
    return PdfTableEvidence(
        source_sha256=page.source_sha256,
        page_id=page.page_id,
        page_index=page.page_index,
        inherited_page_sidecar_id=page.inherited_page_sidecar_id,
        inherited_page_sidecar_sha256=page.inherited_page_sidecar_sha256,
        inherited_manifest_id=page.inherited_manifest_id,
        reading_page_sidecar_id=page.reading_page_sidecar_id,
        reading_page_sidecar_sha256=page.reading_page_sidecar_sha256,
        source_fact_ids=tuple(sorted({item.fact.fact_id for item in text_items})),
        source_layout_node_ids=tuple(
            sorted({item.node.node_id for item in text_items})
        ),
        drawing_fact_ids=tuple(
            sorted({fact for segment in segments for fact in segment.drawing_fact_ids})
        ),
        separator_candidate_ids=tuple(
            sorted(
                {
                    candidate
                    for segment in segments
                    for candidate in segment.separator_candidate_ids
                }
            )
        ),
        evidence_categories=tuple(
            sorted(
                set(categories)
                | {
                    derivation
                    for segment in segments
                    for derivation in segment.derivations
                }
            )
        ),
        geometry=geometry,
    )


def _identified[IdentifiedModelT: BaseModel](
    model: type[IdentifiedModelT],
    field: str,
    kind: str,
    values: dict[str, Any],
) -> IdentifiedModelT:
    complete = {
        name: definition.default
        for name, definition in model.model_fields.items()
        if name != field and not definition.is_required()
    } | values
    return model(**{field: table_structure_identifier(kind, complete), **complete})


def _cell_role(
    *,
    page: PdfTablePageInput,
    geometry: PdfBoundingBox,
    row_start: int,
    column_start: int,
    column_span: int,
    row_count: int,
    column_count: int,
    leading_header_rows: frozenset[int],
    assigned: Sequence[_TextItem],
    body_font_baseline: float | None,
    config: PdfTableAlgorithmConfig,
) -> tuple[str, str, tuple[str, ...]]:
    dark_full_width_fill = _has_dark_full_width_fill(
        page,
        geometry=geometry,
        column_start=column_start,
        column_span=column_span,
        column_count=column_count,
        config=config,
    )
    if row_start in leading_header_rows or dark_full_width_fill:
        proven = bool(assigned) and all(
            _font_emphasized(item.fact, body_font_baseline=body_font_baseline)
            for item in assigned
        )
        physical_evidence = {
            *(
                ("leading_header_band",)
                if row_start == 0
                else ("leading_partition_increase",)
                if row_start in leading_header_rows
                else ()
            ),
            *(
                ("first_row_repeated_column_alignment",)
                if row_start == 0 and column_count >= 2
                else ()
            ),
            *(("source_backed_dark_full_width_fill",) if dark_full_width_fill else ()),
        }
        return (
            "COLUMN_HEADER_LIKE",
            "PROVEN" if proven else "CANDIDATE",
            tuple(
                sorted(
                    {
                        *physical_evidence,
                        *(("font_emphasis",) if proven else ()),
                    }
                )
            ),
        )
    if column_start == 0 and row_count >= 2:
        proven = bool(assigned) and all(
            _font_emphasized(item.fact, body_font_baseline=body_font_baseline)
            for item in assigned
        )
        return (
            "ROW_HEADER_LIKE",
            "PROVEN" if proven else "CANDIDATE",
            tuple(
                sorted(
                    {
                        "first_column_repeated_row_alignment",
                        *(("font_emphasis",) if proven else ()),
                    }
                )
            ),
        )
    return "BODY_LIKE", "PROVEN", ("interior_table_position",)


def _has_dark_full_width_fill(
    page: PdfTablePageInput,
    *,
    geometry: PdfBoundingBox,
    column_start: int,
    column_span: int,
    column_count: int,
    config: PdfTableAlgorithmConfig,
) -> bool:
    if column_start != 0 or column_span != column_count:
        return False
    cell_area = (geometry.x1 - geometry.x0) * (geometry.y1 - geometry.y0)
    if cell_area <= 0:
        return False
    for drawing in page.facts.drawings:
        if drawing.kind != "rectangle" or drawing.paint_operation not in {
            "fill",
            "fill_stroke",
        }:
            continue
        luminance = drawing.parser_metadata.get("fill_luminance")
        if (
            isinstance(luminance, bool)
            or not isinstance(luminance, (int, float))
            or not isfinite(luminance)
            or luminance < 0
            or luminance > config.header_dark_fill_maximum_luminance
        ):
            continue
        overlap_width = max(
            0.0,
            min(geometry.x1, drawing.bbox.x1) - max(geometry.x0, drawing.bbox.x0),
        )
        overlap_height = max(
            0.0,
            min(geometry.y1, drawing.bbox.y1) - max(geometry.y0, drawing.bbox.y0),
        )
        if (
            overlap_width * overlap_height / cell_area
            >= config.header_fill_minimum_cell_coverage
        ):
            return True
    return False


def _font_emphasized(fact: PdfTextFact, *, body_font_baseline: float | None) -> bool:
    font_name = (fact.font_name or "").casefold()
    if any(token in font_name for token in ("bold", "semibold", "demibold")):
        return True
    font_size = fact.effective_font_size_y or fact.font_size
    return bool(
        font_size is not None
        and body_font_baseline is not None
        and font_size > body_font_baseline * 1.05
    )


def _point_inside(
    x: float, y: float, geometry: PdfBoundingBox, *, tolerance: float
) -> bool:
    return bool(
        geometry.x0 - tolerance <= x <= geometry.x1 + tolerance
        and geometry.y0 - tolerance <= y <= geometry.y1 + tolerance
    )


def _bbox_inside(
    bbox: PdfBoundingBox, geometry: PdfBoundingBox, *, tolerance: float
) -> bool:
    return bool(
        bbox.x0 >= geometry.x0 - tolerance
        and bbox.y0 >= geometry.y0 - tolerance
        and bbox.x1 <= geometry.x1 + tolerance
        and bbox.y1 <= geometry.y1 + tolerance
    )


def _containing_interval(
    value: float, coordinates: tuple[float, ...], *, tolerance: float
) -> int | None:
    if any(abs(value - coordinate) <= tolerance for coordinate in coordinates):
        return None
    for index, (start, end) in enumerate(zip(coordinates, coordinates[1:])):
        if start + tolerance < value < end - tolerance:
            return index
    return None


def _possible_containing_intervals(
    value: float,
    coordinates: tuple[float, ...],
    *,
    tolerance: float,
) -> tuple[int, ...]:
    internal_matches = tuple(
        index
        for index, coordinate in enumerate(coordinates[1:-1], start=1)
        if abs(value - coordinate) <= tolerance
    )
    if internal_matches:
        if len(internal_matches) != 1:
            return ()
        boundary = internal_matches[0]
        return (boundary - 1, boundary)
    selected = _containing_interval(value, coordinates, tolerance=tolerance)
    return () if selected is None else (selected,)


def _text_projection_parts(
    items: tuple[_TextItem, ...],
) -> tuple[PdfTableCellTextPart, ...]:
    if not items:
        return ()
    heights = [max(0.1, item.geometry.y1 - item.geometry.y0) for item in items]
    line_tolerance = median(heights) * 0.6
    lines: list[list[_TextItem]] = []
    for item in items:
        center_y = (item.geometry.y0 + item.geometry.y1) / 2
        if not lines:
            lines.append([item])
            continue
        previous_center = sum(
            (member.geometry.y0 + member.geometry.y1) / 2 for member in lines[-1]
        ) / len(lines[-1])
        if abs(center_y - previous_center) <= line_tolerance:
            lines[-1].append(item)
        else:
            lines.append([item])
    parts: list[PdfTableCellTextPart] = []
    for line in lines:
        ordered = sorted(
            line,
            key=lambda item: (
                item.geometry.x0,
                item.fact.source_order,
                item.node.node_id,
            ),
        )
        previous: _TextItem | None = None
        for current in ordered:
            separator: Literal["", " ", "\n"] = (
                ("\n" if parts else "")
                if previous is None
                else (" " if _ascii_word_boundary(previous.text, current.text) else "")
            )
            parts.append(
                PdfTableCellTextPart(
                    source_fact_id=current.fact.fact_id,
                    source_layout_node_id=current.node.node_id,
                    member_binding_id=current.view.binding.binding_id
                    if current.view is not None
                    else None,
                    separator_before=separator,
                )
            )
            previous = current
    return tuple(parts)


def _project_text(items: tuple[_TextItem, ...]) -> str:
    text_by_key = {
        (
            item.fact.fact_id,
            item.node.node_id,
            item.view.binding.binding_id if item.view is not None else None,
        ): item.text
        for item in items
    }
    return "".join(
        part.separator_before
        + text_by_key[
            (part.source_fact_id, part.source_layout_node_id, part.member_binding_id)
        ]
        for part in _text_projection_parts(items)
    )


def _project_line(items: list[_TextItem]) -> str:
    # Retained private entry point for existing callers; line semantics unchanged.
    ordered = sorted(
        items,
        key=lambda item: (item.geometry.x0, item.fact.source_order, item.node.node_id),
    )
    result = ordered[0].text
    for previous, current in zip(ordered, ordered[1:]):
        result += (
            " " if _ascii_word_boundary(previous.text, current.text) else ""
        ) + current.text
    return result


def _ascii_word_boundary(left: str, right: str) -> bool:
    return bool(left and right and left[-1].isascii() and right[0].isascii())


def _two_row_alignment_candidate(
    page: PdfTablePageInput,
    items: tuple[_TextItem, ...],
    config: PdfTableAlgorithmConfig,
    tolerance: float,
) -> bool:
    if len(items) == 2 and page.facts.text_members:
        diagnostic = repeated_member_grid(
            source_sha256=page.source_sha256,
            page=page.facts,
            parents=tuple((item.fact, item.node) for item in items),
            minimum_rows=2,
            minimum_columns=max(4, config.borderless_minimum_columns),
        )
        if diagnostic.views:
            return True
    if len(items) < 4 or any(
        item.fact.rotation != 0
        or item.geometry.x1 <= item.geometry.x0
        or item.geometry.y1 <= item.geometry.y0
        or (item.geometry.x1 - item.geometry.x0) / page.facts.canonical_width
        > config.borderless_maximum_text_width_ratio
        for item in items
    ):
        return False
    height = median(item.geometry.y1 - item.geometry.y0 for item in items)
    rows = _cluster_items(items, axis="y", tolerance=max(tolerance, height * 0.6))
    if len(rows) != 2 or max(item.geometry.y1 for item in rows[0]) > min(
        item.geometry.y0 for item in rows[1]
    ):
        return False
    anchors = _cluster_coordinates(
        (item.geometry.x0 for item in items), tolerance=max(tolerance, height)
    )
    if len(anchors) < 2:
        return False
    positions: set[tuple[int, int]] = set()
    for row_index, row in enumerate(rows):
        ordered = sorted(row, key=lambda item: item.geometry.x0)
        if any(
            left.geometry.x1 > right.geometry.x0
            for left, right in zip(ordered, ordered[1:])
        ):
            return False
        for item in row:
            matches = [
                index
                for index, value in enumerate(anchors)
                if abs(item.geometry.x0 - value) <= max(tolerance, height)
            ]
            if len(matches) != 1 or (row_index, matches[0]) in positions:
                return False
            positions.add((row_index, matches[0]))
    return len(positions) / (2 * len(anchors)) >= config.borderless_minimum_occupancy


def _looks_like_borderless_table(
    items: tuple[_TextItem, ...],
    *,
    page: PdfTablePageInput,
    config: PdfTableAlgorithmConfig,
    tolerance: float,
) -> bool:
    words = tuple(item for item in items if item.node.node_type == "word")
    minimum = config.borderless_minimum_rows * config.borderless_minimum_columns
    if len(words) < minimum:
        return False
    if any(
        (item.geometry.x1 - item.geometry.x0) / page.facts.canonical_width
        > config.borderless_maximum_text_width_ratio
        for item in words
    ):
        return False
    heights = [max(0.1, item.geometry.y1 - item.geometry.y0) for item in words]
    row_tolerance = max(tolerance, median(heights) * 0.6)
    rows = _cluster_items(words, axis="y", tolerance=row_tolerance)
    if len(rows) < config.borderless_minimum_rows:
        return False
    x_coordinates = _cluster_coordinates(
        (item.geometry.x0 for item in words), tolerance=max(tolerance, median(heights))
    )
    if len(x_coordinates) < config.borderless_minimum_columns:
        return False
    occupied = sum(
        1
        for row in rows
        for coordinate in x_coordinates
        if any(
            abs(item.geometry.x0 - coordinate) <= max(tolerance, median(heights))
            for item in row
        )
    )
    return (
        occupied / (len(rows) * len(x_coordinates))
        >= config.borderless_minimum_occupancy
    )


def _cluster_items(
    items: Sequence[_TextItem], *, axis: str, tolerance: float
) -> tuple[tuple[_TextItem, ...], ...]:
    coordinate: Callable[[_TextItem], float] = (
        (lambda item: (item.geometry.y0 + item.geometry.y1) / 2)
        if axis == "y"
        else (lambda item: (item.geometry.x0 + item.geometry.x1) / 2)
    )
    groups: list[list[_TextItem]] = []
    for item in sorted(
        items, key=lambda value: (coordinate(value), value.node.node_id)
    ):
        if (
            groups
            and abs(
                coordinate(item)
                - sum(coordinate(member) for member in groups[-1]) / len(groups[-1])
            )
            <= tolerance
        ):
            groups[-1].append(item)
        else:
            groups.append([item])
    return tuple(tuple(group) for group in groups)


def _noncomplete_sidecar(
    page: PdfTablePageInput,
    *,
    config: PdfTableAlgorithmConfig,
    outcome: Literal["PARTIAL", "AMBIGUOUS", "NO_TABLE"],
    limitation_codes: tuple[str, ...],
    evidence_categories: tuple[str, ...],
    segments: Sequence[_Segment],
) -> PdfTableStructurePageSidecar:
    geometry = PdfBoundingBox(
        x0=0,
        y0=0,
        x1=page.facts.canonical_width,
        y1=page.facts.canonical_height,
    )
    evidence = _evidence(
        page,
        geometry=geometry,
        text_items=(),
        segments=segments,
        categories=evidence_categories,
    )
    return build_table_page_sidecar(
        source_sha256=page.source_sha256,
        page_id=page.page_id,
        page_index=page.page_index,
        canonical_width=page.facts.canonical_width,
        canonical_height=page.facts.canonical_height,
        outcome=outcome,
        tables=(),
        negative_evidence=(evidence,),
        inherited_page_sidecar_id=page.inherited_page_sidecar_id,
        inherited_page_sidecar_sha256=page.inherited_page_sidecar_sha256,
        inherited_manifest_id=page.inherited_manifest_id,
        reading_page_sidecar_id=page.reading_page_sidecar_id,
        reading_page_sidecar_sha256=page.reading_page_sidecar_sha256,
        configuration_identity=config.identity,
        dependency_identity=page.dependency_identity,
        limitation_codes=limitation_codes,
    )


def _reindex_table(table: PdfTable, *, table_index: int) -> PdfTable:
    if table.table_index == table_index:
        return table
    values = table.model_dump(mode="python", exclude={"table_id"})
    values["table_index"] = table_index
    return _identified(PdfTable, "table_id", "table", values)


def _with_table_limitation(table: PdfTable, limitation: str) -> PdfTable:
    values = table.model_dump(mode="python", exclude={"table_id"})
    values["state"] = "PARTIAL"
    values["limitation_codes"] = tuple(
        sorted(set(table.limitation_codes) | {limitation})
    )
    return _identified(PdfTable, "table_id", "table", values)

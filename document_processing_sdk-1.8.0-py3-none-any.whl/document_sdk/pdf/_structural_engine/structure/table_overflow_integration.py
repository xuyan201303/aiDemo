"""Integrate explicit source-emission ownership without claiming containment."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .native_event_ownership import (
    SourceAnchoredOverflowProof,
    select_source_anchored_overflow,
    validate_source_anchored_overflow,
)
from .table_member_contracts import PdfTableCellTextPart, PdfTableCellTextProjection

if TYPE_CHECKING:
    from collections.abc import Sequence

    from document_sdk.pdf._structural_engine.facts.contracts import PdfPageFacts
    from document_sdk.pdf._structural_engine.layout.contracts import PdfLayoutNode

    from .table_algorithm import PdfTablePageInput, _GridCandidate
    from .table_contracts import PdfTable, PdfTableCell, PdfTableStructurePageSidecar
    from .table_text_evidence import TableTextEvidenceCollector


OVERFLOW_CODE = "source_anchored_grid_contains_actual_overflow"
OVERFLOW_PREFIX = "source_anchored_overflow:"


def _cell_overflow_part(
    cell: PdfTableCell,
    projection: PdfTableCellTextProjection | None,
) -> tuple[str, PdfTableCellTextPart] | None:
    """Validate the tagged one-event projection before resolving source proofs."""
    parts = () if projection is None else projection.parts
    ids = [
        p.source_anchored_overflow_id
        for p in parts
        if p.source_anchored_overflow_id is not None
    ]
    tokens = {
        v.removeprefix(OVERFLOW_PREFIX)
        for v in cell.text_assignment_evidence
        if v.startswith(OVERFLOW_PREFIX)
    }
    if tokens != set(ids):
        message = "table overflow projection/token mismatch"
        raise ValueError(message)
    if not ids:
        if (
            projection is not None
            and projection.method == "source_anchored_cell_text.v1"
        ):
            message = "source-anchored cell lacks its proof"
            raise ValueError(message)
        return None
    if (
        projection is None
        or projection.method != "source_anchored_cell_text.v1"
        or len(parts) != 1
        or len(ids) != 1
        or parts[0].separator_before
        or parts[0].member_binding_id is not None
    ):
        message = "overflow cell requires one exact source-event part"
        raise ValueError(message)
    return ids[0], parts[0]


def validate_overflow_references(sidecar: PdfTableStructurePageSidecar) -> None:
    """Require a complete, exclusive, explicitly limited source proof per cell."""
    proofs = {
        proof.proof_id: proof for proof in sidecar.source_anchored_overflow_proofs
    }
    if len(proofs) != len(sidecar.source_anchored_overflow_proofs):
        message = "table overflow proof identity repeated"
        raise ValueError(message)
    projections = {p.cell_id: p for p in sidecar.cell_text_projections}
    used: set[str] = set()
    members: set[str] = set()
    for table in sidecar.tables:
        table_proofs = []
        for cell in table.cells:
            projection = projections.get(cell.cell_id)
            selected = _cell_overflow_part(cell, projection)
            if selected is None:
                continue
            identity, part = selected
            proof = proofs.get(identity)
            if (
                proof is None
                or identity in used
                or members.intersection(proof.member_ids)
            ):
                message = "overflow proof missing or source occurrence reused"
                raise ValueError(message)
            if (
                proof.source_sha256 != sidecar.source_sha256
                or proof.page_id != sidecar.page_id
                or proof.row_index != cell.row_start
                or proof.column_index != cell.column_start
                or cell.row_span != 1
                or cell.column_span != 1
                or proof.cell_geometry != cell.geometry
                or cell.text != proof.text
                or cell.state != "AMBIGUOUS"
                or table.state != "PARTIAL"
                or sidecar.outcome != "PARTIAL"
                or OVERFLOW_CODE not in cell.limitation_codes
                or OVERFLOW_CODE not in table.limitation_codes
                or (part.source_fact_id, part.source_layout_node_id)
                != (proof.parent_fact_id, proof.parent_layout_node_id)
            ):
                message = "table overflow proof is not bound to its limited cell"
                raise ValueError(message)
            used.add(identity)
            members.update(proof.member_ids)
            table_proofs.append(proof)
        if table_proofs and len(table_proofs) != len(table.cells):
            message = "source-anchored grid requires proof for every cell"
            raise ValueError(message)
    if used != set(proofs):
        message = "unused table overflow proof"
        raise ValueError(message)


def validate_overflow_sources(
    sidecar: PdfTableStructurePageSidecar,
    *,
    page: PdfPageFacts,
    nodes: dict[str, PdfLayoutNode],
) -> None:
    """Replay every physical grid against actual bound Facts and Layout."""
    validate_overflow_references(sidecar)
    by_id = {proof.proof_id: proof for proof in sidecar.source_anchored_overflow_proofs}
    projections = {p.cell_id: p for p in sidecar.cell_text_projections}
    replay_budget = 100_000
    for table in sidecar.tables:
        proofs = (
            tuple(
                by_id[part.source_anchored_overflow_id]
                for cell in table.cells
                for part in projections[cell.cell_id].parts
                if part.source_anchored_overflow_id is not None
            )
            if by_id
            else ()
        )
        if proofs:
            work = len(proofs) * len(page.text_members)
            if work > replay_budget:
                message = "table overflow replay exceeds its page work budget"
                raise ValueError(message)
            replay_budget -= work
            validate_source_anchored_overflow(
                proofs,
                source_sha256=sidecar.source_sha256,
                page=page,
                nodes=tuple(nodes.values()),
                row_coordinates=tuple(
                    bound.coordinate for bound in table.row_boundaries
                ),
                column_coordinates=tuple(
                    bound.coordinate for bound in table.column_boundaries
                ),
            )


def try_source_anchored_table(
    page: PdfTablePageInput,
    candidate: _GridCandidate,
    collector: TableTextEvidenceCollector,
) -> tuple[PdfTable | None, str | None]:
    """Recover only a complete source-event grid; all cells remain ambiguous."""
    count = (len(candidate.row_coordinates) - 1) * (
        len(candidate.column_coordinates) - 1
    )
    upper_comparisons = count * len(page.facts.text_members)
    if not collector.reserve_overflow_scan(upper_comparisons):
        return None, "table_native_ownership_scan_resource_limit"
    selected = select_source_anchored_overflow(
        source_sha256=page.source_sha256,
        page=page.facts,
        nodes=page.layout.nodes,
        row_coordinates=candidate.row_coordinates,
        column_coordinates=candidate.column_coordinates,
        maximum_selections=collector.maximum_selections,
        maximum_references=collector.maximum_references,
        maximum_bytes=collector.maximum_bytes,
        maximum_collision_comparisons=upper_comparisons,
    )
    if selected.status != "PARTIAL":
        return None, (
            selected.limitation_codes[0] if selected.limitation_codes else None
        )
    if not collector.reserve_overflow_proofs(selected.proofs):
        return None, "table_native_ownership_evidence_resource_limit"
    return _build_source_table(page, candidate, selected.proofs, collector), None


def _build_source_table(
    page: PdfTablePageInput,
    candidate: _GridCandidate,
    proofs: Sequence[SourceAnchoredOverflowProof],
    collector: TableTextEvidenceCollector,
) -> PdfTable | None:
    """Use real grid geometry and source parents, never rewritten parent Facts."""
    from document_sdk.pdf._structural_engine.facts.contracts import PdfBoundingBox

    from . import table_contracts as contracts
    from .table_algorithm import _evidence, _identified, _TextItem

    facts = {
        fact.fact_id: fact
        for layer in (
            page.facts.words,
            page.facts.text_spans,
            page.facts.line_candidates,
            page.facts.characters,
        )
        for fact in layer
    }
    nodes = {node.node_id: node for node in page.layout.nodes}
    items = {
        proof.parent_layout_node_id: _TextItem(
            facts[proof.parent_fact_id],
            nodes[proof.parent_layout_node_id],
            facts[proof.parent_fact_id].bbox,
        )
        for proof in proofs
    }
    segments = candidate.horizontals + candidate.verticals
    evidence = _evidence(
        page,
        geometry=candidate.geometry,
        text_items=tuple(
            items[key] for key in sorted({p.parent_layout_node_id for p in proofs})
        ),
        segments=segments,
        categories=(
            "orthogonal_separator_grid",
            "source_emission_anchors",
            "actual_overflow_retained",
        ),
    )
    identify = _identified
    cells = []
    for proof in proofs:
        cell_evidence = _evidence(
            page,
            geometry=proof.cell_geometry,
            text_items=(items[proof.parent_layout_node_id],),
            segments=segments,
            categories=(
                "closed_physical_cell",
                "source_emission_anchors",
                "actual_overflow_retained",
            ),
        )
        cell = identify(
            contracts.PdfTableCell,
            "cell_id",
            "cell",
            {
                "row_start": proof.row_index,
                "column_start": proof.column_index,
                "row_span": 1,
                "column_span": 1,
                "geometry": proof.cell_geometry,
                "text": proof.text,
                "text_fact_ids": (proof.parent_fact_id,),
                "text_layout_node_ids": (proof.parent_layout_node_id,),
                "text_assignment_evidence": (OVERFLOW_PREFIX + proof.proof_id,),
                "state": "AMBIGUOUS",
                "role": "UNKNOWN",
                "role_status": "UNAVAILABLE",
                "role_evidence": (),
                "empty_cell_evidence": (),
                "evidence": cell_evidence,
                "limitation_codes": (OVERFLOW_CODE,),
            },
        )
        projection = PdfTableCellTextProjection(
            cell_id=cell.cell_id,
            method="source_anchored_cell_text.v1",
            parts=(
                PdfTableCellTextPart(
                    source_fact_id=proof.parent_fact_id,
                    source_layout_node_id=proof.parent_layout_node_id,
                    source_anchored_overflow_id=proof.proof_id,
                ),
            ),
        )
        if not collector.reserve_projection(projection):
            return None
        cells.append(cell)
    ys, xs = candidate.row_coordinates, candidate.column_coordinates
    rows = tuple(
        identify(
            contracts.PdfTableRow,
            "row_id",
            "row",
            {
                "row_index": i,
                "geometry": PdfBoundingBox(x0=xs[0], y0=y, x1=xs[-1], y1=ys[i + 1]),
                "anchor_cell_ids": tuple(
                    sorted(c.cell_id for c in cells if c.row_start == i)
                ),
                "evidence": evidence,
            },
        )
        for i, y in enumerate(ys[:-1])
    )
    columns = tuple(
        identify(
            contracts.PdfTableColumn,
            "column_id",
            "column",
            {
                "column_index": i,
                "geometry": PdfBoundingBox(x0=x, y0=ys[0], x1=xs[i + 1], y1=ys[-1]),
                "anchor_cell_ids": tuple(
                    sorted(c.cell_id for c in cells if c.column_start == i)
                ),
                "evidence": evidence,
            },
        )
        for i, x in enumerate(xs[:-1])
    )
    boundaries = []
    for axis, coordinates in (("ROW", ys), ("COLUMN", xs)):
        boundaries.append(
            tuple(
                identify(
                    contracts.PdfTableAxisBoundary,
                    "boundary_id",
                    "axis-boundary",
                    {
                        "axis": axis,
                        "boundary_index": i,
                        "coordinate": value,
                        "state": "PROVEN",
                        "evidence": evidence,
                    },
                )
                for i, value in enumerate(coordinates)
            )
        )
    return identify(
        contracts.PdfTable,
        "table_id",
        "table",
        {
            "table_index": 0,
            "geometry": candidate.geometry,
            "state": "PARTIAL",
            "row_boundaries": boundaries[0],
            "column_boundaries": boundaries[1],
            "rows": rows,
            "columns": columns,
            "cells": tuple(cells),
            "evidence": evidence,
            "limitation_codes": (OVERFLOW_CODE,),
        },
    )

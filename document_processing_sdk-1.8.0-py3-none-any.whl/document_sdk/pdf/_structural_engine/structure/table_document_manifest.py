# ruff: noqa: C901, EM101, EM102, PLR0913, PLR2004, TRY003

from __future__ import annotations

from collections import Counter
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from . import table_contracts as _table_contracts
from .identity import canonical_sha256

PdfTableStructurePageReference = _table_contracts.PdfTableStructurePageReference

PDF_TABLE_DOCUMENT_MANIFEST_VERSION = "document_sdk_pdf_table_document_manifest.v1"
PDF_TABLE_ALGORITHM_DESIGN_VERSION = "document_sdk.pdf.phase3.table.algorithm_design.v3"
_DOCUMENT_IDENTITY_DOMAIN = "document_sdk.pdf.phase3.document_table.document.v1"
_PAGE_SEQUENCE_DOMAIN = "document_sdk.pdf.phase3.table.page_sequence.v1"
_TABLE_ORDER_DOMAIN = "document_sdk.pdf.phase3.table.order.v1"
_DOCUMENT_MANIFEST_DOMAIN = "document_sdk.pdf.phase3.table.document_manifest.v1"


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)


class PdfTableOutcomeSummary(_FrozenModel):
    physical_page_count: int = Field(ge=0)
    complete: int = Field(ge=0)
    partial: int = Field(ge=0)
    ambiguous: int = Field(ge=0)
    no_table: int = Field(ge=0)
    unsupported: int = Field(ge=0)
    unavailable: int = Field(ge=0)
    image_only_ocr_required: int = Field(ge=0)
    legacy_encoding_unreliable: int = Field(ge=0)

    @model_validator(mode="after")
    def validate_total(self) -> PdfTableOutcomeSummary:
        if self.physical_page_count != sum(
            getattr(self, name)
            for name in (
                "complete",
                "partial",
                "ambiguous",
                "no_table",
                "unsupported",
                "unavailable",
                "image_only_ocr_required",
                "legacy_encoding_unreliable",
            )
        ):
            raise ValueError("table outcome summary does not account every page")
        return self


def build_document_identity(
    *, source_sha256: str, page_table_manifest_sha256: str
) -> str:
    for value, label in (
        (source_sha256, "source SHA-256"),
        (page_table_manifest_sha256, "page Table manifest SHA-256"),
    ):
        if len(value) != 64 or any(
            character not in "0123456789abcdef" for character in value
        ):
            raise ValueError(f"{label} is invalid")
    return "P3D-document-" + canonical_sha256(
        {
            "domain": _DOCUMENT_IDENTITY_DOMAIN,
            "page_table_manifest_sha256": page_table_manifest_sha256,
            "source_sha256": source_sha256,
        }
    )


def _page_sequence_identity(
    page_references: tuple[PdfTableStructurePageReference, ...],
) -> str:
    return canonical_sha256(
        {
            "domain": _PAGE_SEQUENCE_DOMAIN,
            "pages": tuple(
                (
                    item.page_index,
                    item.page_id,
                    item.sidecar_id,
                    item.sidecar_sha256,
                    item.outcome,
                )
                for item in page_references
            ),
        }
    )


def _table_order_identity(
    page_references: tuple[PdfTableStructurePageReference, ...],
) -> str:
    return canonical_sha256(
        {
            "domain": _TABLE_ORDER_DOMAIN,
            "tables": tuple(
                (item.page_index, item.table_ids) for item in page_references
            ),
        }
    )


def _outcome_summary(
    page_references: tuple[PdfTableStructurePageReference, ...],
) -> PdfTableOutcomeSummary:
    counts = Counter(item.outcome for item in page_references)
    return PdfTableOutcomeSummary(
        physical_page_count=len(page_references),
        complete=counts["COMPLETE"],
        partial=counts["PARTIAL"],
        ambiguous=counts["AMBIGUOUS"],
        no_table=counts["NO_TABLE"],
        unsupported=counts["UNSUPPORTED"],
        unavailable=counts["UNAVAILABLE"],
        image_only_ocr_required=counts["IMAGE_ONLY_OCR_REQUIRED"],
        legacy_encoding_unreliable=counts["LEGACY_ENCODING_UNRELIABLE"],
    )


def _page_table_authority_sha256(
    *,
    source_sha256: str,
    reading_authority_id: str,
    reading_authority_sha256: str,
    page_references: tuple[PdfTableStructurePageReference, ...],
    page_sequence_identity: str,
    table_order_identity: str,
    outcome_summary: PdfTableOutcomeSummary,
    dependency_identity: str,
    configuration_identity: str,
    limitation_codes: tuple[str, ...],
) -> str:
    return canonical_sha256(
        {
            "configuration_identity": configuration_identity,
            "dependency_identity": dependency_identity,
            "domain": _DOCUMENT_MANIFEST_DOMAIN,
            "limitation_codes": limitation_codes,
            "outcome_summary": outcome_summary,
            "page_references": page_references,
            "page_sequence_identity": page_sequence_identity,
            "reading_authority_id": reading_authority_id,
            "reading_authority_sha256": reading_authority_sha256,
            "schema_version": PDF_TABLE_DOCUMENT_MANIFEST_VERSION,
            "source_sha256": source_sha256,
            "table_algorithm_design_version": (PDF_TABLE_ALGORITHM_DESIGN_VERSION),
            "table_order_identity": table_order_identity,
        }
    )


class PdfTableDocumentManifest(_FrozenModel):
    schema_version: Literal["document_sdk_pdf_table_document_manifest.v1"] = (
        PDF_TABLE_DOCUMENT_MANIFEST_VERSION  # type: ignore[assignment]
    )
    manifest_id: str = Field(pattern=r"^P3D-table-page-manifest-[0-9a-f]{64}$")
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_table_manifest_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    document_identity: str = Field(pattern=r"^P3D-document-[0-9a-f]{64}$")
    reading_authority_id: str = Field(pattern=r"^P3S-page-manifest-[0-9a-f]{64}$")
    reading_authority_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_references: tuple[PdfTableStructurePageReference, ...]
    page_sequence_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    table_order_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    outcome_summary: PdfTableOutcomeSummary
    dependency_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    configuration_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    table_algorithm_design_version: Literal[
        "document_sdk.pdf.phase3.table.algorithm_design.v3"
    ] = PDF_TABLE_ALGORITHM_DESIGN_VERSION  # type: ignore[assignment]
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_manifest(self) -> PdfTableDocumentManifest:
        indexes = tuple(item.page_index for item in self.page_references)
        if indexes != tuple(range(len(self.page_references))):
            raise ValueError("table manifest page sequence is noncanonical")
        page_ids = tuple(item.page_id for item in self.page_references)
        sidecar_ids = tuple(item.sidecar_id for item in self.page_references)
        table_ids = tuple(
            table_id for item in self.page_references for table_id in item.table_ids
        )
        if len(page_ids) != len(set(page_ids)):
            raise ValueError("table manifest repeats a physical Page identity")
        if len(sidecar_ids) != len(set(sidecar_ids)):
            raise ValueError("table manifest repeats a page Sidecar identity")
        if any(
            len(item.table_ids) != len(set(item.table_ids))
            for item in self.page_references
        ) or len(table_ids) != len(set(table_ids)):
            raise ValueError("table manifest repeats a page-local Table identity")
        if self.outcome_summary.physical_page_count != len(self.page_references):
            raise ValueError("table manifest page accounting mismatch")
        if self.page_sequence_identity != _page_sequence_identity(self.page_references):
            raise ValueError("table page-sequence identity mismatch")
        if self.table_order_identity != _table_order_identity(self.page_references):
            raise ValueError("table order identity mismatch")
        if self.outcome_summary != _outcome_summary(self.page_references):
            raise ValueError("table outcome counts mismatch")
        if self.limitation_codes != tuple(sorted(set(self.limitation_codes))):
            raise ValueError("table manifest limitations must be sorted and unique")
        expected_authority = _page_table_authority_sha256(
            source_sha256=self.source_sha256,
            reading_authority_id=self.reading_authority_id,
            reading_authority_sha256=self.reading_authority_sha256,
            page_references=self.page_references,
            page_sequence_identity=self.page_sequence_identity,
            table_order_identity=self.table_order_identity,
            outcome_summary=self.outcome_summary,
            dependency_identity=self.dependency_identity,
            configuration_identity=self.configuration_identity,
            limitation_codes=self.limitation_codes,
        )
        if self.page_table_manifest_sha256 != expected_authority:
            raise ValueError("page Table manifest authority mismatch")
        expected_document = build_document_identity(
            source_sha256=self.source_sha256,
            page_table_manifest_sha256=self.page_table_manifest_sha256,
        )
        if self.document_identity != expected_document:
            raise ValueError("document identity mismatch")
        expected_manifest = "P3D-table-page-manifest-" + canonical_sha256(
            {
                "domain": _DOCUMENT_MANIFEST_DOMAIN,
                "payload": self.model_dump(exclude={"manifest_id"}),
            }
        )
        if self.manifest_id != expected_manifest:
            raise ValueError("table document manifest identity mismatch")
        return self


def build_table_manifest(
    *,
    source_sha256: str,
    reading_authority_id: str,
    reading_authority_sha256: str,
    page_references: tuple[PdfTableStructurePageReference, ...],
    dependency_identity: str,
    configuration_identity: str,
    limitation_codes: tuple[str, ...] = (),
) -> PdfTableDocumentManifest:
    limitations = tuple(sorted(set(limitation_codes)))
    page_sequence = _page_sequence_identity(page_references)
    table_order = _table_order_identity(page_references)
    summary = _outcome_summary(page_references)
    page_table_manifest_sha256 = _page_table_authority_sha256(
        source_sha256=source_sha256,
        reading_authority_id=reading_authority_id,
        reading_authority_sha256=reading_authority_sha256,
        page_references=page_references,
        page_sequence_identity=page_sequence,
        table_order_identity=table_order,
        outcome_summary=summary,
        dependency_identity=dependency_identity,
        configuration_identity=configuration_identity,
        limitation_codes=limitations,
    )
    values = {
        "schema_version": PDF_TABLE_DOCUMENT_MANIFEST_VERSION,
        "source_sha256": source_sha256,
        "page_table_manifest_sha256": page_table_manifest_sha256,
        "document_identity": build_document_identity(
            source_sha256=source_sha256,
            page_table_manifest_sha256=page_table_manifest_sha256,
        ),
        "reading_authority_id": reading_authority_id,
        "reading_authority_sha256": reading_authority_sha256,
        "page_references": page_references,
        "page_sequence_identity": page_sequence,
        "table_order_identity": table_order,
        "outcome_summary": summary,
        "dependency_identity": dependency_identity,
        "configuration_identity": configuration_identity,
        "table_algorithm_design_version": PDF_TABLE_ALGORITHM_DESIGN_VERSION,
        "limitation_codes": limitations,
    }
    manifest_id = "P3D-table-page-manifest-" + canonical_sha256(
        {"domain": _DOCUMENT_MANIFEST_DOMAIN, "payload": values}
    )
    return PdfTableDocumentManifest.model_validate(
        {"manifest_id": manifest_id, **values}
    )


build_table_document_manifest = build_table_manifest

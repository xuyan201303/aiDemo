# ruff: noqa: C420, PLR0911, PLR2004, TC001

from __future__ import annotations

from collections import defaultdict

from document_sdk.pdf._structural_engine.facts.contracts import PdfBoundingBox
from document_sdk.pdf._structural_engine.layout.contracts import PdfLayoutNode

from .contracts import PDF_STRUCTURE_MODE, PdfReadingOrderEdge
from .identity import canonical_sha256

PHASE3B_ALGORITHM_VERSION = "3b.1"
PHASE3B_READING_ORDER_STRATEGY_VERSION = "evidence_graph.v1"
PHASE3B_BLOCK_STRATEGY_VERSION = "atomic_native_region.v1"
PHASE3B_HIERARCHY_STRATEGY_VERSION = "proven_order_levels.v1"


def phase3b_configuration_identity(
    *, parser_name: str, parser_version: str, safe_runtime_version: str
) -> str:
    return canonical_sha256(
        {
            "mode": PDF_STRUCTURE_MODE,
            "algorithm_version": PHASE3B_ALGORITHM_VERSION,
            "reading_order": PHASE3B_READING_ORDER_STRATEGY_VERSION,
            "blocks": PHASE3B_BLOCK_STRATEGY_VERSION,
            "hierarchy": PHASE3B_HIERARCHY_STRATEGY_VERSION,
            "parser_name": parser_name,
            "parser_version": parser_version,
            "safe_runtime_version": safe_runtime_version,
            "numeric_policy": "finite_fixed_six_decimals_negative_zero_to_zero",
        }
    )


def _union(nodes: tuple[PdfLayoutNode, ...]) -> PdfBoundingBox:
    return PdfBoundingBox(
        x0=min(n.bbox.x0 for n in nodes),
        y0=min(n.bbox.y0 for n in nodes),
        x1=max(n.bbox.x1 for n in nodes),
        y1=max(n.bbox.y1 for n in nodes),
    )


def _role(
    node: PdfLayoutNode,
    *,
    font_size: float | None,
    median_size: float,
    page_height: float,
    text: str,
) -> tuple[str, tuple[str, ...]]:
    top = node.bbox.y0 / page_height
    bottom = node.bbox.y1 / page_height
    if top <= 0.07 and node.geometry_quality == "precise":
        return "page_header_candidate", (
            "canonical_top_region",
            "native_text_parentage",
        )
    if bottom >= 0.93 and node.geometry_quality == "precise":
        return "page_footer_candidate", (
            "canonical_bottom_region",
            "native_text_parentage",
        )
    marker = text.lstrip()[:3]
    if (
        marker
        and (marker[0] in "•・●○▪-" or marker[:2].rstrip(".").isdigit())
        and node.bbox.x0 > 0
    ):
        return "list_item", ("exact_marker_syntax", "canonical_indentation")
    if font_size and median_size and font_size >= median_size * 1.18 and top < 0.9:
        return "heading_candidate", (
            "relative_typography",
            "page_region_position",
        )
    if bottom >= 0.86 and font_size and median_size and font_size <= median_size * 0.9:
        return "footnote_candidate", (
            "relative_typography",
            "canonical_bottom_region",
        )
    if node.node_type in {"line_candidate", "text_span"}:
        return "paragraph", (
            "native_text_parentage",
            "canonical_region_geometry",
        )
    return "generic_region", (
        "native_text_parentage",
        "canonical_region_geometry",
    )


def _topological(
    ids: tuple[str, ...], edges: tuple[PdfReadingOrderEdge, ...]
) -> tuple[tuple[str, ...], tuple[tuple[str, ...], ...]]:
    outgoing: dict[str, set[str]] = defaultdict(set)
    indegree = {item: 0 for item in ids}
    for edge in edges:
        if (
            edge.decision_status != "proven"
            or edge.successor_entity_id in outgoing[edge.predecessor_entity_id]
        ):
            continue
        outgoing[edge.predecessor_entity_id].add(edge.successor_entity_id)
        indegree[edge.successor_entity_id] += 1
    ready = sorted(item for item, count in indegree.items() if count == 0)
    ordered: list[str] = []
    while ready:
        current = ready.pop(0)
        ordered.append(current)
        for target in sorted(outgoing[current]):
            indegree[target] -= 1
            if indegree[target] == 0:
                ready.append(target)
                ready.sort()
    unresolved = tuple((item,) for item in sorted(set(ids) - set(ordered)))
    return tuple(ordered), unresolved

# ruff: noqa: ANN001, ANN202, B905, C408, C901, E731, EM101, F841, I001, PLR0911, PLR0912, PLR0913, PLR0915, PLR2004, RUF001, RUF007, SIM300, TC001, TRY003

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from hashlib import sha256
import math
from statistics import median
import re
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from collections.abc import Mapping

from document_sdk.pdf._structural_engine.facts.contracts import (
    PdfBoundingBox,
    PdfTextFact,
)
from document_sdk.pdf._structural_engine.layout.contracts import PdfLayoutNode

from .identity import canonical_sha256
from .reading_member_runs import exact_native_reading_run
from .reading_input import PdfReadingPageAuthority, PdfReadingPageEvidence
from .reading_contracts import (
    PdfHeadingHierarchyRelation,
    PdfHierarchyGraph,
    PdfPageReadingOrderGraph,
    PdfReadingOrderRelation,
    PdfReadingStructuralBlock,
    PdfReadingStructureComponentHashes,
    PdfReadingStructurePageSidecar,
    PdfReadingStructureProvenance,
    PdfStructuralTextFragment,
    reading_structure_identifier,
)


PHASE3B_READING_ALGORITHM_VERSION = "pdf_reading_structure.6.12"
PHASE3B_READING_OPERATION_VERSION = "pdf_reading_structure_safe_runtime.v1"


def phase3b_reading_configuration_identity() -> str:
    return canonical_sha256(
        {
            "contract": "pdf_reading_structure.v1",
            "algorithm": PHASE3B_READING_ALGORITHM_VERSION,
            "line_grouping": "physical_lines_exact_native_run.v12",
            "reading_order": "stable_regions_exact_native_run.v5",
            "heading": "relative_typography_isolation_numbering_typed_proof.v4",
            "hierarchy": "proven_heading_stack_flat_root_evidence.v4",
            "numeric_policy": "finite_fixed_six_decimals_negative_zero_to_zero",
            "ambiguity_policy": "fail_closed_review_required",
        }
    )


def _identified(model, field: str, kind: str, values: dict):  # type: ignore[no-untyped-def, type-arg]
    return model(**{field: reading_structure_identifier(kind, values), **values})


def _bbox_union(boxes: tuple[PdfBoundingBox, ...]) -> PdfBoundingBox:
    return PdfBoundingBox(
        x0=min(item.x0 for item in boxes),
        y0=min(item.y0 for item in boxes),
        x1=max(item.x1 for item in boxes),
        y1=max(item.y1 for item in boxes),
    )


def _fact_map(sidecar: PdfReadingPageEvidence) -> dict[str, object]:
    page = sidecar.payload.facts.page
    return {
        item.fact_id: item
        for collection in (page.text_spans, page.words, page.line_candidates)
        for item in collection
    }


def _exact_line_candidate_ids(
    *,
    lines: tuple[tuple[object, ...], ...],
    facts: Mapping[str, object],
    candidates: tuple[object, ...],
) -> tuple[str, ...]:
    result = []
    proven_line_count = 0
    candidate_by_id = {candidate.fact_id: candidate for candidate in candidates}  # type: ignore[attr-defined]

    def canonical_source_order(values: list[str]) -> tuple[str, ...]:
        return tuple(
            sorted(
                values,
                key=lambda fact_id: (
                    candidate_by_id[fact_id].source_order,  # type: ignore[attr-defined]
                    fact_id,
                ),
            )
        )

    for line in lines:
        box = _bbox_union(tuple(node.bbox for node in line))  # type: ignore[attr-defined]
        text = " ".join(facts[node.source_fact_id].text for node in line)  # type: ignore[attr-defined]
        matches = tuple(
            candidate
            for candidate in candidates
            if (candidate.bbox == box and candidate.text == text)  # type: ignore[attr-defined]
        )
        if len(matches) == 1:
            result.append(matches[0].fact_id)  # type: ignore[attr-defined]
            proven_line_count += 1
            continue
        partition = tuple(
            sorted(
                (
                    candidate
                    for candidate in candidates
                    if (
                        candidate.bbox.x0 >= box.x0  # type: ignore[attr-defined]
                        and candidate.bbox.x1 <= box.x1  # type: ignore[attr-defined]
                        and min(candidate.bbox.y1, box.y1)  # type: ignore[attr-defined]
                        - max(candidate.bbox.y0, box.y0)  # type: ignore[attr-defined]
                        >= min(candidate.bbox.y1 - candidate.bbox.y0, box.y1 - box.y0)  # type: ignore[attr-defined]
                        * 0.4
                    )
                ),
                key=lambda item: (
                    item.bbox.x0,  # type: ignore[attr-defined]
                    item.bbox.y0,  # type: ignore[attr-defined]
                    item.source_order,  # type: ignore[attr-defined]
                    item.fact_id,  # type: ignore[attr-defined]
                ),
            )
        )
        canonical_text = lambda value: "".join(value.split())
        if partition and canonical_text(  # type: ignore[no-untyped-call]
            "".join(candidate.text for candidate in partition)  # type: ignore[attr-defined]
        ) == canonical_text(text):  # type: ignore[no-untyped-call]
            result.extend(candidate.fact_id for candidate in partition)  # type: ignore[attr-defined]
            proven_line_count += 1
    if proven_line_count == len(lines):
        return canonical_source_order(result)

    # Parser-authoritative line candidates may span more than one visual
    # baseline (for example, a drop cap). If the derived line partition cannot
    # prove every unit, retry only at the immutable block boundary. Acceptance
    # still requires exact geometry containment, canonical source order and
    # complete normalized text equality.
    block_box = _bbox_union(tuple(node.bbox for line in lines for node in line))  # type: ignore[attr-defined]
    bounded = tuple(
        sorted(
            (
                candidate
                for candidate in candidates
                if (
                    block_box.x0
                    <= (candidate.bbox.x0 + candidate.bbox.x1) / 2  # type: ignore[attr-defined]
                    <= block_box.x1
                    and block_box.y0
                    <= (candidate.bbox.y0 + candidate.bbox.y1) / 2  # type: ignore[attr-defined]
                    <= block_box.y1
                )
            ),
            key=lambda item: (item.source_order, item.fact_id),  # type: ignore[attr-defined]
        )
    )
    ordered_nodes = tuple(
        sorted(
            (node for line in lines for node in line),
            key=lambda item: (
                getattr(item, "source_order", 0),
                getattr(item, "node_id", ""),
            ),
        )
    )
    canonical_text = lambda value: "".join(value.split())
    if bounded and canonical_text(  # type: ignore[no-untyped-call]
        "".join(candidate.text for candidate in bounded)  # type: ignore[attr-defined]
    ) == canonical_text(  # type: ignore[no-untyped-call]
        "".join(facts[node.source_fact_id].text for node in ordered_nodes)  # type: ignore[attr-defined]
    ):
        return tuple(candidate.fact_id for candidate in bounded)  # type: ignore[attr-defined]
    return tuple(result)


def _font_size(fact: object) -> float | None:
    return getattr(fact, "effective_font_size_y", None) or getattr(
        fact, "font_size", None
    )


def _font_is_emphasized(fact: object) -> bool:
    name = (getattr(fact, "font_name", "") or "").lower()
    return any(
        token in name
        for token in (
            "bold",
            "semibold",
            "demi",
            "medium",
            "-medi",
            "black",
            "-blk",
            "-md",
            "-bd",
        )
    )


def _font_is_italic(fact: object) -> bool:
    name = (getattr(fact, "font_name", "") or "").lower()
    return "italic" in name or "oblique" in name


@dataclass(frozen=True)
class ParagraphContinuationDecision:
    decision: str
    continuation_evidence: tuple[str, ...]
    boundary_evidence: tuple[str, ...]
    vertical_gap: float
    local_leading_gaps: tuple[float, ...]


def _font_family(fact: object) -> str:
    name = (getattr(fact, "font_name", "") or "").lower()
    name = name.split("+", 1)[-1]
    return re.sub(
        r"(?:bold|semibold|demi|medium|black|italic|oblique|regular|roman|"
        r"-medi|-blk|-md|-bd|mt)",
        "",
        name,
    ).strip("-_ ")


def _line_typography(
    line: tuple[object, ...],
    facts: Mapping[str, object],
) -> tuple[str, float, bool, bool, int, str]:
    dominant = max(
        line,
        key=lambda node: (
            node.bbox.x1 - node.bbox.x0,  # type: ignore[attr-defined]
            -(getattr(node, "source_order", 0)),
            getattr(node, "node_id", ""),
        ),
    )
    fact = facts[dominant.source_fact_id]  # type: ignore[attr-defined]
    size = _font_size(fact) or (dominant.bbox.y1 - dominant.bbox.y0)  # type: ignore[attr-defined]
    return (
        _font_family(fact),
        round(float(size), 6),
        sum(_font_is_emphasized(facts[node.source_fact_id]) for node in line) * 2  # type: ignore[attr-defined]
        >= len(line),
        sum(_font_is_italic(facts[node.source_fact_id]) for node in line) * 2  # type: ignore[attr-defined]
        >= len(line),
        int(getattr(fact, "rotation", 0) or 0),
        str(getattr(fact, "writing_direction", "") or "unknown"),
    )


def _line_typography_family_set(
    line: tuple[object, ...],
    facts: Mapping[str, object],
) -> tuple[str, ...]:
    return tuple(sorted({_font_family(facts[node.source_fact_id]) for node in line}))  # type: ignore[attr-defined]


def _line_size_axis(
    line: tuple[object, ...],
    facts: Mapping[str, object],
) -> tuple[float, int, str]:
    typography = _line_typography(line, facts)
    return typography[1], typography[4], typography[5]


def _typography_compatible(
    previous: tuple[str, float, bool, bool, int, str],
    current: tuple[str, float, bool, bool, int, str],
) -> bool:
    previous_size = previous[1]
    current_size = current[1]
    size_ratio = abs(previous_size - current_size) / max(
        previous_size,
        current_size,
        1e-9,
    )
    return (
        previous[0] == current[0] and size_ratio <= 0.08 and previous[2:] == current[2:]
    )


def _paragraph_typography_compatible(
    previous_line: tuple[object, ...],
    current_line: tuple[object, ...],
    *,
    facts: dict[str, object],
    accepted_families: tuple[str, ...] = (),
    allow_open_short_fragment: bool = False,
) -> bool:
    """Allow bounded inline fragments without erasing structural style changes."""
    previous = _line_typography(previous_line, facts)
    current = _line_typography(current_line, facts)
    if _typography_compatible(previous, current):
        return True
    previous_families = set(_line_typography_family_set(previous_line, facts))
    current_families = set(_line_typography_family_set(current_line, facts))
    if len(previous_families) > 1 and len(current_families) == 1:
        # A mixed inline-fragment line may continue back to the paragraph base
        # family, but it must not become a bridge that silently migrates the
        # paragraph anchor to the inline fragment's family.
        accepted = set(accepted_families)
        if (
            current[0] != previous[0]
            and current[0] not in accepted
            and not (allow_open_short_fragment and current[0] in previous_families)
        ):
            return False
    same_family_size_axis = (
        previous[0] == current[0]
        and abs(previous[1] - current[1]) / max(previous[1], current[1], 1e-9) <= 0.08
        and previous[3:] == current[3:]
    )
    if not same_family_size_axis:
        previous_size, previous_rotation, previous_direction = _line_size_axis(
            previous_line,
            facts,
        )
        current_size, current_rotation, current_direction = _line_size_axis(
            current_line,
            facts,
        )
        size_ratio = abs(previous_size - current_size) / max(
            previous_size,
            current_size,
            1e-9,
        )
        same_size_axis = (
            size_ratio <= 0.08
            and previous_rotation == current_rotation
            and previous_direction == current_direction
        )
        inline_family_bridge = (
            same_size_axis
            and bool(previous_families & current_families)
            and (len(previous_families) > 1 or len(current_families) > 1)
        )
        if not inline_family_bridge:
            return False
    previous_emphasis = {
        _font_is_emphasized(facts[node.source_fact_id])  # type: ignore[attr-defined]
        for node in previous_line
    }
    current_emphasis = {
        _font_is_emphasized(facts[node.source_fact_id])  # type: ignore[attr-defined]
        for node in current_line
    }
    return (
        len(previous_emphasis) > 1
        or len(current_emphasis) > 1
        or len(_line_typography_family_set(previous_line, facts)) > 1
        or len(_line_typography_family_set(current_line, facts)) > 1
    )


def _line_text(
    line: tuple[object, ...],
    facts: Mapping[str, object],
) -> str:
    return " ".join(facts[node.source_fact_id].text for node in line).strip()  # type: ignore[attr-defined]


def _terminal_text_flow(text: str) -> bool:
    return re.search(r"[.!?。！？:：;；][\"'’”）)]*$", text.strip()) is not None


def _entry_anchor_label(text: str) -> str | None:
    match = re.match(
        r"^\s*([A-Za-z][A-Za-z][A-Za-z .&/-]{0,30}?)\s+"
        r"(?:[A-Z]?\d+(?:[-.]\d+)*|[IVXLCDM]+|[A-Z])\s*[:：]\s+",
        text.strip(),
    )
    if match is None:
        return None
    return re.sub(r"\s+", " ", match.group(1).strip().lower())


def _entry_body_is_self_contained(text: str) -> bool:
    match = re.match(
        r"^\s*[A-Za-z][A-Za-z][A-Za-z .&/-]{0,30}?\s+"
        r"(?:[A-Z]?\d+(?:[-.]\d+)*|[IVXLCDM]+|[A-Z])\s*[:：]\s+(.+)$",
        text.strip(),
    )
    if match is None:
        return False
    body = match.group(1).strip()
    return bool(body) and re.match(r"^[A-Z0-9（(]", body) is not None


def _repeated_entry_reset_boundary(
    previous_text: str,
    current_text: str,
    previous: PdfBoundingBox,
    current: PdfBoundingBox,
    *,
    page_width: float,
) -> bool:
    previous_label = _entry_anchor_label(previous_text)
    current_label = _entry_anchor_label(current_text)
    return (
        previous_label is not None
        and previous_label == current_label
        and _entry_body_is_self_contained(previous_text)
        and _entry_body_is_self_contained(current_text)
        and _terminal_text_flow(previous_text)
        and abs(current.x0 - previous.x0) <= page_width * 0.025
    )


def _hard_boundary_blocks_special_continuation(
    boundary_signals: tuple[str, ...],
) -> bool:
    return "repeated_entry_reset" in boundary_signals


def _aligned_flow(
    previous: PdfBoundingBox,
    current: PdfBoundingBox,
    *,
    page_width: float,
    previous_line_anchor_x0s: tuple[float, ...] = (),
) -> tuple[bool, bool, bool]:
    aligned = abs(current.x0 - previous.x0) <= page_width * 0.025
    centered = (
        abs((current.x0 + current.x1) / 2 - (previous.x0 + previous.x1) / 2)
        <= page_width * 0.025
    )
    hanging_indent = any(
        abs(current.x0 - anchor) <= page_width * 0.025
        for anchor in previous_line_anchor_x0s
    )
    return aligned, centered, hanging_indent


def _local_leading_modes(
    column: tuple[tuple[object, ...], ...],
    *,
    facts: dict[str, object],
    median_height: float,
    page_width: float,
) -> dict[tuple[str, float, bool, bool, int, str], tuple[float, ...]]:
    """Return stable, typography-bound local leading modes for one text flow."""
    if len(column) < 3:
        return {}
    boxes = tuple(_bbox_union(tuple(node.bbox for node in line)) for line in column)  # type: ignore[attr-defined]
    flow_width = max(box.x1 for box in boxes) - min(box.x0 for box in boxes)
    samples: dict[tuple[str, float, bool, bool, int, str], list[float]] = defaultdict(
        list
    )
    for previous_line, current_line, previous_box, current_box in zip(
        column,
        column[1:],
        boxes,
        boxes[1:],
    ):
        previous_typography = _line_typography(previous_line, facts)
        current_typography = _line_typography(current_line, facts)
        if not _paragraph_typography_compatible(
            previous_line,
            current_line,
            facts=facts,
        ):
            continue
        aligned, centered, hanging = _aligned_flow(
            previous_box,
            current_box,
            page_width=page_width,
            previous_line_anchor_x0s=tuple(node.bbox.x0 for node in previous_line),  # type: ignore[attr-defined]
        )
        if not (aligned or centered or hanging):
            continue
        previous_text = _line_text(previous_line, facts)
        current_text = _line_text(current_line, facts)
        if (
            _starts_list_item(current_text)
            or _is_explicit_caption(previous_text)
            or _is_explicit_caption(current_text)
            or _starts_hierarchical_heading(current_text)
            or _repeated_entry_reset_boundary(
                previous_text,
                current_text,
                previous_box,
                current_box,
                page_width=page_width,
            )
        ):
            continue
        previous_width = previous_box.x1 - previous_box.x0
        if _terminal_text_flow(previous_text) and previous_width < flow_width * 0.72:
            continue
        gap = current_box.y0 - previous_box.y1
        if -median_height * 0.15 <= gap <= median_height * 1.5:
            samples[previous_typography].append(gap)

    modes = {}
    cluster_tolerance = median_height * 0.08
    for typography, values in samples.items():
        clusters: list[list[float]] = []
        for value in sorted(values):
            if not clusters or value - median(clusters[-1]) > cluster_tolerance:
                clusters.append([value])
            else:
                clusters[-1].append(value)
        stable = sorted(
            (cluster for cluster in clusters if len(cluster) >= 2),
            key=lambda cluster: (-len(cluster), median(cluster)),
        )
        if stable:
            primary = float(median(stable[0]))
            same_leading_family = tuple(
                float(median(cluster))
                for cluster in stable
                if abs(float(median(cluster)) - primary) <= median_height * 0.25
            )
            modes[typography] = tuple(sorted(same_leading_family))
    return modes


def _paragraph_continuation_decision(
    previous: PdfBoundingBox,
    current: PdfBoundingBox,
    *,
    median_height: float,
    page_width: float,
    previous_line_anchor_x0s: tuple[float, ...] = (),
    local_leading_gaps: tuple[float, ...] = (),
    typography_compatible: bool = True,
    orientation_compatible: bool = True,
    previous_text: str = "",
    current_text: str = "",
    flow_width: float | None = None,
    flow_x0: float | None = None,
    boundary_signals: tuple[str, ...] = (),
    list_marker_is_boundary: bool | None = None,
) -> ParagraphContinuationDecision:
    """Resolve adjacent-line continuation from typed local physical evidence."""
    gap = current.y0 - previous.y1
    aligned, centered, hanging = _aligned_flow(
        previous,
        current,
        page_width=page_width,
        previous_line_anchor_x0s=previous_line_anchor_x0s,
    )
    continuation = []
    boundary = list(boundary_signals)
    if aligned:
        continuation.append("left_edge_continuity")
    elif centered:
        continuation.append("center_alignment_continuity")
    elif hanging:
        continuation.append("hanging_indent_continuity")
    else:
        boundary.append("indentation_or_alignment_jump")
    if orientation_compatible:
        continuation.append("orientation_and_writing_direction_continuity")
    else:
        boundary.append("orientation_or_writing_direction_transition")
    if typography_compatible:
        continuation.append("typography_continuity")
    else:
        boundary.append("typography_transition")

    effective_flow_width = flow_width or page_width
    previous_width = previous.x1 - previous.x0
    terminal = _terminal_text_flow(previous_text)
    reset = flow_x0 is not None and abs(current.x0 - flow_x0) <= page_width * 0.025
    if not terminal or previous_width >= effective_flow_width * 0.72:
        continuation.append("open_or_full_line_text_flow")
    elif reset:
        boundary.append("short_terminal_line_followed_by_reset")
    if (
        _starts_list_item(current_text)
        if list_marker_is_boundary is None
        else list_marker_is_boundary
    ):
        boundary.append("list_marker_transition")
    if _is_explicit_caption(current_text):
        boundary.append("caption_transition")

    local_tolerance = median_height * 0.12
    local_jump = median_height * 0.18
    if local_leading_gaps:
        if any(abs(gap - mode) <= local_tolerance for mode in local_leading_gaps):
            continuation.append("stable_local_leading")
        elif gap >= max(local_leading_gaps) + local_jump:
            boundary.append("local_leading_cluster_jump")
        else:
            boundary.append("ambiguous_local_leading")
    elif -median_height * 0.15 <= gap <= median_height * 0.70:
        continuation.append("bounded_legacy_gap_fallback")
    else:
        boundary.append("gap_outside_bounded_fallback")

    hard_boundary = (
        bool(boundary_signals)
        or not orientation_compatible
        or not (aligned or centered or hanging)
    )
    leading_proven = (
        "stable_local_leading" in continuation
        or "bounded_legacy_gap_fallback" in continuation
    )
    boundary_wins = (
        hard_boundary
        or "local_leading_cluster_jump" in boundary
        or "short_terminal_line_followed_by_reset" in boundary
        or "list_marker_transition" in boundary
        or "caption_transition" in boundary
        or "ambiguous_local_leading" in boundary
        or not typography_compatible
    )
    decision = (
        "continue"
        if leading_proven and not boundary_wins and len(continuation) >= 4
        else "boundary"
    )
    return ParagraphContinuationDecision(
        decision=decision,
        continuation_evidence=tuple(sorted(set(continuation))),
        boundary_evidence=tuple(sorted(set(boundary))),
        vertical_gap=gap,
        local_leading_gaps=tuple(sorted(local_leading_gaps)),
    )


def _is_explicit_caption(text: str) -> bool:
    stripped = text.strip()
    appendix_identifier = r"(?:\d+(?:[-.]\d+)*|[A-Z](?:-?\d+)?)"
    return any(
        re.match(pattern, stripped, re.IGNORECASE) is not None
        for pattern in (
            rf"^Figure\s+{appendix_identifier}(?=$|[.:：](?:\s|$))",
            r"^Fig\.\s*\d+(?:[-.]\d+)*(?=$|\s|[.:：])",
            r"^(?:図|写真)\s*\d+(?:[-.]\d+)*(?=$|\s|[.:：])",
        )
    )


def _can_continue_explicit_caption(
    anchor_line: tuple[object, ...],
    current_line: tuple[object, ...],
    *,
    facts: Mapping[str, object],
    median_height: float,
    page_width: float,
    previous_line: tuple[object, ...] | None = None,
) -> bool:
    """Prove the next physical line in an active explicit-caption flow."""
    anchor_text = _line_text(anchor_line, facts)
    current_text = _line_text(current_line, facts)
    anchor_box = _bbox_union(tuple(node.bbox for node in anchor_line))  # type: ignore[attr-defined]
    previous = previous_line or anchor_line
    previous_text = _line_text(previous, facts)
    previous_box = _bbox_union(tuple(node.bbox for node in previous))  # type: ignore[attr-defined]
    current_box = _bbox_union(tuple(node.bbox for node in current_line))  # type: ignore[attr-defined]
    if not _is_explicit_caption(anchor_text):
        return False
    if (
        _is_explicit_caption(current_text)
        or _starts_list_item(current_text)
        or _starts_hierarchical_heading(current_text)
        or _is_narrow_decimal_section_heading(
            current_text,
            current_box,
            page_width,
        )
        or _is_narrow_numbered_part_heading(
            current_text,
            current_box,
            page_width,
        )
    ):
        return False
    if anchor_box.x1 - anchor_box.x0 < page_width * 0.55:
        return False
    aligned, centered, hanging = _aligned_flow(
        previous_box,
        current_box,
        page_width=page_width,
        previous_line_anchor_x0s=tuple(node.bbox.x0 for node in anchor_line + previous),  # type: ignore[attr-defined]
    )
    anchor_aligned = abs(current_box.x0 - anchor_box.x0) <= page_width * 0.025
    previous_width = previous_box.x1 - previous_box.x0
    anchor_width = anchor_box.x1 - anchor_box.x0
    current_width = current_box.x1 - current_box.x0
    paragraph_reset = (
        _terminal_text_flow(previous_text)
        and previous_width < anchor_width * 0.72
        and current_width >= anchor_width * 0.72
        and anchor_aligned
    )
    return (
        _typography_compatible(
            _line_typography(previous, facts),
            _line_typography(current_line, facts),
        )
        and (aligned or centered or hanging)
        and not paragraph_reset
        and -median_height * 0.15 <= current_box.y0 - previous_box.y1 <= median_height
    )


def _stable_columns(
    lines: tuple[tuple[object, ...], ...],
    page_width: float,
    page_height: float,
) -> tuple[tuple[tuple[object, ...], ...], ...]:
    if len(lines) < 2:
        return (lines,)
    wide = tuple(
        line
        for line in lines
        if (
            _bbox_union(tuple(item.bbox for item in line)).x1  # type: ignore[attr-defined]
            - _bbox_union(tuple(item.bbox for item in line)).x0  # type: ignore[attr-defined]
        )
        >= page_width * 0.65
        and 0.055 < (_bbox_union(tuple(item.bbox for item in line)).y0 / page_height)  # type: ignore[attr-defined]
        and (_bbox_union(tuple(item.bbox for item in line)).y1 / page_height) < 0.88  # type: ignore[attr-defined]
    )
    body = tuple(line for line in lines if line not in wide)
    if len(body) < 2:
        return (
            tuple(
                sorted(
                    lines,
                    key=lambda line: (
                        _bbox_union(tuple(item.bbox for item in line)).y0,  # type: ignore[attr-defined]
                        _bbox_union(tuple(item.bbox for item in line)).x0,  # type: ignore[attr-defined]
                    ),
                )
            ),
        )
    ordered = sorted(
        body,
        key=lambda line: (
            _bbox_union(tuple(item.bbox for item in line)).x0,  # type: ignore[attr-defined]
            _bbox_union(tuple(item.bbox for item in line)).y0,  # type: ignore[attr-defined]
        ),
    )
    groups: list[list[tuple[object, ...]]] = []
    tolerance = page_width * 0.08
    for line in ordered:
        x0 = _bbox_union(tuple(item.bbox for item in line)).x0  # type: ignore[attr-defined]
        if (
            not groups
            or abs(
                x0
                - median(
                    _bbox_union(tuple(item.bbox for item in prior)).x0  # type: ignore[attr-defined]
                    for prior in groups[-1]
                )
            )
            > tolerance
        ):
            groups.append([line])
        else:
            groups[-1].append(line)
    if len(groups) <= 1:
        return (
            tuple(
                sorted(
                    lines,
                    key=lambda line: (
                        _bbox_union(tuple(item.bbox for item in line)).y0,  # type: ignore[attr-defined]
                        _bbox_union(tuple(item.bbox for item in line)).x0,  # type: ignore[attr-defined]
                    ),
                )
            ),
        )
    if wide:
        # Mixed full-width and multi-column bands require region segmentation;
        # preserve deterministic page-axis order and let downstream state remain
        # review-required rather than forcing a column transition.
        return (
            tuple(
                sorted(
                    lines,
                    key=lambda line: (
                        _bbox_union(tuple(item.bbox for item in line)).y0,  # type: ignore[attr-defined]
                        _bbox_union(tuple(item.bbox for item in line)).x0,  # type: ignore[attr-defined]
                    ),
                )
            ),
        )
    ranges = tuple(
        (
            min(_bbox_union(tuple(item.bbox for item in line)).x0 for line in group),  # type: ignore[attr-defined]
            max(_bbox_union(tuple(item.bbox for item in line)).x1 for line in group),  # type: ignore[attr-defined]
        )
        for group in groups
    )
    if any(left[1] > right[0] + tolerance for left, right in zip(ranges, ranges[1:])):
        return (
            tuple(
                sorted(
                    lines,
                    key=lambda line: (
                        _bbox_union(tuple(item.bbox for item in line)).y0,  # type: ignore[attr-defined]
                        _bbox_union(tuple(item.bbox for item in line)).x0,  # type: ignore[attr-defined]
                    ),
                )
            ),
        )
    result: list[tuple[tuple[object, ...], ...]] = []
    result.extend(
        tuple(
            sorted(
                group,
                key=lambda line: (
                    _bbox_union(tuple(item.bbox for item in line)).y0,  # type: ignore[attr-defined]
                    _bbox_union(tuple(item.bbox for item in line)).x0,  # type: ignore[attr-defined]
                ),
            )
        )
        for group in groups
    )
    return tuple(result)


def _role(
    *,
    text: str,
    bbox: PdfBoundingBox,
    page_height: float,
    page_width: float,
    size: float | None,
    median_size: float,
    bold_ratio: float,
    vertically_isolated: bool = False,
    italic_ratio: float = 0.0,
    followed_by_list: bool = False,
    physical_line_count: int = 1,
) -> tuple[str, str, tuple[str, ...], int | None]:
    stripped = text.strip()
    top = bbox.y0 / page_height
    bottom = bbox.y1 / page_height
    if bottom >= 0.88 and _is_compact_page_number(stripped):
        return "page_number", "proven", ("bottom_region", "exact_numeric_pattern"), None
    if top <= 0.055:
        return "header", "candidate", ("top_region",), None
    marginal = _multisignal_marginal_role(
        text=stripped,
        bbox=bbox,
        page_height=page_height,
        page_width=page_width,
        size=size,
        median_size=median_size,
        italic_ratio=italic_ratio,
    )
    if marginal is not None:
        role, evidence = marginal
        return role, "proven", evidence, None
    if bottom >= 0.945:
        return "footer", "candidate", ("bottom_region",), None
    hierarchical_level = _hierarchical_heading_level(stripped)
    if hierarchical_level is not None:
        return (
            "heading",
            "proven",
            (
                "exact_hierarchical_signature",
                "isolated_structural_line",
            ),
            hierarchical_level,
        )
    if _is_narrow_numbered_part_heading(stripped, bbox, page_width):
        return (
            "heading",
            "proven",
            (
                "exact_numbered_part_signature",
                "narrow_structural_line",
            ),
            1,
        )
    if _is_narrow_decimal_section_heading(stripped, bbox, page_width):
        section = re.match(
            r"^([0-9０-９]+(?:[.．][0-9０-９]+)+)",
            stripped,
        )
        return (
            "heading",
            "proven",
            (
                "exact_decimal_section_signature",
                "narrow_structural_line",
            ),
            len(re.split(r"[.．]", section.group(1))),  # type: ignore[union-attr]
        )
    if bold_ratio >= 0.8 and _is_hyphenated_section_heading(stripped):
        return (
            "heading",
            "proven",
            (
                "exact_bold_font_lineage",
                "exact_hyphenated_section_signature",
            ),
            None,
        )
    if italic_ratio >= 0.8 and followed_by_list and len(stripped) <= 180:
        return (
            "heading",
            "proven",
            (
                "exact_italic_font_lineage",
                "exact_list_transition",
                "isolated_short_line",
            ),
            None,
        )
    if _is_explicit_caption(stripped) and bold_ratio < 0.8:
        return (
            "caption",
            "proven",
            (
                "exact_caption_marker",
                "exact_line_membership",
            ),
            None,
        )
    numbered = re.match(r"^(\d+(?:\.\d+){0,5})[.\s　]", stripped)
    centered = abs((bbox.x0 + bbox.x1) / 2 - page_width / 2) <= page_width * 0.08
    prominent_top_multiline_title = (
        top <= 0.18
        and size
        and median_size
        and size >= median_size * 1.35
        and physical_line_count >= 2
        and bold_ratio >= 0.8
        and len(stripped) <= 220
    )
    if prominent_top_multiline_title or (
        size
        and median_size
        and size >= median_size * 1.35
        and centered
        and len(stripped) <= 220
    ):
        return (
            "title",
            "proven",
            (
                "relative_glyph_height",
                "center_alignment",
                "isolated_short_line",
            ),
            None,
        )
    if (
        ((size and median_size and size >= median_size * 1.18) or bold_ratio >= 0.8)
        and len(stripped) <= 180
        and (
            numbered is not None
            or stripped.endswith(":")
            or (size and median_size and size >= median_size * 1.25)
        )
    ):
        level = len(numbered.group(1).split(".")) if numbered else None
        return (
            "heading",
            "proven",
            (
                *(("exact_bold_font_lineage",) if bold_ratio >= 0.8 else ()),
                "relative_glyph_height",
                "isolated_short_line",
                *(("exact_numbering_pattern",) if numbered else ()),
            ),
            level,
        )
    if bold_ratio >= 0.8 and vertically_isolated and len(stripped) <= 180:
        return (
            "heading",
            "proven",
            (
                "exact_bold_font_lineage",
                "vertical_block_isolation",
                "isolated_short_line",
            ),
            None,
        )
    if _starts_list_item(stripped) and bold_ratio < 0.8:
        return "list_item", "proven", ("exact_list_marker", "indentation"), None
    if size and median_size and size >= median_size * 1.12 and len(stripped) <= 140:
        return "heading", "candidate", ("relative_font_size", "short_line"), None
    if bottom >= 0.86 and size and median_size and size <= median_size * 0.88:
        return "footnote", "candidate", ("small_type", "bottom_region"), None
    return "paragraph", "proven", ("native_line_parentage", "line_continuity"), None


def _affine_number_equal(left: float, right: float) -> bool:
    """Allow arithmetic roundoff only; never increase a geometry tolerance."""
    epsilon = max(math.ulp(left), math.ulp(right), math.ulp(1.0)) * 32
    return epsilon <= 1e-9 and abs(left - right) <= epsilon


def _single_source_affine_baseline(
    nodes: tuple[object, ...], *, facts: dict[str, object]
) -> tuple[object, ...] | None:
    """Use an exact native baseline for one complete, nonvertical text flow.

    Canonical page y cannot order a slanted line. This narrow route requires
    every primary node on the page to have the same native affine basis and
    baseline, matching precise Fact geometry, nonoverlapping along-axis bounds,
    and an ordinary within-line gap. Multiple lines, mixed directions, vertical
    text, source overlap and uncertain geometry retain the existing partition.
    Original bboxes/text are never transformed or replaced. This establishes
    local fragment order, not original whitespace or a semantic document role.
    """
    if len(nodes) < 2:
        return None
    entries: list[tuple[PdfLayoutNode, PdfTextFact]] = []
    for node in nodes:
        if not isinstance(node, PdfLayoutNode):
            return None
        fact = facts.get(node.source_fact_id)
        if (
            not isinstance(fact, PdfTextFact)
            or node.geometry_quality != "precise"
            or node.source_page_id != fact.page_id
            or node.bbox != fact.bbox
            or node.rotation != fact.rotation
            or node.source_order != fact.source_order
            or node.bbox.x1 <= node.bbox.x0
            or node.bbox.y1 <= node.bbox.y0
            or fact.text_transform is None
            or fact.rotation is None
            or fact.rotation == 0
        ):
            return None
        entries.append((node, fact))
    if len({node.node_id for node, _ in entries}) != len(entries) or len(
        {fact.fact_id for _, fact in entries}
    ) != len(entries):
        return None
    first = entries[0][1]
    basis = first.text_transform
    if basis is None:
        return None
    # Limit the route to a forward, horizontally dominated baseline. Native
    # vertical font direction is not inferred from rotation or font names.
    if (
        not all(
            math.isfinite(value)
            for value in (basis.a, basis.b, basis.c, basis.d, basis.e, basis.f)
        )
        or basis.a <= 0
        or basis.b == 0
        or abs(basis.b) >= basis.a
        or basis.a * basis.d - basis.b * basis.c <= 0
    ):
        return None
    matrix_rotation = (-math.degrees(math.atan2(basis.b, basis.a))) % 360
    if first.rotation is None or not _affine_number_equal(
        first.rotation, matrix_rotation
    ):
        return None
    norm = math.hypot(basis.a, basis.b)
    ux, uy = basis.a / norm, -basis.b / norm
    offsets = []
    for node, fact in entries:
        matrix = fact.text_transform
        if matrix is None:
            return None
        if (
            fact.page_id != first.page_id
            or fact.rotation != first.rotation
            or (matrix.a, matrix.b, matrix.c, matrix.d)
            != (basis.a, basis.b, basis.c, basis.d)
        ):
            return None
        # Native matrices use parser bottom-left coordinates. Compare origin
        # displacement, avoiding page-box translations and guessed glyph ink.
        cross_x = (matrix.e - basis.e) * basis.b
        cross_y = (matrix.f - basis.f) * basis.a
        if not _affine_number_equal(cross_x, cross_y):
            return None
        along = (matrix.e - basis.e) * ux - (matrix.f - basis.f) * uy
        box = node.bbox
        projected = tuple(
            x * ux + y * uy for x in (box.x0, box.x1) for y in (box.y0, box.y1)
        )
        normal = tuple(
            -x * uy + y * ux for x in (box.x0, box.x1) for y in (box.y0, box.y1)
        )
        offsets.append(
            (along, min(projected), max(projected), max(normal) - min(normal), node)
        )
    offsets.sort(key=lambda item: item[0])
    for left, right in zip(offsets, offsets[1:]):
        gap = right[1] - left[2]
        if right[0] <= left[0] or gap < 0 or gap > min(left[3], right[3]) * 1.25:
            return None
    return tuple(item[4] for item in offsets)


def _physical_lines(
    nodes: tuple[object, ...],
    *,
    page_width: float,
    limitation_codes: set[str] | None = None,
) -> tuple[tuple[object, ...], ...]:
    lines: list[list[object]] = []
    for node in sorted(
        nodes,
        key=lambda item: (
            (item.bbox.y0 + item.bbox.y1) / 2,  # type: ignore[attr-defined]
            item.bbox.x0,  # type: ignore[attr-defined]
            item.node_id,  # type: ignore[attr-defined]
        ),
    ):
        match = None
        for line in reversed(lines[-3:]):
            box = _bbox_union(tuple(item.bbox for item in line))  # type: ignore[attr-defined]
            overlap = min(box.y1, node.bbox.y1) - max(box.y0, node.bbox.y0)  # type: ignore[attr-defined]
            local_height = min(
                box.y1 - box.y0,
                node.bbox.y1 - node.bbox.y0,  # type: ignore[attr-defined]
            )
            if overlap >= local_height * 0.55:
                match = line
                break
        if match is None:
            lines.append([node])
        else:
            match.append(node)
    ordered_lines = tuple(
        tuple(
            sorted(
                line,
                key=lambda item: (item.bbox.x0, item.source_order, item.node_id),  # type: ignore[attr-defined]
            )
        )
        for line in lines
    )
    gutter_samples: list[tuple[float, bool, int, int]] = []
    for ordered in ordered_lines:
        for left, right in zip(ordered, ordered[1:]):
            local_height = min(
                left.bbox.y1 - left.bbox.y0,  # type: ignore[attr-defined]
                right.bbox.y1 - right.bbox.y0,  # type: ignore[attr-defined]
            )
            gap = right.bbox.x0 - left.bbox.x1  # type: ignore[attr-defined]
            left_region_width = left.bbox.x1 - ordered[0].bbox.x0  # type: ignore[attr-defined]
            right_region_width = ordered[-1].bbox.x1 - right.bbox.x0  # type: ignore[attr-defined]
            broad_flow_gutter = (
                left_region_width >= page_width * 0.12
                and right_region_width >= page_width * 0.12
            )
            # A short text flow can occupy far less than 12% of a wide page.
            # Geometry alone cannot distinguish two short columns from repeated
            # row-wise label/value pairs.  Such a narrow route therefore also
            # needs source-occurrence order to agree with the column partition.
            short_flow_gutter = (
                local_height > 0
                and min(left_region_width, right_region_width) >= local_height * 3
                and gap >= max(local_height * 4, page_width * 0.08)
            )
            if gap > local_height * 1.25 and (broad_flow_gutter or short_flow_gutter):
                gutter_samples.append(
                    (
                        (left.bbox.x1 + right.bbox.x0) / 2,  # type: ignore[attr-defined]
                        not broad_flow_gutter,
                        left.source_order,  # type: ignore[attr-defined]
                        right.source_order,  # type: ignore[attr-defined]
                    )
                )
    gutter_groups: list[list[tuple[float, bool, int, int]]] = []
    for sample in sorted(gutter_samples, key=lambda item: item[0]):
        if (
            not gutter_groups
            or abs(sample[0] - median(item[0] for item in gutter_groups[-1]))
            > page_width * 0.02
        ):
            gutter_groups.append([sample])
        else:
            gutter_groups[-1].append(sample)
    stable_gutters_list: list[float] = []
    for group in gutter_groups:
        if len(group) < 3:
            continue
        broad_sample_count = sum(not item[1] for item in group)
        source_order_agrees = max(item[2] for item in group) < min(
            item[3] for item in group
        )
        if broad_sample_count < 3 and not source_order_agrees:
            if limitation_codes is not None:
                limitation_codes.add("short_column_order_unproven")
            continue
        stable_gutters_list.append(median(item[0] for item in group))
    stable_gutters = tuple(stable_gutters_list)

    result = []
    for ordered in ordered_lines:
        split_indexes = []
        for index, (left, right) in enumerate(zip(ordered, ordered[1:]), 1):
            local_height = min(
                left.bbox.y1 - left.bbox.y0,  # type: ignore[attr-defined]
                right.bbox.y1 - right.bbox.y0,  # type: ignore[attr-defined]
            )
            gap = right.bbox.x0 - left.bbox.x1  # type: ignore[attr-defined]
            if gap > local_height * 1.25 and any(
                left.bbox.x1 < gutter < right.bbox.x0  # type: ignore[attr-defined]
                for gutter in stable_gutters
            ):
                split_indexes.append(index)
        start = 0
        for end in (*split_indexes, len(ordered)):
            result.append(ordered[start:end])
            start = end
    return tuple(result)


def _is_rotated_opaque_page(
    *, candidates: tuple[object, ...], drawing_count: int
) -> bool:
    """Detect a page-axis conflict without interpreting table semantics.

    The decision deliberately requires independent Fact geometry population and
    parser drawing inventory evidence.  It only causes a typed opaque region;
    it never proves an internal reading order.
    """
    eligible = tuple(
        item
        for item in candidates
        if (
            item.bbox.x1 > item.bbox.x0  # type: ignore[attr-defined]
            and item.bbox.y1 > item.bbox.y0  # type: ignore[attr-defined]
            and item.text.strip()  # type: ignore[attr-defined]
        )
    )
    if len(eligible) < 50 or drawing_count < 1:
        return False
    rotated_axis = sum(
        (item.bbox.y1 - item.bbox.y0) > (item.bbox.x1 - item.bbox.x0) * 1.5  # type: ignore[attr-defined]
        for item in eligible
    )
    return rotated_axis * 10 >= len(eligible)


def _dense_grid_regions(
    *,
    separators: tuple[object, ...],
    page_width: float,
    page_height: float,
) -> tuple[PdfBoundingBox, ...]:
    """Return bounded opaque regions supported by repeated grid separators."""
    horizontal = tuple(
        item
        for item in separators
        if (
            item.orientation == "horizontal"  # type: ignore[attr-defined]
            and item.source_kind == "drawing_fact"  # type: ignore[attr-defined]
            and item.line_length >= page_width * 0.15  # type: ignore[attr-defined]
            and item.bbox.x0 > page_width * 0.01  # type: ignore[attr-defined]
            and item.bbox.x1 < page_width * 0.99  # type: ignore[attr-defined]
        )
    )
    groups: list[list[object]] = []
    for item in sorted(
        horizontal,
        key=lambda value: (value.bbox.y0, value.bbox.x0, value.separator_candidate_id),  # type: ignore[attr-defined]
    ):
        matches = []
        for group in groups:
            box = _bbox_union(tuple(value.bbox for value in group))  # type: ignore[attr-defined]
            horizontal_gap = max(box.x0, item.bbox.x0) - min(box.x1, item.bbox.x1)  # type: ignore[attr-defined]
            vertical_gap = max(0.0, item.bbox.y0 - box.y1, box.y0 - item.bbox.y1)  # type: ignore[attr-defined]
            if (
                horizontal_gap <= page_width * 0.015
                and vertical_gap <= page_height * 0.06
            ):
                matches.append(group)
        if not matches:
            groups.append([item])
        else:
            target = matches[0]
            target.append(item)
            for other in matches[1:]:
                target.extend(other)
                groups.remove(other)
    regions = []
    for group in groups:
        distinct_y = {round((item.bbox.y0 + item.bbox.y1) / 2, 3) for item in group}  # type: ignore[attr-defined]
        box = _bbox_union(tuple(item.bbox for item in group))  # type: ignore[attr-defined]
        if (
            len(group) >= 6
            and len(distinct_y) >= 4
            and box.x1 - box.x0 >= page_width * 0.3
            and box.y1 - box.y0 >= page_height * 0.025
        ):
            regions.append(box)
    return tuple(sorted(regions, key=lambda box: (box.y0, box.x0, box.y1, box.x1)))


def _aligned_numeric_index_groups(
    *,
    lines: tuple[tuple[object, ...], ...],
    facts: dict[str, object],
    page_width: float,
    page_height: float,
) -> tuple[tuple[tuple[object, ...], ...], ...]:
    return tuple(
        group
        for group in _aligned_numeric_anchor_groups(
            lines=lines,
            facts=facts,
            page_width=page_width,
            page_height=page_height,
        )
        if not _is_leader_index_flow(group=group, facts=facts)
    )


def _aligned_leader_index_groups(
    *,
    lines: tuple[tuple[object, ...], ...],
    facts: dict[str, object],
    page_width: float,
    page_height: float,
) -> tuple[tuple[tuple[object, ...], ...], ...]:
    return tuple(
        group
        for group in _aligned_numeric_anchor_groups(
            lines=lines,
            facts=facts,
            page_width=page_width,
            page_height=page_height,
        )
        if _is_leader_index_flow(group=group, facts=facts)
    )


def _aligned_numeric_anchor_groups(
    *,
    lines: tuple[tuple[object, ...], ...],
    facts: dict[str, object],
    page_width: float,
    page_height: float,
) -> tuple[tuple[tuple[object, ...], ...], ...]:
    candidates = []
    for line in lines:
        ordered = tuple(sorted(line, key=lambda item: (item.bbox.x0, item.node_id)))  # type: ignore[attr-defined]
        if len(ordered) < 2:
            continue
        right = ordered[-1]
        right_text = getattr(facts[right.source_fact_id], "text", "").strip()  # type: ignore[attr-defined]
        if re.fullmatch(r"\d{1,4}", right_text) and right.bbox.x0 >= page_width * 0.70:  # type: ignore[attr-defined]
            candidates.append(line)
    groups: list[list[tuple[object, ...]]] = []
    for line in sorted(
        candidates,
        key=lambda value: (
            _bbox_union(tuple(item.bbox for item in value)).y0,  # type: ignore[attr-defined]
            _bbox_union(tuple(item.bbox for item in value)).x0,  # type: ignore[attr-defined]
        ),
    ):
        right_x = max(item.bbox.x1 for item in line)  # type: ignore[attr-defined]
        if not groups:
            groups.append([line])
            continue
        prior = groups[-1][-1]
        prior_right_x = max(item.bbox.x1 for item in prior)  # type: ignore[attr-defined]
        prior_box = _bbox_union(tuple(item.bbox for item in prior))  # type: ignore[attr-defined]
        box = _bbox_union(tuple(item.bbox for item in line))  # type: ignore[attr-defined]
        if (
            abs(right_x - prior_right_x) <= page_width * 0.02
            and box.y0 - prior_box.y1 <= page_height * 0.05
        ):
            groups[-1].append(line)
        else:
            groups.append([line])
    return tuple(
        tuple(group)
        for group in groups
        if (
            len(group) >= 6
            and (
                _bbox_union(tuple(item.bbox for line in group for item in line)).y1  # type: ignore[attr-defined]
                - _bbox_union(tuple(item.bbox for line in group for item in line)).y0  # type: ignore[attr-defined]
            )
            >= page_height * 0.05
        )
    )


def _is_leader_index_flow(
    *,
    group: tuple[tuple[object, ...], ...],
    facts: dict[str, object],
) -> bool:
    """Distinguish a physical index/TOC flow from an opaque numeric grid."""
    if len(group) < 6:
        return False
    leader_lines = 0
    for line in group:
        text = " ".join(
            getattr(facts[item.source_fact_id], "text", "")  # type: ignore[attr-defined]
            for item in line
        ).strip()
        if re.search(r"(?:[.．] *){3,}|…{2,}", text) and re.search(
            r"[0-9０-９]{1,4}\s*$", text
        ):
            leader_lines += 1
    return leader_lines * 3 >= len(group) * 2


def _can_group(
    previous: PdfBoundingBox,
    current: PdfBoundingBox,
    *,
    median_height: float,
    page_width: float,
    previous_line_anchor_x0s: tuple[float, ...] = (),
) -> bool:
    return (
        _paragraph_continuation_decision(
            previous,
            current,
            median_height=median_height,
            page_width=page_width,
            previous_line_anchor_x0s=previous_line_anchor_x0s,
        ).decision
        == "continue"
    )


def _can_continue_wrapped_emphasis(
    previous: PdfBoundingBox,
    current: PdfBoundingBox,
    *,
    median_height: float,
    page_width: float,
    previous_emphasized: bool,
    current_emphasized: bool,
    previous_italic: bool,
    current_italic: bool,
) -> bool:
    return (
        previous_emphasized
        and current_emphasized
        and previous_italic
        and current_italic
        and -median_height * 0.15 <= current.y0 - previous.y1 <= median_height * 0.70
        and abs((current.x0 + current.x1) / 2 - (previous.x0 + previous.x1) / 2)
        <= page_width * 0.05
    )


def _can_continue_drop_cap_paragraph(
    previous: PdfBoundingBox,
    current: PdfBoundingBox,
    *,
    median_height: float,
    page_width: float,
) -> bool:
    return (
        previous.y1 - previous.y0 >= median_height * 1.6
        and -median_height * 0.6 <= current.y0 - previous.y1 < -median_height * 0.15
        and abs(current.x0 - previous.x0) <= page_width * 0.025
    )


def _starts_list_item(text: str) -> bool:
    stripped = text.strip()
    return (
        re.match(
            r"^(?:[•・●○▪◦①-⑳]|[-*]\s|"
            r"\(?\d+[.)](?:\s|$)|[A-Za-z][.)](?:\s|$)|"
            r"[（(]\s*[A-Za-zＡ-Ｚａ-ｚ]\s*[）)]\s*|"
            r"（\s*[0-9０-９]+\s*）|"
            r"[（(]\s*[ァ-ヶｦ-ﾟ一-龠]\s*[）)]\s*)",
            stripped,
        )
        is not None
    )


def _starts_new_list_block(
    *,
    current_first_text: str,
    line_text: str,
    vertical_gap: float,
    median_height: float,
) -> bool:
    return _starts_list_item(line_text) and (
        _starts_list_item(current_first_text) or vertical_gap > median_height * 0.45
    )


def _starts_bottom_footnote_line(
    line: tuple[object, ...],
    *,
    facts: dict[str, object],
    median_size: float,
    page_height: float,
) -> bool:
    box = _bbox_union(tuple(item.bbox for item in line))  # type: ignore[attr-defined]
    sizes = tuple(
        _font_size(facts[item.source_fact_id]) or (item.bbox.y1 - item.bbox.y0)  # type: ignore[attr-defined]
        for item in line
    )
    text = " ".join(facts[item.source_fact_id].text for item in line).strip()  # type: ignore[attr-defined]
    return (
        box.y1 / page_height >= 0.86
        and bool(sizes)
        and median(sizes) <= median_size * 0.88
        and re.match(r"^[0-9０-９]{1,3}[\s　]+\S", text) is not None
    )


def _is_narrow_numbered_part_heading(
    text: str,
    bbox: PdfBoundingBox,
    page_width: float,
) -> bool:
    return (
        re.match(
            r"^第[0-9０-９一二三四五六七八九十百]{1,4}[\s　]+\S",
            text.strip(),
        )
        is not None
        and len(text.strip()) <= 180
        and bbox.x1 - bbox.x0 <= page_width * 0.65
    )


def _is_ruby_annotation_for_next_line(
    annotation: tuple[object, ...],
    base: tuple[object, ...],
    *,
    facts: Mapping[str, object],
    median_size: float,
    page_width: float,
) -> bool:
    annotation_box = _bbox_union(tuple(item.bbox for item in annotation))  # type: ignore[attr-defined]
    base_box = _bbox_union(tuple(item.bbox for item in base))  # type: ignore[attr-defined]
    sizes = tuple(
        _font_size(facts[item.source_fact_id]) or (item.bbox.y1 - item.bbox.y0)  # type: ignore[attr-defined]
        for item in annotation
    )
    return (
        bool(sizes)
        and median(sizes) <= median_size * 0.7
        and annotation_box.x1 - annotation_box.x0 <= page_width * 0.2
        and base_box.x0 <= (annotation_box.x0 + annotation_box.x1) / 2 <= base_box.x1
        and annotation_box.y0 < base_box.y0
        and annotation_box.y1 >= base_box.y0 - median_size * 0.1
    )


def _merge_ruby_annotation_lines(
    lines: tuple[tuple[object, ...], ...],
    *,
    facts: dict[str, object],
    median_size: float,
    page_width: float,
) -> tuple[tuple[object, ...], ...]:
    merged = []
    index = 0
    while index < len(lines):
        if index + 1 < len(lines) and _is_ruby_annotation_for_next_line(
            lines[index],
            lines[index + 1],
            facts=facts,
            median_size=median_size,
            page_width=page_width,
        ):
            merged.append(
                tuple(
                    sorted(
                        (*lines[index], *lines[index + 1]),
                        key=lambda item: (item.bbox.x0, item.bbox.y0, item.node_id),  # type: ignore[attr-defined]
                    )
                )
            )
            index += 2
            continue
        merged.append(lines[index])
        index += 1
    return tuple(merged)


def _is_detached_list_marker(text: str) -> bool:
    return re.fullmatch(r"(?:\d{1,4}|[A-Za-z])[.)]", text.strip()) is not None


def _can_attach_detached_list_body(
    marker: PdfBoundingBox,
    body: PdfBoundingBox,
    *,
    median_height: float,
    page_width: float,
) -> bool:
    vertical_gap = body.y0 - marker.y1
    horizontal_gap = body.x0 - marker.x1
    return (
        body.x0 > marker.x1
        and 0 <= horizontal_gap <= page_width * 0.12
        and -median_height * 0.75 <= vertical_gap <= median_height * 0.85
    )


def _starts_hierarchical_heading(text: str) -> bool:
    return _hierarchical_heading_level(text) is not None


def _is_narrow_decimal_section_heading(
    text: str,
    bbox: PdfBoundingBox,
    page_width: float,
) -> bool:
    return (
        re.match(r"^[0-9０-９]{1,3}[.．][0-9０-９]{1,3}[\s　]+\S", text.strip())
        is not None
        and len(text.strip()) <= 180
        and bbox.x1 - bbox.x0 <= page_width * 0.65
    )


def _hierarchical_heading_level(text: str) -> int | None:
    stripped = text.strip()
    decimal = re.match(
        r"^([0-9０-９]+(?:[.．][0-9０-９]+){2,5})[\s　]+\S",
        stripped,
    )
    if decimal is not None:
        return len(re.split(r"[.．]", decimal.group(1)))
    japanese = re.match(
        r"^第[0-9０-９一二三四五六七八九十百千]+([編章節款目])[\s　]*\S",
        stripped,
    )
    if japanese is not None:
        return {"編": 1, "章": 2, "節": 3, "款": 4, "目": 5}[japanese.group(1)]
    return None


def _is_hyphenated_section_heading(text: str) -> bool:
    return (
        re.match(r"^[0-9０-９]{1,3}-[0-9０-９]{3,5}[\s　]+\S", text.strip()) is not None
    )


def _is_compact_page_number(text: str) -> bool:
    return (
        re.fullmatch(
            r"(?:[-–— ]*\d{1,4}[-–— ]*|Page\s*(?:\d{1,4}|[ivxlcdm]{1,8})"
            r"(?:\s+of\s+\d{1,4})?)",
            text.strip(),
            re.IGNORECASE,
        )
        is not None
    )


def _multisignal_marginal_role(
    *,
    text: str,
    bbox: PdfBoundingBox,
    page_height: float,
    page_width: float,
    size: float | None,
    median_size: float,
    italic_ratio: float,
) -> tuple[str, tuple[str, ...]] | None:
    top = bbox.y0 / page_height
    bottom = bbox.y1 / page_height
    relative_size = size / median_size if size and median_size else None
    right_aligned = bbox.x1 >= page_width * 0.8
    edge_aligned = right_aligned or bbox.x0 <= page_width * 0.2
    width_ratio = (bbox.x1 - bbox.x0) / page_width
    if (
        top <= 0.10
        and relative_size is not None
        and relative_size <= 0.9
        and right_aligned
        and italic_ratio < 0.8
        and width_ratio <= 0.6
        and len(text) <= 180
    ):
        return "header", (
            "inset_top_region",
            "relative_small_type",
            "right_edge_alignment",
        )
    if bottom < 0.91:
        return None
    if _is_compact_page_number(text):
        return "footer", ("inset_bottom_region", "exact_pagination_pattern")
    if re.match(r"^\d{1,4}[\s　]+\S", text) and right_aligned:
        return "footer", (
            "inset_bottom_region",
            "leading_page_number",
            "right_edge_alignment",
        )
    if (
        relative_size is not None
        and relative_size <= 0.9
        and edge_aligned
        and width_ratio >= 0.3
        and len(text) <= 120
    ):
        return "footer", (
            "inset_bottom_region",
            "relative_small_type",
            "edge_alignment",
        )
    if italic_ratio >= 0.8 and width_ratio >= 0.5 and re.search(r"\d", text):
        return "footer", (
            "inset_bottom_region",
            "exact_italic_font_lineage",
            "wide_marginal_metadata",
            "numeric_page_token",
        )
    return None


def _complete_candidate_margin_flows(
    blocks: list[PdfReadingStructuralBlock],
    columns: tuple[tuple[tuple[object, ...], ...], ...],
) -> frozenset[str]:
    """Keep an independently ordered flow despite its tentative margin role.

    A location-only header/footer candidate does not invalidate three complete
    physical lines in a nonoverlapping column. This narrow exception requires
    every column and every participating source node to retain precise geometry;
    it does not promote the role, order isolated labels, or infer missing glyphs.
    """
    if len(columns) < 2 or any(len(column) < 3 for column in columns):
        return frozenset()
    column_boxes = []
    column_node_ids = []
    for column in columns:
        if any(
            node.geometry_quality != "precise"  # type: ignore[attr-defined]
            or node.bbox.x1 <= node.bbox.x0  # type: ignore[attr-defined]
            or node.bbox.y1 <= node.bbox.y0  # type: ignore[attr-defined]
            for line in column
            for node in line
        ):
            return frozenset()
        line_boxes = tuple(
            _bbox_union(tuple(node.bbox for node in line))  # type: ignore[attr-defined]
            for line in column
        )
        if any(left.y1 > right.y0 for left, right in zip(line_boxes, line_boxes[1:])):
            return frozenset()
        column_boxes.append(_bbox_union(line_boxes))
        column_node_ids.append(
            frozenset(node.node_id for line in column for node in line)  # type: ignore[attr-defined]
        )
    if any(left.x1 >= right.x0 for left, right in zip(column_boxes, column_boxes[1:])):
        return frozenset()
    return frozenset(
        block.block_id
        for block in blocks
        if block.role in {"header", "footer"}
        and block.role_status == "candidate"
        and frozenset(block.source_node_ids) in column_node_ids
    )


def build_reading_structure_page(
    *,
    inherited: PdfReadingPageEvidence,
    inherited_manifest: PdfReadingPageAuthority,
    inherited_sidecar_bytes: bytes,
) -> PdfReadingStructurePageSidecar:
    if inherited.source_sha256 != inherited_manifest.source_sha256:
        raise ValueError("reading structure inherited source mismatch")
    reference = inherited_manifest.page_references[inherited.page_index]
    if reference.sidecar_id != inherited.sidecar_id:
        raise ValueError("reading structure inherited sidecar mismatch")
    if sha256(inherited_sidecar_bytes).hexdigest() != reference.sidecar_file_sha256:
        raise ValueError("reading structure inherited sidecar bytes mismatch")

    payload = inherited.payload
    graph = payload.layout
    facts = _fact_map(inherited)
    nodes = tuple(
        sorted(
            (
                node
                for node in graph.nodes
                if node.text_layer_role == "primary"
                and node.source_fact_id in facts
                and getattr(facts[node.source_fact_id], "text", "").strip()
            ),
            key=lambda node: (node.source_order, node.node_id),
        )
    )
    sizes = tuple(
        _font_size(facts[node.source_fact_id]) or (node.bbox.y1 - node.bbox.y0)
        for node in nodes
        if node.bbox.y1 > node.bbox.y0
    )
    median_size = median(sizes) if sizes else 0.0
    heights = tuple(
        node.bbox.y1 - node.bbox.y0 for node in nodes if node.bbox.y1 > node.bbox.y0
    )
    median_height = median(heights) if heights else 1.0
    native_run = (
        exact_native_reading_run(
            nodes, page=payload.facts.page, source_sha256=payload.facts.source_sha256
        )
        if (
            payload.facts.page.native_text_event_evidence is not None
            and payload.facts.page.native_text_event_evidence.availability == "COMPLETE"
            and len(payload.facts.page.native_text_event_evidence.events) == 1
        )
        or (
            not any(
                item.evidence_kind != "page_boundary"
                for item in graph.separator_candidates
            )
            and not payload.facts.page.drawings
        )
        else None
    )
    affine_baseline = (
        _single_source_affine_baseline(nodes, facts=facts)
        if not any(
            item.evidence_kind != "page_boundary" for item in graph.separator_candidates
        )
        and not payload.facts.page.drawings
        else None
    )
    physical_line_limitations: set[str] = set()
    selected_lines = (
        (native_run.nodes,)
        if native_run is not None
        else (affine_baseline,)
        if affine_baseline is not None
        else _physical_lines(
            nodes,
            page_width=graph.canonical_width,
            limitation_codes=physical_line_limitations,
        )
    )
    physical_lines = _merge_ruby_annotation_lines(
        selected_lines,
        facts=facts,
        median_size=median_size,
        page_width=graph.canonical_width,
    )
    grid_regions = _dense_grid_regions(
        separators=tuple(graph.separator_candidates),
        page_width=graph.canonical_width,
        page_height=graph.canonical_height,
    )
    rotated_opaque = _is_rotated_opaque_page(
        candidates=tuple(payload.facts.page.line_candidates),
        drawing_count=len(payload.facts.page.drawings),
    )
    opaque_lines: tuple[tuple[object, ...], ...] = ()
    grid_line_groups: list[tuple[tuple[object, ...], ...]] = []
    aligned_index_groups: list[tuple[tuple[object, ...], ...]] = []
    leader_index_groups: list[tuple[tuple[object, ...], ...]] = []
    if rotated_opaque:
        marginal = []
        opaque = []
        for line in physical_lines:
            box = _bbox_union(tuple(item.bbox for item in line))  # type: ignore[attr-defined]
            text = " ".join(facts[item.source_fact_id].text for item in line).strip()  # type: ignore[attr-defined]
            bottom = box.y1 / graph.canonical_height
            if box.y0 / graph.canonical_height <= 0.055 or (
                bottom >= 0.88 and _is_compact_page_number(text)
            ):
                marginal.append((line,))
            else:
                opaque.append(line)
        opaque_lines = tuple(opaque)
        columns = tuple(marginal)
    else:
        remaining = list(physical_lines)
        for region in grid_regions:
            members = tuple(
                line
                for line in remaining
                if (
                    region.x0
                    <= (
                        _bbox_union(tuple(item.bbox for item in line)).x0  # type: ignore[attr-defined]
                        + _bbox_union(tuple(item.bbox for item in line)).x1  # type: ignore[attr-defined]
                    )
                    / 2
                    <= region.x1
                    and region.y0
                    <= (
                        _bbox_union(tuple(item.bbox for item in line)).y0  # type: ignore[attr-defined]
                        + _bbox_union(tuple(item.bbox for item in line)).y1  # type: ignore[attr-defined]
                    )
                    / 2
                    <= region.y1
                )
            )
            if members:
                grid_line_groups.append(members)
                remaining = [line for line in remaining if line not in members]
        aligned_index_groups.extend(
            _aligned_numeric_index_groups(
                lines=tuple(remaining),
                facts=facts,
                page_width=graph.canonical_width,
                page_height=graph.canonical_height,
            )
        )
        leader_index_groups.extend(
            _aligned_leader_index_groups(
                lines=tuple(remaining),
                facts=facts,
                page_width=graph.canonical_width,
                page_height=graph.canonical_height,
            )
        )
        for members in (*aligned_index_groups, *leader_index_groups):
            remaining = [line for line in remaining if line not in members]
        columns = _stable_columns(  # type: ignore[assignment]
            tuple(remaining),
            graph.canonical_width,
            graph.canonical_height,
        )
    layout_edges = {
        (edge.source_node_id, edge.target_node_id): edge for edge in graph.edges
    }

    grouped: list[tuple[tuple[object, ...], ...]] = []

    def line_is_bold(line: tuple[object, ...]) -> bool:
        return (
            sum(_font_is_emphasized(facts[node.source_fact_id]) for node in line)  # type: ignore[attr-defined]
            / len(line)
            >= 0.8
        )

    def line_is_italic(line: tuple[object, ...]) -> bool:
        return (
            sum(_font_is_italic(facts[node.source_fact_id]) for node in line)  # type: ignore[attr-defined]
            / len(line)
            >= 0.8
        )

    def line_is_strong_numbered_heading(line: tuple[object, ...]) -> bool:
        text = " ".join(facts[node.source_fact_id].text for node in line).strip()  # type: ignore[attr-defined]
        return line_is_bold(line) and (
            re.match(r"^\d+(?:\.\d+){0,5}[.\s　]", text) is not None
            or _is_hyphenated_section_heading(text)
        )

    def line_is_exact_section_heading(line: tuple[object, ...]) -> bool:
        text = " ".join(facts[node.source_fact_id].text for node in line).strip()  # type: ignore[attr-defined]
        box = _bbox_union(tuple(node.bbox for node in line))  # type: ignore[attr-defined]
        return (
            _starts_hierarchical_heading(text)
            or _is_narrow_numbered_part_heading(
                text,
                box,
                graph.canonical_width,
            )
            or _is_narrow_decimal_section_heading(
                text,
                box,
                graph.canonical_width,
            )
        )

    for column in columns:
        column_boxes = tuple(
            _bbox_union(tuple(item.bbox for item in line))  # type: ignore[attr-defined]
            for line in column
        )
        flow_width = (
            (max(box.x1 for box in column_boxes) - min(box.x0 for box in column_boxes))
            if column_boxes
            else graph.canonical_width
        )
        flow_x0 = min((box.x0 for box in column_boxes), default=0.0)
        local_leading_modes = _local_leading_modes(
            column,
            facts=facts,
            median_height=median_height,
            page_width=graph.canonical_width,
        )
        current: list[tuple[object, ...]] = []
        for line in column:
            line_text = " ".join(facts[item.source_fact_id].text for item in line)  # type: ignore[attr-defined]
            line_starts_list = _starts_list_item(line_text)
            footnote_boundary = bool(current) and _starts_bottom_footnote_line(
                line,
                facts=facts,
                median_size=median_size,
                page_height=graph.canonical_height,
            )
            page_number_boundary = bool(current) and _is_compact_page_number(
                line_text,
            )
            previous_box = (
                _bbox_union(tuple(item.bbox for item in current[-1]))  # type: ignore[attr-defined]
                if current
                else None
            )
            current_box = _bbox_union(tuple(item.bbox for item in line))  # type: ignore[attr-defined]
            current_first_text = (
                " ".join(facts[item.source_fact_id].text for item in current[0])  # type: ignore[attr-defined]
                if current
                else ""
            )
            list_boundary = (
                bool(current)
                and line_starts_list
                and (
                    _starts_new_list_block(
                        current_first_text=current_first_text,
                        line_text=line_text,
                        vertical_gap=current_box.y0 - previous_box.y1,  # type: ignore[union-attr]
                        median_height=median_height,
                    )
                )
            )
            detached_list_continuation = (
                bool(current)
                and len(current) == 1
                and (
                    _is_detached_list_marker(current_first_text)
                    and _can_attach_detached_list_body(
                        previous_box,  # type: ignore[arg-type]
                        current_box,
                        median_height=median_height,
                        page_width=graph.canonical_width,
                    )
                )
            )
            caption_continuation = bool(current) and (
                _is_explicit_caption(current_first_text)
                and _can_continue_explicit_caption(
                    current[0],
                    line,
                    facts=facts,
                    median_height=median_height,
                    page_width=graph.canonical_width,
                    previous_line=current[-1],
                )
            )
            emphasized_wrap_continuation = bool(current) and (
                _can_continue_wrapped_emphasis(
                    previous_box,  # type: ignore[arg-type]
                    current_box,
                    median_height=median_height,
                    page_width=graph.canonical_width,
                    previous_emphasized=line_is_bold(current[-1]),
                    current_emphasized=line_is_bold(line),
                    previous_italic=line_is_italic(current[-1]),
                    current_italic=line_is_italic(line),
                )
            )
            drop_cap_continuation = (
                bool(current)
                and len(current) == 1
                and (
                    _can_continue_drop_cap_paragraph(
                        previous_box,  # type: ignore[arg-type]
                        current_box,
                        median_height=median_height,
                        page_width=graph.canonical_width,
                    )
                )
            )
            previous_typography = (
                _line_typography(current[-1], facts) if current else None
            )
            current_typography = _line_typography(line, facts)
            paragraph_first_families = (
                set(_line_typography_family_set(current[0], facts))
                if current
                else set()
            )
            paragraph_seen_families = (
                {
                    family
                    for prior_line in current
                    for family in _line_typography_family_set(prior_line, facts)
                }
                if current
                else set()
            )
            accepted_family_evidence = tuple(
                sorted(
                    family
                    for family in paragraph_seen_families
                    if family in paragraph_first_families
                    or sum(
                        family in _line_typography_family_set(prior_line, facts)
                        for prior_line in current
                    )
                    >= 2
                )
            )
            typography_continuity = bool(current) and _paragraph_typography_compatible(
                current[-1],
                line,
                facts=facts,
                accepted_families=accepted_family_evidence,
                allow_open_short_fragment=(
                    not _terminal_text_flow(_line_text(current[-1], facts))
                    and current_box.x1 - current_box.x0 < flow_width * 0.72
                ),
            )
            orientation_continuity = bool(current) and (
                previous_typography[4:] == current_typography[4:]  # type: ignore[index]
            )
            repeated_entry_boundary = bool(current) and (
                _repeated_entry_reset_boundary(
                    _line_text(current[-1], facts),
                    line_text,
                    previous_box,  # type: ignore[arg-type]
                    current_box,
                    page_width=graph.canonical_width,
                )
            )
            paragraph_decision = (
                _paragraph_continuation_decision(
                    previous_box,  # type: ignore[arg-type]
                    current_box,
                    median_height=median_height,
                    page_width=graph.canonical_width,
                    previous_line_anchor_x0s=tuple(
                        item.bbox.x0  # type: ignore[attr-defined]
                        for item in current[-1]
                    ),
                    local_leading_gaps=(
                        local_leading_modes.get(previous_typography, ())  # type: ignore[arg-type]
                        if typography_continuity
                        else ()
                    ),
                    typography_compatible=typography_continuity,
                    orientation_compatible=orientation_continuity,
                    previous_text=_line_text(current[-1], facts),
                    current_text=line_text,
                    flow_width=flow_width,
                    flow_x0=flow_x0,
                    boundary_signals=(
                        ("repeated_entry_reset",) if repeated_entry_boundary else ()
                    ),
                    list_marker_is_boundary=list_boundary,
                )
                if current
                else None
            )
            style_boundary = bool(current) and (
                line_is_bold(current[-1]) != line_is_bold(line)
                and current_box.y0 - previous_box.y1 > median_height * 0.45  # type: ignore[union-attr]
            )
            heading_boundary = bool(current) and (
                line_is_strong_numbered_heading(line)
                or line_is_exact_section_heading(line)
                or (
                    line_is_strong_numbered_heading(current[0])
                    and all(line_is_bold(item) for item in current)
                    and not line_is_bold(line)
                )
                or (
                    line_is_exact_section_heading(current[0])
                    and not line_is_exact_section_heading(line)
                    and not (
                        all(line_is_bold(item) for item in current)
                        and line_is_bold(line)
                    )
                )
            )
            hard_boundary_blocks_special_continuation = (
                _hard_boundary_blocks_special_continuation(
                    ("repeated_entry_reset",) if repeated_entry_boundary else (),
                )
            )
            if current and (
                hard_boundary_blocks_special_continuation
                or list_boundary
                or footnote_boundary
                or page_number_boundary
                or style_boundary
                or not (
                    paragraph_decision.decision == "continue"  # type: ignore[union-attr]
                    or detached_list_continuation
                    or caption_continuation
                    or emphasized_wrap_continuation
                    or drop_cap_continuation
                )
                or heading_boundary
            ):
                grouped.append(tuple(current))
                current = []
            current.append(line)
        if current:
            grouped.append(tuple(current))
    if opaque_lines:
        grouped.append(opaque_lines)
    grouped.extend(grid_line_groups)
    grouped.extend(aligned_index_groups)
    leader_index_line_groups = tuple(
        (line,) for group in leader_index_groups for line in group
    )
    grouped.extend(leader_index_line_groups)
    if (grid_line_groups or aligned_index_groups or leader_index_groups) and len(
        columns
    ) == 1:
        grouped.sort(
            key=lambda member_lines: (
                _bbox_union(
                    tuple(item.bbox for line in member_lines for item in line)  # type: ignore[attr-defined]
                ).y0,
                _bbox_union(
                    tuple(item.bbox for line in member_lines for item in line)  # type: ignore[attr-defined]
                ).x0,
            )
        )

    blocks: list[PdfReadingStructuralBlock] = []
    grouped_boxes = tuple(
        _bbox_union(tuple(item.bbox for line in member_lines for item in line))  # type: ignore[attr-defined]
        for member_lines in grouped
    )
    for group_index, member_lines in enumerate(grouped):
        members = tuple(item for line in member_lines for item in line)  # type: ignore[misc]
        fragments = []
        for position, node in enumerate(members):
            fact = facts[node.source_fact_id]  # type: ignore[attr-defined]
            values = dict(
                fact_id=node.source_fact_id,  # type: ignore[attr-defined]
                layout_node_id=node.node_id,  # type: ignore[attr-defined]
                canonical_bbox=node.bbox,  # type: ignore[attr-defined]
                text=fact.text,  # type: ignore[attr-defined]
                physical_order=position,
            )
            fragments.append(
                _identified(
                    PdfStructuralTextFragment, "fragment_id", "fragment", values
                )
            )
        bbox = grouped_boxes[group_index]
        exact_member_text = native_run is not None and tuple(
            item.layout_node_id for item in fragments
        ) == tuple(node.node_id for node in native_run.nodes)
        text = (
            native_run.text
            if native_run is not None and exact_member_text
            else " ".join(item.text.strip() for item in fragments)
        )
        member_sizes = tuple(
            _font_size(facts[node.source_fact_id]) or (node.bbox.y1 - node.bbox.y0)  # type: ignore[attr-defined]
            for node in members
        )
        bold_count = sum(
            _font_is_emphasized(facts[node.source_fact_id])  # type: ignore[attr-defined]
            for node in members
        )
        italic_count = sum(
            _font_is_italic(facts[node.source_fact_id])  # type: ignore[attr-defined]
            for node in members
        )
        previous_gap = (
            bbox.y0 - grouped_boxes[group_index - 1].y1 if group_index else float("inf")
        )
        next_gap = (
            grouped_boxes[group_index + 1].y0 - bbox.y1
            if group_index + 1 < len(grouped_boxes)
            else float("inf")
        )
        vertically_isolated = (
            previous_gap >= median_height * 0.75 and next_gap >= median_height * 0.75
        )
        next_group_text = (
            " ".join(
                facts[item.source_fact_id].text  # type: ignore[attr-defined]
                for line in grouped[group_index + 1]
                for item in line
            )
            if group_index + 1 < len(grouped)
            else ""
        )
        role, role_status, evidence, heading_level = _role(
            text=text,
            bbox=bbox,
            page_height=graph.canonical_height,
            page_width=graph.canonical_width,
            size=median(member_sizes) if member_sizes else None,
            median_size=median_size,
            bold_ratio=bold_count / len(members),
            vertically_isolated=vertically_isolated,
            italic_ratio=italic_count / len(members),
            followed_by_list=_starts_list_item(next_group_text),
            physical_line_count=len(member_lines),
        )
        if member_lines in leader_index_line_groups:
            role, role_status, evidence, heading_level = (
                "list_item",
                "proven",
                (
                    "leader_run",
                    "repeated_right_numeric_anchor",
                    "exact_line_membership",
                ),
                None,
            )
        grid_opaque = member_lines in grid_line_groups
        aligned_index_opaque = member_lines in aligned_index_groups
        if (
            (
                rotated_opaque
                and len(member_lines) > 1
                and bbox.y0 / graph.canonical_height > 0.055
            )
            or grid_opaque
            or aligned_index_opaque
        ):
            role, role_status, evidence, heading_level = (
                "table_region",
                "review_required",
                (
                    ("exact_rotated_axis_population", "parser_drawing_inventory")
                    if rotated_opaque
                    else (
                        (
                            "layout_separator_grid_inventory",
                            "exact_page_region_membership",
                        )
                        if grid_opaque
                        else ("repeated_right_numeric_anchor", "exact_line_membership")
                    )
                ),
                None,
            )
        relation_ids = tuple(
            sorted(
                edge.edge_id
                for left, right in zip(members, members[1:])
                if (edge := layout_edges.get((left.node_id, right.node_id))) is not None  # type: ignore[attr-defined]
            )
        )
        state = "complete" if role_status == "proven" else "review_required"
        source_line_candidate_ids = _exact_line_candidate_ids(
            lines=member_lines,
            facts=facts,
            candidates=tuple(payload.facts.page.line_candidates),
        )
        if rotated_opaque and role == "table_region":
            source_line_candidate_ids = tuple(
                candidate.fact_id
                for candidate in sorted(
                    (
                        candidate
                        for candidate in payload.facts.page.line_candidates
                        if candidate.text.strip()
                        and candidate.bbox.y0 / graph.canonical_height > 0.055
                    ),
                    key=lambda candidate: (
                        candidate.bbox.y0,
                        candidate.bbox.x0,
                        candidate.source_order,
                        candidate.fact_id,
                    ),
                )
            )
        elif grid_opaque:
            source_line_candidate_ids = tuple(
                candidate.fact_id
                for candidate in sorted(
                    (
                        candidate
                        for candidate in payload.facts.page.line_candidates
                        if candidate.text.strip()
                        and bbox.x0
                        <= (candidate.bbox.x0 + candidate.bbox.x1) / 2
                        <= bbox.x1
                        and bbox.y0
                        <= (candidate.bbox.y0 + candidate.bbox.y1) / 2
                        <= bbox.y1
                    ),
                    key=lambda candidate: (
                        candidate.bbox.y0,
                        candidate.bbox.x0,
                        candidate.source_order,
                        candidate.fact_id,
                    ),
                )
            )
        values = dict(
            page_id=inherited.page_id,
            source_node_ids=tuple(item.layout_node_id for item in fragments),
            source_fact_ids=tuple(item.fact_id for item in fragments),
            source_line_candidate_fact_ids=source_line_candidate_ids,
            source_layout_relation_ids=relation_ids,
            canonical_bbox=bbox,
            fragments=tuple(fragments),
            normalized_text=text,
            role=role,
            role_status=role_status,
            evidence_categories=tuple(sorted(evidence)),
            ordering_evidence=(
                (
                    "exact_native_member_advance_chain",
                    "complete_page_primary_member_intervals",
                )
                if exact_member_text
                else (
                    "exact_source_affine_baseline",
                    "nonoverlapping_baseline_intervals",
                    "complete_page_primary_membership",
                )
                if affine_baseline is not None
                else (
                    ("canonical_page_axis", "short_column_order_unproven")
                    if physical_line_limitations
                    else ("canonical_page_axis", "stable_column_partition")
                )
            ),
            separator_evidence=(
                (
                    "exact_native_literal_whitespace",
                    "source_span_fact:" + native_run.source_span_fact_id,
                )
                if native_run is not None and exact_member_text
                else ()
            ),
            heading_level=heading_level,
            state=state,
            limitation_codes=() if state == "complete" else ("role_requires_review",),
        )
        blocks.append(
            _identified(PdfReadingStructuralBlock, "block_id", "block", values)
        )

    marginal_roles = {
        "header",
        "footer",
        "page_number",
        "footnote",
        "figure_region",
        "table_region",
    }
    ordered_margin_flows = _complete_candidate_margin_flows(blocks, columns)
    primary_blocks = tuple(
        block
        for block in blocks
        if block.role not in marginal_roles or block.block_id in ordered_margin_flows
    )
    order_relations: list[PdfReadingOrderRelation] = []
    for previous, current in zip(primary_blocks, primary_blocks[1:]):  # type: ignore[assignment]
        ambiguous = previous.canonical_bbox.y0 == current.canonical_bbox.y0 and (  # type: ignore[attr-defined]
            previous.canonical_bbox.x1 > current.canonical_bbox.x0  # type: ignore[attr-defined]
        )
        status = "review_required" if ambiguous else "accepted"
        layout_relation_ids = tuple(
            sorted(
                set(
                    previous.source_layout_relation_ids
                    + current.source_layout_relation_ids  # type: ignore[attr-defined]
                )
            )
        )
        relation_type = (
            "heading_to_body" if previous.role == "heading" else "same_column"
        )
        values = dict(
            page_id=inherited.page_id,
            predecessor_block_id=previous.block_id,
            successor_block_id=current.block_id,  # type: ignore[attr-defined]
            relation_type=relation_type,
            source_layout_relation_ids=layout_relation_ids,
            separator_evidence=(),
            column_evidence=("stable_nonoverlapping_column_partition",),
            status=status,
            rejection_reason="overlapping_axis_projection" if ambiguous else None,
            supporting_fact_ids=tuple(
                sorted(set(previous.source_fact_ids + current.source_fact_ids))  # type: ignore[attr-defined]
            ),
            algorithm_version=PHASE3B_READING_ALGORITHM_VERSION,
            configuration_identity=phase3b_reading_configuration_identity(),
        )
        order_relations.append(
            _identified(PdfReadingOrderRelation, "relation_id", "reading-edge", values)
        )
    unresolved = tuple(
        (item.predecessor_block_id, item.successor_block_id)
        for item in order_relations
        if item.status != "accepted"
    )
    reading_limitations = set(physical_line_limitations)
    if unresolved:
        reading_limitations.add("ambiguous_reading_order_component")
    reading_values = dict(
        page_id=inherited.page_id,
        ordered_block_ids=tuple(block.block_id for block in primary_blocks),
        relations=tuple(order_relations),
        unresolved_components=unresolved,
        state="review_required"
        if unresolved or physical_line_limitations
        else "complete",
        limitation_codes=tuple(sorted(reading_limitations)),
    )
    reading = _identified(
        PdfPageReadingOrderGraph, "graph_id", "reading-page", reading_values
    )

    hierarchy_relations: list[PdfHeadingHierarchyRelation] = []
    heading_stack: list[PdfReadingStructuralBlock] = []
    roots: list[str] = []
    orphans: list[str] = []
    review: list[str] = []
    has_proven_heading = any(
        block.role == "heading" and block.role_status == "proven" for block in blocks
    )
    for block in blocks:
        if block.role == "heading" and block.role_status == "proven":
            level = block.heading_level or 1
            while heading_stack and (heading_stack[-1].heading_level or 1) >= level:
                heading_stack.pop()
            if heading_stack:
                parent = heading_stack[-1]
            else:
                roots.append(block.block_id)
                parent = None
            if parent is not None:
                values = dict(
                    parent_block_id=parent.block_id,
                    child_block_id=block.block_id,
                    relation_type="heading_contains_heading",
                    parent_heading_level=parent.heading_level or 1,
                    child_heading_level=level,
                    status="accepted",
                    source_fact_ids=tuple(
                        sorted(set(parent.source_fact_ids + block.source_fact_ids))
                    ),
                    source_layout_relation_ids=(),
                    rejected_evidence_id=None,
                    algorithm_version=PHASE3B_READING_ALGORITHM_VERSION,
                    configuration_identity=phase3b_reading_configuration_identity(),
                )
                hierarchy_relations.append(
                    _identified(
                        PdfHeadingHierarchyRelation,
                        "relation_id",
                        "hierarchy-edge",
                        values,
                    )
                )
            heading_stack.append(block)
        elif heading_stack and block.role_status == "proven":
            parent = heading_stack[-1]
            values = dict(
                parent_block_id=parent.block_id,
                child_block_id=block.block_id,
                relation_type="heading_contains_content",
                parent_heading_level=parent.heading_level or 1,
                child_heading_level=None,
                status="accepted",
                source_fact_ids=tuple(
                    sorted(set(parent.source_fact_ids + block.source_fact_ids))
                ),
                source_layout_relation_ids=(),
                rejected_evidence_id=None,
                algorithm_version=PHASE3B_READING_ALGORITHM_VERSION,
                configuration_identity=phase3b_reading_configuration_identity(),
            )
            hierarchy_relations.append(
                _identified(
                    PdfHeadingHierarchyRelation, "relation_id", "hierarchy-edge", values
                )
            )
        elif block.role_status != "proven":
            review.append(block.block_id)
        elif block.role == "title" or not has_proven_heading:
            roots.append(block.block_id)
        else:
            orphans.append(block.block_id)
    hierarchy_values = dict(
        page_id=inherited.page_id,
        root_block_ids=tuple(roots),
        relations=tuple(hierarchy_relations),
        orphan_block_ids=tuple(orphans),
        review_required_block_ids=tuple(review),
        rejected_relation_ids=(),
        state="review_required" if review else ("partial" if orphans else "complete"),
        limitation_codes=("ambiguous_hierarchy_parent",)
        if review
        else (("no_proven_heading_parent",) if orphans else ()),
    )
    hierarchy = _identified(
        PdfHierarchyGraph, "graph_id", "hierarchy-page", hierarchy_values
    )
    provenance = PdfReadingStructureProvenance(
        source_sha256=inherited.source_sha256,
        page_id=inherited.page_id,
        page_index=inherited.page_index,
        inherited_page_sidecar_id=inherited.sidecar_id,
        inherited_page_sidecar_sha256=reference.sidecar_file_sha256,
        inherited_manifest_id=inherited_manifest.manifest_id,
        dependency_identity=inherited.dependency_identity,
        operation_version=PHASE3B_READING_OPERATION_VERSION,
        algorithm_version=PHASE3B_READING_ALGORITHM_VERSION,
        configuration_identity=phase3b_reading_configuration_identity(),
    )
    components = PdfReadingStructureComponentHashes(
        fact_snapshot_sha256=canonical_sha256(payload.facts),
        layout_snapshot_sha256=canonical_sha256(payload.layout),
        ctif_reference_sha256=canonical_sha256(payload.ctif),
        structural_page_sha256=payload.structural_page_sha256,
        reading_order_sha256=canonical_sha256(reading),
        block_result_sha256=canonical_sha256(tuple(blocks)),
        hierarchy_result_sha256=canonical_sha256(hierarchy),
    )
    states = (reading.state, hierarchy.state, *(block.state for block in blocks))
    page_state: Literal["review_required", "partial", "complete"] = (
        "review_required"
        if "review_required" in states
        else ("partial" if "partial" in states else "complete")
    )
    limitation_codes = tuple(
        sorted(
            set(
                reading.limitation_codes
                + hierarchy.limitation_codes
                + tuple(code for block in blocks for code in block.limitation_codes)
            )
        )
    )
    values = dict(
        schema_version="pdf_reading_structure_page_sidecar.v1",
        source_sha256=inherited.source_sha256,
        page_id=inherited.page_id,
        page_index=inherited.page_index,
        blocks=tuple(blocks),
        reading_order=reading,
        hierarchy=hierarchy,
        component_hashes=components,
        state=page_state,
        limitation_codes=limitation_codes,
        provenance=provenance,
    )
    return PdfReadingStructurePageSidecar(
        sidecar_id=reading_structure_identifier("structure-page", values),
        schema_version="pdf_reading_structure_page_sidecar.v1",
        source_sha256=inherited.source_sha256,
        page_id=inherited.page_id,
        page_index=inherited.page_index,
        blocks=tuple(blocks),
        reading_order=reading,
        hierarchy=hierarchy,
        component_hashes=components,
        state=page_state,
        limitation_codes=limitation_codes,
        provenance=provenance,
    )

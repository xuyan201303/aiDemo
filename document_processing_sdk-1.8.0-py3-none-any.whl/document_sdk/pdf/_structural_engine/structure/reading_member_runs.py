"""Strict original separators for one complete same-parser rotated source run."""

from __future__ import annotations

import math
from dataclasses import dataclass
from itertools import pairwise
from typing import TYPE_CHECKING

from document_sdk.pdf._structural_engine.facts.native_text_contracts import (
    native_event_identifier,
)

if TYPE_CHECKING:
    from document_sdk.pdf._structural_engine.facts.contracts import (
        PdfPageFacts,
        PdfTextFact,
        PdfTextMember,
    )
    from document_sdk.pdf._structural_engine.layout.contracts import PdfLayoutNode

_NUMERIC_ULPS = 32
_MAX_NUMERIC_EPSILON = 1e-9


@dataclass(frozen=True)
class ExactNativeReadingRun:
    nodes: tuple[PdfLayoutNode, ...]
    text: str
    source_span_fact_id: str
    separator_member_ids: tuple[str, ...]


def _near(left: float, right: float) -> bool:
    epsilon = max(math.ulp(left), math.ulp(right), math.ulp(1.0)) * _NUMERIC_ULPS
    return epsilon <= _MAX_NUMERIC_EPSILON and abs(left - right) <= epsilon


def _source_usable(member: PdfTextMember) -> bool:
    matrix, box, advance = member.text_transform, member.bbox, member.parser_advance
    return (
        member.source_writing_mode == "HORIZONTAL"
        and matrix is not None
        and all(math.isfinite(getattr(matrix, key)) for key in "abcdef")
        and matrix.a * matrix.d - matrix.b * matrix.c > 0
        and math.hypot(matrix.a, matrix.b) > 0
        and advance is not None
        and math.isfinite(advance)
        and advance > 0
        and box is not None
        and box.x0 < box.x1
        and box.y0 < box.y1
        and member.parser_bbox is not None
        and (member.text.isspace() or not any(c.isspace() for c in member.text))
    )


def _usable(member: PdfTextMember) -> bool:
    return (
        member.selection_state == "RETAINED"
        and member.geometry_status == "INSIDE"
        and not member.warnings
        and _source_usable(member)
    )


def _excluded_source_member(member: PdfTextMember, page: PdfPageFacts) -> bool:
    """Retain a source occurrence excluded by the existing whole-box boundary."""
    box = member.bbox
    return (
        member.selection_state == "GEOMETRY_REJECTED"
        and all(w.code.value == "invalid_bbox" for w in member.warnings)
        and _source_usable(member)
        and box is not None
        and _excluded_box_matches_status(member, page)
    )


def _excluded_box_matches_status(member: PdfTextMember, page: PdfPageFacts) -> bool:
    """Verify rejected geometry without admitting it to the visible subrun."""
    box = member.bbox
    if box is None:
        return False
    outside = (
        box.x1 < 0
        or box.y1 < 0
        or box.x0 > page.canonical_width
        or box.y0 > page.canonical_height
    )
    if member.geometry_status == "OUTSIDE":
        return outside
    return (
        member.geometry_status == "INTERSECTS"
        and not outside
        and box.x1 >= 0
        and box.y1 >= 0
        and box.x0 <= page.canonical_width
        and box.y0 <= page.canonical_height
        and (
            box.x0 < 0
            or box.y0 < 0
            or box.x1 > page.canonical_width
            or box.y1 > page.canonical_height
        )
    )


def _literal_fact(fact: PdfTextFact, members: tuple[PdfTextMember, ...]) -> bool:
    if (
        fact.member_inventory_status != "COMPLETE"
        or fact.member_projection_status != "EXACT"
        or fact.source_member_count != len(members)
        or tuple(fact.member_ids) != tuple(m.member_id for m in members)
        or len(fact.member_projection) != len(members)
        or fact.text != "".join(m.text for m in members)
    ):
        return False
    offset = 0
    for part, member in zip(fact.member_projection, members, strict=True):
        if (
            part.member_id != member.member_id
            or part.transform != "IDENTITY"
            or part.output_start != offset
            or part.output_end != offset + len(member.text)
        ):
            return False
        offset += len(member.text)
    return True


def _native_inventory(
    page: PdfPageFacts, source_sha256: str, *, allow_excluded_source: bool = False
) -> tuple[PdfTextMember, ...] | None:
    evidence = page.native_text_event_evidence
    members = tuple(page.text_members)
    if (
        not members
        or page.text_member_inventory_status != "COMPLETE"
        or page.source_text_member_count != len(members)
        or page.native_text_event_capture_status != "COMPLETE"
        or evidence is None
        or evidence.availability != "COMPLETE"
        or evidence.source_member_count != len(members)
        or evidence.retained_member_count != len(members)
        or evidence.truncated
        or page.text_source_group_truncated
        or not all(
            _usable(m) or (allow_excluded_source and _excluded_source_member(m, page))
            for m in members
        )
        or [m.source_character_index for m in members] != list(range(len(members)))
        or [m.native_character_ordinal for m in members] != list(range(len(members)))
        or len({m.member_id for m in members}) != len(members)
    ):
        return None
    events = {e.source_event_id: e for e in evidence.events}
    if any(
        e.source_sha256 != source_sha256
        or e.page_number != page.page_number
        or e.completeness != "COMPLETE"
        or e.source_event_id != native_event_identifier(e.model_dump(mode="json"))
        for e in evidence.events
    ):
        return None
    observed: dict[str, list[int]] = {event_id: [] for event_id in events}
    for member in members:
        event = events.get(member.native_text_event_id or "")
        ordinal = member.native_text_event_member_ordinal
        if (
            member.page_id != page.page_id
            or event is None
            or ordinal is None
            or member.native_text_event_ordinal != event.native_event_ordinal
        ):
            return None
        observed[event.source_event_id].append(ordinal)
    if any(
        observed[event.source_event_id] != list(range(event.source_member_count))
        for event in evidence.events
    ):
        return None
    return members


def _visible_subrun(
    page: PdfPageFacts, source_sha256: str
) -> tuple[PdfTextMember, ...] | None:
    """Validate the full chain before retaining one determinate visible interval."""
    source = _native_inventory(page, source_sha256, allow_excluded_source=True)
    if source is None:
        return None
    positions = [i for i, member in enumerate(source) if _usable(member)]
    if (
        not positions
        or len(positions) == len(source)
        or positions != list(range(positions[0], positions[-1] + 1))
    ):
        return None
    visible = source[positions[0] : positions[-1] + 1]
    span = _source_span(page, visible)
    if span is None:
        return None
    spacing = _executed_spacing(page, span)
    if (
        spacing is None
        and span.parser_metadata.get("source_run_projection")
        != "native_horizontal_advance_chain.v1"
    ) or not _native_chain(source, spacing):
        return None
    return visible


def _native_chain(
    members: tuple[PdfTextMember, ...], spacing: tuple[float, float] | None = None
) -> bool:
    basis = members[0].text_transform
    if basis is None or (spacing is None and _near(basis.b, 0.0) and basis.a > 0):
        return False
    for left, right in pairwise(members):
        lm, rm, advance = left.text_transform, right.text_transform, left.parser_advance
        if (
            lm is None
            or rm is None
            or advance is None
            or not all(_near(getattr(lm, k), getattr(rm, k)) for k in "abcd")
        ):
            return False
        step = advance
        if spacing is not None:
            if lm.a <= 0 or not _near(lm.b, 0.0) or not _near(lm.c, 0.0):
                return False
            step += spacing[0] + (spacing[1] if left.text == " " else 0.0)
        if (
            step <= 0
            or not _near(lm.e + lm.a * step, rm.e)
            or not _near(lm.f + lm.b * step, rm.f)
        ):
            return False
    return True


def _executed_spacing(
    page: PdfPageFacts, span: PdfTextFact
) -> tuple[float, float] | None:
    """Bind the spaced baseline to one complete unadjusted source event."""
    evidence = page.native_text_event_evidence
    spacing = (
        span.parser_metadata.get("source_run_charspace"),
        span.parser_metadata.get("source_run_wordspace"),
    )
    if (
        span.parser_metadata.get("source_run_projection")
        != "native_spaced_advance_chain.v1"
        or evidence is None
        or len(evidence.events) != 1
        or evidence.events[0].numeric_adjustment_count != 0
        or not all(
            isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)
            for v in spacing
        )
    ):
        return None
    first, second = spacing
    if not isinstance(first, (int, float)) or not isinstance(second, (int, float)):
        return None
    return float(first), float(second)


def _source_span(
    page: PdfPageFacts, members: tuple[PdfTextMember, ...]
) -> PdfTextFact | None:
    spans = [span for span in page.text_spans if _literal_fact(span, members)]
    if len(spans) != 1:
        return None
    span = spans[0]
    groups = [
        g for g in page.text_source_groups if g.source_group_id == span.source_group_id
    ]
    if (
        len(groups) != 1
        or groups[0].parent_fact_id != span.fact_id
        or groups[0].disposition != "ADMITTED"
        or groups[0].text != span.text
        or groups[0].member_ids != span.member_ids
        or groups[0].member_projection != span.member_projection
    ):
        return None
    return span


def _word_nodes(
    nodes: tuple[PdfLayoutNode, ...],
    page: PdfPageFacts,
    members: tuple[PdfTextMember, ...],
) -> tuple[PdfLayoutNode, ...] | None:
    by_id = {member.member_id: member for member in members}
    positions = {member.member_id: i for i, member in enumerate(members)}
    words = {word.fact_id: word for word in page.words}
    if (
        not nodes
        or len(words) != len(page.words)
        or len({node.node_id for node in nodes}) != len(nodes)
        or len({node.source_fact_id for node in nodes}) != len(nodes)
        or {node.source_fact_id for node in nodes} != set(words)
    ):
        return None
    ordered = []
    used: set[str] = set()
    for node in nodes:
        word = words[node.source_fact_id]
        if (
            node.geometry_quality != "precise"
            or node.source_page_id != page.page_id
            or node.bbox != word.bbox
            or node.rotation != word.rotation
            or node.source_order != word.source_order
            or not word.member_ids
            or any(mid not in by_id for mid in word.member_ids)
        ):
            return None
        selected = tuple(by_id[mid] for mid in word.member_ids)
        starts = [positions[mid] for mid in word.member_ids]
        if (
            starts != list(range(starts[0], starts[0] + len(starts)))
            or not _literal_fact(word, selected)
            or any(m.text.isspace() for m in selected)
            or used.intersection(word.member_ids)
        ):
            return None
        used.update(word.member_ids)
        ordered.append((starts[0], node))
    nonspace = {m.member_id for m in members if not m.text.isspace()}
    if used != nonspace:
        return None
    ordered.sort(key=lambda item: item[0])
    return tuple(item[1] for item in ordered)


def exact_native_reading_run(
    nodes: tuple[PdfLayoutNode, ...], *, page: PdfPageFacts, source_sha256: str
) -> ExactNativeReadingRun | None:
    """Prove one complete rotated native run; preserve role uncertainty.

    This is not a page-coordinate sort. Every character and separator needs an
    independent exact native member and a literal Fact projection. Unknown or
    incomplete inventories keep the prior conservative Reading path.
    """
    members = _native_inventory(page, source_sha256)
    if members is None:
        members = _visible_subrun(page, source_sha256)
        if members is None:
            return None
    span = _source_span(page, members)
    if span is None:
        return None
    if not _native_chain(members, _executed_spacing(page, span)):
        return None
    ordered = _word_nodes(nodes, page, members)
    if ordered is None:
        return None
    return ExactNativeReadingRun(
        nodes=ordered,
        text=span.text,
        source_span_fact_id=span.fact_id,
        separator_member_ids=tuple(m.member_id for m in members if m.text.isspace()),
    )

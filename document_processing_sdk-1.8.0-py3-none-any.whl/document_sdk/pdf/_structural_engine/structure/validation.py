# ruff: noqa: EM101, TC003, TRY003

from __future__ import annotations

from collections.abc import Iterator


class PdfStructureEvidenceError(ValueError):
    pass


def _validate_acyclic_adjacency(adjacency: dict[str, set[str]]) -> None:
    """Validate a directed graph without depending on Python recursion depth."""
    visited: set[str] = set()
    for root in sorted(adjacency):
        if root in visited:
            continue
        visiting: set[str] = {root}
        stack: list[tuple[str, Iterator[str]]] = [(root, iter(sorted(adjacency[root])))]
        while stack:
            node, targets = stack[-1]
            try:
                target = next(targets)
            except StopIteration:
                stack.pop()
                visiting.remove(node)
                visited.add(node)
                continue
            if target in visiting:
                raise PdfStructureEvidenceError("proven reading order contains a cycle")
            if target in visited:
                continue
            visiting.add(target)
            stack.append((target, iter(sorted(adjacency[target]))))

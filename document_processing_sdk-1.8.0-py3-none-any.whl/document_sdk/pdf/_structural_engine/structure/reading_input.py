# ruff: noqa: EM101, EM102, PLR0913, TC001, TRY003

from __future__ import annotations

from hashlib import sha256
from importlib import import_module
from typing import TYPE_CHECKING, Literal, Protocol

from pydantic import BaseModel, ConfigDict, Field, model_validator

from document_sdk.pdf._structural_engine.facts.contracts import (
    PdfFactArtifact,
    PdfPageFacts,
)
from document_sdk.pdf._structural_engine.facts.status import (
    PdfExtractionStatus,
    PdfFactWarning,
)
from document_sdk.pdf._structural_engine.layout.contracts import (
    PdfLayoutEdge,
    PdfLayoutGraphArtifact,
    PdfLayoutNode,
    PdfLayoutPageQualitySignals,
    PdfLayoutRelationObservationScope,
    PdfLayoutSeparatorCandidate,
)

from .identity import canonical_json_digest_and_size, canonical_sha256

if TYPE_CHECKING:

    class _CanonicalAuthorityIdentity(Protocol):
        authority_version: str
        source_artifact_sha256: str
        original_page_number: int

    class CanonicalEvidenceBundle(BaseModel):
        authority_identity: _CanonicalAuthorityIdentity
        bundle_digest: str

else:
    CanonicalEvidenceBundle = import_module(
        "document_sdk.pdf._structural_engine.canonical_identity.contracts"
    ).CanonicalEvidenceBundle

READING_PAGE_EVIDENCE_VERSION: Literal["document_sdk_pdf_reading_page_evidence.v1"] = (
    "document_sdk_pdf_reading_page_evidence.v1"
)
READING_PAGE_AUTHORITY_VERSION: Literal[
    "document_sdk_pdf_reading_page_authority.v1"
] = "document_sdk_pdf_reading_page_authority.v1"

READING_PAGE_EVIDENCE_IDENTITY_DOMAIN = (
    "document_sdk.pdf.phase3.reading.page_evidence.v1"
)
READING_PAGE_SEQUENCE_IDENTITY_DOMAIN = (
    "document_sdk.pdf.phase3.reading.page_sequence.v1"
)
READING_PAGE_AUTHORITY_IDENTITY_DOMAIN = (
    "document_sdk.pdf.phase3.reading.page_authority.v1"
)


def build_unavailable_reading_canonical_evidence(
    *,
    source_sha256: str,
    document_identity: str,
    page_identity: str,
    page_number: int,
) -> CanonicalEvidenceBundle:
    """Build the fixed no-CTIF companion used by local Reading orchestration."""
    authority = {
        "authority_version": "canonical_text_identity.v1",
        "source_artifact_sha256": source_sha256,
        "document_identity": document_identity,
        "original_page_number": page_number,
        "page_identity": page_identity,
        "source_snapshot_identity": canonical_sha256(
            {"page_id": page_identity, "kind": "facts-layout"}
        ),
        "generation_mode": "off",
        "generator_identity": "document_sdk.pdf.full_local.v1",
        "extraction_configuration_identity": canonical_sha256(
            {"runtime": "document_sdk.pdf.full_local.v1"}
        ),
        "resource_policy_identity": canonical_sha256({"policy": "default_bounded"}),
        "normalization_policy_identity": canonical_sha256({"policy": "not_executed"}),
        "decoding_policy_identity": canonical_sha256({"policy": "not_executed"}),
        "created_from_source_identity": source_sha256,
    }
    values = {
        "authority_identity": authority,
        "canonical_stream_digest": canonical_sha256(
            {"state": "unavailable", "page_id": page_identity}
        ),
        "resource_policy": {},
        "generation_completeness": "unavailable",
    }
    return CanonicalEvidenceBundle.model_validate(
        {**values, "bundle_digest": canonical_sha256(values)}
    )


_ReadingPageState = Literal[
    "complete",
    "partial",
    "review_required",
    "unsupported",
    "unavailable",
]


class PageScopedEvidenceError(ValueError):
    pass


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)


class PdfPageScopedFactSnapshot(_FrozenModel):
    inherited_contract: Literal["pdf_facts.v1"] = "pdf_facts.v1"
    inherited_artifact_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    document_id: str = Field(pattern=r"^PDFD-[0-9a-f]{24}$")
    parser_name: str
    parser_version: str
    extraction_scope_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    page: PdfPageFacts


class PdfPageScopedLayoutSnapshot(_FrozenModel):
    inherited_contract: Literal["pdf_layout_graph.v1"] = "pdf_layout_graph.v1"
    inherited_graph_id: str = Field(pattern=r"^PDFLG-[0-9a-f]{24}$")
    inherited_graph_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    inherited_fact_artifact_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    page_graph_id: str = Field(pattern=r"^PDFLP-[0-9a-f]{24}$")
    page_number: int = Field(ge=1)
    canonical_width: float = Field(gt=0)
    canonical_height: float = Field(gt=0)
    rotation: Literal[0, 90, 180, 270]
    nodes: tuple[PdfLayoutNode, ...]
    edges: tuple[PdfLayoutEdge, ...]
    separator_candidates: tuple[PdfLayoutSeparatorCandidate, ...] = ()
    relation_observation: PdfLayoutRelationObservationScope
    quality_signals: PdfLayoutPageQualitySignals
    build_status: PdfExtractionStatus
    warnings: tuple[PdfFactWarning, ...] = ()

    @model_validator(mode="after")
    def validate_snapshot(self) -> PdfPageScopedLayoutSnapshot:
        node_ids = tuple(item.node_id for item in self.nodes)
        if len(node_ids) != len(set(node_ids)):
            raise ValueError("page Layout snapshot has duplicate nodes")
        if any(item.source_page_id != self.page_id for item in self.nodes):
            raise ValueError("page Layout snapshot node Page mismatch")
        return self


class PdfReadingPagePayload(_FrozenModel):
    facts: PdfPageScopedFactSnapshot
    layout: PdfPageScopedLayoutSnapshot
    ctif: CanonicalEvidenceBundle
    structural_page_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_payload(self) -> PdfReadingPagePayload:
        fact_page = self.facts.page
        if not (
            fact_page.page_id == self.layout.page_id
            and fact_page.page_number == self.layout.page_number
        ):
            raise ValueError("reading page Fact/Layout Page identity mismatch")
        if self.facts.source_sha256 != self.layout.source_sha256:
            raise ValueError("reading page Fact/Layout source binding mismatch")
        if (
            self.layout.inherited_fact_artifact_identity
            != self.facts.inherited_artifact_identity
        ):
            raise ValueError("reading page Fact/Layout artifact binding missing")
        if (
            self.ctif.authority_identity.source_artifact_sha256
            != self.facts.source_sha256
        ):
            raise ValueError("reading page CTIF source mismatch")
        if self.ctif.authority_identity.original_page_number != fact_page.page_number:
            raise ValueError("reading page CTIF page mismatch")
        return self


class PdfReadingPageEvidence(_FrozenModel):
    schema_version: Literal["document_sdk_pdf_reading_page_evidence.v1"] = (
        READING_PAGE_EVIDENCE_VERSION
    )
    sidecar_id: str = Field(pattern=r"^P3S-page-evidence-[0-9a-f]{64}$")
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    page_index: int = Field(ge=0)
    page_fact_artifact_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_layout_graph_id: str = Field(pattern=r"^PDFLG-[0-9a-f]{24}$")
    page_layout_graph_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_ctif_evidence_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    dependency_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    parser_lineage_identity: str
    pdfium_lineage_identity: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )
    cross_parser_alignment_identity: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )
    extraction_scope_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    algorithm_version: str
    configuration_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    payload_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    payload_bytes: int = Field(ge=0)
    state: _ReadingPageState
    limitation_codes: tuple[str, ...] = ()
    provenance_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    payload: PdfReadingPagePayload

    @model_validator(mode="after")
    def validate_sidecar(self) -> PdfReadingPageEvidence:
        facts = self.payload.facts
        page = facts.page
        payload_sha256, payload_bytes = canonical_json_digest_and_size(self.payload)
        expected = {
            "source_sha256": facts.source_sha256,
            "page_id": page.page_id,
            "page_index": page.page_number - 1,
            "page_fact_artifact_identity": facts.inherited_artifact_identity,
            "page_layout_graph_id": self.payload.layout.inherited_graph_id,
            "page_layout_graph_digest": self.payload.layout.inherited_graph_digest,
            "page_ctif_evidence_identity": self.payload.ctif.bundle_digest,
            "extraction_scope_identity": facts.extraction_scope_identity,
            "payload_sha256": payload_sha256,
            "payload_bytes": payload_bytes,
        }
        for name, value in expected.items():
            if getattr(self, name) != value:
                raise ValueError(f"reading page {name} mismatch")
        identity = reading_page_sidecar_identity(
            self.model_dump(exclude={"sidecar_id", "payload"})
        )
        if self.sidecar_id != f"P3S-page-evidence-{identity}":
            raise ValueError("reading page sidecar identity mismatch")
        return self


class PdfPageScopedReference(_FrozenModel):
    sidecar_id: str = Field(pattern=r"^P3S-page-evidence-[0-9a-f]{64}$")
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    page_index: int = Field(ge=0)
    sidecar_file_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    sidecar_bytes: int = Field(ge=0)
    structural_page_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")


class PdfReadingPageAuthority(_FrozenModel):
    schema_version: Literal["document_sdk_pdf_reading_page_authority.v1"] = (
        READING_PAGE_AUTHORITY_VERSION
    )
    manifest_id: str = Field(pattern=r"^P3S-page-manifest-[0-9a-f]{64}$")
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_count: int = Field(ge=0)
    page_references: tuple[PdfPageScopedReference, ...]
    page_sequence_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    dependency_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    operation_version: str
    configuration_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    algorithm_version: str
    fact_contract: Literal["pdf_facts.v1"] = "pdf_facts.v1"
    layout_contract: Literal["pdf_layout_graph.v1"] = "pdf_layout_graph.v1"
    ctif_contract: str
    state: _ReadingPageState
    limitation_codes: tuple[str, ...] = ()
    provenance_identity: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_authority(self) -> PdfReadingPageAuthority:
        indexes = tuple(item.page_index for item in self.page_references)
        if indexes != tuple(range(self.page_count)):
            raise ValueError(
                "reading page authority sequence is missing, duplicate, or noncanonical"
            )
        page_ids = tuple(item.page_id for item in self.page_references)
        if len(page_ids) != len(set(page_ids)):
            raise ValueError("reading page authority repeats a Page identity")
        sidecar_ids = tuple(item.sidecar_id for item in self.page_references)
        if len(sidecar_ids) != len(set(sidecar_ids)):
            raise ValueError("reading page authority repeats a sidecar identity")
        expected_sequence = reading_page_sequence_identity(self.page_references)
        if self.page_sequence_digest != expected_sequence:
            raise ValueError("reading page authority sequence digest mismatch")
        expected_id = reading_page_authority_identity(
            self.model_dump(exclude={"manifest_id"})
        )
        if self.manifest_id != f"P3S-page-manifest-{expected_id}":
            raise ValueError("reading page authority identity mismatch")
        return self


def reading_page_sidecar_identity(metadata: dict[str, object]) -> str:
    return canonical_sha256(
        {**metadata, "domain": READING_PAGE_EVIDENCE_IDENTITY_DOMAIN}
    )


def reading_page_sequence_identity(
    references: tuple[PdfPageScopedReference, ...],
) -> str:
    return canonical_sha256(
        {
            "domain": READING_PAGE_SEQUENCE_IDENTITY_DOMAIN,
            "pages": tuple(
                (
                    item.page_index,
                    item.page_id,
                    item.sidecar_id,
                    item.sidecar_file_sha256,
                )
                for item in references
            ),
        }
    )


def reading_page_authority_identity(payload: dict[str, object]) -> str:
    return canonical_sha256(
        {**payload, "domain": READING_PAGE_AUTHORITY_IDENTITY_DOMAIN}
    )


def validate_reference_sidecar(
    *,
    reference: PdfPageScopedReference,
    sidecar: PdfReadingPageEvidence,
    content: bytes,
    expected_source_sha256: str,
) -> None:
    """Directly validate every sealed Reference-to-Sidecar binding."""
    observed = {
        "page_id": sidecar.page_id,
        "page_index": sidecar.page_index,
        "sidecar_id": sidecar.sidecar_id,
        "structural_page_sha256": sidecar.payload.structural_page_sha256,
        "sidecar_file_sha256": sha256(content).hexdigest(),
        "sidecar_bytes": len(content),
        "source_sha256": sidecar.source_sha256,
    }
    expected = {
        "page_id": reference.page_id,
        "page_index": reference.page_index,
        "sidecar_id": reference.sidecar_id,
        "structural_page_sha256": reference.structural_page_sha256,
        "sidecar_file_sha256": reference.sidecar_file_sha256,
        "sidecar_bytes": reference.sidecar_bytes,
        "source_sha256": expected_source_sha256,
    }
    mismatches = tuple(name for name in expected if observed[name] != expected[name])
    if mismatches:
        raise PageScopedEvidenceError(
            "reading page Reference/Sidecar mismatch: " + ",".join(mismatches)
        )


def build_page_fact_snapshot(
    *,
    facts: PdfFactArtifact,
    inherited_artifact_identity: str,
) -> PdfPageScopedFactSnapshot:
    if len(facts.pages) != 1:
        raise PageScopedEvidenceError("Fact snapshot requires exactly one page")
    return PdfPageScopedFactSnapshot(
        inherited_artifact_identity=inherited_artifact_identity,
        source_sha256=facts.source_sha256,
        document_id=facts.document_id,
        parser_name=facts.parser_name,
        parser_version=facts.parser_version,
        extraction_scope_identity=facts.extraction_scope_result.scope_digest,
        page=facts.pages[0],
    )


def build_page_layout_snapshot(
    *,
    layout: PdfLayoutGraphArtifact,
    source_sha256: str,
) -> PdfPageScopedLayoutSnapshot:
    if len(layout.pages) != 1:
        raise PageScopedEvidenceError("Layout snapshot requires exactly one page")
    page = layout.pages[0]
    return PdfPageScopedLayoutSnapshot(
        inherited_graph_id=layout.layout_graph_id,
        inherited_graph_digest=layout.graph_digest,
        inherited_fact_artifact_identity=layout.source_fact_artifact_sha256,
        source_sha256=source_sha256,
        page_id=page.source_page_id,
        page_graph_id=page.page_graph_id,
        page_number=page.page_number,
        canonical_width=page.canonical_width,
        canonical_height=page.canonical_height,
        rotation=page.rotation,
        nodes=page.nodes,
        edges=page.edges,
        separator_candidates=page.separator_candidates,
        relation_observation=page.relation_observation,
        quality_signals=page.quality_signals,
        build_status=page.build_status,
        warnings=page.warnings,
    )


def build_reading_page_evidence(
    *,
    payload: PdfReadingPagePayload,
    dependency_identity: str,
    parser_lineage_identity: str,
    algorithm_version: str,
    configuration_identity: str,
    state: _ReadingPageState,
    limitation_codes: tuple[str, ...],
    provenance_identity: str,
    pdfium_lineage_identity: str | None = None,
    cross_parser_alignment_identity: str | None = None,
) -> PdfReadingPageEvidence:
    facts = payload.facts
    page = facts.page
    payload_sha256, payload_bytes = canonical_json_digest_and_size(payload)
    metadata = {
        "schema_version": READING_PAGE_EVIDENCE_VERSION,
        "source_sha256": facts.source_sha256,
        "page_id": page.page_id,
        "page_index": page.page_number - 1,
        "page_fact_artifact_identity": facts.inherited_artifact_identity,
        "page_layout_graph_id": payload.layout.inherited_graph_id,
        "page_layout_graph_digest": payload.layout.inherited_graph_digest,
        "page_ctif_evidence_identity": payload.ctif.bundle_digest,
        "dependency_identity": dependency_identity,
        "parser_lineage_identity": parser_lineage_identity,
        "pdfium_lineage_identity": pdfium_lineage_identity,
        "cross_parser_alignment_identity": cross_parser_alignment_identity,
        "extraction_scope_identity": facts.extraction_scope_identity,
        "algorithm_version": algorithm_version,
        "configuration_identity": configuration_identity,
        "payload_sha256": payload_sha256,
        "payload_bytes": payload_bytes,
        "state": state,
        "limitation_codes": limitation_codes,
        "provenance_identity": provenance_identity,
    }
    return PdfReadingPageEvidence(
        sidecar_id=(f"P3S-page-evidence-{reading_page_sidecar_identity(metadata)}"),
        payload=payload,
        **metadata,  # type: ignore[arg-type]
    )


def build_reading_page_authority(
    *,
    source_sha256: str,
    references: tuple[PdfPageScopedReference, ...],
    dependency_identity: str,
    operation_version: str,
    configuration_identity: str,
    algorithm_version: str,
    ctif_contract: str,
    state: _ReadingPageState,
    limitation_codes: tuple[str, ...],
    provenance_identity: str,
) -> PdfReadingPageAuthority:
    sequence = reading_page_sequence_identity(references)
    values = {
        "schema_version": READING_PAGE_AUTHORITY_VERSION,
        "source_sha256": source_sha256,
        "page_count": len(references),
        "page_references": references,
        "page_sequence_digest": sequence,
        "dependency_identity": dependency_identity,
        "operation_version": operation_version,
        "configuration_identity": configuration_identity,
        "algorithm_version": algorithm_version,
        "fact_contract": "pdf_facts.v1",
        "layout_contract": "pdf_layout_graph.v1",
        "ctif_contract": ctif_contract,
        "state": state,
        "limitation_codes": limitation_codes,
        "provenance_identity": provenance_identity,
    }
    return PdfReadingPageAuthority(
        manifest_id=(f"P3S-page-manifest-{reading_page_authority_identity(values)}"),
        **values,  # type: ignore[arg-type]
    )

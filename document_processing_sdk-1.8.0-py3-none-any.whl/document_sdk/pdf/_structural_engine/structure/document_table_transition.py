# ruff: noqa: B905, C901, EM101, PLR2004, SIM114, TRY003

from __future__ import annotations

from collections import defaultdict
from itertools import product

from pydantic import BaseModel, ConfigDict, Field, model_validator

from . import document_table_contracts as _contracts
from .identity import canonical_number, canonical_sha256

PdfPhase3DColumnMapping = _contracts.PdfPhase3DColumnMapping
PdfPhase3DResourceContract = _contracts.PdfPhase3DResourceContract
PdfPhase3DTableEndpoint = _contracts.PdfPhase3DTableEndpoint
PdfRepeatedHeaderMapping = _contracts.PdfRepeatedHeaderMapping
PdfRowFragmentLink = _contracts.PdfRowFragmentLink
PdfTablePageTransition = _contracts.PdfTablePageTransition
build_row_fragment_link = _contracts.build_row_fragment_link
build_table_page_transition = _contracts.build_table_page_transition

_MAXIMUM_GEOMETRY_DRIFT = 0.04


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)


class PdfTransitionColumnFeature(_FrozenModel):
    column_id: str = Field(pattern=r"^P3C-column-[0-9a-f]{64}$")
    column_index: int = Field(ge=0)
    normalized_x0: float = Field(ge=0, le=1)
    normalized_x1: float = Field(ge=0, le=1)

    @model_validator(mode="after")
    def validate_extent(self) -> PdfTransitionColumnFeature:
        if self.normalized_x0 >= self.normalized_x1:
            raise ValueError("normalized column extent is empty")
        return self


class PdfTransitionTableFeatures(_FrozenModel):
    endpoint: PdfPhase3DTableEndpoint
    normalized_x0: float = Field(ge=0, le=1)
    normalized_y0: float = Field(ge=0, le=1)
    normalized_x1: float = Field(ge=0, le=1)
    normalized_y1: float = Field(ge=0, le=1)
    normalized_upper_gap: float | None = Field(default=None, ge=0, le=1)
    normalized_lower_gap: float | None = Field(default=None, ge=0, le=1)
    columns: tuple[PdfTransitionColumnFeature, ...]
    page_table_count: int = Field(default=1, ge=1)
    rotation_degrees: int = Field(default=0)
    empty_spacer_column_indexes: tuple[int, ...] = ()
    empty_spacer_column_states: tuple[bool | None, ...] | None = None
    header_row_ids: tuple[str, ...] | None = None
    header_cell_ids: tuple[str, ...] | None = None
    header_symbolic_signatures: tuple[str, ...] | None = None
    header_geometry_signature: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )
    strategy: str | None = Field(min_length=1, max_length=64)
    reaches_lower_content_boundary: bool | None
    starts_near_upper_content_boundary: bool | None
    bottom_boundary_open: bool | None
    top_boundary_open: bool | None
    terminal_boundary_closed: bool | None
    independent_top_enclosure: bool | None
    last_row_physically_incomplete: bool | None
    first_row_fragment_compatible: bool | None
    last_row_symbolically_incomplete: bool | None = None
    first_row_symbolically_compatible: bool | None = None
    first_body_row_id: str
    first_body_cell_ids: tuple[str, ...]
    last_body_row_id: str
    last_body_cell_ids: tuple[str, ...]
    source_available: bool = True
    upstream_partial: bool = False
    fingerprint_similarity: float | None = Field(ge=0, le=1)
    topology_signature: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_features(self) -> PdfTransitionTableFeatures:
        if self.normalized_x0 >= self.normalized_x1 or self.normalized_y0 >= (
            self.normalized_y1
        ):
            raise ValueError("normalized table extent is empty")
        if tuple(column.column_index for column in self.columns) != tuple(
            range(len(self.columns))
        ):
            raise ValueError("transition columns are noncanonical")
        header_inventories = (
            self.header_row_ids,
            self.header_cell_ids,
            self.header_symbolic_signatures,
            self.header_geometry_signature,
        )
        if any(value is None for value in header_inventories) and not all(
            value is None for value in header_inventories
        ):
            raise ValueError("header authority inventories must be jointly available")
        if all(value is not None for value in header_inventories) and any(
            not value for value in header_inventories
        ):
            raise ValueError("available header authority inventories must be nonempty")
        if self.header_symbolic_signatures is not None and any(
            len(value) != 64
            or any(character not in "0123456789abcdef" for character in value)
            for value in self.header_symbolic_signatures
        ):
            raise ValueError("header symbolic signatures must be canonical SHA-256")
        if (
            self.header_row_ids is not None
            and self.header_symbolic_signatures is not None
            and len(self.header_row_ids) != len(self.header_symbolic_signatures)
        ):
            raise ValueError("header row and symbolic inventories differ")
        if any(
            index < 0 or index >= len(self.columns)
            for index in self.empty_spacer_column_indexes
        ) or self.empty_spacer_column_indexes != tuple(
            sorted(set(self.empty_spacer_column_indexes))
        ):
            raise ValueError("empty spacer column inventory is invalid")
        if self.empty_spacer_column_states is not None:
            if len(self.empty_spacer_column_states) != len(self.columns):
                raise ValueError(
                    "empty spacer states must align with transition columns"
                )
            proven_indexes = tuple(
                index
                for index, state in enumerate(self.empty_spacer_column_states)
                if state is True
            )
            if self.empty_spacer_column_indexes and (
                self.empty_spacer_column_indexes != proven_indexes
            ):
                raise ValueError("empty spacer indexes conflict with typed states")
        if not has_required_table_topology(self):
            raise ValueError("transition feature topology authority is incomplete")
        if self.header_row_ids is not None and self.header_cell_ids is not None:
            _validate_header_topology(self)
        return self


def _validate_header_topology(features: PdfTransitionTableFeatures) -> None:
    header_row_ids = features.header_row_ids
    header_cell_ids = features.header_cell_ids
    if header_row_ids is None or header_cell_ids is None:
        return
    memberships = dict(features.endpoint.row_cell_membership)
    selected_rows = set(header_row_ids)
    selected_cells = set(header_cell_ids)
    expected_rows = tuple(
        row_id for row_id in features.endpoint.table_row_ids if row_id in selected_rows
    )
    expected_cells = tuple(
        cell_id
        for row_id in header_row_ids
        if row_id in memberships
        for cell_id in memberships[row_id]
        if cell_id in selected_cells
    )
    if (
        any(row_id not in memberships for row_id in header_row_ids)
        or header_row_ids != expected_rows
        or header_cell_ids != expected_cells
        or any(
            not selected_cells.intersection(memberships[row_id])
            for row_id in header_row_ids
        )
    ):
        raise ValueError("header authority is not bound to table topology")
    body_rows = {features.first_body_row_id, features.last_body_row_id}
    body_cells = {*features.first_body_cell_ids, *features.last_body_cell_ids}
    if body_rows.intersection(header_row_ids) or body_cells.intersection(
        header_cell_ids
    ):
        raise ValueError("header and body authority must be disjoint")


def has_required_table_topology(features: PdfTransitionTableFeatures) -> bool:
    endpoint = features.endpoint
    if (
        not features.columns
        or not endpoint.table_row_ids
        or not endpoint.table_cell_ids
    ):
        return False
    membership_rows = tuple(row_id for row_id, _ in endpoint.row_cell_membership)
    membership_cells = tuple(
        cell_id for _, cell_ids in endpoint.row_cell_membership for cell_id in cell_ids
    )
    if membership_rows != endpoint.table_row_ids or (
        len(membership_cells) != len(set(membership_cells))
        or len(membership_cells) != len(endpoint.table_cell_ids)
        or set(membership_cells) != set(endpoint.table_cell_ids)
    ):
        return False
    memberships = dict(endpoint.row_cell_membership)
    return all(
        row_id in memberships and cell_ids == memberships[row_id]
        for row_id, cell_ids in (
            (features.first_body_row_id, features.first_body_cell_ids),
            (features.last_body_row_id, features.last_body_cell_ids),
        )
    )


def _canonical_strategy(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = value.strip().casefold()
    return normalized if normalized in {"ruled", "borderless"} else None


def _empty_spacer_states(
    features: PdfTransitionTableFeatures,
) -> tuple[bool | None, ...]:
    if features.empty_spacer_column_states is not None:
        return features.empty_spacer_column_states
    indexes = set(features.empty_spacer_column_indexes)
    return tuple(
        True if index in indexes else None for index in range(len(features.columns))
    )


def _empty_spacer_topology_compatible(
    left: PdfTransitionTableFeatures,
    right: PdfTransitionTableFeatures,
) -> bool:
    left_states = _empty_spacer_states(left)
    right_states = _empty_spacer_states(right)
    return len(left_states) == len(right_states) and all(
        left_state is None or right_state is None or left_state == right_state
        for left_state, right_state in zip(left_states, right_states, strict=True)
    )


def map_columns(
    left: PdfTransitionTableFeatures,
    right: PdfTransitionTableFeatures,
    *,
    maximum_axis_distance: float = 0.025,
    maximum_width_ratio_difference: float = 0.08,
) -> tuple[PdfPhase3DColumnMapping, ...]:
    if len(left.columns) != len(right.columns):
        return ()
    translation_x0 = right.normalized_x0 - left.normalized_x0
    translation_x1 = right.normalized_x1 - left.normalized_x1
    translation = (
        (translation_x0 + translation_x1) / 2
        if max(abs(translation_x0), abs(translation_x1)) <= _MAXIMUM_GEOMETRY_DRIFT
        and abs(translation_x0 - translation_x1) <= maximum_axis_distance
        else 0.0
    )
    mappings = []
    for left_column, right_column in zip(left.columns, right.columns):
        left_width = left_column.normalized_x1 - left_column.normalized_x0
        right_width = right_column.normalized_x1 - right_column.normalized_x0
        axis_distance = max(
            abs(left_column.normalized_x0 - (right_column.normalized_x0 - translation)),
            abs(left_column.normalized_x1 - (right_column.normalized_x1 - translation)),
        )
        width_difference = abs(left_width - right_width) / max(left_width, right_width)
        conflicting_evidence = tuple(
            reason
            for failed, reason in (
                (
                    axis_distance > maximum_axis_distance,
                    "COLUMN_RELATIVE_AXIS_DRIFT",
                ),
                (
                    width_difference > maximum_width_ratio_difference,
                    "COLUMN_WIDTH_RATIO_DRIFT",
                ),
            )
            if failed
        )
        compatible = (
            axis_distance <= maximum_axis_distance
            and width_difference <= maximum_width_ratio_difference
        )
        mappings.append(
            PdfPhase3DColumnMapping(
                left_column_id=left_column.column_id,
                right_column_id=right_column.column_id,
                left_column_index=left_column.column_index,
                right_column_index=right_column.column_index,
                normalized_axis_distance=canonical_number(axis_distance),
                width_ratio_difference=canonical_number(width_difference),
                topology_compatible=compatible,
                evidence_strength=canonical_number(
                    max(0.0, 1.0 - axis_distance / maximum_axis_distance)
                ),
                conflicting_evidence=conflicting_evidence,
                reason_code=(
                    "NORMALIZED_COLUMN_MATCH"
                    if compatible
                    else "COLUMN_MAPPING_UNPROVEN"
                ),
            )
        )
    return tuple(mappings)


def _leading_symbolic_header_count(
    left: PdfTransitionTableFeatures,
    right: PdfTransitionTableFeatures,
) -> int:
    if (
        left.header_symbolic_signatures is None
        or right.header_symbolic_signatures is None
    ):
        return 0
    count = 0
    for left_signature, right_signature in zip(
        left.header_symbolic_signatures,
        right.header_symbolic_signatures,
    ):
        if left_signature != right_signature:
            break
        count += 1
    return count


def _header_cells_for_rows(
    features: PdfTransitionTableFeatures,
    row_ids: tuple[str, ...],
) -> tuple[str, ...]:
    if features.header_cell_ids is None:
        return ()
    memberships = dict(features.endpoint.row_cell_membership)
    selected = set(features.header_cell_ids)
    return tuple(
        cell_id
        for row_id in row_ids
        if row_id in memberships
        for cell_id in memberships[row_id]
        if cell_id in selected
    )


def _header_mapping(
    left: PdfTransitionTableFeatures,
    right: PdfTransitionTableFeatures,
    *,
    topology_compatible: bool,
) -> tuple[PdfRepeatedHeaderMapping, ...]:
    header_count = _leading_symbolic_header_count(left, right)
    if not header_count:
        return ()
    if (
        left.header_row_ids is None
        or right.header_row_ids is None
        or left.header_symbolic_signatures is None
    ):
        return ()
    left_rows = left.header_row_ids[:header_count]
    right_rows = right.header_row_ids[:header_count]
    left_cells = _header_cells_for_rows(left, left_rows)
    right_cells = _header_cells_for_rows(right, right_rows)
    if not left_cells or len(left_cells) != len(right_cells):
        return ()
    signatures = left.header_symbolic_signatures[:header_count]
    identity = "P3D-header-" + canonical_sha256(
        {
            "domain": ("document_sdk.pdf.phase3.document_table.logical_header.v1"),
            "left": signatures,
            "topology": left.topology_signature,
        }
    )
    return (
        PdfRepeatedHeaderMapping(
            logical_header_identity=identity,
            left_row_ids=left_rows,
            right_row_ids=right_rows,
            left_cell_ids=left_cells,
            right_cell_ids=right_cells,
            occurrence_index=1,
            exact_symbolic_repeat=True,
            topology_compatible=topology_compatible,
        ),
    )


def _complete_header_predicate(
    left: PdfTransitionTableFeatures,
    right: PdfTransitionTableFeatures,
    headers: tuple[PdfRepeatedHeaderMapping, ...],
    *,
    evidence_proven: bool,
) -> bool:
    return (
        evidence_proven
        and bool(headers)
        and bool(left.header_geometry_signature)
        and left.header_geometry_signature == right.header_geometry_signature
    )


def _transition_topology_compatible(
    left: PdfTransitionTableFeatures,
    right: PdfTransitionTableFeatures,
    mappings: tuple[PdfPhase3DColumnMapping, ...],
) -> bool:
    left_strategy = _canonical_strategy(left.strategy)
    right_strategy = _canonical_strategy(right.strategy)
    return (
        bool(mappings)
        and all(item.topology_compatible for item in mappings)
        and left_strategy is not None
        and left_strategy == right_strategy
        and _empty_spacer_topology_compatible(left, right)
    )


def _row_fragment(
    left: PdfTransitionTableFeatures,
    right: PdfTransitionTableFeatures,
    mappings: tuple[PdfPhase3DColumnMapping, ...],
    headers: tuple[PdfRepeatedHeaderMapping, ...],
) -> tuple[PdfRowFragmentLink, ...]:
    if not (
        left.last_row_physically_incomplete is True
        and right.first_row_fragment_compatible is True
    ):
        return ()
    if not left.last_body_cell_ids or len(left.last_body_cell_ids) != len(
        right.first_body_cell_ids
    ):
        return ()
    explicit_boundary_pair = (
        left.bottom_boundary_open is True and right.top_boundary_open is True
    )
    repeated_header_symbolic_pair = (
        bool(headers)
        and left.last_row_symbolically_incomplete is True
        and right.first_row_symbolically_compatible is True
    )
    if not (explicit_boundary_pair or repeated_header_symbolic_pair):
        return ()
    return (
        build_row_fragment_link(
            left_row_id=left.last_body_row_id,
            right_row_id=right.first_body_row_id,
            left_cell_ids=left.last_body_cell_ids,
            right_cell_ids=right.first_body_cell_ids,
            mapped_column_indexes=tuple(
                (item.left_column_index, item.right_column_index) for item in mappings
            ),
            physically_incomplete_left=True,
            physically_compatible_right=True,
        ),
    )


def _fingerprint_evidence(
    left: float | None,
    right: float | None,
) -> tuple[bool, bool, float]:
    unavailable = left is None or right is None
    negative = (left is not None and left < 0.45) or (
        right is not None and right < 0.45
    )
    support = 0.0 if left is None or right is None else min(left, right)
    return unavailable, negative, support


def _transition_limitations(
    *,
    outcome: str,
    required_input_available: bool,
    proven: bool,
    fingerprint_unavailable: bool,
) -> tuple[str, ...]:
    limitations: tuple[str, ...]
    if not required_input_available:
        limitations = ("PAIR_INPUT_UNAVAILABLE",)
    elif outcome == "CONTINUATION_PARTIAL":
        limitations = ("UPSTREAM_PHASE3C_PARTIAL",)
    elif proven:
        limitations = ()
    else:
        limitations = (outcome,)
    if fingerprint_unavailable:
        return tuple(sorted({*limitations, "FINGERPRINT_SIMILARITY_UNAVAILABLE"}))
    return limitations


def evaluate_transition_pair(
    left: PdfTransitionTableFeatures,
    right: PdfTransitionTableFeatures,
    *,
    candidate_pair_count: int = 1,
) -> PdfTablePageTransition:
    if right.endpoint.page_index != left.endpoint.page_index + 1:
        raise ValueError("candidate evaluation requires adjacent forward pages")
    mappings = map_columns(left, right)
    mappings_proven = bool(mappings) and all(
        item.topology_compatible for item in mappings
    )
    left_strategy = _canonical_strategy(left.strategy)
    right_strategy = _canonical_strategy(right.strategy)
    required_input_available = (
        left_strategy is not None
        and right_strategy is not None
        and has_required_table_topology(left)
        and has_required_table_topology(right)
    )
    topology = _transition_topology_compatible(left, right, mappings)
    x_drift = max(
        abs(left.normalized_x0 - right.normalized_x0),
        abs(left.normalized_x1 - right.normalized_x1),
    )
    geometry = x_drift <= _MAXIMUM_GEOMETRY_DRIFT
    strict_boundary = (
        left.reaches_lower_content_boundary is True
        and right.starts_near_upper_content_boundary is True
    )
    headers = _header_mapping(left, right, topology_compatible=topology)
    fragments = _row_fragment(left, right, mappings, headers) if mappings_proven else ()
    (
        fingerprint_unavailable,
        fingerprint_negative,
        fingerprint_support,
    ) = _fingerprint_evidence(
        left.fingerprint_similarity,
        right.fingerprint_similarity,
    )
    complete_header_evidence = _complete_header_predicate(
        left,
        right,
        headers,
        evidence_proven=(
            mappings_proven and geometry and topology and not fingerprint_negative
        ),
    )
    exact_boundary_terminal = (
        left.reaches_lower_content_boundary is True
        and left.terminal_boundary_closed is True
        and right.starts_near_upper_content_boundary is True
        and complete_header_evidence
    )
    boundary = strict_boundary
    boundary_negative = (
        left.reaches_lower_content_boundary is False
        or right.starts_near_upper_content_boundary is False
    )
    boundary_strength = (
        None
        if (
            not left.source_available
            or not right.source_available
            or not required_input_available
        )
        else 1.0
        if strict_boundary
        else 0.0
        if boundary_negative
        else None
    )
    complete_header_predicate = complete_header_evidence and boundary
    enclosure = right.independent_top_enclosure is True or (
        left.terminal_boundary_closed is True and not exact_boundary_terminal
    )

    if (
        not left.source_available
        or not right.source_available
        or not required_input_available
    ):
        outcome = "UNAVAILABLE_UPSTREAM"
    elif len(left.columns) != len(right.columns) or not mappings_proven:
        outcome = "COLUMN_STRUCTURE_CHANGED"
    elif enclosure:
        outcome = "NOT_CONTINUOUS"
    elif not (geometry and topology) or boundary_negative:
        outcome = "NOT_CONTINUOUS"
    elif fingerprint_negative:
        outcome = "AMBIGUOUS_CONTINUATION"
    elif (
        left.upstream_partial or right.upstream_partial
    ) and not complete_header_predicate:
        outcome = "CONTINUATION_PARTIAL"
    elif fragments:
        outcome = "SPLIT_ROW_CONTINUATION"
    elif headers:
        outcome = "REPEATED_HEADER_CONTINUATION"
    elif strict_boundary:
        outcome = "CONTINUATION_PROVEN"
    else:
        # Compatible geometry and topology are necessary but are not positive
        # cross-page continuity evidence.  Unknown boundary authority must not
        # become proof merely because no explicit negative was observed.
        outcome = "AMBIGUOUS_CONTINUATION"
    proven = outcome in {
        "CONTINUATION_PROVEN",
        "CONTINUATION_PARTIAL",
        "REPEATED_HEADER_CONTINUATION",
        "SPLIT_ROW_CONTINUATION",
    }
    limitations = _transition_limitations(
        outcome=outcome,
        required_input_available=required_input_available,
        proven=proven,
        fingerprint_unavailable=fingerprint_unavailable,
    )
    evaluated = (
        left.source_available and right.source_available and required_input_available
    )
    return build_table_page_transition(
        left=left.endpoint,
        right=right.endpoint,
        outcome=outcome,
        column_mappings=mappings if evaluated else (),
        repeated_header_mappings=headers if proven else (),
        row_fragment_links=fragments if proven else (),
        table_geometry_compatible=(
            geometry if left.source_available and right.source_available else None
        ),
        topology_compatible=topology if evaluated else None,
        page_boundary_evidence_strength=boundary_strength,
        fingerprint_support_strength=fingerprint_support,
        candidate_pair_count=candidate_pair_count,
        limitation_codes=limitations,
    )


def evaluate_adjacent_candidates(
    left_tables: tuple[PdfTransitionTableFeatures, ...],
    right_tables: tuple[PdfTransitionTableFeatures, ...],
    *,
    resource_contract: PdfPhase3DResourceContract | None = None,
) -> tuple[PdfTablePageTransition, ...]:
    contract = resource_contract or PdfPhase3DResourceContract()
    if (
        len(left_tables) > contract.maximum_tables_per_page
        or len(right_tables) > contract.maximum_tables_per_page
    ):
        raise ValueError("table candidate inventory exceeds resource contract")
    pairs = tuple(product(left_tables, right_tables))
    if len(pairs) > contract.maximum_candidate_pairs_per_transition:
        raise ValueError("candidate pair inventory exceeds resource contract")
    results = tuple(
        evaluate_transition_pair(left, right, candidate_pair_count=len(pairs))
        for left, right in pairs
    )
    proven = tuple(
        item
        for item in results
        if item.outcome
        in {
            "CONTINUATION_PROVEN",
            "CONTINUATION_PARTIAL",
            "REPEATED_HEADER_CONTINUATION",
            "SPLIT_ROW_CONTINUATION",
        }
    )
    left_counts: defaultdict[str, int] = defaultdict(int)
    right_counts: defaultdict[str, int] = defaultdict(int)
    for item in proven:
        left_counts[item.left.table_id] += 1
        right_counts[item.right.table_id] += 1
    ambiguous_left = {key for key, count in left_counts.items() if count > 1}
    ambiguous_right = {key for key, count in right_counts.items() if count > 1}
    if not ambiguous_left and not ambiguous_right:
        return results
    adjusted = []
    for item in results:
        if (
            item.left.table_id in ambiguous_left
            or item.right.table_id in ambiguous_right
        ):
            adjusted.append(
                build_table_page_transition(
                    left=item.left,
                    right=item.right,
                    outcome="MULTIPLE_CANDIDATES",
                    table_geometry_compatible=item.table_geometry_compatible,
                    topology_compatible=item.topology_compatible,
                    page_boundary_evidence_strength=(
                        item.page_boundary_evidence_strength
                    ),
                    fingerprint_support_strength=item.fingerprint_support_strength,
                    candidate_pair_count=len(pairs),
                    limitation_codes=tuple(
                        sorted(
                            {
                                *item.limitation_codes,
                                "ONE_TO_MANY_OR_MANY_TO_ONE_UNPROVEN",
                            }
                        )
                    ),
                )
            )
        else:
            adjusted.append(item)
    return tuple(adjusted)

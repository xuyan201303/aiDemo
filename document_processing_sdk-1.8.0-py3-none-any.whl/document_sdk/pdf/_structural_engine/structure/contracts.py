# ruff: noqa: EM101, PLR2004, TC001, TRY003, UP037

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from document_sdk.pdf._structural_engine.facts.contracts import PdfBoundingBox

PDF_STRUCTURAL_DOCUMENT_SCHEMA_VERSION = "pdf_structural_document.v1"
PDF_STRUCTURE_ALGORITHM_NAME: Literal["aiventra_pdf_structure_bridge"] = (
    "aiventra_pdf_structure_bridge"
)
PDF_STRUCTURE_ALGORITHM_VERSION: Literal["3a.1"] = "3a.1"
PDF_STRUCTURE_MODE: Literal["pdf_structure_v1"] = "pdf_structure_v1"
PDF_REJECTED_HIERARCHY_EVIDENCE_SCHEMA_VERSION = "pdf_rejected_hierarchy_evidence.v1"

PdfStructureState = Literal[
    "complete", "partial", "review_required", "unsupported", "unavailable"
]
PdfStructureConfidence = Literal["high", "medium", "low"]


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class PdfStructureEvidence(_FrozenModel):
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_ids: tuple[str, ...]
    page_numbers: tuple[int, ...]
    member_fact_ids: tuple[str, ...] = ()
    geometry: PdfBoundingBox | None = None
    layout_graph_id: str = Field(pattern=r"^PDFLG-[0-9a-f]{24}$")
    layout_graph_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    layout_node_ids: tuple[str, ...] = ()
    relation_edge_ids: tuple[str, ...] = ()
    separator_candidate_ids: tuple[str, ...] = ()
    ctif_evidence_digests: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_evidence(self) -> "PdfStructureEvidence":
        ordered_sets = (
            self.member_fact_ids,
            self.layout_node_ids,
            self.relation_edge_ids,
            self.separator_candidate_ids,
            self.ctif_evidence_digests,
        )
        if any(items != tuple(sorted(set(items))) for items in ordered_sets):
            raise ValueError("structural evidence sets must be sorted and unique")
        if len(self.page_ids) != len(self.page_numbers) or not self.page_ids:
            raise ValueError("page IDs and page numbers require a non-empty pairing")
        if self.page_numbers != tuple(sorted(set(self.page_numbers))):
            raise ValueError("page numbers must be sorted and unique")
        if any(number < 1 for number in self.page_numbers):
            raise ValueError("page numbers must be positive")
        if any(not value.startswith("PDFP-") for value in self.page_ids):
            raise ValueError("structural evidence requires Phase 1 Page IDs")
        if any(not value.startswith("PDFF-") for value in self.member_fact_ids):
            raise ValueError("structural evidence requires Phase 1 Fact IDs")
        if any(len(value) != 64 for value in self.ctif_evidence_digests):
            raise ValueError("CTIF evidence references must be SHA-256 digests")
        return self


class PdfStructureSourceReference(_FrozenModel):
    source_reference_id: str = Field(pattern=r"^P3S-source-reference-[0-9a-f]{64}$")
    structural_entity_id: str = Field(pattern=r"^P3S-[a-z0-9-]+-[0-9a-f]{64}$")
    evidence: PdfStructureEvidence


class PdfStructureProvenance(_FrozenModel):
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    fact_artifact_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    layout_graph_id: str = Field(pattern=r"^PDFLG-[0-9a-f]{24}$")
    layout_graph_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    ctif_evidence_digests: tuple[str, ...] = ()
    algorithm_name: Literal["aiventra_pdf_structure_bridge"] = (
        PDF_STRUCTURE_ALGORITHM_NAME
    )
    algorithm_version: Literal["3a.1", "3b.1"] = PDF_STRUCTURE_ALGORITHM_VERSION
    configuration_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    parser_name: str = Field(min_length=1, max_length=64)
    parser_version: str = Field(min_length=1, max_length=64)
    safe_runtime_operation: Literal["pdf_structure_v1"] = PDF_STRUCTURE_MODE
    safe_runtime_version: str = Field(min_length=1, max_length=64)

    @model_validator(mode="after")
    def validate_ctif_order(self) -> "PdfStructureProvenance":
        if self.ctif_evidence_digests != tuple(sorted(set(self.ctif_evidence_digests))):
            raise ValueError("CTIF evidence digests must be sorted and unique")
        return self


class PdfStructureLimitation(_FrozenModel):
    code: str = Field(pattern=r"^[a-z0-9_]+$", max_length=96)
    capability: str = Field(pattern=r"^[a-z0-9_]+$", max_length=64)
    state: Literal["partial", "unsupported", "unavailable"]
    affected_entity_ids: tuple[str, ...] = ()
    evidence: tuple[str, ...] = ()


class PdfStructureReviewRequirement(_FrozenModel):
    code: str = Field(pattern=r"^[a-z0-9_]+$", max_length=96)
    capability: str = Field(pattern=r"^[a-z0-9_]+$", max_length=64)
    affected_entity_ids: tuple[str, ...]
    candidate_entity_ids: tuple[str, ...] = ()
    evidence: tuple[str, ...]
    allowed_action: Literal["manual_review"] = "manual_review"


class PdfCapabilityPlaceholder(_FrozenModel):
    state: PdfStructureState
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def require_limitation(self) -> "PdfCapabilityPlaceholder":
        if self.state != "complete" and not self.limitation_codes:
            raise ValueError("non-complete capability requires a limitation")
        if self.limitation_codes != tuple(sorted(set(self.limitation_codes))):
            raise ValueError("limitation codes must be sorted and unique")
        return self


class PdfStructuralBlock(_FrozenModel):
    structural_id: str = Field(pattern=r"^P3S-block-[0-9a-f]{64}$")
    block_kind: Literal[
        "paragraph",
        "heading",
        "heading_candidate",
        "list",
        "list_item",
        "caption",
        "caption_candidate",
        "page_header_candidate",
        "page_footer_candidate",
        "footnote_candidate",
        "region",
        "generic_region",
        "unsupported_region",
        "unknown",
    ]
    state: PdfStructureState
    confidence: PdfStructureConfidence
    evidence: PdfStructureEvidence
    provenance: PdfStructureProvenance
    member_line_node_ids: tuple[str, ...] = ()
    grouping_evidence: tuple[str, ...] = ()
    role_evidence: tuple[str, ...] = ()
    reading_order_position: int | None = Field(default=None, ge=0)
    limitation_codes: tuple[str, ...] = ()


class PdfReadingOrderEdge(_FrozenModel):
    edge_id: str = Field(pattern=r"^P3S-order-edge-[0-9a-f]{64}$")
    predecessor_entity_id: str
    successor_entity_id: str
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    supporting_evidence_types: tuple[str, ...]
    supporting_fact_ids: tuple[str, ...]
    supporting_layout_relation_ids: tuple[str, ...] = ()
    separator_candidate_ids: tuple[str, ...] = ()
    orientation: Literal["page_axis", "rotated_axis", "unknown"]
    strategy_version: str = Field(min_length=1, max_length=64)
    configuration_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    decision_status: Literal["proven", "candidate", "rejected", "unresolved"]
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_edge(self) -> "PdfReadingOrderEdge":
        if self.predecessor_entity_id == self.successor_entity_id:
            raise ValueError("reading-order self edge is prohibited")
        for items in (
            self.supporting_evidence_types,
            self.supporting_fact_ids,
            self.supporting_layout_relation_ids,
            self.separator_candidate_ids,
            self.limitation_codes,
        ):
            if items != tuple(sorted(set(items))):
                raise ValueError("reading-order evidence sets must be canonical")
        if self.decision_status == "proven" and len(self.supporting_evidence_types) < 2:
            raise ValueError("proven precedence requires independent evidence")
        return self


class PdfReadingOrder(_FrozenModel):
    structural_id: str | None = Field(
        default=None, pattern=r"^P3S-reading-order-[0-9a-f]{64}$"
    )
    state: PdfStructureState
    ordered_entity_ids: tuple[str, ...] = ()
    limitation_codes: tuple[str, ...] = ()
    edges: tuple[PdfReadingOrderEdge, ...] = ()
    unresolved_components: tuple[tuple[str, ...], ...] = ()

    @model_validator(mode="after")
    def validate_state(self) -> "PdfReadingOrder":
        if self.state == "complete" and self.structural_id is None:
            raise ValueError("complete reading order requires identity")
        if self.state != "complete" and not self.limitation_codes:
            raise ValueError("unproven reading order requires a limitation")
        return self


class PdfStructuralHierarchy(PdfReadingOrder):
    structural_id: str | None = Field(
        default=None, pattern=r"^P3S-hierarchy-[0-9a-f]{64}$"
    )
    ordered_entity_ids: tuple[str, ...] = ()
    relations: tuple["PdfHierarchyRelation", ...] = ()


class PdfHierarchyRelation(_FrozenModel):
    relation_id: str = Field(pattern=r"^P3S-hierarchy-edge-[0-9a-f]{64}$")
    parent_structural_id: str
    child_structural_id: str
    relation_type: Literal[
        "document_contains_page", "page_contains_block", "section_contains_block"
    ]
    supporting_evidence: tuple[str, ...]
    level_evidence: tuple[str, ...] = ()
    page_ids: tuple[str, ...]
    order_range: tuple[int, int]
    status: Literal["proven", "review_required"]
    limitation_codes: tuple[str, ...] = ()
    algorithm_version: Literal["3b.1"] = "3b.1"
    configuration_identity: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_relation(self) -> "PdfHierarchyRelation":
        if self.parent_structural_id == self.child_structural_id:
            raise ValueError("hierarchy self edge is prohibited")
        if self.order_range[0] < 0 or self.order_range[1] < self.order_range[0]:
            raise ValueError("hierarchy order range is invalid")
        if self.status == "proven" and not self.supporting_evidence:
            raise ValueError("proven hierarchy requires evidence")
        return self


PdfHierarchyRejectionType = Literal[
    "cycle_edge",
    "duplicate_parent",
    "cross_source",
    "cross_document",
    "invalid_level_transition",
    "outside_parent_order_range",
    "insufficient_evidence",
    "conflicting_evidence",
    "stale_reference",
    "invalid_identity",
]


class PdfCrossPageContinuation(_FrozenModel):
    structural_id: str = Field(pattern=r"^P3S-continuation-[0-9a-f]{64}$")
    source_entity_id: str
    target_entity_id: str
    state: Literal["complete", "review_required"]
    evidence: PdfStructureEvidence
    provenance: PdfStructureProvenance


class PdfStructuredRecord(_FrozenModel):
    structural_id: str = Field(pattern=r"^P3S-record-[0-9a-f]{64}$")
    state: PdfStructureState
    member_entity_ids: tuple[str, ...]
    evidence: PdfStructureEvidence
    provenance: PdfStructureProvenance

# ruff: noqa: EM101, N818, PLR0913, RUF005, TRY003, UP037

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .identity import canonical_json_bytes, canonical_sha256

PDF_PHASE3BR_RESOURCE_CONTRACT_VERSION: Literal["pdf_phase3br_resource_contract.v1"] = (
    "pdf_phase3br_resource_contract.v1"
)
PDF_PHASE3BR_CHECKPOINT_VERSION = "pdf_phase3br_checkpoint.v1"
PDF_PHASE3BR_SAFE_RSS_CEILING_BYTES = 768 * 1024 * 1024
PDF_PHASE3BR_HARD_RSS_BUDGET_BYTES = 1024 * 1024 * 1024
PDF_PHASE3BR_PAGE_WORKSPACE_CEILING_BYTES = 128 * 1024 * 1024
PDF_PHASE3BR_FRONTIER_CEILING_BYTES = 8 * 1024 * 1024
PDF_PHASE3BR_MAX_FRONTIER_PAGES = 4096


class BoundedResourceViolation(RuntimeError):
    pass


class BoundedStageIntegrityError(RuntimeError):
    pass


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class PdfPhase3BrResourceContract(_FrozenModel):
    schema_version: Literal["pdf_phase3br_resource_contract.v1"] = (
        PDF_PHASE3BR_RESOURCE_CONTRACT_VERSION
    )
    hard_rss_budget_bytes: int = PDF_PHASE3BR_HARD_RSS_BUDGET_BYTES
    safe_live_child_aggregate_ceiling_bytes: int = PDF_PHASE3BR_SAFE_RSS_CEILING_BYTES
    page_workspace_ceiling_bytes: int = PDF_PHASE3BR_PAGE_WORKSPACE_CEILING_BYTES
    compact_frontier_ceiling_bytes: int = PDF_PHASE3BR_FRONTIER_CEILING_BYTES
    maximum_frontier_pages: int = PDF_PHASE3BR_MAX_FRONTIER_PAGES

    @model_validator(mode="after")
    def validate_ceilings(self) -> "PdfPhase3BrResourceContract":
        if not (
            self.page_workspace_ceiling_bytes
            < self.safe_live_child_aggregate_ceiling_bytes
            < self.hard_rss_budget_bytes
        ):
            raise ValueError("resource ceilings must preserve hard-budget headroom")
        if self.compact_frontier_ceiling_bytes >= self.page_workspace_ceiling_bytes:
            raise ValueError("compact frontier must be smaller than page workspace")
        return self

    @property
    def identity(self) -> str:
        return canonical_sha256(self)


class PdfPhase3BrStagedPage(_FrozenModel):
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    page_number: int = Field(gt=0)
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_input_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_result_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    staged_payload_bytes: int = Field(ge=0)
    workspace_peak_bytes: int = Field(ge=0)
    limitation_codes: tuple[str, ...] = ()


class PdfPhase3BrCompactFrontier(_FrozenModel):
    resource_contract_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    pages: tuple[PdfPhase3BrStagedPage, ...] = ()
    unresolved_hierarchy_candidate_ids: tuple[str, ...] = ()
    continuation_metadata_hashes: tuple[str, ...] = ()
    state: Literal["partial", "review_required", "complete"] = "partial"

    @model_validator(mode="after")
    def validate_frontier(self) -> "PdfPhase3BrCompactFrontier":
        numbers = tuple(item.page_number for item in self.pages)
        if numbers != tuple(sorted(set(numbers))):
            raise ValueError("frontier pages must be canonical")
        for values in (
            self.unresolved_hierarchy_candidate_ids,
            self.continuation_metadata_hashes,
        ):
            if values != tuple(sorted(set(values))):
                raise ValueError("frontier collections must be canonical")
        return self

    @property
    def identity(self) -> str:
        return canonical_sha256(self)


def page_input_identity(
    *,
    source_sha256: str,
    page_id: str,
    page_number: int,
    dependency_identity: str,
    configuration_identity: str,
    resource_contract_identity: str,
) -> str:
    return canonical_sha256(
        {
            "domain": "aiventra.phase3br.page-input.v1",
            "source_sha256": source_sha256,
            "page_id": page_id,
            "page_number": page_number,
            "dependency_identity": dependency_identity,
            "configuration_identity": configuration_identity,
            "resource_contract_identity": resource_contract_identity,
        }
    )


def add_staged_page(
    *,
    frontier: PdfPhase3BrCompactFrontier,
    page: PdfPhase3BrStagedPage,
    contract: PdfPhase3BrResourceContract,
) -> PdfPhase3BrCompactFrontier:
    if page.workspace_peak_bytes > contract.page_workspace_ceiling_bytes:
        raise BoundedResourceViolation("page_workspace_ceiling_exceeded")
    pages = frontier.pages + (page,)
    if len(pages) > contract.maximum_frontier_pages:
        raise BoundedResourceViolation("compact_frontier_cardinality_exceeded")
    result = frontier.model_copy(update={"pages": pages})
    if len(canonical_json_bytes(result)) > contract.compact_frontier_ceiling_bytes:
        raise BoundedResourceViolation("compact_frontier_byte_ceiling_exceeded")
    return PdfPhase3BrCompactFrontier.model_validate(result)

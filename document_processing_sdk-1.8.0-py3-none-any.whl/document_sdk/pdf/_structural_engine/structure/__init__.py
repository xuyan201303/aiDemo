"""Private PDF structure and reading foundation."""

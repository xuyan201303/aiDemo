# ruff: noqa: C901, EM101, PLR0913, TRY003

from __future__ import annotations

from typing import Any, Literal, Self

from pydantic import BaseModel, ConfigDict, Field, ValidationError, model_validator

from . import document_table_contracts as _contracts
from . import document_table_transition as _transition
from . import table_document_manifest as _manifest
from .identity import canonical_json_size, canonical_number, canonical_sha256

PdfTablePageTransition = _contracts.PdfTablePageTransition
PdfTransitionTableFeatures = _transition.PdfTransitionTableFeatures
build_document_identity = _manifest.build_document_identity

PDF_DOCUMENT_TABLE_FINGERPRINT_FEATURE_VERSION = (
    "document_sdk_pdf_document_table_transition_fingerprint_features.v2"
)
FEATURE_SCHEMA_VERSION = PDF_DOCUMENT_TABLE_FINGERPRINT_FEATURE_VERSION

_ARTIFACT_SCHEMA_VERSION = "document_sdk_pdf_document_table_transition_fingerprint.v2"
_COMPARISON_SCHEMA_VERSION = "document_sdk_pdf_document_table_fingerprint_comparison.v1"
_ARTIFACT_IDENTITY_DOMAIN = (
    "document_sdk.pdf.phase3.document_table.fingerprint.artifact.v2"
)
_SEMANTIC_IDENTITY_DOMAIN = (
    "document_sdk.pdf.phase3.document_table.fingerprint.semantic.v2"
)
_RESOURCE_ERROR = "transition fingerprint resource contract exceeded"
_DEPENDENCY_ERROR = "transition fingerprint dependency is stale or mismatched"
_INPUT_ERROR = "transition fingerprint input authority is stale or mismatched"
_INPUT_UNAVAILABLE = "transition fingerprint required authority is unavailable"
_MAXIMUM_SERIALIZED_BYTES = 524288
_MAXIMUM_REVALIDATION_DEPTH = 64
_PARTIAL_SAFETY_SCORE = 0.5
_LINKING_TRANSITION_OUTCOMES = {
    "CONTINUATION_PROVEN",
    "CONTINUATION_PARTIAL",
    "REPEATED_HEADER_CONTINUATION",
    "SPLIT_ROW_CONTINUATION",
}


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)


def _id(kind: Literal["transition", "semantic"], payload: object) -> str:
    domain = (
        _ARTIFACT_IDENTITY_DOMAIN if kind == "transition" else _SEMANTIC_IDENTITY_DOMAIN
    )
    return f"P3D-XFP-{kind}-" + canonical_sha256({"domain": domain, "payload": payload})


def _revalidation_payload(
    value: object,
    active_container_ids: set[int] | None = None,
    depth: int = 0,
) -> object:
    if depth > _MAXIMUM_REVALIDATION_DEPTH:
        return {"__maximum_revalidation_depth_exceeded__": True}
    if not isinstance(value, (BaseModel, tuple, list, dict)):
        return value
    active = active_container_ids if active_container_ids is not None else set()
    value_id = id(value)
    if value_id in active:
        return {"__cyclic_revalidation_input__": True}
    active.add(value_id)
    try:
        if isinstance(value, BaseModel):
            field_names = set(type(value).model_fields)
            state = {
                key: _revalidation_payload(item, active, depth + 1)
                for key, item in value.__dict__.items()
                if key in field_names
            }
            if set(value.__dict__) - field_names or value.__pydantic_extra__:
                state["__pydantic_extra_present__"] = True
            return state
        if isinstance(value, (tuple, list)):
            items = [_revalidation_payload(item, active, depth + 1) for item in value]
            return tuple(items) if isinstance(value, tuple) else items
        return {
            key: _revalidation_payload(item, active, depth + 1)
            for key, item in value.items()
        }
    finally:
        active.remove(value_id)


class PdfTransitionPagePairGeometry(_FrozenModel):
    orientation_relationship: Literal[
        "SAME", "NORMALIZED_ROTATION", "INCOMPATIBLE", "UNAVAILABLE"
    ]
    normalized_table_width_drift: float | None = Field(default=None, ge=0)
    normalized_margin_drift: float | None = Field(default=None, ge=0)
    margin_similarity: float | None = Field(default=None, ge=0, le=1)
    left_lower_boundary_proximity: float | None = Field(default=None, ge=0, le=1)
    right_upper_boundary_proximity: float | None = Field(default=None, ge=0, le=1)
    boundary_proximity: float | None = Field(default=None, ge=0, le=1)
    orientation_similarity: float | None = Field(default=None, ge=0, le=1)
    left_bottom_enclosure: Literal["OPEN", "CLOSED", "PARTIAL", "UNAVAILABLE"]
    right_top_enclosure: Literal["OPEN", "CLOSED", "PARTIAL", "UNAVAILABLE"]


class PdfTransitionColumnContinuity(_FrozenModel):
    left_column_count: int = Field(ge=0)
    right_column_count: int = Field(ge=0)
    normalized_axis_distances: tuple[float, ...] = ()
    column_width_ratio_drifts: tuple[float, ...] = ()
    inserted_column_count: int = Field(ge=0)
    removed_column_count: int = Field(ge=0)
    empty_spacer_column_continuity: Literal["SAME", "CHANGED", "ABSENT", "UNAVAILABLE"]
    mapping_completeness: float | None = Field(default=None, ge=0, le=1)
    mapping_ambiguous: bool | None
    topology_hard_difference: bool | None


class PdfTransitionHeaderContinuity(_FrozenModel):
    repeated_header_present: bool | None
    repeated_header_depth: int | None = Field(default=None, ge=0)
    header_pattern: Literal["NONE", "ONE_ROW", "MULTI_ROW", "UNAVAILABLE"]
    merged_header_topology_signature: str | None = Field(default=None, max_length=128)
    normalized_header_geometry_signature: tuple[float, ...] | None = None
    header_geometry_signature: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )
    symbolic_repetition: Literal["EXACT", "NEAR", "NONE", "UNAVAILABLE"]
    repeated_occurrence_count: int | None = Field(default=None, ge=0)
    body_start_offset: int | None = Field(default=None, ge=0)


class PdfTransitionRowCellContinuity(_FrozenModel):
    split_row_present: bool | None
    split_cell_present: bool | None
    open_last_row: bool | None
    open_first_row: bool | None
    fragment_count: int | None = Field(default=None, ge=0)
    mapped_column_fragment_distribution: tuple[int, ...] | None = None
    multiline_continuation: bool | None
    local_text_order_continuous: bool | None
    ambiguous_fragment_count: int | None = Field(default=None, ge=0)


class PdfTransitionPairContext(_FrozenModel):
    left_table_count: int = Field(ge=0)
    right_table_count: int = Field(ge=0)
    candidate_pair_count: int = Field(ge=0)
    selected_pair_rank: int | None = Field(default=None, ge=1)
    multiple_table_transition: bool
    predecessor_exclusive: bool
    successor_exclusive: bool
    continuation_outcome: str = Field(min_length=1, max_length=64)
    conflicting_evidence_groups: tuple[str, ...] = ()
    typed_downgrade_reason: str | None = Field(default=None, max_length=128)


class PdfTransitionSafetyState(_FrozenModel):
    source_capability_state: Literal[
        "RELIABLE", "PARTIAL", "IMAGE_ONLY", "LEGACY", "UNAVAILABLE"
    ]
    runtime_truncated: bool | None
    dependency_state: Literal["CURRENT", "STALE", "MISSING", "UNAVAILABLE"]
    evidence_complete: bool
    safety_score: float | None = Field(default=None, ge=0, le=1)


def _features_have_complete_optional_authority(
    features: PdfTransitionTableFeatures,
) -> bool:
    scalar_values = (
        features.normalized_upper_gap,
        features.normalized_lower_gap,
        features.header_row_ids,
        features.header_cell_ids,
        features.header_symbolic_signatures,
        features.header_geometry_signature,
        features.reaches_lower_content_boundary,
        features.starts_near_upper_content_boundary,
        features.bottom_boundary_open,
        features.top_boundary_open,
        features.terminal_boundary_closed,
        features.independent_top_enclosure,
        features.last_row_physically_incomplete,
        features.first_row_fragment_compatible,
        features.last_row_symbolically_incomplete,
        features.first_row_symbolically_compatible,
        features.fingerprint_similarity,
    )
    spacer_states = features.empty_spacer_column_states
    return (
        not any(value is None for value in scalar_values)
        and spacer_states is not None
        and not any(value is None for value in spacer_states)
    )


def _mapped_optional_dimensions_available(
    *,
    page_pair_geometry: PdfTransitionPagePairGeometry,
    column_continuity: PdfTransitionColumnContinuity,
    header_continuity: PdfTransitionHeaderContinuity,
    row_cell_continuity: PdfTransitionRowCellContinuity,
) -> bool:
    page_values = (
        page_pair_geometry.normalized_table_width_drift,
        page_pair_geometry.normalized_margin_drift,
        page_pair_geometry.margin_similarity,
        page_pair_geometry.left_lower_boundary_proximity,
        page_pair_geometry.right_upper_boundary_proximity,
        page_pair_geometry.boundary_proximity,
        page_pair_geometry.orientation_similarity,
    )
    column_values = (
        column_continuity.mapping_completeness,
        column_continuity.mapping_ambiguous,
        column_continuity.topology_hard_difference,
    )
    header_values = (
        header_continuity.repeated_header_present,
        header_continuity.repeated_header_depth,
        header_continuity.repeated_occurrence_count,
        header_continuity.body_start_offset,
    )
    row_values = (
        row_cell_continuity.split_row_present,
        row_cell_continuity.split_cell_present,
        row_cell_continuity.open_last_row,
        row_cell_continuity.open_first_row,
        row_cell_continuity.fragment_count,
        row_cell_continuity.mapped_column_fragment_distribution,
        row_cell_continuity.multiline_continuation,
        row_cell_continuity.ambiguous_fragment_count,
    )
    header_geometry_available = (
        header_continuity.normalized_header_geometry_signature is not None
        or header_continuity.header_geometry_signature is not None
    )
    local_order_available = (
        row_cell_continuity.split_row_present is False
        or row_cell_continuity.local_text_order_continuous is not None
    )
    return (
        not any(value is None for value in page_values)
        and page_pair_geometry.orientation_relationship != "UNAVAILABLE"
        and page_pair_geometry.left_bottom_enclosure != "UNAVAILABLE"
        and page_pair_geometry.right_top_enclosure != "UNAVAILABLE"
        and not any(value is None for value in column_values)
        and column_continuity.empty_spacer_column_continuity != "UNAVAILABLE"
        and not any(value is None for value in header_values)
        and header_continuity.header_pattern != "UNAVAILABLE"
        and header_continuity.symbolic_repetition != "UNAVAILABLE"
        and header_geometry_available
        and not any(value is None for value in row_values)
        and local_order_available
    )


def _unavailable_feature_dimensions_are_neutral(
    *,
    page_pair_geometry: PdfTransitionPagePairGeometry,
    column_continuity: PdfTransitionColumnContinuity,
    header_continuity: PdfTransitionHeaderContinuity,
    row_cell_continuity: PdfTransitionRowCellContinuity,
) -> bool:
    return (
        page_pair_geometry
        == PdfTransitionPagePairGeometry(
            orientation_relationship="UNAVAILABLE",
            left_bottom_enclosure="UNAVAILABLE",
            right_top_enclosure="UNAVAILABLE",
        )
        and column_continuity
        == PdfTransitionColumnContinuity(
            left_column_count=0,
            right_column_count=0,
            inserted_column_count=0,
            removed_column_count=0,
            empty_spacer_column_continuity="UNAVAILABLE",
            mapping_ambiguous=None,
            topology_hard_difference=None,
        )
        and header_continuity
        == PdfTransitionHeaderContinuity(
            repeated_header_present=None,
            header_pattern="UNAVAILABLE",
            symbolic_repetition="UNAVAILABLE",
        )
        and row_cell_continuity
        == PdfTransitionRowCellContinuity(
            split_row_present=None,
            split_cell_present=None,
            open_last_row=None,
            open_first_row=None,
            multiline_continuation=None,
            local_text_order_continuous=None,
        )
    )


class PdfTransitionFingerprintInputAuthority(_FrozenModel):
    """Bound, PDF-free inputs required for one mechanical DT1 projection."""

    features: PdfTransitionTableFeatures
    page_width: float = Field(gt=0)
    page_height: float = Field(gt=0)
    table_x0: float = Field(ge=0)
    table_y0: float = Field(ge=0)
    table_x1: float = Field(gt=0)
    table_y1: float = Field(gt=0)
    table_state: Literal["COMPLETE", "PARTIAL"]
    required_authority_available: bool
    optional_authority_available: bool
    runtime_truncated: bool | None
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_bound_geometry(self) -> Self:
        if (
            self.table_x0 >= self.table_x1
            or self.table_y0 >= self.table_y1
            or self.table_x1 > self.page_width
            or self.table_y1 > self.page_height
        ):
            raise ValueError(_INPUT_ERROR)
        expected = tuple(
            canonical_number(value)
            for value in (
                self.table_x0 / self.page_width,
                self.table_y0 / self.page_height,
                self.table_x1 / self.page_width,
                self.table_y1 / self.page_height,
            )
        )
        observed = tuple(
            canonical_number(value)
            for value in (
                self.features.normalized_x0,
                self.features.normalized_y0,
                self.features.normalized_x1,
                self.features.normalized_y1,
            )
        )
        if observed != expected:
            raise ValueError(_INPUT_ERROR)
        if self.features.rotation_degrees % 360 not in {0, 90, 180, 270}:
            raise ValueError(_INPUT_ERROR)
        if self.limitation_codes != tuple(sorted(set(self.limitation_codes))):
            raise ValueError(_INPUT_ERROR)
        strategy = self.features.strategy
        canonical_strategy = (
            strategy.strip().casefold() if strategy is not None else None
        )
        required_features_available = (
            self.features.source_available
            and canonical_strategy in {"ruled", "borderless"}
            and bool(self.features.columns)
            and _transition.has_required_table_topology(self.features)
        )
        if self.required_authority_available and not required_features_available:
            raise ValueError(_INPUT_ERROR)
        if self.optional_authority_available and (
            not _features_have_complete_optional_authority(self.features)
            or bool(self.limitation_codes)
        ):
            raise ValueError(_INPUT_ERROR)
        return self


class PdfTransitionFingerprintResourceContract(_FrozenModel):
    schema_version: Literal[
        "document_sdk_pdf_document_table_transition_fingerprint_resource.v1"
    ] = "document_sdk_pdf_document_table_transition_fingerprint_resource.v1"
    maximum_columns: int = Field(default=64, ge=1, le=64)
    maximum_axis_values: int = Field(default=128, ge=1, le=128)
    maximum_header_geometry_values: int = Field(default=256, ge=1, le=256)
    maximum_fragment_distribution_values: int = Field(default=128, ge=1, le=128)
    maximum_conflicting_evidence_groups: int = Field(default=64, ge=1, le=64)
    maximum_limitation_codes: int = Field(default=64, ge=1, le=64)
    maximum_serialized_bytes: int = Field(default=524288, ge=1024, le=524288)


class PdfTableTransitionFingerprint(_FrozenModel):
    schema_version: Literal[
        "document_sdk_pdf_document_table_transition_fingerprint.v2"
    ] = _ARTIFACT_SCHEMA_VERSION  # type: ignore[assignment]
    feature_schema_version: Literal[
        "document_sdk_pdf_document_table_transition_fingerprint_features.v2"
    ] = FEATURE_SCHEMA_VERSION  # type: ignore[assignment]
    fingerprint_id: str = Field(pattern=r"^P3D-XFP-transition-[0-9a-f]{64}$")
    semantic_fingerprint_identity: str = Field(
        pattern=r"^P3D-XFP-semantic-[0-9a-f]{64}$"
    )
    state: Literal["AVAILABLE", "PARTIAL", "UNSUPPORTED", "UNAVAILABLE"]
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    document_identity: str = Field(pattern=r"^P3D-document-[0-9a-f]{64}$")
    page_table_manifest_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    transition_id: str = Field(pattern=r"^P3D-transition-[0-9a-f]{64}$")
    left_page_index: int = Field(ge=0)
    right_page_index: int = Field(ge=0)
    left_page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    right_page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    left_table_id: str = Field(pattern=r"^P3C-table-[0-9a-f]{64}$")
    right_table_id: str = Field(pattern=r"^P3C-table-[0-9a-f]{64}$")
    left_table_sidecar_id: str = Field(pattern=r"^P3C-table-page-[0-9a-f]{64}$")
    right_table_sidecar_id: str = Field(pattern=r"^P3C-table-page-[0-9a-f]{64}$")
    left_table_sidecar_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    right_table_sidecar_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    left_configuration_identity: str | None = Field(
        default=None, pattern=r"^[0-9a-f]{64}$"
    )
    right_configuration_identity: str | None = Field(
        default=None, pattern=r"^[0-9a-f]{64}$"
    )
    left_dependency_identity: str | None = Field(
        default=None, pattern=r"^[0-9a-f]{64}$"
    )
    right_dependency_identity: str | None = Field(
        default=None, pattern=r"^[0-9a-f]{64}$"
    )
    page_pair_geometry: PdfTransitionPagePairGeometry
    column_continuity: PdfTransitionColumnContinuity
    header_continuity: PdfTransitionHeaderContinuity
    row_cell_continuity: PdfTransitionRowCellContinuity
    pair_context: PdfTransitionPairContext
    safety_state: PdfTransitionSafetyState
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_fingerprint(self) -> PdfTableTransitionFingerprint:
        if self.right_page_index != self.left_page_index + 1:
            raise ValueError("transition fingerprint pages are not adjacent")
        if (
            self.left_page_id == self.right_page_id
            or self.left_table_id == self.right_table_id
        ):
            raise ValueError("transition fingerprint repeats page-local identity")
        expected_document = build_document_identity(
            source_sha256=self.source_sha256,
            page_table_manifest_sha256=self.page_table_manifest_sha256,
        )
        if self.document_identity != expected_document:
            raise ValueError("transition fingerprint document identity mismatch")
        if self.limitation_codes != tuple(sorted(set(self.limitation_codes))):
            raise ValueError(
                "transition fingerprint limitations must be sorted and unique"
            )
        if self.state == "AVAILABLE" and (
            self.safety_state.dependency_state != "CURRENT"
            or self.safety_state.source_capability_state != "RELIABLE"
            or self.safety_state.runtime_truncated is not False
            or not self.safety_state.evidence_complete
            or self.safety_state.safety_score != 1.0
            or bool(self.limitation_codes)
            or not _mapped_optional_dimensions_available(
                page_pair_geometry=self.page_pair_geometry,
                column_continuity=self.column_continuity,
                header_continuity=self.header_continuity,
                row_cell_continuity=self.row_cell_continuity,
            )
        ):
            raise ValueError("available fingerprint requires current complete evidence")
        if self.state == "PARTIAL" and (
            self.safety_state.dependency_state != "CURRENT"
            or self.safety_state.evidence_complete
            or self.safety_state.safety_score != _PARTIAL_SAFETY_SCORE
            or not self.limitation_codes
        ):
            raise ValueError("partial fingerprint requires current limited evidence")
        if self.state in {"UNSUPPORTED", "UNAVAILABLE"} and (
            not _unavailable_feature_dimensions_are_neutral(
                page_pair_geometry=self.page_pair_geometry,
                column_continuity=self.column_continuity,
                header_continuity=self.header_continuity,
                row_cell_continuity=self.row_cell_continuity,
            )
            or self.safety_state.evidence_complete
            or self.safety_state.safety_score is not None
            or not self.limitation_codes
        ):
            raise ValueError(
                "unavailable fingerprint cannot fabricate structural features"
            )
        expected_semantic = _id("semantic", _semantic_payload(self))
        if self.semantic_fingerprint_identity != expected_semantic:
            raise ValueError("transition semantic fingerprint identity mismatch")
        expected = _id("transition", self.model_dump(exclude={"fingerprint_id"}))
        if self.fingerprint_id != expected:
            raise ValueError("transition fingerprint artifact identity mismatch")
        if canonical_json_size(self) > _MAXIMUM_SERIALIZED_BYTES:
            raise ValueError(_RESOURCE_ERROR)
        return self


def _semantic_payload(value: PdfTableTransitionFingerprint) -> dict[str, object]:
    return {
        "feature_schema_version": value.feature_schema_version,
        "state": value.state,
        "page_pair_geometry": value.page_pair_geometry,
        "column_continuity": value.column_continuity,
        "header_continuity": value.header_continuity,
        "row_cell_continuity": value.row_cell_continuity,
        "pair_context": value.pair_context,
        "safety_state": value.safety_state,
        "limitation_codes": value.limitation_codes,
    }


def _validate_resource_inventories(
    *,
    column_continuity: PdfTransitionColumnContinuity,
    header_continuity: PdfTransitionHeaderContinuity,
    row_cell_continuity: PdfTransitionRowCellContinuity,
    pair_context: PdfTransitionPairContext,
    limitation_codes: tuple[str, ...],
    resource_contract: PdfTransitionFingerprintResourceContract,
) -> None:
    exceeds = (
        column_continuity.left_column_count > resource_contract.maximum_columns
        or column_continuity.right_column_count > resource_contract.maximum_columns
        or len(column_continuity.normalized_axis_distances)
        > resource_contract.maximum_axis_values
        or len(column_continuity.column_width_ratio_drifts)
        > resource_contract.maximum_axis_values
        or len(header_continuity.normalized_header_geometry_signature or ())
        > resource_contract.maximum_header_geometry_values
        or len(row_cell_continuity.mapped_column_fragment_distribution or ())
        > resource_contract.maximum_fragment_distribution_values
        or len(pair_context.conflicting_evidence_groups)
        > resource_contract.maximum_conflicting_evidence_groups
        or len(limitation_codes) > resource_contract.maximum_limitation_codes
    )
    if exceeds:
        raise ValueError(_RESOURCE_ERROR)


def build_transition_fingerprint(
    *,
    transition: PdfTablePageTransition,
    state: Literal["AVAILABLE", "PARTIAL", "UNSUPPORTED", "UNAVAILABLE"],
    page_pair_geometry: PdfTransitionPagePairGeometry,
    column_continuity: PdfTransitionColumnContinuity,
    header_continuity: PdfTransitionHeaderContinuity,
    row_cell_continuity: PdfTransitionRowCellContinuity,
    pair_context: PdfTransitionPairContext,
    safety_state: PdfTransitionSafetyState,
    limitation_codes: tuple[str, ...] = (),
    resource_contract: PdfTransitionFingerprintResourceContract | None = None,
) -> PdfTableTransitionFingerprint:
    transition = PdfTablePageTransition.model_validate(
        _revalidation_payload(transition)
    )
    supplied_contract = (
        resource_contract
        if resource_contract is not None
        else PdfTransitionFingerprintResourceContract()
    )
    try:
        contract = PdfTransitionFingerprintResourceContract.model_validate(
            _revalidation_payload(supplied_contract)
        )
        page_pair_geometry = PdfTransitionPagePairGeometry.model_validate(
            _revalidation_payload(page_pair_geometry)
        )
        column_continuity = PdfTransitionColumnContinuity.model_validate(
            _revalidation_payload(column_continuity)
        )
        header_continuity = PdfTransitionHeaderContinuity.model_validate(
            _revalidation_payload(header_continuity)
        )
        row_cell_continuity = PdfTransitionRowCellContinuity.model_validate(
            _revalidation_payload(row_cell_continuity)
        )
        pair_context = PdfTransitionPairContext.model_validate(
            _revalidation_payload(pair_context)
        )
        safety_state = PdfTransitionSafetyState.model_validate(
            _revalidation_payload(safety_state)
        )
    except ValidationError:
        raise ValueError(_RESOURCE_ERROR) from None
    if not isinstance(limitation_codes, tuple) or any(
        not isinstance(item, str) for item in limitation_codes
    ):
        raise ValueError(_RESOURCE_ERROR)
    _validate_resource_inventories(
        column_continuity=column_continuity,
        header_continuity=header_continuity,
        row_cell_continuity=row_cell_continuity,
        pair_context=pair_context,
        limitation_codes=limitation_codes,
        resource_contract=contract,
    )
    values: dict[str, Any] = {
        "state": state,
        "source_sha256": transition.left.source_sha256,
        "document_identity": transition.left.document_identity,
        "page_table_manifest_sha256": transition.left.page_table_manifest_sha256,
        "transition_id": transition.transition_id,
        "left_page_index": transition.left.page_index,
        "right_page_index": transition.right.page_index,
        "left_page_id": transition.left.page_id,
        "right_page_id": transition.right.page_id,
        "left_table_id": transition.left.table_id,
        "right_table_id": transition.right.table_id,
        "left_table_sidecar_id": transition.left.table_sidecar_id,
        "right_table_sidecar_id": transition.right.table_sidecar_id,
        "left_table_sidecar_sha256": transition.left.table_sidecar_sha256,
        "right_table_sidecar_sha256": transition.right.table_sidecar_sha256,
        "left_configuration_identity": transition.left.configuration_identity,
        "right_configuration_identity": transition.right.configuration_identity,
        "left_dependency_identity": transition.left.dependency_identity,
        "right_dependency_identity": transition.right.dependency_identity,
        "page_pair_geometry": page_pair_geometry,
        "column_continuity": column_continuity,
        "header_continuity": header_continuity,
        "row_cell_continuity": row_cell_continuity,
        "pair_context": pair_context,
        "safety_state": safety_state,
        "limitation_codes": limitation_codes,
    }
    draft = PdfTableTransitionFingerprint.model_construct(
        fingerprint_id=_id("transition", {"draft": True}),
        semantic_fingerprint_identity="P3D-XFP-semantic-" + "0" * 64,
        **values,
    )
    complete = draft.model_dump(
        exclude={"fingerprint_id", "semantic_fingerprint_identity"}
    )
    complete["semantic_fingerprint_identity"] = _id(
        "semantic", _semantic_payload(draft)
    )
    complete["fingerprint_id"] = _id("transition", complete)
    result = PdfTableTransitionFingerprint.model_validate(complete)
    if canonical_json_size(result) > contract.maximum_serialized_bytes:
        raise ValueError(_RESOURCE_ERROR)
    return result


def _clamp_unit(value: float) -> float:
    return max(0.0, min(1.0, value))


def _enclosure_state(
    *,
    open_state: bool | None,
    closed_state: bool | None,
) -> Literal["OPEN", "CLOSED", "PARTIAL", "UNAVAILABLE"]:
    if open_state is True and closed_state is True:
        raise ValueError(_INPUT_ERROR)
    if open_state is True:
        return "OPEN"
    if closed_state is True:
        return "CLOSED"
    if open_state is False or closed_state is False:
        return "PARTIAL"
    return "UNAVAILABLE"


def _empty_spacer_continuity(
    left: PdfTransitionTableFeatures,
    right: PdfTransitionTableFeatures,
) -> Literal["SAME", "CHANGED", "ABSENT", "UNAVAILABLE"]:
    left_states = left.empty_spacer_column_states
    right_states = right.empty_spacer_column_states
    if (
        left_states is None
        or right_states is None
        or any(item is None for item in left_states + right_states)
    ):
        return "UNAVAILABLE"
    if not any(left_states) and not any(right_states):
        return "ABSENT"
    return "SAME" if left_states == right_states else "CHANGED"


def _header_continuity_from_authority(
    transition: PdfTablePageTransition,
    left: PdfTransitionTableFeatures,
    right: PdfTransitionTableFeatures,
) -> PdfTransitionHeaderContinuity:
    if transition.outcome not in _LINKING_TRANSITION_OUTCOMES:
        return PdfTransitionHeaderContinuity(
            repeated_header_present=None,
            repeated_header_depth=None,
            header_pattern="UNAVAILABLE",
            normalized_header_geometry_signature=None,
            header_geometry_signature=None,
            symbolic_repetition="UNAVAILABLE",
            repeated_occurrence_count=None,
            body_start_offset=None,
        )
    inventories = (
        left.header_row_ids,
        left.header_cell_ids,
        left.header_symbolic_signatures,
        right.header_row_ids,
        right.header_cell_ids,
        right.header_symbolic_signatures,
        left.header_geometry_signature,
        right.header_geometry_signature,
    )
    if any(item is None for item in inventories):
        return PdfTransitionHeaderContinuity(
            repeated_header_present=None,
            repeated_header_depth=None,
            header_pattern="UNAVAILABLE",
            normalized_header_geometry_signature=None,
            header_geometry_signature=None,
            symbolic_repetition="UNAVAILABLE",
            repeated_occurrence_count=None,
            body_start_offset=None,
        )
    mappings = transition.repeated_header_mappings
    depth = max((len(item.left_row_ids) for item in mappings), default=0)
    geometry_signature = (
        left.header_geometry_signature
        if left.header_geometry_signature is not None
        and left.header_geometry_signature == right.header_geometry_signature
        else None
    )
    merged_signature = (
        mappings[0].logical_header_identity.removeprefix("P3D-header-")
        if len(mappings) == 1
        else canonical_sha256(tuple(item.logical_header_identity for item in mappings))
        if mappings
        else None
    )
    return PdfTransitionHeaderContinuity(
        repeated_header_present=bool(mappings),
        repeated_header_depth=depth,
        header_pattern=(
            "NONE" if depth == 0 else "ONE_ROW" if depth == 1 else "MULTI_ROW"
        ),
        merged_header_topology_signature=merged_signature,
        normalized_header_geometry_signature=None,
        header_geometry_signature=geometry_signature,
        symbolic_repetition=(
            "NONE"
            if not mappings
            else "EXACT"
            if all(item.exact_symbolic_repeat for item in mappings)
            else "NEAR"
        ),
        repeated_occurrence_count=len(mappings),
        body_start_offset=depth,
    )


def _row_cell_continuity_from_authority(
    transition: PdfTablePageTransition,
    left: PdfTransitionTableFeatures,
    right: PdfTransitionTableFeatures,
) -> PdfTransitionRowCellContinuity:
    links = transition.row_fragment_links
    if links:
        split_state: bool | None = True
    elif (
        left.last_row_physically_incomplete is False
        or right.first_row_fragment_compatible is False
    ):
        split_state = False
    else:
        split_state = None
    return PdfTransitionRowCellContinuity(
        split_row_present=split_state,
        split_cell_present=split_state,
        open_last_row=left.bottom_boundary_open,
        open_first_row=right.top_boundary_open,
        fragment_count=len(links) if split_state is not None else None,
        mapped_column_fragment_distribution=(
            tuple(len(item.mapped_column_indexes) for item in links)
            if split_state is True
            else ()
            if split_state is False
            else None
        ),
        multiline_continuation=False if split_state is False else None,
        local_text_order_continuous=(
            all(item.local_fragment_order == ("LEFT", "RIGHT") for item in links)
            if links
            else None
        ),
        ambiguous_fragment_count=(
            sum(bool(item.conflicting_evidence) for item in links)
            if split_state is not None
            else None
        ),
    )


def _validated_fingerprint_inputs(
    transition: PdfTablePageTransition,
    left: PdfTransitionFingerprintInputAuthority,
    right: PdfTransitionFingerprintInputAuthority,
) -> tuple[
    PdfTablePageTransition,
    PdfTransitionFingerprintInputAuthority,
    PdfTransitionFingerprintInputAuthority,
]:
    try:
        transition = PdfTablePageTransition.model_validate(
            _revalidation_payload(transition)
        )
        left = PdfTransitionFingerprintInputAuthority.model_validate(
            _revalidation_payload(left)
        )
        right = PdfTransitionFingerprintInputAuthority.model_validate(
            _revalidation_payload(right)
        )
    except ValidationError:
        raise ValueError(_INPUT_ERROR) from None
    if (
        left.features.endpoint != transition.left
        or right.features.endpoint != transition.right
    ):
        raise ValueError(_INPUT_ERROR)
    if (
        not left.required_authority_available
        or not right.required_authority_available
        or transition.outcome == "UNAVAILABLE_UPSTREAM"
    ):
        raise ValueError(_INPUT_UNAVAILABLE)
    if (
        transition.left.dependency_identity is None
        or transition.right.dependency_identity is None
    ):
        raise ValueError(_INPUT_UNAVAILABLE)
    return transition, left, right


def build_transition_fingerprint_from_authority(
    *,
    transition: PdfTablePageTransition,
    left: PdfTransitionFingerprintInputAuthority,
    right: PdfTransitionFingerprintInputAuthority,
    resource_contract: PdfTransitionFingerprintResourceContract | None = None,
) -> PdfTableTransitionFingerprint:
    """Map one completed DT0 result without reopening or interpreting the PDF."""
    transition, left, right = _validated_fingerprint_inputs(transition, left, right)

    left_margin = _clamp_unit(left.table_x0 / left.page_width)
    left_right_margin = _clamp_unit((left.page_width - left.table_x1) / left.page_width)
    right_margin = _clamp_unit(right.table_x0 / right.page_width)
    right_right_margin = _clamp_unit(
        (right.page_width - right.table_x1) / right.page_width
    )
    margin_similarity = 1.0 - min(
        1.0,
        (abs(left_margin - right_margin) + abs(left_right_margin - right_right_margin))
        / 2.0,
    )
    left_bottom_gap = _clamp_unit((left.page_height - left.table_y1) / left.page_height)
    right_top_gap = _clamp_unit(right.table_y0 / right.page_height)
    boundary_proximity = 1.0 - min(
        1.0,
        (left_bottom_gap + right_top_gap) / 2.0,
    )
    rotations_match = (
        left.features.rotation_degrees % 360 == right.features.rotation_degrees % 360
    )
    orientation_similarity = 1.0 if rotations_match else 0.0
    page_pair_geometry = PdfTransitionPagePairGeometry(
        orientation_relationship="SAME" if rotations_match else "INCOMPATIBLE",
        normalized_table_width_drift=None,
        normalized_margin_drift=1.0 - margin_similarity,
        margin_similarity=margin_similarity,
        left_lower_boundary_proximity=1.0 - left_bottom_gap,
        right_upper_boundary_proximity=1.0 - right_top_gap,
        boundary_proximity=boundary_proximity,
        orientation_similarity=orientation_similarity,
        left_bottom_enclosure=_enclosure_state(
            open_state=left.features.bottom_boundary_open,
            closed_state=left.features.terminal_boundary_closed,
        ),
        right_top_enclosure=_enclosure_state(
            open_state=right.features.top_boundary_open,
            closed_state=right.features.independent_top_enclosure,
        ),
    )

    left_columns = len(left.features.columns)
    right_columns = len(right.features.columns)
    mappings_available = bool(transition.column_mappings)
    explicit_column_count_difference = left_columns != right_columns
    column_continuity = PdfTransitionColumnContinuity(
        left_column_count=left_columns,
        right_column_count=right_columns,
        normalized_axis_distances=tuple(
            item.normalized_axis_distance for item in transition.column_mappings
        ),
        column_width_ratio_drifts=tuple(
            item.width_ratio_difference for item in transition.column_mappings
        ),
        inserted_column_count=max(0, right_columns - left_columns),
        removed_column_count=max(0, left_columns - right_columns),
        empty_spacer_column_continuity=_empty_spacer_continuity(
            left.features,
            right.features,
        ),
        mapping_completeness=(
            1.0
            if mappings_available and transition.topology_compatible is True
            else 0.0
            if (mappings_available and transition.topology_compatible is False)
            or explicit_column_count_difference
            else None
        ),
        mapping_ambiguous=(
            True
            if transition.outcome == "MULTIPLE_CANDIDATES"
            else False
            if transition.candidate_pair_count == 1
            and (mappings_available or explicit_column_count_difference)
            else None
        ),
        topology_hard_difference=(
            False
            if mappings_available and transition.topology_compatible is True
            else True
            if mappings_available and transition.topology_compatible is False
            else True
            if explicit_column_count_difference
            else None
        ),
    )
    header_continuity = _header_continuity_from_authority(
        transition,
        left.features,
        right.features,
    )
    row_cell_continuity = _row_cell_continuity_from_authority(
        transition,
        left.features,
        right.features,
    )

    mapped_optional_dimensions_available = _mapped_optional_dimensions_available(
        page_pair_geometry=page_pair_geometry,
        column_continuity=column_continuity,
        header_continuity=header_continuity,
        row_cell_continuity=row_cell_continuity,
    )
    partial = (
        left.table_state == "PARTIAL"
        or right.table_state == "PARTIAL"
        or left.features.upstream_partial
        or right.features.upstream_partial
        or not left.optional_authority_available
        or not right.optional_authority_available
        or not mapped_optional_dimensions_available
        or left.runtime_truncated is not False
        or right.runtime_truncated is not False
        or transition.outcome == "CONTINUATION_PARTIAL"
    )
    limitations = {
        *left.limitation_codes,
        *right.limitation_codes,
        *(
            code
            for code in transition.limitation_codes
            if code != "FINGERPRINT_SIMILARITY_UNAVAILABLE"
        ),
    }
    if (
        left.table_state == "PARTIAL"
        or right.table_state == "PARTIAL"
        or left.features.upstream_partial
        or right.features.upstream_partial
    ):
        limitations.add("UPSTREAM_TABLE_PARTIAL")
    if (
        not left.optional_authority_available
        or not right.optional_authority_available
        or not mapped_optional_dimensions_available
    ):
        limitations.add("DT1_OPTIONAL_EVIDENCE_UNAVAILABLE")
    if left.runtime_truncated is True or right.runtime_truncated is True:
        limitations.add("DT1_RUNTIME_TRUNCATED")
    elif left.runtime_truncated is None or right.runtime_truncated is None:
        limitations.add("DT1_RUNTIME_TRUNCATION_UNAVAILABLE")
    if transition.outcome == "CONTINUATION_PARTIAL":
        limitations.add("UPSTREAM_TRANSITION_PARTIAL")
    limitation_codes = tuple(sorted(limitations))
    if partial and not limitation_codes:
        limitation_codes = ("DT1_EVIDENCE_PARTIAL",)

    context_conflicts = tuple(
        sorted(
            {
                reason
                for item in transition.column_mappings
                for reason in item.conflicting_evidence
            }
        )
    )
    pair_context = PdfTransitionPairContext(
        left_table_count=left.features.page_table_count,
        right_table_count=right.features.page_table_count,
        candidate_pair_count=transition.candidate_pair_count,
        selected_pair_rank=1 if transition.candidate_pair_count == 1 else None,
        multiple_table_transition=transition.candidate_pair_count > 1,
        predecessor_exclusive=transition.candidate_pair_count == 1,
        successor_exclusive=transition.candidate_pair_count == 1,
        continuation_outcome=transition.outcome,
        conflicting_evidence_groups=context_conflicts,
        typed_downgrade_reason=limitation_codes[0] if partial else None,
    )
    safety_score = _PARTIAL_SAFETY_SCORE if partial else 1.0
    safety_state = PdfTransitionSafetyState(
        source_capability_state="PARTIAL" if partial else "RELIABLE",
        runtime_truncated=(
            True
            if left.runtime_truncated is True or right.runtime_truncated is True
            else None
            if left.runtime_truncated is None or right.runtime_truncated is None
            else False
        ),
        dependency_state="CURRENT",
        evidence_complete=not partial,
        safety_score=safety_score,
    )
    return build_transition_fingerprint(
        transition=transition,
        state="PARTIAL" if partial else "AVAILABLE",
        page_pair_geometry=page_pair_geometry,
        column_continuity=column_continuity,
        header_continuity=header_continuity,
        row_cell_continuity=row_cell_continuity,
        pair_context=pair_context,
        safety_state=safety_state,
        limitation_codes=limitation_codes,
        resource_contract=resource_contract,
    )


def validate_transition_fingerprint_dependency(
    fingerprint: PdfTableTransitionFingerprint,
    transition: PdfTablePageTransition,
) -> None:
    try:
        fingerprint = PdfTableTransitionFingerprint.model_validate(
            _revalidation_payload(fingerprint)
        )
        transition = PdfTablePageTransition.model_validate(
            _revalidation_payload(transition)
        )
    except ValidationError:
        raise ValueError(_DEPENDENCY_ERROR) from None
    expected = (
        transition.transition_id,
        transition.left.source_sha256,
        transition.right.source_sha256,
        transition.left.document_identity,
        transition.right.document_identity,
        transition.left.page_table_manifest_sha256,
        transition.right.page_table_manifest_sha256,
        transition.left.page_index,
        transition.right.page_index,
        transition.left.page_id,
        transition.right.page_id,
        transition.left.table_id,
        transition.right.table_id,
        transition.left.table_sidecar_id,
        transition.right.table_sidecar_id,
        transition.left.table_sidecar_sha256,
        transition.right.table_sidecar_sha256,
        transition.left.configuration_identity,
        transition.right.configuration_identity,
        transition.left.dependency_identity,
        transition.right.dependency_identity,
    )
    actual = (
        fingerprint.transition_id,
        fingerprint.source_sha256,
        fingerprint.source_sha256,
        fingerprint.document_identity,
        fingerprint.document_identity,
        fingerprint.page_table_manifest_sha256,
        fingerprint.page_table_manifest_sha256,
        fingerprint.left_page_index,
        fingerprint.right_page_index,
        fingerprint.left_page_id,
        fingerprint.right_page_id,
        fingerprint.left_table_id,
        fingerprint.right_table_id,
        fingerprint.left_table_sidecar_id,
        fingerprint.right_table_sidecar_id,
        fingerprint.left_table_sidecar_sha256,
        fingerprint.right_table_sidecar_sha256,
        fingerprint.left_configuration_identity,
        fingerprint.right_configuration_identity,
        fingerprint.left_dependency_identity,
        fingerprint.right_dependency_identity,
    )
    if actual != expected:
        raise ValueError(_DEPENDENCY_ERROR)


class PdfCrossPageFingerprintComparison(_FrozenModel):
    schema_version: Literal[
        "document_sdk_pdf_document_table_fingerprint_comparison.v1"
    ] = _COMPARISON_SCHEMA_VERSION  # type: ignore[assignment]
    state: Literal["COMPARABLE", "INCOMPARABLE"]
    left_semantic_identity: str
    right_semantic_identity: str
    group_similarities: dict[str, float]
    structural_hard_differences: tuple[str, ...]
    conflicting_evidence: tuple[str, ...]
    overall_similarity: float | None = Field(default=None, ge=0, le=1)
    incomparable_reason: str | None = None


def compare_transition_fingerprints(
    left: PdfTableTransitionFingerprint,
    right: PdfTableTransitionFingerprint,
) -> PdfCrossPageFingerprintComparison:
    left = PdfTableTransitionFingerprint.model_validate(_revalidation_payload(left))
    right = PdfTableTransitionFingerprint.model_validate(_revalidation_payload(right))
    if (
        left.feature_schema_version != right.feature_schema_version
        or left.state != "AVAILABLE"
        or right.state != "AVAILABLE"
    ):
        return PdfCrossPageFingerprintComparison(
            state="INCOMPARABLE",
            left_semantic_identity=left.semantic_fingerprint_identity,
            right_semantic_identity=right.semantic_fingerprint_identity,
            group_similarities={},
            structural_hard_differences=(),
            conflicting_evidence=(),
            incomparable_reason="SCHEMA_OR_FEATURE_STATE_INCOMPARABLE",
        )
    if (
        left.page_pair_geometry.normalized_table_width_drift is None
        or right.page_pair_geometry.normalized_table_width_drift is None
    ):
        return PdfCrossPageFingerprintComparison(
            state="INCOMPARABLE",
            left_semantic_identity=left.semantic_fingerprint_identity,
            right_semantic_identity=right.semantic_fingerprint_identity,
            group_similarities={},
            structural_hard_differences=(),
            conflicting_evidence=(),
            incomparable_reason="PAGE_GEOMETRY_AUTHORITY_UNAVAILABLE",
        )
    hard: list[str] = []
    if (
        left.column_continuity.left_column_count
        != right.column_continuity.left_column_count
        or left.column_continuity.right_column_count
        != right.column_continuity.right_column_count
    ):
        hard.append("COLUMN_COUNT")
    if (
        left.header_continuity.repeated_header_present
        != right.header_continuity.repeated_header_present
    ):
        hard.append("REPEATED_HEADER_PRESENCE")
    if (
        left.header_continuity.repeated_header_depth
        != right.header_continuity.repeated_header_depth
    ):
        hard.append("REPEATED_HEADER_DEPTH")
    if (
        left.row_cell_continuity.split_row_present
        != right.row_cell_continuity.split_row_present
    ):
        hard.append("SPLIT_ROW_STATE")
    if (
        left.pair_context.multiple_table_transition
        != right.pair_context.multiple_table_transition
    ):
        hard.append("MULTIPLE_TABLE_CONTEXT")
    if (
        left.pair_context.continuation_outcome
        != right.pair_context.continuation_outcome
    ):
        hard.append("CONTINUATION_OUTCOME")
    if (
        left.column_continuity.empty_spacer_column_continuity
        != right.column_continuity.empty_spacer_column_continuity
    ):
        hard.append("EMPTY_SPACER_COLUMN")
    geometry_delta = abs(
        left.page_pair_geometry.normalized_table_width_drift
        - right.page_pair_geometry.normalized_table_width_drift
    )
    axis_left = left.column_continuity.normalized_axis_distances
    axis_right = right.column_continuity.normalized_axis_distances
    axis_delta = (
        sum(abs(a - b) for a, b in zip(axis_left, axis_right, strict=True))
        / max(len(axis_left), 1)
        if len(axis_left) == len(axis_right)
        else 1.0
    )
    column_hard_difference = bool({"COLUMN_COUNT", "EMPTY_SPACER_COLUMN"} & set(hard))
    groups = {
        "page_pair_geometry": max(0.0, 1.0 - geometry_delta),
        "column_continuity": (
            0.0 if column_hard_difference else max(0.0, 1.0 - axis_delta)
        ),
        "header_continuity": (
            1.0 if not any(item.startswith("REPEATED_HEADER") for item in hard) else 0.0
        ),
        "row_cell_continuity": 1.0 if "SPLIT_ROW_STATE" not in hard else 0.0,
        "pair_context": (
            1.0
            if not ({"MULTIPLE_TABLE_CONTEXT", "CONTINUATION_OUTCOME"} & set(hard))
            else 0.0
        ),
        "source_safety": 1.0 if left.safety_state == right.safety_state else 0.5,
    }
    return PdfCrossPageFingerprintComparison(
        state="COMPARABLE",
        left_semantic_identity=left.semantic_fingerprint_identity,
        right_semantic_identity=right.semantic_fingerprint_identity,
        group_similarities=groups,
        structural_hard_differences=tuple(hard),
        conflicting_evidence=tuple(
            sorted(
                set(
                    left.pair_context.conflicting_evidence_groups
                    + right.pair_context.conflicting_evidence_groups
                )
            )
        ),
        overall_similarity=sum(groups.values()) / len(groups),
    )

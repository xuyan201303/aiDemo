# ruff: noqa: EM101, TRY003

"""Typed, evidence-only Page Table to DT0 input projection."""

from __future__ import annotations

from dataclasses import dataclass
from math import floor
from typing import TYPE_CHECKING, Literal
from unicodedata import normalize

from .document_table_contracts import PdfPhase3DTableEndpoint
from .document_table_transition import (
    PdfTransitionColumnFeature,
    PdfTransitionTableFeatures,
)
from .identity import canonical_json_bytes, canonical_sha256

if TYPE_CHECKING:
    from document_sdk.pdf._structural_engine.facts.contracts import (
        PdfFactArtifact,
        PdfPageFacts,
    )

    from .table_contracts import (
        PdfTable,
        PdfTableCell,
        PdfTableRow,
        PdfTableStructurePageSidecar,
    )
    from .table_document_manifest import PdfTableDocumentManifest

HEADER_GEOMETRY_BUCKET_COUNT = 32
HEADER_GEOMETRY_DOMAIN = "document_sdk.pdf.phase3.document_table.header_geometry.v1"
HEADER_SYMBOLIC_DOMAIN = "document_sdk.pdf.phase3.document_table.header_symbolic.v1"
INPUT_TOPOLOGY_DOMAIN = "document_sdk.pdf.phase3.document_table.input_topology.v1"

PAIR_INPUT_UNAVAILABLE_STRATEGY = "PAIR_INPUT_UNAVAILABLE_STRATEGY"
PAIR_INPUT_UNAVAILABLE_TABLE_STATE = "PAIR_INPUT_UNAVAILABLE_TABLE_STATE"
PAIR_INPUT_UNAVAILABLE_BODY_ROWS = "PAIR_INPUT_UNAVAILABLE_BODY_ROWS"
HEADER_AUTHORITY_UNAVAILABLE = "HEADER_AUTHORITY_UNAVAILABLE"
EMPTY_SPACER_AUTHORITY_PARTIAL = "EMPTY_SPACER_AUTHORITY_PARTIAL"
BOUNDARY_AUTHORITY_PARTIAL = "BOUNDARY_AUTHORITY_PARTIAL"
SPLIT_ROW_AUTHORITY_UNAVAILABLE = "SPLIT_ROW_AUTHORITY_UNAVAILABLE"
PRIOR_FINGERPRINT_UNAVAILABLE = "PRIOR_FINGERPRINT_UNAVAILABLE"
RUNTIME_TRUNCATION_AUTHORITY_UNAVAILABLE = "RUNTIME_TRUNCATION_AUTHORITY_UNAVAILABLE"
UPSTREAM_RUNTIME_TRUNCATED = "UPSTREAM_RUNTIME_TRUNCATED"

_BORDERLESS_EVIDENCE = frozenset(
    {
        "intercell_whitespace",
        "repeated_row_alignment",
        "stable_borderless_column_anchors",
    }
)
_HEADER_ROLE = "COLUMN_HEADER_LIKE"

PdfTransitionTableInputState = Literal["AVAILABLE", "UNAVAILABLE"]
PdfBoundTableState = Literal["COMPLETE", "PARTIAL"]


@dataclass(frozen=True, slots=True)
class PdfTransitionTableInputAuthority:
    """A DT0 feature plus the bound numeric authority needed by DT1."""

    features: PdfTransitionTableFeatures
    page_width: float
    page_height: float
    table_state: PdfBoundTableState
    normalized_upper_gap: float
    normalized_lower_gap: float
    left_margin: float
    right_margin: float
    required_authority_available: Literal[True]
    optional_authority_available: bool
    runtime_truncated: bool | None
    limitation_codes: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class PdfTransitionTableInputResult:
    """Fail-closed adapter result; unavailable is never negative evidence."""

    state: PdfTransitionTableInputState
    authority: PdfTransitionTableInputAuthority | None
    limitation_codes: tuple[str, ...]

    def __post_init__(self) -> None:
        if (self.state == "AVAILABLE") != (self.authority is not None):
            raise ValueError("adapter availability and authority must be paired")
        if self.limitation_codes != tuple(sorted(set(self.limitation_codes))):
            raise ValueError("adapter limitation codes must be sorted and unique")


@dataclass(frozen=True, slots=True)
class _HeaderAuthority:
    row_ids: tuple[str, ...]
    cell_ids: tuple[str, ...]
    symbolic_signatures: tuple[str, ...]
    geometry_signature: str
    topology: tuple[tuple[int, int, int, int, str], ...]


def build_page_transition_inputs(
    *,
    facts: PdfFactArtifact,
    page: PdfTableStructurePageSidecar,
    manifest: PdfTableDocumentManifest,
) -> tuple[PdfTransitionTableInputResult, ...]:
    """Project a page's tables in canonical candidate order."""
    return tuple(
        build_transition_table_input(
            facts=facts,
            page=page,
            table=table,
            manifest=manifest,
        )
        for table in sorted(
            page.tables,
            key=lambda item: (item.table_index, item.table_id),
        )
    )


def build_transition_table_input(
    *,
    facts: PdfFactArtifact,
    page: PdfTableStructurePageSidecar,
    table: PdfTable,
    manifest: PdfTableDocumentManifest,
) -> PdfTransitionTableInputResult:
    """Build one existing DT0 feature without inferred or fabricated evidence."""
    fact_page = _validate_bindings(
        facts=facts,
        page=page,
        table=table,
        manifest=manifest,
    )
    if table.state == "COMPLETE":
        table_state: PdfBoundTableState = "COMPLETE"
    elif table.state == "PARTIAL":
        table_state = "PARTIAL"
    else:
        return _unavailable(PAIR_INPUT_UNAVAILABLE_TABLE_STATE)

    strategy = _strategy(table)
    if strategy is None:
        return _unavailable(PAIR_INPUT_UNAVAILABLE_STRATEGY)

    width = float(page.canonical_width)
    height = float(page.canonical_height)
    normalized_x0 = _ratio(table.geometry.x0, width)
    normalized_y0 = _ratio(table.geometry.y0, height)
    normalized_x1 = _ratio(table.geometry.x1, width)
    normalized_y1 = _ratio(table.geometry.y1, height)
    upper_gap = normalized_y0
    lower_gap = _ratio(height - table.geometry.y1, height)
    left_margin = normalized_x0
    right_margin = _ratio(width - table.geometry.x1, width)

    header = _header_authority(table)
    spacer_states = _empty_spacer_states(table)
    runtime_truncated = _runtime_truncation_state(
        facts=facts,
        fact_page=fact_page,
        page=page,
        table_state=table_state,
    )
    enclosed = _complete_ruled_enclosure(table, strategy=strategy)
    # A complete local perimeter proves terminal closure.  It does not prove
    # openness or that the next page starts an independent table.
    boundary_values: tuple[bool | None, bool | None, bool | None, bool | None] = (
        (None, None, True, None) if enclosed else (None, None, None, None)
    )
    bottom_open, top_open, terminal_closed, independent_top = boundary_values

    body_endpoints = _body_endpoints(table, header=header)
    if body_endpoints is None:
        return _unavailable(PAIR_INPUT_UNAVAILABLE_BODY_ROWS)
    first_row, last_row = body_endpoints
    endpoint = PdfPhase3DTableEndpoint(
        source_sha256=page.source_sha256,
        document_identity=manifest.document_identity,
        page_table_manifest_sha256=manifest.page_table_manifest_sha256,
        page_index=page.page_index,
        page_id=page.page_id,
        table_sidecar_id=page.sidecar_id,
        table_sidecar_sha256=canonical_sha256(page),
        sidecar_bytes=len(canonical_json_bytes(page)),
        configuration_identity=page.configuration_identity,
        dependency_identity=page.dependency_identity,
        table_id=table.table_id,
        table_row_ids=tuple(row.row_id for row in table.rows),
        table_cell_ids=tuple(cell.cell_id for cell in table.cells),
        row_cell_membership=tuple(
            (row.row_id, row.anchor_cell_ids) for row in table.rows
        ),
    )

    split_row_state: dict[str, bool | None] = {
        "first_row_fragment_compatible": None,
        "first_row_symbolically_compatible": None,
        "last_row_physically_incomplete": None,
        "last_row_symbolically_incomplete": None,
    }
    topology_signature = canonical_sha256(
        {
            "boundary_state_topology": {
                "columns": tuple(
                    (item.boundary_index, item.state)
                    for item in table.column_boundaries
                ),
                "rows": tuple(
                    (item.boundary_index, item.state) for item in table.row_boundaries
                ),
            },
            "cell_spans": tuple(
                (
                    cell.row_start,
                    cell.row_span,
                    cell.column_start,
                    cell.column_span,
                )
                for cell in _ordered_cells(table)
            ),
            "column_count": len(table.columns),
            "domain": INPUT_TOPOLOGY_DOMAIN,
            "empty_spacer_typed_states": spacer_states,
            "page_rotation": fact_page.rotation % 360,
            "proven_header_role_topology": (
                header.topology if header is not None else None
            ),
            "row_count": len(table.rows),
            "split_row_typed_state": split_row_state,
            "strategy": strategy,
            "table_state": table_state,
        }
    )

    limitations = {
        PRIOR_FINGERPRINT_UNAVAILABLE,
        SPLIT_ROW_AUTHORITY_UNAVAILABLE,
    }
    if header is None:
        limitations.add(HEADER_AUTHORITY_UNAVAILABLE)
    if any(value is None for value in spacer_states):
        limitations.add(EMPTY_SPACER_AUTHORITY_PARTIAL)
    if any(value is None for value in boundary_values):
        limitations.add(BOUNDARY_AUTHORITY_PARTIAL)
    if runtime_truncated is None:
        limitations.add(RUNTIME_TRUNCATION_AUTHORITY_UNAVAILABLE)
    elif runtime_truncated:
        limitations.add(UPSTREAM_RUNTIME_TRUNCATED)
    ordered_limitations = tuple(sorted(limitations))

    features = PdfTransitionTableFeatures(
        endpoint=endpoint,
        normalized_x0=normalized_x0,
        normalized_y0=normalized_y0,
        normalized_x1=normalized_x1,
        normalized_y1=normalized_y1,
        normalized_upper_gap=upper_gap,
        normalized_lower_gap=lower_gap,
        columns=tuple(
            PdfTransitionColumnFeature(
                column_id=column.column_id,
                column_index=column.column_index,
                normalized_x0=_ratio(column.geometry.x0, width),
                normalized_x1=_ratio(column.geometry.x1, width),
            )
            for column in table.columns
        ),
        page_table_count=len(page.tables),
        rotation_degrees=fact_page.rotation % 360,
        empty_spacer_column_indexes=tuple(
            index for index, state in enumerate(spacer_states) if state is True
        ),
        empty_spacer_column_states=spacer_states,
        header_row_ids=header.row_ids if header is not None else None,
        header_cell_ids=header.cell_ids if header is not None else None,
        header_symbolic_signatures=(
            header.symbolic_signatures if header is not None else None
        ),
        header_geometry_signature=(
            header.geometry_signature if header is not None else None
        ),
        strategy=strategy,
        reaches_lower_content_boundary=True if lower_gap == 0.0 else None,
        starts_near_upper_content_boundary=True if upper_gap == 0.0 else None,
        bottom_boundary_open=bottom_open,
        top_boundary_open=top_open,
        terminal_boundary_closed=terminal_closed,
        independent_top_enclosure=independent_top,
        last_row_physically_incomplete=None,
        first_row_fragment_compatible=None,
        last_row_symbolically_incomplete=None,
        first_row_symbolically_compatible=None,
        first_body_row_id=first_row.row_id,
        first_body_cell_ids=first_row.anchor_cell_ids,
        last_body_row_id=last_row.row_id,
        last_body_cell_ids=last_row.anchor_cell_ids,
        source_available=True,
        upstream_partial=(
            table_state == "PARTIAL"
            or page.outcome == "PARTIAL"
            or facts.partial_extraction
            or fact_page.extraction_status.value != "success"
        ),
        fingerprint_similarity=None,
        topology_signature=topology_signature,
    )
    authority = PdfTransitionTableInputAuthority(
        features=features,
        page_width=width,
        page_height=height,
        table_state=table_state,
        normalized_upper_gap=upper_gap,
        normalized_lower_gap=lower_gap,
        left_margin=left_margin,
        right_margin=right_margin,
        required_authority_available=True,
        optional_authority_available=not ordered_limitations,
        runtime_truncated=runtime_truncated,
        limitation_codes=ordered_limitations,
    )
    return PdfTransitionTableInputResult(
        state="AVAILABLE",
        authority=authority,
        limitation_codes=ordered_limitations,
    )


def _unavailable(reason: str) -> PdfTransitionTableInputResult:
    return PdfTransitionTableInputResult(
        state="UNAVAILABLE",
        authority=None,
        limitation_codes=(reason,),
    )


def _validate_bindings(
    *,
    facts: PdfFactArtifact,
    page: PdfTableStructurePageSidecar,
    table: PdfTable,
    manifest: PdfTableDocumentManifest,
) -> PdfPageFacts:
    if facts.source_sha256 != page.source_sha256 or facts.source_sha256 != (
        manifest.source_sha256
    ):
        raise ValueError("adapter input crosses source authority")
    fact_pages = tuple(
        item
        for item in facts.pages
        if item.page_id == page.page_id and item.page_number - 1 == page.page_index
    )
    if len(fact_pages) != 1:
        raise ValueError("adapter input lacks exact Fact page authority")
    fact_page = fact_pages[0]
    if (
        fact_page.canonical_width != page.canonical_width
        or fact_page.canonical_height != page.canonical_height
    ):
        raise ValueError("adapter Fact/Table page geometry mismatch")
    if not any(item is table or item == table for item in page.tables):
        raise ValueError("adapter table is absent from its page sidecar")

    sidecar_digest = canonical_sha256(page)
    sidecar_size = len(canonical_json_bytes(page))
    references = tuple(
        item
        for item in manifest.page_references
        if item.page_id == page.page_id
        and item.page_index == page.page_index
        and item.sidecar_id == page.sidecar_id
    )
    if len(references) != 1:
        raise ValueError("adapter input lacks exact page Table manifest authority")
    reference = references[0]
    if (
        reference.sidecar_sha256 != sidecar_digest
        or reference.sidecar_bytes != sidecar_size
        or reference.outcome != page.outcome
        or reference.table_ids != tuple(item.table_id for item in page.tables)
    ):
        raise ValueError("adapter Page Table authority is stale or mismatched")
    return fact_page


def _strategy(table: PdfTable) -> Literal["ruled", "borderless"] | None:
    table_categories = set(table.evidence.evidence_categories)
    ruled = "orthogonal_separator_grid" in table_categories
    borderless = table_categories >= _BORDERLESS_EVIDENCE
    if ruled == borderless:
        return None
    return "ruled" if ruled else "borderless"


def _header_authority(table: PdfTable) -> _HeaderAuthority | None:
    indexed_cells = tuple(enumerate(table.cells))
    claimed_header_cells = tuple(
        (ordinal, cell)
        for ordinal, cell in indexed_cells
        if cell.role_status == "PROVEN" and cell.role == _HEADER_ROLE
    )
    if not claimed_header_cells or any(
        cell.state not in {"PROVEN", "PROVEN_EMPTY"} for _, cell in claimed_header_cells
    ):
        return None
    header_cells = tuple(
        sorted(
            claimed_header_cells,
            key=lambda item: (
                item[1].row_start,
                item[1].column_start,
                item[0],
            ),
        )
    )
    rows_by_index = {row.row_index: row for row in table.rows}
    row_indexes = tuple(sorted({cell.row_start for _, cell in header_cells}))
    if any(index not in rows_by_index for index in row_indexes):
        raise ValueError("header cell lacks row authority")

    symbolic = []
    for row_index in row_indexes:
        texts = tuple(
            normalize("NFC", cell.text)
            for _, cell in header_cells
            if cell.row_start == row_index
        )
        symbolic.append(
            canonical_sha256(
                {
                    "content": texts,
                    "domain": HEADER_SYMBOLIC_DOMAIN,
                }
            )
        )
    geometry_tokens = tuple(
        (
            cell.row_start,
            cell.column_start,
            cell.row_span,
            cell.column_span,
            _geometry_bucket(
                (cell.geometry.x0 - table.geometry.x0)
                / (table.geometry.x1 - table.geometry.x0)
            ),
            _geometry_bucket(
                (cell.geometry.x1 - cell.geometry.x0)
                / (table.geometry.x1 - table.geometry.x0)
            ),
        )
        for _, cell in header_cells
    )
    geometry_signature = canonical_sha256(
        {
            "domain": HEADER_GEOMETRY_DOMAIN,
            "tokens": geometry_tokens,
        }
    )
    selected_header_cell_ids = {cell.cell_id for _, cell in header_cells}
    return _HeaderAuthority(
        row_ids=tuple(rows_by_index[index].row_id for index in row_indexes),
        cell_ids=tuple(
            cell_id
            for row_index in row_indexes
            for cell_id in rows_by_index[row_index].anchor_cell_ids
            if cell_id in selected_header_cell_ids
        ),
        symbolic_signatures=tuple(symbolic),
        geometry_signature=geometry_signature,
        topology=tuple(
            (
                cell.row_start,
                cell.column_start,
                cell.row_span,
                cell.column_span,
                cell.role,
            )
            for _, cell in header_cells
        ),
    )


def _ordered_cells(table: PdfTable) -> tuple[PdfTableCell, ...]:
    return tuple(
        item[1]
        for item in sorted(
            enumerate(table.cells),
            key=lambda item: (
                item[1].row_start,
                item[1].column_start,
                item[0],
            ),
        )
    )


def _empty_spacer_states(table: PdfTable) -> tuple[bool | None, ...]:
    states: list[bool | None] = []
    for column in table.columns:
        covering = tuple(
            cell
            for cell in table.cells
            if cell.column_start
            <= column.column_index
            < cell.column_start + cell.column_span
        )
        if any(cell.state == "PROVEN" and bool(cell.text) for cell in covering):
            states.append(False)
            continue
        positions = {
            row_index
            for cell in covering
            for row_index in range(cell.row_start, cell.row_start + cell.row_span)
        }
        if positions != set(range(len(table.rows))):
            states.append(None)
            continue
        if covering and all(
            cell.state == "PROVEN_EMPTY" and bool(cell.empty_cell_evidence)
            for cell in covering
        ):
            states.append(True)
            continue
        states.append(None)
    return tuple(states)


def _complete_ruled_enclosure(
    table: PdfTable,
    *,
    strategy: Literal["ruled", "borderless"],
) -> bool:
    if strategy != "ruled" or table.state != "COMPLETE":
        return False
    if (
        len(table.row_boundaries) != len(table.rows) + 1
        or len(table.column_boundaries) != len(table.columns) + 1
        or any(
            boundary.state != "PROVEN"
            for boundary in (*table.row_boundaries, *table.column_boundaries)
        )
    ):
        return False
    return bool(
        table.row_boundaries[0].coordinate == table.geometry.y0
        and table.row_boundaries[-1].coordinate == table.geometry.y1
        and table.column_boundaries[0].coordinate == table.geometry.x0
        and table.column_boundaries[-1].coordinate == table.geometry.x1
    )


def _runtime_truncation_state(
    *,
    facts: PdfFactArtifact,
    fact_page: PdfPageFacts,
    page: PdfTableStructurePageSidecar,
    table_state: PdfBoundTableState,
) -> bool | None:
    codes = {
        *(warning.code.value for warning in facts.warnings),
        *(warning.code.value for warning in fact_page.warnings),
        *page.limitation_codes,
    }
    resource_markers = ("LIMIT", "RESOURCE", "TIMEOUT", "TRUNCAT")
    if any(marker in code.upper() for code in codes for marker in resource_markers):
        return True
    if (
        not facts.partial_extraction
        and fact_page.extraction_status.value == "success"
        and page.outcome == "COMPLETE"
        and table_state == "COMPLETE"
    ):
        return False
    return None


def _body_endpoints(
    table: PdfTable,
    *,
    header: _HeaderAuthority | None,
) -> tuple[PdfTableRow, PdfTableRow] | None:
    header_ids = set(header.row_ids) if header is not None else set()
    body_rows = tuple(row for row in table.rows if row.row_id not in header_ids)
    if not body_rows:
        return None
    return body_rows[0], body_rows[-1]


def _geometry_bucket(value: float) -> int:
    clamped = _clamp(value)
    return min(
        HEADER_GEOMETRY_BUCKET_COUNT - 1,
        floor(clamped * HEADER_GEOMETRY_BUCKET_COUNT),
    )


def _ratio(value: float, denominator: float) -> float:
    if denominator <= 0:
        raise ValueError("adapter geometry denominator must be positive")
    return _clamp(value / denominator)


def _clamp(value: float) -> float:
    return float(max(0.0, min(1.0, value)))

# ruff: noqa: E501, EM101, TC001, TRY003, UP037

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from document_sdk.pdf._structural_engine.facts.contracts import PdfBoundingBox

from .identity import canonical_sha256

PDF_READING_STRUCTURE_VERSION = "pdf_reading_structure.v1"
PDF_READING_STRUCTURE_SIDECAR_VERSION: Literal[
    "pdf_reading_structure_page_sidecar.v1"
] = "pdf_reading_structure_page_sidecar.v1"

CapabilityState = Literal[
    "complete", "partial", "review_required", "unsupported", "unavailable"
]
DecisionState = Literal["accepted", "rejected", "review_required"]
BlockRole = Literal[
    "title",
    "heading",
    "paragraph",
    "list_item",
    "caption",
    "footnote",
    "header",
    "footer",
    "page_number",
    "figure_region",
    "table_region",
    "unknown_text",
    "review_required",
]


def reading_structure_identifier(kind: str, payload: object) -> str:
    return f"P3B-{kind}-{canonical_sha256({'domain': 'pdf_reading_structure.v1', 'entity_kind': kind, 'payload': payload})}"


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class PdfReadingStructureComponentHashes(_FrozenModel):
    fact_snapshot_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    layout_snapshot_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    ctif_reference_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    structural_page_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    reading_order_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    block_result_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    hierarchy_result_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")


class PdfReadingStructureProvenance(_FrozenModel):
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    page_index: int = Field(ge=0)
    inherited_page_sidecar_id: str = Field(pattern=r"^P3S-page-evidence-[0-9a-f]{64}$")
    inherited_page_sidecar_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    inherited_manifest_id: str = Field(pattern=r"^P3S-page-manifest-[0-9a-f]{64}$")
    dependency_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    operation_version: str
    algorithm_version: str
    configuration_identity: str = Field(pattern=r"^[0-9a-f]{64}$")


class PdfStructuralTextFragment(_FrozenModel):
    fragment_id: str = Field(pattern=r"^P3B-fragment-[0-9a-f]{64}$")
    fact_id: str
    layout_node_id: str
    canonical_bbox: PdfBoundingBox
    text: str
    physical_order: int = Field(ge=0)

    @model_validator(mode="after")
    def validate_identity(self) -> "PdfStructuralTextFragment":
        expected = reading_structure_identifier(
            "fragment", self.model_dump(exclude={"fragment_id"})
        )
        if self.fragment_id != expected:
            raise ValueError("structural fragment identity mismatch")
        return self


class PdfReadingStructuralBlock(_FrozenModel):
    block_id: str = Field(pattern=r"^P3B-block-[0-9a-f]{64}$")
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    source_node_ids: tuple[str, ...]
    source_fact_ids: tuple[str, ...]
    source_line_candidate_fact_ids: tuple[str, ...] = ()
    source_layout_relation_ids: tuple[str, ...] = ()
    canonical_bbox: PdfBoundingBox
    fragments: tuple[PdfStructuralTextFragment, ...]
    normalized_text: str
    role: BlockRole
    role_status: Literal["proven", "candidate", "review_required", "rejected"]
    evidence_categories: tuple[str, ...]
    ordering_evidence: tuple[str, ...] = ()
    separator_evidence: tuple[str, ...] = ()
    heading_level: int | None = Field(default=None, ge=1, le=9)
    state: CapabilityState
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_block(self) -> "PdfReadingStructuralBlock":
        if not self.fragments or not self.source_fact_ids or not self.source_node_ids:
            raise ValueError("structural block requires exact source membership")
        if tuple(item.fact_id for item in self.fragments) != self.source_fact_ids:
            raise ValueError("structural block Fact sequence mismatch")
        if self.source_line_candidate_fact_ids != tuple(
            dict.fromkeys(self.source_line_candidate_fact_ids)
        ):
            raise ValueError("structural block line-candidate Facts are noncanonical")
        if (
            tuple(item.layout_node_id for item in self.fragments)
            != self.source_node_ids
        ):
            raise ValueError("structural block Layout-node sequence mismatch")
        if tuple(item.physical_order for item in self.fragments) != tuple(
            range(len(self.fragments))
        ):
            raise ValueError("structural fragment order is noncanonical")
        if self.role_status != "proven" and self.state == "complete":
            raise ValueError("unproven structural role cannot report complete")
        if self.heading_level is not None and not (
            self.role == "heading" and self.role_status == "proven"
        ):
            raise ValueError("heading level requires a proven heading")
        expected = reading_structure_identifier(
            "block", self.model_dump(exclude={"block_id"})
        )
        if self.block_id != expected:
            raise ValueError("structural block identity mismatch")
        return self


class PdfReadingOrderRelation(_FrozenModel):
    relation_id: str = Field(pattern=r"^P3B-reading-edge-[0-9a-f]{64}$")
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    predecessor_block_id: str = Field(pattern=r"^P3B-block-[0-9a-f]{64}$")
    successor_block_id: str = Field(pattern=r"^P3B-block-[0-9a-f]{64}$")
    relation_type: Literal[
        "same_block_fragment",
        "same_column",
        "column_transition",
        "heading_to_body",
        "list_sequence",
        "region_transition",
    ]
    source_layout_relation_ids: tuple[str, ...] = ()
    separator_evidence: tuple[str, ...] = ()
    column_evidence: tuple[str, ...] = ()
    status: DecisionState
    rejection_reason: str | None = None
    supporting_fact_ids: tuple[str, ...]
    algorithm_version: str
    configuration_identity: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_relation(self) -> "PdfReadingOrderRelation":
        if self.predecessor_block_id == self.successor_block_id:
            raise ValueError("reading-order relation cannot self-reference")
        if self.status != "accepted" and not self.rejection_reason:
            raise ValueError("non-accepted reading relation requires a reason")
        expected = reading_structure_identifier(
            "reading-edge", self.model_dump(exclude={"relation_id"})
        )
        if self.relation_id != expected:
            raise ValueError("reading-order relation identity mismatch")
        return self


class PdfPageReadingOrderGraph(_FrozenModel):
    graph_id: str = Field(pattern=r"^P3B-reading-page-[0-9a-f]{64}$")
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    ordered_block_ids: tuple[str, ...]
    relations: tuple[PdfReadingOrderRelation, ...]
    unresolved_components: tuple[tuple[str, ...], ...] = ()
    state: CapabilityState
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_graph(self) -> "PdfPageReadingOrderGraph":
        if len(self.ordered_block_ids) != len(set(self.ordered_block_ids)):
            raise ValueError("reading-order graph repeats a block")
        if self.unresolved_components and self.state == "complete":
            raise ValueError("unresolved reading graph cannot report complete")
        expected = reading_structure_identifier(
            "reading-page", self.model_dump(exclude={"graph_id"})
        )
        if self.graph_id != expected:
            raise ValueError("page reading-order graph identity mismatch")
        return self


class PdfHeadingHierarchyRelation(_FrozenModel):
    relation_id: str = Field(pattern=r"^P3B-hierarchy-edge-[0-9a-f]{64}$")
    parent_block_id: str = Field(pattern=r"^P3B-block-[0-9a-f]{64}$")
    child_block_id: str = Field(pattern=r"^P3B-block-[0-9a-f]{64}$")
    relation_type: Literal[
        "heading_contains_heading", "heading_contains_content", "root_contains"
    ]
    parent_heading_level: int | None = Field(default=None, ge=1, le=9)
    child_heading_level: int | None = Field(default=None, ge=1, le=9)
    status: DecisionState
    source_fact_ids: tuple[str, ...]
    source_layout_relation_ids: tuple[str, ...] = ()
    rejected_evidence_id: str | None = None
    algorithm_version: str
    configuration_identity: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_relation(self) -> "PdfHeadingHierarchyRelation":
        if self.parent_block_id == self.child_block_id:
            raise ValueError("hierarchy relation cannot self-reference")
        if self.status == "rejected" and self.rejected_evidence_id is None:
            raise ValueError("rejected hierarchy requires exact rejection evidence")
        expected = reading_structure_identifier(
            "hierarchy-edge", self.model_dump(exclude={"relation_id"})
        )
        if self.relation_id != expected:
            raise ValueError("hierarchy relation identity mismatch")
        return self


class PdfHierarchyGraph(_FrozenModel):
    graph_id: str = Field(pattern=r"^P3B-hierarchy-page-[0-9a-f]{64}$")
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    root_block_ids: tuple[str, ...]
    relations: tuple[PdfHeadingHierarchyRelation, ...]
    orphan_block_ids: tuple[str, ...] = ()
    review_required_block_ids: tuple[str, ...] = ()
    rejected_relation_ids: tuple[str, ...] = ()
    state: CapabilityState
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_graph(self) -> "PdfHierarchyGraph":
        if self.review_required_block_ids and self.state == "complete":
            raise ValueError("ambiguous hierarchy cannot report complete")
        expected = reading_structure_identifier(
            "hierarchy-page", self.model_dump(exclude={"graph_id"})
        )
        if self.graph_id != expected:
            raise ValueError("hierarchy graph identity mismatch")
        return self


class PdfReadingStructurePageSidecar(_FrozenModel):
    schema_version: Literal["pdf_reading_structure_page_sidecar.v1"] = (
        PDF_READING_STRUCTURE_SIDECAR_VERSION
    )
    sidecar_id: str = Field(pattern=r"^P3B-structure-page-[0-9a-f]{64}$")
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    page_index: int = Field(ge=0)
    blocks: tuple[PdfReadingStructuralBlock, ...]
    reading_order: PdfPageReadingOrderGraph
    hierarchy: PdfHierarchyGraph
    component_hashes: PdfReadingStructureComponentHashes
    state: CapabilityState
    limitation_codes: tuple[str, ...] = ()
    provenance: PdfReadingStructureProvenance

    @model_validator(mode="after")
    def validate_sidecar(self) -> "PdfReadingStructurePageSidecar":
        if not (
            self.source_sha256 == self.provenance.source_sha256
            and self.page_id == self.provenance.page_id
            and self.page_index == self.provenance.page_index
            and self.reading_order.page_id == self.page_id
            and self.hierarchy.page_id == self.page_id
        ):
            raise ValueError("reading structure source/Page provenance mismatch")
        block_ids = tuple(item.block_id for item in self.blocks)
        if set(self.reading_order.ordered_block_ids) - set(block_ids):
            raise ValueError("reading order references a nonexistent block")
        if self.component_hashes.block_result_sha256 != canonical_sha256(self.blocks):
            raise ValueError("block component hash mismatch")
        if self.component_hashes.reading_order_sha256 != canonical_sha256(
            self.reading_order
        ):
            raise ValueError("reading-order component hash mismatch")
        if self.component_hashes.hierarchy_result_sha256 != canonical_sha256(
            self.hierarchy
        ):
            raise ValueError("hierarchy component hash mismatch")
        expected = reading_structure_identifier(
            "structure-page", self.model_dump(exclude={"sidecar_id"})
        )
        if self.sidecar_id != expected:
            raise ValueError("reading structure page-sidecar identity mismatch")
        return self


class PdfReadingStructurePageReference(_FrozenModel):
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    page_index: int = Field(ge=0)
    sidecar_id: str = Field(pattern=r"^P3B-structure-page-[0-9a-f]{64}$")
    sidecar_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    sidecar_bytes: int = Field(gt=0)
    reading_order_graph_id: str = Field(pattern=r"^P3B-reading-page-[0-9a-f]{64}$")
    hierarchy_graph_id: str = Field(pattern=r"^P3B-hierarchy-page-[0-9a-f]{64}$")
    block_ids: tuple[str, ...]


class PdfReadingStructureCapabilitySummary(_FrozenModel):
    reading_order: CapabilityState
    structural_blocks: CapabilityState
    paragraphs: CapabilityState
    lists: CapabilityState
    headings: CapabilityState
    hierarchy: CapabilityState
    tables: Literal["unsupported", "unavailable"] = "unavailable"

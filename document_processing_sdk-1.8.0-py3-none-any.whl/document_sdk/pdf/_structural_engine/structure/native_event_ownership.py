# ruff: noqa: C408, C901, EM101, PLR0911, PLR0912, PLR0913, PLR0915, PLR2004, TRY003
"""Observed native-emission anchors with explicit overflow; never containment.

The first contract deliberately admits only complete rectangular stroke grids,
one independent native Tj (or single-segment TJ) per cell, horizontal unrotated
source members, and repeated row anchors. Accepted content remains PARTIAL.
"""

from __future__ import annotations

from bisect import bisect_right
from dataclasses import dataclass
from itertools import pairwise
from math import isfinite, ulp
from typing import TYPE_CHECKING, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from document_sdk.pdf._structural_engine.facts.contracts import PdfBoundingBox
from document_sdk.pdf._structural_engine.facts.coordinates import (
    pdfminer_native_origin_to_canonical,
)
from document_sdk.pdf._structural_engine.structure.identity import (
    canonical_json_digest_and_size,
    canonical_sha256,
)

if TYPE_CHECKING:
    from collections.abc import Sequence

    from document_sdk.pdf._structural_engine.facts.contracts import (
        PdfPageFacts,
        PdfTextMember,
    )
    from document_sdk.pdf._structural_engine.facts.native_text_contracts import (
        PdfNativeTextShowEvent,
    )
    from document_sdk.pdf._structural_engine.layout.contracts import PdfLayoutNode


class CrossedPhysicalSeparator(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    axis: Literal["COLUMN"] = "COLUMN"
    boundary_index: int = Field(ge=1)
    coordinate: float
    outer_boundary: bool
    member_id: str = Field(pattern=r"^PDFF-[0-9a-f]{24}$")
    source_drawing_fact_ids: tuple[str, ...]


class SourceAnchoredOverflowProof(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    schema_version: Literal["pdf_source_anchored_overflow.v1"] = (
        "pdf_source_anchored_overflow.v1"
    )
    proof_id: str = Field(pattern=r"^P3C-source-anchored-overflow-[0-9a-f]{64}$")
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    grid_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    native_event_id: str = Field(pattern=r"^PDFTE-[0-9a-f]{64}$")
    native_event_ordinal: int = Field(ge=0)
    parent_fact_id: str = Field(pattern=r"^PDFF-[0-9a-f]{24}$")
    parent_layout_node_id: str = Field(pattern=r"^PDFLN-[0-9a-f]{24}$")
    member_ids: tuple[str, ...] = Field(min_length=1, max_length=100_000)
    actual_origins: tuple[tuple[float, float], ...]
    actual_member_geometry: tuple[PdfBoundingBox, ...]
    actual_geometry: PdfBoundingBox
    cell_geometry: PdfBoundingBox
    row_index: int = Field(ge=0)
    column_index: int = Field(ge=0)
    text: str
    crossings: tuple[CrossedPhysicalSeparator, ...]
    basis: Literal["independent_native_event_repeated_physical_cell_anchors"] = (
        "independent_native_event_repeated_physical_cell_anchors"
    )
    ownership_status: Literal["SOURCE_ANCHORED_WITH_GEOMETRY_LIMITATION"] = (
        "SOURCE_ANCHORED_WITH_GEOMETRY_LIMITATION"
    )
    cell_state: Literal["AMBIGUOUS"] = "AMBIGUOUS"
    table_outcome: Literal["PARTIAL"] = "PARTIAL"
    limitation_codes: tuple[str, ...] = (
        "source_anchored_grid_contains_actual_overflow",
    )

    @model_validator(mode="after")
    def validate_identity(self) -> SourceAnchoredOverflowProof:
        if len(set(self.member_ids)) != len(self.member_ids):
            raise ValueError("source-anchored proof repeats a member")
        if (
            not len(self.member_ids)
            == len(self.actual_origins)
            == len(self.actual_member_geometry)
        ):
            raise ValueError("source-anchored proof member evidence is incomplete")
        expected = "P3C-source-anchored-overflow-" + canonical_sha256(
            self.model_dump(exclude={"proof_id"})
        )
        if self.proof_id != expected:
            raise ValueError("source-anchored proof identity mismatch")
        return self


@dataclass(frozen=True)
class SourceAnchoredOwnershipResult:
    status: Literal["PARTIAL", "AMBIGUOUS", "NOT_APPLICABLE"]
    proofs: tuple[SourceAnchoredOverflowProof, ...] = ()
    limitation_codes: tuple[str, ...] = ()


def _reject(code: str) -> SourceAnchoredOwnershipResult:
    return SourceAnchoredOwnershipResult("AMBIGUOUS", limitation_codes=(code,))


def _inside(box: PdfBoundingBox, outer: PdfBoundingBox) -> bool:
    return (
        outer.x0 <= box.x0 <= box.x1 <= outer.x1
        and outer.y0 <= box.y0 <= box.y1 <= outer.y1
    )


def _overlaps(a: PdfBoundingBox, b: PdfBoundingBox) -> bool:
    return min(a.x1, b.x1) > max(a.x0, b.x0) and min(a.y1, b.y1) > max(a.y0, b.y0)


def _interval(value: float, axes: tuple[float, ...]) -> int | None:
    index = bisect_right(axes, value) - 1
    return (
        index
        if 0 <= index < len(axes) - 1 and axes[index] < value < axes[index + 1]
        else None
    )


def _equal_observation(left: float, right: float) -> bool:
    return abs(left - right) <= 4 * max(ulp(left), ulp(right))


def _covered(intervals: list[tuple[float, float]], low: float, high: float) -> bool:
    cursor = low
    for start, end in sorted(intervals):
        if start > cursor:
            return False
        cursor = max(cursor, end)
        if cursor >= high:
            return True
    return False


def select_source_anchored_overflow(
    *,
    source_sha256: str,
    page: PdfPageFacts,
    nodes: Sequence[PdfLayoutNode],
    row_coordinates: tuple[float, ...],
    column_coordinates: tuple[float, ...],
    maximum_selections: int = 4096,
    maximum_references: int = 100_000,
    maximum_bytes: int = 8 * 1024 * 1024,
    maximum_collision_comparisons: int = 100_000,
) -> SourceAnchoredOwnershipResult:
    """Reconstruct bounded source anchors; all rejected content stays in Facts.

    This does not issue legacy member bindings, change any bbox, relax a physical
    boundary, or declare a PROVEN cell. Canonical must rerun this function against
    its bound source page and compare the exact resulting proofs.
    """
    rows, columns = row_coordinates, column_coordinates
    if (
        len(rows) < 3
        or len(columns) < 3
        or rows != tuple(sorted(set(rows)))
        or columns != tuple(sorted(set(columns)))
        or not all(isfinite(v) for v in (*rows, *columns))
    ):
        return _reject("native_anchor_grid_requires_ordered_two_by_two_axes")
    cells = (len(rows) - 1) * (len(columns) - 1)
    if cells > maximum_selections:
        return _reject("native_anchor_selection_limit")
    report = page.native_text_event_evidence
    if (
        report is None
        or report.availability != "COMPLETE"
        or report.truncated
        or page.text_member_inventory_status != "COMPLETE"
    ):
        return _reject("native_anchor_event_or_member_inventory_incomplete")
    grid_box = PdfBoundingBox(x0=columns[0], y0=rows[0], x1=columns[-1], y1=rows[-1])
    if not _inside(
        grid_box,
        PdfBoundingBox(x0=0, y0=0, x1=page.canonical_width, y1=page.canonical_height),
    ):
        return _reject("native_anchor_grid_exceeds_physical_page")
    node_map = {node.node_id: node for node in nodes}
    if len(node_map) != len(nodes) or any(
        node.source_page_id != page.page_id for node in nodes
    ):
        return _reject("native_anchor_layout_page_or_identity_conflict")
    drawing_nodes = {
        node.source_fact_id
        for node in nodes
        if node.node_type == "drawing" and node.geometry_quality == "precise"
    }
    support: dict[tuple[str, float], list[tuple[float, float, str]]] = {}
    for drawing in page.drawings:
        box = drawing.bbox
        if (
            drawing.fact_id not in drawing_nodes
            or drawing.kind != "line"
            or drawing.paint_operation != "stroke"
            or drawing.is_clipping_path
            or drawing.warnings
            or not drawing.path_geometry_complete
            or drawing.path_segment_truncated
            or drawing.bbox_semantics.kind != "path_geometry"
        ):
            continue
        if box.y0 == box.y1 and box.x0 < box.x1:
            key, start, end = ("ROW", box.y0), box.x0, box.x1
        elif box.x0 == box.x1 and box.y0 < box.y1:
            key, start, end = ("COLUMN", box.x0), box.y0, box.y1
        else:
            continue
        support.setdefault(key, []).append((start, end, drawing.fact_id))
    used_separator_ids: set[str] = set()
    for axis, values, low, high in (
        ("ROW", rows, columns[0], columns[-1]),
        ("COLUMN", columns, rows[0], rows[-1]),
    ):
        for coordinate in values:
            segments = support.get((axis, coordinate), ())
            if not _covered([(a, b) for a, b, _ in segments], low, high):
                return _reject("native_anchor_grid_lacks_complete_independent_strokes")
            used_separator_ids.update(identity for _, _, identity in segments)
    grid_identity = canonical_sha256(
        dict(
            source_sha256=source_sha256,
            page_id=page.page_id,
            rows=rows,
            columns=columns,
            source_drawing_fact_ids=tuple(sorted(used_separator_ids)),
        )
    )

    members = {member.member_id: member for member in page.text_members}
    if len(members) != len(page.text_members):
        return _reject("native_anchor_member_identity_repeated")
    by_event: dict[str, list[PdfTextMember]] = {}
    for member in page.text_members:
        if member.native_text_event_id is not None:
            by_event.setdefault(member.native_text_event_id, []).append(member)
        elif member.bbox is not None and _overlaps(member.bbox, grid_box):
            return _reject("native_anchor_intersecting_member_has_no_event")
    event_map = {event.source_event_id: event for event in report.events}
    if len(event_map) != len(report.events):
        return _reject("native_anchor_event_identity_repeated")
    facts = {
        fact.fact_id: fact
        for layer in (
            page.words,
            page.text_spans,
            page.line_candidates,
            page.characters,
        )
        for fact in layer
    }
    owners: dict[str, list[PdfLayoutNode]] = {}
    parent_positions: dict[str, dict[str, int]] = {}
    for node in nodes:
        parent = facts.get(node.source_fact_id)
        if node.text_layer_role != "primary" or parent is None:
            continue
        if (
            parent.member_inventory_status != "COMPLETE"
            or parent.member_projection_status != "EXACT"
            or not parent.member_ids
            or any(key not in members for key in parent.member_ids)
            or "".join(members[key].text for key in parent.member_ids) != parent.text
        ):
            continue
        parent_positions[node.node_id] = {
            key: i for i, key in enumerate(parent.member_ids)
        }
        for member_key in parent.member_ids:
            owners.setdefault(member_key, []).append(node)

    selected: dict[
        tuple[int, int],
        tuple[
            PdfNativeTextShowEvent,
            list[PdfTextMember],
            tuple[tuple[float, float], ...],
            PdfLayoutNode,
        ],
    ] = {}
    total_references = 0
    seen_native_ordinals: set[int] = set()
    for event_id, group in by_event.items():
        if not any(
            member.bbox is not None and _overlaps(member.bbox, grid_box)
            for member in group
        ):
            continue
        event = event_map.get(event_id)
        if (
            event is None
            or event.source_sha256 != source_sha256
            or event.page_number != page.page_number
            or event.completeness != "COMPLETE"
            or event.limitation_codes
            or event.source_member_count != len(group)
            or event.retained_member_count != len(group)
        ):
            return _reject("native_anchor_event_membership_incomplete_or_foreign")
        if (
            event.operator not in {"Tj", "TJ"}
            or event.string_segment_count != 1
            or event.numeric_adjustment_count
        ):
            return _reject("native_anchor_operator_positioning_not_supported")
        group.sort(
            key=lambda member: (
                member.native_text_event_member_ordinal
                if member.native_text_event_member_ordinal is not None
                else -1
            )
        )
        if [member.native_text_event_member_ordinal for member in group] != list(
            range(len(group))
        ):
            return _reject("native_anchor_event_member_order_incomplete")
        origins = []
        for member in group:
            matrix = member.text_transform
            native_index = member.native_character_ordinal
            if (
                member.page_id != page.page_id
                or member.native_text_event_ordinal != event.native_event_ordinal
                or member.selection_state != "RETAINED"
                or member.duplicate_of_member_id is not None
                or member.geometry_status != "INSIDE"
                or member.bbox is None
                or member.warnings
                or member.rotation != 0
                or member.source_writing_mode != "HORIZONTAL"
                or member.parser_advance is None
                or not isfinite(member.parser_advance)
                or member.parser_advance <= 0
                or native_index is None
                or native_index in seen_native_ordinals
                or matrix is None
                or (matrix.a, matrix.b, matrix.c, matrix.d) != (1, 0, 0, 1)
            ):
                return _reject("native_anchor_member_origin_or_native_state_unproven")
            seen_native_ordinals.add(native_index)
            media, effective = page.media_box, page.effective_page_box
            try:
                origin = pdfminer_native_origin_to_canonical(
                    parser_origin=(matrix.e, matrix.f),
                    media_box=(media.x0, media.y0, media.x1, media.y1),
                    effective_box=(
                        effective.x0,
                        effective.y0,
                        effective.x1,
                        effective.y1,
                    ),
                    page_rotation=page.rotation,
                    user_unit=page.user_unit,
                )
            except ValueError:
                return _reject("native_anchor_coordinate_transform_unproven")
            origins.append(origin)
        if any(
            a.native_character_ordinal is None
            or b.native_character_ordinal != a.native_character_ordinal + 1
            for a, b in pairwise(group)
        ):
            return _reject("native_anchor_event_emission_not_contiguous")
        if any(
            not _equal_observation(a[1], b[1]) or b[0] <= a[0]
            for a, b in pairwise(origins)
        ):
            return _reject("native_anchor_baseline_or_origin_order_ambiguous")
        origin_cells = {(_interval(y, rows), _interval(x, columns)) for x, y in origins}
        if len(origin_cells) != 1 or any(
            index is None for cell in origin_cells for index in cell
        ):
            return _reject("native_anchor_event_origins_cross_or_touch_cells")
        row, column = next(iter(origin_cells))
        if row is None or column is None:
            return _reject("native_anchor_event_origins_cross_or_touch_cells")
        if (row, column) in selected:
            return _reject("native_anchor_cell_has_competing_or_overprinted_events")
        candidate_nodes = []
        ids = tuple(member.member_id for member in group)
        for node in owners.get(ids[0], ()):
            parent = facts[node.source_fact_id]
            start = parent_positions[node.node_id][ids[0]]
            if parent.member_ids[start : start + len(ids)] == ids and all(
                member.bbox is not None and _inside(member.bbox, node.bbox)
                for member in group
            ):
                candidate_nodes.append(node)
        if len(candidate_nodes) != 1:
            return _reject("native_anchor_primary_parent_lineage_not_unique")
        total_references += len(group)
        if total_references > maximum_references:
            return _reject("native_anchor_reference_limit")
        selected[(row, column)] = (event, group, tuple(origins), candidate_nodes[0])
    if set(selected) != {
        (r, c) for r in range(len(rows) - 1) for c in range(len(columns) - 1)
    }:
        return _reject("native_anchor_grid_lacks_one_independent_event_per_cell")
    for column in range(len(columns) - 1):
        starts = [selected[(row, column)][2][0][0] for row in range(len(rows) - 1)]
        if any(not _equal_observation(starts[0], value) for value in starts[1:]):
            return _reject("native_anchor_column_origins_do_not_repeat")
    for row in range(len(rows) - 1):
        baselines = [
            selected[(row, column)][2][0][1] for column in range(len(columns) - 1)
        ]
        if any(not _equal_observation(baselines[0], value) for value in baselines[1:]):
            return _reject("native_anchor_row_baselines_do_not_repeat")
    offsets = [selected[(row, 0)][2][0][1] - rows[row] for row in range(len(rows) - 1)]
    if any(not _equal_observation(offsets[0], value) for value in offsets[1:]):
        return _reject("native_anchor_relative_row_origins_do_not_repeat")

    proofs = []
    crossing_count = serialized_bytes = comparisons = 0
    for (row, column), (event, group, proof_origins, node) in sorted(selected.items()):
        cell = PdfBoundingBox(
            x0=columns[column], y0=rows[row], x1=columns[column + 1], y1=rows[row + 1]
        )
        crossings = []
        for ordinal, member in enumerate(group):
            member_box = member.bbox
            if member_box is None:
                return _reject("native_anchor_member_geometry_missing")
            if _inside(member_box, cell):
                continue
            if not (
                ordinal == len(group) - 1
                and cell.x0 <= member_box.x0 < cell.x1 < member_box.x1
                and cell.y0 <= member_box.y0 < member_box.y1 <= cell.y1
            ):
                return _reject("native_anchor_overflow_is_not_terminal_right_glyph")
            if column + 1 < len(columns) - 1:
                adjacent = selected[(row, column + 1)]
                if member_box.x1 >= adjacent[2][0][0]:
                    return _reject("native_anchor_overflow_reaches_neighbor_origin")
            group_ids = {item.member_id for item in group}
            for other in page.text_members:
                comparisons += 1
                if comparisons > maximum_collision_comparisons:
                    return _reject("native_anchor_collision_scan_limit")
                if (
                    other.member_id not in group_ids
                    and other.bbox is not None
                    and _overlaps(member_box, other.bbox)
                ):
                    return _reject(
                        "native_anchor_overflow_intersects_other_source_text"
                    )
            crossings.append(
                CrossedPhysicalSeparator(
                    boundary_index=column + 1,
                    coordinate=cell.x1,
                    outer_boundary=column == len(columns) - 2,
                    member_id=member.member_id,
                    source_drawing_fact_ids=tuple(
                        sorted(
                            identity for _, _, identity in support[("COLUMN", cell.x1)]
                        )
                    ),
                )
            )
        crossing_count += len(crossings)
        boxes = tuple(member.bbox for member in group if member.bbox is not None)
        proof_values = dict(
            source_sha256=source_sha256,
            page_id=page.page_id,
            grid_identity=grid_identity,
            native_event_id=event.source_event_id,
            native_event_ordinal=event.native_event_ordinal,
            parent_fact_id=node.source_fact_id,
            parent_layout_node_id=node.node_id,
            member_ids=tuple(member.member_id for member in group),
            actual_origins=proof_origins,
            actual_member_geometry=boxes,
            actual_geometry=PdfBoundingBox(
                x0=min(box.x0 for box in boxes),
                y0=min(box.y0 for box in boxes),
                x1=max(box.x1 for box in boxes),
                y1=max(box.y1 for box in boxes),
            ),
            cell_geometry=cell,
            row_index=row,
            column_index=column,
            text="".join(member.text for member in group),
            crossings=tuple(crossings),
        )
        payload = {
            name: definition.default
            for name, definition in SourceAnchoredOverflowProof.model_fields.items()
            if name != "proof_id" and not definition.is_required()
        } | proof_values
        proof = SourceAnchoredOverflowProof.model_validate(
            payload
            | {"proof_id": "P3C-source-anchored-overflow-" + canonical_sha256(payload)}
        )
        serialized_bytes += canonical_json_digest_and_size(proof)[1] + 1
        if serialized_bytes + 2 > maximum_bytes:
            return _reject("native_anchor_evidence_bytes_limit")
        proofs.append(proof)
    if not crossing_count:
        return SourceAnchoredOwnershipResult("NOT_APPLICABLE")
    return SourceAnchoredOwnershipResult(
        "PARTIAL", tuple(proofs), ("source_anchored_grid_contains_actual_overflow",)
    )


def validate_source_anchored_overflow(
    proofs: Sequence[SourceAnchoredOverflowProof],
    *,
    source_sha256: str,
    page: PdfPageFacts,
    nodes: Sequence[PdfLayoutNode],
    row_coordinates: tuple[float, ...],
    column_coordinates: tuple[float, ...],
) -> None:
    """Canonical replay requires exact proofs from the bound actual source page."""
    reconstructed = select_source_anchored_overflow(
        source_sha256=source_sha256,
        page=page,
        nodes=nodes,
        row_coordinates=row_coordinates,
        column_coordinates=column_coordinates,
    )
    if reconstructed.status != "PARTIAL" or reconstructed.proofs != tuple(proofs):
        raise ValueError(
            "source-anchored overflow proof does not reconstruct from source"
        )

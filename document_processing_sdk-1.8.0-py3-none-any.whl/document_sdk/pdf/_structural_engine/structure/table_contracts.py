# ruff: noqa: B905, C901, EM101, EM102, I001, PLR0912, PLR0913, PLR0915, RUF007, TRY003, UP037

from __future__ import annotations

from hashlib import sha256
from typing import Any, Literal, cast

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    SerializerFunctionWrapHandler,
    model_serializer,
    model_validator,
)

from document_sdk.pdf._structural_engine.facts.contracts import PdfBoundingBox

from .identity import canonical_sha256, canonical_json_digest_and_size
from .native_event_ownership import SourceAnchoredOverflowProof  # noqa: TC001 - Pydantic runtime field.
from . import table_member_contracts as _member_contracts  # noqa: TC001 - Pydantic runtime fields.


PDF_TABLE_STRUCTURE_VERSION = "pdf_table_structure.v1"
PDF_TABLE_PAGE_SIDECAR_VERSION = "pdf_table_structure_page_sidecar.v3"
PDF_TABLE_ALGORITHM_VERSION = "pdf_table_structure.34"
PDF_TABLE_OPERATION_VERSION = "pdf_table_structure_safe_runtime.v1"
MAXIMUM_TABLE_PROJECTION_PARTS = 65_536
MAXIMUM_TABLE_SOURCE_SELECTIONS = 4096
MAXIMUM_TABLE_SOURCE_REFERENCES = 100_000

PdfTablePageOutcome = Literal[
    "COMPLETE",
    "PARTIAL",
    "AMBIGUOUS",
    "NO_TABLE",
    "UNSUPPORTED",
    "UNAVAILABLE",
    "IMAGE_ONLY_OCR_REQUIRED",
    "LEGACY_ENCODING_UNRELIABLE",
]
PdfTableState = Literal["COMPLETE", "PARTIAL", "AMBIGUOUS"]
PdfCellState = Literal["PROVEN", "PROVEN_EMPTY", "AMBIGUOUS", "UNAVAILABLE"]
PdfCellRole = Literal["COLUMN_HEADER_LIKE", "ROW_HEADER_LIKE", "BODY_LIKE", "UNKNOWN"]
PdfCellRoleStatus = Literal["PROVEN", "CANDIDATE", "UNAVAILABLE"]


def table_structure_identifier(kind: str, payload: object) -> str:
    return f"P3C-{kind}-" + canonical_sha256(
        {
            "domain": PDF_TABLE_STRUCTURE_VERSION,
            "entity_kind": kind,
            "payload": payload,
        }
    )


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


def _canonical(values: tuple[str, ...], *, label: str) -> None:
    if values != tuple(sorted(set(values))):
        raise ValueError(f"{label} must be sorted and unique")


class PdfTableEvidence(_FrozenModel):
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    page_index: int = Field(ge=0)
    inherited_page_sidecar_id: str = Field(pattern=r"^P3S-page-evidence-[0-9a-f]{64}$")
    inherited_page_sidecar_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    inherited_manifest_id: str = Field(pattern=r"^P3S-page-manifest-[0-9a-f]{64}$")
    reading_page_sidecar_id: str | None = Field(
        default=None, pattern=r"^P3B-structure-page-[0-9a-f]{64}$"
    )
    reading_page_sidecar_sha256: str | None = Field(
        default=None, pattern=r"^[0-9a-f]{64}$"
    )
    source_fact_ids: tuple[str, ...] = ()
    source_layout_node_ids: tuple[str, ...] = ()
    drawing_fact_ids: tuple[str, ...] = ()
    separator_candidate_ids: tuple[str, ...] = ()
    evidence_categories: tuple[str, ...]
    geometry: PdfBoundingBox | None = None

    @model_validator(mode="after")
    def validate_evidence(self) -> "PdfTableEvidence":
        for values, label in (
            (self.source_fact_ids, "source Fact IDs"),
            (self.source_layout_node_ids, "source Layout node IDs"),
            (self.drawing_fact_ids, "drawing Fact IDs"),
            (self.separator_candidate_ids, "separator candidate IDs"),
            (self.evidence_categories, "evidence categories"),
        ):
            _canonical(values, label=label)
        if any(not value.startswith("PDFF-") for value in self.source_fact_ids):
            message = "table evidence requires Canonical Fact IDs"
            raise ValueError(message)
        if any(not value.startswith("PDFF-") for value in self.drawing_fact_ids):
            message = "drawing evidence requires Canonical Fact IDs"
            raise ValueError(message)
        if any(not value.startswith("PDFLN-") for value in self.source_layout_node_ids):
            message = "table evidence requires Layout node IDs"
            raise ValueError(message)
        if any(
            not value.startswith("PDFLS-") for value in self.separator_candidate_ids
        ):
            message = "table evidence requires separator candidate IDs"
            raise ValueError(message)
        reading_pair = (
            self.reading_page_sidecar_id is not None,
            self.reading_page_sidecar_sha256 is not None,
        )
        if reading_pair[0] != reading_pair[1]:
            message = "Phase 3B reading association must be an exact pair"
            raise ValueError(message)
        if not self.evidence_categories:
            message = "table evidence requires an explicit physical category"
            raise ValueError(message)
        return self


class PdfTableAxisBoundary(_FrozenModel):
    boundary_id: str = Field(pattern=r"^P3C-axis-boundary-[0-9a-f]{64}$")
    axis: Literal["ROW", "COLUMN"]
    boundary_index: int = Field(ge=0)
    coordinate: float
    evidence: PdfTableEvidence
    state: Literal["PROVEN", "AMBIGUOUS"]

    @model_validator(mode="after")
    def validate_identity(self) -> "PdfTableAxisBoundary":
        expected = table_structure_identifier(
            "axis-boundary", self.model_dump(exclude={"boundary_id"})
        )
        if self.boundary_id != expected:
            message = "table axis-boundary identity mismatch"
            raise ValueError(message)
        return self


class PdfTableCell(_FrozenModel):
    cell_id: str = Field(pattern=r"^P3C-cell-[0-9a-f]{64}$")
    row_start: int = Field(ge=0)
    row_span: int = Field(ge=1)
    column_start: int = Field(ge=0)
    column_span: int = Field(ge=1)
    geometry: PdfBoundingBox
    text: str
    text_fact_ids: tuple[str, ...] = ()
    text_layout_node_ids: tuple[str, ...] = ()
    text_assignment_evidence: tuple[str, ...] = ()
    state: PdfCellState
    role: PdfCellRole
    role_status: PdfCellRoleStatus
    role_evidence: tuple[str, ...] = ()
    empty_cell_evidence: tuple[str, ...] = ()
    evidence: PdfTableEvidence
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_cell(self) -> "PdfTableCell":
        for values, label in (
            (self.text_fact_ids, "cell text Fact IDs"),
            (self.text_layout_node_ids, "cell text Layout node IDs"),
            (self.text_assignment_evidence, "text-assignment evidence"),
            (self.role_evidence, "cell role evidence"),
            (self.empty_cell_evidence, "empty-cell evidence"),
            (self.limitation_codes, "cell limitations"),
        ):
            _canonical(values, label=label)
        if self.state == "PROVEN_EMPTY":
            if self.text or self.text_fact_ids or self.text_layout_node_ids:
                message = "proven empty cell cannot contain source text"
                raise ValueError(message)
            if not self.empty_cell_evidence:
                raise ValueError(
                    "proven empty cell requires physical enclosure evidence"
                )
        elif self.empty_cell_evidence:
            message = "non-empty cell cannot claim empty-cell evidence"
            raise ValueError(message)
        if self.text and (
            not self.text_fact_ids
            or not self.text_layout_node_ids
            or not self.text_assignment_evidence
        ):
            message = "cell text requires exact source assignment evidence"
            raise ValueError(message)
        if bool(self.text_fact_ids) != bool(self.text_layout_node_ids):
            message = "cell text Fact and Layout membership must be paired"
            raise ValueError(message)
        if set(self.text_fact_ids) - set(self.evidence.source_fact_ids):
            message = "cell text Facts are absent from cell evidence"
            raise ValueError(message)
        if set(self.text_layout_node_ids) - set(self.evidence.source_layout_node_ids):
            message = "cell text Layout nodes are absent from cell evidence"
            raise ValueError(message)
        if self.role_status == "PROVEN" and not self.role_evidence:
            message = "proven cell role requires physical evidence"
            raise ValueError(message)
        if self.role == "UNKNOWN" and self.role_status == "PROVEN":
            message = "unknown cell role cannot be proven"
            raise ValueError(message)
        if self.state in {"AMBIGUOUS", "UNAVAILABLE"} and not self.limitation_codes:
            message = "non-proven cell requires a limitation"
            raise ValueError(message)
        expected = table_structure_identifier(
            "cell", self.model_dump(exclude={"cell_id"})
        )
        if self.cell_id != expected:
            message = "table cell identity mismatch"
            raise ValueError(message)
        return self


class PdfTableRow(_FrozenModel):
    row_id: str = Field(pattern=r"^P3C-row-[0-9a-f]{64}$")
    row_index: int = Field(ge=0)
    geometry: PdfBoundingBox
    anchor_cell_ids: tuple[str, ...]
    evidence: PdfTableEvidence

    @model_validator(mode="after")
    def validate_row(self) -> "PdfTableRow":
        _canonical(self.anchor_cell_ids, label="row anchor cell IDs")
        expected = table_structure_identifier(
            "row", self.model_dump(exclude={"row_id"})
        )
        if self.row_id != expected:
            message = "table row identity mismatch"
            raise ValueError(message)
        return self


class PdfTableColumn(_FrozenModel):
    column_id: str = Field(pattern=r"^P3C-column-[0-9a-f]{64}$")
    column_index: int = Field(ge=0)
    geometry: PdfBoundingBox
    anchor_cell_ids: tuple[str, ...]
    evidence: PdfTableEvidence

    @model_validator(mode="after")
    def validate_column(self) -> "PdfTableColumn":
        _canonical(self.anchor_cell_ids, label="column anchor cell IDs")
        expected = table_structure_identifier(
            "column", self.model_dump(exclude={"column_id"})
        )
        if self.column_id != expected:
            message = "table column identity mismatch"
            raise ValueError(message)
        return self


class PdfTable(_FrozenModel):
    table_id: str = Field(pattern=r"^P3C-table-[0-9a-f]{64}$")
    table_index: int = Field(ge=0)
    geometry: PdfBoundingBox
    state: PdfTableState
    row_boundaries: tuple[PdfTableAxisBoundary, ...]
    column_boundaries: tuple[PdfTableAxisBoundary, ...]
    rows: tuple[PdfTableRow, ...]
    columns: tuple[PdfTableColumn, ...]
    cells: tuple[PdfTableCell, ...]
    evidence: PdfTableEvidence
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_table(self) -> "PdfTable":
        if tuple(item.row_index for item in self.rows) != tuple(range(len(self.rows))):
            message = "table rows must be contiguous and ordered"
            raise ValueError(message)
        if tuple(item.column_index for item in self.columns) != tuple(
            range(len(self.columns))
        ):
            message = "table columns must be contiguous and ordered"
            raise ValueError(message)
        if tuple(item.boundary_index for item in self.row_boundaries) != tuple(
            range(len(self.row_boundaries))
        ) or tuple(item.boundary_index for item in self.column_boundaries) != tuple(
            range(len(self.column_boundaries))
        ):
            message = "table axis boundaries must be contiguous and ordered"
            raise ValueError(message)
        if len(self.row_boundaries) != len(self.rows) + 1:
            message = "row boundary count must be row count plus one"
            raise ValueError(message)
        if len(self.column_boundaries) != len(self.columns) + 1:
            message = "column boundary count must be column count plus one"
            raise ValueError(message)
        if any(item.axis != "ROW" for item in self.row_boundaries) or any(
            item.axis != "COLUMN" for item in self.column_boundaries
        ):
            message = "table axis boundary type mismatch"
            raise ValueError(message)
        row_coordinates = tuple(item.coordinate for item in self.row_boundaries)
        column_coordinates = tuple(item.coordinate for item in self.column_boundaries)
        if any(
            current >= following
            for current, following in zip(row_coordinates, row_coordinates[1:])
        ) or any(
            current >= following
            for current, following in zip(column_coordinates, column_coordinates[1:])
        ):
            message = "table axis coordinates must be strictly increasing"
            raise ValueError(message)
        expected_table_geometry = PdfBoundingBox(
            x0=column_coordinates[0],
            y0=row_coordinates[0],
            x1=column_coordinates[-1],
            y1=row_coordinates[-1],
        )
        if self.geometry != expected_table_geometry:
            message = "table geometry does not match outer axis boundaries"
            raise ValueError(message)
        if self.evidence.geometry != self.geometry:
            message = "table evidence geometry mismatch"
            raise ValueError(message)
        if not self.rows or not self.columns or not self.cells:
            message = "accepted table requires rows, columns, and cells"
            raise ValueError(message)
        cell_ids = tuple(item.cell_id for item in self.cells)
        if len(cell_ids) != len(set(cell_ids)):
            message = "table repeats a cell identity"
            raise ValueError(message)
        coverage: dict[tuple[int, int], str] = {}
        for cell in self.cells:
            if cell.row_start + cell.row_span > len(
                self.rows
            ) or cell.column_start + cell.column_span > len(self.columns):
                message = "cell span exceeds table axes"
                raise ValueError(message)
            expected_cell_geometry = PdfBoundingBox(
                x0=column_coordinates[cell.column_start],
                y0=row_coordinates[cell.row_start],
                x1=column_coordinates[cell.column_start + cell.column_span],
                y1=row_coordinates[cell.row_start + cell.row_span],
            )
            if cell.geometry != expected_cell_geometry:
                message = "cell geometry does not match axis span"
                raise ValueError(message)
            if cell.evidence.geometry != cell.geometry:
                message = "cell evidence geometry mismatch"
                raise ValueError(message)
            for row_index in range(cell.row_start, cell.row_start + cell.row_span):
                for column_index in range(
                    cell.column_start, cell.column_start + cell.column_span
                ):
                    position = (row_index, column_index)
                    if position in coverage:
                        message = "cell spans overlap"
                        raise ValueError(message)
                    coverage[position] = cell.cell_id
        expected_positions = {
            (row_index, column_index)
            for row_index in range(len(self.rows))
            for column_index in range(len(self.columns))
        }
        if self.state == "COMPLETE" and set(coverage) != expected_positions:
            message = "complete table must cover every physical cell position"
            raise ValueError(message)
        if self.state != "COMPLETE" and not self.limitation_codes:
            message = "non-complete table requires a limitation"
            raise ValueError(message)
        for row in self.rows:
            expected_geometry = PdfBoundingBox(
                x0=column_coordinates[0],
                y0=row_coordinates[row.row_index],
                x1=column_coordinates[-1],
                y1=row_coordinates[row.row_index + 1],
            )
            if row.geometry != expected_geometry:
                message = "row geometry does not match axis boundaries"
                raise ValueError(message)
            expected = tuple(
                sorted(
                    cell.cell_id
                    for cell in self.cells
                    if cell.row_start == row.row_index
                )
            )
            if row.anchor_cell_ids != expected:
                message = "row anchor-cell membership mismatch"
                raise ValueError(message)
        for column in self.columns:
            expected_geometry = PdfBoundingBox(
                x0=column_coordinates[column.column_index],
                y0=row_coordinates[0],
                x1=column_coordinates[column.column_index + 1],
                y1=row_coordinates[-1],
            )
            if column.geometry != expected_geometry:
                message = "column geometry does not match axis boundaries"
                raise ValueError(message)
            expected = tuple(
                sorted(
                    cell.cell_id
                    for cell in self.cells
                    if cell.column_start == column.column_index
                )
            )
            if column.anchor_cell_ids != expected:
                message = "column anchor-cell membership mismatch"
                raise ValueError(message)
        all_cell_facts = {fact for cell in self.cells for fact in cell.text_fact_ids}
        if all_cell_facts - set(self.evidence.source_fact_ids):
            message = "table evidence omits a cell source Fact"
            raise ValueError(message)
        _canonical(self.limitation_codes, label="table limitations")
        expected = table_structure_identifier(  # type: ignore[assignment]
            "table", self.model_dump(exclude={"table_id"})
        )
        if self.table_id != expected:  # type: ignore[comparison-overlap]
            message = "table identity mismatch"
            raise ValueError(message)
        return self  # type: ignore[unreachable]


class PdfTableStructurePageSidecar(_FrozenModel):
    schema_version: Literal[
        "pdf_table_structure_page_sidecar.v1",
        "pdf_table_structure_page_sidecar.v2",
        "pdf_table_structure_page_sidecar.v3",
    ] = PDF_TABLE_PAGE_SIDECAR_VERSION  # type: ignore[assignment]
    sidecar_id: str = Field(pattern=r"^P3C-table-page-[0-9a-f]{64}$")
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    page_index: int = Field(ge=0)
    canonical_width: float = Field(gt=0)
    canonical_height: float = Field(gt=0)
    outcome: PdfTablePageOutcome
    tables: tuple[PdfTable, ...] = ()
    source_anchored_overflow_proofs: tuple[SourceAnchoredOverflowProof, ...] = Field(
        default=(), max_length=4096
    )
    member_bindings: tuple[_member_contracts.PdfTableMemberBinding, ...] = Field(
        default=(), max_length=4096
    )
    cell_text_projections: tuple[_member_contracts.PdfTableCellTextProjection, ...] = (
        Field(default=(), max_length=65_536)
    )
    negative_evidence: tuple[PdfTableEvidence, ...] = ()
    inherited_page_sidecar_id: str = Field(pattern=r"^P3S-page-evidence-[0-9a-f]{64}$")
    inherited_page_sidecar_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    inherited_manifest_id: str = Field(pattern=r"^P3S-page-manifest-[0-9a-f]{64}$")
    reading_page_sidecar_id: str | None = Field(
        default=None, pattern=r"^P3B-structure-page-[0-9a-f]{64}$"
    )
    reading_page_sidecar_sha256: str | None = Field(
        default=None, pattern=r"^[0-9a-f]{64}$"
    )
    table_component_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    evidence_component_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    algorithm_version: Literal[
        "pdf_table_structure.1",
        "pdf_table_structure.2",
        "pdf_table_structure.3",
        "pdf_table_structure.4",
        "pdf_table_structure.5",
        "pdf_table_structure.6",
        "pdf_table_structure.7",
        "pdf_table_structure.8",
        "pdf_table_structure.9",
        "pdf_table_structure.10",
        "pdf_table_structure.11",
        "pdf_table_structure.12",
        "pdf_table_structure.13",
        "pdf_table_structure.14",
        "pdf_table_structure.15",
        "pdf_table_structure.16",
        "pdf_table_structure.17",
        "pdf_table_structure.18",
        "pdf_table_structure.19",
        "pdf_table_structure.20",
        "pdf_table_structure.21",
        "pdf_table_structure.22",
        "pdf_table_structure.23",
        "pdf_table_structure.24",
        "pdf_table_structure.25",
        "pdf_table_structure.26",
        "pdf_table_structure.27",
        "pdf_table_structure.28",
        "pdf_table_structure.29",
        "pdf_table_structure.30",
        "pdf_table_structure.31",
        "pdf_table_structure.32",
        "pdf_table_structure.33",
        "pdf_table_structure.34",
    ] = PDF_TABLE_ALGORITHM_VERSION  # type: ignore[assignment]
    operation_version: Literal["pdf_table_structure_safe_runtime.v1"] = (
        PDF_TABLE_OPERATION_VERSION  # type: ignore[assignment]
    )
    configuration_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    dependency_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    limitation_codes: tuple[str, ...] = ()

    @model_serializer(mode="wrap")
    def serialize_versioned_fields(
        self, handler: SerializerFunctionWrapHandler
    ) -> dict[str, Any]:
        """Keep v1 wire fields exact; v2 explicitly carries its new evidence."""
        values = cast("dict[str, Any]", handler(self))
        if not self.schema_version.endswith(".v3"):
            values.pop("source_anchored_overflow_proofs", None)
        if self.schema_version == "pdf_table_structure_page_sidecar.v1":
            values.pop("member_bindings", None)
            values.pop("cell_text_projections", None)
        return values

    @model_validator(mode="after")
    def validate_sidecar(self) -> "PdfTableStructurePageSidecar":
        if self.schema_version.endswith(".v1") and (
            self.member_bindings or self.cell_text_projections
        ):
            message = "v1 table sidecar cannot contain member bindings"
            raise ValueError(message)
        if not self.schema_version.endswith(".v3") and (
            self.source_anchored_overflow_proofs
            or any(
                part.source_anchored_overflow_id is not None
                for projection in self.cell_text_projections
                for part in projection.parts
            )
        ):
            raise ValueError("legacy table sidecar cannot hide overflow proofs")
        if self.schema_version.endswith(".v3") and (
            len(self.member_bindings) + len(self.source_anchored_overflow_proofs)
            > MAXIMUM_TABLE_SOURCE_SELECTIONS
            or sum(len(p.member_ids) for p in self.member_bindings)
            + sum(len(p.member_ids) for p in self.source_anchored_overflow_proofs)
            > MAXIMUM_TABLE_SOURCE_REFERENCES
            or canonical_json_digest_and_size(
                (
                    self.member_bindings,
                    self.source_anchored_overflow_proofs,
                    self.cell_text_projections,
                )
            )[1]
            > 8 * 1024 * 1024
        ):
            raise ValueError("table text evidence exceeds shared finite budget")
        from .table_overflow_integration import validate_overflow_references

        validate_overflow_references(self)
        by_projection = {item.cell_id: item for item in self.cell_text_projections}
        if len(by_projection) != len(self.cell_text_projections):
            message = "table sidecar repeats a cell text projection"
            raise ValueError(message)
        cells = {cell.cell_id: cell for table in self.tables for cell in table.cells}
        if not self.schema_version.endswith(".v1") and set(by_projection) != set(cells):
            message = "v2 table text projection must cover every cell exactly"
            raise ValueError(message)
        if (
            sum(len(item.parts) for item in self.cell_text_projections)
            > MAXIMUM_TABLE_PROJECTION_PARTS
        ):
            message = "table text projection part budget exceeded"
            raise ValueError(message)
        by_binding = {item.binding_id: item for item in self.member_bindings}
        if len(by_binding) != len(self.member_bindings):
            message = "table sidecar repeats a member selection"
            raise ValueError(message)
        used_bindings: set[str] = set()
        used_members: set[str] = set()
        cells_by_parent: dict[str, set[str]] = {}
        selected_cells_by_parent: dict[str, set[str]] = {}
        for table in self.tables:
            for cell in table.cells:
                for fact_id in cell.text_fact_ids:
                    cells_by_parent.setdefault(fact_id, set()).add(cell.cell_id)
                for token in cell.text_assignment_evidence:
                    if not token.startswith("member_selection:"):
                        continue
                    binding_id = token.removeprefix("member_selection:")
                    binding = by_binding.get(binding_id)
                    if binding is None or binding_id in used_bindings:
                        message = "missing or reused table member selection"
                        raise ValueError(message)
                    if (
                        binding.source_sha256 != self.source_sha256
                        or binding.page_id != self.page_id
                        or binding.parent_fact_id not in cell.text_fact_ids
                        or binding.parent_layout_node_id
                        not in cell.text_layout_node_ids
                        or used_members.intersection(binding.member_ids)
                    ):
                        message = "table member source/parent/ownership mismatch"
                        raise ValueError(message)
                    if not (
                        cell.geometry.x0
                        <= binding.geometry.x0
                        <= binding.geometry.x1
                        <= cell.geometry.x1
                        and cell.geometry.y0
                        <= binding.geometry.y0
                        <= binding.geometry.y1
                        <= cell.geometry.y1
                    ):
                        message = "table member selection crosses its cell"
                        raise ValueError(message)
                    projection = by_projection.get(cell.cell_id)
                    if projection is None or not any(
                        part.member_binding_id == binding_id
                        for part in projection.parts
                    ):
                        message = "table member selection lacks ordered text projection"
                        raise ValueError(message)
                    used_bindings.add(binding_id)
                    used_members.update(binding.member_ids)
                    selected_cells_by_parent.setdefault(
                        binding.parent_fact_id, set()
                    ).add(cell.cell_id)
        for cell_id, projection in by_projection.items():
            cell = cells[cell_id]
            if {part.source_fact_id for part in projection.parts} != set(
                cell.text_fact_ids
            ):
                message = "table text projection Fact inventory mismatch"
                raise ValueError(message)
            if {part.source_layout_node_id for part in projection.parts} != set(
                cell.text_layout_node_ids
            ):
                message = "table text projection Layout inventory mismatch"
                raise ValueError(message)
            projected_selections = {
                part.member_binding_id
                for part in projection.parts
                if part.member_binding_id is not None
            }
            actual_selections = {
                token.removeprefix("member_selection:")
                for token in cell.text_assignment_evidence
                if token.startswith("member_selection:")
            }
            if projected_selections != actual_selections:
                message = "table text projection selection inventory mismatch"
                raise ValueError(message)
            for part in projection.parts:
                if part.member_binding_id is not None:
                    binding = by_binding[part.member_binding_id]
                    if (binding.parent_fact_id, binding.parent_layout_node_id) != (
                        part.source_fact_id,
                        part.source_layout_node_id,
                    ):
                        message = "table text projection selection parent mismatch"
                        raise ValueError(message)
        for projection in self.cell_text_projections:
            full_parents = {
                part.source_fact_id
                for part in projection.parts
                if part.member_binding_id is None
            }
            selected_parents = {
                part.source_fact_id
                for part in projection.parts
                if part.member_binding_id is not None
            }
            if full_parents & selected_parents:
                message = (
                    "cell text repeats a full parent alongside its selected members"
                )
                raise ValueError(message)
        if used_bindings != set(by_binding):
            message = "table sidecar contains an unused member selection"
            raise ValueError(message)
        if any(
            cells_by_parent[parent] != selected
            for parent, selected in selected_cells_by_parent.items()
        ):
            message = "table parent is reused as both full and selected content"
            raise ValueError(message)
        if self.outcome == "COMPLETE" and (
            not self.tables or any(table.state != "COMPLETE" for table in self.tables)
        ):
            message = "complete page requires complete table structure"
            raise ValueError(message)
        if self.outcome == "NO_TABLE" and (self.tables or not self.negative_evidence):
            message = "NO_TABLE requires explicit negative evidence only"
            raise ValueError(message)
        if (
            self.outcome
            in {
                "UNSUPPORTED",
                "UNAVAILABLE",
                "IMAGE_ONLY_OCR_REQUIRED",
                "LEGACY_ENCODING_UNRELIABLE",
            }
            and self.tables
        ):
            message = "unsupported page cannot publish a table"
            raise ValueError(message)
        if self.outcome not in {"COMPLETE", "NO_TABLE"} and not self.limitation_codes:
            message = "non-complete page outcome requires a limitation"
            raise ValueError(message)
        if tuple(table.table_index for table in self.tables) != tuple(
            range(len(self.tables))
        ):
            message = "page table order must be contiguous"
            raise ValueError(message)
        if len({table.table_id for table in self.tables}) != len(self.tables):
            message = "page repeats a table identity"
            raise ValueError(message)
        reading_pair = (
            self.reading_page_sidecar_id is not None,
            self.reading_page_sidecar_sha256 is not None,
        )
        if reading_pair[0] != reading_pair[1]:
            message = "Phase 3B reading association must be an exact pair"
            raise ValueError(message)
        for evidence in (
            *(table.evidence for table in self.tables),
            *(
                boundary.evidence
                for table in self.tables
                for boundary in (*table.row_boundaries, *table.column_boundaries)
            ),
            *(row.evidence for table in self.tables for row in table.rows),
            *(column.evidence for table in self.tables for column in table.columns),
            *(cell.evidence for table in self.tables for cell in table.cells),
            *self.negative_evidence,
        ):
            if (
                evidence.source_sha256 != self.source_sha256
                or evidence.page_id != self.page_id
                or evidence.page_index != self.page_index
                or evidence.inherited_page_sidecar_id != self.inherited_page_sidecar_id
                or evidence.inherited_page_sidecar_sha256
                != self.inherited_page_sidecar_sha256
                or evidence.inherited_manifest_id != self.inherited_manifest_id
                or evidence.reading_page_sidecar_id != self.reading_page_sidecar_id
                or evidence.reading_page_sidecar_sha256
                != self.reading_page_sidecar_sha256
            ):
                message = "table page evidence binding mismatch"
                raise ValueError(message)
            if evidence.geometry is not None and not _geometry_within_page(
                evidence.geometry,
                width=self.canonical_width,
                height=self.canonical_height,
            ):
                message = "table evidence geometry exceeds physical page"
                raise ValueError(message)
        if any(
            not _geometry_within_page(
                table.geometry,
                width=self.canonical_width,
                height=self.canonical_height,
            )
            for table in self.tables
        ):
            message = "table geometry exceeds physical page"
            raise ValueError(message)
        if self.table_component_sha256 != canonical_sha256(self.tables):
            message = "table component hash mismatch"
            raise ValueError(message)
        evidence_payload: dict[str, object] = {
            "tables": tuple(table.evidence for table in self.tables),
            "negative_evidence": self.negative_evidence,
        }
        if not self.schema_version.endswith(".v1"):
            evidence_payload["member_bindings"] = self.member_bindings
            evidence_payload["cell_text_projections"] = self.cell_text_projections
        if self.schema_version.endswith(".v3"):
            evidence_payload["source_anchored_overflow_proofs"] = (
                self.source_anchored_overflow_proofs
            )
        if self.evidence_component_sha256 != canonical_sha256(evidence_payload):
            message = "table evidence component hash mismatch"
            raise ValueError(message)
        _canonical(self.limitation_codes, label="page table limitations")
        excluded = {"sidecar_id"}
        if self.schema_version.endswith(".v1"):
            excluded.update({"member_bindings", "cell_text_projections"})
        expected = table_structure_identifier(
            "table-page", self.model_dump(exclude=excluded)
        )
        if self.sidecar_id != expected:
            message = "table page-sidecar identity mismatch"
            raise ValueError(message)
        return self


class PdfTableStructurePageReference(_FrozenModel):
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    page_index: int = Field(ge=0)
    sidecar_id: str = Field(pattern=r"^P3C-table-page-[0-9a-f]{64}$")
    sidecar_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    sidecar_bytes: int = Field(gt=0)
    outcome: PdfTablePageOutcome
    table_ids: tuple[str, ...] = ()


def build_table_page_sidecar(
    *,
    source_sha256: str,
    page_id: str,
    page_index: int,
    canonical_width: float,
    canonical_height: float,
    outcome: PdfTablePageOutcome,
    tables: tuple[PdfTable, ...],
    negative_evidence: tuple[PdfTableEvidence, ...],
    inherited_page_sidecar_id: str,
    inherited_page_sidecar_sha256: str,
    inherited_manifest_id: str,
    reading_page_sidecar_id: str | None,
    reading_page_sidecar_sha256: str | None,
    configuration_identity: str,
    dependency_identity: str,
    limitation_codes: tuple[str, ...] = (),
    member_bindings: tuple[_member_contracts.PdfTableMemberBinding, ...] = (),
    cell_text_projections: tuple[
        _member_contracts.PdfTableCellTextProjection, ...
    ] = (),
    source_anchored_overflow_proofs: tuple[SourceAnchoredOverflowProof, ...] = (),
) -> PdfTableStructurePageSidecar:
    values = {
        "schema_version": PDF_TABLE_PAGE_SIDECAR_VERSION,
        "source_sha256": source_sha256,
        "page_id": page_id,
        "page_index": page_index,
        "canonical_width": canonical_width,
        "canonical_height": canonical_height,
        "outcome": outcome,
        "tables": tables,
        "source_anchored_overflow_proofs": source_anchored_overflow_proofs,
        "member_bindings": member_bindings,
        "cell_text_projections": cell_text_projections,
        "negative_evidence": negative_evidence,
        "inherited_page_sidecar_id": inherited_page_sidecar_id,
        "inherited_page_sidecar_sha256": inherited_page_sidecar_sha256,
        "inherited_manifest_id": inherited_manifest_id,
        "reading_page_sidecar_id": reading_page_sidecar_id,
        "reading_page_sidecar_sha256": reading_page_sidecar_sha256,
        "table_component_sha256": canonical_sha256(tables),
        "evidence_component_sha256": canonical_sha256(
            {
                "tables": tuple(table.evidence for table in tables),
                "negative_evidence": negative_evidence,
                "source_anchored_overflow_proofs": source_anchored_overflow_proofs,
                "member_bindings": member_bindings,
                "cell_text_projections": cell_text_projections,
            }
        ),
        "configuration_identity": configuration_identity,
        "dependency_identity": dependency_identity,
        "algorithm_version": PDF_TABLE_ALGORITHM_VERSION,
        "operation_version": PDF_TABLE_OPERATION_VERSION,
        "limitation_codes": tuple(sorted(set(limitation_codes))),
    }
    return PdfTableStructurePageSidecar(
        sidecar_id=table_structure_identifier("table-page", values),
        **values,  # type: ignore[arg-type]
    )


def validate_table_reference_sidecar(
    *,
    reference: PdfTableStructurePageReference,
    sidecar: PdfTableStructurePageSidecar,
    content: bytes,
    expected_source_sha256: str,
) -> None:
    observed = {
        "page_id": sidecar.page_id,
        "page_index": sidecar.page_index,
        "sidecar_id": sidecar.sidecar_id,
        "sidecar_sha256": sha256(content).hexdigest(),
        "sidecar_bytes": len(content),
        "outcome": sidecar.outcome,
        "table_ids": tuple(table.table_id for table in sidecar.tables),
        "source_sha256": sidecar.source_sha256,
    }
    expected = {
        "page_id": reference.page_id,
        "page_index": reference.page_index,
        "sidecar_id": reference.sidecar_id,
        "sidecar_sha256": reference.sidecar_sha256,
        "sidecar_bytes": reference.sidecar_bytes,
        "outcome": reference.outcome,
        "table_ids": reference.table_ids,
        "source_sha256": expected_source_sha256,
    }
    mismatches = tuple(name for name in expected if observed[name] != expected[name])
    if mismatches:
        raise ValueError("table Reference/Sidecar mismatch: " + ",".join(mismatches))


def _geometry_within_page(
    geometry: PdfBoundingBox, *, width: float, height: float
) -> bool:
    return bool(
        geometry.x0 >= 0
        and geometry.y0 >= 0
        and geometry.x1 <= width
        and geometry.y1 <= height
    )

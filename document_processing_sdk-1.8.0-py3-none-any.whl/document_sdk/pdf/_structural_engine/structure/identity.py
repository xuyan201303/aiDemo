# ruff: noqa: C901, EM101, PLR0912, TC003, TRY003

from __future__ import annotations

import json
import math
from collections.abc import Iterator
from datetime import date, datetime, time
from decimal import ROUND_HALF_EVEN, Decimal
from enum import Enum
from hashlib import sha256
from pathlib import Path
from typing import Any
from uuid import UUID

from pydantic import BaseModel
from pydantic_core import to_jsonable_python

PDF_STRUCTURE_IDENTITY_VERSION = "pdf_structure_identity.v1"
_QUANTUM = Decimal("0.000001")


def _legacy_table_sidecar_excluded_fields(value: BaseModel) -> frozenset[str]:
    """Mirror exactly the versioned Table serializers in the streaming encoder."""
    model_type = type(value)
    if (
        model_type.__module__
        == "document_sdk.pdf._structural_engine.structure.table_contracts"
        and model_type.__name__ == "PdfTableStructurePageSidecar"
    ):
        version = getattr(value, "schema_version", None)
        if version == "pdf_table_structure_page_sidecar.v1":
            return frozenset(
                {
                    "member_bindings",
                    "cell_text_projections",
                    "source_anchored_overflow_proofs",
                }
            )
        if version == "pdf_table_structure_page_sidecar.v2":
            return frozenset({"source_anchored_overflow_proofs"})
    if (
        model_type.__module__
        == "document_sdk.pdf._structural_engine.structure.table_member_contracts"
        and model_type.__name__ == "PdfTableCellTextPart"
        and getattr(value, "source_anchored_overflow_id", None) is None
    ):
        return frozenset({"source_anchored_overflow_id"})
    return frozenset()


def _legacy_fact_serialization_context(
    value: BaseModel, *, legacy_facts_v1: bool
) -> tuple[bool, frozenset[str]]:
    """Propagate only an explicit v1 Fact artifact into its typed subtree."""
    model_type = type(value)
    if not legacy_facts_v1 and not (
        model_type.__module__ == "document_sdk.pdf._structural_engine.facts.contracts"
        and model_type.__name__ == "PdfFactArtifact"
    ):
        return False, frozenset()
    # Lazy import avoids loading the Facts package when only Table/Reading or
    # primitive identities are used. The helper imports no Fact model types.
    from document_sdk.pdf._structural_engine.facts.legacy_serialization import (
        is_legacy_fact_artifact,
        legacy_fact_model_excluded_fields,
    )

    legacy = legacy_facts_v1 or is_legacy_fact_artifact(value)
    return legacy, legacy_fact_model_excluded_fields(value, legacy_facts_v1=legacy)


def canonical_number(value: float) -> int | float:
    if not math.isfinite(value):
        raise ValueError("structural identity numbers must be finite")
    rounded = Decimal(str(value)).quantize(_QUANTUM, rounding=ROUND_HALF_EVEN)
    if rounded == 0:
        return 0
    integral = rounded.to_integral_value()
    if rounded == integral:
        return int(integral)
    return float(format(rounded, "f"))


def canonical_value(value: Any) -> Any:
    if isinstance(value, BaseModel):
        return canonical_value(value.model_dump(mode="json"))
    if isinstance(value, dict):
        return {key: canonical_value(value[key]) for key in sorted(value)}
    if isinstance(value, (list, tuple)):
        return [canonical_value(item) for item in value]
    if isinstance(value, float):
        return canonical_number(value)
    return value


def canonical_json_bytes(value: Any, *, newline: bool = False) -> bytes:
    result = json.dumps(
        canonical_value(value),
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
        allow_nan=False,
    ).encode("utf-8")
    return result + (b"\n" if newline else b"")


def canonical_json_byte_chunks(
    value: Any,
    *,
    newline: bool = False,
) -> Iterator[bytes]:
    """Yield the existing canonical encoding without building a normalized tree.

    This is an allocation-bounded equivalent of ``canonical_json_bytes`` for
    immutable evidence models.  Primitive encoding remains delegated to the
    standard JSON encoder so escaping and numeric text stay byte-identical.
    """
    encoder = json.JSONEncoder(
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
        allow_nan=False,
    )

    def primitive(item: Any) -> bytes:
        return encoder.encode(item).encode("utf-8")

    def walk(item: Any, *, legacy_facts_v1: bool = False) -> Iterator[bytes]:
        if isinstance(item, BaseModel):
            legacy_facts_v1, fact_excluded = _legacy_fact_serialization_context(
                item, legacy_facts_v1=legacy_facts_v1
            )
            yield b"{"
            first = True
            legacy_excluded = (
                _legacy_table_sidecar_excluded_fields(item) | fact_excluded
            )
            names = sorted(
                name
                for name, field in type(item).model_fields.items()
                if not field.exclude and name not in legacy_excluded
            )
            for name in names:
                if not first:
                    yield b","
                first = False
                yield primitive(name)
                yield b":"
                yield from walk(getattr(item, name), legacy_facts_v1=legacy_facts_v1)
            yield b"}"
            return
        if isinstance(item, dict):
            yield b"{"
            for index, key in enumerate(sorted(item)):
                if index:
                    yield b","
                yield primitive(key)
                yield b":"
                yield from walk(item[key], legacy_facts_v1=legacy_facts_v1)
            yield b"}"
            return
        if isinstance(item, (list, tuple)):
            yield b"["
            for index, child in enumerate(item):
                if index:
                    yield b","
                yield from walk(child, legacy_facts_v1=legacy_facts_v1)
            yield b"]"
            return
        if isinstance(item, float):
            yield primitive(canonical_number(item))
            return
        if isinstance(item, Enum):
            yield from walk(item.value, legacy_facts_v1=legacy_facts_v1)
            return
        if isinstance(item, (UUID, Path, datetime, date, time, Decimal)):
            yield primitive(to_jsonable_python(item))
            return
        yield primitive(item)

    yield from walk(value)
    if newline:
        yield b"\n"


def canonical_json_digest_and_size(value: Any) -> tuple[str, int]:
    digest = sha256()
    size = 0
    for chunk in canonical_json_byte_chunks(value):
        digest.update(chunk)
        size += len(chunk)
    return digest.hexdigest(), size


def sorted_json_model_digest(
    value: BaseModel,
    *,
    exclude_top_level_fields: frozenset[str] = frozenset(),
) -> str:
    """Hash a sealed sorted compact-JSON projection without a model-dump tree."""
    encoder = json.JSONEncoder(
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    )
    digest = sha256()

    def emit(raw: str) -> None:
        digest.update(raw.encode("utf-8"))

    def walk(
        item: Any, *, top_level: bool = False, legacy_facts_v1: bool = False
    ) -> None:
        if isinstance(item, BaseModel):
            legacy_facts_v1, fact_excluded = _legacy_fact_serialization_context(
                item, legacy_facts_v1=legacy_facts_v1
            )
            emit("{")
            fields = []
            legacy_excluded = (
                _legacy_table_sidecar_excluded_fields(item) | fact_excluded
            )
            for name, field in type(item).model_fields.items():
                if (
                    field.exclude
                    or name in legacy_excluded
                    or (top_level and name in exclude_top_level_fields)
                ):
                    continue
                key = field.serialization_alias or field.alias or name
                fields.append((key, getattr(item, name)))
            for index, (key, child) in enumerate(sorted(fields)):
                if index:
                    emit(",")
                emit(encoder.encode(key))
                emit(":")
                walk(child, legacy_facts_v1=legacy_facts_v1)
            emit("}")
            return
        if isinstance(item, dict):
            emit("{")
            for index, key in enumerate(sorted(item)):
                if index:
                    emit(",")
                emit(encoder.encode(key))
                emit(":")
                walk(item[key], legacy_facts_v1=legacy_facts_v1)
            emit("}")
            return
        if isinstance(item, (list, tuple)):
            emit("[")
            for index, child in enumerate(item):
                if index:
                    emit(",")
                walk(child, legacy_facts_v1=legacy_facts_v1)
            emit("]")
            return
        if isinstance(item, Enum):
            walk(item.value, legacy_facts_v1=legacy_facts_v1)
            return
        if isinstance(item, (UUID, Path, datetime, date, time, Decimal)):
            emit(encoder.encode(to_jsonable_python(item)))
            return
        emit(encoder.encode(item))

    walk(value, top_level=True)
    return digest.hexdigest()


def canonical_json_size(value: Any) -> int:
    return canonical_json_digest_and_size(value)[1]


def canonical_sha256(value: Any) -> str:
    return canonical_json_digest_and_size(value)[0]


def structural_identifier(kind: str, payload: Any) -> str:
    normalized_kind = kind.lower().replace("_", "-")
    if not normalized_kind or not all(
        character.isascii() and (character.isalnum() or character == "-")
        for character in normalized_kind
    ):
        raise ValueError("structural identity kind is invalid")
    digest = canonical_sha256(
        {
            "domain": PDF_STRUCTURE_IDENTITY_VERSION,
            "entity_kind": normalized_kind,
            "payload": payload,
        }
    )
    return f"P3S-{normalized_kind}-{digest}"

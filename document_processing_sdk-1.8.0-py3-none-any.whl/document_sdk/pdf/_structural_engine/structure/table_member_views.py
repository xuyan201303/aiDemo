"""Conservative Table-only views over captured same-parser text members.

A view never replaces or mutates its parent Fact/Layout node. Native character
extents remain parser observations, not asserted painted-ink bounds.
"""

from __future__ import annotations

from bisect import bisect_right
from dataclasses import dataclass
from itertools import pairwise
from math import ulp
from statistics import median
from typing import TYPE_CHECKING, Literal

from document_sdk.pdf._structural_engine.facts.contracts import (
    PdfBoundingBox,
    PdfPageFacts,
    PdfTextFact,
)
from document_sdk.pdf._structural_engine.structure.table_member_contracts import (
    PdfTableMemberBinding,
    make_member_binding,
)

if TYPE_CHECKING:
    from collections.abc import Sequence

    from document_sdk.pdf._structural_engine.facts.contracts import PdfTextMember
    from document_sdk.pdf._structural_engine.layout.contracts import PdfLayoutNode
    from document_sdk.pdf._structural_engine.structure.table_contracts import (
        PdfTableStructurePageSidecar,
    )

    from .table_member_contracts import PdfTableCellTextPart


TABLE_MEMBER_PARTITION_METHOD = "pdf_table_member_partition.v1"
MAXIMUM_TABLE_MEMBER_VIEWS = 4096
MAXIMUM_TABLE_MEMBER_REFERENCES = 100_000
MINIMUM_GRID_COORDINATES = 2
MINIMUM_MEMBERS_PER_RECOVERED_CELL = 2


@dataclass(frozen=True)
class TableTextView:
    """Selected content plus the real, unsplit provenance objects."""

    fact: PdfTextFact
    node: PdfLayoutNode
    binding: PdfTableMemberBinding

    @property
    def geometry(self) -> PdfBoundingBox:
        return self.binding.geometry

    @property
    def text(self) -> str:
        return self.binding.text


@dataclass(frozen=True)
class MemberPartitionResult:
    views: tuple[TableTextView, ...] = ()
    limitation: str | None = None


def _inside(inner: PdfBoundingBox, outer: PdfBoundingBox) -> bool:
    # These are observations from one coordinate transform. Do not apply the
    # table's placement tolerance to absorb real member/separator crossings.
    return (
        outer.x0 <= inner.x0 <= inner.x1 <= outer.x1
        and outer.y0 <= inner.y0 <= inner.y1 <= outer.y1
    )


def _overlaps_beyond_roundoff(left_end: float, right_start: float) -> bool:
    """Distinguish a real overlap from addition roundoff, in source units."""
    return left_end - right_start > 4 * max(ulp(left_end), ulp(right_start))


def _envelope(members: Sequence[PdfTextMember]) -> PdfBoundingBox:
    boxes = [member.bbox for member in members if member.bbox is not None]
    if len(boxes) != len(members) or not boxes:
        message = "table member envelope requires every member geometry"
        raise ValueError(message)
    return PdfBoundingBox(
        x0=min(box.x0 for box in boxes),
        y0=min(box.y0 for box in boxes),
        x1=max(box.x1 for box in boxes),
        y1=max(box.y1 for box in boxes),
    )


def _members_for_parent(
    page: PdfPageFacts,
    fact: PdfTextFact,
    by_id: dict[str, PdfTextMember],
) -> tuple[PdfTextMember, ...] | None:
    if (
        fact.page_id != page.page_id
        or fact.member_inventory_status != "COMPLETE"
        or fact.member_projection_status != "EXACT"
        or not fact.source_group_id
        or not fact.member_ids
        or len(fact.member_ids) != fact.source_member_count
        or len(fact.member_ids) > MAXIMUM_TABLE_MEMBER_REFERENCES
        or len(set(fact.member_ids)) != len(fact.member_ids)
    ):
        return None
    members = tuple(by_id.get(value) for value in fact.member_ids)
    if any(member is None for member in members):
        return None
    selected = tuple(member for member in members if member is not None)
    if any(
        member.page_id != page.page_id
        or member.selection_state != "RETAINED"
        or member.geometry_status != "INSIDE"
        or member.bbox is None
        or member.bbox.x1 <= member.bbox.x0
        or member.bbox.y1 <= member.bbox.y0
        or member.rotation != 0
        or member.warnings
        for member in selected
    ):
        return None
    # EXACT is a claim to verify, never an authorization to trust old labels.
    if "".join(member.text for member in selected) != fact.text:
        return None
    return selected


def _view(  # noqa: PLR0913 - Explicit independent source and selection inputs.
    *,
    source_sha256: str,
    page: PdfPageFacts,
    fact: PdfTextFact,
    node: PdfLayoutNode,
    members: tuple[PdfTextMember, ...],
    basis: Literal["closed_physical_separator_grid", "repeated_member_whitespace_grid"],
) -> TableTextView:
    if fact.source_group_id is None:
        message = "table member view requires its observed source group"
        raise ValueError(message)
    return TableTextView(
        fact=fact,
        node=node,
        binding=make_member_binding(
            source_sha256=source_sha256,
            page_id=page.page_id,
            parent_fact_id=fact.fact_id,
            parent_layout_node_id=node.node_id,
            source_group_id=fact.source_group_id,
            member_ids=tuple(member.member_id for member in members),
            text="".join(member.text for member in members),
            geometry=_envelope(members),
            partition_basis=basis,
        ),
    )


def validate_member_bindings(
    bindings: Sequence[PdfTableMemberBinding],
    *,
    source_sha256: str,
    page: PdfPageFacts,
    nodes: dict[str, PdfLayoutNode],
) -> None:
    """Reconstruct selected content with one bounded inventory build per page."""
    facts = {
        fact.fact_id: fact
        for layer in (
            page.words,
            page.text_spans,
            page.line_candidates,
            page.characters,
        )
        for fact in layer
    }
    by_id = {member.member_id: member for member in page.text_members}
    parents: dict[str, tuple[tuple[PdfTextMember, ...], dict[str, int]]] = {}
    checked_node_parents: set[tuple[str, str]] = set()
    for binding in bindings:
        node = nodes.get(binding.parent_layout_node_id)
        if (
            binding.source_sha256 != source_sha256
            or binding.page_id != page.page_id
            or node is None
            or node.source_page_id != page.page_id
        ):
            message = "table member selection source/page/node mismatch"
            raise ValueError(message)
        parent = facts.get(binding.parent_fact_id)
        node_fact = facts.get(node.source_fact_id)
        if parent is None or node_fact is None:
            message = "table member parent Fact is absent"
            raise ValueError(message)
        if parent.fact_id not in parents:
            complete = _members_for_parent(page, parent, by_id)
            if complete is None:
                message = "table member parent relation is incomplete"
                raise ValueError(message)
            parents[parent.fact_id] = (
                complete,
                {member.member_id: ordinal for ordinal, member in enumerate(complete)},
            )
        complete, positions = parents[parent.fact_id]
        node_parent = node.node_id, parent.fact_id
        if node_parent not in checked_node_parents:
            if node_fact.member_inventory_status != "COMPLETE" or not set(
                parent.member_ids
            ).issubset(node_fact.member_ids):
                message = "table member parent/primary-node membership is incomplete"
                raise ValueError(message)
            checked_node_parents.add(node_parent)
        start = positions.get(binding.member_ids[0], -1)
        if (
            start < 0
            or parent.member_ids[start : start + len(binding.member_ids)]
            != binding.member_ids
        ):
            message = "table member selection is not an exact contiguous source run"
            raise ValueError(message)
        members = complete[start : start + len(binding.member_ids)]
        rebuilt = _view(
            source_sha256=source_sha256,
            page=page,
            fact=parent,
            node=node,
            members=members,
            basis=binding.partition_basis,
        )
        if rebuilt.binding != binding or not _inside(binding.geometry, node.bbox):
            message = "table member selection content or geometry disagrees with source"
            raise ValueError(message)


@dataclass(frozen=True)
class _ProjectionSources:
    page_id: str
    facts: dict[str, PdfTextFact]
    nodes: dict[str, PdfLayoutNode]
    selections: dict[str, PdfTableMemberBinding]

    def resolve(
        self, part: PdfTableCellTextPart
    ) -> tuple[PdfTextFact, PdfLayoutNode, TableTextView | None]:
        fact = self.facts.get(part.source_fact_id)
        node = self.nodes.get(part.source_layout_node_id)
        if fact is None or node is None or node.source_page_id != self.page_id:
            message = "table text projection source Fact/Layout missing"
            raise ValueError(message)
        if node.source_fact_id != fact.fact_id:
            parent = self.facts.get(node.source_fact_id)
            if (
                parent is None
                or parent.member_inventory_status != "COMPLETE"
                or fact.member_inventory_status != "COMPLETE"
                or not fact.member_ids
                or not set(fact.member_ids).issubset(parent.member_ids)
            ):
                message = "table word projection lacks primary Layout membership"
                raise ValueError(message)
        view = None
        if part.member_binding_id is not None:
            binding = self.selections[part.member_binding_id]
            if (binding.parent_fact_id, binding.parent_layout_node_id) != (
                part.source_fact_id,
                part.source_layout_node_id,
            ):
                message = "table text projection member parent mismatch"
                raise ValueError(message)
            view = TableTextView(fact, node, binding)
        return fact, node, view


def _require_cell_ownership(
    geometry: PdfBoundingBox,
    cell_geometry: PdfBoundingBox,
    *,
    legacy: bool,
    replayed_overflow: bool,
) -> None:
    """Never equate textual reconstruction with spatial cell ownership."""
    if not legacy and not replayed_overflow and not _inside(geometry, cell_geometry):
        message = (
            "table text crosses its physical cell without a replayable ownership proof"
        )
        raise ValueError(message)


def validate_table_text_projections(
    sidecar: PdfTableStructurePageSidecar,
    *,
    page: PdfPageFacts,
    nodes: dict[str, PdfLayoutNode],
) -> None:
    """Bind every recorded part to its source and replay its declared text rule."""
    # Imports are deferred to avoid a cycle with the Table algorithms.
    from .table_algorithm import _text_projection_parts as ruled_parts
    from .table_algorithm import _TextItem
    from .table_borderless import _Item
    from .table_borderless import _text_projection_parts as borderless_parts
    from .table_overflow_integration import validate_overflow_sources

    validate_overflow_sources(sidecar, page=page, nodes=nodes)
    overflow = {p.proof_id: p for p in sidecar.source_anchored_overflow_proofs}
    sources = _ProjectionSources(
        page_id=page.page_id,
        facts={
            fact.fact_id: fact
            for layer in (
                page.words,
                page.text_spans,
                page.line_candidates,
                page.characters,
            )
            for fact in layer
        },
        nodes=nodes,
        selections={item.binding_id: item for item in sidecar.member_bindings},
    )
    cells = {cell.cell_id: cell for table in sidecar.tables for cell in table.cells}
    used: set[tuple[str, str, str | None, str | None]] = set()
    used_source_members: set[str] = set()
    for projection in sidecar.cell_text_projections:
        cell = cells[projection.cell_id]
        ruled_items: list[_TextItem] = []
        borderless_items: list[_Item] = []
        pieces: list[str] = []
        for part in projection.parts:
            key = (
                part.source_fact_id,
                part.source_layout_node_id,
                part.member_binding_id,
                part.source_anchored_overflow_id,
            )
            if key in used:
                message = "table text source occurrence is repeated across cells"
                raise ValueError(message)
            used.add(key)
            fact, node, view = sources.resolve(part)
            geometry = (
                view.geometry
                if view is not None
                else (node.bbox if node.source_fact_id == fact.fact_id else fact.bbox)
            )
            text = view.text if view is not None else fact.text
            members = view.binding.member_ids if view is not None else fact.member_ids
            if part.source_anchored_overflow_id is not None:
                proof = overflow[part.source_anchored_overflow_id]
                geometry, text, members = (
                    proof.actual_geometry,
                    proof.text,
                    proof.member_ids,
                )
            _require_cell_ownership(
                geometry,
                cell.geometry,
                legacy=sidecar.schema_version.endswith(".v1"),
                replayed_overflow=part.source_anchored_overflow_id is not None,
            )
            if used_source_members.intersection(members):
                message = (
                    "table text repeats source members through different parent Facts"
                )
                raise ValueError(message)
            used_source_members.update(members)
            pieces.append(part.separator_before + text)
            ruled_items.append(_TextItem(fact, node, geometry, view))
            borderless_items.append(_Item(fact, node, view))
        if "".join(pieces) != cell.text:
            message = "table cell text disagrees with recorded source projection"
            raise ValueError(message)
        if projection.method == "source_anchored_cell_text.v1":
            # validate_overflow_sources already replayed the exact single event
            # and grid; ordinary layout sorting must not rewrite that source run.
            continue
        if projection.method == "ruled_cell_text.v1":
            ordered = tuple(
                sorted(
                    ruled_items,
                    key=lambda item: (
                        item.geometry.y0,
                        item.geometry.x0,
                        item.fact.source_order,
                        item.node.node_id,
                    ),
                )
            )
            reconstructed = ruled_parts(ordered)
        else:
            reconstructed = borderless_parts(borderless_items)
        if reconstructed != projection.parts:
            message = "table cell text order/separators disagree with declared rule"
            raise ValueError(message)


def partition_parent_at_grid(  # noqa: PLR0913 - Keep source and physical axes explicit.
    *,
    source_sha256: str,
    page: PdfPageFacts,
    fact: PdfTextFact,
    node: PdfLayoutNode,
    row_coordinates: tuple[float, ...],
    column_coordinates: tuple[float, ...],
    members_by_id: dict[str, PdfTextMember],
) -> MemberPartitionResult:
    """Split only when every source member fits one authoritative atomic cell.

    A crossing member rejects the partition as a whole. Its original parent is
    still available to the caller, which must retain ambiguity and the evidence.
    """
    if (
        len(row_coordinates) < MINIMUM_GRID_COORDINATES
        or len(column_coordinates) < MINIMUM_GRID_COORDINATES
        or row_coordinates != tuple(sorted(set(row_coordinates)))
        or column_coordinates != tuple(sorted(set(column_coordinates)))
    ):
        message = "table member partition requires ordered physical axes"
        raise ValueError(message)
    members = _members_for_parent(page, fact, members_by_id)
    if members is None:
        return MemberPartitionResult(limitation="table_member_relation_incomplete")
    selected: list[list[PdfTextMember]] = []
    positions: list[tuple[int, int]] = []
    for member in members:
        box = member.bbox
        if box is None:
            message = "validated table member unexpectedly lacks geometry"
            raise ValueError(message)
        row = bisect_right(row_coordinates, box.y0) - 1
        column = bisect_right(column_coordinates, box.x0) - 1
        if not (
            0 <= row < len(row_coordinates) - 1
            and 0 <= column < len(column_coordinates) - 1
        ):
            return MemberPartitionResult(
                limitation="table_member_crosses_outer_boundary"
            )
        cell = PdfBoundingBox(
            x0=column_coordinates[column],
            y0=row_coordinates[row],
            x1=column_coordinates[column + 1],
            y1=row_coordinates[row + 1],
        )
        if not _inside(box, cell):
            return MemberPartitionResult(
                limitation="table_member_crosses_physical_separator"
            )
        position = row, column
        if positions and positions[-1] == position:
            selected[-1].append(member)
        else:
            if position in positions:
                return MemberPartitionResult(
                    limitation="table_member_cell_source_order_ambiguous"
                )
            positions.append(position)
            selected.append([member])
        if len(selected) > MAXIMUM_TABLE_MEMBER_VIEWS:
            return MemberPartitionResult(limitation="table_member_view_limit_exceeded")
    return MemberPartitionResult(
        views=tuple(
            _view(
                source_sha256=source_sha256,
                page=page,
                fact=fact,
                node=node,
                members=tuple(group),
                basis="closed_physical_separator_grid",
            )
            for group in selected
        )
    )


@dataclass(frozen=True)
class _MemberRow:
    fact: PdfTextFact
    node: PdfLayoutNode
    groups: tuple[tuple[PdfTextMember, ...], ...]


@dataclass(frozen=True)
class _MemberGroups:
    groups: tuple[tuple[PdfTextMember, ...], ...] = ()
    limitation: str | None = None


def _member_row_groups(
    members: tuple[PdfTextMember, ...], minimum_columns: int
) -> _MemberGroups:
    boxes = tuple(member.bbox for member in members if member.bbox is not None)
    widths = tuple(box.x1 - box.x0 for box in boxes)
    height = median(box.y1 - box.y0 for box in boxes)
    if min(box.y1 for box in boxes) - max(
        box.y0 for box in boxes
    ) < height * 0.55 or any(
        _overlaps_beyond_roundoff(left.x1, right.x0) for left, right in pairwise(boxes)
    ):
        return _MemberGroups(limitation="table_member_row_geometry_ambiguous")
    # Positive whitespace must exceed character-local placement noise and
    # repeat at the same physical intervals across every complete row.
    gap_floor = median(widths) * 0.25
    groups: list[list[PdfTextMember]] = [[members[0]]]
    for (left, right), member in zip(pairwise(boxes), members[1:], strict=True):
        if right.x0 - left.x1 > gap_floor:
            groups.append([member])
        else:
            groups[-1].append(member)
    if len(groups) < minimum_columns:
        return _MemberGroups()
    if any(len(group) < MINIMUM_MEMBERS_PER_RECOVERED_CELL for group in groups):
        # Uniform character tracking is not a multi-column table. Independent
        # one-letter source words use the ordinary detector, not this recovery.
        return _MemberGroups(limitation="table_member_single_character_grid_unproven")
    return _MemberGroups(groups=tuple(tuple(group) for group in groups))


def _member_grid_geometry_limitation(rows: Sequence[_MemberRow]) -> str | None:
    columns = len(rows[0].groups)
    if any(len(row.groups) != columns for row in rows):
        return "table_member_grid_nonrepeating"
    if len(rows) * columns > MAXIMUM_TABLE_MEMBER_VIEWS:
        return "table_member_view_limit_exceeded"
    row_boxes = tuple(
        _envelope(tuple(member for group in row.groups for member in group))
        for row in rows
    )
    height = median(box.y1 - box.y0 for box in row_boxes)
    pitches = tuple(right.y0 - left.y0 for left, right in pairwise(row_boxes))
    if (
        not pitches
        or min(pitches) < height * 1.5
        or max(pitches) - min(pitches) > height * 0.25
        or any(right.y0 < left.y1 for left, right in pairwise(row_boxes))
    ):
        return "table_member_grid_row_pitch_ambiguous"
    cell_boxes = tuple(tuple(_envelope(group) for group in row.groups) for row in rows)
    for column in range(columns):
        starts = tuple(row[column].x0 for row in cell_boxes)
        if max(starts) - min(starts) > height * 0.25:
            return "table_member_grid_anchor_ambiguous"
        if column + 1 < columns and max(row[column].x1 for row in cell_boxes) >= min(
            row[column + 1].x0 for row in cell_boxes
        ):
            return "table_member_grid_gutter_ambiguous"
    return None


def _complete_member_rows(
    page: PdfPageFacts,
    parents: Sequence[tuple[PdfTextFact, PdfLayoutNode]],
    minimum_columns: int,
) -> tuple[tuple[_MemberRow, ...], str | None]:
    by_id = {member.member_id: member for member in page.text_members}
    if len(by_id) != len(page.text_members):
        message = "duplicate source member identity"
        raise ValueError(message)
    ordered = sorted(parents, key=lambda pair: (pair[0].source_order, pair[0].fact_id))
    rows: list[_MemberRow] = []
    used_members: set[str] = set()
    for fact, node in ordered:
        members = _members_for_parent(page, fact, by_id)
        if members is None:
            return (), "table_member_relation_incomplete"
        if used_members.intersection(fact.member_ids):
            return (), "table_member_parent_overlap"
        used_members.update(fact.member_ids)
        if len(used_members) > MAXIMUM_TABLE_MEMBER_REFERENCES:
            return (), "table_member_reference_limit_exceeded"
        selection = _member_row_groups(members, minimum_columns)
        if not selection.groups:
            return (), selection.limitation
        rows.append(_MemberRow(fact, node, selection.groups))
    return tuple(rows), None


def repeated_member_grid(
    *,
    source_sha256: str,
    page: PdfPageFacts,
    parents: Sequence[tuple[PdfTextFact, PdfLayoutNode]],
    minimum_rows: int,
    minimum_columns: int,
) -> MemberPartitionResult:
    """Require complete repeated gaps in row-ordered aggregate parents.

    Independently tokenized prose is excluded. Reading is never retokenized,
    and the ordinary detector's logical-word gap threshold is unchanged.
    """
    if len(parents) < minimum_rows:
        return MemberPartitionResult()
    rows, limitation = _complete_member_rows(page, parents, minimum_columns)
    if not rows:
        return MemberPartitionResult(limitation=limitation)
    limitation = _member_grid_geometry_limitation(rows)
    if limitation is not None:
        return MemberPartitionResult(limitation=limitation)
    return MemberPartitionResult(
        views=tuple(
            _view(
                source_sha256=source_sha256,
                page=page,
                fact=row.fact,
                node=row.node,
                members=group,
                basis="repeated_member_whitespace_grid",
            )
            for row in rows
            for group in row.groups
        )
    )

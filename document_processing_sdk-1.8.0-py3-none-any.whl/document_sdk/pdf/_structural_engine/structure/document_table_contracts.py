# ruff: noqa: C901, EM101, EM102, PLR0912, TRY003, UP047

from __future__ import annotations

from typing import Any, Literal, TypeVar

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .identity import canonical_sha256
from .table_document_manifest import build_document_identity

PDF_DOCUMENT_TABLE_ALGORITHM_VERSION = (
    "document_sdk.pdf.phase3.document_table.algorithm.v2"
)
PdfTransitionOutcome = Literal[
    "CONTINUATION_PROVEN",
    "CONTINUATION_PARTIAL",
    "NOT_CONTINUOUS",
    "AMBIGUOUS_CONTINUATION",
    "REPEATED_HEADER_CONTINUATION",
    "SPLIT_ROW_CONTINUATION",
    "COLUMN_STRUCTURE_CHANGED",
    "MULTIPLE_CANDIDATES",
    "UNSUPPORTED_SOURCE",
    "UNAVAILABLE_UPSTREAM",
    "RESOURCE_LIMITED",
]
PdfDocumentTableStatus = Literal[
    "COMPLETE", "PARTIAL", "AMBIGUOUS", "UNSUPPORTED", "RESOURCE_LIMITED"
]

_IDENTITY_DOMAINS = {
    "row-fragment": "document_sdk.pdf.phase3.document_table.row_fragment.v1",
    "transition": "document_sdk.pdf.phase3.document_table.transition.v2",
    "logical-row": "document_sdk.pdf.phase3.document_table.logical_row.v1",
    "document-table": "document_sdk.pdf.phase3.document_table.table.v1",
    "manifest": "document_sdk.pdf.phase3.document_table.manifest.v2",
}


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)


def _identifier(kind: str, payload: object) -> str:
    try:
        domain = _IDENTITY_DOMAINS[kind]
    except KeyError:
        raise ValueError("unsupported document Table identity kind") from None
    return f"P3D-{kind}-" + canonical_sha256({"domain": domain, "payload": payload})


ModelT = TypeVar("ModelT", bound=BaseModel)


def _build_identified(
    model: type[ModelT], *, identity_field: str, kind: str, values: dict[str, Any]
) -> ModelT:
    draft_values: dict[str, Any] = dict(values)
    draft_values[identity_field] = _identifier(kind, {"draft": True})
    draft = model.model_construct(**draft_values)
    payload = draft.model_dump(exclude={identity_field})
    payload[identity_field] = _identifier(kind, payload)
    return model.model_validate(payload)


class PdfPhase3DResourceContract(_FrozenModel):
    schema_version: Literal["pdf_phase3d_resource_contract.v1"] = (
        "pdf_phase3d_resource_contract.v1"
    )
    maximum_pages_per_document: int = Field(default=2048, ge=2, le=4096)
    maximum_adjacent_transitions: int = Field(default=2047, ge=1, le=4095)
    maximum_tables_per_page: int = Field(default=32, ge=1, le=64)
    maximum_candidate_pairs_per_transition: int = Field(default=64, ge=1, le=128)
    maximum_chain_length: int = Field(default=1024, ge=2, le=2048)
    maximum_logical_rows: int = Field(default=200_000, ge=1, le=500_000)
    maximum_logical_cells: int = Field(default=2_000_000, ge=1, le=4_000_000)
    maximum_artifact_bytes: int = Field(default=64 * 1024 * 1024, ge=1024)
    maximum_transition_evidence_bytes: int = Field(default=512 * 1024, ge=1024)
    maximum_stage_runtime_seconds: float = Field(default=120.0, gt=0, le=300.0)

    @model_validator(mode="after")
    def validate_relationships(self) -> PdfPhase3DResourceContract:
        if self.maximum_adjacent_transitions >= self.maximum_pages_per_document:
            raise ValueError("adjacent transition ceiling must be below page ceiling")
        if self.maximum_chain_length > self.maximum_pages_per_document:
            raise ValueError("chain ceiling exceeds page ceiling")
        if self.maximum_transition_evidence_bytes > self.maximum_artifact_bytes:
            raise ValueError("transition evidence ceiling exceeds artifact ceiling")
        return self


class PdfPhase3DTableEndpoint(_FrozenModel):
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    document_identity: str = Field(pattern=r"^P3D-document-[0-9a-f]{64}$")
    page_table_manifest_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_index: int = Field(ge=0)
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    table_sidecar_id: str = Field(pattern=r"^P3C-table-page-[0-9a-f]{64}$")
    table_sidecar_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    sidecar_bytes: int | None = Field(default=None, gt=0)
    configuration_identity: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    dependency_identity: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    table_id: str = Field(pattern=r"^P3C-table-[0-9a-f]{64}$")
    table_row_ids: tuple[str, ...]
    table_cell_ids: tuple[str, ...]
    row_cell_membership: tuple[tuple[str, tuple[str, ...]], ...] = ()

    @model_validator(mode="after")
    def validate_inventory(self) -> PdfPhase3DTableEndpoint:
        expected_document = build_document_identity(
            source_sha256=self.source_sha256,
            page_table_manifest_sha256=self.page_table_manifest_sha256,
        )
        if self.document_identity != expected_document:
            raise ValueError("table endpoint document identity mismatch")
        if len(set(self.table_row_ids)) != len(self.table_row_ids):
            raise ValueError("table endpoint repeats a row identity")
        if len(set(self.table_cell_ids)) != len(self.table_cell_ids):
            raise ValueError("table endpoint repeats a cell identity")
        membership_rows = tuple(item[0] for item in self.row_cell_membership)
        if len(set(membership_rows)) != len(membership_rows):
            raise ValueError("table endpoint repeats row-cell membership")
        if set(membership_rows) - set(self.table_row_ids):
            raise ValueError("table endpoint row-cell membership has a phantom row")
        if any(
            len(cells) != len(set(cells)) or bool(set(cells) - set(self.table_cell_ids))
            for _, cells in self.row_cell_membership
        ):
            raise ValueError("table endpoint row-cell membership has a phantom cell")
        return self


class PdfPhase3DColumnMapping(_FrozenModel):
    left_column_id: str = Field(pattern=r"^P3C-column-[0-9a-f]{64}$")
    right_column_id: str = Field(pattern=r"^P3C-column-[0-9a-f]{64}$")
    left_column_index: int = Field(ge=0)
    right_column_index: int = Field(ge=0)
    normalized_axis_distance: float = Field(ge=0, le=1)
    width_ratio_difference: float = Field(ge=0)
    topology_compatible: bool
    evidence_strength: float = Field(ge=0, le=1)
    conflicting_evidence: tuple[str, ...] = ()
    reason_code: str = Field(min_length=1, max_length=128)


class PdfRepeatedHeaderMapping(_FrozenModel):
    logical_header_identity: str = Field(pattern=r"^P3D-header-[0-9a-f]{64}$")
    left_row_ids: tuple[str, ...]
    right_row_ids: tuple[str, ...]
    left_cell_ids: tuple[str, ...]
    right_cell_ids: tuple[str, ...]
    occurrence_index: int = Field(ge=1)
    exact_symbolic_repeat: bool
    topology_compatible: bool
    repeated_header: Literal[True] = True

    @model_validator(mode="after")
    def validate_shape(self) -> PdfRepeatedHeaderMapping:
        if not self.left_row_ids or len(self.left_row_ids) != len(self.right_row_ids):
            raise ValueError("repeated header row mapping is incomplete")
        if not self.left_cell_ids or len(self.left_cell_ids) != len(
            self.right_cell_ids
        ):
            raise ValueError("repeated header cell mapping is incomplete")
        return self


class PdfRowFragmentLink(_FrozenModel):
    fragment_link_id: str = Field(pattern=r"^P3D-row-fragment-[0-9a-f]{64}$")
    left_row_id: str = Field(pattern=r"^P3C-row-[0-9a-f]{64}$")
    right_row_id: str = Field(pattern=r"^P3C-row-[0-9a-f]{64}$")
    left_cell_ids: tuple[str, ...]
    right_cell_ids: tuple[str, ...]
    mapped_column_indexes: tuple[tuple[int, int], ...]
    local_fragment_order: tuple[Literal["LEFT", "RIGHT"], ...] = (
        "LEFT",
        "RIGHT",
    )
    physically_incomplete_left: bool
    physically_compatible_right: bool
    conflicting_evidence: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_identity(self) -> PdfRowFragmentLink:
        if not self.left_cell_ids or not self.right_cell_ids:
            raise ValueError("row fragment requires cell provenance on both pages")
        if self.local_fragment_order != ("LEFT", "RIGHT"):
            raise ValueError("row fragment order must follow physical page order")
        expected = _identifier(
            "row-fragment", self.model_dump(exclude={"fragment_link_id"})
        )
        if self.fragment_link_id != expected:
            raise ValueError("row fragment identity mismatch")
        return self


class PdfTablePageTransition(_FrozenModel):
    schema_version: Literal["pdf_table_page_transition.v2"] = (
        "pdf_table_page_transition.v2"
    )
    transition_id: str = Field(pattern=r"^P3D-transition-[0-9a-f]{64}$")
    left: PdfPhase3DTableEndpoint
    right: PdfPhase3DTableEndpoint
    outcome: PdfTransitionOutcome
    column_mappings: tuple[PdfPhase3DColumnMapping, ...] = ()
    repeated_header_mappings: tuple[PdfRepeatedHeaderMapping, ...] = ()
    row_fragment_links: tuple[PdfRowFragmentLink, ...] = ()
    table_geometry_compatible: bool | None
    topology_compatible: bool | None
    page_boundary_evidence_strength: float | None = Field(ge=0, le=1)
    fingerprint_support_strength: float = Field(ge=0, le=1)
    candidate_pair_count: int = Field(ge=0, le=64)
    limitation_codes: tuple[str, ...] = ()
    algorithm_version: Literal[
        "document_sdk.pdf.phase3.document_table.algorithm.v2"
    ] = PDF_DOCUMENT_TABLE_ALGORITHM_VERSION  # type: ignore[assignment]

    @model_validator(mode="after")
    def validate_transition(self) -> PdfTablePageTransition:
        for field in (
            "source_sha256",
            "document_identity",
            "page_table_manifest_sha256",
        ):
            if getattr(self.left, field) != getattr(self.right, field):
                raise ValueError(f"cross-boundary transition mismatch: {field}")
        if self.right.page_index != self.left.page_index + 1:
            raise ValueError("table transition must bind adjacent forward pages")
        if self.left.page_id == self.right.page_id:
            raise ValueError("table transition repeats a physical page")
        left_rows = set(self.left.table_row_ids)
        right_rows = set(self.right.table_row_ids)
        left_cells = set(self.left.table_cell_ids)
        right_cells = set(self.right.table_cell_ids)
        if left_rows & right_rows or left_cells & right_cells:
            raise ValueError(
                "cross-page transition reuses a page-local row or cell identity"
            )
        for header in self.repeated_header_mappings:
            if (
                not set(header.left_row_ids) <= left_rows
                or not set(header.right_row_ids) <= right_rows
            ):
                raise ValueError("repeated header references a phantom row")
            if (
                not set(header.left_cell_ids) <= left_cells
                or not set(header.right_cell_ids) <= right_cells
            ):
                raise ValueError("repeated header references a phantom cell")
        for fragment in self.row_fragment_links:
            if (
                fragment.left_row_id not in left_rows
                or fragment.right_row_id not in right_rows
            ):
                raise ValueError("row fragment references a phantom row")
            if (
                not set(fragment.left_cell_ids) <= left_cells
                or not set(fragment.right_cell_ids) <= right_cells
            ):
                raise ValueError("row fragment references a phantom cell")
        proven = self.outcome in {
            "CONTINUATION_PROVEN",
            "CONTINUATION_PARTIAL",
            "REPEATED_HEADER_CONTINUATION",
            "SPLIT_ROW_CONTINUATION",
        }
        if proven and (
            not self.column_mappings
            or self.table_geometry_compatible is not True
            or self.topology_compatible is not True
        ):
            raise ValueError(
                "proven continuation lacks geometry, topology, or column proof"
            )
        if (
            self.outcome == "REPEATED_HEADER_CONTINUATION"
            and not self.repeated_header_mappings
        ):
            raise ValueError("repeated-header outcome lacks header mapping")
        if self.outcome == "SPLIT_ROW_CONTINUATION" and not self.row_fragment_links:
            raise ValueError("split-row outcome lacks fragment mapping")
        expected = _identifier("transition", self.model_dump(exclude={"transition_id"}))
        if self.transition_id != expected:
            raise ValueError("table transition identity mismatch")
        return self


class PdfDocumentTablePageReference(_FrozenModel):
    page_index: int = Field(ge=0)
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    table_id: str = Field(pattern=r"^P3C-table-[0-9a-f]{64}$")
    table_sidecar_id: str = Field(pattern=r"^P3C-table-page-[0-9a-f]{64}$")
    source_row_ids: tuple[str, ...]
    source_cell_ids: tuple[str, ...]


class PdfDocumentLogicalRow(_FrozenModel):
    logical_row_id: str = Field(pattern=r"^P3D-logical-row-[0-9a-f]{64}$")
    fragment_row_ids: tuple[str, ...]
    fragment_cell_ids: tuple[str, ...]
    source_page_indexes: tuple[int, ...]
    repeated_header_occurrence: bool = False
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_identity(self) -> PdfDocumentLogicalRow:
        if not self.fragment_row_ids or not self.fragment_cell_ids:
            raise ValueError("logical row requires row and cell provenance")
        if tuple(sorted(set(self.source_page_indexes))) != self.source_page_indexes:
            raise ValueError("logical row page provenance is noncanonical")
        expected = _identifier(
            "logical-row", self.model_dump(exclude={"logical_row_id"})
        )
        if self.logical_row_id != expected:
            raise ValueError("logical row identity mismatch")
        return self


class PdfDocumentTable(_FrozenModel):
    schema_version: Literal["pdf_document_table.v1"] = "pdf_document_table.v1"
    document_table_id: str = Field(pattern=r"^P3D-document-table-[0-9a-f]{64}$")
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    document_identity: str = Field(pattern=r"^P3D-document-[0-9a-f]{64}$")
    page_table_manifest_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_table_references: tuple[PdfDocumentTablePageReference, ...]
    transition_ids: tuple[str, ...]
    logical_rows: tuple[PdfDocumentLogicalRow, ...]
    canonical_header_identity: str | None = Field(
        default=None, pattern=r"^P3D-header-[0-9a-f]{64}$"
    )
    repeated_header_identities: tuple[str, ...] = ()
    status: PdfDocumentTableStatus
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_chain(self) -> PdfDocumentTable:
        expected_document = build_document_identity(
            source_sha256=self.source_sha256,
            page_table_manifest_sha256=self.page_table_manifest_sha256,
        )
        if self.document_identity != expected_document:
            raise ValueError("document Table identity binding mismatch")
        if not self.page_table_references:
            raise ValueError("document table chain is empty")
        indexes = tuple(item.page_index for item in self.page_table_references)
        if indexes != tuple(range(indexes[0], indexes[0] + len(indexes))):
            raise ValueError(
                "document table chain must be forward adjacent and acyclic"
            )
        table_ids = tuple(item.table_id for item in self.page_table_references)
        if len(set(table_ids)) != len(table_ids):
            raise ValueError("document table chain repeats a page table")
        page_ids = tuple(item.page_id for item in self.page_table_references)
        if len(set(page_ids)) != len(page_ids):
            raise ValueError("document table chain repeats a physical page")
        all_row_ids = tuple(
            row_id
            for item in self.page_table_references
            for row_id in item.source_row_ids
        )
        all_cell_ids = tuple(
            cell_id
            for item in self.page_table_references
            for cell_id in item.source_cell_ids
        )
        if len(set(all_row_ids)) != len(all_row_ids):
            raise ValueError("document table chain repeats a source row")
        if len(set(all_cell_ids)) != len(all_cell_ids):
            raise ValueError("document table chain repeats a source cell")
        if len(self.transition_ids) != max(0, len(indexes) - 1):
            raise ValueError("document table transition count mismatch")
        if len(set(self.transition_ids)) != len(self.transition_ids):
            raise ValueError("document table repeats a transition")
        if len({row.logical_row_id for row in self.logical_rows}) != len(
            self.logical_rows
        ):
            raise ValueError("document table repeats a logical row")
        source_rows = {
            row for item in self.page_table_references for row in item.source_row_ids
        }
        source_cells = {
            cell for item in self.page_table_references for cell in item.source_cell_ids
        }
        if any(set(row.fragment_row_ids) - source_rows for row in self.logical_rows):
            raise ValueError("document logical row references a phantom source row")
        if any(set(row.fragment_cell_ids) - source_cells for row in self.logical_rows):
            raise ValueError("document logical row references a phantom source cell")
        expected = _identifier(
            "document-table", self.model_dump(exclude={"document_table_id"})
        )
        if self.document_table_id != expected:
            raise ValueError("document table identity mismatch")
        return self


class PdfDocumentTableManifest(_FrozenModel):
    schema_version: Literal["pdf_document_table_manifest.v2"] = (
        "pdf_document_table_manifest.v2"
    )
    manifest_id: str = Field(pattern=r"^P3D-manifest-[0-9a-f]{64}$")
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    document_identity: str = Field(pattern=r"^P3D-document-[0-9a-f]{64}$")
    page_table_manifest_id: str = Field(
        pattern=r"^P3D-table-page-manifest-[0-9a-f]{64}$"
    )
    page_table_manifest_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    transition_ids: tuple[str, ...]
    document_table_ids: tuple[str, ...]
    transition_count: int = Field(ge=0)
    document_table_count: int = Field(ge=0)
    adjacent_page_pair_count: int = Field(default=0, ge=0)
    evaluated_adjacent_page_pair_count: int = Field(default=0, ge=0)
    no_candidate_page_pair_count: int = Field(default=0, ge=0)
    resource_limited_page_pair_count: int = Field(default=0, ge=0)
    unavailable_adjacent_page_pair_count: int = Field(default=0, ge=0)
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_manifest(self) -> PdfDocumentTableManifest:
        expected_document = build_document_identity(
            source_sha256=self.source_sha256,
            page_table_manifest_sha256=self.page_table_manifest_sha256,
        )
        if self.document_identity != expected_document:
            raise ValueError("document Table manifest identity binding mismatch")
        if self.transition_count != len(self.transition_ids) or len(
            set(self.transition_ids)
        ) != len(self.transition_ids):
            raise ValueError("manifest transition accounting mismatch")
        if self.document_table_count != len(self.document_table_ids) or len(
            set(self.document_table_ids)
        ) != len(self.document_table_ids):
            raise ValueError("manifest document-table accounting mismatch")
        if (
            self.evaluated_adjacent_page_pair_count
            + self.no_candidate_page_pair_count
            + self.resource_limited_page_pair_count
            + self.unavailable_adjacent_page_pair_count
            != self.adjacent_page_pair_count
        ):
            raise ValueError("manifest adjacent-page accounting mismatch")
        if self.limitation_codes != tuple(sorted(set(self.limitation_codes))):
            raise ValueError("manifest limitations must be sorted and unique")
        expected = _identifier("manifest", self.model_dump(exclude={"manifest_id"}))
        if self.manifest_id != expected:
            raise ValueError("document table manifest identity mismatch")
        return self


def build_row_fragment_link(**values: object) -> PdfRowFragmentLink:
    return _build_identified(
        PdfRowFragmentLink,
        identity_field="fragment_link_id",
        kind="row-fragment",
        values=dict(values),
    )


def build_table_page_transition(**values: object) -> PdfTablePageTransition:
    return _build_identified(
        PdfTablePageTransition,
        identity_field="transition_id",
        kind="transition",
        values=dict(values),
    )


def build_document_logical_row(**values: object) -> PdfDocumentLogicalRow:
    return _build_identified(
        PdfDocumentLogicalRow,
        identity_field="logical_row_id",
        kind="logical-row",
        values=dict(values),
    )


def build_document_table(**values: object) -> PdfDocumentTable:
    return _build_identified(
        PdfDocumentTable,
        identity_field="document_table_id",
        kind="document-table",
        values=dict(values),
    )


def build_document_table_manifest(**values: object) -> PdfDocumentTableManifest:
    return _build_identified(
        PdfDocumentTableManifest,
        identity_field="manifest_id",
        kind="manifest",
        values=dict(values),
    )

"""Bounded per-page storage for exact Table text selections and projections."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from .identity import canonical_json_digest_and_size

if TYPE_CHECKING:
    from collections.abc import Sequence

    from .native_event_ownership import SourceAnchoredOverflowProof
    from .table_member_contracts import (
        PdfTableCellTextProjection,
        PdfTableMemberBinding,
    )


@dataclass
class TableTextEvidenceCollector:
    """One page budget, including rejected candidates until the page is sealed."""

    maximum_collision_comparisons: int = 100_000
    collision_comparisons: int = 0
    overflow_proofs: dict[str, SourceAnchoredOverflowProof] = field(
        default_factory=dict
    )
    maximum_selections: int = 4096
    maximum_references: int = 100_000
    maximum_projection_parts: int = 65_536
    maximum_bytes: int = 8 * 1024 * 1024
    selections: dict[str, PdfTableMemberBinding] = field(default_factory=dict)
    projections: dict[str, PdfTableCellTextProjection] = field(default_factory=dict)
    reference_count: int = 0
    projection_part_count: int = 0
    # Conservative encoded [selections, proofs, projections] envelope.
    serialized_bytes: int = 10
    limit_exceeded: bool = False

    def reserve_selections(self, values: Sequence[PdfTableMemberBinding]) -> bool:
        pending: dict[str, PdfTableMemberBinding] = {}
        references = 0
        size = 0
        for value in values:
            existing = self.selections.get(value.binding_id) or pending.get(
                value.binding_id
            )
            if existing is not None:
                if existing != value:
                    message = "table selection identity collision"
                    raise ValueError(message)
                continue
            pending[value.binding_id] = value
            references += len(value.member_ids)
            size += canonical_json_digest_and_size(value)[1] + 1
            if (
                len(self.selections) + len(self.overflow_proofs) + len(pending)
                > self.maximum_selections
                or self.reference_count + references > self.maximum_references
                or self.serialized_bytes + size > self.maximum_bytes
            ):
                self.limit_exceeded = True
                return False
        self.selections.update(pending)
        self.reference_count += references
        self.serialized_bytes += size
        return True

    def reserve_overflow_scan(self, upper_bound: int) -> bool:
        """Charge a conservative page-wide collision work bound before scanning."""
        if (
            upper_bound < 0
            or self.collision_comparisons + upper_bound
            > self.maximum_collision_comparisons
        ):
            self.limit_exceeded = True
            return False
        self.collision_comparisons += upper_bound
        return True

    def reserve_overflow_proofs(
        self, values: Sequence[SourceAnchoredOverflowProof]
    ) -> bool:
        """Atomically charge proof storage to the same selection/reference budget."""
        pending: dict[str, SourceAnchoredOverflowProof] = {}
        references = size = 0
        for value in values:
            previous = self.overflow_proofs.get(value.proof_id) or pending.get(
                value.proof_id
            )
            if previous is not None:
                if previous != value:
                    message = "table overflow proof identity collision"
                    raise ValueError(message)
                continue
            pending[value.proof_id] = value
            references += len(value.member_ids)
            size += canonical_json_digest_and_size(value)[1] + 1
            if (
                len(self.selections) + len(self.overflow_proofs) + len(pending)
                > self.maximum_selections
                or self.reference_count + references > self.maximum_references
                or self.serialized_bytes + size > self.maximum_bytes
            ):
                self.limit_exceeded = True
                return False
        self.overflow_proofs.update(pending)
        self.reference_count += references
        self.serialized_bytes += size
        return True

    def reserve_projection(self, value: PdfTableCellTextProjection) -> bool:
        existing = self.projections.get(value.cell_id)
        if existing is not None:
            if existing != value:
                message = "table cell has conflicting text projection"
                raise ValueError(message)
            return True
        parts = len(value.parts)
        size = canonical_json_digest_and_size(value)[1] + 1
        if (
            # Empty-cell records consume storage too.
            len(self.projections) >= self.maximum_projection_parts
            or self.projection_part_count + parts > self.maximum_projection_parts
            or self.serialized_bytes + size > self.maximum_bytes
        ):
            self.limit_exceeded = True
            return False
        self.projections[value.cell_id] = value
        self.projection_part_count += parts
        self.serialized_bytes += size
        return True

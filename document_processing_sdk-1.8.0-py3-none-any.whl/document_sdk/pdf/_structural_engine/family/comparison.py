"""Deterministic comparison for normalized document-family profiles."""

from __future__ import annotations

from typing import Literal

from .contracts import (
    DocumentFamilyComparison,
    DocumentFamilyFeatureProfile,
    PdfFamilyComparisonRelation,
    PdfFamilyFeatureComparison,
    PdfFamilyFeatureName,
    build_comparison,
)

_HARD_GROUPS: frozenset[PdfFamilyFeatureName] = frozenset(
    {
        "table_layout",
        "column_topology",
        "header_topology",
        "cross_page_continuity",
    }
)
_CORE_GROUPS: frozenset[PdfFamilyFeatureName] = frozenset(
    {
        "page_layout",
        "table_layout",
        "column_topology",
        "header_topology",
        "row_cell_structure",
    }
)
_ComparisonState = Literal["COMPARABLE", "INCOMPARABLE", "MISSING", "UNSUPPORTED"]
_HARD_TOPOLOGY_SIMILARITY_MAXIMUM = 0.5
_SAME_FAMILY_DRIFT_MINIMUM = 0.72
_LOW_SIMILARITY_REFERENCE = 0.35
_MINIMUM_COMPARABLE_CORE_GROUPS = 3


def _jaccard(left: tuple[str, ...], right: tuple[str, ...]) -> float:
    left_values, right_values = set(left), set(right)
    if not left_values and not right_values:
        return 1.0
    return len(left_values & right_values) / len(left_values | right_values)


def _numeric_similarity(
    left: tuple[float, ...],
    right: tuple[float, ...],
) -> float:
    if not left and not right:
        return 1.0
    if not left or not right:
        return 0.0
    common = min(len(left), len(right))
    distances = [min(1.0, abs(left[index] - right[index])) for index in range(common)]
    length_penalty = abs(len(left) - len(right)) / max(len(left), len(right))
    return max(
        0.0,
        1.0 - ((sum(distances) / common + length_penalty) / 2),
    )


def compare_document_family_profiles(  # noqa: C901, PLR0912, PLR0915
    left: DocumentFamilyFeatureProfile,
    right: DocumentFamilyFeatureProfile,
) -> DocumentFamilyComparison:
    if left.family_scope_identity != right.family_scope_identity:
        msg = "document-family comparison crosses scope boundary"
        raise ValueError(msg)
    if (left.document_identity, left.profile_id) > (
        right.document_identity,
        right.profile_id,
    ):
        left, right = right, left

    results: list[PdfFamilyFeatureComparison] = []
    hard_codes: set[str] = set()
    missing_codes: set[str] = set()
    for left_group, right_group in zip(
        left.feature_groups,
        right.feature_groups,
        strict=True,
    ):
        if left_group.name != right_group.name:
            msg = "document-family comparison feature order mismatch"
            raise ValueError(msg)
        evidence = tuple(
            sorted(
                set(left_group.evidence + right_group.evidence),
                key=lambda item: (
                    item.artifact_kind,
                    item.role,
                    item.artifact_id,
                    item.sha256,
                ),
            )
        )
        state: _ComparisonState
        similarity: float | None
        exact: bool | None
        hard: bool
        reasons: tuple[str, ...]
        if "UNSUPPORTED" in {left_group.state, right_group.state}:
            state = "UNSUPPORTED"
            reasons = tuple(
                sorted(
                    {
                        "UNSUPPORTED_FEATURE_EVIDENCE",
                        *left_group.reason_codes,
                        *right_group.reason_codes,
                    }
                )
            )
            missing_codes.add(f"{left_group.name}:UNSUPPORTED")
            similarity, exact, hard = None, None, False
        elif "INCOMPARABLE" in {left_group.state, right_group.state}:
            state = "INCOMPARABLE"
            reasons = tuple(
                sorted(
                    {
                        "INCOMPARABLE_FEATURE_EVIDENCE",
                        *left_group.reason_codes,
                        *right_group.reason_codes,
                    }
                )
            )
            missing_codes.add(f"{left_group.name}:INCOMPARABLE")
            similarity, exact, hard = None, None, False
        elif "MISSING" in {left_group.state, right_group.state}:
            state = "MISSING"
            reasons = tuple(
                sorted(
                    {
                        "MISSING_FEATURE_EVIDENCE",
                        *left_group.reason_codes,
                        *right_group.reason_codes,
                    }
                )
            )
            missing_codes.add(f"{left_group.name}:MISSING")
            similarity, exact, hard = None, None, False
        else:
            state = "COMPARABLE"
            categorical = _jaccard(
                left_group.categorical_values,
                right_group.categorical_values,
            )
            numeric = _numeric_similarity(
                left_group.numeric_values,
                right_group.numeric_values,
            )
            similarity = round((categorical + numeric) / 2, 6)
            exact = left_group.structural_signature == right_group.structural_signature
            hard = (
                left_group.name in _HARD_GROUPS
                and similarity <= _HARD_TOPOLOGY_SIMILARITY_MAXIMUM
            )
            if exact:
                reasons = ("EXACT_STRUCTURAL_MATCH",)
            elif hard:
                reasons = ("MATERIAL_STRUCTURAL_DIFFERENCE",)
            else:
                reasons = ("STRUCTURAL_VARIATION",)
            if hard:
                hard_codes.add(f"{left_group.name}:MATERIAL_STRUCTURAL_DIFFERENCE")
        results.append(
            PdfFamilyFeatureComparison(
                name=left_group.name,
                state=state,
                similarity=similarity,
                exact_match=exact,
                hard_incompatibility=hard,
                explanation_codes=reasons,
                evidence=evidence,
            )
        )

    comparable = [item for item in results if item.state == "COMPARABLE"]
    comparable_core = [item for item in comparable if item.name in _CORE_GROUPS]
    unavailable_core = [
        item
        for item in results
        if item.name in _CORE_GROUPS and item.state != "COMPARABLE"
    ]
    relation: PdfFamilyComparisonRelation
    if hard_codes:
        relation = "DISTINCT_FAMILY_PROVEN"
    elif not comparable_core:
        relation = "INCOMPARABLE"
    elif unavailable_core or len(comparable_core) < _MINIMUM_COMPARABLE_CORE_GROUPS:
        relation = "INSUFFICIENT_EVIDENCE"
    elif all(item.exact_match for item in comparable_core):
        relation = "SAME_FAMILY_PROVEN"
    elif all(
        (item.similarity or 0) >= _SAME_FAMILY_DRIFT_MINIMUM for item in comparable_core
    ):
        relation = "SAME_FAMILY_WITH_DRIFT"
    elif all(
        (item.similarity or 0) < _LOW_SIMILARITY_REFERENCE for item in comparable_core
    ):
        relation = "AMBIGUOUS_RELATION"
    else:
        relation = "AMBIGUOUS_RELATION"
    return build_comparison(
        family_scope_identity=left.family_scope_identity,
        left_document_identity=left.document_identity,
        right_document_identity=right.document_identity,
        left_profile_id=left.profile_id,
        right_profile_id=right.profile_id,
        group_results=tuple(results),
        hard_incompatibility_evidence=tuple(sorted(hard_codes)),
        missing_evidence=tuple(sorted(missing_codes)),
        relation=relation,
    )

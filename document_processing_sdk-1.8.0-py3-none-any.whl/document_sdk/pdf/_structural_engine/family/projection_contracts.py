"""Strict private contracts for current-artifact family projection."""

from __future__ import annotations

from typing import Literal, Self

from pydantic import BaseModel, ConfigDict, Field, InstanceOf, model_validator

from document_sdk.pdf._structural_engine.layout.contracts import (
    PdfLayoutGraphArtifact,  # noqa: TC001 - Pydantic resolves runtime annotations.
)
from document_sdk.pdf._structural_engine.structure import (
    document_table_contracts as _document_table_contracts,
)
from document_sdk.pdf._structural_engine.structure import (
    document_table_fingerprint as _document_table_fingerprint,
)
from document_sdk.pdf._structural_engine.structure import (
    table_contracts as _table_contracts,
)
from document_sdk.pdf._structural_engine.structure import (
    table_document_manifest as _table_document_manifest,
)
from document_sdk.pdf._structural_engine.structure.identity import canonical_sha256
from document_sdk.pdf._structural_engine.structure.reading_contracts import (
    PdfReadingStructurePageReference,  # noqa: TC001 - Pydantic runtime annotation.
    PdfReadingStructurePageSidecar,  # noqa: TC001 - Pydantic runtime annotation.
)
from document_sdk.pdf._structural_engine.structure.reading_input import (
    PdfReadingPageAuthority,  # noqa: TC001 - Pydantic resolves runtime annotations.
    PdfReadingPageEvidence,  # noqa: TC001 - Pydantic resolves runtime annotations.
)

from .contracts import (  # noqa: TC001 - Pydantic resolves runtime annotations.
    DocumentFamilyFeatureProfile,
)

PdfDocumentTable = _document_table_contracts.PdfDocumentTable
PdfDocumentTableManifest = _document_table_contracts.PdfDocumentTableManifest
PdfTablePageTransition = _document_table_contracts.PdfTablePageTransition
PdfTableTransitionFingerprint = (
    _document_table_fingerprint.PdfTableTransitionFingerprint
)
PdfTableStructurePageSidecar = _table_contracts.PdfTableStructurePageSidecar
PdfTableDocumentManifest = _table_document_manifest.PdfTableDocumentManifest

PROJECTION_VERSION: Literal[
    "document_sdk_pdf_document_family_feature_projection.v1"
] = "document_sdk_pdf_document_family_feature_projection.v1"
CURRENT_ARTIFACT_AUTHORITY_VERSION: Literal[
    "document_sdk.pdf.phase3.family.current_artifact_authority.v2"
] = "document_sdk.pdf.phase3.family.current_artifact_authority.v2"
PROJECTION_IDENTITY_DOMAIN: Literal["document_sdk.pdf.phase3.family.projection.v2"] = (
    "document_sdk.pdf.phase3.family.projection.v2"
)
PROJECTION_INPUT_IDENTITY_DOMAIN: Literal[
    "document_sdk.pdf.phase3.family.projection_input.v2"
] = "document_sdk.pdf.phase3.family.projection_input.v2"

PdfFamilyDocumentTableExecutionState = Literal[
    "NOT_EXECUTED",
    "COMPLETED",
    "UNSUPPORTED",
    "UNAVAILABLE",
]
PdfFamilyCanonicalExportState = Literal["NOT_AVAILABLE"]


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)


class PdfFamilyFeatureProjectionLimits(_FrozenModel):
    maximum_pages: int = Field(ge=1)
    maximum_layout_nodes: int = Field(ge=1)
    maximum_tables: int = Field(ge=1)
    maximum_cells: int = Field(ge=1)
    maximum_transitions: int = Field(ge=1)
    maximum_fingerprints: int = Field(ge=1)
    maximum_evidence_references: int = Field(ge=1)
    maximum_categorical_values_per_group: int = Field(ge=1)
    maximum_numeric_values_per_group: int = Field(ge=1)
    maximum_profile_canonical_bytes: int = Field(ge=1)


class PdfFamilyUpstreamBundle(_FrozenModel):
    authority_version: Literal[
        "document_sdk.pdf.phase3.family.current_artifact_authority.v2"
    ] = CURRENT_ARTIFACT_AUTHORITY_VERSION
    family_scope_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    document_identity: str = Field(pattern=r"^P3D-document-[0-9a-f]{64}$")
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_layout: InstanceOf[PdfLayoutGraphArtifact]
    reading_page_evidence: tuple[InstanceOf[PdfReadingPageEvidence], ...]
    reading_authority: InstanceOf[PdfReadingPageAuthority]
    reading_structures: tuple[InstanceOf[PdfReadingStructurePageSidecar], ...]
    reading_structure_references: tuple[
        InstanceOf[PdfReadingStructurePageReference], ...
    ]
    page_table_manifest: InstanceOf[PdfTableDocumentManifest]
    page_tables: tuple[InstanceOf[PdfTableStructurePageSidecar], ...]
    document_table_state: PdfFamilyDocumentTableExecutionState
    document_table_manifest: InstanceOf[PdfDocumentTableManifest] | None
    document_tables: tuple[InstanceOf[PdfDocumentTable], ...]
    transitions: tuple[InstanceOf[PdfTablePageTransition], ...]
    transition_fingerprints: tuple[InstanceOf[PdfTableTransitionFingerprint], ...]
    canonical_export_state: PdfFamilyCanonicalExportState
    limits: PdfFamilyFeatureProjectionLimits


class PdfFamilyFeatureProjectionResult(_FrozenModel):
    schema_version: Literal[
        "document_sdk_pdf_document_family_feature_projection.v1"
    ] = PROJECTION_VERSION
    authority_version: Literal[
        "document_sdk.pdf.phase3.family.current_artifact_authority.v2"
    ] = CURRENT_ARTIFACT_AUTHORITY_VERSION
    projection_id: str = Field(pattern=r"^P3F-projection-[0-9a-f]{64}$")
    projection_input_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    profile: DocumentFamilyFeatureProfile

    @model_validator(mode="after")
    def validate_result(self) -> Self:
        if (
            self.profile.family_scope_identity == ""
            or self.profile.document_identity == ""
            or self.profile.source_sha256 == ""
        ):
            msg = "family projection result has an incomplete profile binding"
            raise ValueError(msg)
        expected = "P3F-projection-" + canonical_sha256(
            {
                "domain": PROJECTION_IDENTITY_DOMAIN,
                "projection_input_identity": self.projection_input_identity,
                "profile_id": self.profile.profile_id,
            }
        )
        if self.projection_id != expected:
            msg = "family projection result identity mismatch"
            raise ValueError(msg)
        return self


def build_projection_result(
    *,
    projection_input_identity: str,
    profile: DocumentFamilyFeatureProfile,
) -> PdfFamilyFeatureProjectionResult:
    projection_id = "P3F-projection-" + canonical_sha256(
        {
            "domain": PROJECTION_IDENTITY_DOMAIN,
            "projection_input_identity": projection_input_identity,
            "profile_id": profile.profile_id,
        }
    )
    return PdfFamilyFeatureProjectionResult(
        projection_id=projection_id,
        projection_input_identity=projection_input_identity,
        profile=profile,
    )

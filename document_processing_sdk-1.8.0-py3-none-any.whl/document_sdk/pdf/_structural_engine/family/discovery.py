"""Deterministic bounded discovery, membership, drift, and compatibility."""

from __future__ import annotations

from itertools import combinations

from document_sdk.pdf._structural_engine.structure.identity import canonical_sha256

from .comparison import compare_document_family_profiles
from .contracts import (
    DISCOVERY_POLICY_VERSION,
    DocumentCompatibilityAssessment,
    DocumentFamilyCandidate,
    DocumentFamilyComparison,
    DocumentFamilyDiscoveryReport,
    DocumentFamilyFeatureProfile,
    DocumentFamilyMembership,
    DocumentLayoutDriftAssessment,
    PdfDocumentCompatibilityResult,
    PdfFamilyDiscoveryLimits,
    PdfFamilyMembershipStatus,
    build_compatibility,
    build_drift,
    build_membership,
    build_report,
    phase3f_identifier,
)

_STABILITY_THRESHOLD = 0.75
_MINIMUM_FAMILY_MEMBERS = 2


def _comparison_key(left: str, right: str) -> tuple[str, str]:
    if left <= right:
        return left, right
    return right, left


def _coverage(comparisons: tuple[DocumentFamilyComparison, ...]) -> float:
    groups = [group for item in comparisons for group in item.group_results]
    if not groups:
        return 0.0
    comparable = sum(item.state == "COMPARABLE" for item in groups)
    return round(comparable / len(groups), 6)


def _make_candidate(
    members: tuple[DocumentFamilyFeatureProfile, ...],
    comparisons: tuple[DocumentFamilyComparison, ...],
) -> DocumentFamilyCandidate:
    member_ids = {item.profile_id for item in members}
    intra = tuple(
        sorted(
            item.comparison_id
            for item in comparisons
            if {item.left_profile_id, item.right_profile_id} <= member_ids
        )
    )
    exact_counts = {
        profile.profile_id: sum(
            group.exact_match is True
            for comparison in comparisons
            if profile.profile_id
            in {comparison.left_profile_id, comparison.right_profile_id}
            and {comparison.left_profile_id, comparison.right_profile_id} <= member_ids
            for group in comparison.group_results
        )
        for profile in members
    }
    representative = min(
        members, key=lambda item: (-exact_counts[item.profile_id], item.profile_id)
    )
    member_profile_ids = tuple(sorted(member_ids))
    limitations = tuple(
        sorted({code for profile in members for code in profile.limitation_codes})
    )
    warnings = tuple(
        sorted({code for profile in members for code in profile.warning_codes})
    )
    coverage = _coverage(
        tuple(item for item in comparisons if item.comparison_id in set(intra))
    )
    return DocumentFamilyCandidate(
        family_id=phase3f_identifier(
            "family",
            {
                "policy": DISCOVERY_POLICY_VERSION,
                "member_profile_ids": member_profile_ids,
            },
        ),
        member_document_identities=tuple(
            sorted(item.document_identity for item in members)
        ),
        member_profile_ids=member_profile_ids,
        representative_profile_id=representative.profile_id,
        intra_family_comparison_ids=intra,
        evidence_coverage=coverage,
        stability_state=(
            "LIMITED_EVIDENCE" if coverage < _STABILITY_THRESHOLD else "STABLE"
        ),
        warning_codes=warnings,
        limitation_codes=limitations,
    )


def assess_layout_drift(
    *,
    family_id: str,
    baseline: DocumentFamilyFeatureProfile,
    target: DocumentFamilyFeatureProfile,
    comparison: DocumentFamilyComparison,
) -> DocumentLayoutDriftAssessment:
    changed = tuple(
        item.name
        for item in comparison.group_results
        if item.state == "COMPARABLE" and not item.exact_match
    )
    unchanged = tuple(
        item.name
        for item in comparison.group_results
        if item.state == "COMPARABLE" and item.exact_match
    )
    incomparable = tuple(
        item.name for item in comparison.group_results if item.state != "COMPARABLE"
    )
    if comparison.hard_incompatibility_evidence:
        severity, behavior = "MATERIAL", "REJECT_AS_INCOMPATIBLE"
    elif incomparable and not changed:
        severity, behavior = "UNKNOWN", "TYPED_UNKNOWN"
    elif changed:
        severity, behavior = "MINOR", "WARN_AND_PRESERVE"
    else:
        severity, behavior = "NONE", "UNCHANGED"
    return build_drift(
        family_id=family_id,
        baseline_profile_id=baseline.profile_id,
        target_profile_id=target.profile_id,
        changed_feature_groups=changed,
        unchanged_feature_groups=unchanged,
        incomparable_feature_groups=incomparable,
        severity=severity,
        safe_product_behavior=behavior,
        evidence_comparison_id=comparison.comparison_id,
    )


def _upstream_compatibility(target: DocumentFamilyFeatureProfile) -> str:
    statuses = set(target.upstream_statuses)
    if statuses & {
        "UNSUPPORTED",
        "IMAGE_ONLY_OCR_REQUIRED",
        "LEGACY_ENCODING_UNRELIABLE",
    }:
        return "UNSUPPORTED"
    if statuses & {"PARTIAL", "AMBIGUOUS", "UNAVAILABLE", "MISSING"}:
        return "LIMITED"
    return "SUPPORTED"


def _export_compatibility(target: DocumentFamilyFeatureProfile) -> str:
    outcome = next(
        item
        for item in target.feature_groups
        if item.name == "canonical_export_outcome"
    )
    if (
        outcome.state == "UNSUPPORTED"
        or "status:UNSUPPORTED" in outcome.categorical_values
    ):
        return "UNSUPPORTED"
    if outcome.state != "AVAILABLE":
        return "UNKNOWN"
    if "status:PROVEN" not in outcome.categorical_values:
        return "LIMITED"
    if "format:CSV" in outcome.categorical_values:
        return "LOSSY_WITH_DECLARATION"
    return "SUPPORTED"


def assess_compatibility(
    *,
    target: DocumentFamilyFeatureProfile,
    family: DocumentFamilyCandidate,
    comparison: DocumentFamilyComparison,
) -> DocumentCompatibilityAssessment:
    if comparison.relation == "SAME_FAMILY_PROVEN":
        structural = "PROVEN"
    elif comparison.relation == "SAME_FAMILY_WITH_DRIFT":
        structural = "DRIFTED"
    elif comparison.relation == "DISTINCT_FAMILY_PROVEN":
        structural = "INCOMPATIBLE"
    else:
        structural = "UNKNOWN"
    upstream = _upstream_compatibility(target)
    export = _export_compatibility(target)

    result: PdfDocumentCompatibilityResult
    if structural == "INCOMPATIBLE":
        result, behavior = "INCOMPATIBLE", "REJECT_INCOMPATIBLE"
    elif upstream == "UNSUPPORTED":
        result, behavior = "UNSUPPORTED_UPSTREAM", "REJECT_UNSUPPORTED"
    elif structural == "UNKNOWN" or export == "UNKNOWN":
        result, behavior = "UNKNOWN_COMPATIBILITY", "TYPED_UNKNOWN"
    elif (
        structural == "PROVEN"
        and upstream == "SUPPORTED"
        and export in {"SUPPORTED", "LOSSY_WITH_DECLARATION"}
    ):
        result, behavior = "COMPATIBLE", "PROCESS"
    else:
        result, behavior = "CONDITIONALLY_COMPATIBLE", "PROCESS_WITH_WARNINGS"
    return build_compatibility(
        target_document_identity=target.document_identity,
        target_profile_id=target.profile_id,
        reference_family_id=family.family_id,
        structural_compatibility=structural,
        upstream_support_compatibility=upstream,
        export_compatibility=export,
        limitation_exposure=target.limitation_codes,
        expected_safe_product_behavior=behavior,
        result=result,
        evidence_comparison_id=comparison.comparison_id,
    )


def _proven_clusters(
    ordered: tuple[DocumentFamilyFeatureProfile, ...],
    lookup: dict[tuple[str, str], DocumentFamilyComparison],
) -> list[list[DocumentFamilyFeatureProfile]]:
    clusters: list[list[DocumentFamilyFeatureProfile]] = []
    for profile in ordered:
        eligible = [
            cluster
            for cluster in clusters
            if all(
                lookup[_comparison_key(profile.profile_id, member.profile_id)].relation
                == "SAME_FAMILY_PROVEN"
                for member in cluster
            )
        ]
        if len(eligible) == 1:
            eligible[0].append(profile)
        else:
            clusters.append([profile])
    return clusters


def _known_membership(
    *,
    profile: DocumentFamilyFeatureProfile,
    candidate: DocumentFamilyCandidate,
    profile_by_id: dict[str, DocumentFamilyFeatureProfile],
    lookup: dict[tuple[str, str], DocumentFamilyComparison],
) -> tuple[
    DocumentFamilyMembership,
    DocumentLayoutDriftAssessment | None,
    DocumentCompatibilityAssessment,
]:
    representative = profile_by_id[candidate.representative_profile_id]
    if profile.profile_id == representative.profile_id:
        peer_id = next(
            item for item in candidate.member_profile_ids if item != profile.profile_id
        )
        comparison = lookup[_comparison_key(profile.profile_id, peer_id)]
        drift = None
    else:
        comparison = lookup[
            _comparison_key(profile.profile_id, representative.profile_id)
        ]
        drift = assess_layout_drift(
            family_id=candidate.family_id,
            baseline=representative,
            target=profile,
            comparison=comparison,
        )
    membership = build_membership(
        document_identity=profile.document_identity,
        profile_id=profile.profile_id,
        family_id=candidate.family_id,
        status="PROVEN_MEMBER",
        evidence_comparison_ids=(comparison.comparison_id,),
        conflicting_family_ids=(),
        drift_id=None if drift is None else drift.drift_id,
        confidence_state="PROVEN",
    )
    compatibility = assess_compatibility(
        target=profile,
        family=candidate,
        comparison=comparison,
    )
    return membership, drift, compatibility


def _external_membership(
    *,
    profile: DocumentFamilyFeatureProfile,
    candidates: tuple[DocumentFamilyCandidate, ...],
    profile_by_id: dict[str, DocumentFamilyFeatureProfile],
    lookup: dict[tuple[str, str], DocumentFamilyComparison],
) -> tuple[
    DocumentFamilyMembership,
    DocumentLayoutDriftAssessment | None,
    DocumentCompatibilityAssessment | None,
]:
    matches: list[tuple[DocumentFamilyCandidate, DocumentFamilyComparison]] = []
    considered: list[DocumentFamilyComparison] = []
    for candidate in candidates:
        representative = profile_by_id[candidate.representative_profile_id]
        comparison = lookup[
            _comparison_key(profile.profile_id, representative.profile_id)
        ]
        considered.append(comparison)
        if comparison.relation in {
            "SAME_FAMILY_PROVEN",
            "SAME_FAMILY_WITH_DRIFT",
        }:
            matches.append((candidate, comparison))
    evidence_ids = tuple(sorted(item.comparison_id for item in considered))
    family_id: str | None = None
    conflicting_family_ids: tuple[str, ...] = ()
    drift: DocumentLayoutDriftAssessment | None = None
    compatibility: DocumentCompatibilityAssessment | None = None
    status: PdfFamilyMembershipStatus
    if len(matches) > 1:
        status, confidence = "AMBIGUOUS_MEMBER", "AMBIGUOUS"
        conflicting_family_ids = tuple(sorted(item[0].family_id for item in matches))
    elif len(matches) == 1:
        candidate, comparison = matches[0]
        representative = profile_by_id[candidate.representative_profile_id]
        drift = assess_layout_drift(
            family_id=candidate.family_id,
            baseline=representative,
            target=profile,
            comparison=comparison,
        )
        family_id = candidate.family_id
        if comparison.relation == "SAME_FAMILY_PROVEN":
            status, confidence = "PROVEN_MEMBER", "PROVEN"
        else:
            status, confidence = "DRIFTED_MEMBER", "DRIFTED"
        compatibility = assess_compatibility(
            target=profile,
            family=candidate,
            comparison=comparison,
        )
    elif considered and all(item.relation == "INCOMPARABLE" for item in considered):
        status, confidence = "INCOMPARABLE", "INCOMPARABLE"
    else:
        status, confidence = "UNASSIGNED", "NONE"
    membership = build_membership(
        document_identity=profile.document_identity,
        profile_id=profile.profile_id,
        family_id=family_id,
        status=status,
        evidence_comparison_ids=evidence_ids,
        conflicting_family_ids=conflicting_family_ids,
        drift_id=None if drift is None else drift.drift_id,
        confidence_state=confidence,
    )
    return membership, drift, compatibility


def discover_document_families(
    profiles: tuple[DocumentFamilyFeatureProfile, ...],
    *,
    limits: PdfFamilyDiscoveryLimits,
) -> DocumentFamilyDiscoveryReport:
    """Discover pairwise-proven cliques without forced assignment."""
    if not profiles:
        msg = "document-family discovery input cannot be empty"
        raise ValueError(msg)
    if len(profiles) > limits.maximum_profiles:
        msg = "document-family profile limit exceeded"
        raise ValueError(msg)
    unique = {(item.document_identity, item.profile_id): item for item in profiles}
    ordered = tuple(unique[key] for key in sorted(unique))
    pairwise_count = len(ordered) * (len(ordered) - 1) // 2
    if pairwise_count > limits.maximum_pairwise_comparisons:
        msg = "document-family pairwise comparison limit exceeded"
        raise ValueError(msg)
    scopes = {item.family_scope_identity for item in ordered}
    if len(scopes) != 1:
        msg = "document-family discovery crosses scope boundary"
        raise ValueError(msg)
    comparisons = tuple(
        sorted(
            (
                compare_document_family_profiles(left, right)
                for left, right in combinations(ordered, 2)
            ),
            key=lambda item: item.comparison_id,
        )
    )
    lookup = {
        _comparison_key(item.left_profile_id, item.right_profile_id): item
        for item in comparisons
    }
    clusters = _proven_clusters(ordered, lookup)
    candidates = tuple(
        sorted(
            (
                _make_candidate(tuple(cluster), comparisons)
                for cluster in clusters
                if len(cluster) >= _MINIMUM_FAMILY_MEMBERS
            ),
            key=lambda item: item.family_id,
        )
    )
    profile_by_id = {item.profile_id: item for item in ordered}
    memberships: list[DocumentFamilyMembership] = []
    drifts: list[DocumentLayoutDriftAssessment] = []
    compatibilities: list[DocumentCompatibilityAssessment] = []
    for profile in ordered:
        compatibility: DocumentCompatibilityAssessment | None
        containing = [
            candidate
            for candidate in candidates
            if profile.profile_id in candidate.member_profile_ids
        ]
        if containing:
            membership, drift, compatibility = _known_membership(
                profile=profile,
                candidate=containing[0],
                profile_by_id=profile_by_id,
                lookup=lookup,
            )
        else:
            membership, drift, compatibility = _external_membership(
                profile=profile,
                candidates=candidates,
                profile_by_id=profile_by_id,
                lookup=lookup,
            )
        memberships.append(membership)
        if drift is not None:
            drifts.append(drift)
        if compatibility is not None:
            compatibilities.append(compatibility)

    memberships_tuple = tuple(sorted(memberships, key=lambda item: item.membership_id))
    return build_report(
        corpus_identity=canonical_sha256(
            tuple((item.document_identity, item.profile_id) for item in ordered)
        ),
        discovery_policy_identity=canonical_sha256(
            {"policy_version": DISCOVERY_POLICY_VERSION}
        ),
        family_scope_identity=next(iter(scopes)),
        profiles=ordered,
        comparisons=comparisons,
        candidates=candidates,
        memberships=memberships_tuple,
        drift_assessments=tuple(sorted(drifts, key=lambda item: item.drift_id)),
        compatibility_assessments=tuple(
            sorted(compatibilities, key=lambda item: item.assessment_id)
        ),
        unassigned_document_identities=tuple(
            sorted(
                item.document_identity
                for item in memberships_tuple
                if item.status == "UNASSIGNED"
            )
        ),
        incomparable_document_identities=tuple(
            sorted(
                item.document_identity
                for item in memberships_tuple
                if item.status == "INCOMPARABLE"
            )
        ),
        ambiguous_document_identities=tuple(
            sorted(
                item.document_identity
                for item in memberships_tuple
                if item.status == "AMBIGUOUS_MEMBER"
            )
        ),
        safety_codes=(
            "AMBIGUITY_PRESERVED",
            "INCOMPARABLE_NOT_SCORED",
            "NO_FORCED_ASSIGNMENT",
            "NO_SEMANTIC_NAMING",
            "UPSTREAM_STATUS_NOT_UPGRADED",
        ),
    )

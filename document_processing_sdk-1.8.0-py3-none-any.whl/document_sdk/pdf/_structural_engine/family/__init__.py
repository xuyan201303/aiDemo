"""Private, unwired document-family primitives."""

"""Private orchestration for one bounded family feature projection."""

from __future__ import annotations

from document_sdk.pdf._structural_engine.structure.identity import canonical_json_size

from .contracts import DocumentFamilyFeatureProfile, build_profile
from .current_artifact_projection import project_current_artifacts
from .projection_contracts import (
    PdfFamilyFeatureProjectionResult,
    PdfFamilyUpstreamBundle,
    build_projection_result,
)

_LIMIT_ERROR = "family projection resource contract exceeded"


def build_document_family_feature_projection(
    bundle: PdfFamilyUpstreamBundle,
) -> PdfFamilyFeatureProjectionResult:
    projected = project_current_artifacts(bundle)
    request = projected.request
    profile = build_profile(
        family_scope_identity=request.family_scope_identity,
        document_identity=request.document_identity,
        source_sha256=request.source_sha256,
        source_artifacts=projected.source_artifacts,
        feature_groups=projected.feature_groups,
        upstream_statuses=projected.upstream_statuses,
        warning_codes=projected.warning_codes,
        limitation_codes=projected.limitation_codes,
    )
    if canonical_json_size(profile) > request.limits.maximum_profile_canonical_bytes:
        raise ValueError(_LIMIT_ERROR)
    return build_projection_result(
        projection_input_identity=projected.projection_input_identity,
        profile=profile,
    )


def build_document_family_feature_profile(
    bundle: PdfFamilyUpstreamBundle,
) -> DocumentFamilyFeatureProfile:
    return build_document_family_feature_projection(bundle).profile

"""Deterministic structural projection from sealed current authorities."""

from __future__ import annotations

import math
from dataclasses import dataclass
from itertools import pairwise
from typing import TYPE_CHECKING, Literal

from pydantic import BaseModel, ValidationError

from document_sdk.pdf._structural_engine.facts.contracts import PdfBoundingBox
from document_sdk.pdf._structural_engine.facts.identifiers import (
    document_identifier,
    page_identifier,
)
from document_sdk.pdf._structural_engine.layout.contracts import (
    PdfLayoutGraphArtifact,
    PdfLayoutNode,
    PdfLayoutPageGraph,
)
from document_sdk.pdf._structural_engine.structure import (
    document_table_contracts as _document_table_contracts,
)
from document_sdk.pdf._structural_engine.structure import (
    document_table_fingerprint as _document_table_fingerprint,
)
from document_sdk.pdf._structural_engine.structure import (
    table_contracts as _table_contracts,
)
from document_sdk.pdf._structural_engine.structure import (
    table_document_manifest as _table_document_manifest,
)
from document_sdk.pdf._structural_engine.structure.identity import canonical_sha256
from document_sdk.pdf._structural_engine.structure.reading_contracts import (
    PdfReadingStructurePageReference,
    PdfReadingStructurePageSidecar,
)
from document_sdk.pdf._structural_engine.structure.reading_input import (
    PdfReadingPageAuthority,
    PdfReadingPageEvidence,
)

from .contracts import (
    PdfFamilyArtifactKind,
    PdfFamilyArtifactReference,
    PdfFamilyFeatureGroup,
    PdfFamilyFeatureName,
    build_feature_group,
)
from .projection_contracts import (
    CURRENT_ARTIFACT_AUTHORITY_VERSION,
    PROJECTION_INPUT_IDENTITY_DOMAIN,
    PdfFamilyUpstreamBundle,
)

if TYPE_CHECKING:
    from collections.abc import Iterable

PdfDocumentTable = _document_table_contracts.PdfDocumentTable
PdfDocumentTableManifest = _document_table_contracts.PdfDocumentTableManifest
PdfTablePageTransition = _document_table_contracts.PdfTablePageTransition
PdfTableTransitionFingerprint = (
    _document_table_fingerprint.PdfTableTransitionFingerprint
)
_validate_fingerprint_dependency = (
    _document_table_fingerprint.validate_transition_fingerprint_dependency
)
PdfTable = _table_contracts.PdfTable
PdfTableCell = _table_contracts.PdfTableCell
PdfTableStructurePageSidecar = _table_contracts.PdfTableStructurePageSidecar
PdfTableDocumentManifest = _table_document_manifest.PdfTableDocumentManifest
build_document_identity = _table_document_manifest.build_document_identity

_AUTHORITY_ERROR = "family projection artifact authority mismatch"
_INVENTORY_ERROR = "family projection inventory is noncanonical"
_LIMIT_ERROR = "family projection resource contract exceeded"
_CATEGORY_ERROR = "family projection categorical value is unsafe"
_NUMERIC_ERROR = "family projection numeric value is nonfinite"
_NO_TABLE_REASON = "NO_PHYSICALLY_PROVEN_TABLE"
_UNSUPPORTED_TABLE_REASON = "UPSTREAM_UNSUPPORTED_TABLE_STRUCTURE"
_UNSUPPORTED_PAGE_OUTCOMES = {
    "UNSUPPORTED",
    "UNAVAILABLE",
    "IMAGE_ONLY_OCR_REQUIRED",
    "LEGACY_ENCODING_UNRELIABLE",
}
_UNSUPPORTED_TRANSITION_OUTCOMES = {
    "UNSUPPORTED_SOURCE",
    "UNAVAILABLE_UPSTREAM",
    "RESOURCE_LIMITED",
}
_AMBIGUOUS_TRANSITION_OUTCOMES = {
    "AMBIGUOUS_CONTINUATION",
    "MULTIPLE_CANDIDATES",
}
_TEXT_NODE_TYPES = {"text_span", "word", "line_candidate"}
_GEOMETRY_TOLERANCE = 1e-6
_MAXIMUM_CATEGORY_LENGTH = 160
_MINIMUM_MULTILINE_NODES = 2
_MINIMUM_MULTILINE_BANDS = 2


@dataclass(frozen=True, slots=True)
class ProjectedCurrentArtifactFeatures:
    request: PdfFamilyUpstreamBundle
    projection_input_identity: str
    source_artifacts: tuple[PdfFamilyArtifactReference, ...]
    feature_groups: tuple[PdfFamilyFeatureGroup, ...]
    upstream_statuses: tuple[str, ...]
    warning_codes: tuple[str, ...]
    limitation_codes: tuple[str, ...]


def _validated[ModelT: BaseModel](model: type[ModelT], value: ModelT) -> ModelT:
    try:
        return model.model_validate(value.model_dump(mode="python"))
    except ValidationError:
        raise ValueError(_AUTHORITY_ERROR) from None


def _safe_code(value: str) -> str:
    if (
        not value
        or len(value) > _MAXIMUM_CATEGORY_LENGTH
        or not value.isascii()
        or not value.isprintable()
    ):
        raise ValueError(_CATEGORY_ERROR)
    return value


def _categorical(*groups: tuple[str, ...]) -> tuple[str, ...]:
    values = tuple(value for group in groups for value in group)
    for value in values:
        _safe_code(value)
    return tuple(sorted(set(values)))


def _numeric(values: Iterable[int | float]) -> tuple[float, ...]:
    result: set[float] = set()
    for value in values:
        number = float(value)
        if not math.isfinite(number):
            raise ValueError(_NUMERIC_ERROR)
        rounded = round(number, 3)
        result.add(0.0 if rounded == 0 else rounded)
    return tuple(sorted(result))


def _evidence_key(
    item: PdfFamilyArtifactReference,
) -> tuple[str, str, str, str]:
    return item.artifact_kind, item.role, item.artifact_id, item.sha256


def _artifact(
    artifact_kind: PdfFamilyArtifactKind,
    role: str,
    artifact_id: str,
    digest: str,
) -> PdfFamilyArtifactReference:
    return PdfFamilyArtifactReference(
        artifact_kind=artifact_kind,
        role=role,
        artifact_id=artifact_id,
        sha256=digest,
    )


def _available(
    name: PdfFamilyFeatureName,
    *,
    categorical_values: tuple[str, ...],
    numeric_values: tuple[float, ...],
    evidence: tuple[PdfFamilyArtifactReference, ...],
) -> PdfFamilyFeatureGroup:
    return build_feature_group(
        name=name,
        state="AVAILABLE",
        categorical_values=_categorical(categorical_values),
        numeric_values=_numeric(numeric_values),
        evidence=tuple(sorted(set(evidence), key=_evidence_key)),
    )


def _unavailable(
    name: PdfFamilyFeatureName,
    *,
    state: Literal["MISSING", "INCOMPARABLE", "UNSUPPORTED"],
    reason: str | tuple[str, ...],
    evidence: tuple[PdfFamilyArtifactReference, ...] = (),
) -> PdfFamilyFeatureGroup:
    reasons = (reason,) if isinstance(reason, str) else reason
    return build_feature_group(
        name=name,
        state=state,
        reason_codes=_categorical(reasons),
        evidence=tuple(sorted(set(evidence), key=_evidence_key)),
    )


def _reference_digest(
    reference: PdfReadingStructurePageReference,
) -> str:
    return canonical_sha256(
        {
            "domain": "document_sdk.pdf.phase3.family.reading_reference.v1",
            "sidecar_id": reference.sidecar_id,
            "page_id": reference.page_id,
            "page_index": reference.page_index,
            "reading_order_graph_id": reference.reading_order_graph_id,
            "hierarchy_graph_id": reference.hierarchy_graph_id,
            "block_count": len(reference.block_ids),
        }
    )


def _reading_digest(value: PdfReadingStructurePageSidecar) -> str:
    return canonical_sha256(
        {
            "domain": "document_sdk.pdf.phase3.family.reading_structure.v1",
            "sidecar_id": value.sidecar_id,
            "page_id": value.page_id,
            "page_index": value.page_index,
            "state": value.state,
            "block_topology": tuple(
                (
                    block.role,
                    block.role_status,
                    block.heading_level,
                    block.state,
                    len(block.source_node_ids),
                    len(block.source_fact_ids),
                )
                for block in value.blocks
            ),
            "reading_order_state": value.reading_order.state,
            "reading_relation_types": tuple(
                item.relation_type for item in value.reading_order.relations
            ),
            "unresolved_component_sizes": tuple(
                len(item) for item in value.reading_order.unresolved_components
            ),
            "hierarchy_state": value.hierarchy.state,
            "hierarchy_relation_count": len(value.hierarchy.relations),
            "limitation_codes": value.limitation_codes,
        }
    )


def _normalized_box(
    *,
    geometry: PdfBoundingBox,
    width: float,
    height: float,
) -> tuple[float, float, float, float]:
    return (
        geometry.x0 / width,
        geometry.y0 / height,
        geometry.x1 / width,
        geometry.y1 / height,
    )


def _table_projection(
    value: PdfTableStructurePageSidecar,
) -> tuple[
    tuple[
        str | int | float | bool | tuple[int, ...] | tuple[str, ...] | None,
        ...,
    ],
    ...,
]:
    return tuple(
        (
            table.table_index,
            table.state,
            *_normalized_box(
                geometry=table.geometry,
                width=value.canonical_width,
                height=value.canonical_height,
            ),
            len(table.rows),
            len(table.columns),
            len(table.cells),
            tuple(cell.row_span for cell in table.cells),
            tuple(cell.column_span for cell in table.cells),
            tuple(cell.state for cell in table.cells),
            tuple(cell.role for cell in table.cells),
            tuple(cell.role_status for cell in table.cells),
            table.limitation_codes,
        )
        for table in value.tables
    )


def _page_table_digest(value: PdfTableStructurePageSidecar) -> str:
    return canonical_sha256(
        {
            "domain": "document_sdk.pdf.phase3.family.page_table.v1",
            "sidecar_id": value.sidecar_id,
            "source_sha256": value.source_sha256,
            "page_id": value.page_id,
            "page_index": value.page_index,
            "canonical_width": value.canonical_width,
            "canonical_height": value.canonical_height,
            "outcome": value.outcome,
            "tables": _table_projection(value),
            "negative_evidence_categories": tuple(
                item.evidence_categories for item in value.negative_evidence
            ),
            "algorithm_version": value.algorithm_version,
            "operation_version": value.operation_version,
            "configuration_identity": value.configuration_identity,
            "dependency_identity": value.dependency_identity,
            "limitation_codes": value.limitation_codes,
        }
    )


def _document_manifest_digest(value: PdfDocumentTableManifest) -> str:
    return canonical_sha256(
        {
            "domain": "document_sdk.pdf.phase3.family.document_table_manifest.v2",
            "manifest_id": value.manifest_id,
            "source_sha256": value.source_sha256,
            "document_identity": value.document_identity,
            "page_table_manifest_id": value.page_table_manifest_id,
            "page_table_manifest_sha256": value.page_table_manifest_sha256,
            "transition_ids": value.transition_ids,
            "document_table_ids": value.document_table_ids,
            "transition_count": value.transition_count,
            "document_table_count": value.document_table_count,
            "adjacent_page_pair_count": value.adjacent_page_pair_count,
            "evaluated_adjacent_page_pair_count": (
                value.evaluated_adjacent_page_pair_count
            ),
            "no_candidate_page_pair_count": value.no_candidate_page_pair_count,
            "resource_limited_page_pair_count": (
                value.resource_limited_page_pair_count
            ),
            "unavailable_adjacent_page_pair_count": (
                value.unavailable_adjacent_page_pair_count
            ),
            "limitation_codes": value.limitation_codes,
        }
    )


def _transition_digest(value: PdfTablePageTransition) -> str:
    return canonical_sha256(
        {
            "domain": "document_sdk.pdf.phase3.family.document_table_transition.v1",
            "transition_id": value.transition_id,
            "left_page_index": value.left.page_index,
            "right_page_index": value.right.page_index,
            "left_table_id": value.left.table_id,
            "right_table_id": value.right.table_id,
            "outcome": value.outcome,
            "column_mappings": tuple(
                (
                    item.left_column_index,
                    item.right_column_index,
                    item.normalized_axis_distance,
                    item.width_ratio_difference,
                    item.topology_compatible,
                )
                for item in value.column_mappings
            ),
            "repeated_header_count": len(value.repeated_header_mappings),
            "row_fragment_count": len(value.row_fragment_links),
            "table_geometry_compatible": value.table_geometry_compatible,
            "topology_compatible": value.topology_compatible,
            "page_boundary_evidence_strength": (value.page_boundary_evidence_strength),
            "fingerprint_support_strength": value.fingerprint_support_strength,
            "candidate_pair_count": value.candidate_pair_count,
            "limitation_codes": value.limitation_codes,
        }
    )


def _fingerprint_digest(value: PdfTableTransitionFingerprint) -> str:
    return canonical_sha256(
        {
            "domain": "document_sdk.pdf.phase3.family.document_table_fingerprint.v1",
            "fingerprint_id": value.fingerprint_id,
            "semantic_fingerprint_identity": value.semantic_fingerprint_identity,
            "state": value.state,
            "transition_id": value.transition_id,
            "page_pair_geometry": value.page_pair_geometry,
            "column_continuity": value.column_continuity,
            "header_continuity": {
                "repeated_header_present": (
                    value.header_continuity.repeated_header_present
                ),
                "repeated_header_depth": value.header_continuity.repeated_header_depth,
                "header_pattern": value.header_continuity.header_pattern,
                "merged_header_topology_present": (
                    value.header_continuity.merged_header_topology_signature is not None
                ),
                "normalized_header_geometry_signature": (
                    value.header_continuity.normalized_header_geometry_signature
                ),
                "symbolic_repetition": value.header_continuity.symbolic_repetition,
                "repeated_occurrence_count": (
                    value.header_continuity.repeated_occurrence_count
                ),
                "body_start_offset": value.header_continuity.body_start_offset,
            },
            "row_cell_continuity": value.row_cell_continuity,
            "pair_context": value.pair_context,
            "safety_state": value.safety_state,
            "limitation_codes": value.limitation_codes,
        }
    )


def _exact_reading_bindings(request: PdfFamilyUpstreamBundle) -> None:
    layout = request.page_layout
    evidence = request.reading_page_evidence
    authority = request.reading_authority
    structures = request.reading_structures
    structure_references = request.reading_structure_references
    source_sha256 = request.source_sha256
    pages = layout.pages
    page_indexes = tuple(item.page_index for item in evidence)
    if page_indexes != tuple(range(len(pages))):
        raise ValueError(_INVENTORY_ERROR)
    if authority.source_sha256 != source_sha256 or authority.page_count != len(pages):
        raise ValueError(_AUTHORITY_ERROR)
    if len(authority.page_references) != len(evidence):
        raise ValueError(_AUTHORITY_ERROR)
    for page, item, reference in zip(
        pages,
        evidence,
        authority.page_references,
        strict=True,
    ):
        if (
            item.source_sha256 != source_sha256
            or item.page_id != page.source_page_id
            or item.page_index != page.page_number - 1
            or item.page_layout_graph_id != layout.layout_graph_id
            or item.page_layout_graph_digest != layout.graph_digest
            or reference.page_id != item.page_id
            or reference.page_index != item.page_index
            or reference.sidecar_id != item.sidecar_id
            or reference.structural_page_sha256 != item.payload.structural_page_sha256
        ):
            raise ValueError(_AUTHORITY_ERROR)

    structure_indexes = tuple(item.page_index for item in structures)
    reference_indexes = tuple(item.page_index for item in structure_references)
    if structure_indexes != tuple(sorted(set(structure_indexes))) or (
        reference_indexes != structure_indexes
    ):
        raise ValueError(_INVENTORY_ERROR)
    evidence_by_index = {item.page_index: item for item in evidence}
    authority_refs = {item.page_index: item for item in authority.page_references}
    for structure, structure_reference in zip(
        structures,
        structure_references,
        strict=True,
    ):
        inherited = evidence_by_index.get(structure.page_index)
        authority_reference = authority_refs.get(structure.page_index)
        if inherited is None or authority_reference is None:
            raise ValueError(_AUTHORITY_ERROR)
        if (
            structure.source_sha256 != source_sha256
            or structure.page_id != inherited.page_id
            or structure.provenance.source_sha256 != source_sha256
            or structure.provenance.page_id != inherited.page_id
            or structure.provenance.page_index != inherited.page_index
            or structure.provenance.inherited_manifest_id != authority.manifest_id
            or structure.provenance.inherited_page_sidecar_id != inherited.sidecar_id
            or structure.provenance.inherited_page_sidecar_sha256
            != authority_reference.sidecar_file_sha256
            or structure_reference.sidecar_id != structure.sidecar_id
            or structure_reference.page_id != structure.page_id
            or structure_reference.reading_order_graph_id
            != structure.reading_order.graph_id
            or structure_reference.hierarchy_graph_id != structure.hierarchy.graph_id
            or structure_reference.block_ids
            != tuple(block.block_id for block in structure.blocks)
        ):
            raise ValueError(_AUTHORITY_ERROR)


def _exact_page_table_bindings(request: PdfFamilyUpstreamBundle) -> None:
    layout = request.page_layout
    reading_evidence = request.reading_page_evidence
    reading_authority = request.reading_authority
    reading_structures = request.reading_structures
    reading_structure_references = request.reading_structure_references
    manifest = request.page_table_manifest
    page_tables = request.page_tables
    source_sha256 = request.source_sha256
    document_identity = request.document_identity
    if (
        manifest.source_sha256 != source_sha256
        or manifest.document_identity != document_identity
        or manifest.reading_authority_id != reading_authority.manifest_id
    ):
        raise ValueError(_AUTHORITY_ERROR)
    indexes = tuple(item.page_index for item in page_tables)
    if indexes != tuple(range(len(layout.pages))):
        raise ValueError(_INVENTORY_ERROR)
    if len(manifest.page_references) != len(page_tables):
        raise ValueError(_AUTHORITY_ERROR)
    reading_by_index = {item.page_index: item for item in reading_evidence}
    structures_by_index = {item.page_index: item for item in reading_structures}
    structure_refs_by_index = {
        item.page_index: item for item in reading_structure_references
    }
    authority_refs_by_index = {
        item.page_index: item for item in reading_authority.page_references
    }
    for layout_page, sidecar, reference in zip(
        layout.pages,
        page_tables,
        manifest.page_references,
        strict=True,
    ):
        inherited = reading_by_index[sidecar.page_index]
        authority_reference = authority_refs_by_index[sidecar.page_index]
        if (
            sidecar.source_sha256 != source_sha256
            or sidecar.page_id != layout_page.source_page_id
            or sidecar.page_index != layout_page.page_number - 1
            or sidecar.canonical_width != layout_page.canonical_width
            or sidecar.canonical_height != layout_page.canonical_height
            or sidecar.inherited_manifest_id != reading_authority.manifest_id
            or sidecar.inherited_page_sidecar_id != inherited.sidecar_id
            or sidecar.inherited_page_sidecar_sha256
            != authority_reference.sidecar_file_sha256
            or reference.page_id != sidecar.page_id
            or reference.page_index != sidecar.page_index
            or reference.sidecar_id != sidecar.sidecar_id
            or reference.outcome != sidecar.outcome
            or reference.table_ids != tuple(table.table_id for table in sidecar.tables)
        ):
            raise ValueError(_AUTHORITY_ERROR)
        structure = structures_by_index.get(sidecar.page_index)
        structure_reference = structure_refs_by_index.get(sidecar.page_index)
        if structure is None:
            if sidecar.reading_page_sidecar_id is not None:
                raise ValueError(_AUTHORITY_ERROR)
        elif (
            structure_reference is None
            or sidecar.reading_page_sidecar_id != structure.sidecar_id
            or sidecar.reading_page_sidecar_sha256 != structure_reference.sidecar_sha256
        ):
            raise ValueError(_AUTHORITY_ERROR)
        _validate_cell_layout_join(layout_page=layout_page, sidecar=sidecar)


def _inside_cell(node: PdfLayoutNode, cell: PdfTableCell) -> bool:
    return bool(
        node.bbox.x0 >= cell.geometry.x0 - _GEOMETRY_TOLERANCE
        and node.bbox.y0 >= cell.geometry.y0 - _GEOMETRY_TOLERANCE
        and node.bbox.x1 <= cell.geometry.x1 + _GEOMETRY_TOLERANCE
        and node.bbox.y1 <= cell.geometry.y1 + _GEOMETRY_TOLERANCE
    )


def _center_inside_cell(node: PdfLayoutNode, cell: PdfTableCell) -> bool:
    center_x = (node.bbox.x0 + node.bbox.x1) / 2
    center_y = (node.bbox.y0 + node.bbox.y1) / 2
    return bool(
        center_x >= cell.geometry.x0 - _GEOMETRY_TOLERANCE
        and center_y >= cell.geometry.y0 - _GEOMETRY_TOLERANCE
        and center_x <= cell.geometry.x1 + _GEOMETRY_TOLERANCE
        and center_y <= cell.geometry.y1 + _GEOMETRY_TOLERANCE
    )


def _has_positive_cell_intersection(
    node: PdfLayoutNode,
    cell: PdfTableCell,
) -> bool:
    return bool(
        min(node.bbox.x1, cell.geometry.x1) - max(node.bbox.x0, cell.geometry.x0) > 0
        and min(node.bbox.y1, cell.geometry.y1) - max(node.bbox.y0, cell.geometry.y0)
        > 0
    )


def _has_center_assignment_authority(cell: PdfTableCell) -> bool:
    evidence = set(cell.text_assignment_evidence)
    return bool(
        "center_inside_cell" in evidence
        or {"stable_column_anchor", "stable_row_band"} <= evidence
    )


def _validate_cell_layout_join(
    *,
    layout_page: PdfLayoutPageGraph,
    sidecar: PdfTableStructurePageSidecar,
) -> None:
    nodes = {item.node_id: item for item in layout_page.nodes}
    assigned: set[str] = set()
    for table in sidecar.tables:
        for cell in table.cells:
            for node_id in cell.text_layout_node_ids:
                node = nodes.get(node_id)
                if (
                    node is None
                    or node.node_type not in _TEXT_NODE_TYPES
                    or node_id not in cell.evidence.source_layout_node_ids
                    or node_id in assigned
                ):
                    raise ValueError(_AUTHORITY_ERROR)
                if not _inside_cell(node, cell) and not (
                    _has_center_assignment_authority(cell)
                    and _center_inside_cell(node, cell)
                    and _has_positive_cell_intersection(node, cell)
                ):
                    raise ValueError(_AUTHORITY_ERROR)
                assigned.add(node_id)


def _exact_document_table_bindings(  # noqa: C901, PLR0912
    request: PdfFamilyUpstreamBundle,
) -> None:
    if request.document_table_state != "COMPLETED":
        if (
            request.document_table_manifest is not None
            or request.document_tables
            or request.transitions
            or request.transition_fingerprints
        ):
            raise ValueError(_AUTHORITY_ERROR)
        return
    manifest = request.document_table_manifest
    if manifest is None:
        raise ValueError(_AUTHORITY_ERROR)
    if (
        manifest.source_sha256 != request.source_sha256
        or manifest.document_identity != request.document_identity
        or manifest.page_table_manifest_id != request.page_table_manifest.manifest_id
        or manifest.page_table_manifest_sha256
        != request.page_table_manifest.page_table_manifest_sha256
        or manifest.transition_ids
        != tuple(item.transition_id for item in request.transitions)
        or manifest.document_table_ids
        != tuple(item.document_table_id for item in request.document_tables)
    ):
        raise ValueError(_AUTHORITY_ERROR)
    sidecars = {item.sidecar_id: item for item in request.page_tables}
    references = {
        item.sidecar_id: item for item in request.page_table_manifest.page_references
    }
    tables = {
        table.table_id: (sidecar, table)
        for sidecar in request.page_tables
        for table in sidecar.tables
    }
    transition_by_id = {item.transition_id: item for item in request.transitions}
    for transition in request.transitions:
        for endpoint in (transition.left, transition.right):
            sidecar = sidecars.get(endpoint.table_sidecar_id)
            reference = references.get(endpoint.table_sidecar_id)
            table_pair = tables.get(endpoint.table_id)
            if sidecar is None or reference is None or table_pair is None:
                raise ValueError(_AUTHORITY_ERROR)
            _, table = table_pair
            if (
                endpoint.source_sha256 != request.source_sha256
                or endpoint.document_identity != request.document_identity
                or endpoint.page_table_manifest_sha256
                != request.page_table_manifest.page_table_manifest_sha256
                or endpoint.page_id != sidecar.page_id
                or endpoint.page_index != sidecar.page_index
                or endpoint.table_sidecar_sha256 != reference.sidecar_sha256
                or endpoint.configuration_identity != sidecar.configuration_identity
                or endpoint.dependency_identity != sidecar.dependency_identity
                or endpoint.table_row_ids != tuple(row.row_id for row in table.rows)
                or endpoint.table_cell_ids
                != tuple(cell.cell_id for cell in table.cells)
            ):
                raise ValueError(_AUTHORITY_ERROR)
    for document_table in request.document_tables:
        if (
            document_table.source_sha256 != request.source_sha256
            or document_table.document_identity != request.document_identity
            or document_table.page_table_manifest_sha256
            != request.page_table_manifest.page_table_manifest_sha256
            or any(
                item not in transition_by_id for item in document_table.transition_ids
            )
        ):
            raise ValueError(_AUTHORITY_ERROR)
    for fingerprint in request.transition_fingerprints:
        fingerprint_transition = transition_by_id.get(fingerprint.transition_id)
        if (
            fingerprint_transition is None
            or fingerprint.source_sha256 != request.source_sha256
            or fingerprint.document_identity != request.document_identity
        ):
            raise ValueError(_AUTHORITY_ERROR)
        try:
            _validate_fingerprint_dependency(fingerprint, fingerprint_transition)
        except ValueError:
            raise ValueError(_AUTHORITY_ERROR) from None


def _resource_inventory(request: PdfFamilyUpstreamBundle) -> None:
    limits = request.limits
    page_count = len(request.page_layout.pages)
    table_count = sum(len(item.tables) for item in request.page_tables)
    cell_count = sum(
        len(table.cells) for item in request.page_tables for table in item.tables
    )
    exceeds = (
        page_count > limits.maximum_pages
        or request.page_layout.total_node_count > limits.maximum_layout_nodes
        or table_count > limits.maximum_tables
        or cell_count > limits.maximum_cells
        or len(request.transitions) > limits.maximum_transitions
        or len(request.transition_fingerprints) > limits.maximum_fingerprints
    )
    if exceeds:
        raise ValueError(_LIMIT_ERROR)


def validate_current_artifact_request(
    request: PdfFamilyUpstreamBundle,
) -> PdfFamilyUpstreamBundle:
    layout = _validated(PdfLayoutGraphArtifact, request.page_layout)
    evidence = tuple(
        _validated(PdfReadingPageEvidence, item)
        for item in request.reading_page_evidence
    )
    authority = _validated(PdfReadingPageAuthority, request.reading_authority)
    structures = tuple(
        _validated(PdfReadingStructurePageSidecar, item)
        for item in request.reading_structures
    )
    structure_references = tuple(
        _validated(PdfReadingStructurePageReference, item)
        for item in request.reading_structure_references
    )
    page_table_manifest = _validated(
        PdfTableDocumentManifest,
        request.page_table_manifest,
    )
    page_tables = tuple(
        _validated(PdfTableStructurePageSidecar, item) for item in request.page_tables
    )
    document_manifest = (
        None
        if request.document_table_manifest is None
        else _validated(PdfDocumentTableManifest, request.document_table_manifest)
    )
    document_tables = tuple(
        sorted(
            (_validated(PdfDocumentTable, item) for item in request.document_tables),
            key=lambda item: item.document_table_id,
        )
    )
    transitions = tuple(
        _validated(PdfTablePageTransition, item) for item in request.transitions
    )
    fingerprints = tuple(
        sorted(
            (
                _validated(PdfTableTransitionFingerprint, item)
                for item in request.transition_fingerprints
            ),
            key=lambda item: (item.left_page_index, item.fingerprint_id),
        )
    )
    if not layout.pages:
        raise ValueError(_AUTHORITY_ERROR)
    expected_document = document_identifier(source_hash=request.source_sha256)
    if layout.source_document_id != expected_document:
        raise ValueError(_AUTHORITY_ERROR)
    page_numbers = tuple(item.page_number for item in layout.pages)
    if page_numbers != tuple(range(1, len(layout.pages) + 1)):
        raise ValueError(_INVENTORY_ERROR)
    for page in layout.pages:
        expected_page = page_identifier(
            source_hash=request.source_sha256,
            parser_name=layout.source_parser_name,
            parser_version=layout.source_parser_version,
            page_number=page.page_number,
        )
        if page.source_page_id != expected_page:
            raise ValueError(_AUTHORITY_ERROR)
    expected_family_document = build_document_identity(
        source_sha256=request.source_sha256,
        page_table_manifest_sha256=page_table_manifest.page_table_manifest_sha256,
    )
    if request.document_identity != expected_family_document:
        raise ValueError(_AUTHORITY_ERROR)
    transition_order = tuple(
        (item.left.page_index, item.right.page_index, item.transition_id)
        for item in transitions
    )
    if transition_order != tuple(sorted(set(transition_order))):
        raise ValueError(_INVENTORY_ERROR)
    if len({item.sidecar_id for item in page_tables}) != len(page_tables) or len(
        {item.fingerprint_id for item in fingerprints}
    ) != len(fingerprints):
        raise ValueError(_INVENTORY_ERROR)
    canonical = PdfFamilyUpstreamBundle(
        authority_version=request.authority_version,
        family_scope_identity=request.family_scope_identity,
        document_identity=request.document_identity,
        source_sha256=request.source_sha256,
        page_layout=layout,
        reading_page_evidence=evidence,
        reading_authority=authority,
        reading_structures=structures,
        reading_structure_references=structure_references,
        page_table_manifest=page_table_manifest,
        page_tables=page_tables,
        document_table_state=request.document_table_state,
        document_table_manifest=document_manifest,
        document_tables=document_tables,
        transitions=transitions,
        transition_fingerprints=fingerprints,
        canonical_export_state=request.canonical_export_state,
        limits=request.limits,
    )
    _exact_reading_bindings(canonical)
    _exact_page_table_bindings(canonical)
    _exact_document_table_bindings(canonical)
    _resource_inventory(canonical)
    return canonical


def _layout_extent(page: PdfLayoutPageGraph) -> tuple[float, ...]:
    if not page.nodes:
        return ()
    geometry = PdfBoundingBox(
        x0=min(item.bbox.x0 for item in page.nodes),
        y0=min(item.bbox.y0 for item in page.nodes),
        x1=max(item.bbox.x1 for item in page.nodes),
        y1=max(item.bbox.y1 for item in page.nodes),
    )
    return _normalized_box(
        geometry=geometry,
        width=page.canonical_width,
        height=page.canonical_height,
    )


def _page_layout_group(
    request: PdfFamilyUpstreamBundle,
    evidence: tuple[PdfFamilyArtifactReference, ...],
) -> PdfFamilyFeatureGroup:
    layout = request.page_layout
    categories = _categorical(
        (f"page_count:{len(layout.pages)}",),
        (f"layout_status:{layout.build_status.value.upper()}",),
        (f"layout_partial:{str(layout.partial_build).lower()}",),
        tuple(f"rotation:{item.rotation}" for item in layout.pages),
        (f"reading_authority_state:{request.reading_authority.state.upper()}",),
        tuple(
            f"reading_state:{item.state.upper()}" for item in request.reading_structures
        ),
        tuple(
            f"reading_order_state:{item.reading_order.state.upper()}"
            for item in request.reading_structures
        ),
        tuple(
            f"reading_unresolved_components:{len(item.reading_order.unresolved_components)}"
            for item in request.reading_structures
        ),
    )
    numeric = _numeric(
        value
        for page in layout.pages
        for value in (
            page.canonical_width / page.canonical_height,
            *_layout_extent(page),
        )
    )
    return _available(
        "page_layout",
        categorical_values=categories,
        numeric_values=numeric,
        evidence=evidence,
    )


def _table_strategy(table: PdfTable) -> str:
    categories = set(table.evidence.evidence_categories)
    if "stable_borderless_column_anchors" in categories:
        return "borderless"
    if "partial_internal_ruling" in categories:
        return "partially_ruled"
    if "orthogonal_separator_grid" in categories:
        return "ruled"
    return "other_physically_proven"


def _table_layout_group(
    request: PdfFamilyUpstreamBundle,
    evidence: tuple[PdfFamilyArtifactReference, ...],
) -> PdfFamilyFeatureGroup:
    tables = tuple(table for page in request.page_tables for table in page.tables)
    outcomes = tuple(item.outcome for item in request.page_tables)
    if not tables and any(item in _UNSUPPORTED_PAGE_OUTCOMES for item in outcomes):
        return _unavailable(
            "table_layout",
            state="UNSUPPORTED",
            reason=_UNSUPPORTED_TABLE_REASON,
            evidence=evidence,
        )
    if not tables and any(item != "NO_TABLE" for item in outcomes):
        return _unavailable(
            "table_layout",
            state="INCOMPARABLE",
            reason="TABLE_STRUCTURE_NOT_PHYSICALLY_PROVEN",
            evidence=evidence,
        )
    categories = _categorical(
        (f"table_count:{len(tables)}",),
        tuple(f"page_table_outcome:{item}" for item in outcomes),
        tuple(f"table_state:{item.state}" for item in tables),
        tuple(f"table_strategy:{_table_strategy(item)}" for item in tables),
        ("NO_TABLE_PROVEN",) if not tables else (),
    )
    numeric = _numeric(
        (
            (table.geometry.x1 - table.geometry.x0)
            * (table.geometry.y1 - table.geometry.y0)
            / (page.canonical_width * page.canonical_height)
        )
        for page in request.page_tables
        for table in page.tables
    )
    return _available(
        "table_layout",
        categorical_values=categories,
        numeric_values=numeric,
        evidence=evidence,
    )


def _table_unavailable_group(
    *,
    name: Literal["column_topology", "header_topology", "row_cell_structure"],
    table_layout: PdfFamilyFeatureGroup,
    evidence: tuple[PdfFamilyArtifactReference, ...],
) -> PdfFamilyFeatureGroup:
    if table_layout.state == "UNSUPPORTED":
        return _unavailable(
            name,
            state="UNSUPPORTED",
            reason=_UNSUPPORTED_TABLE_REASON,
            evidence=evidence,
        )
    return _unavailable(
        name,
        state="MISSING",
        reason=_NO_TABLE_REASON,
        evidence=evidence,
    )


def _column_topology_group(
    request: PdfFamilyUpstreamBundle,
    table_layout: PdfFamilyFeatureGroup,
    evidence: tuple[PdfFamilyArtifactReference, ...],
) -> PdfFamilyFeatureGroup:
    tables = tuple(table for page in request.page_tables for table in page.tables)
    if not tables:
        return _table_unavailable_group(
            name="column_topology",
            table_layout=table_layout,
            evidence=evidence,
        )
    numeric_values: list[float] = []
    for page in request.page_tables:
        for table in page.tables:
            numeric_values.extend(
                (
                    (column.geometry.x1 - column.geometry.x0)
                    / (table.geometry.x1 - table.geometry.x0)
                )
                for column in table.columns
            )
            centers = tuple(
                (item.geometry.x0 + item.geometry.x1) / 2 for item in table.columns
            )
            numeric_values.extend(
                (right - left) / page.canonical_width
                for left, right in pairwise(centers)
            )
    return _available(
        "column_topology",
        categorical_values=_categorical(
            tuple(f"column_count:{len(item.columns)}" for item in tables),
            ("ordered_one_to_one_topology:proven",),
        ),
        numeric_values=_numeric(numeric_values),
        evidence=evidence,
    )


def _header_topology_group(
    request: PdfFamilyUpstreamBundle,
    table_layout: PdfFamilyFeatureGroup,
    evidence: tuple[PdfFamilyArtifactReference, ...],
) -> PdfFamilyFeatureGroup:
    tables = tuple(table for page in request.page_tables for table in page.tables)
    if not tables:
        return _table_unavailable_group(
            name="header_topology",
            table_layout=table_layout,
            evidence=evidence,
        )
    categories: list[str] = []
    for table in tables:
        header_rows = {
            cell.row_start for cell in table.cells if cell.role == "COLUMN_HEADER_LIKE"
        }
        categories.extend(
            (
                f"header_row_count:{len(header_rows)}",
                "merged_header:present"
                if any(
                    cell.column_span > 1 and cell.row_start in header_rows
                    for cell in table.cells
                )
                else "merged_header:absent",
                "row_header:present"
                if any(cell.role == "ROW_HEADER_LIKE" for cell in table.cells)
                else "row_header:absent",
            )
        )
        categories.extend(f"header_role:{cell.role}" for cell in table.cells)
    repeated_count = sum(
        len(item.repeated_header_mappings) for item in request.transitions
    )
    categories.append(f"repeated_header_mapping_count:{repeated_count}")
    return _available(
        "header_topology",
        categorical_values=_categorical(tuple(categories)),
        numeric_values=(),
        evidence=evidence,
    )


def _physically_multiline(
    cell: PdfTableCell,
    *,
    nodes: dict[str, PdfLayoutNode],
) -> bool:
    selected = tuple(nodes[item] for item in cell.text_layout_node_ids)
    if len(selected) < _MINIMUM_MULTILINE_NODES or any(
        item.rotation not in {None, 0, 180, -180} for item in selected
    ):
        return False
    intervals = sorted((item.bbox.y0, item.bbox.y1) for item in selected)
    bands = 0
    end: float | None = None
    for start, stop in intervals:
        if end is None or start > end + _GEOMETRY_TOLERANCE:
            bands += 1
            end = stop
        else:
            end = max(end, stop)
    return bands >= _MINIMUM_MULTILINE_BANDS


def _row_cell_structure_group(
    request: PdfFamilyUpstreamBundle,
    table_layout: PdfFamilyFeatureGroup,
    evidence: tuple[PdfFamilyArtifactReference, ...],
) -> PdfFamilyFeatureGroup:
    page_pairs = tuple(
        (page, table) for page in request.page_tables for table in page.tables
    )
    if not page_pairs:
        return _table_unavailable_group(
            name="row_cell_structure",
            table_layout=table_layout,
            evidence=evidence,
        )
    layout_by_index = {
        item.page_number - 1: {node.node_id: node for node in item.nodes}
        for item in request.page_layout.pages
    }
    categories: list[str] = []
    numeric: list[float] = []
    for page, table in page_pairs:
        cell_count = len(table.cells)
        covered_positions = sum(
            cell.row_span * cell.column_span for cell in table.cells
        )
        multiline = sum(
            _physically_multiline(cell, nodes=layout_by_index[page.page_index])
            for cell in table.cells
        )
        merged = sum(cell.row_span > 1 or cell.column_span > 1 for cell in table.cells)
        empty = sum(cell.state == "PROVEN_EMPTY" for cell in table.cells)
        categories.extend(
            (
                f"row_count:{len(table.rows)}",
                f"cell_count:{cell_count}",
                "multiline_basis:layout_geometry_bands",
            )
        )
        categories.extend(f"row_span:{cell.row_span}" for cell in table.cells)
        categories.extend(f"column_span:{cell.column_span}" for cell in table.cells)
        numeric.extend(
            (
                merged / cell_count,
                empty / cell_count,
                multiline / cell_count,
                covered_positions / (len(table.rows) * len(table.columns)),
            )
        )
    return _available(
        "row_cell_structure",
        categorical_values=_categorical(tuple(categories)),
        numeric_values=_numeric(numeric),
        evidence=evidence,
    )


def _continuity_group(  # noqa: PLR0911
    request: PdfFamilyUpstreamBundle,
    evidence: tuple[PdfFamilyArtifactReference, ...],
) -> PdfFamilyFeatureGroup:
    if request.document_table_state == "NOT_EXECUTED":
        return _unavailable(
            "cross_page_continuity",
            state="MISSING",
            reason="DOCUMENT_TABLE_NOT_EXECUTED",
        )
    if request.document_table_state in {"UNSUPPORTED", "UNAVAILABLE"}:
        return _unavailable(
            "cross_page_continuity",
            state="UNSUPPORTED",
            reason=f"DOCUMENT_TABLE_{request.document_table_state}",
        )
    manifest = request.document_table_manifest
    if manifest is None:
        raise ValueError(_AUTHORITY_ERROR)
    incomplete_reasons = _categorical(
        (
            ("DOCUMENT_TABLE_RESOURCE_LIMITED",)
            if manifest.resource_limited_page_pair_count
            else ()
        ),
        (
            ("DOCUMENT_TABLE_INPUT_UNAVAILABLE",)
            if manifest.unavailable_adjacent_page_pair_count
            else ()
        ),
    )
    if incomplete_reasons:
        return _unavailable(
            "cross_page_continuity",
            state="INCOMPARABLE",
            reason=incomplete_reasons,
            evidence=evidence,
        )
    if not request.transitions:
        if (
            manifest.evaluated_adjacent_page_pair_count
            or manifest.no_candidate_page_pair_count
            != manifest.adjacent_page_pair_count
        ):
            return _unavailable(
                "cross_page_continuity",
                state="INCOMPARABLE",
                reason="DOCUMENT_TABLE_TRANSITION_INVENTORY_INCOMPLETE",
                evidence=evidence,
            )
        return _available(
            "cross_page_continuity",
            categorical_values=("continuity_outcome:none", "transition_count:0"),
            numeric_values=(),
            evidence=evidence,
        )
    outcomes = {item.outcome for item in request.transitions}
    if outcomes <= _UNSUPPORTED_TRANSITION_OUTCOMES:
        return _unavailable(
            "cross_page_continuity",
            state="UNSUPPORTED",
            reason="DOCUMENT_TABLE_TRANSITION_UNSUPPORTED",
            evidence=evidence,
        )
    if outcomes & _UNSUPPORTED_TRANSITION_OUTCOMES:
        return _unavailable(
            "cross_page_continuity",
            state="INCOMPARABLE",
            reason="DOCUMENT_TABLE_TRANSITION_MIXED_SUPPORT",
            evidence=evidence,
        )
    hard_differences = tuple(
        "hard_difference:COLUMN_TOPOLOGY"
        for item in request.transition_fingerprints
        if item.column_continuity.topology_hard_difference
    )
    repeated = sum(len(item.repeated_header_mappings) for item in request.transitions)
    split = sum(len(item.row_fragment_links) for item in request.transitions)
    ambiguous = sum(
        item.outcome in _AMBIGUOUS_TRANSITION_OUTCOMES for item in request.transitions
    )
    categories = _categorical(
        (f"transition_count:{len(request.transitions)}",),
        tuple(f"continuity_outcome:{item}" for item in outcomes),
        (f"repeated_header_evidence_count:{repeated}",),
        (f"split_row_evidence_count:{split}",),
        (f"ambiguous_transition_count:{ambiguous}",),
        tuple(
            f"fingerprint_state:{item.state}"
            for item in request.transition_fingerprints
        ),
        hard_differences,
    )
    numeric = _numeric(
        value
        for item in request.transitions
        for value in (
            item.page_boundary_evidence_strength,
            item.fingerprint_support_strength,
        )
        if value is not None
    )
    return _available(
        "cross_page_continuity",
        categorical_values=categories,
        numeric_values=numeric,
        evidence=evidence,
    )


def _warning_codes(request: PdfFamilyUpstreamBundle) -> tuple[str, ...]:
    values = tuple(
        warning.code.value
        for page in request.page_layout.pages
        for warning in page.warnings
    ) + tuple(warning.code.value for warning in request.page_layout.warnings)
    return _categorical(values)


def _limitation_codes(request: PdfFamilyUpstreamBundle) -> tuple[str, ...]:
    values = (
        request.reading_authority.limitation_codes
        + tuple(
            code
            for item in request.reading_page_evidence
            for code in item.limitation_codes
        )
        + tuple(
            code
            for item in request.reading_structures
            for code in item.limitation_codes
        )
        + request.page_table_manifest.limitation_codes
        + tuple(code for item in request.page_tables for code in item.limitation_codes)
        + tuple(code for item in request.transitions for code in item.limitation_codes)
        + tuple(
            code for item in request.document_tables for code in item.limitation_codes
        )
        + tuple(
            code
            for item in request.transition_fingerprints
            for code in item.limitation_codes
        )
        + (
            ()
            if request.document_table_manifest is None
            else request.document_table_manifest.limitation_codes
        )
    )
    return _categorical(values)


def _upstream_statuses(request: PdfFamilyUpstreamBundle) -> tuple[str, ...]:
    return _categorical(
        (request.page_layout.build_status.value.upper(),),
        (request.reading_authority.state.upper(),),
        tuple(item.state.upper() for item in request.reading_page_evidence),
        tuple(item.state.upper() for item in request.reading_structures),
        tuple(item.outcome for item in request.page_tables),
        (request.document_table_state,),
        tuple(item.status for item in request.document_tables),
        tuple(item.state for item in request.transition_fingerprints),
    )


def _evidence_safety_group(
    request: PdfFamilyUpstreamBundle,
    *,
    warnings: tuple[str, ...],
    limitations: tuple[str, ...],
    evidence: tuple[PdfFamilyArtifactReference, ...],
) -> PdfFamilyFeatureGroup:
    categories = _categorical(
        tuple(f"upstream_state:{item}" for item in _upstream_statuses(request)),
        tuple(f"warning_code:{item}" for item in warnings),
        tuple(f"limitation_code:{item}" for item in limitations),
        tuple(
            "fingerprint_dependency:CURRENT"
            for _item in request.transition_fingerprints
        ),
        ("fingerprint_dependency:NONE",) if not request.transition_fingerprints else (),
        tuple(
            f"fingerprint_state:{item.state}"
            for item in request.transition_fingerprints
        ),
        (
            f"authority_version:{CURRENT_ARTIFACT_AUTHORITY_VERSION}",
            "projection_determinism:CANONICAL",
        ),
    )
    return _available(
        "evidence_safety",
        categorical_values=categories,
        numeric_values=(),
        evidence=evidence,
    )


def _source_artifacts(
    request: PdfFamilyUpstreamBundle,
) -> tuple[
    tuple[PdfFamilyArtifactReference, ...],
    tuple[PdfFamilyArtifactReference, ...],
    tuple[PdfFamilyArtifactReference, ...],
]:
    layout_evidence = (
        _artifact(
            "PAGE_LAYOUT",
            "PAGE_LAYOUT_AUTHORITY",
            request.page_layout.layout_graph_id,
            request.page_layout.graph_digest,
        ),
        _artifact(
            "PAGE_LAYOUT",
            "READING_STRUCTURE_AUTHORITY",
            request.reading_authority.manifest_id,
            canonical_sha256(
                {
                    "domain": "document_sdk.pdf.phase3.family.reading_authority.v1",
                    "manifest_id": request.reading_authority.manifest_id,
                    "source_sha256": request.reading_authority.source_sha256,
                    "state": request.reading_authority.state,
                    "page_references": tuple(
                        (
                            item.page_index,
                            item.page_id,
                            item.sidecar_id,
                            item.structural_page_sha256,
                        )
                        for item in request.reading_authority.page_references
                    ),
                    "limitation_codes": request.reading_authority.limitation_codes,
                }
            ),
        ),
        *tuple(
            _artifact(
                "PAGE_LAYOUT",
                "READING_STRUCTURE_AUTHORITY",
                item.sidecar_id,
                _reading_digest(item),
            )
            for item in request.reading_structures
        ),
        *tuple(
            _artifact(
                "PAGE_LAYOUT",
                "READING_STRUCTURE_AUTHORITY",
                item.sidecar_id,
                _reference_digest(item),
            )
            for item in request.reading_structure_references
            if item.sidecar_id
            not in {structure.sidecar_id for structure in request.reading_structures}
        ),
    )
    page_table_evidence = (
        _artifact(
            "PAGE_TABLE",
            "PAGE_TABLE_AUTHORITY",
            request.page_table_manifest.manifest_id,
            request.page_table_manifest.page_table_manifest_sha256,
        ),
        *tuple(
            _artifact(
                "PAGE_TABLE",
                "PAGE_TABLE_AUTHORITY",
                item.sidecar_id,
                _page_table_digest(item),
            )
            for item in request.page_tables
        ),
    )
    document_evidence: tuple[PdfFamilyArtifactReference, ...] = ()
    if request.document_table_manifest is not None:
        document_evidence += (
            _artifact(
                "DOCUMENT_TABLE",
                "DOCUMENT_TABLE_MANIFEST",
                request.document_table_manifest.manifest_id,
                _document_manifest_digest(request.document_table_manifest),
            ),
        )
    document_evidence += tuple(
        _artifact(
            "DOCUMENT_TABLE",
            "DOCUMENT_TABLE_TRANSITION",
            item.transition_id,
            _transition_digest(item),
        )
        for item in request.transitions
    )
    document_evidence += tuple(
        _artifact(
            "DOCUMENT_TABLE",
            "DOCUMENT_TABLE_FINGERPRINT",
            item.fingerprint_id,
            _fingerprint_digest(item),
        )
        for item in request.transition_fingerprints
    )
    return (
        tuple(sorted(set(layout_evidence), key=_evidence_key)),
        tuple(sorted(set(page_table_evidence), key=_evidence_key)),
        tuple(sorted(set(document_evidence), key=_evidence_key)),
    )


def _validate_output_limits(
    *,
    request: PdfFamilyUpstreamBundle,
    source_artifacts: tuple[PdfFamilyArtifactReference, ...],
    feature_groups: tuple[PdfFamilyFeatureGroup, ...],
) -> None:
    limits = request.limits
    if len(source_artifacts) > limits.maximum_evidence_references or any(
        len(item.categorical_values) > limits.maximum_categorical_values_per_group
        or len(item.numeric_values) > limits.maximum_numeric_values_per_group
        for item in feature_groups
    ):
        raise ValueError(_LIMIT_ERROR)


def project_current_artifacts(
    request: PdfFamilyUpstreamBundle,
) -> ProjectedCurrentArtifactFeatures:
    canonical = validate_current_artifact_request(request)
    layout_evidence, table_evidence, document_evidence = _source_artifacts(canonical)
    source_artifacts = tuple(
        sorted(
            set(layout_evidence + table_evidence + document_evidence),
            key=_evidence_key,
        )
    )
    warnings = _warning_codes(canonical)
    limitations = _limitation_codes(canonical)
    table_layout = _table_layout_group(canonical, table_evidence)
    feature_groups = (
        _page_layout_group(canonical, layout_evidence),
        table_layout,
        _column_topology_group(canonical, table_layout, table_evidence),
        _header_topology_group(canonical, table_layout, table_evidence),
        _row_cell_structure_group(canonical, table_layout, table_evidence),
        _continuity_group(canonical, document_evidence),
        _unavailable(
            "canonical_export_outcome",
            state="MISSING",
            reason="CANONICAL_EXPORT_NOT_AVAILABLE",
        ),
        _evidence_safety_group(
            canonical,
            warnings=warnings,
            limitations=limitations,
            evidence=source_artifacts,
        ),
    )
    _validate_output_limits(
        request=canonical,
        source_artifacts=source_artifacts,
        feature_groups=feature_groups,
    )
    projection_input_identity = canonical_sha256(
        {
            "domain": PROJECTION_INPUT_IDENTITY_DOMAIN,
            "authority_version": canonical.authority_version,
            "family_scope_identity": canonical.family_scope_identity,
            "document_identity": canonical.document_identity,
            "source_sha256": canonical.source_sha256,
            "source_artifacts": tuple(_evidence_key(item) for item in source_artifacts),
            "document_table_state": canonical.document_table_state,
            "canonical_export_state": canonical.canonical_export_state,
            "limits": canonical.limits,
        }
    )
    return ProjectedCurrentArtifactFeatures(
        request=canonical,
        projection_input_identity=projection_input_identity,
        source_artifacts=source_artifacts,
        feature_groups=feature_groups,
        upstream_statuses=_upstream_statuses(canonical),
        warning_codes=warnings,
        limitation_codes=limitations,
    )

"""Deterministic private contracts for normalized document-family profiles."""

from __future__ import annotations

from typing import Any, Literal, TypeVar

from pydantic import BaseModel, ConfigDict, Field, model_validator

from document_sdk.pdf._structural_engine.structure.identity import canonical_sha256

PROFILE_VERSION: Literal["document_sdk_pdf_document_family_feature_profile.v1"] = (
    "document_sdk_pdf_document_family_feature_profile.v1"
)
COMPARISON_VERSION: Literal["document_sdk_pdf_document_family_comparison.v1"] = (
    "document_sdk_pdf_document_family_comparison.v1"
)
DISCOVERY_POLICY_VERSION: Literal["document_sdk.pdf.phase3.family.discovery.v1"] = (
    "document_sdk.pdf.phase3.family.discovery.v1"
)
REPORT_VERSION: Literal["document_sdk_pdf_document_family_discovery_report.v1"] = (
    "document_sdk_pdf_document_family_discovery_report.v1"
)

PdfFamilyFeatureName = Literal[
    "page_layout",
    "table_layout",
    "column_topology",
    "header_topology",
    "row_cell_structure",
    "cross_page_continuity",
    "canonical_export_outcome",
    "evidence_safety",
]
FEATURE_ORDER: tuple[PdfFamilyFeatureName, ...] = (
    "page_layout",
    "table_layout",
    "column_topology",
    "header_topology",
    "row_cell_structure",
    "cross_page_continuity",
    "canonical_export_outcome",
    "evidence_safety",
)
PdfFamilyFeatureState = Literal["AVAILABLE", "MISSING", "INCOMPARABLE", "UNSUPPORTED"]
PdfFamilyComparisonRelation = Literal[
    "SAME_FAMILY_PROVEN",
    "SAME_FAMILY_WITH_DRIFT",
    "DISTINCT_FAMILY_PROVEN",
    "AMBIGUOUS_RELATION",
    "INCOMPARABLE",
    "INSUFFICIENT_EVIDENCE",
]
PdfFamilyMembershipStatus = Literal[
    "PROVEN_MEMBER",
    "DRIFTED_MEMBER",
    "AMBIGUOUS_MEMBER",
    "UNASSIGNED",
    "INCOMPARABLE",
]
PdfDocumentCompatibilityResult = Literal[
    "COMPATIBLE",
    "CONDITIONALLY_COMPATIBLE",
    "UNKNOWN_COMPATIBILITY",
    "INCOMPATIBLE",
    "UNSUPPORTED_UPSTREAM",
]
PdfFamilyArtifactKind = Literal[
    "PAGE_LAYOUT", "PAGE_TABLE", "DOCUMENT_TABLE", "CANONICAL_EXPORT"
]

_IDENTITY_DOMAINS = {
    "profile-semantic": "document_sdk.pdf.phase3.family.profile_semantic.v1",
    "profile": "document_sdk.pdf.phase3.family.profile.v1",
    "comparison": "document_sdk.pdf.phase3.family.comparison.v1",
    "family": "document_sdk.pdf.phase3.family.candidate.v1",
    "drift": "document_sdk.pdf.phase3.family.drift.v1",
    "membership": "document_sdk.pdf.phase3.family.membership.v1",
    "compatibility": "document_sdk.pdf.phase3.family.compatibility.v1",
    "report": "document_sdk.pdf.phase3.family.report.v1",
}
_MINIMUM_FAMILY_MEMBERS = 2
_MINIMUM_CONFLICTING_FAMILIES = 2


class _FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)


def phase3f_identifier(kind: str, payload: object) -> str:
    try:
        domain = _IDENTITY_DOMAINS[kind]
    except KeyError:
        msg = "unsupported document-family identity kind"
        raise ValueError(msg) from None
    return f"P3F-{kind}-" + canonical_sha256({"domain": domain, "payload": payload})


def _sorted_unique(values: tuple[str, ...], *, label: str) -> None:
    if values != tuple(sorted(set(values))):
        msg = f"{label} must be sorted and unique"
        raise ValueError(msg)


ModelT = TypeVar("ModelT", bound=BaseModel)


def _identified[ModelT: BaseModel](
    model: type[ModelT],
    *,
    field: str,
    kind: str,
    values: dict[str, Any],
) -> ModelT:
    draft_values = dict(values)
    draft_values[field] = phase3f_identifier(kind, {"draft": True})
    draft = model.model_construct(**draft_values)
    payload = draft.model_dump(exclude={field})
    payload[field] = phase3f_identifier(kind, payload)
    return model.model_validate(payload)


class PdfFamilyDiscoveryLimits(_FrozenModel):
    maximum_profiles: int = Field(ge=1)
    maximum_pairwise_comparisons: int = Field(ge=1)


class PdfFamilyArtifactReference(_FrozenModel):
    artifact_kind: PdfFamilyArtifactKind
    role: str = Field(min_length=1, max_length=96)
    artifact_id: str = Field(min_length=1, max_length=180)
    sha256: str = Field(pattern=r"^[0-9a-f]{64}$")


class PdfFamilyFeatureGroup(_FrozenModel):
    name: PdfFamilyFeatureName
    state: PdfFamilyFeatureState
    categorical_values: tuple[str, ...] = ()
    numeric_values: tuple[float, ...] = ()
    evidence: tuple[PdfFamilyArtifactReference, ...] = ()
    reason_codes: tuple[str, ...] = ()
    structural_signature: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )

    @model_validator(mode="after")
    def validate_group(self) -> PdfFamilyFeatureGroup:
        _sorted_unique(self.categorical_values, label="feature categorical values")
        _sorted_unique(self.reason_codes, label="feature reason codes")
        evidence_order = tuple(
            (item.artifact_kind, item.role, item.artifact_id, item.sha256)
            for item in self.evidence
        )
        if evidence_order != tuple(sorted(set(evidence_order))):
            msg = "feature evidence must be ordered and unique"
            raise ValueError(msg)
        if self.state == "AVAILABLE":
            if (
                not (self.categorical_values or self.numeric_values)
                or not self.evidence
                or self.reason_codes
                or self.structural_signature is None
            ):
                msg = "available feature requires values, evidence, and signature"
                raise ValueError(msg)
            expected = canonical_sha256(
                {
                    "name": self.name,
                    "categorical_values": self.categorical_values,
                    "numeric_values": self.numeric_values,
                }
            )
            if self.structural_signature != expected:
                msg = "feature structural signature mismatch"
                raise ValueError(msg)
        elif (
            self.categorical_values
            or self.numeric_values
            or self.structural_signature is not None
            or not self.reason_codes
        ):
            msg = "unavailable feature must carry only evidence and reasons"
            raise ValueError(msg)
        return self


class DocumentFamilyFeatureProfile(_FrozenModel):
    schema_version: Literal["document_sdk_pdf_document_family_feature_profile.v1"] = (
        PROFILE_VERSION
    )
    profile_id: str = Field(pattern=r"^P3F-profile-[0-9a-f]{64}$")
    semantic_profile_identity: str = Field(
        pattern=r"^P3F-profile-semantic-[0-9a-f]{64}$"
    )
    family_scope_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    document_identity: str = Field(pattern=r"^P3D-document-[0-9a-f]{64}$")
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    source_artifacts: tuple[PdfFamilyArtifactReference, ...]
    feature_groups: tuple[PdfFamilyFeatureGroup, ...]
    upstream_statuses: tuple[str, ...]
    warning_codes: tuple[str, ...] = ()
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_profile(self) -> DocumentFamilyFeatureProfile:
        if tuple(item.name for item in self.feature_groups) != FEATURE_ORDER:
            msg = "document-family feature groups are incomplete or unordered"
            raise ValueError(msg)
        for values, label in (
            (self.upstream_statuses, "upstream statuses"),
            (self.warning_codes, "warning codes"),
            (self.limitation_codes, "limitation codes"),
        ):
            _sorted_unique(values, label=label)
        artifact_order = tuple(
            (item.artifact_kind, item.role, item.artifact_id, item.sha256)
            for item in self.source_artifacts
        )
        if not artifact_order or artifact_order != tuple(sorted(set(artifact_order))):
            msg = "profile source artifacts must be nonempty, ordered, and unique"
            raise ValueError(msg)
        semantic_payload = tuple(
            (
                item.name,
                item.state,
                item.categorical_values,
                item.numeric_values,
                item.reason_codes,
                item.structural_signature,
            )
            for item in self.feature_groups
        )
        expected_semantic = phase3f_identifier(
            "profile-semantic",
            semantic_payload,
        )
        if self.semantic_profile_identity != expected_semantic:
            msg = "document-family semantic profile identity mismatch"
            raise ValueError(msg)
        expected = phase3f_identifier(
            "profile",
            self.model_dump(exclude={"profile_id"}),
        )
        if self.profile_id != expected:
            msg = "document-family profile identity mismatch"
            raise ValueError(msg)
        return self


class PdfFamilyFeatureComparison(_FrozenModel):
    name: PdfFamilyFeatureName
    state: Literal["COMPARABLE", "INCOMPARABLE", "MISSING", "UNSUPPORTED"]
    similarity: float | None = Field(default=None, ge=0, le=1)
    exact_match: bool | None = None
    hard_incompatibility: bool
    explanation_codes: tuple[str, ...]
    evidence: tuple[PdfFamilyArtifactReference, ...]

    @model_validator(mode="after")
    def validate_result(self) -> PdfFamilyFeatureComparison:
        _sorted_unique(
            self.explanation_codes,
            label="feature comparison explanations",
        )
        if self.state == "COMPARABLE":
            if self.similarity is None or self.exact_match is None:
                msg = "comparable feature requires similarity and exact result"
                raise ValueError(msg)
        elif self.similarity is not None or self.exact_match is not None:
            msg = "non-comparable feature cannot claim similarity"
            raise ValueError(msg)
        if self.hard_incompatibility and self.state != "COMPARABLE":
            msg = "hard incompatibility requires comparable evidence"
            raise ValueError(msg)
        return self


class DocumentFamilyComparison(_FrozenModel):
    schema_version: Literal["document_sdk_pdf_document_family_comparison.v1"] = (
        COMPARISON_VERSION
    )
    comparison_id: str = Field(pattern=r"^P3F-comparison-[0-9a-f]{64}$")
    family_scope_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    left_document_identity: str = Field(pattern=r"^P3D-document-[0-9a-f]{64}$")
    right_document_identity: str = Field(pattern=r"^P3D-document-[0-9a-f]{64}$")
    left_profile_id: str = Field(pattern=r"^P3F-profile-[0-9a-f]{64}$")
    right_profile_id: str = Field(pattern=r"^P3F-profile-[0-9a-f]{64}$")
    group_results: tuple[PdfFamilyFeatureComparison, ...]
    hard_incompatibility_evidence: tuple[str, ...]
    missing_evidence: tuple[str, ...]
    relation: PdfFamilyComparisonRelation

    @model_validator(mode="after")
    def validate_comparison(self) -> DocumentFamilyComparison:
        if (self.left_document_identity, self.left_profile_id) > (
            self.right_document_identity,
            self.right_profile_id,
        ):
            msg = "comparison endpoints are not canonically ordered"
            raise ValueError(msg)
        if tuple(item.name for item in self.group_results) != FEATURE_ORDER:
            msg = "comparison groups are incomplete or unordered"
            raise ValueError(msg)
        _sorted_unique(
            self.hard_incompatibility_evidence,
            label="hard incompatibility evidence",
        )
        _sorted_unique(self.missing_evidence, label="missing evidence")
        if (
            self.relation == "DISTINCT_FAMILY_PROVEN"
            and not self.hard_incompatibility_evidence
        ):
            msg = "proven distinct relation requires hard evidence"
            raise ValueError(msg)
        if (
            self.relation.startswith("SAME_FAMILY")
            and self.hard_incompatibility_evidence
        ):
            msg = "same-family relation cannot retain hard incompatibility"
            raise ValueError(msg)
        expected = phase3f_identifier(
            "comparison",
            self.model_dump(exclude={"comparison_id"}),
        )
        if self.comparison_id != expected:
            msg = "document-family comparison identity mismatch"
            raise ValueError(msg)
        return self


class DocumentFamilyCandidate(_FrozenModel):
    family_id: str = Field(pattern=r"^P3F-family-[0-9a-f]{64}$")
    member_document_identities: tuple[str, ...]
    member_profile_ids: tuple[str, ...]
    representative_profile_id: str = Field(pattern=r"^P3F-profile-[0-9a-f]{64}$")
    intra_family_comparison_ids: tuple[str, ...]
    evidence_coverage: float = Field(ge=0, le=1)
    stability_state: Literal["STABLE", "DRIFT_PRESENT", "LIMITED_EVIDENCE"]
    warning_codes: tuple[str, ...] = ()
    limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_candidate(self) -> DocumentFamilyCandidate:
        for values, label in (
            (self.member_document_identities, "candidate member documents"),
            (self.member_profile_ids, "candidate member profiles"),
            (self.intra_family_comparison_ids, "candidate comparisons"),
            (self.warning_codes, "candidate warnings"),
            (self.limitation_codes, "candidate limitations"),
        ):
            _sorted_unique(values, label=label)
        if len(self.member_document_identities) < _MINIMUM_FAMILY_MEMBERS or len(
            self.member_document_identities
        ) != len(self.member_profile_ids):
            msg = "family candidate requires two distinct profiles"
            raise ValueError(msg)
        if self.representative_profile_id not in self.member_profile_ids:
            msg = "representative profile is not a family member"
            raise ValueError(msg)
        expected = phase3f_identifier(
            "family",
            {
                "policy": DISCOVERY_POLICY_VERSION,
                "member_profile_ids": self.member_profile_ids,
            },
        )
        if self.family_id != expected:
            msg = "document-family identity mismatch"
            raise ValueError(msg)
        return self


class DocumentLayoutDriftAssessment(_FrozenModel):
    drift_id: str = Field(pattern=r"^P3F-drift-[0-9a-f]{64}$")
    family_id: str = Field(pattern=r"^P3F-family-[0-9a-f]{64}$")
    baseline_profile_id: str = Field(pattern=r"^P3F-profile-[0-9a-f]{64}$")
    target_profile_id: str = Field(pattern=r"^P3F-profile-[0-9a-f]{64}$")
    changed_feature_groups: tuple[PdfFamilyFeatureName, ...]
    unchanged_feature_groups: tuple[PdfFamilyFeatureName, ...]
    incomparable_feature_groups: tuple[PdfFamilyFeatureName, ...]
    severity: Literal["NONE", "MINOR", "MATERIAL", "UNKNOWN"]
    safe_product_behavior: Literal[
        "UNCHANGED",
        "WARN_AND_PRESERVE",
        "REJECT_AS_INCOMPATIBLE",
        "TYPED_UNKNOWN",
    ]
    evidence_comparison_id: str = Field(pattern=r"^P3F-comparison-[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_drift(self) -> DocumentLayoutDriftAssessment:
        groups = (
            self.changed_feature_groups
            + self.unchanged_feature_groups
            + self.incomparable_feature_groups
        )
        if set(groups) != set(FEATURE_ORDER) or len(groups) != len(set(groups)):
            msg = "drift feature partitions are incomplete or overlapping"
            raise ValueError(msg)
        expected = phase3f_identifier(
            "drift",
            self.model_dump(exclude={"drift_id"}),
        )
        if self.drift_id != expected:
            msg = "document drift identity mismatch"
            raise ValueError(msg)
        return self


class DocumentFamilyMembership(_FrozenModel):
    membership_id: str = Field(pattern=r"^P3F-membership-[0-9a-f]{64}$")
    document_identity: str = Field(pattern=r"^P3D-document-[0-9a-f]{64}$")
    profile_id: str = Field(pattern=r"^P3F-profile-[0-9a-f]{64}$")
    family_id: str | None = Field(
        default=None,
        pattern=r"^P3F-family-[0-9a-f]{64}$",
    )
    status: PdfFamilyMembershipStatus
    evidence_comparison_ids: tuple[str, ...]
    conflicting_family_ids: tuple[str, ...] = ()
    drift_id: str | None = Field(
        default=None,
        pattern=r"^P3F-drift-[0-9a-f]{64}$",
    )
    confidence_state: Literal["PROVEN", "DRIFTED", "AMBIGUOUS", "NONE", "INCOMPARABLE"]

    @model_validator(mode="after")
    def validate_membership(self) -> DocumentFamilyMembership:
        _sorted_unique(self.evidence_comparison_ids, label="membership evidence")
        _sorted_unique(self.conflicting_family_ids, label="conflicting families")
        if (
            self.status in {"PROVEN_MEMBER", "DRIFTED_MEMBER"}
            and self.family_id is None
        ):
            msg = "positive membership requires a family"
            raise ValueError(msg)
        if (
            self.status in {"UNASSIGNED", "INCOMPARABLE", "AMBIGUOUS_MEMBER"}
            and self.family_id is not None
        ):
            msg = "non-unique membership cannot select a family"
            raise ValueError(msg)
        if (
            self.status == "AMBIGUOUS_MEMBER"
            and len(self.conflicting_family_ids) < _MINIMUM_CONFLICTING_FAMILIES
        ):
            msg = "ambiguous membership requires competing families"
            raise ValueError(msg)
        expected = phase3f_identifier(
            "membership",
            self.model_dump(exclude={"membership_id"}),
        )
        if self.membership_id != expected:
            msg = "family membership identity mismatch"
            raise ValueError(msg)
        return self


class DocumentCompatibilityAssessment(_FrozenModel):
    assessment_id: str = Field(pattern=r"^P3F-compatibility-[0-9a-f]{64}$")
    target_document_identity: str = Field(pattern=r"^P3D-document-[0-9a-f]{64}$")
    target_profile_id: str = Field(pattern=r"^P3F-profile-[0-9a-f]{64}$")
    reference_family_id: str = Field(pattern=r"^P3F-family-[0-9a-f]{64}$")
    structural_compatibility: Literal["PROVEN", "DRIFTED", "INCOMPATIBLE", "UNKNOWN"]
    upstream_support_compatibility: Literal[
        "SUPPORTED", "LIMITED", "UNSUPPORTED", "UNKNOWN"
    ]
    export_compatibility: Literal[
        "SUPPORTED",
        "LOSSY_WITH_DECLARATION",
        "LIMITED",
        "UNSUPPORTED",
        "UNKNOWN",
    ]
    limitation_exposure: tuple[str, ...]
    expected_safe_product_behavior: Literal[
        "PROCESS",
        "PROCESS_WITH_WARNINGS",
        "TYPED_UNKNOWN",
        "REJECT_INCOMPATIBLE",
        "REJECT_UNSUPPORTED",
    ]
    result: PdfDocumentCompatibilityResult
    evidence_comparison_id: str = Field(pattern=r"^P3F-comparison-[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_assessment(self) -> DocumentCompatibilityAssessment:
        _sorted_unique(
            self.limitation_exposure,
            label="compatibility limitations",
        )
        if self.result == "COMPATIBLE" and (
            self.structural_compatibility != "PROVEN"
            or self.upstream_support_compatibility != "SUPPORTED"
            or self.export_compatibility not in {"SUPPORTED", "LOSSY_WITH_DECLARATION"}
        ):
            msg = "compatible result upgrades incomplete evidence"
            raise ValueError(msg)
        if (
            self.result == "UNSUPPORTED_UPSTREAM"
            and self.upstream_support_compatibility != "UNSUPPORTED"
        ):
            msg = "unsupported result requires unsupported upstream"
            raise ValueError(msg)
        expected = phase3f_identifier(
            "compatibility",
            self.model_dump(exclude={"assessment_id"}),
        )
        if self.assessment_id != expected:
            msg = "compatibility assessment identity mismatch"
            raise ValueError(msg)
        return self


class DocumentFamilyDiscoveryReport(_FrozenModel):
    schema_version: Literal["document_sdk_pdf_document_family_discovery_report.v1"] = (
        REPORT_VERSION
    )
    report_id: str = Field(pattern=r"^P3F-report-[0-9a-f]{64}$")
    corpus_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    discovery_policy_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    family_scope_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    profiles: tuple[DocumentFamilyFeatureProfile, ...]
    comparisons: tuple[DocumentFamilyComparison, ...]
    candidates: tuple[DocumentFamilyCandidate, ...]
    memberships: tuple[DocumentFamilyMembership, ...]
    drift_assessments: tuple[DocumentLayoutDriftAssessment, ...]
    compatibility_assessments: tuple[DocumentCompatibilityAssessment, ...]
    unassigned_document_identities: tuple[str, ...]
    incomparable_document_identities: tuple[str, ...]
    ambiguous_document_identities: tuple[str, ...]
    safety_codes: tuple[str, ...]

    @model_validator(mode="after")
    def validate_report(self) -> DocumentFamilyDiscoveryReport:
        for values, label in (
            (self.unassigned_document_identities, "unassigned documents"),
            (self.incomparable_document_identities, "incomparable documents"),
            (self.ambiguous_document_identities, "ambiguous documents"),
            (self.safety_codes, "safety codes"),
        ):
            _sorted_unique(values, label=label)
        profile_order = tuple(
            (item.document_identity, item.profile_id) for item in self.profiles
        )
        if profile_order != tuple(sorted(set(profile_order))):
            msg = "report profiles are unordered or duplicated"
            raise ValueError(msg)
        if any(
            item.family_scope_identity != self.family_scope_identity
            for item in self.profiles
        ):
            msg = "family report crosses scope boundary"
            raise ValueError(msg)
        comparison_order = tuple(item.comparison_id for item in self.comparisons)
        if comparison_order != tuple(sorted(set(comparison_order))):
            msg = "report comparisons are unordered or duplicated"
            raise ValueError(msg)
        candidate_order = tuple(item.family_id for item in self.candidates)
        if candidate_order != tuple(sorted(set(candidate_order))):
            msg = "report candidates are unordered or duplicated"
            raise ValueError(msg)
        expected_corpus = canonical_sha256(profile_order)
        if self.corpus_identity != expected_corpus:
            msg = "family corpus identity mismatch"
            raise ValueError(msg)
        expected_policy = canonical_sha256({"policy_version": DISCOVERY_POLICY_VERSION})
        if self.discovery_policy_identity != expected_policy:
            msg = "family discovery policy identity mismatch"
            raise ValueError(msg)
        expected = phase3f_identifier(
            "report",
            self.model_dump(exclude={"report_id"}),
        )
        if self.report_id != expected:
            msg = "family discovery report identity mismatch"
            raise ValueError(msg)
        return self


def build_feature_group(**values: Any) -> PdfFamilyFeatureGroup:
    if values.get("state") == "AVAILABLE":
        values["structural_signature"] = canonical_sha256(
            {
                "name": values["name"],
                "categorical_values": values.get("categorical_values", ()),
                "numeric_values": values.get("numeric_values", ()),
            }
        )
    return PdfFamilyFeatureGroup.model_validate(values)


def build_profile(**values: Any) -> DocumentFamilyFeatureProfile:
    semantic_payload = tuple(
        (
            item.name,
            item.state,
            item.categorical_values,
            item.numeric_values,
            item.reason_codes,
            item.structural_signature,
        )
        for item in values["feature_groups"]
    )
    values["semantic_profile_identity"] = phase3f_identifier(
        "profile-semantic",
        semantic_payload,
    )
    return _identified(
        DocumentFamilyFeatureProfile,
        field="profile_id",
        kind="profile",
        values=values,
    )


def build_comparison(**values: Any) -> DocumentFamilyComparison:
    return _identified(
        DocumentFamilyComparison,
        field="comparison_id",
        kind="comparison",
        values=values,
    )


def build_drift(**values: Any) -> DocumentLayoutDriftAssessment:
    return _identified(
        DocumentLayoutDriftAssessment,
        field="drift_id",
        kind="drift",
        values=values,
    )


def build_membership(**values: Any) -> DocumentFamilyMembership:
    return _identified(
        DocumentFamilyMembership,
        field="membership_id",
        kind="membership",
        values=values,
    )


def build_compatibility(**values: Any) -> DocumentCompatibilityAssessment:
    return _identified(
        DocumentCompatibilityAssessment,
        field="assessment_id",
        kind="compatibility",
        values=values,
    )


def build_report(**values: Any) -> DocumentFamilyDiscoveryReport:
    return _identified(
        DocumentFamilyDiscoveryReport,
        field="report_id",
        kind="report",
        values=values,
    )

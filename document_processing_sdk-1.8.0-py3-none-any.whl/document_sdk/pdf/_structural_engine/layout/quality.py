# ruff: noqa: PLR0913, PLR2004

from collections.abc import Mapping, Sequence
from typing import Literal

from document_sdk.pdf._structural_engine.facts.contracts import PdfPageFacts
from document_sdk.pdf._structural_engine.facts.status import PdfExtractionStatus
from document_sdk.pdf._structural_engine.layout.contracts import (
    PdfLayoutEdge,
    PdfLayoutEmptyPageClassification,
    PdfLayoutNode,
    PdfLayoutPageQualitySignals,
    PdfLayoutParserQualitySummary,
    PdfLayoutTextLayerSelection,
    finite_ratio,
)


def build_page_quality_signals(
    *,
    page: PdfPageFacts,
    nodes: Sequence[PdfLayoutNode],
    edges: Sequence[PdfLayoutEdge],
    text_length_by_node_id: Mapping[str, int],
    text_layer_selection: PdfLayoutTextLayerSelection,
    source_fact_count: int,
    eligible_fact_count: int,
    invalid_geometry_count: int,
    resource_truncation: bool,
    source_document_partial: bool,
    source_warning_count: int,
    text_bbox_quality: Literal["unavailable", "anchor", "precise"],
    drawing_bbox_quality: Literal["unavailable", "approximate", "precise"],
) -> PdfLayoutPageQualitySignals:
    node_count = len(nodes)
    text_lengths = tuple(text_length_by_node_id.values())
    single_character_count = sum(length == 1 for length in text_lengths)
    fragmented_count = sum(length <= 2 for length in text_lengths)
    overlap_node_ids = {
        node_id
        for edge in edges
        if edge.relation_type == "overlaps"
        for node_id in (edge.source_node_id, edge.target_node_id)
    }
    connected_node_ids = {
        node_id
        for edge in edges
        for node_id in (edge.source_node_id, edge.target_node_id)
    }
    geometry_denominator = eligible_fact_count
    source_page_partial = page.extraction_status is not PdfExtractionStatus.SUCCESS
    source_incomplete = (
        source_page_partial or text_layer_selection.selected_layer_incomplete
    )
    empty_page_classification = _empty_page_classification(
        source_fact_count=source_fact_count,
        eligible_fact_count=eligible_fact_count,
        node_count=node_count,
        invalid_geometry_count=invalid_geometry_count,
        source_incomplete=source_incomplete,
    )
    if eligible_fact_count:
        node_retention_completeness = finite_ratio(
            node_count,
            eligible_fact_count,
        )
        fact_geometry_validity = 1 - finite_ratio(
            invalid_geometry_count,
            geometry_denominator,
        )
    elif empty_page_classification == "truly_empty":
        node_retention_completeness = 1.0
        fact_geometry_validity = 1.0
    else:
        node_retention_completeness = 0.0
        fact_geometry_validity = 0.0
    page_geometry_weight = {
        "complete": 1.0,
        "partial": 0.75,
        "assumed": 0.5,
    }[page.coordinate_transform.geometry_completeness]
    source_geometry_completeness = fact_geometry_validity * page_geometry_weight
    text_coverage = text_layer_selection.combined_text_coverage_ratio
    if text_coverage is None:
        text_coverage = text_layer_selection.selected_layer_coverage_ratio
    if text_coverage is None:
        text_coverage = (
            1.0 if empty_page_classification in {"truly_empty", "not_empty"} else 0.0
        )
    graph_completeness = (
        0.45 * node_retention_completeness
        + 0.35 * text_coverage
        + 0.20 * source_geometry_completeness
    )
    spatial_text_conflict_ratio = (
        text_layer_selection.selected_spatial_text_conflict_ratio or 0.0
    )
    graph_completeness *= 1 - (0.15 * spatial_text_conflict_ratio)
    if text_layer_selection.selected_layer_incomplete:
        graph_completeness *= 0.8
    if resource_truncation:
        graph_completeness *= 0.85
    fragmentation = finite_ratio(fragmented_count, len(text_lengths))
    parser_geometry_weight = (
        1.0 if page.coordinate_transform.geometry_confidence == "high" else 0.75
    )
    truncation_weight = 0.7 if resource_truncation else 1.0
    spatial_duplicate_ratio = (
        text_layer_selection.selected_spatial_duplicate_ratio or 0.0
    )
    duplicate_quality_weight = 1 - (0.25 * spatial_duplicate_ratio)
    text_conflict_quality_weight = 1 - (0.40 * spatial_text_conflict_ratio)
    if empty_page_classification == "truly_empty":
        graph_confidence = parser_geometry_weight
    elif empty_page_classification == "source_incomplete" and not node_count:
        graph_confidence = 0.0
    else:
        graph_confidence = (
            0.65 * graph_completeness
            + 0.25 * source_geometry_completeness
            + 0.10 * (1 - fragmentation)
        ) * (
            parser_geometry_weight
            * truncation_weight
            * duplicate_quality_weight
            * text_conflict_quality_weight
        )
    page_area = max(page.canonical_width * page.canonical_height, 1.0)
    return PdfLayoutPageQualitySignals(
        node_density_per_10k_points=round((node_count / page_area) * 10_000, 6),
        edge_density_per_node=round(
            len(edges) / max(node_count, 1),
            6,
        ),
        text_fragmentation_ratio=round(fragmentation, 6),
        single_character_node_ratio=round(
            finite_ratio(single_character_count, len(text_lengths)),
            6,
        ),
        overlapping_node_ratio=round(
            finite_ratio(len(overlap_node_ids), node_count),
            6,
        ),
        invalid_geometry_ratio=round(
            finite_ratio(invalid_geometry_count, geometry_denominator),
            6,
        ),
        rotated_node_ratio=round(
            finite_ratio(
                sum(node.rotation not in (None, 0) for node in nodes),
                node_count,
            ),
            6,
        ),
        drawing_node_ratio=round(
            finite_ratio(
                sum(node.node_type == "drawing" for node in nodes),
                node_count,
            ),
            6,
        ),
        image_node_ratio=round(
            finite_ratio(
                sum(node.node_type == "image_region" for node in nodes),
                node_count,
            ),
            6,
        ),
        isolated_node_ratio=round(
            finite_ratio(node_count - len(connected_node_ids), node_count),
            6,
        ),
        resource_truncation=resource_truncation,
        node_retention_completeness=round(node_retention_completeness, 6),
        source_geometry_completeness=round(
            source_geometry_completeness,
            6,
        ),
        graph_completeness=round(graph_completeness, 6),
        graph_confidence=round(min(1.0, max(0.0, graph_confidence)), 6),
        empty_page_classification=empty_page_classification,
        text_layer_selection=text_layer_selection,
        parser_quality=PdfLayoutParserQualitySummary(
            source_extraction_status=page.extraction_status,
            source_partial_extraction=(source_document_partial or source_page_partial),
            source_document_partial=source_document_partial,
            source_page_partial=source_page_partial,
            source_warning_count=source_warning_count,
            geometry_completeness=(page.coordinate_transform.geometry_completeness),
            geometry_confidence=page.coordinate_transform.geometry_confidence,
            text_bbox_quality=text_bbox_quality,
            drawing_bbox_quality=drawing_bbox_quality,
        ),
    )


def _empty_page_classification(
    *,
    source_fact_count: int,
    eligible_fact_count: int,
    node_count: int,
    invalid_geometry_count: int,
    source_incomplete: bool,
) -> PdfLayoutEmptyPageClassification:
    if source_fact_count == 0:
        return "source_incomplete" if source_incomplete else "truly_empty"
    if eligible_fact_count == 0:
        return "no_eligible_facts"
    if node_count == 0 and invalid_geometry_count:
        return "geometry_unavailable"
    return "not_empty"

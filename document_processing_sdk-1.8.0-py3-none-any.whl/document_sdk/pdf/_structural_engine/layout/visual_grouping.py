# ruff: noqa: C901, D202, FBT003, I001, PLR0912, PLR0913, PLR0915, PLR2004, RUF005, TC001, TC003, UP046, UP047

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass
import math
from typing import Generic, TypeVar

from document_sdk.pdf._structural_engine.facts.contracts import PdfBoundingBox


T = TypeVar("T")


@dataclass(frozen=True)
class PdfVisualProjection:
    """A canonical visual bbox projected onto reading and cross axes."""

    primary_min: float
    primary_max: float
    primary_center: float
    cross_min: float
    cross_max: float
    cross_center: float


@dataclass(frozen=True)
class PdfVisualGroupSearchResult(Generic[T]):
    groups: tuple[tuple[T, ...], ...]
    expansion_count: int
    truncated: bool
    deadline_reached: bool


@dataclass(frozen=True)
class _BeamState(Generic[T]):
    indices: tuple[int, ...]
    skipped_count: int
    visible_length: int
    geometry_score: float
    identifier_key: tuple[str, ...]


def project_visual_bbox(
    bbox: PdfBoundingBox,
    *,
    rotation: float,
) -> PdfVisualProjection:
    """Project canonical y-down coordinates onto clockwise reading axes."""

    radians = math.radians(rotation % 360)
    primary_axis = (math.cos(radians), math.sin(radians))
    cross_axis = (-math.sin(radians), math.cos(radians))
    corners = (
        (bbox.x0, bbox.y0),
        (bbox.x0, bbox.y1),
        (bbox.x1, bbox.y0),
        (bbox.x1, bbox.y1),
    )
    primary_values = tuple(
        x * primary_axis[0] + y * primary_axis[1] for x, y in corners
    )
    cross_values = tuple(x * cross_axis[0] + y * cross_axis[1] for x, y in corners)
    primary_min = min(primary_values)
    primary_max = max(primary_values)
    cross_min = min(cross_values)
    cross_max = max(cross_values)
    return PdfVisualProjection(
        primary_min=primary_min,
        primary_max=primary_max,
        primary_center=(primary_min + primary_max) / 2,
        cross_min=cross_min,
        cross_max=cross_max,
        cross_center=(cross_min + cross_max) / 2,
    )


def visual_item_sort_key(
    *,
    bbox: PdfBoundingBox,
    rotation: float,
    source_order: int,
    identifier: str,
) -> tuple[float, float, int, str]:
    projection = project_visual_bbox(bbox, rotation=rotation)
    return (
        projection.primary_center,
        projection.cross_center,
        source_order,
        identifier,
    )


def visual_bboxes_are_neighbors(
    *,
    previous_bbox: PdfBoundingBox,
    previous_rotation: float | None,
    candidate_bbox: PdfBoundingBox,
    candidate_rotation: float | None,
    rotation: float,
    rotation_tolerance_degrees: float = 5.0,
    minimum_cross_overlap_ratio: float = 0.3,
    maximum_gap_points: float = 36.0,
    maximum_gap_scale: float = 4.0,
) -> bool:
    if (
        previous_rotation is not None
        and candidate_rotation is not None
        and circular_angle_delta(previous_rotation, candidate_rotation)
        > rotation_tolerance_degrees
    ):
        return False
    previous = project_visual_bbox(previous_bbox, rotation=rotation)
    candidate = project_visual_bbox(candidate_bbox, rotation=rotation)
    cross_overlap = max(
        0.0,
        min(previous.cross_max, candidate.cross_max)
        - max(previous.cross_min, candidate.cross_min),
    )
    cross_size = max(
        1e-6,
        min(
            previous.cross_max - previous.cross_min,
            candidate.cross_max - candidate.cross_min,
        ),
    )
    if cross_overlap / cross_size < minimum_cross_overlap_ratio:
        return False
    gap = candidate.primary_min - previous.primary_max
    scale = max(
        previous.cross_max - previous.cross_min,
        candidate.cross_max - candidate.cross_min,
        1.0,
    )
    return (
        -0.25 * scale
        <= gap
        <= max(
            maximum_gap_points,
            maximum_gap_scale * scale,
        )
    )


def bounded_visual_group_search(
    *,
    items: Sequence[T],
    rotation: float,
    bbox_of: Callable[[T], PdfBoundingBox],
    rotation_of: Callable[[T], float | None],
    source_order_of: Callable[[T], int],
    identifier_of: Callable[[T], str],
    visible_length_of: Callable[[T], int],
    expected_visible_lengths: Sequence[int],
    maximum_group_size: int,
    maximum_group_count: int,
    maximum_beam_width: int,
    maximum_expansions: int,
    maximum_skipped_visual_nodes: int,
    maximum_gap_points: float,
    deadline_reached: Callable[[], bool],
) -> PdfVisualGroupSearchResult[T]:
    """Enumerate bounded visual token paths without greedy successor loss."""

    if not items or maximum_group_size < 2:
        return PdfVisualGroupSearchResult((), 0, False, False)
    ordered = tuple(
        sorted(
            items,
            key=lambda item: visual_item_sort_key(
                bbox=bbox_of(item),
                rotation=rotation,
                source_order=source_order_of(item),
                identifier=identifier_of(item),
            ),
        )
    )
    maximum_expected_length = max(expected_visible_lengths, default=0)
    groups: list[tuple[T, ...]] = []
    seen_groups: set[tuple[str, ...]] = set()
    expansion_count = 0
    truncated = False
    deadline_hit = False

    for start_index, start in enumerate(ordered):
        if deadline_reached():
            deadline_hit = True
            truncated = True
            break
        initial_identifier = identifier_of(start)
        beam: list[_BeamState[T]] = [
            _BeamState(
                indices=(start_index,),
                skipped_count=0,
                visible_length=visible_length_of(start),
                geometry_score=0.0,
                identifier_key=(initial_identifier,),
            )
        ]
        for _depth in range(1, maximum_group_size):
            next_states: list[_BeamState[T]] = []
            for state in beam:
                last_index = state.indices[-1]
                last_item = ordered[last_index]
                remaining_skip_budget = (
                    maximum_skipped_visual_nodes - state.skipped_count
                )
                final_index = min(
                    len(ordered),
                    last_index + remaining_skip_budget + maximum_beam_width + 2,
                )
                for candidate_index in range(last_index + 1, final_index):
                    skipped = candidate_index - last_index - 1
                    if state.skipped_count + skipped > maximum_skipped_visual_nodes:
                        continue
                    expansion_count += 1
                    if expansion_count > maximum_expansions:
                        truncated = True
                        return PdfVisualGroupSearchResult(
                            tuple(groups),
                            expansion_count - 1,
                            truncated,
                            deadline_hit,
                        )
                    if deadline_reached():
                        deadline_hit = True
                        truncated = True
                        return PdfVisualGroupSearchResult(
                            tuple(groups),
                            expansion_count,
                            truncated,
                            deadline_hit,
                        )
                    candidate = ordered[candidate_index]
                    if not visual_bboxes_are_neighbors(
                        previous_bbox=bbox_of(last_item),
                        previous_rotation=rotation_of(last_item),
                        candidate_bbox=bbox_of(candidate),
                        candidate_rotation=rotation_of(candidate),
                        rotation=rotation,
                        maximum_gap_points=maximum_gap_points,
                    ):
                        continue
                    visible_length = state.visible_length + visible_length_of(candidate)
                    if (
                        maximum_expected_length
                        and visible_length > maximum_expected_length
                    ):
                        continue
                    previous_projection = project_visual_bbox(
                        bbox_of(last_item),
                        rotation=rotation,
                    )
                    candidate_projection = project_visual_bbox(
                        bbox_of(candidate),
                        rotation=rotation,
                    )
                    gap = max(
                        0.0,
                        candidate_projection.primary_min
                        - previous_projection.primary_max,
                    )
                    cross_delta = abs(
                        candidate_projection.cross_center
                        - previous_projection.cross_center
                    )
                    identifiers = state.identifier_key + (identifier_of(candidate),)
                    next_states.append(
                        _BeamState(
                            indices=state.indices + (candidate_index,),
                            skipped_count=state.skipped_count + skipped,
                            visible_length=visible_length,
                            geometry_score=(
                                state.geometry_score
                                + gap
                                + 0.25 * cross_delta
                                + skipped
                            ),
                            identifier_key=identifiers,
                        )
                    )
            if not next_states:
                break
            next_states.sort(
                key=lambda state: (
                    state.geometry_score,
                    state.skipped_count,
                    state.identifier_key,
                )
            )
            beam = next_states[:maximum_beam_width]
            for state in beam:
                if state.identifier_key in seen_groups:
                    continue
                seen_groups.add(state.identifier_key)
                groups.append(tuple(ordered[index] for index in state.indices))
                if len(groups) >= maximum_group_count:
                    truncated = bool(next_states or start_index + 1 < len(ordered))
                    return PdfVisualGroupSearchResult(
                        tuple(groups),
                        expansion_count,
                        truncated,
                        deadline_hit,
                    )
    return PdfVisualGroupSearchResult(
        tuple(groups),
        expansion_count,
        truncated,
        deadline_hit,
    )


def circular_angle_delta(first: float, second: float) -> float:
    difference = abs((first - second) % 360)
    return min(difference, 360 - difference)

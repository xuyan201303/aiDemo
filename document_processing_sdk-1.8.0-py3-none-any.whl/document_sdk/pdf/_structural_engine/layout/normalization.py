# ruff: noqa: D202, FBT003, I001, PLR0911, PLR0913, PLR2004

from bisect import bisect_left
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
import math
from time import perf_counter
from typing import Literal, cast
import unicodedata

from document_sdk.pdf._structural_engine.facts.capabilities import PdfParserCapabilities
from document_sdk.pdf._structural_engine.facts.contracts import (
    PdfDrawingFact,
    PdfFactArtifact,
    PdfFactConfidence,
    PdfImageRegionFact,
    PdfPageFacts,
    PdfTextFact,
)
from document_sdk.pdf._structural_engine.facts.status import (
    PdfExtractionStatus,
    PdfFactWarning,
    PdfWarningCode,
)
from document_sdk.pdf._structural_engine.layout.contracts import (
    PdfLayoutGeometryQuality,
    PdfLayoutNode,
    PdfLayoutNodeType,
    PdfLayoutSupplementalReason,
    PdfLayoutTextLayerRole,
    PdfLayoutTextLayerSelection,
    PdfLayoutTextLayerSelectionReason,
)
from document_sdk.pdf._structural_engine.layout.identifiers import (
    layout_node_identifier,
)
from document_sdk.pdf._structural_engine.layout.limits import (
    PdfLayoutGraphLimits,
    PdfLayoutGraphOptions,
    PdfLayoutTextNodePolicy,
)


LayoutSourceFact = PdfTextFact | PdfDrawingFact | PdfImageRegionFact
_SourceTextLayer = Literal["word", "text_span", "line_candidate"]
_NODE_TYPE_ORDER = {
    "line_candidate": 0,
    "word": 1,
    "text_span": 2,
    "drawing": 3,
    "image_region": 4,
}
_ASCII_INVISIBLE_TRANSLATION = {
    code_point: None
    for code_point in range(128)
    if chr(code_point).isspace()
    or unicodedata.category(chr(code_point)) in {"Cc", "Cf", "Cs"}
}


@dataclass(frozen=True)
class SelectedLayoutFact:
    fact: LayoutSourceFact
    node_type: PdfLayoutNodeType
    text_length: int | None = None
    text_layer_role: PdfLayoutTextLayerRole = "not_text"
    supplemental_reason: PdfLayoutSupplementalReason = "none"
    retain_zero_width_text_anchor: bool = False


@dataclass(frozen=True)
class PdfLayoutFactSelection:
    facts: tuple[SelectedLayoutFact, ...]
    text_layer_selection: PdfLayoutTextLayerSelection
    drawing_facts_by_id: Mapping[str, PdfDrawingFact]
    stage_timings: "PdfLayoutNormalizationStageTimings"


@dataclass(frozen=True)
class PdfLayoutNormalizationStageTimings:
    text_layer_metrics: float
    hard_duplicate_grouping: float
    spatial_conflict_analysis: float
    supplemental_gap_fill: float


@dataclass
class _NormalizationTimingAccumulator:
    hard_duplicate_grouping: float = 0.0
    spatial_conflict_analysis: float = 0.0


@dataclass(frozen=True)
class _TextLayerMetrics:
    layer: _SourceTextLayer
    raw_facts: tuple[PdfTextFact, ...]
    hard_deduplicated_facts: tuple[PdfTextFact, ...]
    facts: tuple[PdfTextFact, ...]
    excluded_blank_fact_count: int
    raw_non_whitespace_character_count: int
    hard_deduplicated_non_whitespace_character_count: int
    non_whitespace_character_count: int
    conflict_capped_non_whitespace_character_count: int
    valid_geometry_ratio: float
    geometry_quality_ratio: float
    single_character_ratio: float
    spatial_duplicate_occurrence_count: int
    spatial_duplicate_cluster_count: int
    spatial_duplicate_ratio: float
    repeated_text_ratio: float
    soft_equivalent_occurrence_count: int
    spatial_text_conflict_occurrence_count: int
    spatial_text_conflict_cluster_count: int
    spatial_text_conflict_ratio: float
    spatial_text_conflict_suppressed_occurrence_count: int
    incomplete: bool
    capability_available: bool


@dataclass
class _TextDuplicateCluster:
    representative: PdfTextFact
    occurrence_count: int = 1


@dataclass
class _TextSpatialCluster:
    facts: list[PdfTextFact]


@dataclass(frozen=True)
class _TextSpatialConflictResult:
    facts: tuple[PdfTextFact, ...]
    conflict_capped_non_whitespace_character_count: int
    repeated_text_ratio: float
    soft_equivalent_occurrence_count: int
    spatial_text_conflict_occurrence_count: int
    spatial_text_conflict_cluster_count: int
    suppressed_occurrence_count: int


@dataclass(frozen=True)
class _SupplementalTextSelection:
    layer: _SourceTextLayer | None
    facts: tuple[PdfTextFact, ...]
    non_whitespace_character_count: int
    missing_region_count: int
    conflict_count: int
    truncation_count: int
    scanned_fact_count: int
    fallback_incomplete: bool

    @property
    def source_fact_available_graph_missing_count(self) -> int:
        return max(0, self.missing_region_count - len(self.facts))


@dataclass(frozen=True)
class _PrimaryTextFactSpatialIndex:
    """Immutable center-bucket lookup for supplemental-to-primary matching."""

    facts: tuple[PdfTextFact, ...]
    indices_by_bucket: dict[tuple[int, int], tuple[int, ...]]
    bucket_size: float
    maximum_half_width: float
    maximum_half_height: float

    @classmethod
    def build(
        cls,
        *,
        facts: tuple[PdfTextFact, ...],
        options: PdfLayoutGraphOptions,
    ) -> "_PrimaryTextFactSpatialIndex":
        bucket_size = max(
            8.0,
            options.text_duplicate_center_tolerance_points * 4,
            options.text_duplicate_bbox_tolerance_points * 4,
        )
        grouped: dict[tuple[int, int], list[int]] = {}
        maximum_half_width = 0.0
        maximum_half_height = 0.0
        for fact_index, fact in enumerate(facts):
            grouped.setdefault(
                _text_duplicate_bucket_key(fact, bucket_size=bucket_size),
                [],
            ).append(fact_index)
            maximum_half_width = max(
                maximum_half_width,
                max(0.0, fact.bbox.x1 - fact.bbox.x0) / 2,
            )
            maximum_half_height = max(
                maximum_half_height,
                max(0.0, fact.bbox.y1 - fact.bbox.y0) / 2,
            )
        return cls(
            facts=facts,
            indices_by_bucket={
                key: tuple(indices) for key, indices in sorted(grouped.items())
            },
            bucket_size=bucket_size,
            maximum_half_width=maximum_half_width,
            maximum_half_height=maximum_half_height,
        )

    def candidates(
        self,
        candidate: PdfTextFact,
        *,
        options: PdfLayoutGraphOptions,
    ) -> tuple[PdfTextFact, ...]:
        """Return an exact-match superset in original deterministic fact order."""

        center_x, center_y = _text_bbox_center(candidate)
        center_tolerance = options.text_duplicate_center_tolerance_points
        minimum_column = math.floor(
            min(
                candidate.bbox.x0 - self.maximum_half_width,
                center_x - center_tolerance,
            )
            / self.bucket_size
        )
        maximum_column = math.floor(
            max(
                candidate.bbox.x1 + self.maximum_half_width,
                center_x + center_tolerance,
            )
            / self.bucket_size
        )
        minimum_row = math.floor(
            min(
                candidate.bbox.y0 - self.maximum_half_height,
                center_y - center_tolerance,
            )
            / self.bucket_size
        )
        maximum_row = math.floor(
            max(
                candidate.bbox.y1 + self.maximum_half_height,
                center_y + center_tolerance,
            )
            / self.bucket_size
        )
        bucket_span = (maximum_column - minimum_column + 1) * (
            maximum_row - minimum_row + 1
        )
        fact_indices: list[int] = []
        if bucket_span <= max(64, len(self.indices_by_bucket) * 2):
            for row in range(minimum_row, maximum_row + 1):
                for column in range(minimum_column, maximum_column + 1):
                    fact_indices.extend(self.indices_by_bucket.get((column, row), ()))
        else:
            # Avoid materializing a pathological coordinate range for an
            # unusually large canonical bbox while preserving the same lookup.
            for (column, row), indices in self.indices_by_bucket.items():
                if (
                    minimum_column <= column <= maximum_column
                    and minimum_row <= row <= maximum_row
                ):
                    fact_indices.extend(indices)
        fact_indices.sort()
        return tuple(self.facts[index] for index in fact_indices)


_TEXT_INCOMPLETE_WARNING_CODES = {
    PdfWarningCode.MALFORMED_TEXT_OBJECT,
    PdfWarningCode.PAGE_PARTIALLY_PARSED,
    PdfWarningCode.PARTIAL_PAGE_FAILURE,
    PdfWarningCode.TEXT_FACT_LIMIT_REACHED,
    PdfWarningCode.TOTAL_FACT_LIMIT_REACHED,
    PdfWarningCode.ARTIFACT_SIZE_LIMIT_REACHED,
    PdfWarningCode.EXTRACTION_TIMEOUT,
}


def select_page_layout_facts(
    *,
    page: PdfPageFacts,
    parser_capabilities: PdfParserCapabilities,
    artifact_warnings: Sequence[PdfFactWarning],
    options: PdfLayoutGraphOptions,
    limits: PdfLayoutGraphLimits,
) -> PdfLayoutFactSelection:
    text_metrics_started_at = perf_counter()
    timing_accumulator = _NormalizationTimingAccumulator()
    text_layers: dict[_SourceTextLayer, Sequence[PdfTextFact]] = {
        "word": page.words,
        "text_span": page.text_spans,
        "line_candidate": page.line_candidates,
    }
    policy_order = cast(
        "tuple[_SourceTextLayer, _SourceTextLayer, _SourceTextLayer]",
        {
            "prefer_words": ("word", "text_span", "line_candidate"),
            "prefer_text_spans": ("text_span", "word", "line_candidate"),
            "prefer_line_candidates": ("line_candidate", "word", "text_span"),
        }[options.text_node_policy],
    )
    coverage_text_by_value: dict[str, str] = {}
    soft_key_by_value: dict[str, str] = {}
    for facts in text_layers.values():
        for fact in facts:
            if fact.text in coverage_text_by_value:
                continue
            covered = _coverage_text(fact.text)
            coverage_text_by_value[fact.text] = covered
            soft_key_by_value[fact.text] = (
                covered if covered.isascii() else unicodedata.normalize("NFKC", covered)
            )
    page_incomplete = (
        page.extraction_status is not PdfExtractionStatus.SUCCESS
        or _has_incomplete_warning(page.warnings)
        or _has_relevant_artifact_warning(
            artifact_warnings,
            page_number=page.page_number,
        )
    )
    layer_metrics: dict[_SourceTextLayer, _TextLayerMetrics] = {
        layer: _text_layer_metrics(
            layer=layer,
            facts=tuple(text_layers[layer]),
            page_incomplete=page_incomplete,
            capability_available=_layer_capability(
                layer=layer,
                capabilities=parser_capabilities,
            ),
            text_bbox_quality=parser_capabilities.text_bbox_quality,
            options=options,
            limits=limits,
            coverage_text_by_value=coverage_text_by_value,
            soft_key_by_value=soft_key_by_value,
            timing_accumulator=timing_accumulator,
        )
        for layer in text_layers
    }
    text_metrics_total = (perf_counter() - text_metrics_started_at) * 1_000
    text_layer_metrics_elapsed = max(
        0.0,
        text_metrics_total
        - timing_accumulator.hard_duplicate_grouping
        - timing_accumulator.spatial_conflict_analysis,
    )
    best_character_count = max(
        (
            metrics.conflict_capped_non_whitespace_character_count
            for metrics in layer_metrics.values()
        ),
        default=0,
    )
    selected_metrics, selection_reason = _select_text_layer(
        policy_order=policy_order,
        layer_metrics=layer_metrics,
        best_character_count=best_character_count,
        options=options,
        limits=limits,
    )
    supplemental_started_at = perf_counter()
    retained_anchor_ids = _witnessed_zero_width_word_ids(
        selected_metrics=selected_metrics,
        layer_metrics=layer_metrics,
        limits=limits,
    )
    supplemental = _select_supplemental_text_facts(
        selected_metrics=selected_metrics,
        layer_metrics=layer_metrics,
        options=options,
        limits=limits,
    )
    supplemental_elapsed = (perf_counter() - supplemental_started_at) * 1_000
    if supplemental.facts and selected_metrics is not None:
        selection_reason = "preferred_with_supplemental_gap_fill"
    selected: list[SelectedLayoutFact] = []
    if selected_metrics is not None:
        selected.extend(
            SelectedLayoutFact(
                fact=fact,
                node_type=selected_metrics.layer,
                text_length=len(coverage_text_by_value[fact.text]),
                text_layer_role="primary",
                retain_zero_width_text_anchor=fact.fact_id in retained_anchor_ids,
            )
            for fact in selected_metrics.facts
        )
    if supplemental.layer is not None:
        selected.extend(
            SelectedLayoutFact(
                fact=fact,
                node_type=supplemental.layer,
                text_length=len(coverage_text_by_value[fact.text]),
                text_layer_role="supplemental",
                supplemental_reason="primary_coverage_gap",
            )
            for fact in supplemental.facts
        )
    drawing_facts_by_id: dict[str, PdfDrawingFact] = {}
    if options.include_drawings:
        # Build the separator lookup while materializing selected drawing
        # facts.  The builder previously walked the full drawing inventory a
        # second time solely to recreate this mapping on drawing-heavy pages.
        for drawing_fact in page.drawings:
            drawing_facts_by_id[drawing_fact.fact_id] = drawing_fact
            selected.append(SelectedLayoutFact(fact=drawing_fact, node_type="drawing"))
    if options.include_image_regions:
        selected.extend(
            SelectedLayoutFact(fact=image_fact, node_type="image_region")
            for image_fact in page.image_regions
        )
    selected.sort(key=_selected_fact_sort_key)
    return PdfLayoutFactSelection(
        facts=tuple(selected),
        text_layer_selection=_selection_contract(
            requested_policy=options.text_node_policy,
            selected_metrics=selected_metrics,
            selection_reason=selection_reason,
            layer_metrics=layer_metrics,
            best_character_count=best_character_count,
            options=options,
            supplemental=supplemental,
        ),
        drawing_facts_by_id=drawing_facts_by_id,
        stage_timings=PdfLayoutNormalizationStageTimings(
            text_layer_metrics=text_layer_metrics_elapsed,
            hard_duplicate_grouping=(timing_accumulator.hard_duplicate_grouping),
            spatial_conflict_analysis=(timing_accumulator.spatial_conflict_analysis),
            supplemental_gap_fill=supplemental_elapsed,
        ),
    )


def _text_layer_metrics(
    *,
    layer: _SourceTextLayer,
    facts: tuple[PdfTextFact, ...],
    page_incomplete: bool,
    capability_available: bool,
    text_bbox_quality: str,
    options: PdfLayoutGraphOptions,
    limits: PdfLayoutGraphLimits,
    coverage_text_by_value: Mapping[str, str] | None = None,
    soft_key_by_value: Mapping[str, str] | None = None,
    timing_accumulator: _NormalizationTimingAccumulator | None = None,
) -> _TextLayerMetrics:
    if coverage_text_by_value is None:
        coverage_text_by_value = {
            fact.text: _coverage_text(fact.text) for fact in facts
        }
    if soft_key_by_value is None:
        soft_key_by_value = {
            text: (
                covered if covered.isascii() else unicodedata.normalize("NFKC", covered)
            )
            for text, covered in coverage_text_by_value.items()
        }
    visible_facts = tuple(fact for fact in facts if coverage_text_by_value[fact.text])
    raw_coverage_texts = tuple(
        coverage_text_by_value[fact.text] for fact in visible_facts
    )
    hard_duplicate_started_at = perf_counter()
    hard_deduplicated_facts, duplicate_occurrences, duplicate_clusters = (
        _deduplicate_text_facts(
            facts=visible_facts,
            text_bbox_quality=text_bbox_quality,
            options=options,
        )
    )
    if timing_accumulator is not None:
        timing_accumulator.hard_duplicate_grouping += (
            perf_counter() - hard_duplicate_started_at
        ) * 1_000
    spatial_conflict_started_at = perf_counter()
    conflict_result = _analyze_spatial_text_conflicts(
        facts=hard_deduplicated_facts,
        text_bbox_quality=text_bbox_quality,
        options=options,
        max_alternatives_per_cluster=(limits.max_text_alternatives_per_spatial_cluster),
        coverage_text_by_value=coverage_text_by_value,
        soft_key_by_value=soft_key_by_value,
    )
    if timing_accumulator is not None:
        timing_accumulator.spatial_conflict_analysis += (
            perf_counter() - spatial_conflict_started_at
        ) * 1_000
    selected_facts = conflict_result.facts
    selected_coverage_texts = tuple(
        coverage_text_by_value[fact.text] for fact in selected_facts
    )
    valid_geometry_count = sum(
        _text_geometry_is_usable(fact) for fact in selected_facts
    )
    geometry_quality_total = sum(
        _text_geometry_quality_rank(
            fact,
            text_bbox_quality=text_bbox_quality,
        )
        for fact in selected_facts
    )
    selected_fact_count = len(selected_facts)
    visible_fact_count = len(visible_facts)
    hard_deduplicated_fact_count = len(hard_deduplicated_facts)
    return _TextLayerMetrics(
        layer=layer,
        raw_facts=facts,
        hard_deduplicated_facts=hard_deduplicated_facts,
        facts=selected_facts,
        excluded_blank_fact_count=len(facts) - visible_fact_count,
        raw_non_whitespace_character_count=sum(
            len(text) for text in raw_coverage_texts
        ),
        hard_deduplicated_non_whitespace_character_count=sum(
            len(coverage_text_by_value[fact.text]) for fact in hard_deduplicated_facts
        ),
        non_whitespace_character_count=sum(
            len(text) for text in selected_coverage_texts
        ),
        conflict_capped_non_whitespace_character_count=(
            conflict_result.conflict_capped_non_whitespace_character_count
        ),
        valid_geometry_ratio=(
            valid_geometry_count / selected_fact_count if selected_fact_count else 0.0
        ),
        geometry_quality_ratio=(
            geometry_quality_total / (selected_fact_count * 2)
            if selected_fact_count
            else 0.0
        ),
        single_character_ratio=(
            sum(len(text) == 1 for text in selected_coverage_texts)
            / selected_fact_count
            if selected_fact_count
            else 0.0
        ),
        spatial_duplicate_occurrence_count=duplicate_occurrences,
        spatial_duplicate_cluster_count=duplicate_clusters,
        spatial_duplicate_ratio=(
            duplicate_occurrences / visible_fact_count if visible_fact_count else 0.0
        ),
        repeated_text_ratio=conflict_result.repeated_text_ratio,
        soft_equivalent_occurrence_count=(
            conflict_result.soft_equivalent_occurrence_count
        ),
        spatial_text_conflict_occurrence_count=(
            conflict_result.spatial_text_conflict_occurrence_count
        ),
        spatial_text_conflict_cluster_count=(
            conflict_result.spatial_text_conflict_cluster_count
        ),
        spatial_text_conflict_ratio=(
            conflict_result.spatial_text_conflict_occurrence_count
            / hard_deduplicated_fact_count
            if hard_deduplicated_fact_count
            else 0.0
        ),
        spatial_text_conflict_suppressed_occurrence_count=(
            conflict_result.suppressed_occurrence_count
        ),
        incomplete=(
            page_incomplete
            or any(_has_incomplete_warning(fact.warnings) for fact in facts)
            or bool(conflict_result.suppressed_occurrence_count)
        ),
        capability_available=capability_available,
    )


def _complete_equivalent_geometry_layer(
    preferred: _TextLayerMetrics,
    policy_order: tuple[_SourceTextLayer, _SourceTextLayer, _SourceTextLayer],
    layer_metrics: dict[_SourceTextLayer, _TextLayerMetrics],
    limits: PdfLayoutGraphLimits,
) -> _TextLayerMetrics | None:
    # A word can retain real text but have unusable geometry (for example a
    # missing glyph advance in the backend's font metrics). Prefer an intact
    # larger text layer only for exact source-ordered fact text/boundaries and
    # unchanged valid geometry, or the strictly single-span projection below.
    # Multi-line pages retain their word granularity; a witnessed zero-width
    # word may instead remain an explicitly incomplete source anchor. Coverage
    # keys are deliberately lossy and cannot establish either equality. Do not
    # invent a word box or use this route to resolve lexical/spatial conflicts.
    if (
        preferred.valid_geometry_ratio < 1.0
        and not preferred.spatial_text_conflict_occurrence_count
        and len(preferred.facts) <= limits.max_supplemental_text_fact_scan
    ):
        preferred_facts = tuple(
            sorted(preferred.facts, key=lambda fact: fact.source_order)
        )
        if len(preferred.raw_facts) != len(preferred_facts):
            return None
        bracketed, isolated = _word_anchor_partition_support(preferred_facts)
        supported_anchor_ids = bracketed | isolated
        remaining_scan = limits.max_supplemental_text_fact_scan - len(preferred_facts)
        for layer in policy_order:
            candidate = layer_metrics[layer]
            if (
                candidate.layer != preferred.layer
                and candidate.capability_available
                and candidate.valid_geometry_ratio == 1.0
                and not candidate.spatial_text_conflict_occurrence_count
                and len(candidate.raw_facts) == len(candidate.facts)
            ):
                remaining_scan -= len(preferred_facts) + len(candidate.raw_facts)
                if remaining_scan < 0:
                    return None
                candidate_facts = tuple(
                    sorted(candidate.facts, key=lambda fact: fact.source_order)
                )
                if _matches_exact_fact_geometry(
                    preferred_facts, candidate_facts, supported_anchor_ids
                ) or (
                    preferred.layer == "word"
                    and candidate.layer in {"text_span", "line_candidate"}
                    and _matches_single_line_word_projection(
                        words=preferred_facts,
                        spans=candidate_facts,
                    )
                ):
                    return candidate

    return None


def _matching_text_style(first: PdfTextFact, second: PdfTextFact) -> bool:
    return (
        first.font_name,
        first.font_size,
        first.effective_font_scale_x,
        first.effective_font_scale_y,
        first.effective_font_size_x,
        first.effective_font_size_y,
        first.text_transform,
    ) == (
        second.font_name,
        second.font_size,
        second.effective_font_scale_x,
        second.effective_font_scale_y,
        second.effective_font_size_x,
        second.effective_font_size_y,
        second.text_transform,
    )


def _matches_exact_fact_geometry(
    preferred: tuple[PdfTextFact, ...],
    candidates: tuple[PdfTextFact, ...],
    supported_anchor_ids: frozenset[str],
) -> bool:
    if (
        len(preferred) != len(candidates)
        or len({fact.source_order for fact in preferred}) != len(preferred)
        or len({fact.source_order for fact in candidates}) != len(candidates)
    ):
        return False
    # An expanded anchor may not introduce a new horizontal region. For a
    # multi-fact page this route covers only an already uniform single-column
    # interval. Mixed-width/column pages keep their original word anchors.
    valid_intervals = {
        (fact.bbox.x0, fact.bbox.x1)
        for fact in preferred
        if _text_geometry_is_usable(fact)
    }
    for original, candidate in zip(preferred, candidates, strict=True):
        if (
            original.text != candidate.text
            or original.page_id != candidate.page_id
            or original.rotation != candidate.rotation
            or original.writing_direction != candidate.writing_direction
            or not _matching_text_style(original, candidate)
        ):
            return False
        if _text_geometry_is_usable(original):
            if original.bbox != candidate.bbox:
                return False
        elif len(preferred) == 1:
            # A sole source text fact has no other text partition to merge.
            # Its exact independent counterpart can repair even a point box.
            if not (
                candidate.bbox.x0
                <= original.bbox.x0
                <= original.bbox.x1
                <= candidate.bbox.x1
                and candidate.bbox.y0
                <= original.bbox.y0
                <= original.bbox.y1
                <= candidate.bbox.y1
            ):
                return False
        elif not (
            original.bbox.x0 == original.bbox.x1
            and original.fact_id in supported_anchor_ids
            and original.bbox.y0 == candidate.bbox.y0
            and original.bbox.y1 == candidate.bbox.y1
            and candidate.bbox.x0 <= original.bbox.x0 <= candidate.bbox.x1
            and valid_intervals == {(candidate.bbox.x0, candidate.bbox.x1)}
        ):
            return False
    return True


def _word_anchor_partition_support(
    words: tuple[PdfTextFact, ...],
) -> tuple[frozenset[str], frozenset[str]]:
    """Find original healthy-word brackets and separate vertical isolation.

    Support comes from the full source word inventory, independently of how
    candidate spans partition it. An anchor may not split a large original
    gap or extend a healthy line vertically. Isolation alone cannot authorize
    retention: additional zero-word x positions can affect column grouping.
    Only exact tuple replacement may use isolation, with its separate uniform
    healthy/candidate horizontal-interval constraint.
    """
    rows: dict[tuple[float, float], list[PdfTextFact]] = {}
    for word in words:
        if _text_geometry_is_usable(word):
            rows.setdefault((word.bbox.y0, word.bbox.y1), []).append(word)
    row_indexes: dict[
        tuple[float, float], tuple[tuple[PdfTextFact, ...], tuple[float, ...]]
    ] = {}
    for bounds, row in rows.items():
        ordered = tuple(sorted(row, key=lambda word: (word.bbox.x0, word.source_order)))
        row_indexes[bounds] = (ordered, tuple(word.bbox.x0 for word in ordered))
    vertical = sorted(words, key=lambda word: (word.bbox.y0, word.source_order))
    supported: set[str] = set()
    isolated_ids: set[str] = set()
    preceding_bottom = -math.inf
    for index, word in enumerate(vertical):
        next_top = (
            vertical[index + 1].bbox.y0 if index + 1 < len(vertical) else math.inf
        )
        if word.bbox.x0 == word.bbox.x1 and word.bbox.y0 < word.bbox.y1:
            isolated = preceding_bottom <= word.bbox.y0 and next_top >= word.bbox.y1
            row_index = row_indexes.get((word.bbox.y0, word.bbox.y1))
            if isolated:
                isolated_ids.add(word.fact_id)
            if row_index is not None and _has_original_word_gap_support(
                word, *row_index
            ):
                supported.add(word.fact_id)
        preceding_bottom = max(preceding_bottom, word.bbox.y1)
    return frozenset(supported), frozenset(isolated_ids)


def _has_original_word_gap_support(
    anchor: PdfTextFact,
    ordered: tuple[PdfTextFact, ...],
    starts: tuple[float, ...],
) -> bool:
    right_index = bisect_left(starts, anchor.bbox.x0)
    if right_index == 0 or right_index == len(ordered):
        return False
    left, right = ordered[right_index - 1 : right_index + 1]
    return (
        left.page_id == anchor.page_id == right.page_id
        and left.rotation == anchor.rotation == right.rotation
        and left.writing_direction
        == anchor.writing_direction
        == right.writing_direction
        and left.source_order < anchor.source_order < right.source_order
        and left.bbox.x1 <= anchor.bbox.x0 <= right.bbox.x0
        and right.bbox.x0 - left.bbox.x1 <= (anchor.bbox.y1 - anchor.bbox.y0) * 1.25
    )


def _word_projection_groups(
    words: tuple[PdfTextFact, ...],
    spans: tuple[PdfTextFact, ...],
) -> tuple[tuple[PdfTextFact, ...], ...] | None:
    """Partition every source-ordered token without normalizing its text.

    This is only the parser/Reading one-ASCII-space projection, never a claim
    that the PDF's original whitespace or operator boundaries were identical.
    All tokens and all spans must participate once; duplicate source positions
    and partial lexical matches cannot supply an anchor witness.
    """
    if (
        not words
        or not spans
        or len({fact.source_order for fact in words}) != len(words)
        or len({fact.source_order for fact in spans}) != len(spans)
    ):
        return None
    groups: list[tuple[PdfTextFact, ...]] = []
    word_index = 0
    for span in spans:
        offset = 0
        group_start = word_index
        while offset < len(span.text) and word_index < len(words):
            if word_index > group_start:
                if span.text[offset : offset + 1] != " ":
                    return None
                offset += 1
            word = words[word_index]
            if not span.text.startswith(word.text, offset):
                return None
            offset += len(word.text)
            word_index += 1
        if offset != len(span.text) or word_index == group_start:
            return None
        groups.append(words[group_start:word_index])
    return tuple(groups) if word_index == len(words) else None


def _has_bounded_word_line_geometry(
    words: tuple[PdfTextFact, ...], span: PdfTextFact
) -> bool:
    if (
        not words
        or not _text_geometry_is_usable(span)
        or span.rotation != 0
        or span.writing_direction != "left_to_right"
    ):
        return False
    common_top = max(word.bbox.y0 for word in words)
    common_bottom = min(word.bbox.y1 for word in words)
    previous: PdfTextFact | None = None
    previous_positive: PdfTextFact | None = None
    for word in words:
        height = word.bbox.y1 - word.bbox.y0
        if (
            height <= 0
            or word.rotation != span.rotation
            or word.writing_direction != span.writing_direction
            or word.page_id != span.page_id
            or word.bbox.x0 < span.bbox.x0
            or word.bbox.x1 > span.bbox.x1
            or word.bbox.y0 < span.bbox.y0
            or word.bbox.y1 > span.bbox.y1
            # A common overlap is stronger than pairwise chaining. These are
            # conservative bounds under the existing physical-line/gutter
            # contract, not a second Reading implementation.
            or common_bottom - common_top < height * 0.55
        ):
            return False
        if previous is not None:
            gap = word.bbox.x0 - previous.bbox.x1
            if gap < 0 or gap > min(height, previous.bbox.y1 - previous.bbox.y0) * 1.25:
                return False
        previous = word
        if word.bbox.x0 < word.bbox.x1:
            if previous_positive is not None and (
                word.bbox.x0 - previous_positive.bbox.x1
                > min(height, previous_positive.bbox.y1 - previous_positive.bbox.y0)
                * 1.25
            ):
                return False
            previous_positive = word
    return True


def _matches_single_line_word_projection(
    *,
    words: tuple[PdfTextFact, ...],
    spans: tuple[PdfTextFact, ...],
) -> bool:
    """Allow whole-layer projection only for one complete, unchanged line."""
    if len(spans) != 1 or _word_projection_groups(words, spans) is None:
        return False
    span = spans[0]
    if not _has_bounded_word_line_geometry(words, span):
        return False
    if any(not _matching_text_style(word, span) for word in words):
        return False
    return (
        min(word.bbox.x0 for word in words),
        min(word.bbox.y0 for word in words),
        max(word.bbox.x1 for word in words),
        max(word.bbox.y1 for word in words),
    ) == (span.bbox.x0, span.bbox.y0, span.bbox.x1, span.bbox.y1)


def _witnessed_zero_width_word_ids(
    *,
    selected_metrics: _TextLayerMetrics | None,
    layer_metrics: dict[_SourceTextLayer, _TextLayerMetrics],
    limits: PdfLayoutGraphLimits,
) -> frozenset[str]:
    """Retain source anchors without upgrading or inventing their geometry."""
    if (
        selected_metrics is None
        or selected_metrics.layer != "word"
        or selected_metrics.valid_geometry_ratio == 1.0
        or selected_metrics.spatial_text_conflict_occurrence_count
        or len(selected_metrics.raw_facts) != len(selected_metrics.facts)
        or len(selected_metrics.facts) > limits.max_supplemental_text_fact_scan
    ):
        return frozenset()
    words = tuple(sorted(selected_metrics.facts, key=lambda fact: fact.source_order))
    bracketed, _isolated = _word_anchor_partition_support(words)
    anchor_ids = set(bracketed)
    if not anchor_ids:
        return frozenset()
    witnesses: dict[str, tuple[str, ...]] = {}
    ambiguous: set[str] = set()
    remaining_scan = limits.max_supplemental_text_fact_scan - len(words)
    for layer in ("text_span", "line_candidate"):
        candidate = layer_metrics[layer]
        if not candidate.facts or not candidate.capability_available:
            continue
        # Count the full read before allocating/grouping it. On exhaustion no
        # incomplete search may claim uniqueness or retain a new anchor.
        remaining_scan -= len(words) + len(candidate.raw_facts)
        if remaining_scan < 0:
            return frozenset()
        if candidate.spatial_text_conflict_occurrence_count or len(
            candidate.raw_facts
        ) != len(candidate.facts):
            return frozenset()
        spans = tuple(sorted(candidate.facts, key=lambda fact: fact.source_order))
        groups = _word_projection_groups(words, spans)
        if groups is None:
            return frozenset()
        _record_word_anchor_witnesses(spans, groups, anchor_ids, witnesses, ambiguous)
    return frozenset(witnesses.keys() - ambiguous)


def _record_word_anchor_witnesses(
    spans: tuple[PdfTextFact, ...],
    groups: tuple[tuple[PdfTextFact, ...], ...],
    anchor_ids: set[str],
    witnesses: dict[str, tuple[str, ...]],
    ambiguous: set[str],
) -> None:
    for span, group in zip(spans, groups, strict=True):
        group_anchor_ids = anchor_ids.intersection(word.fact_id for word in group)
        if not group_anchor_ids:
            continue
        membership = tuple(word.fact_id for word in group)
        geometry_matches = _has_bounded_word_line_geometry(group, span)
        for fact_id in group_anchor_ids:
            if not geometry_matches or (
                fact_id in witnesses and witnesses[fact_id] != membership
            ):
                ambiguous.add(fact_id)
            else:
                witnesses[fact_id] = membership


def _select_text_layer(
    *,
    policy_order: tuple[_SourceTextLayer, _SourceTextLayer, _SourceTextLayer],
    layer_metrics: dict[_SourceTextLayer, _TextLayerMetrics],
    best_character_count: int,
    options: PdfLayoutGraphOptions,
    limits: PdfLayoutGraphLimits,
) -> tuple[_TextLayerMetrics | None, PdfLayoutTextLayerSelectionReason]:
    available = [
        layer_metrics[layer] for layer in policy_order if layer_metrics[layer].facts
    ]
    if not available:
        return None, "no_text_facts"
    preferred = layer_metrics[policy_order[0]]
    scored = [
        (
            _text_layer_score(
                metrics=metrics,
                best_character_count=best_character_count,
            ),
            -policy_order.index(metrics.layer),
            metrics,
        )
        for metrics in available
    ]
    best_score, _order, best = max(scored, key=lambda item: (item[0], item[1]))
    if not preferred.facts:
        return best, "preferred_unavailable"

    complete_layer = _complete_equivalent_geometry_layer(
        preferred, policy_order, layer_metrics, limits
    )
    if complete_layer is not None:
        return complete_layer, "fallback_higher_quality"

    preferred_score = _text_layer_score(
        metrics=preferred,
        best_character_count=best_character_count,
    )
    preferred_coverage = _coverage_ratio(
        preferred.conflict_capped_non_whitespace_character_count,
        best_character_count,
    )
    preferred_sufficient = (
        preferred.capability_available
        and preferred_coverage >= options.minimum_preferred_text_layer_coverage_ratio
        and preferred.valid_geometry_ratio
        >= options.minimum_text_layer_valid_geometry_ratio
        and preferred.spatial_duplicate_ratio
        <= options.maximum_preferred_text_layer_spatial_duplicate_ratio
        and preferred.spatial_text_conflict_ratio
        <= options.maximum_preferred_text_layer_spatial_conflict_ratio
        and not preferred.incomplete
    )
    if preferred_sufficient:
        return preferred, "preferred_sufficient"
    preferred_usable_as_primary = (
        preferred.capability_available
        and (
            not preferred.incomplete
            or preferred_coverage >= options.minimum_preferred_text_layer_coverage_ratio
        )
        and preferred.valid_geometry_ratio
        >= options.minimum_text_layer_valid_geometry_ratio
        and preferred.spatial_duplicate_ratio
        <= options.maximum_preferred_text_layer_spatial_duplicate_ratio
        and preferred.spatial_text_conflict_ratio
        <= options.maximum_preferred_text_layer_spatial_conflict_ratio
    )
    if preferred_usable_as_primary:
        if preferred.spatial_text_conflict_ratio:
            return preferred, "best_effort_ambiguous"
        return preferred, "best_effort_incomplete"
    if (
        preferred.layer == "word"
        and preferred.capability_available
        and preferred_coverage == 1.0
        and preferred.valid_geometry_ratio
        < options.minimum_text_layer_valid_geometry_ratio
        and not preferred.spatial_duplicate_occurrence_count
        and not preferred.spatial_text_conflict_occurrence_count
        and not preferred.incomplete
    ):
        # Geometry alone cannot justify a lossy whole-layer score fallback.
        # Exact/structurally bounded replacement was considered above; retain
        # the available words and expose any remaining invalid boxes instead.
        # Independent coverage gaps, conflicts and incomplete extraction still
        # take the existing fallback route below.
        return preferred, "best_effort_incomplete"
    if best.layer != preferred.layer and (
        preferred.incomplete
        or preferred_coverage < options.minimum_preferred_text_layer_coverage_ratio
        or preferred.valid_geometry_ratio
        < options.minimum_text_layer_valid_geometry_ratio
        or preferred.spatial_duplicate_ratio
        > options.maximum_preferred_text_layer_spatial_duplicate_ratio
        or preferred.spatial_text_conflict_ratio
        > options.maximum_preferred_text_layer_spatial_conflict_ratio
        or best_score
        >= preferred_score + options.minimum_text_layer_fallback_score_improvement
    ):
        return best, "fallback_higher_quality"
    if preferred.spatial_text_conflict_ratio:
        return preferred, "best_effort_ambiguous"
    return preferred, "best_effort_incomplete"


def _select_supplemental_text_facts(
    *,
    selected_metrics: _TextLayerMetrics | None,
    layer_metrics: dict[_SourceTextLayer, _TextLayerMetrics],
    options: PdfLayoutGraphOptions,
    limits: PdfLayoutGraphLimits,
) -> _SupplementalTextSelection:
    empty = _SupplementalTextSelection(None, (), 0, 0, 0, 0, 0, True)
    if selected_metrics is None or not selected_metrics.facts:
        return empty
    alternatives = [
        metrics
        for metrics in layer_metrics.values()
        if metrics.layer != selected_metrics.layer and metrics.facts
    ]
    if not alternatives:
        return empty
    best_character_count = max(
        (
            metrics.conflict_capped_non_whitespace_character_count
            for metrics in layer_metrics.values()
        ),
        default=0,
    )
    fallback = max(
        alternatives,
        key=lambda metrics: (
            _text_layer_score(
                metrics=metrics,
                best_character_count=best_character_count,
            ),
            metrics.conflict_capped_non_whitespace_character_count,
            -{"word": 0, "text_span": 1, "line_candidate": 2}[metrics.layer],
        ),
    )
    retained: list[PdfTextFact] = []
    missing_region_count = 0
    conflict_count = 0
    truncation_count = 0
    scanned_fact_count = 0
    region_counts: dict[tuple[int, int], int] = {}
    primary_facts = tuple(selected_metrics.facts)
    primary_index = _PrimaryTextFactSpatialIndex.build(
        facts=primary_facts,
        options=options,
    )
    for index, candidate in enumerate(fallback.facts):
        if not _text_geometry_is_usable(candidate):
            continue
        if scanned_fact_count >= limits.max_supplemental_text_fact_scan:
            truncation_count += len(fallback.facts) - index
            missing_region_count += len(fallback.facts) - index
            break
        represented, conflict, scans, search_complete = (
            _supplemental_fact_relation_to_primary(
                candidate=candidate,
                primary_facts=primary_index.candidates(
                    candidate,
                    options=options,
                ),
                options=options,
                remaining_scan_budget=(
                    limits.max_supplemental_text_fact_scan - scanned_fact_count
                ),
            )
        )
        scanned_fact_count += scans
        if represented:
            continue
        missing_region_count += 1
        truncation_count += int(not search_complete)
        if conflict or not search_complete:
            conflict_count += int(conflict)
            continue
        if len(retained) >= limits.max_supplemental_text_nodes_per_page:
            truncation_count += 1
            continue
        region_key = _text_duplicate_bucket_key(
            candidate,
            bucket_size=max(
                options.text_duplicate_center_tolerance_points,
                1.0,
            ),
        )
        if (
            region_counts.get(region_key, 0)
            >= limits.max_supplemental_text_nodes_per_region
        ):
            truncation_count += 1
            continue
        retained.append(candidate)
        region_counts[region_key] = region_counts.get(region_key, 0) + 1
    retained.sort(key=lambda fact: (fact.source_order, fact.fact_id))
    return _SupplementalTextSelection(
        layer=fallback.layer,
        facts=tuple(retained),
        non_whitespace_character_count=sum(
            len(_coverage_text(fact.text)) for fact in retained
        ),
        missing_region_count=missing_region_count,
        conflict_count=conflict_count,
        truncation_count=truncation_count,
        scanned_fact_count=scanned_fact_count,
        fallback_incomplete=fallback.incomplete,
    )


def _supplemental_fact_relation_to_primary(
    *,
    candidate: PdfTextFact,
    primary_facts: tuple[PdfTextFact, ...],
    options: PdfLayoutGraphOptions,
    remaining_scan_budget: int,
) -> tuple[bool, bool, int, bool]:
    overlapping: list[PdfTextFact] = []
    scanned = 0
    for primary in primary_facts:
        if scanned >= remaining_scan_budget:
            break
        scanned += 1
        overlap_ratio = _text_bbox_overlap_over_smaller(candidate, primary)
        if overlap_ratio <= 0 and not _text_facts_are_spatial_duplicates(
            candidate,
            primary,
            options=options,
        ):
            continue
        overlapping.append(primary)

    candidate_hard = _hard_text_identity(candidate.text)
    candidate_soft = _soft_lexical_equivalence_key(candidate.text)
    for primary in overlapping:
        if not _text_facts_are_spatial_duplicates(
            candidate,
            primary,
            options=options,
        ):
            continue
        primary_hard = _hard_text_identity(primary.text)
        if primary_hard == candidate_hard or (
            _soft_lexical_equivalence_key(primary.text) == candidate_soft
        ):
            return True, False, scanned, True
        return False, True, scanned, True

    if overlapping:
        geometric_order = sorted(
            overlapping,
            key=lambda fact: (
                fact.bbox.y0,
                fact.bbox.x0,
                fact.source_order,
                fact.fact_id,
            ),
        )
        source_order = sorted(
            overlapping,
            key=lambda fact: (
                fact.source_order,
                fact.bbox.y0,
                fact.bbox.x0,
                fact.bbox.y1,
                fact.bbox.x1,
                fact.fact_id,
            ),
        )
        geometric_assembly = _soft_lexical_equivalence_key(
            "".join(fact.text for fact in geometric_order)
        )
        source_assembly = _soft_lexical_equivalence_key(
            "".join(fact.text for fact in source_order)
        )
        if candidate_soft in {geometric_assembly, source_assembly}:
            return True, False, scanned, True
        if any(
            _text_bbox_overlap_over_smaller(candidate, primary) >= 0.85
            for primary in overlapping
        ):
            return False, True, scanned, True
    return False, False, scanned, scanned == len(primary_facts)


def _text_bbox_overlap_over_smaller(
    first: PdfTextFact,
    second: PdfTextFact,
) -> float:
    intersection_width = max(
        0.0,
        min(first.bbox.x1, second.bbox.x1) - max(first.bbox.x0, second.bbox.x0),
    )
    intersection_height = max(
        0.0,
        min(first.bbox.y1, second.bbox.y1) - max(first.bbox.y0, second.bbox.y0),
    )
    intersection = intersection_width * intersection_height
    smaller = min(
        max(
            0.0,
            (first.bbox.x1 - first.bbox.x0) * (first.bbox.y1 - first.bbox.y0),
        ),
        max(
            0.0,
            (second.bbox.x1 - second.bbox.x0) * (second.bbox.y1 - second.bbox.y0),
        ),
    )
    return intersection / smaller if smaller > 0 else 0.0


def _selection_contract(
    *,
    requested_policy: PdfLayoutTextNodePolicy,
    selected_metrics: _TextLayerMetrics | None,
    selection_reason: PdfLayoutTextLayerSelectionReason,
    layer_metrics: dict[_SourceTextLayer, _TextLayerMetrics],
    best_character_count: int,
    options: PdfLayoutGraphOptions,
    supplemental: _SupplementalTextSelection,
) -> PdfLayoutTextLayerSelection:
    preferred_layer = {
        "prefer_words": "word",
        "prefer_text_spans": "text_span",
        "prefer_line_candidates": "line_candidate",
    }[requested_policy]
    if selected_metrics is None:
        return PdfLayoutTextLayerSelection(
            requested_text_layer_policy=requested_policy,
            selected_text_layer="none",
            fallback_used=False,
            available_word_count=len(layer_metrics["word"].raw_facts),
            available_text_span_count=len(layer_metrics["text_span"].raw_facts),
            available_line_candidate_count=len(
                layer_metrics["line_candidate"].raw_facts
            ),
            raw_selected_text_fact_count=0,
            excluded_blank_text_fact_count=sum(
                metrics.excluded_blank_fact_count for metrics in layer_metrics.values()
            ),
            hard_deduplicated_text_fact_count=0,
            selected_text_fact_count=0,
            primary_text_fact_count=0,
            supplemental_text_fact_count=0,
            spatial_duplicate_occurrence_count=0,
            spatial_duplicate_cluster_count=0,
            spatial_text_conflict_suppressed_occurrence_count=0,
            raw_selected_non_whitespace_character_count=0,
            hard_deduplicated_non_whitespace_character_count=0,
            selected_non_whitespace_character_count=0,
            conflict_capped_non_whitespace_character_count=0,
            supplemental_non_whitespace_character_count=0,
            combined_distinct_non_whitespace_character_count=0,
            best_available_non_whitespace_character_count=best_character_count,
            selected_layer_coverage_ratio=None,
            combined_text_coverage_ratio=None,
            selected_valid_geometry_ratio=None,
            selected_single_character_ratio=None,
            selected_spatial_duplicate_ratio=None,
            selected_repeated_text_ratio=None,
            selected_soft_equivalent_occurrence_count=0,
            selected_spatial_text_conflict_occurrence_count=0,
            selected_spatial_text_conflict_cluster_count=0,
            selected_spatial_text_conflict_ratio=None,
            text_conflict_detected=False,
            selected_layer_missing_region_count=0,
            supplemental_conflict_count=0,
            source_fact_available_graph_missing_count=0,
            supplemental_truncation_count=0,
            supplemental_applied=False,
            duplicate_suppression_applied=False,
            selected_layer_incomplete=any(
                metrics.incomplete for metrics in layer_metrics.values()
            )
            or not any(
                metrics.capability_available for metrics in layer_metrics.values()
            ),
            selection_reason=selection_reason,
        )

    coverage = _coverage_ratio(
        selected_metrics.conflict_capped_non_whitespace_character_count,
        best_character_count,
    )
    combined_character_count = (
        selected_metrics.conflict_capped_non_whitespace_character_count
        + supplemental.non_whitespace_character_count
    )
    combined_denominator = max(best_character_count, combined_character_count)
    combined_coverage = _coverage_ratio(
        combined_character_count,
        combined_denominator,
    )
    incomplete = (
        (selected_metrics.incomplete and supplemental.fallback_incomplete)
        or not selected_metrics.capability_available
        or combined_coverage < options.minimum_preferred_text_layer_coverage_ratio
        or selected_metrics.valid_geometry_ratio
        < options.minimum_text_layer_valid_geometry_ratio
        or bool(supplemental.truncation_count)
        or bool(supplemental.source_fact_available_graph_missing_count)
    )
    return PdfLayoutTextLayerSelection(
        requested_text_layer_policy=requested_policy,
        selected_text_layer=selected_metrics.layer,
        fallback_used=(
            selected_metrics.layer != preferred_layer or bool(supplemental.facts)
        ),
        available_word_count=len(layer_metrics["word"].raw_facts),
        available_text_span_count=len(layer_metrics["text_span"].raw_facts),
        available_line_candidate_count=len(layer_metrics["line_candidate"].raw_facts),
        raw_selected_text_fact_count=len(selected_metrics.raw_facts),
        excluded_blank_text_fact_count=(selected_metrics.excluded_blank_fact_count),
        hard_deduplicated_text_fact_count=len(selected_metrics.hard_deduplicated_facts),
        selected_text_fact_count=len(selected_metrics.facts),
        primary_text_fact_count=len(selected_metrics.facts),
        supplemental_text_fact_count=len(supplemental.facts),
        spatial_duplicate_occurrence_count=(
            selected_metrics.spatial_duplicate_occurrence_count
        ),
        spatial_duplicate_cluster_count=(
            selected_metrics.spatial_duplicate_cluster_count
        ),
        spatial_text_conflict_suppressed_occurrence_count=(
            selected_metrics.spatial_text_conflict_suppressed_occurrence_count
        ),
        raw_selected_non_whitespace_character_count=(
            selected_metrics.raw_non_whitespace_character_count
        ),
        hard_deduplicated_non_whitespace_character_count=(
            selected_metrics.hard_deduplicated_non_whitespace_character_count
        ),
        selected_non_whitespace_character_count=(
            selected_metrics.non_whitespace_character_count
        ),
        conflict_capped_non_whitespace_character_count=(
            selected_metrics.conflict_capped_non_whitespace_character_count
        ),
        supplemental_non_whitespace_character_count=(
            supplemental.non_whitespace_character_count
        ),
        combined_distinct_non_whitespace_character_count=(combined_character_count),
        best_available_non_whitespace_character_count=best_character_count,
        selected_layer_coverage_ratio=round(coverage, 6),
        combined_text_coverage_ratio=round(combined_coverage, 6),
        selected_valid_geometry_ratio=round(
            selected_metrics.valid_geometry_ratio,
            6,
        ),
        selected_single_character_ratio=round(
            selected_metrics.single_character_ratio,
            6,
        ),
        selected_spatial_duplicate_ratio=round(
            selected_metrics.spatial_duplicate_ratio,
            6,
        ),
        selected_repeated_text_ratio=round(
            selected_metrics.repeated_text_ratio,
            6,
        ),
        selected_soft_equivalent_occurrence_count=(
            selected_metrics.soft_equivalent_occurrence_count
        ),
        selected_spatial_text_conflict_occurrence_count=(
            selected_metrics.spatial_text_conflict_occurrence_count
        ),
        selected_spatial_text_conflict_cluster_count=(
            selected_metrics.spatial_text_conflict_cluster_count
        ),
        selected_spatial_text_conflict_ratio=round(
            selected_metrics.spatial_text_conflict_ratio,
            6,
        ),
        text_conflict_detected=bool(
            selected_metrics.spatial_text_conflict_occurrence_count
        ),
        selected_layer_missing_region_count=supplemental.missing_region_count,
        supplemental_conflict_count=supplemental.conflict_count,
        source_fact_available_graph_missing_count=(
            supplemental.source_fact_available_graph_missing_count
        ),
        supplemental_truncation_count=supplemental.truncation_count,
        supplemental_applied=bool(supplemental.facts),
        duplicate_suppression_applied=bool(
            selected_metrics.spatial_duplicate_occurrence_count
        ),
        selected_layer_incomplete=incomplete,
        selection_reason=selection_reason,
    )


def _text_layer_score(
    *,
    metrics: _TextLayerMetrics,
    best_character_count: int,
) -> float:
    coverage = _coverage_ratio(
        metrics.conflict_capped_non_whitespace_character_count,
        best_character_count,
    )
    capability_weight = 1.0 if metrics.capability_available else 0.75
    completeness_weight = 0.8 if metrics.incomplete else 1.0
    return (
        (
            0.45 * coverage
            + 0.20 * metrics.valid_geometry_ratio
            + 0.10 * metrics.geometry_quality_ratio
            + 0.10 * (1 - metrics.single_character_ratio)
            + 0.10 * (1 - metrics.spatial_duplicate_ratio)
            + 0.05 * (1 - metrics.spatial_text_conflict_ratio)
        )
        * capability_weight
        * completeness_weight
    )


def _coverage_ratio(value: int, best: int) -> float:
    if best <= 0:
        return 0.0
    return min(1.0, max(0.0, value / best))


def _deduplicate_text_facts(
    *,
    facts: tuple[PdfTextFact, ...],
    text_bbox_quality: str,
    options: PdfLayoutGraphOptions,
) -> tuple[tuple[PdfTextFact, ...], int, int]:
    facts_by_text: dict[str, list[PdfTextFact]] = {}
    for fact in facts:
        facts_by_text.setdefault(
            _hard_text_identity(fact.text),
            [],
        ).append(fact)

    representatives: list[PdfTextFact] = []
    duplicate_occurrence_count = 0
    duplicate_cluster_count = 0
    text_groups = sorted(
        facts_by_text.values(),
        key=lambda group: min(fact.fact_id for fact in group),
    )
    for group in text_groups:
        clusters: list[_TextDuplicateCluster] = []
        buckets: dict[tuple[int, int], list[int]] = {}
        for fact in sorted(
            group,
            key=lambda item: _text_representative_sort_key(
                item,
                text_bbox_quality=text_bbox_quality,
            ),
        ):
            bucket_key = _text_duplicate_bucket_key(
                fact,
                bucket_size=options.text_duplicate_center_tolerance_points,
            )
            candidate_cluster_indices = {
                cluster_index
                for nearby_key in _nearby_bucket_keys(bucket_key)
                for cluster_index in buckets.get(nearby_key, ())
            }
            matching_cluster_indices = [
                cluster_index
                for cluster_index in sorted(candidate_cluster_indices)
                if _text_facts_are_spatial_duplicates(
                    clusters[cluster_index].representative,
                    fact,
                    options=options,
                )
            ]
            if matching_cluster_indices:
                cluster_index = min(
                    matching_cluster_indices,
                    key=lambda index: _text_representative_sort_key(
                        clusters[index].representative,
                        text_bbox_quality=text_bbox_quality,
                    ),
                )
                cluster = clusters[cluster_index]
                if cluster.occurrence_count == 1:
                    duplicate_cluster_count += 1
                cluster.occurrence_count += 1
                duplicate_occurrence_count += 1
                continue

            cluster_index = len(clusters)
            clusters.append(_TextDuplicateCluster(representative=fact))
            buckets.setdefault(bucket_key, []).append(cluster_index)

        representatives.extend(cluster.representative for cluster in clusters)

    representatives.sort(key=lambda fact: (fact.source_order, fact.fact_id))
    return (
        tuple(representatives),
        duplicate_occurrence_count,
        duplicate_cluster_count,
    )


def _analyze_spatial_text_conflicts(
    *,
    facts: tuple[PdfTextFact, ...],
    text_bbox_quality: str,
    options: PdfLayoutGraphOptions,
    max_alternatives_per_cluster: int,
    coverage_text_by_value: Mapping[str, str] | None = None,
    soft_key_by_value: Mapping[str, str] | None = None,
) -> _TextSpatialConflictResult:
    if coverage_text_by_value is None:
        coverage_text_by_value = {
            fact.text: _coverage_text(fact.text) for fact in facts
        }
    if soft_key_by_value is None:
        soft_key_by_value = {
            text: (
                covered if covered.isascii() else unicodedata.normalize("NFKC", covered)
            )
            for text, covered in coverage_text_by_value.items()
        }
    clusters: list[_TextSpatialCluster] = []
    buckets: dict[tuple[int, int], list[int]] = {}
    for fact in sorted(
        facts,
        key=lambda item: _text_representative_sort_key(
            item,
            text_bbox_quality=text_bbox_quality,
        ),
    ):
        bucket_key = _text_duplicate_bucket_key(
            fact,
            bucket_size=options.text_duplicate_center_tolerance_points,
        )
        candidate_cluster_indices = {
            cluster_index
            for nearby_key in _nearby_bucket_keys(bucket_key)
            for cluster_index in buckets.get(nearby_key, ())
        }
        matching_cluster_indices = [
            cluster_index
            for cluster_index in sorted(candidate_cluster_indices)
            if _text_facts_are_spatial_duplicates(
                clusters[cluster_index].facts[0],
                fact,
                options=options,
            )
        ]
        if matching_cluster_indices:
            cluster_index = min(
                matching_cluster_indices,
                key=lambda index: _text_representative_sort_key(
                    clusters[index].facts[0],
                    text_bbox_quality=text_bbox_quality,
                ),
            )
            clusters[cluster_index].facts.append(fact)
            continue

        cluster_index = len(clusters)
        clusters.append(_TextSpatialCluster(facts=[fact]))
        buckets.setdefault(bucket_key, []).append(cluster_index)

    retained_facts: list[PdfTextFact] = []
    conflict_capped_character_count = 0
    conflict_occurrence_count = 0
    conflict_cluster_count = 0
    soft_equivalent_occurrence_count = 0
    suppressed_occurrence_count = 0
    lexical_keys_by_spatial_cluster: list[set[str]] = []
    for cluster in clusters:
        ordered_facts = sorted(
            cluster.facts,
            key=lambda item: _text_representative_sort_key(
                item,
                text_bbox_quality=text_bbox_quality,
            ),
        )
        hard_identities = {_hard_text_identity(fact.text) for fact in ordered_facts}
        is_conflict = len(hard_identities) > 1
        if is_conflict:
            conflict_cluster_count += 1
            conflict_occurrence_count += len(ordered_facts) - 1
            soft_groups: dict[str, set[str]] = {}
            for fact in ordered_facts:
                soft_groups.setdefault(
                    soft_key_by_value[fact.text],
                    set(),
                ).add(_hard_text_identity(fact.text))
            soft_equivalent_occurrence_count += sum(
                len(group) - 1 for group in soft_groups.values()
            )

        retained = ordered_facts[:max_alternatives_per_cluster]
        suppressed_occurrence_count += len(ordered_facts) - len(retained)
        retained_facts.extend(retained)
        conflict_capped_character_count += max(
            (len(coverage_text_by_value[fact.text]) for fact in retained),
            default=0,
        )
        lexical_keys_by_spatial_cluster.append(
            {soft_key_by_value[fact.text] for fact in retained}
        )

    lexical_occurrences = [
        key
        for cluster_keys in lexical_keys_by_spatial_cluster
        for key in sorted(cluster_keys)
        if key
    ]
    repeated_text_count = len(lexical_occurrences) - len(set(lexical_occurrences))
    retained_facts.sort(key=lambda fact: (fact.source_order, fact.fact_id))
    return _TextSpatialConflictResult(
        facts=tuple(retained_facts),
        conflict_capped_non_whitespace_character_count=(
            conflict_capped_character_count
        ),
        repeated_text_ratio=(
            repeated_text_count / len(lexical_occurrences)
            if lexical_occurrences
            else 0.0
        ),
        soft_equivalent_occurrence_count=soft_equivalent_occurrence_count,
        spatial_text_conflict_occurrence_count=conflict_occurrence_count,
        spatial_text_conflict_cluster_count=conflict_cluster_count,
        suppressed_occurrence_count=suppressed_occurrence_count,
    )


def _text_duplicate_bucket_key(
    fact: PdfTextFact,
    *,
    bucket_size: float,
) -> tuple[int, int]:
    center_x, center_y = _text_bbox_center(fact)
    return (
        math.floor(center_x / bucket_size),
        math.floor(center_y / bucket_size),
    )


def _nearby_bucket_keys(
    key: tuple[int, int],
) -> tuple[tuple[int, int], ...]:
    column, row = key
    return tuple(
        (column + column_offset, row + row_offset)
        for row_offset in (-1, 0, 1)
        for column_offset in (-1, 0, 1)
    )


def _text_facts_are_spatial_duplicates(
    first: PdfTextFact,
    second: PdfTextFact,
    *,
    options: PdfLayoutGraphOptions,
) -> bool:
    if not _text_rotations_are_compatible(
        first.rotation,
        second.rotation,
        tolerance=options.rotation_tolerance_degrees,
    ):
        return False
    first_center = _text_bbox_center(first)
    second_center = _text_bbox_center(second)
    center_tolerance = options.text_duplicate_center_tolerance_points
    if (
        abs(first_center[0] - second_center[0]) > center_tolerance
        or abs(first_center[1] - second_center[1]) > center_tolerance
    ):
        return False
    bbox_tolerance = options.text_duplicate_bbox_tolerance_points
    coordinate_close = all(
        abs(first_value - second_value) <= bbox_tolerance
        for first_value, second_value in zip(
            (
                first.bbox.x0,
                first.bbox.y0,
                first.bbox.x1,
                first.bbox.y1,
            ),
            (
                second.bbox.x0,
                second.bbox.y0,
                second.bbox.x1,
                second.bbox.y1,
            ),
            strict=True,
        )
    )
    return coordinate_close or _text_bbox_iou(first, second) >= (
        options.minimum_text_duplicate_iou_ratio
    )


def _text_bbox_iou(first: PdfTextFact, second: PdfTextFact) -> float:
    intersection_width = max(
        0.0,
        min(first.bbox.x1, second.bbox.x1) - max(first.bbox.x0, second.bbox.x0),
    )
    intersection_height = max(
        0.0,
        min(first.bbox.y1, second.bbox.y1) - max(first.bbox.y0, second.bbox.y0),
    )
    intersection_area = intersection_width * intersection_height
    first_area = max(
        0.0,
        (first.bbox.x1 - first.bbox.x0) * (first.bbox.y1 - first.bbox.y0),
    )
    second_area = max(
        0.0,
        (second.bbox.x1 - second.bbox.x0) * (second.bbox.y1 - second.bbox.y0),
    )
    union_area = first_area + second_area - intersection_area
    return intersection_area / union_area if union_area > 0 else 0.0


def _text_bbox_center(fact: PdfTextFact) -> tuple[float, float]:
    return (
        (fact.bbox.x0 + fact.bbox.x1) / 2,
        (fact.bbox.y0 + fact.bbox.y1) / 2,
    )


def _text_rotations_are_compatible(
    first: float | None,
    second: float | None,
    *,
    tolerance: float,
) -> bool:
    if first is None or second is None:
        return first is second
    difference = abs(first - second) % 360
    return min(difference, 360 - difference) <= tolerance


def _text_representative_sort_key(
    fact: PdfTextFact,
    *,
    text_bbox_quality: str,
) -> tuple[object, ...]:
    confidence = (
        cast("float", fact.confidence.value)
        if fact.confidence.availability == "available"
        else -1.0
    )
    return (
        -_text_geometry_quality_rank(
            fact,
            text_bbox_quality=text_bbox_quality,
        ),
        -confidence,
        len(fact.warnings),
        fact.source_order,
        fact.fact_id,
    )


def _text_geometry_quality_rank(
    fact: PdfTextFact,
    *,
    text_bbox_quality: str,
) -> int:
    warning_codes = {warning.code for warning in fact.warnings}
    if (
        not _text_geometry_is_usable(fact)
        or PdfWarningCode.INVALID_BBOX in warning_codes
        or PdfWarningCode.ZERO_AREA_BBOX in warning_codes
    ):
        return 0
    if PdfWarningCode.APPROXIMATE_BBOX in warning_codes:
        return 1
    return {"unavailable": 0, "anchor": 1, "precise": 2}[text_bbox_quality]


def _layer_capability(
    *,
    layer: str,
    capabilities: PdfParserCapabilities,
) -> bool:
    return {
        "word": capabilities.words,
        "text_span": capabilities.text_spans,
        "line_candidate": capabilities.line_candidates,
    }[layer]


def _hard_text_identity(text: str) -> str:
    if text.isascii() and "\r" not in text:
        return text
    normalized_line_endings = text.replace("\r\n", "\n").replace("\r", "\n")
    return unicodedata.normalize("NFC", normalized_line_endings)


def _soft_lexical_equivalence_key(text: str) -> str:
    covered = _coverage_text(text)
    return covered if covered.isascii() else unicodedata.normalize("NFKC", covered)


def _coverage_text(text: str) -> str:
    if text.isascii():
        return text.translate(_ASCII_INVISIBLE_TRANSLATION)
    return "".join(
        character
        for character in unicodedata.normalize("NFC", text)
        if _is_visible_text_character(character)
    )


def _is_visible_text_character(character: str) -> bool:
    category = unicodedata.category(character)
    return (
        not character.isspace()
        and not category.startswith("Z")
        and category not in {"Cc", "Cf", "Cs"}
    )


def _text_geometry_is_usable(fact: PdfTextFact) -> bool:
    return fact.bbox.x1 > fact.bbox.x0 and fact.bbox.y1 > fact.bbox.y0


def _has_incomplete_warning(warnings: Sequence[PdfFactWarning]) -> bool:
    return any(warning.code in _TEXT_INCOMPLETE_WARNING_CODES for warning in warnings)


def _has_relevant_artifact_warning(
    warnings: Sequence[PdfFactWarning],
    *,
    page_number: int,
) -> bool:
    return any(
        warning.code in _TEXT_INCOMPLETE_WARNING_CODES
        and warning.page_number in (None, page_number)
        for warning in warnings
    )


def is_usable_layout_geometry(selected: SelectedLayoutFact) -> bool:
    width = selected.fact.bbox.x1 - selected.fact.bbox.x0
    height = selected.fact.bbox.y1 - selected.fact.bbox.y0
    if selected.node_type in {
        "text_span",
        "word",
        "line_candidate",
        "image_region",
    }:
        return width > 0 and height > 0
    drawing = selected.fact
    if not isinstance(drawing, PdfDrawingFact):
        return False
    if drawing.kind == "rectangle":
        return width > 0 and height > 0
    return width > 0 or height > 0


def build_layout_node(
    *,
    selected: SelectedLayoutFact,
    artifact: PdfFactArtifact,
    page_graph_id: str,
) -> PdfLayoutNode:
    quality = _geometry_quality(selected=selected, artifact=artifact)
    confidence = {
        "precise": PdfFactConfidence(availability="available", value=1.0),
        "approximate": PdfFactConfidence(availability="available", value=0.75),
        "unknown": PdfFactConfidence(),
    }[quality]
    source_warning_codes = tuple(
        sorted(
            {warning.code for warning in selected.fact.warnings},
            key=lambda item: item.value,
        )
    )
    return PdfLayoutNode(
        node_id=layout_node_identifier(
            page_graph_id=page_graph_id,
            source_fact_id=selected.fact.fact_id,
            node_type=selected.node_type,
        ),
        source_page_id=selected.fact.page_id,
        source_fact_id=selected.fact.fact_id,
        node_type=selected.node_type,
        text_layer_role=selected.text_layer_role,
        supplemental_reason=selected.supplemental_reason,
        drawing_kind=(
            selected.fact.kind if isinstance(selected.fact, PdfDrawingFact) else None
        ),
        bbox=selected.fact.bbox,
        rotation=getattr(selected.fact, "rotation", None),
        source_order=selected.fact.source_order,
        geometry_quality=quality,
        parser_name=artifact.parser_name,
        parser_version=artifact.parser_version,
        source_warning_codes=source_warning_codes,
        confidence=confidence,
    )


def source_page_warning_count(page: PdfPageFacts) -> int:
    # Keep warning aggregation streaming.  Star-expanding these inventories
    # created a second page-sized tuple, which is particularly expensive for
    # drawing-heavy pages even though only warning counts are required.
    return len(page.warnings) + sum(
        len(fact.warnings)
        for facts in (
            page.text_spans,
            page.words,
            page.line_candidates,
            page.characters,
            page.drawings,
            page.image_regions,
        )
        for fact in facts
    )


def _selected_fact_sort_key(
    selected: SelectedLayoutFact,
) -> tuple[object, ...]:
    fact = selected.fact
    return (
        fact.source_order,
        _NODE_TYPE_ORDER[selected.node_type],
        round(fact.bbox.y0, 6),
        round(fact.bbox.x0, 6),
        round(fact.bbox.y1, 6),
        round(fact.bbox.x1, 6),
        fact.fact_id,
    )


def _geometry_quality(
    *,
    selected: SelectedLayoutFact,
    artifact: PdfFactArtifact,
) -> PdfLayoutGeometryQuality:
    if selected.retain_zero_width_text_anchor:
        return "unknown"
    warning_codes = {warning.code for warning in selected.fact.warnings}
    if PdfWarningCode.APPROXIMATE_BBOX in warning_codes:
        return "approximate"
    if isinstance(selected.fact, PdfDrawingFact):
        return selected.fact.bbox_semantics.quality
    if isinstance(selected.fact, PdfImageRegionFact):
        return "precise" if selected.fact.parser_available else "unknown"
    return cast(
        "PdfLayoutGeometryQuality",
        {
            "precise": "precise",
            "anchor": "approximate",
            "unavailable": "unknown",
        }[artifact.parser_capabilities.text_bbox_quality],
    )

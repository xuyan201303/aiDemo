# ruff: noqa: C901, D202, EM101, I001, PLR0912, PLR0915, PLR2004, RET505, S101, TRY003, UP040

from datetime import datetime
import math
import re
from typing import Literal, TypeAlias

from pydantic import (
    AwareDatetime,
    BaseModel,
    ConfigDict,
    Field,
    field_validator,
    model_validator,
)

from document_sdk.pdf._structural_engine.facts.contracts import (
    PdfBoundingBox,
    PdfClippingApplication,
    PdfDrawingKind,
    PdfFactConfidence,
    PdfNormalizedBoundingBox,
    PdfPaintOperation,
)
from document_sdk.pdf._structural_engine.facts.status import (
    PdfExtractionStatus,
    PdfFactWarning,
    PdfWarningCode,
    PdfWarningSuppressionSummary,
)
from document_sdk.pdf._structural_engine.layout.limits import (
    PdfLayoutGraphLimits,
    PdfLayoutGraphOptions,
    PdfLayoutTextNodePolicy,
)


PDF_LAYOUT_GRAPH_SCHEMA_VERSION: Literal["pdf_layout_graph.v1"] = "pdf_layout_graph.v1"
PDF_LAYOUT_GRAPH_BUILDER_NAME = "document_sdk_page_local_layout_graph"
PDF_LAYOUT_GRAPH_BUILDER_VERSION = "2.5"
PDF_LAYOUT_RELATION_METHOD_VERSION: Literal["page_local_geometry.v4"] = (
    "page_local_geometry.v4"
)
PDF_LAYOUT_SEPARATOR_CANDIDATE_CONTRACT_VERSION = "pdf_layout_separator_candidate.v2"
PDF_LAYOUT_PAGE_BOUNDARY_CONTRACT_VERSION = "pdf_layout_page_boundary.v1"
PDF_LAYOUT_DRAWING_MATERIALIZATION_POLICY_VERSION = (
    "pdf_layout_drawing_materialization.v1"
)
PDF_LAYOUT_STAGE_TIMING_CONTRACT_VERSION: Literal["pdf_layout_stage_timing.v1"] = (
    "pdf_layout_stage_timing.v1"
)

PdfLayoutNodeType = Literal[
    "text_span",
    "word",
    "line_candidate",
    "drawing",
    "image_region",
]
PdfLayoutGeometryQuality = Literal["precise", "approximate", "unknown"]
PdfLayoutTextLayerRole = Literal["primary", "supplemental", "not_text"]
PdfLayoutSupplementalReason = Literal["none", "primary_coverage_gap"]
PdfLayoutRelationType = Literal[
    "left_of",
    "above",
    "contains",
    "overlaps",
    "adjacent_horizontal",
    "adjacent_vertical",
    "same_row_candidate",
    "same_column_candidate",
]
PdfLayoutAdjacencyBasis = Literal[
    "near_gap",
    "mutual_nearest_row_neighbor",
    "mutual_nearest_column_neighbor",
]
PdfLayoutRelationMethod: TypeAlias = Literal[
    "page_local_geometry.v1",
    "page_local_geometry.v2",
    "page_local_geometry.v3",
    "page_local_geometry.v4",
]
PdfLayoutSeparatorOrientation = Literal["horizontal", "vertical"]
PdfLayoutSeparatorEvidenceKind = Literal[
    "drawing_separator",
    "page_boundary",
]
PdfLayoutSeparatorSourceKind = Literal["drawing_fact", "page_geometry"]
PdfLayoutPageBoundarySide = Literal["top", "bottom", "left", "right"]
PdfLayoutSeparatorPrimitiveSource = Literal[
    "direct_line",
    "rectangle_top_edge",
    "rectangle_bottom_edge",
    "rectangle_left_edge",
    "rectangle_right_edge",
    "thin_rectangle_centerline",
    "axis_aligned_path_segment",
    "line_like_curve_bbox",
    "approximate_path_axis",
    "page_boundary_edge",
]
PdfLayoutSelectedTextLayer = Literal[
    "word",
    "text_span",
    "line_candidate",
    "none",
]
PdfLayoutTextLayerSelectionReason = Literal[
    "preferred_sufficient",
    "fallback_higher_quality",
    "preferred_unavailable",
    "best_effort_incomplete",
    "best_effort_ambiguous",
    "preferred_with_supplemental_gap_fill",
    "no_text_facts",
]
PdfLayoutEmptyPageClassification = Literal[
    "not_empty",
    "truly_empty",
    "no_eligible_facts",
    "source_incomplete",
    "geometry_unavailable",
]
PdfLayoutRelationInventoryMode = Literal["bounded_positive_candidates"]
PdfLayoutRelationScope = Literal["page_local"]
PdfLayoutRelationEdgeSemantics = Literal["positive_candidate_evidence"]
PdfLayoutRelationAbsenceSemantics = Literal["unknown"]
PdfLayoutGraphCompletenessSemantics = Literal[
    "content_node_geometry_not_relation_recall"
]
PdfLayoutRelationConfidenceSemantics = Literal[
    "physical_candidate_not_business_confirmation"
]

PDF_LAYOUT_SYMMETRIC_RELATIONS: frozenset[PdfLayoutRelationType] = frozenset(
    {"overlaps"}
)


def is_symmetric_layout_relation(relation_type: str) -> bool:
    """Return whether relation direction is interchangeable in the contract."""

    return relation_type in PDF_LAYOUT_SYMMETRIC_RELATIONS


_ALLOWED_BUILD_STATUSES = {
    PdfExtractionStatus.SUCCESS,
    PdfExtractionStatus.PARTIAL,
    PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED,
    PdfExtractionStatus.INTERNAL_ERROR,
}
_NODE_TYPE_ORDER = {
    "line_candidate": 0,
    "word": 1,
    "text_span": 2,
    "drawing": 3,
    "image_region": 4,
}


class PdfLayoutGeometryEvidence(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    horizontal_gap: float = Field(ge=0)
    vertical_gap: float = Field(ge=0)
    horizontal_overlap_ratio: float = Field(ge=0, le=1)
    vertical_overlap_ratio: float = Field(ge=0, le=1)
    overlap_ratio: float = Field(ge=0, le=1)
    alignment_delta: float = Field(ge=0)
    containment_ratio: float = Field(ge=0, le=1)
    normalized_distance: float = Field(ge=0)
    rotation_compatible: bool


class PdfLayoutRelationInventoryContract(BaseModel):
    """Static semantics shared by every page-local relation observation."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    inventory_mode: PdfLayoutRelationInventoryMode = "bounded_positive_candidates"
    relation_scope: PdfLayoutRelationScope = "page_local"
    edge_semantics: PdfLayoutRelationEdgeSemantics = "positive_candidate_evidence"
    absence_semantics: PdfLayoutRelationAbsenceSemantics = "unknown"
    globally_exhaustive: Literal[False] = False
    graph_completeness_semantics: PdfLayoutGraphCompletenessSemantics = (
        "content_node_geometry_not_relation_recall"
    )
    relation_confidence_semantics: PdfLayoutRelationConfidenceSemantics = (
        "physical_candidate_not_business_confirmation"
    )
    stored_edge_policy: Literal["bounded_ranked_positive_candidates"] = (
        "bounded_ranked_positive_candidates"
    )
    stored_relation_node_policy: Literal["text_image_and_bounded_non_line_drawings"] = (
        "text_image_and_bounded_non_line_drawings"
    )
    omitted_stored_edge_semantics: Literal["unknown"] = "unknown"
    on_demand_pair_evaluation_available: Literal[True] = True
    relation_method_version: PdfLayoutRelationMethod = (
        PDF_LAYOUT_RELATION_METHOD_VERSION
    )


class PdfLayoutRelationObservationScope(BaseModel):
    """Bounded search coverage signals; never a relation-recall estimate."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    observation_metrics_available: bool = True
    relation_search_truncated: bool
    bounded_search_completed_without_resource_truncation: bool
    eligible_relation_node_count: int | None = Field(default=None, ge=0)
    nodes_with_directed_candidates: int | None = Field(default=None, ge=0)
    nodes_without_directed_candidates: int | None = Field(default=None, ge=0)
    candidate_scope_ratio: float | None = Field(default=None, ge=0, le=1)

    @model_validator(mode="after")
    def validate_observation_scope(self) -> "PdfLayoutRelationObservationScope":
        if self.bounded_search_completed_without_resource_truncation == (
            self.relation_search_truncated
        ):
            raise ValueError(
                "bounded-search completion must be the inverse of search truncation"
            )
        metrics = (
            self.eligible_relation_node_count,
            self.nodes_with_directed_candidates,
            self.nodes_without_directed_candidates,
        )
        if not self.observation_metrics_available:
            if any(value is not None for value in metrics) or (
                self.candidate_scope_ratio is not None
            ):
                raise ValueError(
                    "unavailable relation observation metrics must remain null"
                )
            return self
        if any(value is None for value in metrics):
            raise ValueError("available relation observation metrics cannot be null")
        eligible = self.eligible_relation_node_count
        with_candidates = self.nodes_with_directed_candidates
        without_candidates = self.nodes_without_directed_candidates
        assert eligible is not None
        assert with_candidates is not None
        assert without_candidates is not None
        if with_candidates + without_candidates != eligible:
            raise ValueError("relation candidate node counts must cover eligible nodes")
        expected_ratio = round(with_candidates / eligible, 6) if eligible else None
        if self.candidate_scope_ratio != expected_ratio:
            raise ValueError("relation candidate scope ratio is inconsistent")
        return self


def legacy_relation_observation_scope() -> PdfLayoutRelationObservationScope:
    """Conservatively describe v1 payloads written before scope metrics existed."""

    return PdfLayoutRelationObservationScope(
        observation_metrics_available=False,
        relation_search_truncated=True,
        bounded_search_completed_without_resource_truncation=False,
    )


class PdfLayoutSeparatorCandidate(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    separator_candidate_id: str = Field(pattern=r"^PDFLS-[0-9a-f]{24}$")
    drawing_node_id: str | None = Field(
        default=None,
        pattern=r"^PDFLN-[0-9a-f]{24}$",
    )
    orientation: PdfLayoutSeparatorOrientation
    evidence_kind: PdfLayoutSeparatorEvidenceKind = "drawing_separator"
    source_kind: PdfLayoutSeparatorSourceKind = "drawing_fact"
    page_boundary_side: PdfLayoutPageBoundarySide | None = None
    primitive_source_type: PdfLayoutSeparatorPrimitiveSource = "direct_line"
    bbox: PdfBoundingBox
    normalized_bbox: PdfNormalizedBoundingBox | None = None
    line_length: float = Field(gt=0)
    stroke_width: float | None = Field(default=None, ge=0)
    nearby_node_count: int = Field(ge=0)
    crossing_or_touching_node_count: int = Field(ge=0)
    page_coverage_ratio: float = Field(ge=0, le=1)
    confidence: float = Field(ge=0, le=1)
    geometry_quality: PdfLayoutGeometryQuality
    paint_operation: PdfPaintOperation
    clipping_application: PdfClippingApplication
    quality_metadata_truncated: bool = False

    @model_validator(mode="after")
    def validate_evidence_kind(self) -> "PdfLayoutSeparatorCandidate":
        is_boundary = self.evidence_kind == "page_boundary"
        if is_boundary != (self.source_kind == "page_geometry"):
            raise ValueError(
                "page-boundary evidence must come from canonical page geometry"
            )
        if is_boundary:
            if self.drawing_node_id is not None:
                raise ValueError("page geometry cannot carry a drawing node ID")
            if self.page_boundary_side is None:
                raise ValueError("page boundary requires its canonical side")
            if self.primitive_source_type != "page_boundary_edge":
                raise ValueError("page boundary requires page-boundary edge source")
            if self.normalized_bbox is None:
                raise ValueError("page boundary requires a normalized bbox")
            if self.geometry_quality != "precise":
                raise ValueError("canonical page-boundary geometry must be precise")
            expected_orientation = (
                "horizontal"
                if self.page_boundary_side in {"top", "bottom"}
                else "vertical"
            )
            if self.orientation != expected_orientation:
                raise ValueError(
                    "page-boundary orientation must match its canonical side"
                )
            if (
                self.stroke_width is not None
                or self.paint_operation != "unknown"
                or self.clipping_application != "not_applied"
            ):
                raise ValueError(
                    "page geometry cannot carry drawing paint or stroke metadata"
                )
            expected_normalized_bbox = {
                "top": (0.0, 0.0, 1.0, 0.0),
                "bottom": (0.0, 1.0, 1.0, 1.0),
                "left": (0.0, 0.0, 0.0, 1.0),
                "right": (1.0, 0.0, 1.0, 1.0),
            }[self.page_boundary_side]
            observed_normalized_bbox = (
                self.normalized_bbox.x0,
                self.normalized_bbox.y0,
                self.normalized_bbox.x1,
                self.normalized_bbox.y1,
            )
            if observed_normalized_bbox != expected_normalized_bbox:
                raise ValueError(
                    "page boundary normalized bbox must match its canonical side"
                )
        else:
            if self.drawing_node_id is None:
                raise ValueError("drawing separator requires a drawing node ID")
            if self.page_boundary_side is not None:
                raise ValueError("drawing separator cannot carry a page-boundary side")
            if self.primitive_source_type == "page_boundary_edge":
                raise ValueError(
                    "drawing separator cannot use page-boundary edge source"
                )
        return self


class PdfLayoutNode(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    node_id: str = Field(pattern=r"^PDFLN-[0-9a-f]{24}$")
    source_page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    source_fact_id: str = Field(pattern=r"^PDFF-[0-9a-f]{24}$")
    node_type: PdfLayoutNodeType
    text_layer_role: PdfLayoutTextLayerRole = "not_text"
    supplemental_reason: PdfLayoutSupplementalReason = "none"
    drawing_kind: PdfDrawingKind | None = None
    bbox: PdfBoundingBox
    rotation: float | None = Field(default=None, ge=0, lt=360)
    source_order: int = Field(ge=0)
    geometry_quality: PdfLayoutGeometryQuality
    parser_name: str = Field(min_length=1, max_length=64)
    parser_version: str = Field(min_length=1, max_length=64)
    source_warning_codes: tuple[PdfWarningCode, ...] = ()
    confidence: PdfFactConfidence = Field(default_factory=PdfFactConfidence)

    @model_validator(mode="before")
    @classmethod
    def apply_text_layer_role_default(cls, value: object) -> object:
        if isinstance(value, dict) and "text_layer_role" not in value:
            value = dict(value)
            value["text_layer_role"] = (
                "primary"
                if value.get("node_type") in {"word", "text_span", "line_candidate"}
                else "not_text"
            )
        return value

    @model_validator(mode="after")
    def validate_node_type(self) -> "PdfLayoutNode":
        if (self.node_type == "drawing") != (self.drawing_kind is not None):
            raise ValueError("drawing kind must be present only for drawing nodes")
        is_text = self.node_type in {"word", "text_span", "line_candidate"}
        if is_text != (self.text_layer_role != "not_text"):
            raise ValueError("text layer role must be present only for text nodes")
        if (self.text_layer_role == "supplemental") != (
            self.supplemental_reason != "none"
        ):
            raise ValueError(
                "supplemental text role and reason must be present together"
            )
        warning_values = tuple(item.value for item in self.source_warning_codes)
        if warning_values != tuple(sorted(set(warning_values))):
            raise ValueError("source warning codes must be unique and sorted")
        return self


class PdfLayoutEdge(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    edge_id: str = Field(pattern=r"^PDFLE-[0-9a-f]{24}$")
    source_node_id: str = Field(pattern=r"^PDFLN-[0-9a-f]{24}$")
    target_node_id: str = Field(pattern=r"^PDFLN-[0-9a-f]{24}$")
    relation_type: PdfLayoutRelationType
    adjacency_basis: PdfLayoutAdjacencyBasis | None = None
    confidence: float = Field(
        ge=0,
        le=1,
        description=(
            "Physical relation-candidate confidence; not business or table "
            "confirmation confidence."
        ),
    )
    base_confidence: float = Field(default=0, ge=0, le=1)
    separator_confidence_reduction: float = Field(default=0, ge=0, le=1)
    separator_candidate_ids: tuple[str, ...] = ()
    relevant_separator_count: int = Field(
        default=0,
        ge=0,
        description=(
            "Observed relevant separator count; a lower bound when source "
            "inventory or relation-local context is truncated."
        ),
    )
    retained_separator_evidence_count: int = Field(default=0, ge=0)
    separator_source_inventory_truncated: bool = Field(
        default=False,
        description=(
            "True when the page-level separator candidate inventory is incomplete."
        ),
    )
    separator_context_truncated: bool = Field(
        default=False,
        description=(
            "True when relation-local separator search completeness is not guaranteed."
        ),
    )
    separator_id_list_truncated: bool = Field(
        default=False,
        description="True when only the serialized evidence ID list is bounded.",
    )
    relevant_separator_count_is_lower_bound: bool = Field(
        default=False,
        description="True when relevant_separator_count is an observed lower bound.",
    )
    separator_evidence_truncated: bool = Field(
        default=False,
        description="Summary of source, local-context, or retained-ID truncation.",
    )
    geometry_evidence: PdfLayoutGeometryEvidence
    method_version: PdfLayoutRelationMethod = PDF_LAYOUT_RELATION_METHOD_VERSION
    warning_codes: tuple[PdfWarningCode, ...] = ()

    @model_validator(mode="before")
    @classmethod
    def apply_additive_defaults(cls, value: object) -> object:
        if isinstance(value, dict):
            value = dict(value)
            if "base_confidence" not in value:
                value["base_confidence"] = value.get("confidence", 0)
            legacy_id_list_truncated = value.get(
                "relevant_separator_count",
                0,
            ) > value.get("retained_separator_evidence_count", 0)
            if "separator_id_list_truncated" not in value:
                value["separator_id_list_truncated"] = legacy_id_list_truncated
            if "separator_source_inventory_truncated" not in value:
                value["separator_source_inventory_truncated"] = False
            if "separator_context_truncated" not in value:
                value["separator_context_truncated"] = bool(
                    value.get("separator_evidence_truncated", False)
                    and not legacy_id_list_truncated
                )
            if "relevant_separator_count_is_lower_bound" not in value:
                value["relevant_separator_count_is_lower_bound"] = bool(
                    value.get("separator_source_inventory_truncated", False)
                    or value.get("separator_context_truncated", False)
                )
        return value

    @model_validator(mode="after")
    def reject_self_edge(self) -> "PdfLayoutEdge":
        if self.source_node_id == self.target_node_id:
            raise ValueError("layout edge cannot reference the same node twice")
        if self.relation_type == "adjacent_horizontal":
            if self.adjacency_basis not in {
                "near_gap",
                "mutual_nearest_row_neighbor",
            }:
                raise ValueError("horizontal adjacency requires a row-compatible basis")
        elif self.relation_type == "adjacent_vertical":
            if self.adjacency_basis not in {
                "near_gap",
                "mutual_nearest_column_neighbor",
            }:
                raise ValueError(
                    "vertical adjacency requires a column-compatible basis"
                )
        elif self.adjacency_basis is not None:
            raise ValueError("non-adjacency edge cannot carry adjacency basis")
        if self.confidence > self.base_confidence:
            raise ValueError("separator adjustment cannot increase confidence")
        expected_confidence = self.base_confidence * (
            1 - self.separator_confidence_reduction
        )
        if not math.isclose(self.confidence, expected_confidence, abs_tol=1e-6):
            raise ValueError("edge confidence must match its separator adjustment")
        separator_ids = tuple(self.separator_candidate_ids)
        if separator_ids != tuple(sorted(set(separator_ids))):
            raise ValueError("separator candidate IDs must be unique and sorted")
        if any(
            re.fullmatch(r"PDFLS-[0-9a-f]{24}", item) is None for item in separator_ids
        ):
            raise ValueError("edge separator candidate ID is invalid")
        if self.separator_confidence_reduction and not separator_ids:
            raise ValueError("separator confidence reduction requires evidence")
        if self.retained_separator_evidence_count != len(separator_ids):
            raise ValueError("retained separator count must match stored evidence IDs")
        if self.relevant_separator_count < self.retained_separator_evidence_count:
            raise ValueError("relevant separator count cannot be below retained count")
        if self.relevant_separator_count_is_lower_bound != bool(
            self.separator_source_inventory_truncated
            or self.separator_context_truncated
        ):
            raise ValueError(
                "separator count lower-bound state must match source and local "
                "context completeness"
            )
        expected_id_truncation = (
            self.relevant_separator_count > self.retained_separator_evidence_count
        )
        if self.separator_id_list_truncated != expected_id_truncation:
            raise ValueError(
                "separator ID truncation must match observed and retained counts"
            )
        if self.separator_evidence_truncated != (
            self.separator_source_inventory_truncated
            or self.separator_context_truncated
            or self.separator_id_list_truncated
        ):
            raise ValueError("separator truncation summary is inconsistent")
        truncation_warning = (
            PdfWarningCode.TOTAL_FACT_LIMIT_REACHED in self.warning_codes
        )
        if self.separator_evidence_truncated != truncation_warning:
            raise ValueError("separator truncation must match its warning code")
        warning_values = tuple(item.value for item in self.warning_codes)
        if warning_values != tuple(sorted(set(warning_values))):
            raise ValueError("edge warning codes must be unique and sorted")
        return self


class PdfLayoutParserQualitySummary(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    source_extraction_status: PdfExtractionStatus
    source_partial_extraction: bool = Field(
        description="Summary of document- or page-level source partial state."
    )
    source_document_partial: bool
    source_page_partial: bool
    source_warning_count: int = Field(ge=0)
    geometry_completeness: Literal["complete", "partial", "assumed"]
    geometry_confidence: Literal["high", "low"]
    text_bbox_quality: Literal["unavailable", "anchor", "precise"]
    drawing_bbox_quality: Literal["unavailable", "approximate", "precise"]

    @model_validator(mode="after")
    def validate_partial_scope(self) -> "PdfLayoutParserQualitySummary":
        if self.source_partial_extraction != (
            self.source_document_partial or self.source_page_partial
        ):
            raise ValueError("source partial summary must match document/page scope")
        if self.source_page_partial != (
            self.source_extraction_status is not PdfExtractionStatus.SUCCESS
        ):
            raise ValueError("page partial state must match page extraction status")
        return self


class PdfLayoutTextLayerSelection(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    requested_text_layer_policy: PdfLayoutTextNodePolicy
    selected_text_layer: PdfLayoutSelectedTextLayer
    fallback_used: bool
    available_word_count: int = Field(ge=0)
    available_text_span_count: int = Field(ge=0)
    available_line_candidate_count: int = Field(ge=0)
    raw_selected_text_fact_count: int = Field(ge=0)
    excluded_blank_text_fact_count: int = Field(ge=0)
    hard_deduplicated_text_fact_count: int = Field(ge=0)
    selected_text_fact_count: int = Field(
        ge=0,
        description="Distinct visible text facts retained as layout nodes.",
    )
    primary_text_fact_count: int = Field(default=0, ge=0)
    supplemental_text_fact_count: int = Field(default=0, ge=0)
    spatial_duplicate_occurrence_count: int = Field(ge=0)
    spatial_duplicate_cluster_count: int = Field(ge=0)
    spatial_text_conflict_suppressed_occurrence_count: int = Field(ge=0)
    raw_selected_non_whitespace_character_count: int = Field(ge=0)
    hard_deduplicated_non_whitespace_character_count: int = Field(ge=0)
    selected_non_whitespace_character_count: int = Field(
        ge=0,
        description="Characters retained after hard deduplication and limits.",
    )
    conflict_capped_non_whitespace_character_count: int = Field(ge=0)
    supplemental_non_whitespace_character_count: int = Field(default=0, ge=0)
    combined_distinct_non_whitespace_character_count: int = Field(default=0, ge=0)
    best_available_non_whitespace_character_count: int = Field(ge=0)
    selected_layer_coverage_ratio: float | None = Field(default=None, ge=0, le=1)
    combined_text_coverage_ratio: float | None = Field(default=None, ge=0, le=1)
    selected_valid_geometry_ratio: float | None = Field(default=None, ge=0, le=1)
    selected_single_character_ratio: float | None = Field(default=None, ge=0, le=1)
    selected_spatial_duplicate_ratio: float | None = Field(
        default=None,
        ge=0,
        le=1,
    )
    selected_repeated_text_ratio: float | None = Field(
        default=None,
        ge=0,
        le=1,
    )
    selected_soft_equivalent_occurrence_count: int = Field(ge=0)
    selected_spatial_text_conflict_occurrence_count: int = Field(ge=0)
    selected_spatial_text_conflict_cluster_count: int = Field(ge=0)
    selected_spatial_text_conflict_ratio: float | None = Field(
        default=None,
        ge=0,
        le=1,
    )
    text_conflict_detected: bool
    selected_layer_missing_region_count: int = Field(default=0, ge=0)
    supplemental_conflict_count: int = Field(default=0, ge=0)
    source_fact_available_graph_missing_count: int = Field(default=0, ge=0)
    supplemental_truncation_count: int = Field(default=0, ge=0)
    supplemental_applied: bool = False
    duplicate_suppression_applied: bool
    selected_layer_incomplete: bool
    selection_reason: PdfLayoutTextLayerSelectionReason

    @model_validator(mode="before")
    @classmethod
    def apply_supplemental_defaults(cls, value: object) -> object:
        if isinstance(value, dict):
            value = dict(value)
            selected_count = int(value.get("selected_text_fact_count", 0))
            selected_characters = int(
                value.get("conflict_capped_non_whitespace_character_count", 0)
            )
            value.setdefault("primary_text_fact_count", selected_count)
            value.setdefault("supplemental_text_fact_count", 0)
            value.setdefault("supplemental_non_whitespace_character_count", 0)
            value.setdefault(
                "combined_distinct_non_whitespace_character_count",
                selected_characters,
            )
            value.setdefault(
                "combined_text_coverage_ratio",
                value.get("selected_layer_coverage_ratio"),
            )
            value.setdefault("selected_layer_missing_region_count", 0)
            value.setdefault("supplemental_conflict_count", 0)
            value.setdefault("source_fact_available_graph_missing_count", 0)
            value.setdefault("supplemental_truncation_count", 0)
            value.setdefault("supplemental_applied", False)
        return value

    @model_validator(mode="after")
    def validate_selection(self) -> "PdfLayoutTextLayerSelection":
        preferred_layer = {
            "prefer_words": "word",
            "prefer_text_spans": "text_span",
            "prefer_line_candidates": "line_candidate",
        }[self.requested_text_layer_policy]
        if self.selected_text_layer == "none":
            if any(
                (
                    self.raw_selected_text_fact_count,
                    self.hard_deduplicated_text_fact_count,
                    self.selected_text_fact_count,
                    self.spatial_duplicate_occurrence_count,
                    self.spatial_duplicate_cluster_count,
                    self.spatial_text_conflict_suppressed_occurrence_count,
                    self.raw_selected_non_whitespace_character_count,
                    self.hard_deduplicated_non_whitespace_character_count,
                    self.selected_non_whitespace_character_count,
                    self.conflict_capped_non_whitespace_character_count,
                    self.selected_soft_equivalent_occurrence_count,
                    self.selected_spatial_text_conflict_occurrence_count,
                    self.selected_spatial_text_conflict_cluster_count,
                )
            ):
                raise ValueError("an empty text-layer selection cannot retain text")
            if any(
                value is not None
                for value in (
                    self.selected_layer_coverage_ratio,
                    self.selected_valid_geometry_ratio,
                    self.selected_single_character_ratio,
                    self.selected_spatial_duplicate_ratio,
                    self.selected_repeated_text_ratio,
                    self.selected_spatial_text_conflict_ratio,
                )
            ):
                raise ValueError("an empty text-layer selection has no ratios")
            if self.fallback_used:
                raise ValueError("an empty text-layer selection cannot be a fallback")
            if self.duplicate_suppression_applied:
                raise ValueError(
                    "an empty text-layer selection cannot suppress duplicates"
                )
            if self.text_conflict_detected:
                raise ValueError("an empty text-layer selection cannot have conflicts")
            return self
        else:
            if self.selected_text_fact_count == 0:
                raise ValueError("a selected text layer must retain a text fact")
            if self.raw_selected_text_fact_count < self.selected_text_fact_count:
                raise ValueError(
                    "raw selected facts cannot be fewer than distinct facts"
                )
            if self.selected_layer_coverage_ratio is None:
                raise ValueError("a selected text layer requires coverage")
            if self.selected_valid_geometry_ratio is None:
                raise ValueError("a selected text layer requires geometry quality")
            if self.selected_spatial_duplicate_ratio is None:
                raise ValueError("a selected text layer requires duplicate quality")
            if self.selected_repeated_text_ratio is None:
                raise ValueError("a selected text layer requires repetition quality")
            if self.selected_spatial_text_conflict_ratio is None:
                raise ValueError("a selected text layer requires conflict quality")
            if self.fallback_used != (
                self.selected_text_layer != preferred_layer or self.supplemental_applied
            ):
                raise ValueError("fallback state must match the selected text layer")
        if self.primary_text_fact_count != self.selected_text_fact_count:
            raise ValueError("primary text count must match selected-layer facts")
        if self.supplemental_applied != bool(self.supplemental_text_fact_count):
            raise ValueError(
                "supplemental state must match retained supplemental facts"
            )
        if self.combined_distinct_non_whitespace_character_count != (
            self.conflict_capped_non_whitespace_character_count
            + self.supplemental_non_whitespace_character_count
        ):
            raise ValueError(
                "combined text coverage must match primary and supplemental"
            )
        if self.source_fact_available_graph_missing_count != (
            self.selected_layer_missing_region_count - self.supplemental_text_fact_count
        ):
            raise ValueError("source-to-graph missing text counts are inconsistent")
        visible_raw_fact_count = (
            self.raw_selected_text_fact_count - self.excluded_blank_text_fact_count
        )
        expected_duplicate_occurrences = (
            visible_raw_fact_count - self.hard_deduplicated_text_fact_count
        )
        if self.spatial_duplicate_occurrence_count != expected_duplicate_occurrences:
            raise ValueError(
                "spatial duplicate occurrences must match fact suppression"
            )
        if self.selected_text_fact_count != (
            self.hard_deduplicated_text_fact_count
            - self.spatial_text_conflict_suppressed_occurrence_count
        ):
            raise ValueError("selected facts must match conflict limit suppression")
        if (
            self.spatial_duplicate_cluster_count
            > self.spatial_duplicate_occurrence_count
        ):
            raise ValueError("duplicate clusters cannot exceed duplicate occurrences")
        if bool(self.spatial_duplicate_occurrence_count) != (
            self.spatial_duplicate_cluster_count > 0
        ):
            raise ValueError("duplicate occurrences and clusters must agree")
        if self.duplicate_suppression_applied != bool(
            self.spatial_duplicate_occurrence_count
        ):
            raise ValueError("duplicate suppression state must match occurrences")
        if (
            self.raw_selected_non_whitespace_character_count
            < self.hard_deduplicated_non_whitespace_character_count
        ):
            raise ValueError(
                "raw selected characters cannot be fewer than "
                "hard-deduplicated characters"
            )
        if (
            self.hard_deduplicated_non_whitespace_character_count
            < self.selected_non_whitespace_character_count
        ):
            raise ValueError(
                "hard-deduplicated characters cannot be fewer than retained characters"
            )
        if (
            self.conflict_capped_non_whitespace_character_count
            > self.selected_non_whitespace_character_count
        ):
            raise ValueError(
                "conflict-capped characters cannot exceed retained characters"
            )
        if visible_raw_fact_count and (
            self.selected_spatial_duplicate_ratio is not None
            and not math.isclose(
                self.selected_spatial_duplicate_ratio,
                self.spatial_duplicate_occurrence_count / visible_raw_fact_count,
                abs_tol=1e-6,
            )
        ):
            raise ValueError(
                "spatial duplicate ratio must match suppressed occurrences"
            )
        if (
            self.conflict_capped_non_whitespace_character_count
            > self.best_available_non_whitespace_character_count
        ):
            raise ValueError("selected text coverage exceeds the available maximum")
        if (
            self.selected_soft_equivalent_occurrence_count
            > self.selected_spatial_text_conflict_occurrence_count
        ):
            raise ValueError("soft equivalents must be spatial text conflicts")
        if (
            self.selected_spatial_text_conflict_cluster_count
            > self.selected_spatial_text_conflict_occurrence_count
        ):
            raise ValueError("conflict clusters cannot exceed conflict occurrences")
        if self.text_conflict_detected != bool(
            self.selected_spatial_text_conflict_occurrence_count
        ):
            raise ValueError("text conflict state must match conflict occurrences")
        if self.hard_deduplicated_text_fact_count and (
            self.selected_spatial_text_conflict_ratio is not None
            and not math.isclose(
                self.selected_spatial_text_conflict_ratio,
                self.selected_spatial_text_conflict_occurrence_count
                / self.hard_deduplicated_text_fact_count,
                abs_tol=1e-6,
            )
        ):
            raise ValueError("spatial text conflict ratio must match occurrences")
        return self


class PdfLayoutPageQualitySignals(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    node_density_per_10k_points: float = Field(ge=0)
    edge_density_per_node: float = Field(ge=0)
    text_fragmentation_ratio: float = Field(ge=0, le=1)
    single_character_node_ratio: float = Field(ge=0, le=1)
    overlapping_node_ratio: float = Field(ge=0, le=1)
    invalid_geometry_ratio: float = Field(ge=0, le=1)
    rotated_node_ratio: float = Field(ge=0, le=1)
    drawing_node_ratio: float = Field(ge=0, le=1)
    image_node_ratio: float = Field(ge=0, le=1)
    isolated_node_ratio: float = Field(ge=0, le=1)
    resource_truncation: bool
    node_retention_completeness: float = Field(ge=0, le=1)
    source_geometry_completeness: float = Field(ge=0, le=1)
    graph_completeness: float = Field(
        ge=0,
        le=1,
        description=(
            "Content, retained-node, selected-text, and geometry completeness; "
            "not relation recall or exhaustive pair coverage."
        ),
    )
    graph_confidence: float = Field(
        ge=0,
        le=1,
        description=(
            "Physical graph quality signal; not business meaning or confirmed "
            "table-structure confidence."
        ),
    )
    empty_page_classification: PdfLayoutEmptyPageClassification
    text_layer_selection: PdfLayoutTextLayerSelection
    parser_quality: PdfLayoutParserQualitySummary


class PdfLayoutStageTimingProfile(BaseModel):
    """Sanitized, non-deterministic wall timings for page build stages."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    schema_version: Literal["pdf_layout_stage_timing.v1"] = (
        PDF_LAYOUT_STAGE_TIMING_CONTRACT_VERSION
    )
    text_layer_metrics: float = Field(default=0.0, ge=0)
    hard_duplicate_grouping: float = Field(default=0.0, ge=0)
    spatial_conflict_analysis: float = Field(default=0.0, ge=0)
    supplemental_gap_fill: float = Field(default=0.0, ge=0)
    node_construction: float = Field(default=0.0, ge=0)
    drawing_primitive_extraction: float = Field(default=0.0, ge=0)
    separator_generation: float = Field(default=0.0, ge=0)
    spatial_index_construction: float = Field(default=0.0, ge=0)
    row_column_neighbor_index: float = Field(default=0.0, ge=0)
    generic_relation_candidate_search: float = Field(default=0.0, ge=0)
    relation_inference: float = Field(default=0.0, ge=0)
    sparse_retention: float = Field(default=0.0, ge=0)
    quality_calculation: float = Field(default=0.0, ge=0)
    post_page_stages_available: bool = False
    artifact_construction: float | None = Field(default=None, ge=0)
    serialization_size_calculation: float | None = Field(default=None, ge=0)
    total_profiled_milliseconds: float = Field(default=0.0, ge=0)

    @model_validator(mode="after")
    def validate_stage_total(self) -> "PdfLayoutStageTimingProfile":
        post_page_values = (
            self.artifact_construction,
            self.serialization_size_calculation,
        )
        if self.post_page_stages_available != all(
            value is not None for value in post_page_values
        ):
            raise ValueError(
                "post-page timing availability must match both stage values"
            )
        expected = sum(
            (
                self.text_layer_metrics,
                self.hard_duplicate_grouping,
                self.spatial_conflict_analysis,
                self.supplemental_gap_fill,
                self.node_construction,
                self.drawing_primitive_extraction,
                self.separator_generation,
                self.spatial_index_construction,
                self.row_column_neighbor_index,
                self.generic_relation_candidate_search,
                self.relation_inference,
                self.sparse_retention,
                self.quality_calculation,
                *(value for value in post_page_values if value is not None),
            )
        )
        if not math.isclose(
            self.total_profiled_milliseconds,
            expected,
            rel_tol=0,
            abs_tol=0.001,
        ):
            raise ValueError("profiled stage total must equal its stage inventory")
        return self


class PdfLayoutPageResourceUsage(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    eligible_fact_count: int = Field(ge=0)
    retained_node_count: int = Field(ge=0)
    candidate_pair_count: int = Field(ge=0)
    retained_edge_count: int = Field(ge=0)
    inferred_relation_candidate_count: int = Field(default=0, ge=0)
    sparse_relation_suppressed_count: int = Field(default=0, ge=0)
    relation_candidate_limit_reached: bool = False
    hard_edge_limit_reached: bool = False
    generic_drawing_relation_node_suppressed_count: int = Field(default=0, ge=0)
    drawing_node_suppression_metrics_available: bool = False
    source_drawing_fact_count: int = Field(default=0, ge=0)
    retained_drawing_node_count: int = Field(default=0, ge=0)
    drawing_node_suppressed_count: int = Field(default=0, ge=0)
    drawing_node_suppression_policy_version: str | None = None
    near_identical_drawing_node_suppressed_count: int = Field(default=0, ge=0)
    repeated_decorative_drawing_node_suppressed_count: int = Field(
        default=0,
        ge=0,
    )
    relation_ineligible_drawing_node_suppressed_count: int = Field(
        default=0,
        ge=0,
    )
    separator_source_drawing_fact_evaluated_count: int = Field(default=0, ge=0)
    separator_primitive_retained_count: int = Field(default=0, ge=0)
    maximum_retained_edges_per_node_relation: int = Field(default=0, ge=0)
    invalid_geometry_count: int = Field(ge=0)
    candidate_truncated_node_count: int = Field(ge=0)
    directed_candidate_count: int = Field(default=0, ge=0)
    maximum_directed_candidates_per_node: int = Field(ge=0)
    corridor_query_count: int = Field(default=0, ge=0)
    maximum_relation_context_nodes: int = Field(ge=0)
    total_intervening_candidate_scans: int = Field(ge=0)
    relation_context_truncation_count: int = Field(ge=0)
    spatial_bucket_scan_count: int = Field(ge=0)
    separator_candidate_count: int = Field(default=0, ge=0)
    separator_query_count: int = Field(default=0, ge=0)
    separator_candidate_truncation_count: int = Field(default=0, ge=0)
    separator_source_inventory_truncated: bool = False
    separator_candidate_quality_truncation_count: int = Field(default=0, ge=0)
    separator_path_geometry_incomplete_count: int = Field(default=0, ge=0)
    separator_primitive_truncation_count: int = Field(default=0, ge=0)
    separator_relation_query_count: int = Field(default=0, ge=0)
    separator_relation_candidate_scan_count: int = Field(default=0, ge=0)
    separator_evidence_evaluation_scan_count: int = Field(default=0, ge=0)
    separator_relation_context_truncation_count: int = Field(default=0, ge=0)
    separator_evidence_truncation_count: int = Field(default=0, ge=0)
    separator_source_inventory_truncation_edge_count: int = Field(default=0, ge=0)
    separator_context_truncation_edge_count: int = Field(default=0, ge=0)
    separator_id_list_truncation_count: int = Field(default=0, ge=0)
    maximum_retained_separator_evidence_per_edge: int = Field(default=0, ge=0)
    partition_count: int = Field(default=0, ge=0)
    maximum_nodes_per_partition: int = Field(default=0, ge=0)
    refined_base_bucket_count: int = Field(default=0, ge=0)
    stage_timings: PdfLayoutStageTimingProfile = Field(
        default_factory=PdfLayoutStageTimingProfile
    )
    build_elapsed_milliseconds: float = Field(ge=0)


class PdfLayoutPageGraph(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    page_graph_id: str = Field(pattern=r"^PDFLP-[0-9a-f]{24}$")
    source_page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    page_number: int = Field(ge=1)
    canonical_width: float = Field(gt=0)
    canonical_height: float = Field(gt=0)
    rotation: Literal[0, 90, 180, 270]
    nodes: tuple[PdfLayoutNode, ...]
    edges: tuple[PdfLayoutEdge, ...]
    separator_candidates: tuple[PdfLayoutSeparatorCandidate, ...] = ()
    relation_observation: PdfLayoutRelationObservationScope = Field(
        default_factory=legacy_relation_observation_scope
    )
    quality_signals: PdfLayoutPageQualitySignals
    build_status: PdfExtractionStatus
    warnings: tuple[PdfFactWarning, ...] = ()
    resource_usage: PdfLayoutPageResourceUsage

    @model_validator(mode="after")
    def validate_graph_integrity(self) -> "PdfLayoutPageGraph":
        if self.build_status not in _ALLOWED_BUILD_STATUSES:
            raise ValueError("unsupported page graph build status")
        node_ids = [item.node_id for item in self.nodes]
        edge_ids = [item.edge_id for item in self.edges]
        separator_ids = [
            item.separator_candidate_id for item in self.separator_candidates
        ]
        if len(node_ids) != len(set(node_ids)):
            raise ValueError("page graph node IDs must be unique")
        if len(edge_ids) != len(set(edge_ids)):
            raise ValueError("page graph edge IDs must be unique")
        if len(separator_ids) != len(set(separator_ids)):
            raise ValueError("page separator candidate IDs must be unique")
        if any(item.source_page_id != self.source_page_id for item in self.nodes):
            raise ValueError("page graph nodes cannot cross source pages")
        tolerance = 1e-6
        if any(
            node.bbox.x0 < -tolerance
            or node.bbox.y0 < -tolerance
            or node.bbox.x1 > self.canonical_width + tolerance
            or node.bbox.y1 > self.canonical_height + tolerance
            for node in self.nodes
        ):
            raise ValueError("layout node bbox must remain within its canonical page")
        node_id_set = set(node_ids)
        separator_id_set = set(separator_ids)
        drawing_node_ids = {
            node.node_id for node in self.nodes if node.node_type == "drawing"
        }
        if any(
            item.drawing_node_id not in drawing_node_ids
            for item in self.separator_candidates
            if item.source_kind == "drawing_fact"
        ):
            raise ValueError("separator candidate must reference a drawing node")
        page_boundaries = tuple(
            item
            for item in self.separator_candidates
            if item.source_kind == "page_geometry"
        )
        if page_boundaries:
            if len(page_boundaries) != 4 or {
                item.page_boundary_side for item in page_boundaries
            } != {"top", "bottom", "left", "right"}:
                raise ValueError(
                    "canonical page-boundary inventory must contain every side once"
                )
            canonical_boundary_boxes = {
                "top": (0.0, 0.0, self.canonical_width, 0.0),
                "bottom": (
                    0.0,
                    self.canonical_height,
                    self.canonical_width,
                    self.canonical_height,
                ),
                "left": (0.0, 0.0, 0.0, self.canonical_height),
                "right": (
                    self.canonical_width,
                    0.0,
                    self.canonical_width,
                    self.canonical_height,
                ),
            }
            for boundary in page_boundaries:
                assert boundary.page_boundary_side is not None
                observed_bbox = (
                    boundary.bbox.x0,
                    boundary.bbox.y0,
                    boundary.bbox.x1,
                    boundary.bbox.y1,
                )
                if (
                    observed_bbox
                    != canonical_boundary_boxes[boundary.page_boundary_side]
                ):
                    raise ValueError(
                        "page-boundary bbox must match canonical page geometry"
                    )
                expected_length = (
                    self.canonical_width
                    if boundary.orientation == "horizontal"
                    else self.canonical_height
                )
                if boundary.line_length != expected_length:
                    raise ValueError(
                        "page-boundary length must match canonical page geometry"
                    )
                if boundary.page_coverage_ratio != 1:
                    raise ValueError("page-boundary coverage must be complete")
        if tuple(self.separator_candidates) != tuple(
            sorted(
                self.separator_candidates,
                key=layout_separator_sort_key,
            )
        ):
            raise ValueError("separator candidates must use deterministic order")
        edge_keys: set[tuple[str, str, str]] = set()
        for edge in self.edges:
            if (
                edge.source_node_id not in node_id_set
                or edge.target_node_id not in node_id_set
            ):
                raise ValueError("layout edge references an unknown page node")
            edge_key = (
                edge.source_node_id,
                edge.target_node_id,
                edge.relation_type,
            )
            if edge_key in edge_keys:
                raise ValueError("duplicate layout relation edge")
            edge_keys.add(edge_key)
            if any(
                separator_id not in separator_id_set
                for separator_id in edge.separator_candidate_ids
            ):
                raise ValueError("edge references an unknown separator candidate")
        if tuple(self.nodes) != tuple(sorted(self.nodes, key=layout_node_sort_key)):
            raise ValueError("layout nodes must use deterministic order")
        if tuple(self.edges) != tuple(sorted(self.edges, key=layout_edge_sort_key)):
            raise ValueError("layout edges must use deterministic order")
        if self.resource_usage.retained_node_count != len(self.nodes):
            raise ValueError("page node resource count does not match nodes")
        if self.resource_usage.retained_edge_count != len(self.edges):
            raise ValueError("page edge resource count does not match edges")
        if self.resource_usage.inferred_relation_candidate_count < (
            self.resource_usage.retained_edge_count
            + self.resource_usage.sparse_relation_suppressed_count
        ):
            raise ValueError("relation candidate retention counts are inconsistent")
        if self.resource_usage.separator_candidate_count != len(
            self.separator_candidates
        ):
            raise ValueError("page separator resource count does not match candidates")
        drawing_usage = self.resource_usage
        if drawing_usage.drawing_node_suppression_metrics_available:
            retained_drawing_count = sum(
                node.node_type == "drawing" for node in self.nodes
            )
            if drawing_usage.retained_drawing_node_count != retained_drawing_count:
                raise ValueError(
                    "retained drawing node count does not match page nodes"
                )
            if drawing_usage.source_drawing_fact_count != (
                drawing_usage.retained_drawing_node_count
                + drawing_usage.drawing_node_suppressed_count
            ):
                raise ValueError(
                    "source drawing facts must equal retained and suppressed nodes"
                )
            if drawing_usage.drawing_node_suppressed_count != sum(
                (
                    drawing_usage.near_identical_drawing_node_suppressed_count,
                    drawing_usage.repeated_decorative_drawing_node_suppressed_count,
                    drawing_usage.relation_ineligible_drawing_node_suppressed_count,
                )
            ):
                raise ValueError(
                    "drawing suppression count does not match reason inventory"
                )
            if not drawing_usage.drawing_node_suppression_policy_version:
                raise ValueError(
                    "available drawing suppression metrics require a policy version"
                )
            if drawing_usage.separator_source_drawing_fact_evaluated_count > (
                drawing_usage.source_drawing_fact_count
            ):
                raise ValueError(
                    "separator evaluation exceeds source drawing inventory"
                )
            if (
                not drawing_usage.separator_source_inventory_truncated
                and drawing_usage.separator_source_drawing_fact_evaluated_count
                != drawing_usage.source_drawing_fact_count
            ):
                raise ValueError(
                    "complete separator evaluation must cover all drawing facts"
                )
            if drawing_usage.separator_primitive_retained_count != len(
                self.separator_candidates
            ):
                raise ValueError(
                    "retained separator primitive count does not match candidates"
                )
        observation = self.relation_observation
        if observation.observation_metrics_available:
            expected_eligible_node_count = (
                sum(
                    node.node_type != "drawing" or node.drawing_kind != "line"
                    for node in self.nodes
                )
                - self.resource_usage.generic_drawing_relation_node_suppressed_count
            )
            if observation.eligible_relation_node_count != (
                expected_eligible_node_count
            ):
                raise ValueError(
                    "relation observation eligible-node count does not match nodes"
                )
            if (
                self.resource_usage.candidate_truncated_node_count
                or self.resource_usage.relation_context_truncation_count
                or self.resource_usage.relation_candidate_limit_reached
                or self.resource_usage.hard_edge_limit_reached
            ) and not observation.relation_search_truncated:
                raise ValueError(
                    "truncated relation search requires an incomplete observation scope"
                )
            if self.resource_usage.hard_edge_limit_reached and not (
                self.quality_signals.resource_truncation
            ):
                raise ValueError("hard edge loss requires resource truncation")
        if self.resource_usage.separator_candidate_quality_truncation_count != sum(
            candidate.quality_metadata_truncated
            for candidate in self.separator_candidates
        ):
            raise ValueError(
                "page separator quality truncation count does not match candidates"
            )
        separator_adjusted_relations = {
            "adjacent_horizontal",
            "adjacent_vertical",
            "same_row_candidate",
            "same_column_candidate",
        }
        if any(
            edge.separator_source_inventory_truncated
            != self.resource_usage.separator_source_inventory_truncated
            for edge in self.edges
            if edge.relation_type in separator_adjusted_relations
        ):
            raise ValueError(
                "separator-aware edges must match page source inventory completeness"
            )
        # Missing separator source geometry is hard data loss.  Bounded nearby
        # quality metadata is only an observation limitation: the separator
        # candidate inventory remains complete and exact relation pairs stay
        # queryable.  Do not promote that local top-k condition to hard page
        # resource truncation.
        if (
            self.resource_usage.separator_source_inventory_truncated
            and not self.quality_signals.resource_truncation
        ):
            raise ValueError(
                "separator source inventory truncation requires resource truncation"
            )
        if self.quality_signals.resource_truncation and self.build_status not in {
            PdfExtractionStatus.PARTIAL,
            PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED,
        }:
            raise ValueError("resource truncation requires a partial page status")
        return self


class PdfLayoutBuildResourceUsage(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    pages_attempted: int = Field(ge=0)
    pages_built: int = Field(ge=0)
    total_nodes: int = Field(ge=0)
    total_edges: int = Field(ge=0)
    total_separator_candidates: int = Field(default=0, ge=0)
    total_candidate_pairs: int = Field(ge=0)
    elapsed_milliseconds: float = Field(ge=0)


class PdfLayoutGraphArtifact(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    schema_version: Literal["pdf_layout_graph.v1"]
    layout_graph_id: str = Field(pattern=r"^PDFLG-[0-9a-f]{24}$")
    source_fact_schema_version: Literal["pdf_facts.v1", "pdf_facts.v2"]
    source_document_id: str = Field(pattern=r"^PDFD-[0-9a-f]{24}$")
    source_fact_artifact_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    source_parser_name: str = Field(min_length=1, max_length=64)
    source_parser_version: str = Field(min_length=1, max_length=64)
    graph_builder_name: str = Field(min_length=1, max_length=64)
    graph_builder_version: str = Field(min_length=1, max_length=64)
    relation_inventory_contract: PdfLayoutRelationInventoryContract = Field(
        default_factory=PdfLayoutRelationInventoryContract
    )
    built_at: AwareDatetime
    build_status: PdfExtractionStatus
    source_page_count: int = Field(ge=0)
    source_extracted_page_count: int = Field(ge=0)
    source_document_partial_extraction: bool
    graph_page_count: int = Field(ge=0)
    total_node_count: int = Field(ge=0)
    total_edge_count: int = Field(ge=0)
    total_separator_candidate_count: int = Field(default=0, ge=0)
    applied_limits: PdfLayoutGraphLimits
    build_options: PdfLayoutGraphOptions
    warnings: tuple[PdfFactWarning, ...] = ()
    warning_suppression: PdfWarningSuppressionSummary = Field(
        default_factory=PdfWarningSuppressionSummary
    )
    partial_build: bool
    graph_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    resource_usage: PdfLayoutBuildResourceUsage
    pages: tuple[PdfLayoutPageGraph, ...]

    @field_validator("built_at")
    @classmethod
    def require_timezone(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("built_at must be timezone-aware")
        return value

    @model_validator(mode="after")
    def validate_artifact_integrity(self) -> "PdfLayoutGraphArtifact":
        if self.build_status not in _ALLOWED_BUILD_STATUSES:
            raise ValueError("unsupported layout graph build status")
        if self.source_extracted_page_count > self.source_page_count:
            raise ValueError("source extracted page count exceeds source page count")
        if self.source_document_partial_extraction != (
            self.source_extracted_page_count < self.source_page_count
            or any(
                page.quality_signals.parser_quality.source_document_partial
                for page in self.pages
            )
        ):
            raise ValueError("source document partial state is inconsistent")
        if self.graph_page_count != len(self.pages):
            raise ValueError("graph page count must match page graphs")
        if self.graph_page_count > self.source_extracted_page_count:
            raise ValueError("graph page count exceeds source extracted pages")
        if self.total_node_count != sum(len(page.nodes) for page in self.pages):
            raise ValueError("total node count must match page graphs")
        if self.total_edge_count != sum(len(page.edges) for page in self.pages):
            raise ValueError("total edge count must match page graphs")
        if self.total_separator_candidate_count != sum(
            len(page.separator_candidates) for page in self.pages
        ):
            raise ValueError("total separator count must match page graphs")
        page_numbers = [page.page_number for page in self.pages]
        page_ids = [page.page_graph_id for page in self.pages]
        if page_numbers != sorted(page_numbers):
            raise ValueError("page graphs must use page-number order")
        if len(page_numbers) != len(set(page_numbers)):
            raise ValueError("page graph numbers must be unique")
        if len(page_ids) != len(set(page_ids)):
            raise ValueError("page graph IDs must be unique")
        node_ids = [node.node_id for page in self.pages for node in page.nodes]
        edge_ids = [edge.edge_id for page in self.pages for edge in page.edges]
        if len(node_ids) != len(set(node_ids)):
            raise ValueError("layout node IDs must be globally unique")
        if len(edge_ids) != len(set(edge_ids)):
            raise ValueError("layout edge IDs must be globally unique")
        if self.build_status is PdfExtractionStatus.SUCCESS:
            if self.partial_build:
                raise ValueError("successful layout graph cannot be partial")
            if self.graph_page_count != self.source_extracted_page_count:
                raise ValueError("successful layout graph requires every source page")
        if (
            self.build_status
            in {
                PdfExtractionStatus.PARTIAL,
                PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED,
            }
            and not self.partial_build
        ):
            raise ValueError("partial layout status requires partial_build")
        warning_occurrences = len(self.warnings) + sum(
            len(page.warnings) for page in self.pages
        )
        if warning_occurrences > self.applied_limits.max_warning_count:
            raise ValueError("stored layout warnings exceed the global warning limit")
        warning_limit_markers = sum(
            warning.code is PdfWarningCode.WARNING_LIMIT_REACHED
            for warning in self.warnings
        )
        if self.warning_suppression.suppressed_warning_count:
            if warning_limit_markers != 1:
                raise ValueError("warning suppression requires one artifact marker")
        elif warning_limit_markers:
            raise ValueError("warning-limit marker requires suppression summary")
        if self.resource_usage.pages_built != self.graph_page_count:
            raise ValueError("build resource page count does not match graphs")
        if self.resource_usage.total_nodes != self.total_node_count:
            raise ValueError("build resource node count does not match graphs")
        if self.resource_usage.total_edges != self.total_edge_count:
            raise ValueError("build resource edge count does not match graphs")
        if (
            self.resource_usage.total_separator_candidates
            != self.total_separator_candidate_count
        ):
            raise ValueError("build resource separator count does not match graphs")
        for page in self.pages:
            usage = page.resource_usage
            if (
                usage.maximum_directed_candidates_per_node
                > self.applied_limits.max_candidates_per_node
            ):
                raise ValueError("directed candidate count exceeds its page limit")
            if (
                usage.maximum_relation_context_nodes
                > self.applied_limits.max_intervening_candidates_per_relation
            ):
                raise ValueError("relation context exceeds its page limit")
            if usage.candidate_pair_count > (
                len(page.nodes) * self.applied_limits.max_candidates_per_node
            ):
                raise ValueError("candidate pair count exceeds its directed bound")
            if usage.relation_context_truncation_count > usage.candidate_pair_count:
                raise ValueError("relation truncation count exceeds candidate pairs")
            if (
                usage.separator_relation_query_count
                > self.applied_limits.max_separator_relation_queries_per_page
            ):
                raise ValueError(
                    "separator relation query count exceeds its page limit"
                )
            if usage.separator_relation_candidate_scan_count > (
                usage.separator_relation_query_count
                * self.applied_limits.max_separator_scans_per_relation
            ):
                raise ValueError("separator relation scans exceed their query bound")
            if usage.separator_evidence_evaluation_scan_count > (
                usage.candidate_pair_count
                * self.applied_limits.max_separator_scans_per_relation
                * 4
            ):
                raise ValueError("separator evidence scans exceed their edge bound")
            if (
                usage.maximum_retained_separator_evidence_per_edge
                > self.applied_limits.max_separator_evidence_per_edge
            ):
                raise ValueError("separator edge evidence exceeds its page limit")
            if usage.separator_relation_context_truncation_count > (
                usage.candidate_pair_count
            ):
                raise ValueError("separator context truncation exceeds candidate pairs")
            if usage.separator_evidence_truncation_count > usage.retained_edge_count:
                raise ValueError("separator evidence truncation exceeds retained edges")
            if usage.separator_candidate_quality_truncation_count > (
                usage.separator_candidate_count
            ):
                raise ValueError(
                    "separator quality truncation exceeds retained candidates"
                )
            if usage.separator_source_inventory_truncation_edge_count > (
                usage.separator_evidence_truncation_count
            ):
                raise ValueError(
                    "separator source truncation exceeds separator truncation summary"
                )
            if usage.separator_context_truncation_edge_count > (
                usage.separator_evidence_truncation_count
            ):
                raise ValueError(
                    "separator context truncation exceeds separator truncation summary"
                )
            if usage.separator_id_list_truncation_count > (
                usage.separator_evidence_truncation_count
            ):
                raise ValueError(
                    "separator ID truncation exceeds separator truncation summary"
                )
            if usage.separator_evidence_truncation_count > (
                usage.separator_source_inventory_truncation_edge_count
                + usage.separator_context_truncation_edge_count
                + usage.separator_id_list_truncation_count
            ):
                raise ValueError(
                    "separator truncation summary exceeds its component counts"
                )
            if usage.total_intervening_candidate_scans > (
                usage.candidate_pair_count
                * (
                    self.applied_limits.max_intervening_candidate_scan
                    + self.applied_limits.max_intervening_candidates_per_relation * 2
                )
            ):
                raise ValueError("intervening candidate scans exceed their bound")
        return self


def layout_node_sort_key(node: PdfLayoutNode) -> tuple[object, ...]:
    return (
        node.source_order,
        _NODE_TYPE_ORDER[node.node_type],
        round(node.bbox.y0, 6),
        round(node.bbox.x0, 6),
        round(node.bbox.y1, 6),
        round(node.bbox.x1, 6),
        node.source_fact_id,
        node.node_id,
    )


def layout_edge_sort_key(edge: PdfLayoutEdge) -> tuple[str, str, str, str]:
    return (
        edge.source_node_id,
        edge.target_node_id,
        edge.relation_type,
        edge.edge_id,
    )


def layout_separator_sort_key(
    candidate: PdfLayoutSeparatorCandidate,
) -> tuple[object, ...]:
    boundary_side_order = {
        "top": 0,
        "bottom": 1,
        "left": 2,
        "right": 3,
        None: 4,
    }
    return (
        1 if candidate.source_kind == "page_geometry" else 0,
        boundary_side_order[candidate.page_boundary_side],
        candidate.drawing_node_id or "",
        candidate.separator_candidate_id,
    )


def finite_ratio(numerator: float, denominator: float) -> float:
    if denominator <= 0:
        return 0.0
    value = numerator / denominator
    if not math.isfinite(value):
        return 0.0
    return min(1.0, max(0.0, value))

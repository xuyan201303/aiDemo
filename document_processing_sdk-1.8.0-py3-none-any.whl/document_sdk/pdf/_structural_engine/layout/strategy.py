"""Private PDF layout routing, fallback, and product selection contracts."""

# ruff: noqa: C901, D202, E501, EM101, I001, PLC0208, PLR0911, PLR0912, PLR0913, PLR0915, PLR1714, PLR2004, TRY003

import math
from typing import Any, Literal

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    SerializerFunctionWrapHandler,
    model_serializer,
    model_validator,
)

from document_sdk.pdf._structural_engine.facts.limits import (
    PdfExtractionScope,
    PdfExtractionScopeMode,
    canonical_request_scope_inventory_sha256,
)
from document_sdk.pdf._structural_engine.runtime.contracts import (
    PDF_WORKER_EXIT_CLASSIFICATIONS_BY_MODE,
    PdfWorkerExitClassification,
    PdfWorkerExitMode,
    PdfWorkerProtocolErrorReason,
)
from document_sdk.pdf._structural_engine.facts.status import (
    PdfExtractionStatus,
    PdfWarningCode,
    PdfWarningSeverity,
)
from document_sdk.pdf._structural_engine.layout.contracts import (
    PdfLayoutPageGraph,
    PdfLayoutStageTimingProfile,
)
from document_sdk.pdf._structural_engine.layout.identifiers import (
    canonical_payload_sha256,
)


PdfLayoutRoutableParser = Literal["pdfplumber", "pypdfium2"]
PdfLayoutFinalPageUsability = Literal[
    "usable_ready",
    "usable_with_limitations",
    "unusable",
]
PdfLayoutFallbackReason = Literal[
    "none",
    "source_page_unavailable",
    "source_page_partial",
    "resource_truncation",
    "bounded_observation_scope",
    "drawing_node_materialization_suppressed",
    "not_ready",
    "separator_primitive_unavailable",
    "separator_primitive_coverage_low",
    "operational_quality_below_gate",
    "parser_worker_failure",
]
PdfLayoutFallbackImprovementPrediction = Literal[
    "none",
    "parser_level_likely",
    "layout_level_only",
    "required_recovery",
]
PdfLayoutFallbackPageOutcome = Literal[
    "fallback_not_required",
    "fallback_recommended",
    "fallback_required",
    "fallback_unavailable",
    "fallback_not_applicable",
]
PdfLayoutFallbackExecutionMode = Literal[
    "none",
    "selected_pages",
    "full_document",
    "abstained",
]
PdfLayoutProductPageSelectionReason = Literal[
    "initial_route_accepted",
    "bounded_fallback_selected",
    "initial_retained_after_fallback",
    "fallback_only_available",
    "initial_only_available",
    "only_available_result",
    "page_unresolved",
]
PdfLayoutProductWorkerBatchProfile = Literal[
    "ordinary",
    "long_document",
    "drawing_heavy",
]

PDF_LAYOUT_SELECTIVE_FALLBACK_CONTRACT_VERSION: Literal[
    "pdf_layout_selective_fallback.v1"
] = "pdf_layout_selective_fallback.v1"
PDF_LAYOUT_FINAL_PAGE_SELECTION_CONTRACT_VERSION = "pdf_layout_final_page_selection.v1"

PDF_LAYOUT_OPERATIONAL_TEXT_QUALITY_CONTRACT_VERSION = (
    "pdf_layout_operational_text_quality.v1"
)
PDF_LAYOUT_RESOURCE_SEMANTICS_CONTRACT_VERSION: Literal[
    "pdf_layout_resource_semantics.v2"
] = "pdf_layout_resource_semantics.v2"
PDF_LAYOUT_FINAL_PAGE_USABILITY_CONTRACT_VERSION = "pdf_layout_final_page_usability.v1"

PDF_LAYOUT_DRAWING_POLICY_PRODUCT_EVIDENCE_CONTRACT_VERSION: Literal[
    "pdf_layout_drawing_policy_product_evidence.v1"
] = "pdf_layout_drawing_policy_product_evidence.v1"
PDF_LAYOUT_PRODUCT_CONSUMER_EVIDENCE_CONTRACT_VERSION: Literal[
    "pdf_layout_product_consumer_evidence.v1"
] = "pdf_layout_product_consumer_evidence.v1"
PDF_LAYOUT_PRODUCT_WORKER_BATCH_CONTRACT_VERSION: Literal[
    "pdf_layout_product_worker_batch.v1"
] = "pdf_layout_product_worker_batch.v1"
PDF_LAYOUT_PRODUCT_WORKER_BATCH_POLICY_CONTRACT_VERSION: Literal[
    "pdf_layout_product_worker_batch_policy.v1"
] = "pdf_layout_product_worker_batch_policy.v1"

PDF_LAYOUT_PRODUCT_WORKER_BATCH_EVIDENCE_CONTRACT_VERSION: Literal[
    "pdf_layout_product_worker_batch_evidence.v1"
] = "pdf_layout_product_worker_batch_evidence.v1"

PDF_LAYOUT_PRODUCT_STRATEGY_PHASE2H_POLICY_VERSION = "pdf_layout_parser_routing.v4"
PDF_LAYOUT_PRODUCT_STRATEGY_PHASE2I_POLICY_VERSION = "pdf_layout_parser_routing.v5"
_PDF_LAYOUT_PHASE2H_ROUTING_POLICY_FIELDS = frozenset(
    {
        "product_worker_batch_page_count",
        "ordinary_product_worker_batch_page_count",
        "long_document_product_worker_batch_page_count",
        "drawing_heavy_product_worker_batch_page_count",
        "long_document_source_size_threshold_bytes",
        "maximum_product_worker_batches_per_parser_attempt",
        "maximum_product_worker_batch_split_depth",
        "maximum_product_worker_batch_split_retry_count",
        "abstain_optional_limited_page_fallback",
        "abstain_expensive_optional_page_fallback",
    }
)
_PDF_LAYOUT_PHASE2I_ROUTING_POLICY_FIELDS = frozenset(
    {
        "abstain_layout_only_fallback",
        "product_worker_execution_strategy",
        "maximum_parallel_product_workers",
        "maximum_parallel_product_workers_per_parser",
        "aggregate_product_worker_rss_budget_bytes",
    }
)
PDF_LAYOUT_PRODUCT_GRAPH_ARTIFACT_STATUSES = frozenset(
    {"success", "partial", "resource_limit_exceeded"}
)
PDF_LAYOUT_PRODUCT_GRAPH_NO_ARTIFACT_STATUSES = frozenset({"internal_error"})
_PRODUCT_AGGREGATE_ABSOLUTE_TOLERANCE = 1e-6


class PdfLayoutParserRoutingPolicy(BaseModel):
    """Gold-free, bounded parser routing policy for a future product caller."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    contract_version: Literal[
        "pdf_layout_parser_routing.v1",
        "pdf_layout_parser_routing.v2",
        "pdf_layout_parser_routing.v3",
        "pdf_layout_parser_routing.v4",
        "pdf_layout_parser_routing.v5",
    ] = "pdf_layout_parser_routing.v3"
    long_document_page_threshold: int = Field(default=50, ge=1)
    maximum_parser_executions: Literal[2] = 2
    minimum_graph_confidence: float = Field(default=0.75, ge=0, le=1)
    minimum_node_retention: float = Field(default=0.8, ge=0, le=1)
    minimum_geometry_completeness: float = Field(default=0.8, ge=0, le=1)
    minimum_text_layer_coverage: float = Field(default=0.75, ge=0, le=1)
    minimum_text_geometry_ratio: float = Field(default=0.8, ge=0, le=1)
    minimum_separator_primitives_per_drawing: float = Field(
        default=0.05,
        ge=0,
        le=1,
    )
    minimum_drawing_count_for_coverage_gate: int = Field(default=4, ge=1)
    drawing_heavy_operation_threshold: int = Field(default=64, ge=1)
    image_heavy_operation_threshold: int = Field(default=16, ge=1)
    large_sample_content_stream_bytes: int = Field(default=2 * 1024 * 1024, ge=1)
    minimum_combined_text_coverage: float = Field(default=0.8, ge=0, le=1)
    maximum_unicode_replacement_ratio: float = Field(default=0.01, ge=0, le=1)
    maximum_fragmentation_ratio: float = Field(default=0.75, ge=0, le=1)
    maximum_spatial_conflict_ratio: float = Field(default=0.2, ge=0, le=1)
    full_document_fallback_ratio_threshold: float = Field(
        default=0.75,
        gt=0,
        le=1,
    )
    maximum_recommended_fallback_page_ratio: float = Field(
        default=0.25,
        ge=0,
        le=1,
    )
    maximum_recommended_fallback_pages: int = Field(default=32, ge=0)
    minimum_recommended_fallback_pages_to_execute: int = Field(default=2, ge=1)
    widespread_optional_fallback_abstention_ratio: float = Field(
        default=0.75,
        gt=0,
        le=1,
    )
    product_page_build_budget_milliseconds: float = Field(
        default=2_500,
        gt=0,
        le=5_000,
    )
    product_worker_batch_page_count: int = Field(default=32, ge=1, le=256)
    ordinary_product_worker_batch_page_count: int = Field(
        default=32,
        ge=1,
        le=256,
    )
    long_document_product_worker_batch_page_count: int = Field(
        default=20,
        ge=1,
        le=256,
    )
    drawing_heavy_product_worker_batch_page_count: int = Field(
        default=16,
        ge=1,
        le=256,
    )
    long_document_source_size_threshold_bytes: int = Field(
        default=64 * 1024 * 1024,
        ge=1,
    )
    maximum_product_worker_batches_per_parser_attempt: int = Field(
        default=32,
        ge=1,
        le=4_096,
    )
    maximum_product_worker_batch_split_depth: int = Field(
        default=1,
        ge=0,
        le=4,
    )
    maximum_product_worker_batch_split_retry_count: int = Field(
        default=16,
        ge=0,
        le=4_096,
    )
    abstain_optional_limited_page_fallback: bool = True
    abstain_expensive_optional_page_fallback: bool = True
    abstain_layout_only_fallback: bool = True
    product_worker_execution_strategy: Literal[
        "sequential_independent",
        "bounded_parallel",
    ] = "sequential_independent"
    maximum_parallel_product_workers: int = Field(default=1, ge=1, le=3)
    maximum_parallel_product_workers_per_parser: int = Field(
        default=1,
        ge=1,
        le=3,
    )
    aggregate_product_worker_rss_budget_bytes: int = Field(
        default=2_000_000_000,
        ge=1,
        le=2_500_000_000,
    )
    minimum_fallback_score_improvement: float = Field(default=10.0, ge=0)
    minimum_content_coverage_improvement: float = Field(default=0.05, ge=0, le=1)
    minimum_geometry_quality_improvement: float = Field(default=0.05, ge=0, le=1)

    @model_validator(mode="after")
    def validate_phase2h_batch_policy(self) -> "PdfLayoutParserRoutingPolicy":
        if self.contract_version not in {
            PDF_LAYOUT_PRODUCT_STRATEGY_PHASE2H_POLICY_VERSION,
            PDF_LAYOUT_PRODUCT_STRATEGY_PHASE2I_POLICY_VERSION,
        }:
            return self
        if self.maximum_product_worker_batch_split_retry_count > (
            self.maximum_product_worker_batches_per_parser_attempt
        ):
            raise ValueError(
                "product worker split retry limit exceeds the parser batch limit"
            )
        if self.contract_version == PDF_LAYOUT_PRODUCT_STRATEGY_PHASE2I_POLICY_VERSION:
            parallel = self.product_worker_execution_strategy == "bounded_parallel"
            if parallel != (self.maximum_parallel_product_workers > 1):
                raise ValueError(
                    "parallel worker count must match the execution strategy"
                )
            if self.maximum_parallel_product_workers_per_parser > (
                self.maximum_parallel_product_workers
            ):
                raise ValueError(
                    "per-parser parallelism exceeds the route worker limit"
                )
        return self

    @model_serializer(mode="wrap")
    def serialize_contract(
        self,
        handler: SerializerFunctionWrapHandler,
    ) -> dict[str, object]:
        payload: dict[str, object] = handler(self)
        if (
            self.contract_version != PDF_LAYOUT_PRODUCT_STRATEGY_PHASE2H_POLICY_VERSION
            and self.contract_version
            != PDF_LAYOUT_PRODUCT_STRATEGY_PHASE2I_POLICY_VERSION
        ):
            for field_name in _PDF_LAYOUT_PHASE2H_ROUTING_POLICY_FIELDS:
                payload.pop(field_name, None)
        if self.contract_version != PDF_LAYOUT_PRODUCT_STRATEGY_PHASE2I_POLICY_VERSION:
            for field_name in _PDF_LAYOUT_PHASE2I_ROUTING_POLICY_FIELDS:
                payload.pop(field_name, None)
        return payload


class PdfLayoutParserPreflight(BaseModel):
    """Sanitized metadata available before parser-specific Layout extraction."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    source_size_bytes: int = Field(ge=0)
    page_count: int = Field(ge=1)
    rotated_page_count: int | None = Field(default=None, ge=0)
    text_layer_available: bool | None = None
    drawing_heavy_signal: bool | None = None
    producer_sha256: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    sampled_page_count: int = Field(default=0, ge=0)
    sampled_visible_character_count: int = Field(default=0, ge=0)
    sampled_drawing_operation_count: int = Field(default=0, ge=0)
    sampled_image_operation_count: int = Field(default=0, ge=0)
    average_sample_content_stream_bytes: float | None = Field(default=None, ge=0)
    long_document_signal: bool | None = None
    preflight_complete: bool = True
    preflight_truncated: bool = False

    @model_validator(mode="after")
    def validate_page_counts(self) -> "PdfLayoutParserPreflight":
        if (
            self.rotated_page_count is not None
            and self.rotated_page_count > self.page_count
        ):
            raise ValueError("rotated page count cannot exceed page count")
        if self.sampled_page_count > self.page_count:
            raise ValueError("sampled page count cannot exceed page count")
        if self.preflight_complete == self.preflight_truncated:
            raise ValueError("preflight completeness and truncation must differ")
        return self


class PdfLayoutProductWorkerBatchPolicyDecision(BaseModel):
    """Sanitized, deterministic physical-batch policy for one product route."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    contract_version: Literal[
        "pdf_layout_product_worker_batch_policy.v1",
        "pdf_layout_product_worker_batch_policy.v3",
    ] = PDF_LAYOUT_PRODUCT_WORKER_BATCH_POLICY_CONTRACT_VERSION
    profile: PdfLayoutProductWorkerBatchProfile
    source_page_count: int = Field(ge=1)
    source_size_bytes: int = Field(ge=0)
    long_document_signal: bool
    drawing_heavy_signal: bool
    selected_batch_page_count: int = Field(ge=1)
    maximum_batch_page_count: int = Field(ge=1)
    maximum_worker_batch_count: int = Field(ge=1)
    maximum_batch_split_depth: int = Field(ge=0)
    maximum_batch_split_retry_count: int = Field(ge=0)
    execution_strategy: Literal[
        "sequential_independent",
        "bounded_parallel",
    ] = "sequential_independent"
    maximum_parallel_workers: int = Field(default=1, ge=1, le=3)
    maximum_parallel_workers_per_parser: int = Field(default=1, ge=1, le=3)
    aggregate_rss_budget_bytes: int = Field(
        default=2_000_000_000,
        ge=1,
        le=2_500_000_000,
    )
    repeated_document_open_profile_share: float | None = Field(
        default=None,
        ge=0,
        le=1,
    )
    persistent_parser_session_enabled: Literal[False] = False

    @model_validator(mode="after")
    def validate_decision(self) -> "PdfLayoutProductWorkerBatchPolicyDecision":
        if self.selected_batch_page_count > self.maximum_batch_page_count:
            raise ValueError("selected product worker batch size exceeds its maximum")
        if self.maximum_batch_split_retry_count > self.maximum_worker_batch_count:
            raise ValueError("split retry limit exceeds the parser batch limit")
        if self.profile == "drawing_heavy":
            if not self.drawing_heavy_signal:
                raise ValueError("drawing-heavy batch profile requires its signal")
        elif self.drawing_heavy_signal:
            raise ValueError("drawing-heavy signal must select its batch profile")
        if self.profile == "long_document":
            if not self.long_document_signal:
                raise ValueError("long-document batch profile requires its signal")
        elif self.profile == "ordinary" and self.long_document_signal:
            raise ValueError("long-document signal cannot select the ordinary profile")
        if self.contract_version == "pdf_layout_product_worker_batch_policy.v1":
            if self.execution_strategy != "sequential_independent":
                raise ValueError("legacy batch policy must remain sequential")
            if self.maximum_parallel_workers != 1:
                raise ValueError("legacy batch policy cannot use parallel workers")
        else:
            parallel = self.execution_strategy == "bounded_parallel"
            if parallel != (self.maximum_parallel_workers > 1):
                raise ValueError("parallel batch strategy is inconsistent")
            if self.maximum_parallel_workers_per_parser > self.maximum_parallel_workers:
                raise ValueError("per-parser parallelism exceeds its route limit")
        if self.persistent_parser_session_enabled:
            raise ValueError(
                "persistent parser session requires separate profile evidence"
            )
        return self

    @model_serializer(mode="wrap")
    def serialize_contract(
        self,
        handler: SerializerFunctionWrapHandler,
    ) -> dict[str, object]:
        payload: dict[str, object] = handler(self)
        if self.contract_version == "pdf_layout_product_worker_batch_policy.v1":
            for field_name in (
                "execution_strategy",
                "maximum_parallel_workers",
                "maximum_parallel_workers_per_parser",
                "aggregate_rss_budget_bytes",
                "repeated_document_open_profile_share",
                "persistent_parser_session_enabled",
            ):
                payload.pop(field_name, None)
        return payload


def select_layout_product_worker_batch_policy(
    *,
    preflight: PdfLayoutParserPreflight,
    policy: PdfLayoutParserRoutingPolicy,
    extraction_max_selected_page_count: int,
) -> PdfLayoutProductWorkerBatchPolicyDecision:
    """Select a Gold-free batch profile from bounded source/preflight facts."""

    if policy.contract_version not in {
        PDF_LAYOUT_PRODUCT_STRATEGY_PHASE2H_POLICY_VERSION,
        PDF_LAYOUT_PRODUCT_STRATEGY_PHASE2I_POLICY_VERSION,
    }:
        raise ValueError(
            "product worker batch policy requires a batched routing contract"
        )
    if extraction_max_selected_page_count < 1:
        raise ValueError("selected-page extraction limit must be positive")
    drawing_heavy = preflight.drawing_heavy_signal is True
    long_document = bool(
        preflight.page_count >= policy.long_document_page_threshold
        or preflight.long_document_signal is True
        or preflight.source_size_bytes
        >= policy.long_document_source_size_threshold_bytes
    )
    if drawing_heavy:
        profile: PdfLayoutProductWorkerBatchProfile = "drawing_heavy"
        configured_size = policy.drawing_heavy_product_worker_batch_page_count
    elif long_document:
        profile = "long_document"
        configured_size = policy.long_document_product_worker_batch_page_count
    else:
        profile = "ordinary"
        configured_size = policy.ordinary_product_worker_batch_page_count
    maximum_batch_page_count = min(
        policy.product_worker_batch_page_count,
        extraction_max_selected_page_count,
    )
    return PdfLayoutProductWorkerBatchPolicyDecision(
        contract_version=(
            "pdf_layout_product_worker_batch_policy.v3"
            if policy.contract_version
            == PDF_LAYOUT_PRODUCT_STRATEGY_PHASE2I_POLICY_VERSION
            else "pdf_layout_product_worker_batch_policy.v1"
        ),
        profile=profile,
        source_page_count=preflight.page_count,
        source_size_bytes=preflight.source_size_bytes,
        long_document_signal=long_document,
        drawing_heavy_signal=drawing_heavy,
        selected_batch_page_count=min(configured_size, maximum_batch_page_count),
        maximum_batch_page_count=maximum_batch_page_count,
        maximum_worker_batch_count=(
            policy.maximum_product_worker_batches_per_parser_attempt
        ),
        maximum_batch_split_depth=(policy.maximum_product_worker_batch_split_depth),
        maximum_batch_split_retry_count=(
            policy.maximum_product_worker_batch_split_retry_count
        ),
        execution_strategy=policy.product_worker_execution_strategy,
        maximum_parallel_workers=policy.maximum_parallel_product_workers,
        maximum_parallel_workers_per_parser=(
            policy.maximum_parallel_product_workers_per_parser
        ),
        aggregate_rss_budget_bytes=(policy.aggregate_product_worker_rss_budget_bytes),
        repeated_document_open_profile_share=None,
        persistent_parser_session_enabled=False,
    )


class PdfLayoutProductWorkerBatch(BaseModel):
    """One deterministic Worker v2 selected-page request."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    batch_index: int = Field(ge=1)
    requested_page_numbers: tuple[int, ...] = Field(min_length=1)
    requested_page_inventory_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_batch(self) -> "PdfLayoutProductWorkerBatch":
        if tuple(sorted(set(self.requested_page_numbers))) != (
            self.requested_page_numbers
        ):
            raise ValueError("product worker batch pages must be sorted and unique")
        expected_digest = canonical_request_scope_inventory_sha256(
            PdfExtractionScope(
                mode=PdfExtractionScopeMode.SELECTED_PAGES,
                requested_page_numbers=self.requested_page_numbers,
            )
        )
        if self.requested_page_inventory_sha256 != expected_digest:
            raise ValueError("product worker batch digest is inconsistent")
        return self


class PdfLayoutProductWorkerBatchPlan(BaseModel):
    """Canonical physical batches for one logical parser attempt."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    contract_version: Literal["pdf_layout_product_worker_batch.v1"] = (
        PDF_LAYOUT_PRODUCT_WORKER_BATCH_CONTRACT_VERSION
    )
    source_page_count: int = Field(ge=1)
    logical_scope_mode: Literal["full_document", "selected_pages"]
    requested_page_numbers: tuple[int, ...] = Field(min_length=1)
    maximum_batch_page_count: int = Field(ge=1)
    batches: tuple[PdfLayoutProductWorkerBatch, ...] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_plan(self) -> "PdfLayoutProductWorkerBatchPlan":
        expected_requested = (
            tuple(range(1, self.source_page_count + 1))
            if self.logical_scope_mode == "full_document"
            else self.requested_page_numbers
        )
        if tuple(sorted(set(self.requested_page_numbers))) != (
            self.requested_page_numbers
        ):
            raise ValueError("logical parser request pages must be sorted and unique")
        if self.requested_page_numbers != expected_requested:
            raise ValueError("logical parser request inventory is inconsistent")
        if any(
            page_number > self.source_page_count
            for page_number in self.requested_page_numbers
        ):
            raise ValueError("logical parser request page is outside the document")
        if tuple(batch.batch_index for batch in self.batches) != tuple(
            range(1, len(self.batches) + 1)
        ):
            raise ValueError("product worker batch indices must be contiguous")
        if any(
            len(batch.requested_page_numbers) > self.maximum_batch_page_count
            for batch in self.batches
        ):
            raise ValueError("product worker batch exceeds its page limit")
        flattened = tuple(
            page_number
            for batch in self.batches
            for page_number in batch.requested_page_numbers
        )
        if flattened != self.requested_page_numbers:
            raise ValueError("product worker batches have an overlap or gap")
        return self


def build_layout_product_worker_batch_plan(
    *,
    source_page_count: int,
    scope: PdfExtractionScope,
    maximum_batch_page_count: int,
    maximum_batch_count: int | None = None,
) -> PdfLayoutProductWorkerBatchPlan:
    """Split one logical scope into deterministic, non-overlapping batches."""

    if source_page_count < 1:
        raise ValueError("product worker batch plan requires source pages")
    if maximum_batch_page_count < 1:
        raise ValueError("product worker batch page limit must be positive")
    if maximum_batch_count is not None and maximum_batch_count < 1:
        raise ValueError("product worker batch count limit must be positive")
    requested = (
        tuple(range(1, source_page_count + 1))
        if scope.mode is PdfExtractionScopeMode.FULL_DOCUMENT
        else scope.requested_page_numbers
    )
    if not requested:
        raise ValueError("product worker batch plan requires requested pages")
    required_batch_count = math.ceil(len(requested) / maximum_batch_page_count)
    if maximum_batch_count is not None and required_batch_count > maximum_batch_count:
        raise ValueError(
            "product worker batch plan exceeds the parser attempt batch limit"
        )
    batches = tuple(
        PdfLayoutProductWorkerBatch(
            batch_index=index + 1,
            requested_page_numbers=requested[
                offset : offset + maximum_batch_page_count
            ],
            requested_page_inventory_sha256=(
                canonical_request_scope_inventory_sha256(
                    PdfExtractionScope(
                        mode=PdfExtractionScopeMode.SELECTED_PAGES,
                        requested_page_numbers=requested[
                            offset : offset + maximum_batch_page_count
                        ],
                    )
                )
            ),
        )
        for index, offset in enumerate(
            range(0, len(requested), maximum_batch_page_count)
        )
    )
    return PdfLayoutProductWorkerBatchPlan(
        source_page_count=source_page_count,
        logical_scope_mode=scope.mode.value,
        requested_page_numbers=requested,
        maximum_batch_page_count=maximum_batch_page_count,
        batches=batches,
    )


def canonical_product_worker_page_inventory_sha256(
    page_numbers: tuple[int, ...],
) -> str:
    """Digest one sanitized page inventory, including an empty inventory."""

    return canonical_payload_sha256(
        {
            "contract_version": (
                PDF_LAYOUT_PRODUCT_WORKER_BATCH_EVIDENCE_CONTRACT_VERSION
            ),
            "page_numbers": page_numbers,
        }
    )


def canonical_product_worker_batch_identity_sha256(
    *,
    source_document_sha256: str,
    parser_name: PdfLayoutRoutableParser,
    batch_index: int,
    requested_page_inventory_sha256: str,
) -> str:
    """Bind a batch identity to its source, parser, order, and request."""

    return canonical_payload_sha256(
        {
            "contract_version": (
                PDF_LAYOUT_PRODUCT_WORKER_BATCH_EVIDENCE_CONTRACT_VERSION
            ),
            "source_document_sha256": source_document_sha256,
            "parser_name": parser_name,
            "batch_index": batch_index,
            "requested_page_inventory_sha256": (requested_page_inventory_sha256),
        }
    )


class PdfLayoutProductWorkerBatchEvidence(BaseModel):
    """Sanitized result and split lineage for one physical Worker v2 call."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    batch_index: int = Field(ge=1)
    batch_identity_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    root_batch_index: int = Field(ge=1)
    root_batch_identity_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    parent_batch_index: int | None = Field(default=None, ge=1)
    parent_batch_identity_sha256: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )
    split_depth: int = Field(ge=0)
    source_document_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    parser_name: PdfLayoutRoutableParser
    physical_scope_mode: Literal["full_document", "selected_pages"]
    requested_page_numbers: tuple[int, ...] = Field(min_length=1)
    requested_page_count: int = Field(ge=1)
    requested_page_inventory_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    returned_page_numbers: tuple[int, ...] = ()
    returned_page_count: int = Field(ge=0)
    returned_page_inventory_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    missing_page_numbers: tuple[int, ...] = ()
    missing_page_count: int = Field(ge=0)
    missing_page_inventory_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    incomplete_page_numbers: tuple[int, ...] = ()
    incomplete_page_count: int = Field(default=0, ge=0)
    incomplete_page_inventory_sha256: str = Field(
        default_factory=lambda: canonical_product_worker_page_inventory_sha256(()),
        pattern=r"^[0-9a-f]{64}$",
    )
    requested_scope_complete: bool = False
    completion_status: Literal["completed", "partial", "failed"]
    worker_protocol_version: Literal[
        "pdf_layout_evaluation_worker.v1",
        "pdf_layout_evaluation_worker.v2",
    ]
    parser_version: str | None = Field(default=None, max_length=128)
    exit_mode: PdfWorkerExitMode
    exit_classification: PdfWorkerExitClassification
    error_category: str = Field(max_length=64)
    protocol_error_reason: PdfWorkerProtocolErrorReason | None = None
    elapsed_milliseconds: float = Field(ge=0)
    cpu_time_milliseconds: float | None = Field(default=None, ge=0)
    peak_rss_bytes: int | None = Field(default=None, ge=0)
    peak_python_heap_bytes: int | None = Field(default=None, ge=0)
    extracted_page_count: int = Field(ge=0)
    fact_artifact_size_bytes: int | None = Field(default=None, ge=0)
    layout_artifact_size_bytes: int | None = Field(default=None, ge=0)

    @model_validator(mode="before")
    @classmethod
    def populate_scope_evidence(cls, value: Any) -> Any:
        if not isinstance(value, dict):
            return value
        payload = dict(value)
        incomplete = tuple(payload.get("incomplete_page_numbers", ()))
        payload.setdefault("incomplete_page_count", len(incomplete))
        payload.setdefault(
            "incomplete_page_inventory_sha256",
            canonical_product_worker_page_inventory_sha256(incomplete),
        )
        payload.setdefault(
            "requested_scope_complete",
            payload.get("completion_status") == "completed",
        )
        return payload

    @model_serializer(mode="wrap")
    def serialize_python_heap_evidence(
        self,
        handler: SerializerFunctionWrapHandler,
    ) -> dict[str, object]:
        payload: dict[str, object] = handler(self)
        if self.peak_python_heap_bytes is None:
            payload.pop("peak_python_heap_bytes", None)
        return payload

    @model_validator(mode="after")
    def validate_batch_evidence(self) -> "PdfLayoutProductWorkerBatchEvidence":
        inventories = (
            self.requested_page_numbers,
            self.returned_page_numbers,
            self.missing_page_numbers,
            self.incomplete_page_numbers,
        )
        if any(tuple(sorted(set(items))) != items for items in inventories):
            raise ValueError("worker batch page inventories must be sorted and unique")
        if self.requested_page_count != len(self.requested_page_numbers):
            raise ValueError("worker batch requested page count is inconsistent")
        if self.returned_page_count != len(self.returned_page_numbers):
            raise ValueError("worker batch returned page count is inconsistent")
        if self.missing_page_count != len(self.missing_page_numbers):
            raise ValueError("worker batch missing page count is inconsistent")
        if self.incomplete_page_count != len(self.incomplete_page_numbers):
            raise ValueError("worker batch incomplete page count is inconsistent")
        scope = PdfExtractionScope(
            mode=PdfExtractionScopeMode(self.physical_scope_mode),
            requested_page_numbers=(
                self.requested_page_numbers
                if self.physical_scope_mode == "selected_pages"
                else ()
            ),
        )
        if self.requested_page_inventory_sha256 != (
            canonical_request_scope_inventory_sha256(scope)
        ):
            raise ValueError("worker batch request digest is inconsistent")
        if self.returned_page_inventory_sha256 != (
            canonical_product_worker_page_inventory_sha256(self.returned_page_numbers)
        ):
            raise ValueError("worker batch returned page digest is inconsistent")
        if self.missing_page_inventory_sha256 != (
            canonical_product_worker_page_inventory_sha256(self.missing_page_numbers)
        ):
            raise ValueError("worker batch missing page digest is inconsistent")
        if self.incomplete_page_inventory_sha256 != (
            canonical_product_worker_page_inventory_sha256(self.incomplete_page_numbers)
        ):
            raise ValueError("worker batch incomplete page digest is inconsistent")
        requested = set(self.requested_page_numbers)
        if not set(self.returned_page_numbers).issubset(requested):
            raise ValueError("worker batch returned an unrequested page")
        expected_missing = tuple(
            page_number
            for page_number in self.requested_page_numbers
            if page_number not in set(self.returned_page_numbers)
        )
        if self.missing_page_numbers != expected_missing:
            raise ValueError("worker batch missing page inventory is inconsistent")
        if not set(self.incomplete_page_numbers).issubset(self.returned_page_numbers):
            raise ValueError("worker batch incomplete page was not returned")
        expected_scope_complete = bool(
            not self.missing_page_numbers
            and not self.incomplete_page_numbers
            and self.exit_classification == "completed"
            and self.error_category == "none"
        )
        if self.requested_scope_complete != expected_scope_complete:
            raise ValueError("worker batch scope completeness is inconsistent")
        expected_status = (
            "completed"
            if self.requested_scope_complete
            else "partial"
            if self.returned_page_numbers
            else "failed"
        )
        if self.completion_status != expected_status:
            raise ValueError("worker batch completion status is inconsistent")
        if self.extracted_page_count != self.returned_page_count:
            raise ValueError("worker batch extracted page count is inconsistent")
        has_returned_artifact = bool(self.returned_page_numbers)
        if has_returned_artifact and self.parser_version is None:
            raise ValueError("worker batch parser version availability is inconsistent")
        if has_returned_artifact and self.fact_artifact_size_bytes is None:
            raise ValueError("worker batch Fact artifact evidence is inconsistent")
        if has_returned_artifact and self.layout_artifact_size_bytes is None:
            raise ValueError("worker batch Layout artifact evidence is inconsistent")
        if (
            self.exit_classification
            not in (PDF_WORKER_EXIT_CLASSIFICATIONS_BY_MODE[self.exit_mode])
        ):
            raise ValueError("worker batch exit outcome is inconsistent")
        protocol_error = self.exit_mode == "protocol_error"
        if protocol_error != (self.protocol_error_reason is not None):
            raise ValueError("worker batch protocol error evidence is inconsistent")
        if protocol_error != (self.error_category == "worker_protocol_error"):
            raise ValueError("worker batch protocol error category is inconsistent")
        expected_identity = canonical_product_worker_batch_identity_sha256(
            source_document_sha256=self.source_document_sha256,
            parser_name=self.parser_name,
            batch_index=self.batch_index,
            requested_page_inventory_sha256=(self.requested_page_inventory_sha256),
        )
        if self.batch_identity_sha256 != expected_identity:
            raise ValueError("worker batch identity is inconsistent")
        if (self.parent_batch_index is None) != (
            self.parent_batch_identity_sha256 is None
        ):
            raise ValueError("worker batch parent identity must be paired")
        if self.split_depth == 0:
            if self.parent_batch_index is not None:
                raise ValueError("root worker batch cannot have a parent")
            if self.root_batch_index != self.batch_index:
                raise ValueError("root worker batch index is inconsistent")
            if self.root_batch_identity_sha256 != self.batch_identity_sha256:
                raise ValueError("root worker batch identity is inconsistent")
        elif self.parent_batch_index is None:
            raise ValueError("split worker batch requires a parent")
        return self


def product_worker_batch_is_hard_failed(
    batch: PdfLayoutProductWorkerBatchEvidence,
) -> bool:
    """Return whether a physical batch failed its process/safety contract.

    A completed batch that returned every requested page may remain typed
    partial.  That is scope-incomplete evidence, but it is not a worker
    process failure.  Missing pages and every non-completed/error/protocol
    outcome remain fail-closed hard failures.
    """

    return bool(
        batch.exit_classification != "completed"
        or batch.exit_mode != "completed"
        or batch.error_category != "none"
        or batch.protocol_error_reason is not None
        or batch.missing_page_numbers
    )


def product_worker_batch_is_typed_partial(
    batch: PdfLayoutProductWorkerBatchEvidence,
) -> bool:
    """Return whether a safe completed batch retained typed partial pages."""

    return bool(
        not product_worker_batch_is_hard_failed(batch)
        and batch.incomplete_page_numbers
        and not batch.requested_scope_complete
        and batch.completion_status == "partial"
    )


def count_hard_failed_product_worker_batches(
    batches: tuple[PdfLayoutProductWorkerBatchEvidence, ...],
) -> int:
    """Count only physical batches that failed the process/safety contract."""

    return sum(product_worker_batch_is_hard_failed(batch) for batch in batches)


def _terminal_failed_product_worker_pages(
    batches: tuple[PdfLayoutProductWorkerBatchEvidence, ...],
) -> tuple[int, ...]:
    parent_indices = {
        batch.parent_batch_index
        for batch in batches
        if batch.parent_batch_index is not None
    }
    return tuple(
        sorted(
            {
                page_number
                for batch in batches
                if batch.batch_index not in parent_indices
                for page_number in batch.missing_page_numbers
            }
        )
    )


class PdfLayoutProductSourceLimitation(BaseModel):
    """Sanitized typed source-page limitation retained by Product evidence."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    code: PdfWarningCode
    severity: PdfWarningSeverity
    recoverable: bool
    missing_fact_categories: tuple[
        Literal["text", "characters", "drawings", "image_regions"], ...
    ] = ()

    @model_validator(mode="after")
    def validate_missing_categories(self) -> "PdfLayoutProductSourceLimitation":
        if tuple(sorted(set(self.missing_fact_categories))) != (
            self.missing_fact_categories
        ):
            raise ValueError("source limitation categories must be canonical")
        return self


class PdfLayoutProductWorkerBatchExecutionEvidence(BaseModel):
    """Fail-closed physical-batch evidence for one logical parser attempt."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    contract_version: Literal[
        "pdf_layout_product_worker_batch_evidence.v1",
        "pdf_layout_product_worker_batch_evidence.v2",
    ] = PDF_LAYOUT_PRODUCT_WORKER_BATCH_EVIDENCE_CONTRACT_VERSION
    source_document_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    source_page_count: int = Field(ge=1)
    parser_name: PdfLayoutRoutableParser
    logical_scope_mode: Literal["full_document", "selected_pages"]
    logical_requested_page_numbers: tuple[int, ...] = Field(min_length=1)
    logical_requested_page_count: int = Field(ge=1)
    logical_requested_page_inventory_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    maximum_batch_page_count: int = Field(ge=1)
    maximum_worker_batch_count: int = Field(ge=1)
    maximum_batch_split_depth: int = Field(ge=0)
    maximum_batch_split_retry_count: int = Field(ge=0)
    sequential_execution: bool = True
    execution_strategy: Literal[
        "sequential_independent",
        "bounded_parallel",
    ] = "sequential_independent"
    maximum_parallel_workers: int = Field(default=1, ge=1, le=3)
    rss_throttled: bool = False
    actual_wall_clock_elapsed_milliseconds: float | None = Field(
        default=None,
        ge=0,
    )
    combined_child_peak_rss_bytes: int | None = Field(default=None, ge=0)
    parent_process_peak_rss_bytes: int | None = Field(default=None, ge=0)
    parent_rss_at_combined_peak_bytes: int | None = Field(default=None, ge=0)
    combined_process_peak_rss_bytes: int | None = Field(default=None, ge=0)
    rss_measurement_semantics: (
        Literal["time_aligned_parent_and_live_child_rss_polling"] | None
    ) = None
    rss_sample_interval_seconds: float | None = Field(default=None, gt=0)
    rss_sample_count: int | None = Field(default=None, ge=1)
    peak_concurrent_worker_count: int | None = Field(default=None, ge=1, le=3)
    maximum_observed_concurrent_worker_count: int | None = Field(
        default=None,
        ge=1,
        le=3,
    )
    combined_child_peak_python_heap_bytes: int | None = Field(default=None, ge=0)
    python_heap_measurement_semantics: (
        Literal["sum_largest_possible_concurrent_worker_peaks_upper_bound"] | None
    ) = None
    aggregate_rss_budget_bytes: int | None = Field(default=None, ge=1)
    rss_budget_violation: bool | None = None
    batch_plan: PdfLayoutProductWorkerBatchPlan
    batches: tuple[PdfLayoutProductWorkerBatchEvidence, ...] = Field(min_length=1)
    successful_worker_batch_count: int = Field(ge=0)
    failed_worker_batch_count: int = Field(ge=0)
    typed_partial_worker_batch_count: int = Field(default=0, ge=0)
    hard_failed_worker_batch_count: int = Field(default=0, ge=0)
    scope_complete_worker_batch_count: int = Field(default=0, ge=0)
    split_retry_worker_batch_count: int = Field(ge=0)
    maximum_observed_batch_page_count: int = Field(ge=1)
    maximum_observed_batch_split_depth: int = Field(ge=0)
    returned_page_numbers: tuple[int, ...] = ()
    returned_page_count: int = Field(ge=0)
    returned_page_inventory_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    failed_page_numbers: tuple[int, ...] = ()
    failed_page_count: int = Field(ge=0)
    failed_page_inventory_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    incomplete_page_numbers: tuple[int, ...] = ()
    incomplete_page_count: int = Field(default=0, ge=0)
    incomplete_page_inventory_sha256: str = Field(
        default_factory=lambda: canonical_product_worker_page_inventory_sha256(()),
        pattern=r"^[0-9a-f]{64}$",
    )

    @model_validator(mode="before")
    @classmethod
    def migrate_legacy_typed_batch_counters(cls, value: Any) -> Any:
        """Derive append-only typed counters when reading pre-Cluster-A evidence."""

        if not isinstance(value, dict) or any(
            name in value
            for name in (
                "typed_partial_worker_batch_count",
                "hard_failed_worker_batch_count",
                "scope_complete_worker_batch_count",
            )
        ):
            return value
        payload = dict(value)
        batches = tuple(
            item for item in payload.get("batches", ()) if isinstance(item, dict)
        )

        def hard_failed(item: dict[str, Any]) -> bool:
            return bool(
                item.get("exit_classification") != "completed"
                or item.get("exit_mode") != "completed"
                or item.get("error_category") != "none"
                or item.get("protocol_error_reason") is not None
                or item.get("missing_page_numbers")
            )

        hard_count = sum(hard_failed(item) for item in batches)
        partial_count = sum(
            not hard_failed(item)
            and bool(item.get("incomplete_page_numbers"))
            and not bool(item.get("requested_scope_complete"))
            and item.get("completion_status") == "partial"
            for item in batches
        )
        complete_count = sum(
            item.get("completion_status") == "completed" for item in batches
        )
        payload["typed_partial_worker_batch_count"] = partial_count
        payload["hard_failed_worker_batch_count"] = hard_count
        payload["scope_complete_worker_batch_count"] = complete_count
        payload["failed_worker_batch_count"] = hard_count
        return payload

    @model_validator(mode="after")
    def validate_execution_evidence(
        self,
    ) -> "PdfLayoutProductWorkerBatchExecutionEvidence":
        if self.contract_version == "pdf_layout_product_worker_batch_evidence.v1":
            if not self.sequential_execution:
                raise ValueError("legacy worker batch evidence must be sequential")
            if self.execution_strategy != "sequential_independent":
                raise ValueError("legacy worker batch strategy changed")
            if self.maximum_parallel_workers != 1:
                raise ValueError("legacy worker batch parallelism changed")
        else:
            parallel = self.execution_strategy == "bounded_parallel"
            if not parallel and self.maximum_parallel_workers != 1:
                raise ValueError("sequential strategy cannot allow parallel workers")
            if self.rss_throttled and not parallel:
                raise ValueError("RSS throttle requires a bounded-parallel policy")
            if self.actual_wall_clock_elapsed_milliseconds is None:
                raise ValueError("Phase 2I batch evidence requires wall-clock timing")
            if self.combined_child_peak_rss_bytes is None:
                raise ValueError("Phase 2I batch evidence requires combined child RSS")
            if self.parent_process_peak_rss_bytes is None:
                raise ValueError("Phase 2I batch evidence requires parent process RSS")
            if self.parent_rss_at_combined_peak_bytes is None:
                raise ValueError(
                    "Phase 2I batch evidence requires time-aligned parent RSS"
                )
            if self.combined_process_peak_rss_bytes is None:
                raise ValueError(
                    "Phase 2I batch evidence requires combined process RSS"
                )
            if self.rss_measurement_semantics is None:
                raise ValueError("Phase 2I batch evidence requires RSS semantics")
            if self.rss_sample_interval_seconds is None:
                raise ValueError("Phase 2I batch evidence requires an RSS interval")
            if self.rss_sample_count is None:
                raise ValueError("Phase 2I batch evidence requires RSS samples")
            if self.peak_concurrent_worker_count is None:
                raise ValueError(
                    "Phase 2I batch evidence requires observed concurrency"
                )
            if self.maximum_observed_concurrent_worker_count is None:
                raise ValueError(
                    "Phase 2I batch evidence requires maximum observed concurrency"
                )
            if self.sequential_execution != (
                self.maximum_observed_concurrent_worker_count == 1
            ):
                raise ValueError("worker batch actual concurrency is inconsistent")
            if (
                self.maximum_observed_concurrent_worker_count
                > self.maximum_parallel_workers
            ):
                raise ValueError("observed concurrency exceeds its worker limit")
            if self.peak_concurrent_worker_count > self.maximum_parallel_workers:
                raise ValueError("observed RSS concurrency exceeds its worker limit")
            if (
                self.peak_concurrent_worker_count
                > self.maximum_observed_concurrent_worker_count
            ):
                raise ValueError(
                    "RSS-peak concurrency exceeds maximum observed concurrency"
                )
            if self.aggregate_rss_budget_bytes is None:
                raise ValueError("Phase 2I batch evidence requires its RSS budget")
            if self.rss_budget_violation is None:
                raise ValueError(
                    "Phase 2I batch evidence requires an RSS budget result"
                )
            if self.combined_process_peak_rss_bytes != (
                self.combined_child_peak_rss_bytes
                + self.parent_rss_at_combined_peak_bytes
            ):
                raise ValueError(
                    "combined process RSS must equal time-aligned child and parent evidence"
                )
            if (
                self.parent_process_peak_rss_bytes
                < self.parent_rss_at_combined_peak_bytes
            ):
                raise ValueError("parent RSS peak is below its combined-peak sample")
            if self.rss_budget_violation != (
                self.combined_process_peak_rss_bytes > self.aggregate_rss_budget_bytes
            ):
                raise ValueError("RSS budget result is inconsistent")
            heap_values = sorted(
                (
                    batch.peak_python_heap_bytes
                    for batch in self.batches
                    if batch.peak_python_heap_bytes is not None
                ),
                reverse=True,
            )
            expected_heap = (
                sum(heap_values[: self.maximum_observed_concurrent_worker_count])
                if heap_values
                else None
            )
            if self.combined_child_peak_python_heap_bytes != expected_heap:
                raise ValueError("combined child Python heap evidence is inconsistent")
            if (self.python_heap_measurement_semantics is not None) != bool(
                heap_values
            ):
                raise ValueError("Python heap measurement semantics are incomplete")
        if tuple(batch.batch_index for batch in self.batches) != tuple(
            range(1, len(self.batches) + 1)
        ):
            raise ValueError("worker batch evidence order is not contiguous")
        if len(self.batches) > self.maximum_worker_batch_count:
            raise ValueError("worker batch evidence exceeds its execution limit")
        if self.batch_plan.source_page_count != self.source_page_count:
            raise ValueError("worker batch plan source inventory is inconsistent")
        if self.batch_plan.logical_scope_mode != self.logical_scope_mode:
            raise ValueError("worker batch plan logical scope is inconsistent")
        if self.batch_plan.requested_page_numbers != (
            self.logical_requested_page_numbers
        ):
            raise ValueError("worker batch plan request inventory is inconsistent")
        if self.batch_plan.maximum_batch_page_count != (self.maximum_batch_page_count):
            raise ValueError("worker batch plan page limit is inconsistent")
        if self.logical_requested_page_count != len(
            self.logical_requested_page_numbers
        ):
            raise ValueError("logical worker request page count is inconsistent")
        logical_scope = PdfExtractionScope(
            mode=PdfExtractionScopeMode(self.logical_scope_mode),
            requested_page_numbers=(
                self.logical_requested_page_numbers
                if self.logical_scope_mode == "selected_pages"
                else ()
            ),
        )
        if self.logical_requested_page_inventory_sha256 != (
            canonical_request_scope_inventory_sha256(logical_scope)
        ):
            raise ValueError("logical worker request digest is inconsistent")
        by_index = {batch.batch_index: batch for batch in self.batches}
        roots = tuple(
            batch for batch in self.batches if batch.parent_batch_index is None
        )
        if tuple(batch.requested_page_numbers for batch in roots) != tuple(
            batch.requested_page_numbers for batch in self.batch_plan.batches
        ):
            raise ValueError("worker root batches do not match the batch plan")
        children_by_parent: dict[int, list[PdfLayoutProductWorkerBatchEvidence]] = {}
        for batch in self.batches:
            if batch.parser_name != self.parser_name:
                raise ValueError("worker batch parser identity changed")
            if batch.source_document_sha256 != self.source_document_sha256:
                raise ValueError("worker batch source identity changed")
            if batch.requested_page_count > self.maximum_batch_page_count:
                raise ValueError("worker batch request exceeds its page limit")
            if batch.split_depth > self.maximum_batch_split_depth:
                raise ValueError("worker batch split depth exceeds its limit")
            if batch.parent_batch_index is None:
                continue
            parent = by_index.get(batch.parent_batch_index)
            root = by_index.get(batch.root_batch_index)
            if parent is None or parent.batch_index >= batch.batch_index:
                raise ValueError("worker batch parent identity is invalid")
            if root is None or root.parent_batch_index is not None:
                raise ValueError("worker batch root identity is invalid")
            if batch.parent_batch_identity_sha256 != (parent.batch_identity_sha256):
                raise ValueError("worker batch parent digest is inconsistent")
            if batch.root_batch_identity_sha256 != root.batch_identity_sha256:
                raise ValueError("worker batch root digest is inconsistent")
            if parent.root_batch_index != batch.root_batch_index:
                raise ValueError("worker batch root lineage changed")
            if batch.split_depth != parent.split_depth + 1:
                raise ValueError("worker batch split depth is inconsistent")
            children_by_parent.setdefault(parent.batch_index, []).append(batch)
        if len(self.batches) - len(roots) > (self.maximum_batch_split_retry_count):
            raise ValueError("worker batch split retry count exceeds its limit")
        for parent_index, children in children_by_parent.items():
            parent = by_index[parent_index]
            if len(children) != 2:
                raise ValueError("worker batch split must have exactly two children")
            child_pages = tuple(
                page_number
                for child in children
                for page_number in child.requested_page_numbers
            )
            if child_pages != parent.missing_page_numbers:
                raise ValueError("worker batch children do not partition missing pages")

        expected_order: list[int] = []

        def append_preorder(batch: PdfLayoutProductWorkerBatchEvidence) -> None:
            expected_order.append(batch.batch_index)
            for child in children_by_parent.get(batch.batch_index, []):
                append_preorder(child)

        for root in roots:
            append_preorder(root)
        if tuple(expected_order) != tuple(batch.batch_index for batch in self.batches):
            raise ValueError("worker batch execution is not deterministic preorder")
        returned_flat = tuple(
            page_number
            for batch in self.batches
            for page_number in batch.returned_page_numbers
        )
        if len(returned_flat) != len(set(returned_flat)):
            raise ValueError("worker batch evidence returned a duplicate page")
        expected_returned = tuple(sorted(returned_flat))
        expected_failed = _terminal_failed_product_worker_pages(self.batches)
        expected_incomplete = tuple(
            sorted(
                {
                    page_number
                    for batch in self.batches
                    for page_number in batch.incomplete_page_numbers
                }
            )
        )
        if tuple(sorted(set(self.returned_page_numbers))) != (
            self.returned_page_numbers
        ):
            raise ValueError("aggregate returned page inventory is not canonical")
        if self.returned_page_numbers != expected_returned:
            raise ValueError("aggregate returned page inventory is inconsistent")
        if self.failed_page_numbers != expected_failed:
            raise ValueError("aggregate failed page inventory is inconsistent")
        if self.incomplete_page_numbers != expected_incomplete:
            raise ValueError("aggregate incomplete page inventory is inconsistent")
        if (
            tuple(sorted((*self.returned_page_numbers, *self.failed_page_numbers)))
            != self.logical_requested_page_numbers
        ):
            raise ValueError("worker batch final page inventory is incomplete")
        expected_successful = sum(
            batch.completion_status == "completed" for batch in self.batches
        )
        if self.successful_worker_batch_count != expected_successful:
            raise ValueError("successful worker batch count is inconsistent")
        expected_typed_partial = sum(
            product_worker_batch_is_typed_partial(batch) for batch in self.batches
        )
        expected_hard_failed = count_hard_failed_product_worker_batches(self.batches)
        if self.typed_partial_worker_batch_count != expected_typed_partial:
            raise ValueError("typed partial worker batch count is inconsistent")
        if self.hard_failed_worker_batch_count != expected_hard_failed:
            raise ValueError("hard failed worker batch count is inconsistent")
        if self.failed_worker_batch_count != expected_hard_failed:
            raise ValueError("failed worker batch count is inconsistent")
        if self.scope_complete_worker_batch_count != expected_successful:
            raise ValueError("scope complete worker batch count is inconsistent")
        expected_split_retries = len(self.batches) - len(roots)
        if self.split_retry_worker_batch_count != expected_split_retries:
            raise ValueError("split retry worker batch count is inconsistent")
        if self.maximum_observed_batch_page_count != max(
            batch.requested_page_count for batch in self.batches
        ):
            raise ValueError("maximum observed worker batch size is inconsistent")
        if self.maximum_observed_batch_split_depth != max(
            batch.split_depth for batch in self.batches
        ):
            raise ValueError("maximum observed split depth is inconsistent")
        if self.returned_page_count != len(self.returned_page_numbers):
            raise ValueError("aggregate returned page count is inconsistent")
        if self.returned_page_inventory_sha256 != (
            canonical_product_worker_page_inventory_sha256(self.returned_page_numbers)
        ):
            raise ValueError("aggregate returned page digest is inconsistent")
        if self.failed_page_count != len(self.failed_page_numbers):
            raise ValueError("aggregate failed page count is inconsistent")
        if self.failed_page_inventory_sha256 != (
            canonical_product_worker_page_inventory_sha256(self.failed_page_numbers)
        ):
            raise ValueError("aggregate failed page digest is inconsistent")
        if self.incomplete_page_count != len(self.incomplete_page_numbers):
            raise ValueError("aggregate incomplete page count is inconsistent")
        if self.incomplete_page_inventory_sha256 != (
            canonical_product_worker_page_inventory_sha256(self.incomplete_page_numbers)
        ):
            raise ValueError("aggregate incomplete page digest is inconsistent")
        return self

    @model_serializer(mode="wrap")
    def serialize_execution_contract(
        self,
        handler: SerializerFunctionWrapHandler,
    ) -> dict[str, object]:
        payload: dict[str, object] = handler(self)
        if self.contract_version == "pdf_layout_product_worker_batch_evidence.v1":
            for field_name in (
                "execution_strategy",
                "maximum_parallel_workers",
                "rss_throttled",
                "actual_wall_clock_elapsed_milliseconds",
                "combined_child_peak_rss_bytes",
                "parent_process_peak_rss_bytes",
                "parent_rss_at_combined_peak_bytes",
                "combined_process_peak_rss_bytes",
                "rss_measurement_semantics",
                "rss_sample_interval_seconds",
                "rss_sample_count",
                "peak_concurrent_worker_count",
                "maximum_observed_concurrent_worker_count",
                "combined_child_peak_python_heap_bytes",
                "python_heap_measurement_semantics",
                "aggregate_rss_budget_bytes",
                "rss_budget_violation",
            ):
                payload.pop(field_name, None)
        return payload


def build_layout_product_worker_batch_execution_evidence(
    *,
    source_document_sha256: str,
    source_page_count: int,
    parser_name: PdfLayoutRoutableParser,
    logical_scope: PdfExtractionScope,
    maximum_batch_page_count: int,
    maximum_worker_batch_count: int,
    maximum_batch_split_depth: int,
    maximum_batch_split_retry_count: int,
    batch_plan: PdfLayoutProductWorkerBatchPlan,
    batches: tuple[PdfLayoutProductWorkerBatchEvidence, ...],
    contract_version: Literal[
        "pdf_layout_product_worker_batch_evidence.v1",
        "pdf_layout_product_worker_batch_evidence.v2",
    ] = PDF_LAYOUT_PRODUCT_WORKER_BATCH_EVIDENCE_CONTRACT_VERSION,
    execution_strategy: Literal[
        "sequential_independent",
        "bounded_parallel",
    ] = "sequential_independent",
    maximum_parallel_workers: int = 1,
    rss_throttled: bool = False,
    actual_wall_clock_elapsed_milliseconds: float | None = None,
    combined_child_peak_rss_bytes: int | None = None,
    parent_process_peak_rss_bytes: int | None = None,
    parent_rss_at_combined_peak_bytes: int | None = None,
    combined_process_peak_rss_bytes: int | None = None,
    rss_measurement_semantics: Literal["time_aligned_parent_and_live_child_rss_polling"]
    | None = None,
    rss_sample_interval_seconds: float | None = None,
    rss_sample_count: int | None = None,
    peak_concurrent_worker_count: int | None = None,
    maximum_observed_concurrent_worker_count: int | None = None,
    aggregate_rss_budget_bytes: int | None = None,
    rss_budget_violation: bool | None = None,
) -> PdfLayoutProductWorkerBatchExecutionEvidence:
    returned_pages = tuple(
        sorted(
            page_number
            for batch in batches
            for page_number in batch.returned_page_numbers
        )
    )
    failed_pages = _terminal_failed_product_worker_pages(batches)
    incomplete_pages = tuple(
        sorted(
            {
                page_number
                for batch in batches
                for page_number in batch.incomplete_page_numbers
            }
        )
    )
    logical_requested_pages = (
        tuple(range(1, source_page_count + 1))
        if logical_scope.mode is PdfExtractionScopeMode.FULL_DOCUMENT
        else logical_scope.requested_page_numbers
    )
    return PdfLayoutProductWorkerBatchExecutionEvidence(
        contract_version=contract_version,
        source_document_sha256=source_document_sha256,
        source_page_count=source_page_count,
        parser_name=parser_name,
        logical_scope_mode=logical_scope.mode.value,
        logical_requested_page_numbers=logical_requested_pages,
        logical_requested_page_count=len(logical_requested_pages),
        logical_requested_page_inventory_sha256=(
            canonical_request_scope_inventory_sha256(logical_scope)
        ),
        maximum_batch_page_count=maximum_batch_page_count,
        maximum_worker_batch_count=maximum_worker_batch_count,
        maximum_batch_split_depth=maximum_batch_split_depth,
        maximum_batch_split_retry_count=maximum_batch_split_retry_count,
        sequential_execution=(
            execution_strategy == "sequential_independent"
            or maximum_observed_concurrent_worker_count == 1
        ),
        execution_strategy=execution_strategy,
        maximum_parallel_workers=maximum_parallel_workers,
        rss_throttled=rss_throttled,
        actual_wall_clock_elapsed_milliseconds=(actual_wall_clock_elapsed_milliseconds),
        combined_child_peak_rss_bytes=combined_child_peak_rss_bytes,
        parent_process_peak_rss_bytes=parent_process_peak_rss_bytes,
        parent_rss_at_combined_peak_bytes=parent_rss_at_combined_peak_bytes,
        combined_process_peak_rss_bytes=combined_process_peak_rss_bytes,
        rss_measurement_semantics=rss_measurement_semantics,
        rss_sample_interval_seconds=rss_sample_interval_seconds,
        rss_sample_count=rss_sample_count,
        peak_concurrent_worker_count=peak_concurrent_worker_count,
        maximum_observed_concurrent_worker_count=(
            maximum_observed_concurrent_worker_count
        ),
        combined_child_peak_python_heap_bytes=(
            sum(
                sorted(
                    (
                        batch.peak_python_heap_bytes
                        for batch in batches
                        if batch.peak_python_heap_bytes is not None
                    ),
                    reverse=True,
                )[: maximum_observed_concurrent_worker_count or 1]
            )
            if contract_version == "pdf_layout_product_worker_batch_evidence.v2"
            and any(batch.peak_python_heap_bytes is not None for batch in batches)
            else None
        ),
        python_heap_measurement_semantics=(
            "sum_largest_possible_concurrent_worker_peaks_upper_bound"
            if contract_version == "pdf_layout_product_worker_batch_evidence.v2"
            and any(batch.peak_python_heap_bytes is not None for batch in batches)
            else None
        ),
        aggregate_rss_budget_bytes=aggregate_rss_budget_bytes,
        rss_budget_violation=rss_budget_violation,
        batch_plan=batch_plan,
        batches=batches,
        successful_worker_batch_count=sum(
            batch.completion_status == "completed" for batch in batches
        ),
        failed_worker_batch_count=count_hard_failed_product_worker_batches(batches),
        typed_partial_worker_batch_count=sum(
            product_worker_batch_is_typed_partial(batch) for batch in batches
        ),
        hard_failed_worker_batch_count=count_hard_failed_product_worker_batches(
            batches
        ),
        scope_complete_worker_batch_count=sum(
            batch.completion_status == "completed" for batch in batches
        ),
        split_retry_worker_batch_count=sum(batch.split_depth > 0 for batch in batches),
        maximum_observed_batch_page_count=max(
            batch.requested_page_count for batch in batches
        ),
        maximum_observed_batch_split_depth=max(batch.split_depth for batch in batches),
        returned_page_numbers=returned_pages,
        returned_page_count=len(returned_pages),
        returned_page_inventory_sha256=(
            canonical_product_worker_page_inventory_sha256(returned_pages)
        ),
        failed_page_numbers=failed_pages,
        failed_page_count=len(failed_pages),
        failed_page_inventory_sha256=(
            canonical_product_worker_page_inventory_sha256(failed_pages)
        ),
        incomplete_page_numbers=incomplete_pages,
        incomplete_page_count=len(incomplete_pages),
        incomplete_page_inventory_sha256=(
            canonical_product_worker_page_inventory_sha256(incomplete_pages)
        ),
    )


class PdfLayoutOperationalQualitySignal(BaseModel):
    """Gold-independent evidence produced after one parser execution."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    parser_name: PdfLayoutRoutableParser | None = None
    operational_text_quality_contract_version: str | None = None
    layout_policy_evidence_contract_version: (
        Literal["pdf_layout_drawing_policy_product_evidence.v1"] | None
    ) = None
    layout_policy_only: bool = False
    layout_policy_reason: Literal["drawing_node_materialization_suppressed"] | None = (
        None
    )
    source_page_available: bool
    source_page_success: bool
    resource_truncation: bool
    hard_resource_truncation: bool | None = None
    readiness_outcome: Literal[
        "ready",
        "ready_with_limitations",
        "not_ready",
        "unavailable",
    ]
    graph_confidence: float | None = Field(default=None, ge=0, le=1)
    node_retention: float | None = Field(default=None, ge=0, le=1)
    geometry_completeness: float | None = Field(default=None, ge=0, le=1)
    text_layer_coverage: float | None = Field(default=None, ge=0, le=1)
    text_geometry_ratio: float | None = Field(default=None, ge=0, le=1)
    drawing_node_ratio: float | None = Field(default=None, ge=0, le=1)
    drawing_node_count: int | None = Field(default=None, ge=0)
    separator_candidate_count: int | None = Field(default=None, ge=0)
    separator_primitives_per_drawing: float | None = Field(
        default=None,
        ge=0,
    )
    normalized_visible_text_sha256: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )
    normalized_visible_character_count: int | None = Field(default=None, ge=0)
    distinct_spatial_text_region_count: int | None = Field(default=None, ge=0)
    parser_visible_text_fact_count: int | None = Field(default=None, ge=0)
    primary_visible_character_count: int | None = Field(default=None, ge=0)
    supplemental_visible_character_count: int | None = Field(default=None, ge=0)
    primary_text_region_count: int | None = Field(default=None, ge=0)
    supplemental_text_region_count: int | None = Field(default=None, ge=0)
    text_region_coverage: float | None = Field(default=None, ge=0, le=1)
    combined_text_coverage: float | None = Field(default=None, ge=0, le=1)
    supplemental_text_node_count: int | None = Field(default=None, ge=0)
    unicode_replacement_ratio: float | None = Field(default=None, ge=0, le=1)
    fragmentation_ratio: float | None = Field(default=None, ge=0, le=1)
    spatial_duplicate_ratio: float | None = Field(default=None, ge=0, le=1)
    spatial_conflict_ratio: float | None = Field(default=None, ge=0, le=1)
    warning_severity_score: float = Field(default=0, ge=0)

    @model_validator(mode="after")
    def validate_layout_policy_signal(self) -> "PdfLayoutOperationalQualitySignal":
        evidence_available = self.layout_policy_evidence_contract_version is not None
        if not evidence_available and (
            self.layout_policy_only or self.layout_policy_reason is not None
        ):
            raise ValueError("Layout-policy signal requires typed product evidence")
        if self.layout_policy_only != (self.layout_policy_reason is not None):
            raise ValueError("Layout-policy-only signal and reason are inconsistent")
        if self.layout_policy_only and (
            self.readiness_outcome != "ready_with_limitations"
            or self.hard_resource_truncation is not False
        ):
            raise ValueError(
                "Layout-policy-only limitation must remain usable without hard loss"
            )
        return self

    @model_serializer(mode="wrap")
    def serialize_layout_policy_signal(
        self,
        handler: SerializerFunctionWrapHandler,
    ) -> dict[str, object]:
        payload: dict[str, object] = handler(self)
        if self.layout_policy_evidence_contract_version is None:
            payload.pop("layout_policy_evidence_contract_version", None)
            payload.pop("layout_policy_only", None)
            payload.pop("layout_policy_reason", None)
        return payload


class PdfLayoutDrawingMaterializationEvidence(BaseModel):
    """Sanitized Product evidence for deterministic drawing-node policy."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    contract_version: Literal["pdf_layout_drawing_policy_product_evidence.v1"] = (
        PDF_LAYOUT_DRAWING_POLICY_PRODUCT_EVIDENCE_CONTRACT_VERSION
    )
    source_drawing_fact_count: int = Field(ge=0)
    retained_drawing_node_count: int = Field(ge=0)
    suppressed_drawing_node_count: int = Field(ge=0)
    drawing_materialization_policy_version: str = Field(min_length=1, max_length=128)
    near_identical_suppressed_count: int = Field(ge=0)
    repeated_decorative_suppressed_count: int = Field(ge=0)
    relation_ineligible_suppressed_count: int = Field(ge=0)
    separator_source_drawing_fact_evaluated_count: int = Field(ge=0)
    separator_source_inventory_complete: bool
    separator_primitive_retained_count: int = Field(ge=0)

    @model_validator(mode="after")
    def validate_materialization_inventory(
        self,
    ) -> "PdfLayoutDrawingMaterializationEvidence":
        if self.source_drawing_fact_count != (
            self.retained_drawing_node_count + self.suppressed_drawing_node_count
        ):
            raise ValueError("drawing materialization inventory is inconsistent")
        if self.suppressed_drawing_node_count != sum(
            (
                self.near_identical_suppressed_count,
                self.repeated_decorative_suppressed_count,
                self.relation_ineligible_suppressed_count,
            )
        ):
            raise ValueError("drawing suppression reason inventory is inconsistent")
        if self.separator_source_inventory_complete and (
            self.separator_source_drawing_fact_evaluated_count
            != self.source_drawing_fact_count
        ):
            raise ValueError("separator source evaluation inventory is incomplete")
        return self


class PdfLayoutProductConsumerEvidence(BaseModel):
    """Sanitized page-local consumer capabilities retained by Product runs."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    contract_version: Literal["pdf_layout_product_consumer_evidence.v1"] = (
        PDF_LAYOUT_PRODUCT_CONSUMER_EVIDENCE_CONTRACT_VERSION
    )
    structural_candidate_input_usable: bool
    limitations_must_be_propagated: bool
    automatic_unconditional_use_allowed: bool
    abstention_required: bool
    on_demand_relation_query_usable: bool
    separator_exact_counts_usable: bool
    separator_lower_bounds_only: bool
    hard_resource_loss: bool
    fallback_required: bool
    fallback_recommended: bool

    @model_validator(mode="after")
    def validate_consumer_capabilities(self) -> "PdfLayoutProductConsumerEvidence":
        if self.separator_exact_counts_usable and self.separator_lower_bounds_only:
            raise ValueError("separator evidence cannot be exact and lower-bound only")
        if self.structural_candidate_input_usable and (
            not self.on_demand_relation_query_usable
            or self.abstention_required
            or self.hard_resource_loss
        ):
            raise ValueError("structural input requires usable bounded evidence")
        if self.automatic_unconditional_use_allowed and (
            not self.structural_candidate_input_usable
            or self.limitations_must_be_propagated
            or self.abstention_required
            or self.hard_resource_loss
            or self.fallback_required
            or self.fallback_recommended
        ):
            raise ValueError("unconditional use conflicts with consumer limitations")
        if self.hard_resource_loss and (
            not self.limitations_must_be_propagated or not self.fallback_required
        ):
            raise ValueError("hard resource loss requires propagated recovery")
        if self.fallback_recommended and not self.fallback_required:
            raise ValueError("recommended fallback requires a recovery gate")
        return self


class PdfLayoutResourceSemantics(BaseModel):
    """Separate hard data loss from a bounded, queryable stored graph scope."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    contract_version: Literal["pdf_layout_resource_semantics.v2"] = (
        PDF_LAYOUT_RESOURCE_SEMANTICS_CONTRACT_VERSION
    )
    hard_resource_truncation: bool
    bounded_observation_scope_only: bool
    relation_inventory_scope_limited: bool
    stored_relation_candidate_limited: bool
    on_demand_relation_available: bool
    source_content_lost: bool
    node_inventory_lost: bool
    hard_edge_limit_reached: bool = False
    separator_source_inventory_lost: bool
    artifact_hard_limit_reached: bool
    page_deadline_reached: bool
    internal_error: bool

    @model_validator(mode="after")
    def validate_resource_semantics(self) -> "PdfLayoutResourceSemantics":
        expected_hard = any(
            (
                self.source_content_lost,
                self.node_inventory_lost,
                self.hard_edge_limit_reached,
                self.separator_source_inventory_lost,
                self.artifact_hard_limit_reached,
                self.page_deadline_reached,
                self.internal_error,
            )
        )
        if self.hard_resource_truncation != expected_hard:
            raise ValueError("hard resource state must match typed loss evidence")
        expected_bounded_only = (
            self.relation_inventory_scope_limited
            or self.stored_relation_candidate_limited
        ) and not expected_hard
        if self.bounded_observation_scope_only != expected_bounded_only:
            raise ValueError("bounded-only resource state is inconsistent")
        if self.on_demand_relation_available and expected_hard:
            raise ValueError("unsafe graph cannot expose on-demand relations")
        return self


def layout_page_resource_semantics(
    graph_page: PdfLayoutPageGraph,
) -> PdfLayoutResourceSemantics:
    """Classify one page with the shared Product/Real hard-loss contract."""

    quality = graph_page.quality_signals
    selection = quality.text_layer_selection
    usage = graph_page.resource_usage
    warning_codes = {warning.code for warning in graph_page.warnings}
    page_deadline_reached = PdfWarningCode.EXTRACTION_TIMEOUT in warning_codes
    artifact_hard_limit_reached = (
        PdfWarningCode.ARTIFACT_SIZE_LIMIT_REACHED in warning_codes
    )
    internal_error = graph_page.build_status is PdfExtractionStatus.INTERNAL_ERROR
    effective_eligible_fact_count = usage.eligible_fact_count - (
        usage.drawing_node_suppressed_count
        if usage.drawing_node_suppression_metrics_available
        else 0
    )
    node_inventory_lost = (
        quality.node_retention_completeness < 1
        or usage.retained_node_count < effective_eligible_fact_count
    )
    source_content_lost = bool(
        selection.source_fact_available_graph_missing_count
        or selection.supplemental_truncation_count
    )
    separator_source_inventory_lost = usage.separator_source_inventory_truncated
    hard_edge_limit_reached = usage.hard_edge_limit_reached
    relation_inventory_scope_limited = (
        graph_page.relation_observation.relation_search_truncated
    )
    stored_relation_candidate_limited = bool(
        usage.candidate_truncated_node_count
        or usage.sparse_relation_suppressed_count
        or usage.relation_context_truncation_count
        or usage.relation_candidate_limit_reached
    )
    hard_resource_truncation = any(
        (
            source_content_lost,
            node_inventory_lost,
            hard_edge_limit_reached,
            separator_source_inventory_lost,
            artifact_hard_limit_reached,
            page_deadline_reached,
            internal_error,
        )
    )
    return PdfLayoutResourceSemantics(
        hard_resource_truncation=hard_resource_truncation,
        bounded_observation_scope_only=(
            relation_inventory_scope_limited or stored_relation_candidate_limited
        )
        and not hard_resource_truncation,
        relation_inventory_scope_limited=relation_inventory_scope_limited,
        stored_relation_candidate_limited=stored_relation_candidate_limited,
        on_demand_relation_available=(
            bool(graph_page.nodes) and not hard_resource_truncation
        ),
        source_content_lost=source_content_lost,
        node_inventory_lost=node_inventory_lost,
        hard_edge_limit_reached=hard_edge_limit_reached,
        separator_source_inventory_lost=separator_source_inventory_lost,
        artifact_hard_limit_reached=artifact_hard_limit_reached,
        page_deadline_reached=page_deadline_reached,
        internal_error=internal_error,
    )


class PdfLayoutFallbackPageDecision(BaseModel):
    """Gold-free fallback need for one original source page."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    page_number: int = Field(ge=1)
    outcome: PdfLayoutFallbackPageOutcome
    reason: PdfLayoutFallbackReason
    initial_operational_score: float | None = None
    optional_cost_abstained: bool = False
    improvement_prediction: PdfLayoutFallbackImprovementPrediction = "none"
    parser_change_expected_to_help: bool = False

    @model_validator(mode="after")
    def validate_outcome_reason(self) -> "PdfLayoutFallbackPageDecision":
        if self.outcome == "fallback_not_required" and self.reason != "none":
            raise ValueError("non-required fallback page cannot retain a trigger")
        if self.outcome in {"fallback_required", "fallback_recommended"} and (
            self.reason == "none"
        ):
            raise ValueError("fallback page trigger requires a typed reason")
        if self.optional_cost_abstained and self.outcome != "fallback_recommended":
            raise ValueError("only recommended fallback may be cost-abstained")
        if self.parser_change_expected_to_help != (
            self.improvement_prediction in {"parser_level_likely", "required_recovery"}
        ):
            raise ValueError("fallback improvement prediction is inconsistent")
        if self.reason in {
            "bounded_observation_scope",
            "drawing_node_materialization_suppressed",
        } and (self.improvement_prediction != "layout_level_only"):
            raise ValueError("Layout-only limitation must remain a Layout-level issue")
        return self

    @model_serializer(mode="wrap")
    def serialize_prediction(
        self,
        handler: SerializerFunctionWrapHandler,
    ) -> dict[str, object]:
        payload: dict[str, object] = handler(self)
        if self.improvement_prediction == "none":
            payload.pop("improvement_prediction", None)
            payload.pop("parser_change_expected_to_help", None)
        return payload


class PdfLayoutFallbackPageInventory(BaseModel):
    """Deterministic page inventory executed by the existing worker v2 path."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    contract_version: Literal["pdf_layout_selective_fallback.v1"] = (
        PDF_LAYOUT_SELECTIVE_FALLBACK_CONTRACT_VERSION
    )
    source_page_count: int = Field(ge=1)
    decisions: tuple[PdfLayoutFallbackPageDecision, ...]
    required_page_numbers: tuple[int, ...] = ()
    recommended_page_numbers: tuple[int, ...] = ()
    cost_abstained_page_numbers: tuple[int, ...] = ()
    requested_page_numbers: tuple[int, ...] = ()
    execution_mode: PdfLayoutFallbackExecutionMode = "none"
    requested_page_inventory_sha256: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )
    aggregate_reason: PdfLayoutFallbackReason = "none"

    @model_validator(mode="after")
    def validate_inventory(self) -> "PdfLayoutFallbackPageInventory":
        decision_pages = tuple(decision.page_number for decision in self.decisions)
        expected_pages = tuple(range(1, self.source_page_count + 1))
        if decision_pages != expected_pages:
            raise ValueError("fallback decisions must cover each source page once")
        required = tuple(
            decision.page_number
            for decision in self.decisions
            if decision.outcome == "fallback_required"
        )
        recommended = tuple(
            decision.page_number
            for decision in self.decisions
            if decision.outcome == "fallback_recommended"
        )
        if self.required_page_numbers != required:
            raise ValueError("required fallback page inventory is inconsistent")
        if self.recommended_page_numbers != recommended:
            raise ValueError("recommended fallback page inventory is inconsistent")
        cost_abstained = tuple(
            decision.page_number
            for decision in self.decisions
            if decision.optional_cost_abstained
        )
        if self.cost_abstained_page_numbers != cost_abstained:
            raise ValueError("cost-abstained fallback inventory is inconsistent")
        if (
            tuple(sorted(set(self.requested_page_numbers)))
            != self.requested_page_numbers
        ):
            raise ValueError("fallback requested pages must be sorted and unique")
        if any(
            page_number < 1 or page_number > self.source_page_count
            for page_number in self.requested_page_numbers
        ):
            raise ValueError("fallback requested page is outside the source document")
        if self.execution_mode in {"none", "abstained"}:
            if self.requested_page_numbers or self.requested_page_inventory_sha256:
                raise ValueError("non-executed fallback cannot retain a request")
        elif self.execution_mode == "selected_pages":
            if not self.requested_page_numbers:
                raise ValueError("selected fallback requires requested pages")
            expected_digest = canonical_request_scope_inventory_sha256(
                PdfExtractionScope(
                    mode=PdfExtractionScopeMode.SELECTED_PAGES,
                    requested_page_numbers=self.requested_page_numbers,
                )
            )
            if self.requested_page_inventory_sha256 != expected_digest:
                raise ValueError("selected fallback request digest is inconsistent")
        else:
            if self.requested_page_numbers != expected_pages:
                raise ValueError("full fallback must request the full source inventory")
            expected_digest = canonical_request_scope_inventory_sha256(
                PdfExtractionScope(mode=PdfExtractionScopeMode.FULL_DOCUMENT)
            )
            if self.requested_page_inventory_sha256 != expected_digest:
                raise ValueError("full fallback request digest is inconsistent")
        if self.execution_mode == "none" and self.aggregate_reason != "none":
            raise ValueError("non-fallback inventory cannot retain a reason")
        return self


class PdfLayoutProductPageRun(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    page_number: int = Field(ge=1)
    source_extraction_status: str
    source_limitations: tuple[PdfLayoutProductSourceLimitation, ...] = ()
    graph_build_status: str
    readiness_outcome: Literal[
        "ready",
        "ready_with_limitations",
        "not_ready",
    ]
    operational_quality: PdfLayoutOperationalQualitySignal
    resource_semantics: PdfLayoutResourceSemantics | None = None
    drawing_materialization_evidence: PdfLayoutDrawingMaterializationEvidence | None = (
        None
    )
    layout_stage_timing_profile: PdfLayoutStageTimingProfile | None = None
    consumer_evidence: PdfLayoutProductConsumerEvidence | None = None
    layout_elapsed_milliseconds: float = Field(ge=0)
    layout_artifact_size_bytes: int = Field(ge=0)
    node_count: int = Field(ge=0)
    edge_count: int = Field(ge=0)
    separator_candidate_count: int = Field(ge=0)
    path_segment_source_inventory_complete: bool = True
    graph_digest: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_page_payload(self) -> "PdfLayoutProductPageRun":
        if not self.operational_quality.source_page_available:
            raise ValueError("product page requires an available source page")
        if self.readiness_outcome != self.operational_quality.readiness_outcome:
            raise ValueError("product page readiness summaries are inconsistent")
        if self.resource_semantics is not None and (
            self.operational_quality.hard_resource_truncation
            != self.resource_semantics.hard_resource_truncation
        ):
            raise ValueError("product page hard resource summaries are inconsistent")
        has_policy_evidence = self.drawing_materialization_evidence is not None
        if has_policy_evidence != (
            self.operational_quality.layout_policy_evidence_contract_version is not None
        ):
            raise ValueError("product page Layout-policy evidence is incomplete")
        if self.drawing_materialization_evidence is not None:
            evidence = self.drawing_materialization_evidence
            if (
                evidence.contract_version
                != self.operational_quality.layout_policy_evidence_contract_version
            ):
                raise ValueError(
                    "product page Layout-policy provenance is inconsistent"
                )
            if (
                self.operational_quality.layout_policy_only
                and evidence.suppressed_drawing_node_count == 0
            ):
                raise ValueError("Layout-policy-only signal requires suppressed nodes")
        if self.layout_stage_timing_profile is not None and (
            not self.layout_stage_timing_profile.post_page_stages_available
        ):
            raise ValueError("Product evidence requires all Layout stage timings")
        if self.consumer_evidence is not None:
            consumer = self.consumer_evidence
            if self.resource_semantics is None:
                raise ValueError("consumer evidence requires typed resource semantics")
            if consumer.hard_resource_loss != (
                self.resource_semantics.hard_resource_truncation
            ):
                raise ValueError("consumer and resource hard-loss evidence disagree")
            if consumer.limitations_must_be_propagated != (
                self.readiness_outcome != "ready"
            ):
                raise ValueError("consumer limitation propagation is inconsistent")
            if consumer.abstention_required != (self.readiness_outcome == "not_ready"):
                raise ValueError("consumer abstention evidence is inconsistent")
        has_graph = self.graph_digest is not None
        if has_graph:
            if (
                self.graph_build_status
                not in PDF_LAYOUT_PRODUCT_GRAPH_ARTIFACT_STATUSES
            ):
                raise ValueError("graph payload has an incompatible build status")
            if self.layout_artifact_size_bytes <= 0:
                raise ValueError("graph payload requires a nonempty Layout artifact")
        else:
            if (
                self.graph_build_status
                not in PDF_LAYOUT_PRODUCT_GRAPH_NO_ARTIFACT_STATUSES
            ):
                raise ValueError("missing graph has an incompatible build status")
            if any(
                (
                    self.layout_artifact_size_bytes,
                    self.node_count,
                    self.edge_count,
                    self.separator_candidate_count,
                )
            ):
                raise ValueError("failed graph page cannot retain graph payload counts")
            if self.readiness_outcome != "not_ready":
                raise ValueError("failed graph page must be not ready")
            if self.operational_quality.source_page_success:
                raise ValueError("failed graph page cannot report source-page success")
        return self

    @model_serializer(mode="wrap")
    def serialize_drawing_materialization_evidence(
        self,
        handler: SerializerFunctionWrapHandler,
    ) -> dict[str, object]:
        payload: dict[str, object] = handler(self)
        if self.drawing_materialization_evidence is None:
            payload.pop("drawing_materialization_evidence", None)
        if self.layout_stage_timing_profile is None:
            payload.pop("layout_stage_timing_profile", None)
        if self.consumer_evidence is None:
            payload.pop("consumer_evidence", None)
        return payload


def layout_final_page_usability(
    page: PdfLayoutProductPageRun | None,
) -> PdfLayoutFinalPageUsability:
    """Map consumer readiness to the final, parser-neutral usability contract."""

    if page is None or page.readiness_outcome == "not_ready":
        return "unusable"
    if page.readiness_outcome == "ready_with_limitations":
        return "usable_with_limitations"
    return "usable_ready"


class PdfLayoutProductParserRun(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    parser_name: PdfLayoutRoutableParser
    parser_version: str
    extraction_status: str
    document_partial: bool
    # Historical Phase 2 reports predate the additive extraction-scope fields.
    # Treat their scope completeness as unknown/incomplete; current workers set
    # both fields explicitly.
    extraction_scope_mode: Literal["full_document", "selected_pages"] = "full_document"
    requested_scope_complete: bool = False
    missing_requested_page_numbers: tuple[int, ...] = ()
    missing_requested_page_count: int = Field(default=0, ge=0)
    incomplete_requested_page_numbers: tuple[int, ...] = ()
    incomplete_requested_page_count: int = Field(default=0, ge=0)
    source_page_count: int = Field(ge=0)
    extracted_page_count: int = Field(ge=0)
    extraction_elapsed_milliseconds: float = Field(ge=0)
    layout_elapsed_milliseconds: float = Field(ge=0)
    product_parser_elapsed_milliseconds: float = Field(ge=0)
    fact_artifact_size_bytes: int = Field(ge=0)
    layout_artifact_size_bytes: int = Field(ge=0)
    full_document_layout_completion_rate: float = Field(ge=0, le=1)
    path_segment_inventory_completeness_rate: float = Field(ge=0, le=1)
    resource_limited_page_count: int = Field(ge=0)
    hard_resource_limited_page_count: int | None = Field(default=None, ge=0)
    pages: tuple[PdfLayoutProductPageRun, ...]

    @model_validator(mode="after")
    def validate_scope_inventory(self) -> "PdfLayoutProductParserRun":
        page_numbers = tuple(page.page_number for page in self.pages)
        inventories = (
            self.missing_requested_page_numbers,
            self.incomplete_requested_page_numbers,
        )
        if any(tuple(sorted(set(items))) != items for items in inventories):
            raise ValueError("product parser scope inventories must be canonical")
        if self.missing_requested_page_count != len(
            self.missing_requested_page_numbers
        ):
            raise ValueError("product parser missing page count is inconsistent")
        if self.incomplete_requested_page_count != len(
            self.incomplete_requested_page_numbers
        ):
            raise ValueError("product parser incomplete page count is inconsistent")
        if not set(self.incomplete_requested_page_numbers).issubset(page_numbers):
            raise ValueError("product parser incomplete page was not returned")
        if self.requested_scope_complete and any(inventories):
            raise ValueError("complete product parser run retains incomplete scope")
        if len(self.pages) != self.extracted_page_count:
            raise ValueError("product parser page count is inconsistent")
        if len(page_numbers) != len(set(page_numbers)):
            raise ValueError("product parser pages must be unique")
        if any(page_number > self.source_page_count for page_number in page_numbers):
            raise ValueError("product parser page is outside the source document")
        if (
            self.extraction_scope_mode == "full_document"
            and self.requested_scope_complete
            and self.extracted_page_count != self.source_page_count
        ):
            raise ValueError("complete full-document parser run is missing pages")
        if self.fact_artifact_size_bytes <= 0:
            raise ValueError("product parser run requires a nonempty Fact artifact")
        if any(
            page.operational_quality.parser_name != self.parser_name
            for page in self.pages
        ):
            raise ValueError("product page parser does not match its parser run")
        if self.resource_limited_page_count != sum(
            page.operational_quality.resource_truncation for page in self.pages
        ):
            raise ValueError("resource-limited page count is inconsistent")
        if self.hard_resource_limited_page_count is not None:
            if any(page.resource_semantics is None for page in self.pages):
                raise ValueError("hard resource aggregate requires typed page evidence")
            if self.hard_resource_limited_page_count != sum(
                bool(
                    page.resource_semantics
                    and page.resource_semantics.hard_resource_truncation
                )
                for page in self.pages
            ):
                raise ValueError("hard resource-limited page count is inconsistent")
        expected_completion_rate = (
            sum(page.graph_digest is not None for page in self.pages)
            / self.source_page_count
            if self.source_page_count
            else 0.0
        )
        if not math.isclose(
            self.full_document_layout_completion_rate,
            expected_completion_rate,
            abs_tol=1e-9,
        ):
            raise ValueError("full-document Layout completion rate is inconsistent")
        expected_path_rate = (
            sum(page.path_segment_source_inventory_complete for page in self.pages)
            / len(self.pages)
            if self.pages
            else 0.0
        )
        if not math.isclose(
            self.path_segment_inventory_completeness_rate,
            expected_path_rate,
            abs_tol=1e-9,
        ):
            raise ValueError("path inventory completeness rate is inconsistent")
        expected_layout_size = sum(
            page.layout_artifact_size_bytes for page in self.pages
        )
        if self.layout_artifact_size_bytes != expected_layout_size:
            raise ValueError("Layout artifact size aggregate is inconsistent")
        expected_layout_elapsed = sum(
            page.layout_elapsed_milliseconds for page in self.pages
        )
        if not math.isclose(
            self.layout_elapsed_milliseconds,
            expected_layout_elapsed,
            rel_tol=1e-9,
            abs_tol=_PRODUCT_AGGREGATE_ABSOLUTE_TOLERANCE,
        ):
            raise ValueError("Layout elapsed aggregate is inconsistent")
        expected_product_elapsed = (
            self.extraction_elapsed_milliseconds + self.layout_elapsed_milliseconds
        )
        if not math.isclose(
            self.product_parser_elapsed_milliseconds,
            expected_product_elapsed,
            rel_tol=1e-9,
            abs_tol=_PRODUCT_AGGREGATE_ABSOLUTE_TOLERANCE,
        ):
            raise ValueError("product parser elapsed aggregate is inconsistent")
        return self


class PdfLayoutProductPageSelection(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    page_number: int = Field(ge=1)
    selected_parser_name: PdfLayoutRoutableParser | None = None
    selection_reason: PdfLayoutProductPageSelectionReason
    selected_operational_score: float | None = None
    initial_operational_score: float | None = None
    fallback_operational_score: float | None = None
    cross_parser_text_agreement: bool | None = None
    readiness_outcome: Literal[
        "ready",
        "ready_with_limitations",
        "not_ready",
        "unavailable",
    ]
    final_page_usability: PdfLayoutFinalPageUsability
    resource_limited: bool
    fallback_required: bool = False
    required_fallback_satisfied: bool = True
    page_evidence_contract_version: (
        Literal["pdf_layout_product_page_evidence.v1"] | None
    ) = None
    fallback_attempted: bool = False
    fallback_result_available: bool = False
    fallback_improved_page: bool = False
    fallback_recovery_satisfied: bool = False
    final_page_usable: bool = False
    automatic_use_allowed: bool = False
    limitation_retained: bool = False

    @model_validator(mode="before")
    @classmethod
    def populate_page_evidence(cls, value: Any) -> Any:
        if not isinstance(value, dict):
            return value
        payload = dict(value)
        payload.setdefault(
            "final_page_usability",
            {
                "ready": "usable_ready",
                "ready_with_limitations": "usable_with_limitations",
                "not_ready": "unusable",
                "unavailable": "unusable",
            }.get(
                payload.get("readiness_outcome"),  # type: ignore[arg-type]
                "unusable",
            ),
        )
        reason = payload.get("selection_reason")
        attempted = bool(
            payload.get("fallback_required")
            or payload.get("fallback_operational_score") is not None
            or reason
            in {
                "bounded_fallback_selected",
                "initial_retained_after_fallback",
                "fallback_only_available",
                "initial_only_available",
                "page_unresolved",
            }
        )
        fallback_available = bool(
            payload.get("fallback_operational_score") is not None
            or reason in {"bounded_fallback_selected", "fallback_only_available"}
        )
        final_usable = payload["final_page_usability"] != "unusable"
        payload.setdefault("fallback_attempted", attempted)
        payload.setdefault("fallback_result_available", fallback_available)
        payload.setdefault(
            "fallback_improved_page",
            reason == "bounded_fallback_selected",
        )
        payload.setdefault(
            "fallback_recovery_satisfied",
            bool(
                attempted
                and final_usable
                and (
                    not payload.get("fallback_required")
                    or payload.get("required_fallback_satisfied") is True
                )
            ),
        )
        payload.setdefault("final_page_usable", final_usable)
        payload.setdefault(
            "automatic_use_allowed",
            payload["final_page_usability"] == "usable_ready",
        )
        payload.setdefault(
            "limitation_retained",
            payload["final_page_usability"] == "usable_with_limitations",
        )
        return payload

    @model_serializer(mode="wrap")
    def serialize_page_evidence(
        self,
        handler: SerializerFunctionWrapHandler,
    ) -> dict[str, object]:
        payload: dict[str, object] = handler(self)
        if self.page_evidence_contract_version is None:
            for field_name in {
                "page_evidence_contract_version",
                "fallback_attempted",
                "fallback_result_available",
                "fallback_improved_page",
                "fallback_recovery_satisfied",
                "final_page_usable",
                "automatic_use_allowed",
                "limitation_retained",
            }:
                payload.pop(field_name, None)
        return payload

    @model_validator(mode="after")
    def validate_selection(self) -> "PdfLayoutProductPageSelection":
        unresolved = self.selection_reason == "page_unresolved"
        if unresolved != (self.selected_parser_name is None):
            raise ValueError("unresolved page and selected parser must be paired")
        if unresolved:
            if self.selected_operational_score is not None:
                raise ValueError("unresolved page cannot retain a selected score")
            if self.readiness_outcome != "unavailable":
                raise ValueError("unresolved page must report unavailable readiness")
        elif self.selected_operational_score is None:
            raise ValueError("selected page requires an operational score")
        expected_usability: PdfLayoutFinalPageUsability = {  # type: ignore[assignment]
            "ready": "usable_ready",
            "ready_with_limitations": "usable_with_limitations",
            "not_ready": "unusable",
            "unavailable": "unusable",
        }[self.readiness_outcome]
        if self.final_page_usability != expected_usability:
            raise ValueError("final page usability contradicts consumer readiness")
        if self.required_fallback_satisfied and unresolved and self.fallback_required:
            raise ValueError("unresolved required page cannot satisfy fallback")
        if (
            self.fallback_required
            and self.required_fallback_satisfied
            and self.final_page_usability == "unusable"
        ):
            raise ValueError("unusable final page cannot satisfy required fallback")
        if self.fallback_result_available and not self.fallback_attempted:
            raise ValueError("fallback result requires an attempted fallback")
        if self.fallback_improved_page != (
            self.selection_reason == "bounded_fallback_selected"
        ):
            raise ValueError("fallback improvement evidence is inconsistent")
        if self.fallback_improved_page and not self.fallback_result_available:
            raise ValueError("fallback improvement requires an available result")
        expected_recovery = bool(
            self.fallback_attempted
            and self.final_page_usability != "unusable"
            and (not self.fallback_required or self.required_fallback_satisfied)
        )
        if self.fallback_recovery_satisfied != expected_recovery:
            raise ValueError("fallback recovery evidence is inconsistent")
        if self.final_page_usable != (self.final_page_usability != "unusable"):
            raise ValueError("final page usability evidence is inconsistent")
        if self.automatic_use_allowed != (self.final_page_usability == "usable_ready"):
            raise ValueError("automatic-use evidence is inconsistent")
        if self.limitation_retained != (
            self.final_page_usability == "usable_with_limitations"
        ):
            raise ValueError("retained limitation evidence is inconsistent")
        return self


class PdfLayoutProductParserAttempt(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    parser_name: PdfLayoutRoutableParser
    exit_classification: PdfWorkerExitClassification
    error_category: str = Field(max_length=64)
    elapsed_milliseconds: float = Field(ge=0)
    cpu_time_milliseconds: float | None = Field(default=None, ge=0)
    peak_rss_bytes: int | None = Field(default=None, ge=0)
    peak_python_heap_bytes: int | None = Field(default=None, ge=0)
    completed_successfully: bool
    requested_scope_complete: bool = False
    missing_requested_page_numbers: tuple[int, ...] = ()
    incomplete_requested_page_numbers: tuple[int, ...] = ()
    retained_partial_result: bool = False
    worker_batch_count: int = Field(default=1, ge=1)
    successful_worker_batch_count: int | None = Field(default=None, ge=0)
    failed_worker_batch_count: int | None = Field(default=None, ge=0)
    typed_partial_worker_batch_count: int = Field(default=0, ge=0)
    hard_failed_worker_batch_count: int = Field(default=0, ge=0)
    scope_complete_worker_batch_count: int = Field(default=0, ge=0)
    split_retry_worker_batch_count: int = Field(default=0, ge=0)
    requested_page_count: int | None = Field(default=None, ge=1)
    requested_page_inventory_sha256: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )
    worker_batch_evidence: PdfLayoutProductWorkerBatchExecutionEvidence | None = None

    @model_validator(mode="before")
    @classmethod
    def populate_batch_counts(cls, value: Any) -> Any:
        if not isinstance(value, dict):
            return value
        payload = dict(value)
        batch_count = payload.get("worker_batch_count", 1)
        completed = payload.get("completed_successfully") is True
        payload.setdefault("requested_scope_complete", completed)
        payload.setdefault(
            "successful_worker_batch_count",
            batch_count if completed else 0,
        )
        payload.setdefault(
            "failed_worker_batch_count",
            batch_count - payload["successful_worker_batch_count"],
        )
        evidence = payload.get("worker_batch_evidence")
        if isinstance(evidence, dict):
            migrated = PdfLayoutProductWorkerBatchExecutionEvidence.model_validate(
                evidence
            )
            payload.setdefault(
                "typed_partial_worker_batch_count",
                migrated.typed_partial_worker_batch_count,
            )
            payload.setdefault(
                "hard_failed_worker_batch_count",
                migrated.hard_failed_worker_batch_count,
            )
            payload.setdefault(
                "scope_complete_worker_batch_count",
                migrated.scope_complete_worker_batch_count,
            )
            if not any(
                name in value
                for name in (
                    "typed_partial_worker_batch_count",
                    "hard_failed_worker_batch_count",
                    "scope_complete_worker_batch_count",
                )
            ):
                payload["failed_worker_batch_count"] = (
                    migrated.hard_failed_worker_batch_count
                )
        else:
            payload.setdefault("typed_partial_worker_batch_count", 0)
            payload.setdefault(
                "hard_failed_worker_batch_count", payload["failed_worker_batch_count"]
            )
            payload.setdefault(
                "scope_complete_worker_batch_count",
                payload["successful_worker_batch_count"],
            )
        return payload

    @model_serializer(mode="wrap")
    def serialize_batch_evidence(
        self,
        handler: SerializerFunctionWrapHandler,
    ) -> dict[str, object]:
        payload: dict[str, object] = handler(self)
        if self.worker_batch_evidence is None:
            payload.pop("worker_batch_evidence", None)
        if self.peak_python_heap_bytes is None:
            payload.pop("peak_python_heap_bytes", None)
        return payload

    @model_validator(mode="after")
    def validate_success(self) -> "PdfLayoutProductParserAttempt":
        for inventory in (
            self.missing_requested_page_numbers,
            self.incomplete_requested_page_numbers,
        ):
            if tuple(sorted(set(inventory))) != inventory:
                raise ValueError("parser attempt scope inventory is not canonical")
        if self.requested_scope_complete and (
            self.missing_requested_page_numbers
            or self.incomplete_requested_page_numbers
        ):
            raise ValueError("complete parser attempt retains incomplete scope")
        expected = (
            self.exit_classification == "completed"
            and self.error_category == "none"
            and self.requested_scope_complete
        )
        if self.completed_successfully != expected:
            raise ValueError("product parser attempt success is inconsistent")
        if self.successful_worker_batch_count is None:
            raise ValueError("product parser attempt requires successful batch count")
        if self.failed_worker_batch_count is None:
            raise ValueError("product parser attempt requires failed batch count")
        if (
            self.scope_complete_worker_batch_count
            + self.typed_partial_worker_batch_count
            + self.hard_failed_worker_batch_count
            != self.worker_batch_count
        ):
            raise ValueError("product parser attempt batch counts are inconsistent")
        if self.split_retry_worker_batch_count > self.worker_batch_count:
            raise ValueError("split retry count exceeds worker batch count")
        if self.completed_successfully and not self.successful_worker_batch_count:
            raise ValueError("completed parser attempt requires a successful batch")
        if self.retained_partial_result and self.completed_successfully:
            raise ValueError("completed parser attempt cannot be retained-partial")
        if (self.requested_page_count is None) != (
            self.requested_page_inventory_sha256 is None
        ):
            raise ValueError("logical parser request count and digest must be paired")
        evidence = self.worker_batch_evidence
        if evidence is not None:
            if evidence.parser_name != self.parser_name:
                raise ValueError("parser attempt batch evidence changed parser")
            if self.requested_page_count != (evidence.logical_requested_page_count):
                raise ValueError("parser attempt logical page count is inconsistent")
            if self.requested_page_inventory_sha256 != (
                evidence.logical_requested_page_inventory_sha256
            ):
                raise ValueError("parser attempt logical page digest is inconsistent")
            if self.worker_batch_count != len(evidence.batches):
                raise ValueError("parser attempt batch evidence count is inconsistent")
            if self.successful_worker_batch_count != (
                evidence.successful_worker_batch_count
            ):
                raise ValueError("parser attempt successful batches are inconsistent")
            if self.failed_worker_batch_count != (evidence.failed_worker_batch_count):
                raise ValueError("parser attempt failed batches are inconsistent")
            if self.split_retry_worker_batch_count != (
                evidence.split_retry_worker_batch_count
            ):
                raise ValueError("parser attempt split retries are inconsistent")
            if self.missing_requested_page_numbers != evidence.failed_page_numbers:
                raise ValueError("parser attempt missing inventory is inconsistent")
            if self.incomplete_requested_page_numbers != (
                evidence.incomplete_page_numbers
            ):
                raise ValueError("parser attempt incomplete inventory is inconsistent")
            if self.requested_scope_complete != (
                evidence.failed_page_count == 0 and evidence.incomplete_page_count == 0
            ):
                raise ValueError("parser attempt scope completeness is inconsistent")
            if self.completed_successfully != (
                evidence.failed_page_count == 0 and evidence.incomplete_page_count == 0
            ):
                raise ValueError("parser attempt completion evidence is inconsistent")
            expected_retained_partial = bool(
                evidence.returned_page_count
                and (evidence.failed_page_count or evidence.incomplete_page_count)
            )
            if self.retained_partial_result != expected_retained_partial:
                raise ValueError(
                    "parser attempt retained partial evidence is inconsistent"
                )
        return self


class PdfLayoutParserRoutePlan(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    initial_parser: PdfLayoutRoutableParser
    fallback_parser: PdfLayoutRoutableParser
    maximum_parser_executions: Literal[2] = 2

    @model_validator(mode="after")
    def reject_route_loop(self) -> "PdfLayoutParserRoutePlan":
        if self.initial_parser == self.fallback_parser:
            raise ValueError("initial and fallback parsers must differ")
        return self


def route_layout_parser(
    *,
    preflight: PdfLayoutParserPreflight,
    policy: PdfLayoutParserRoutingPolicy,
) -> PdfLayoutParserRoutePlan:
    """Choose an initial parser without filename, business meaning, or gold."""

    initial: PdfLayoutRoutableParser = (
        "pypdfium2"
        if preflight.page_count >= policy.long_document_page_threshold
        or preflight.long_document_signal is True
        or preflight.drawing_heavy_signal is True
        or preflight.sampled_drawing_operation_count
        >= policy.drawing_heavy_operation_threshold
        or preflight.sampled_image_operation_count
        >= policy.image_heavy_operation_threshold
        or (
            preflight.average_sample_content_stream_bytes is not None
            and preflight.average_sample_content_stream_bytes
            >= policy.large_sample_content_stream_bytes
        )
        else "pdfplumber"
    )
    fallback: PdfLayoutRoutableParser = (
        "pdfplumber" if initial == "pypdfium2" else "pypdfium2"
    )
    return PdfLayoutParserRoutePlan(
        initial_parser=initial,
        fallback_parser=fallback,
    )


def layout_parser_fallback_reason(
    *,
    signal: PdfLayoutOperationalQualitySignal,
    policy: PdfLayoutParserRoutingPolicy,
) -> PdfLayoutFallbackReason:
    """Return one bounded fallback trigger from operational evidence only."""

    if not signal.source_page_available:
        return "source_page_unavailable"
    if not signal.source_page_success:
        return "source_page_partial"
    if (
        signal.resource_truncation
        and signal.hard_resource_truncation is False
        and policy.contract_version
        == PDF_LAYOUT_PRODUCT_STRATEGY_PHASE2I_POLICY_VERSION
    ):
        return "bounded_observation_scope"
    if signal.hard_resource_truncation is True or (
        signal.resource_truncation
        and (
            signal.hard_resource_truncation is None
            or policy.contract_version
            != PDF_LAYOUT_PRODUCT_STRATEGY_PHASE2I_POLICY_VERSION
        )
    ):
        return "resource_truncation"
    if (
        policy.contract_version == PDF_LAYOUT_PRODUCT_STRATEGY_PHASE2I_POLICY_VERSION
        and signal.layout_policy_only
    ):
        return "drawing_node_materialization_suppressed"
    if signal.readiness_outcome == "not_ready":
        return "not_ready"
    if (
        signal.drawing_node_ratio is not None
        and signal.drawing_node_ratio > 0
        and signal.separator_candidate_count == 0
    ):
        return "separator_primitive_unavailable"
    if (
        signal.parser_name == "pypdfium2"
        and signal.drawing_node_count is not None
        and signal.drawing_node_count >= policy.minimum_drawing_count_for_coverage_gate
        and signal.separator_primitives_per_drawing is not None
        and signal.separator_primitives_per_drawing
        < policy.minimum_separator_primitives_per_drawing
    ):
        return "separator_primitive_coverage_low"
    required = (
        (signal.graph_confidence, policy.minimum_graph_confidence),
        (signal.node_retention, policy.minimum_node_retention),
        (signal.geometry_completeness, policy.minimum_geometry_completeness),
        (signal.text_layer_coverage, policy.minimum_text_layer_coverage),
        (signal.text_geometry_ratio, policy.minimum_text_geometry_ratio),
        (
            signal.combined_text_coverage,
            policy.minimum_combined_text_coverage,
        ),
    )
    if signal.readiness_outcome != "ready" or any(
        value is None or value < minimum for value, minimum in required
    ):
        return "operational_quality_below_gate"
    if (
        signal.unicode_replacement_ratio is not None
        and signal.unicode_replacement_ratio > policy.maximum_unicode_replacement_ratio
    ):
        return "operational_quality_below_gate"
    if (
        signal.fragmentation_ratio is not None
        and signal.fragmentation_ratio > policy.maximum_fragmentation_ratio
    ):
        return "operational_quality_below_gate"
    if (
        signal.spatial_conflict_ratio is not None
        and signal.spatial_conflict_ratio > policy.maximum_spatial_conflict_ratio
    ):
        return "operational_quality_below_gate"
    return "none"


def layout_fallback_improvement_prediction(
    *,
    signal: PdfLayoutOperationalQualitySignal | None,
    reason: PdfLayoutFallbackReason,
) -> PdfLayoutFallbackImprovementPrediction:
    """Classify whether changing parsers can address the observed page gap."""

    if reason == "none":
        return "none"
    if reason in {
        "bounded_observation_scope",
        "drawing_node_materialization_suppressed",
    }:
        return "layout_level_only"
    if reason in {
        "source_page_unavailable",
        "source_page_partial",
        "parser_worker_failure",
        "not_ready",
        "resource_truncation",
    }:
        return "required_recovery"
    if reason in {
        "separator_primitive_unavailable",
        "separator_primitive_coverage_low",
        "operational_quality_below_gate",
    }:
        return "parser_level_likely"
    if signal is None:
        return "required_recovery"
    raise ValueError("unsupported fallback improvement prediction")


def _phase2i_source_partial_is_structurally_usable(
    page: PdfLayoutProductPageRun,
    *,
    reason: PdfLayoutFallbackReason,
) -> bool:
    """Keep a typed, usable partial page optional in the Phase 2I route.

    The shared consumer contract intentionally propagates every source-page
    partial state as a limitation.  Phase 2I has the additive evidence needed
    to distinguish that conservative status from actual source or structural
    loss.  Missing or contradictory evidence remains fail-closed.
    """

    resource = page.resource_semantics
    consumer = page.consumer_evidence
    return bool(
        reason == "source_page_partial"
        and not page.operational_quality.source_page_success
        and resource is not None
        and not resource.hard_resource_truncation
        and not resource.source_content_lost
        and consumer is not None
        and consumer.structural_candidate_input_usable
        and not consumer.hard_resource_loss
        and not consumer.abstention_required
    )


def _phase2i_separator_only_hard_loss_can_be_retained(
    page: PdfLayoutProductPageRun,
    *,
    reason: PdfLayoutFallbackReason,
) -> bool:
    """Keep a known separator lower bound nonfatal when all page data remains.

    A truncated separator-source geometry inventory is still a typed hard
    limitation for exact separator counts.  It does not, by itself, mean that
    the page, nodes, positive relations, or visible content are unavailable.
    Phase 2I may therefore retain the page with propagated limitations and
    treat a parser change as optional.  Every other hard-loss category remains
    required recovery and fail-closed.
    """

    resource = page.resource_semantics
    consumer = page.consumer_evidence
    return bool(
        reason == "resource_truncation"
        and page.graph_digest is not None
        and page.node_count > 0
        and page.readiness_outcome == "ready_with_limitations"
        and page.operational_quality.source_page_available
        and page.operational_quality.source_page_success
        and resource is not None
        and resource.hard_resource_truncation
        and resource.separator_source_inventory_lost
        and not resource.source_content_lost
        and not resource.node_inventory_lost
        and not resource.hard_edge_limit_reached
        and not resource.artifact_hard_limit_reached
        and not resource.page_deadline_reached
        and not resource.internal_error
        and consumer is not None
        and consumer.separator_lower_bounds_only
        and consumer.limitations_must_be_propagated
        and not consumer.abstention_required
    )


def build_layout_fallback_page_inventory(
    *,
    run: PdfLayoutProductParserRun | None,
    expected_page_count: int,
    policy: PdfLayoutParserRoutingPolicy,
    max_selected_page_count: int,
) -> PdfLayoutFallbackPageInventory:
    """Derive one bounded, Gold-free fallback request from initial page quality."""

    if expected_page_count < 1:
        raise ValueError("fallback inventory requires a positive source page count")
    if max_selected_page_count < 1:
        raise ValueError("selected fallback limit must be positive")
    phase2h_policy = (
        policy.contract_version == PDF_LAYOUT_PRODUCT_STRATEGY_PHASE2H_POLICY_VERSION
    )
    phase2i_policy = (
        policy.contract_version == PDF_LAYOUT_PRODUCT_STRATEGY_PHASE2I_POLICY_VERSION
    )
    pages = {page.page_number: page for page in run.pages} if run is not None else {}
    decisions: list[PdfLayoutFallbackPageDecision] = []
    for page_number in range(1, expected_page_count + 1):
        page = pages.get(page_number)
        if run is None:
            outcome: PdfLayoutFallbackPageOutcome = "fallback_required"
            reason: PdfLayoutFallbackReason = "parser_worker_failure"
            score = None
            optional_cost_abstained = False
            prediction = layout_fallback_improvement_prediction(
                signal=None,
                reason=reason,
            )
        elif page is None:
            outcome = "fallback_required"
            reason = "source_page_unavailable"
            score = None
            optional_cost_abstained = False
            prediction = layout_fallback_improvement_prediction(
                signal=None,
                reason=reason,
            )
        else:
            reason = layout_parser_fallback_reason(
                signal=page.operational_quality,
                policy=policy,
            )
            score = layout_operational_quality_score(page.operational_quality)
            prediction = layout_fallback_improvement_prediction(
                signal=page.operational_quality,
                reason=reason,
            )
            if (
                phase2i_policy
                and page.resource_semantics is not None
                and page.resource_semantics.page_deadline_reached
            ):
                # A hard page deadline is unsafe, but changing Fact parsers is
                # not itself evidence that the Layout hot path will improve.
                prediction = "layout_level_only"
            phase2i_usable_source_partial = bool(
                phase2i_policy
                and _phase2i_source_partial_is_structurally_usable(
                    page,
                    reason=reason,
                )
            )
            phase2i_retained_separator_limitation = bool(
                phase2i_policy
                and _phase2i_separator_only_hard_loss_can_be_retained(
                    page,
                    reason=reason,
                )
            )
            if phase2i_retained_separator_limitation:
                # An alternate parser can recover exact separator evidence,
                # but the current page remains safely available as an explicit
                # lower bound.  This is optional parser-level improvement, not
                # a fatal required-page recovery.
                prediction = "parser_level_likely"
            typed_recovery_required = bool(
                phase2i_policy
                and not phase2i_usable_source_partial
                and not phase2i_retained_separator_limitation
                and (
                    (
                        page.consumer_evidence is not None
                        and page.consumer_evidence.fallback_required
                    )
                    or (
                        page.resource_semantics is not None
                        and page.resource_semantics.hard_resource_truncation
                    )
                )
            )
            if typed_recovery_required:
                outcome = "fallback_required"
                optional_cost_abstained = False
            elif phase2i_policy and (
                prediction == "layout_level_only"
                and policy.abstain_layout_only_fallback
            ):
                outcome = "fallback_not_applicable"
                optional_cost_abstained = False
            elif phase2h_policy or phase2i_policy:
                usability = layout_final_page_usability(page)
                if usability == "unusable":
                    outcome = "fallback_required"
                elif reason == "none":
                    outcome = "fallback_not_required"
                else:
                    outcome = "fallback_recommended"
                optional_cost_abstained = bool(
                    outcome == "fallback_recommended"
                    and (
                        (
                            policy.abstain_optional_limited_page_fallback
                            and usability == "usable_with_limitations"
                        )
                        or (
                            policy.abstain_expensive_optional_page_fallback
                            and page.layout_elapsed_milliseconds
                            >= policy.product_page_build_budget_milliseconds
                        )
                    )
                )
            else:
                optional_cost_abstained = False
                if reason in {
                    "source_page_unavailable",
                    "source_page_partial",
                    "resource_truncation",
                    "not_ready",
                    "parser_worker_failure",
                }:
                    outcome = "fallback_required"
                elif reason == "none":
                    outcome = "fallback_not_required"
                else:
                    outcome = "fallback_recommended"
        decisions.append(
            PdfLayoutFallbackPageDecision(
                page_number=page_number,
                outcome=outcome,
                reason=reason,
                initial_operational_score=score,
                optional_cost_abstained=optional_cost_abstained,
                improvement_prediction=(prediction if phase2i_policy else "none"),
                parser_change_expected_to_help=(
                    phase2i_policy
                    and prediction in {"parser_level_likely", "required_recovery"}
                ),
            )
        )

    required = tuple(
        decision.page_number
        for decision in decisions
        if decision.outcome == "fallback_required"
    )
    recommended_decisions = sorted(
        (
            decision
            for decision in decisions
            if decision.outcome == "fallback_recommended"
            and not decision.optional_cost_abstained
        ),
        key=lambda item: (
            item.initial_operational_score
            if item.initial_operational_score is not None
            else -math.inf,
            item.page_number,
        ),
    )
    maximum_recommended = min(
        policy.maximum_recommended_fallback_pages,
        math.ceil(expected_page_count * policy.maximum_recommended_fallback_page_ratio),
    )
    requested_recommended = tuple(
        decision.page_number for decision in recommended_decisions[:maximum_recommended]
    )
    recommended = tuple(
        decision.page_number
        for decision in decisions
        if decision.outcome == "fallback_recommended"
    )
    cost_abstained = tuple(
        decision.page_number
        for decision in decisions
        if decision.optional_cost_abstained
    )
    widespread_optional_fallback = bool(
        not required
        and expected_page_count >= policy.long_document_page_threshold
        and len(recommended) / expected_page_count
        >= policy.widespread_optional_fallback_abstention_ratio
    )
    optional_fallback_too_small = bool(
        not required
        and 0
        < len(requested_recommended)
        < policy.minimum_recommended_fallback_pages_to_execute
    )
    targets = (
        ()
        if widespread_optional_fallback or optional_fallback_too_small
        else tuple(sorted(set(required) | set(requested_recommended)))
    )

    if run is None:
        execution_mode: PdfLayoutFallbackExecutionMode = "full_document"
    elif not targets:
        execution_mode = "abstained" if recommended else "none"
    elif (
        len(targets) / expected_page_count
        >= policy.full_document_fallback_ratio_threshold
        or len(targets) > max_selected_page_count
    ):
        execution_mode = "full_document"
    else:
        execution_mode = "selected_pages"

    if execution_mode == "full_document":
        requested = tuple(range(1, expected_page_count + 1))
        digest = canonical_request_scope_inventory_sha256(
            PdfExtractionScope(mode=PdfExtractionScopeMode.FULL_DOCUMENT)
        )
    elif execution_mode == "selected_pages":
        requested = targets
        digest = canonical_request_scope_inventory_sha256(
            PdfExtractionScope(
                mode=PdfExtractionScopeMode.SELECTED_PAGES,
                requested_page_numbers=requested,
            )
        )
    else:
        requested = ()
        digest = None

    priority = {
        "parser_worker_failure": 0,
        "source_page_unavailable": 1,
        "source_page_partial": 2,
        "resource_truncation": 3,
        "not_ready": 4,
        "separator_primitive_unavailable": 5,
        "separator_primitive_coverage_low": 6,
        "operational_quality_below_gate": 7,
        "bounded_observation_scope": 8,
        "drawing_node_materialization_suppressed": 9,
        "none": 10,
    }
    requested_decisions = [
        decision for decision in decisions if decision.page_number in targets
    ]
    aggregate_reason = (
        min(requested_decisions, key=lambda item: priority[item.reason]).reason
        if requested_decisions
        else "none"
    )
    return PdfLayoutFallbackPageInventory(
        source_page_count=expected_page_count,
        decisions=tuple(decisions),
        required_page_numbers=required,
        recommended_page_numbers=recommended,
        cost_abstained_page_numbers=cost_abstained,
        requested_page_numbers=requested,
        execution_mode=execution_mode,
        requested_page_inventory_sha256=digest,
        aggregate_reason=aggregate_reason,
    )


def select_layout_product_page(
    *,
    initial: PdfLayoutProductPageRun | None,
    fallback: PdfLayoutProductPageRun | None,
    policy: PdfLayoutParserRoutingPolicy,
) -> tuple[
    PdfLayoutProductPageRun | None,
    PdfLayoutProductPageSelectionReason,
    float | None,
    float | None,
]:
    """Select one page using relative operational evidence, never Gold."""

    initial_score = (
        layout_operational_quality_score(initial.operational_quality)
        if initial is not None
        else None
    )
    fallback_score = (
        layout_operational_quality_score(fallback.operational_quality)
        if fallback is not None
        else None
    )
    if initial is None and fallback is None:
        return None, "page_unresolved", None, None
    if initial is None:
        return fallback, "fallback_only_available", None, fallback_score
    if fallback is None:
        return initial, "initial_only_available", initial_score, None

    first = initial.operational_quality
    second = fallback.operational_quality
    readiness_rank = {
        "unavailable": 0,
        "not_ready": 1,
        "ready_with_limitations": 2,
        "ready": 3,
    }
    required_recovery = any(
        (
            not first.source_page_success and second.source_page_success,
            readiness_rank[first.readiness_outcome] <= readiness_rank["not_ready"]
            and readiness_rank[second.readiness_outcome]
            > readiness_rank[first.readiness_outcome],
        )
    )
    clear_content_improvement = any(
        (
            _quality_improvement(
                first.combined_text_coverage,
                second.combined_text_coverage,
            )
            >= policy.minimum_content_coverage_improvement,
            _visible_content_improved(first, second),
        )
    )
    content_preserved = _fallback_content_is_preserved(
        first,
        second,
        policy=policy,
        clear_content_improvement=clear_content_improvement,
    )
    fallback_clearly_better = any(
        (
            first.resource_truncation and not second.resource_truncation,
            readiness_rank[second.readiness_outcome]
            > readiness_rank[first.readiness_outcome],
            clear_content_improvement,
            _quality_improvement(
                first.geometry_completeness,
                second.geometry_completeness,
            )
            >= policy.minimum_geometry_quality_improvement,
            _separator_capability_improved(first, second),
        )
    )
    score_margin_reached = (
        fallback_score is not None
        and initial_score is not None
        and fallback_score - initial_score >= policy.minimum_fallback_score_improvement
        and not (
            bool(
                first.hard_resource_truncation
                if first.hard_resource_truncation is not None
                else first.resource_truncation
            )
            and bool(
                second.hard_resource_truncation
                if second.hard_resource_truncation is not None
                else second.resource_truncation
            )
        )
    )
    if required_recovery or (
        content_preserved and (fallback_clearly_better or score_margin_reached)
    ):
        return fallback, "bounded_fallback_selected", initial_score, fallback_score
    return initial, "initial_retained_after_fallback", initial_score, fallback_score


def _quality_improvement(first: float | None, second: float | None) -> float:
    if first is None or second is None:
        return 0.0
    return second - first


def _visible_content_improved(
    first: PdfLayoutOperationalQualitySignal,
    second: PdfLayoutOperationalQualitySignal,
) -> bool:
    first_count = first.normalized_visible_character_count
    second_count = second.normalized_visible_character_count
    if first_count is None or second_count is None or second_count <= first_count:
        return False
    minimum_gain = max(8, math.ceil(first_count * 0.1))
    if second_count - first_count < minimum_gain:
        return False
    first_regions = first.distinct_spatial_text_region_count
    second_regions = second.distinct_spatial_text_region_count
    return (
        first_regions is None
        or second_regions is None
        or second_regions >= first_regions
    )


def _fallback_content_is_preserved(
    first: PdfLayoutOperationalQualitySignal,
    second: PdfLayoutOperationalQualitySignal,
    *,
    policy: PdfLayoutParserRoutingPolicy,
    clear_content_improvement: bool,
) -> bool:
    """Reject non-content wins when the fallback loses visible content.

    A matching normalized text hash is the strongest parser-neutral preservation
    signal.  A mismatching hash is not treated as equivalent content: it requires
    an independently clear content improvement.  When either hash is unavailable,
    every comparable bounded content inventory must remain within the existing
    content-improvement margin.
    """

    first_hash = first.normalized_visible_text_sha256
    second_hash = second.normalized_visible_text_sha256
    cross_parser = bool(
        first.parser_name is not None
        and second.parser_name is not None
        and first.parser_name != second.parser_name
    )
    if first_hash is not None and second_hash is not None:
        if first_hash == second_hash:
            return True
        if not clear_content_improvement and not cross_parser:
            return False

    maximum_loss_ratio = policy.minimum_content_coverage_improvement
    comparisons: list[bool] = []
    if (
        first.combined_text_coverage is not None
        and second.combined_text_coverage is not None
    ):
        comparisons.append(
            second.combined_text_coverage
            >= first.combined_text_coverage - maximum_loss_ratio
        )
    if (
        first.normalized_visible_character_count is not None
        and second.normalized_visible_character_count is not None
    ):
        permitted_character_loss = max(
            1,
            math.ceil(first.normalized_visible_character_count * maximum_loss_ratio),
        )
        comparisons.append(
            second.normalized_visible_character_count
            >= first.normalized_visible_character_count - permitted_character_loss
        )
    if (
        not cross_parser
        and first.distinct_spatial_text_region_count is not None
        and second.distinct_spatial_text_region_count is not None
    ):
        permitted_region_loss = max(
            1,
            math.ceil(first.distinct_spatial_text_region_count * maximum_loss_ratio),
        )
        comparisons.append(
            second.distinct_spatial_text_region_count
            >= first.distinct_spatial_text_region_count - permitted_region_loss
        )
    return bool(comparisons) and all(comparisons)


def _separator_capability_improved(
    first: PdfLayoutOperationalQualitySignal,
    second: PdfLayoutOperationalQualitySignal,
) -> bool:
    if not first.drawing_node_count:
        return False
    first_count = first.separator_candidate_count or 0
    second_count = second.separator_candidate_count or 0
    return second_count > first_count and not second.resource_truncation


def layout_operational_quality_score(
    signal: PdfLayoutOperationalQualitySignal,
) -> float:
    """Score only sanitized runtime quality; gold and edge volume are excluded."""

    if not signal.source_page_available:
        return -1_000.0
    score = 0.0
    if signal.source_page_success:
        score += 100.0
    else:
        score -= 250.0
    hard_resource_truncation = (
        signal.hard_resource_truncation
        if signal.hard_resource_truncation is not None
        else signal.resource_truncation
    )
    if hard_resource_truncation:
        score -= 500.0
    score += {
        "ready": 150.0,
        "ready_with_limitations": 25.0,
        "not_ready": -400.0,
        "unavailable": -500.0,
    }[signal.readiness_outcome]
    weighted = (
        (signal.graph_confidence, 50.0),
        (signal.node_retention, 50.0),
        (signal.geometry_completeness, 40.0),
        (signal.text_layer_coverage, 40.0),
        (signal.combined_text_coverage, 80.0),
        (signal.text_geometry_ratio, 40.0),
    )
    score += sum((value or 0.0) * weight for value, weight in weighted)
    score -= (signal.fragmentation_ratio or 0.0) * 35.0
    score -= (signal.spatial_duplicate_ratio or 0.0) * 20.0
    score -= (signal.spatial_conflict_ratio or 0.0) * 60.0
    score -= (signal.unicode_replacement_ratio or 0.0) * 200.0
    score -= min(50.0, signal.warning_severity_score * 2.0)
    if signal.drawing_node_count:
        if signal.separator_primitives_per_drawing is not None:
            score += min(20.0, signal.separator_primitives_per_drawing * 20.0)
        elif signal.separator_candidate_count == 0:
            score -= 20.0
    if signal.normalized_visible_character_count:
        score += min(20.0, signal.normalized_visible_character_count / 500.0)
    return round(score, 6)

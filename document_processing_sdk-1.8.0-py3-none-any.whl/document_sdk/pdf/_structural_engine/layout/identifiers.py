# ruff: noqa: D202, PLR0913

import json
from typing import Any

from pydantic import BaseModel

from document_sdk.pdf._structural_engine.facts.contracts import PdfFactArtifact
from document_sdk.pdf._structural_engine.facts.identifiers import source_sha256


def source_fact_artifact_digest(artifact: PdfFactArtifact) -> str:
    payload = artifact.model_dump(mode="json")
    payload.pop("extracted_at", None)
    payload.pop("resource_usage", None)
    return canonical_payload_sha256(payload)


def layout_settings_digest(*, limits: BaseModel, options: BaseModel) -> str:
    return canonical_payload_sha256(
        {
            "limits": limits.model_dump(mode="json"),
            "options": options.model_dump(mode="json"),
        }
    )


def layout_graph_identifier(
    *,
    source_fact_digest: str,
    builder_name: str,
    builder_version: str,
    settings_digest: str,
) -> str:
    return "PDFLG-" + _identifier_digest(
        source_fact_digest,
        builder_name,
        builder_version,
        settings_digest,
    )


def layout_page_identifier(*, layout_graph_id: str, source_page_id: str) -> str:
    return "PDFLP-" + _identifier_digest(layout_graph_id, source_page_id)


def layout_node_identifier(
    *,
    page_graph_id: str,
    source_fact_id: str,
    node_type: str,
) -> str:
    return "PDFLN-" + _identifier_digest(
        page_graph_id,
        source_fact_id,
        node_type,
    )


def layout_edge_identifier(
    *,
    page_graph_id: str,
    source_node_id: str,
    target_node_id: str,
    relation_type: str,
    method_version: str,
    adjacency_basis: str | None = None,
) -> str:
    return "PDFLE-" + _identifier_digest(
        page_graph_id,
        source_node_id,
        target_node_id,
        relation_type,
        method_version,
        adjacency_basis or "not_applicable",
    )


def layout_separator_identifier(
    *,
    page_graph_id: str,
    drawing_node_id: str,
    orientation: str,
    primitive_key: str = "direct_line",
) -> str:
    return "PDFLS-" + _identifier_digest(
        page_graph_id,
        drawing_node_id,
        orientation,
        primitive_key,
    )


def layout_page_boundary_separator_identifier(
    *,
    page_graph_id: str,
    page_boundary_side: str,
) -> str:
    """Return an ID for canonical page geometry without a fake drawing ID."""

    return "PDFLS-" + _identifier_digest(
        page_graph_id,
        "page_geometry",
        page_boundary_side,
        "page_boundary_edge",
    )


def canonical_payload_sha256(value: Any) -> str:
    serialized = json.dumps(
        value,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return source_sha256(serialized)


def _identifier_digest(*parts: str) -> str:
    return source_sha256("\x1f".join(parts).encode("utf-8"))[:24]

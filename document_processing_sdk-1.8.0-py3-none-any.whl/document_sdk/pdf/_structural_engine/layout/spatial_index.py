# ruff: noqa: C901, D202, EM101, I001, PLR0913, PLR0917, TRY003, UP035

from collections.abc import Callable, Collection
from dataclasses import dataclass
import math
from typing import Sequence

from document_sdk.pdf._structural_engine.layout.contracts import (
    PdfLayoutNode,
    PdfLayoutSeparatorCandidate,
    PdfLayoutSeparatorOrientation,
)


@dataclass(frozen=True)
class PdfSpatialQueryResult:
    candidate_indices: tuple[int, ...]
    candidate_limit_reached: bool
    bucket_limit_reached: bool
    scanned_candidate_count: int
    scanned_bucket_count: int
    deadline_reached: bool


@dataclass(frozen=True)
class PdfSeparatorSpatialQueryResult:
    candidates: tuple[PdfLayoutSeparatorCandidate, ...]
    candidate_limit_reached: bool
    bucket_limit_reached: bool
    scanned_candidate_count: int
    scanned_bucket_count: int
    deadline_reached: bool


@dataclass(frozen=True)
class _SpatialPartition:
    subcolumn: int
    subrow: int
    x0: float
    y0: float
    x1: float
    y1: float
    node_indices: tuple[int, ...]

    @property
    def center(self) -> tuple[float, float]:
        return ((self.x0 + self.x1) / 2, (self.y0 + self.y1) / 2)


class PdfPageSpatialIndex:
    """Deterministic center-bucket index with bounded query work."""

    def __init__(
        self,
        *,
        nodes: Sequence[PdfLayoutNode],
        page_width: float,
        page_height: float,
        columns: int,
        rows: int,
        adaptive_partitioning: bool,
        target_nodes_per_partition: int,
        max_partition_subdivisions: int,
        indexed_node_indices: Collection[int] | None = None,
    ) -> None:
        if page_width <= 0 or page_height <= 0:
            raise ValueError("spatial index requires positive page dimensions")
        if columns <= 0 or rows <= 0:
            raise ValueError("spatial index dimensions must be positive")
        if target_nodes_per_partition <= 0:
            raise ValueError("spatial partition target must be positive")
        if max_partition_subdivisions <= 0:
            raise ValueError("spatial partition subdivisions must be positive")
        self._nodes = tuple(nodes)
        self._page_width = page_width
        self._page_height = page_height
        self._columns = columns
        self._rows = rows
        if indexed_node_indices is None:
            effective_node_indices = tuple(range(len(self._nodes)))
        else:
            effective_node_indices = tuple(sorted(set(indexed_node_indices)))
            if any(
                index < 0 or index >= len(self._nodes)
                for index in effective_node_indices
            ):
                raise ValueError("indexed node index is outside the page node set")
        buckets: dict[tuple[int, int], list[int]] = {}
        for index in effective_node_indices:
            node = self._nodes[index]
            key = self._bucket_for_point(*_bbox_center(node))
            buckets.setdefault(key, []).append(index)
        partitions_by_bucket: dict[
            tuple[int, int],
            tuple[_SpatialPartition, ...],
        ] = {}
        refined_base_bucket_count = 0
        for key, indices in sorted(buckets.items()):
            subdivisions = 1
            if adaptive_partitioning and len(indices) > target_nodes_per_partition:
                subdivisions = min(
                    max_partition_subdivisions,
                    max(
                        2,
                        math.ceil(math.sqrt(len(indices) / target_nodes_per_partition)),
                    ),
                )
            if subdivisions > 1:
                refined_base_bucket_count += 1
            partitions_by_bucket[key] = self._build_bucket_partitions(
                key=key,
                node_indices=indices,
                subdivisions=subdivisions,
            )
        self._partitions_by_bucket = partitions_by_bucket
        partitions = tuple(
            partition
            for bucket_partitions in partitions_by_bucket.values()
            for partition in bucket_partitions
        )
        self.partition_count = len(partitions)
        self.maximum_nodes_per_partition = max(
            (len(partition.node_indices) for partition in partitions),
            default=0,
        )
        self.refined_base_bucket_count = refined_base_bucket_count
        self._separator_candidates: tuple[PdfLayoutSeparatorCandidate, ...] = ()
        self._separator_indices_by_orientation_and_bucket: dict[
            tuple[PdfLayoutSeparatorOrientation, int, int],
            tuple[int, ...],
        ] = {}

    def index_separator_candidates(
        self,
        candidates: Sequence[PdfLayoutSeparatorCandidate],
        *,
        deadline_reached: Callable[[], bool] | None = None,
    ) -> bool:
        """Register bounded separator metadata in this page's spatial index."""

        ordered = tuple(sorted(candidates, key=_separator_static_sort_key))
        grouped: dict[
            tuple[PdfLayoutSeparatorOrientation, int, int],
            list[int],
        ] = {}
        complete = True
        for candidate_index, candidate in enumerate(ordered):
            if deadline_reached is not None and deadline_reached():
                complete = False
                break
            for column, row in self._region_bucket_keys(
                candidate.bbox.x0,
                candidate.bbox.y0,
                candidate.bbox.x1,
                candidate.bbox.y1,
            ):
                if deadline_reached is not None and deadline_reached():
                    complete = False
                    break
                grouped.setdefault(
                    (candidate.orientation, column, row),
                    [],
                ).append(candidate_index)
            if not complete:
                break
        self._separator_candidates = ordered
        self._separator_indices_by_orientation_and_bucket = {
            key: tuple(indices) for key, indices in sorted(grouped.items())
        }
        return complete

    def query_separators(
        self,
        *,
        orientation: PdfLayoutSeparatorOrientation,
        x0: float,
        y0: float,
        x1: float,
        y1: float,
        reference_x: float,
        reference_y: float,
        max_buckets: int,
        max_candidates: int,
        max_candidate_scan: int,
        deadline_reached: Callable[[], bool] | None = None,
    ) -> PdfSeparatorSpatialQueryResult:
        x0, y0, x1, y1 = self._bounded_region(x0, y0, x1, y1)
        bucket_keys = list(self._region_bucket_keys(x0, y0, x1, y1))
        bucket_keys.sort(
            key=lambda key: (
                math.hypot(
                    self._bucket_center(key)[0] - reference_x,
                    self._bucket_center(key)[1] - reference_y,
                ),
                key[1],
                key[0],
            )
        )
        bucket_limit_reached = len(bucket_keys) > max_buckets
        selected_bucket_keys = bucket_keys[:max_buckets]
        seen: set[int] = set()
        matches: list[PdfLayoutSeparatorCandidate] = []
        scanned_count = 0
        scanned_bucket_count = 0
        scan_limit_reached = False
        hit_deadline = False
        for column, row in selected_bucket_keys:
            if deadline_reached is not None and deadline_reached():
                hit_deadline = True
                break
            scanned_bucket_count += 1
            for (
                candidate_index
            ) in self._separator_indices_by_orientation_and_bucket.get(
                (orientation, column, row),
                (),
            ):
                if candidate_index in seen:
                    continue
                seen.add(candidate_index)
                if scanned_count >= max_candidate_scan:
                    scan_limit_reached = True
                    break
                if deadline_reached is not None and deadline_reached():
                    hit_deadline = True
                    break
                scanned_count += 1
                candidate = self._separator_candidates[candidate_index]
                if _regions_intersect(
                    x0,
                    y0,
                    x1,
                    y1,
                    candidate.bbox.x0,
                    candidate.bbox.y0,
                    candidate.bbox.x1,
                    candidate.bbox.y1,
                ):
                    matches.append(candidate)
            if scan_limit_reached or hit_deadline:
                break
        matches.sort(
            key=lambda candidate: (
                math.hypot(
                    _separator_center(candidate)[0] - reference_x,
                    _separator_center(candidate)[1] - reference_y,
                ),
                *_separator_static_sort_key(candidate),
            )
        )
        candidate_limit_reached = len(matches) > max_candidates or scan_limit_reached
        return PdfSeparatorSpatialQueryResult(
            candidates=tuple(matches[:max_candidates]),
            candidate_limit_reached=candidate_limit_reached,
            bucket_limit_reached=bucket_limit_reached,
            scanned_candidate_count=scanned_count,
            scanned_bucket_count=scanned_bucket_count,
            deadline_reached=hit_deadline,
        )

    def query(
        self,
        *,
        node_index: int,
        expand_x: float,
        expand_y: float,
        max_buckets: int,
        max_candidates: int,
        max_candidate_scan: int,
        deadline_reached: Callable[[], bool] | None = None,
    ) -> PdfSpatialQueryResult:
        node = self._nodes[node_index]
        center_x, center_y = _bbox_center(node)
        return self.query_region(
            x0=node.bbox.x0 - max(0.0, expand_x),
            y0=node.bbox.y0 - max(0.0, expand_y),
            x1=node.bbox.x1 + max(0.0, expand_x),
            y1=node.bbox.y1 + max(0.0, expand_y),
            reference_x=center_x,
            reference_y=center_y,
            excluded_indices={node_index},
            max_buckets=max_buckets,
            max_candidates=max_candidates,
            max_candidate_scan=max_candidate_scan,
            deadline_reached=deadline_reached,
        )

    def query_region(
        self,
        *,
        x0: float,
        y0: float,
        x1: float,
        y1: float,
        reference_x: float,
        reference_y: float,
        excluded_indices: Collection[int] = (),
        max_buckets: int,
        max_candidates: int,
        max_candidate_scan: int,
        deadline_reached: Callable[[], bool] | None = None,
    ) -> PdfSpatialQueryResult:
        x0, y0, x1, y1 = self._bounded_region(x0, y0, x1, y1)
        min_column, min_row = self._bucket_for_point(x0, y0)
        max_column, max_row = self._bucket_for_point(x1, y1)
        bucket_keys: list[tuple[int, int]] = []
        hit_deadline = False
        for row in range(min_row, max_row + 1):
            for column in range(min_column, max_column + 1):
                if deadline_reached is not None and deadline_reached():
                    hit_deadline = True
                    break
                bucket_keys.append((column, row))
            if hit_deadline:
                break
        partitions = [
            (bucket_key, partition)
            for bucket_key in bucket_keys
            for partition in self._partitions_by_bucket.get(bucket_key, ())
            if _regions_intersect(
                x0,
                y0,
                x1,
                y1,
                partition.x0,
                partition.y0,
                partition.x1,
                partition.y1,
            )
        ]
        partitions.sort(
            key=lambda item: (
                math.hypot(
                    item[1].center[0] - reference_x,
                    item[1].center[1] - reference_y,
                ),
                item[0][1],
                item[0][0],
                item[1].subrow,
                item[1].subcolumn,
            )
        )
        bucket_limit_reached = len(partitions) > max_buckets
        selected_partitions = partitions[:max_buckets]

        candidates: list[int] = []
        scanned_count = 0
        scanned_bucket_count = 0
        scan_limit_reached = False
        for _key, partition in selected_partitions:
            if deadline_reached is not None and deadline_reached():
                hit_deadline = True
                break
            scanned_bucket_count += 1
            for candidate_index in partition.node_indices:
                if candidate_index in excluded_indices:
                    continue
                if scanned_count >= max_candidate_scan:
                    scan_limit_reached = True
                    break
                scanned_count += 1
                center_x, center_y = _bbox_center(self._nodes[candidate_index])
                if x0 <= center_x <= x1 and y0 <= center_y <= y1:
                    candidates.append(candidate_index)
            if scan_limit_reached:
                break

        candidates.sort(
            key=lambda candidate_index: (
                math.hypot(
                    _bbox_center(self._nodes[candidate_index])[0] - reference_x,
                    _bbox_center(self._nodes[candidate_index])[1] - reference_y,
                ),
                self._nodes[candidate_index].source_order,
                self._nodes[candidate_index].node_id,
            )
        )
        candidate_limit_reached = len(candidates) > max_candidates or scan_limit_reached
        return PdfSpatialQueryResult(
            candidate_indices=tuple(candidates[:max_candidates]),
            candidate_limit_reached=candidate_limit_reached,
            bucket_limit_reached=bucket_limit_reached,
            scanned_candidate_count=scanned_count,
            scanned_bucket_count=scanned_bucket_count,
            deadline_reached=hit_deadline,
        )

    def _build_bucket_partitions(
        self,
        *,
        key: tuple[int, int],
        node_indices: list[int],
        subdivisions: int,
    ) -> tuple[_SpatialPartition, ...]:
        column, row = key
        bucket_width = self._page_width / self._columns
        bucket_height = self._page_height / self._rows
        bucket_x0 = column * bucket_width
        bucket_y0 = row * bucket_height
        partition_width = bucket_width / subdivisions
        partition_height = bucket_height / subdivisions
        grouped: dict[tuple[int, int], list[int]] = {}
        for node_index in node_indices:
            center_x, center_y = _bbox_center(self._nodes[node_index])
            subcolumn = min(
                subdivisions - 1,
                max(0, int((center_x - bucket_x0) / partition_width)),
            )
            subrow = min(
                subdivisions - 1,
                max(0, int((center_y - bucket_y0) / partition_height)),
            )
            grouped.setdefault((subcolumn, subrow), []).append(node_index)
        return tuple(
            _SpatialPartition(
                subcolumn=subcolumn,
                subrow=subrow,
                x0=bucket_x0 + subcolumn * partition_width,
                y0=bucket_y0 + subrow * partition_height,
                x1=min(
                    self._page_width,
                    bucket_x0 + (subcolumn + 1) * partition_width,
                ),
                y1=min(
                    self._page_height,
                    bucket_y0 + (subrow + 1) * partition_height,
                ),
                node_indices=tuple(indices),
            )
            for (subcolumn, subrow), indices in sorted(grouped.items())
        )

    def _bucket_for_point(self, x: float, y: float) -> tuple[int, int]:
        column = min(
            self._columns - 1,
            max(0, int((x / self._page_width) * self._columns)),
        )
        row = min(
            self._rows - 1,
            max(0, int((y / self._page_height) * self._rows)),
        )
        return column, row

    def _bounded_region(
        self,
        x0: float,
        y0: float,
        x1: float,
        y1: float,
    ) -> tuple[float, float, float, float]:
        bounded_x0 = min(self._page_width, max(0.0, x0))
        bounded_y0 = min(self._page_height, max(0.0, y0))
        bounded_x1 = min(self._page_width, max(0.0, x1))
        bounded_y1 = min(self._page_height, max(0.0, y1))
        if bounded_x1 < bounded_x0:
            bounded_x0, bounded_x1 = bounded_x1, bounded_x0
        if bounded_y1 < bounded_y0:
            bounded_y0, bounded_y1 = bounded_y1, bounded_y0
        return bounded_x0, bounded_y0, bounded_x1, bounded_y1

    def _region_bucket_keys(
        self,
        x0: float,
        y0: float,
        x1: float,
        y1: float,
    ) -> tuple[tuple[int, int], ...]:
        x0, y0, x1, y1 = self._bounded_region(x0, y0, x1, y1)
        min_column, min_row = self._bucket_for_point(x0, y0)
        max_column, max_row = self._bucket_for_point(x1, y1)
        return tuple(
            (column, row)
            for row in range(min_row, max_row + 1)
            for column in range(min_column, max_column + 1)
        )

    def _bucket_center(self, key: tuple[int, int]) -> tuple[float, float]:
        column, row = key
        return (
            (column + 0.5) * self._page_width / self._columns,
            (row + 0.5) * self._page_height / self._rows,
        )


def _bbox_center(node: PdfLayoutNode) -> tuple[float, float]:
    return (
        (node.bbox.x0 + node.bbox.x1) / 2,
        (node.bbox.y0 + node.bbox.y1) / 2,
    )


def _separator_center(
    candidate: PdfLayoutSeparatorCandidate,
) -> tuple[float, float]:
    return (
        (candidate.bbox.x0 + candidate.bbox.x1) / 2,
        (candidate.bbox.y0 + candidate.bbox.y1) / 2,
    )


def _separator_static_sort_key(
    candidate: PdfLayoutSeparatorCandidate,
) -> tuple[object, ...]:
    geometry_rank = {"precise": 0, "approximate": 1, "unknown": 2}
    return (
        -candidate.confidence,
        geometry_rank[candidate.geometry_quality],
        -candidate.page_coverage_ratio,
        candidate.separator_candidate_id,
    )


def _regions_intersect(
    first_x0: float,
    first_y0: float,
    first_x1: float,
    first_y1: float,
    second_x0: float,
    second_y0: float,
    second_x1: float,
    second_y1: float,
) -> bool:
    return not (
        first_x1 < second_x0
        or second_x1 < first_x0
        or first_y1 < second_y0
        or second_y1 < first_y0
    )

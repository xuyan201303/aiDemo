# ruff: noqa: C901, D202, EM101, I001, PLR0912, PLR0915, TRY003

from time import perf_counter
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from document_sdk.pdf._structural_engine.facts.status import (
    PdfExtractionStatus,
    PdfWarningCode,
)
from document_sdk.pdf._structural_engine.layout.contracts import (
    PDF_LAYOUT_RELATION_METHOD_VERSION,
    PdfLayoutEdge,
    PdfLayoutGraphArtifact,
    PdfLayoutPageGraph,
    PdfLayoutRelationType,
    is_symmetric_layout_relation,
)
from document_sdk.pdf._structural_engine.layout.identifiers import (
    layout_edge_identifier,
)
from document_sdk.pdf._structural_engine.layout.relations import (
    PdfLayoutRelationCandidate,
    PdfLayoutRelationOperationCounter,
    infer_layout_relations,
    layout_relation_corridors,
)
from document_sdk.pdf._structural_engine.layout.spatial_index import PdfPageSpatialIndex


PdfLayoutConsumerReadinessOutcome = Literal[
    "ready",
    "ready_with_limitations",
    "not_ready",
]
PdfLayoutConsumerLimitationCode = Literal[
    "source_document_partial",
    "source_page_partial",
    "source_geometry_low_confidence",
    "text_layer_incomplete",
    "source_content_lost",
    "spatial_text_conflict",
    "drawing_node_materialization_suppressed",
    "node_resource_truncated",
    "relation_search_truncated",
    "edge_inventory_hard_truncated",
    "separator_source_inventory_truncated",
    "separator_local_context_truncated",
    "separator_quality_metadata_truncated",
    "graph_resource_truncated",
    "graph_timeout",
    "graph_internal_error",
    "no_eligible_nodes",
    "drawing_only_page",
    "image_only_page",
]
PdfLayoutRelationObservationStatus = Literal[
    "candidate_observed",
    "unknown",
]
PdfLayoutPairEvaluationStatus = Literal["evaluated", "resource_limited"]
PDF_LAYOUT_STRUCTURAL_CONSUMER_CONTRACT_VERSION = "pdf_layout_structural_consumer.v2"


class PdfLayoutRelationObservation(BaseModel):
    """Consumer-safe lookup that never turns an omitted edge into false."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    status: PdfLayoutRelationObservationStatus
    edge_id: str | None = Field(default=None, pattern=r"^PDFLE-[0-9a-f]{24}$")
    candidate_confidence: float | None = Field(default=None, ge=0, le=1)
    absence_is_conclusive: Literal[False] = False

    @model_validator(mode="after")
    def validate_observation(self) -> "PdfLayoutRelationObservation":
        observed = self.status == "candidate_observed"
        if observed != (self.edge_id is not None):
            raise ValueError("observed relation status must match its edge")
        if observed != (self.candidate_confidence is not None):
            raise ValueError("observed relation status must match its confidence")
        return self


class PdfLayoutPageConsumerReadiness(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    page_number: int = Field(ge=1)
    outcome: PdfLayoutConsumerReadinessOutcome
    limitation_codes: tuple[PdfLayoutConsumerLimitationCode, ...]
    capabilities: "PdfLayoutConsumerCapabilities"

    @model_validator(mode="after")
    def validate_outcome(self) -> "PdfLayoutPageConsumerReadiness":
        if self.limitation_codes != tuple(sorted(set(self.limitation_codes))):
            raise ValueError("consumer limitation codes must be unique and sorted")
        if self.outcome == "ready" and self.limitation_codes:
            raise ValueError("ready page cannot carry limitations")
        if self.outcome != "ready" and not self.limitation_codes:
            raise ValueError("limited page requires a limitation code")
        return self


class PdfLayoutGraphConsumerReadiness(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    outcome: PdfLayoutConsumerReadinessOutcome
    limitation_codes: tuple[PdfLayoutConsumerLimitationCode, ...]
    ready_page_count: int = Field(ge=0)
    limited_page_count: int = Field(ge=0)
    not_ready_page_count: int = Field(ge=0)
    capabilities: "PdfLayoutConsumerCapabilities"
    pages: tuple[PdfLayoutPageConsumerReadiness, ...]

    @model_validator(mode="after")
    def validate_inventory(self) -> "PdfLayoutGraphConsumerReadiness":
        if self.limitation_codes != tuple(sorted(set(self.limitation_codes))):
            raise ValueError("graph limitation codes must be unique and sorted")
        counts = {
            "ready": self.ready_page_count,
            "ready_with_limitations": self.limited_page_count,
            "not_ready": self.not_ready_page_count,
        }
        if any(
            counts[outcome] != sum(page.outcome == outcome for page in self.pages)
            for outcome in counts
        ):
            raise ValueError("consumer page readiness counts are inconsistent")
        if self.outcome == "ready" and self.limitation_codes:
            raise ValueError("ready graph cannot carry limitations")
        if self.outcome != "ready" and not self.limitation_codes:
            raise ValueError("limited graph requires a limitation code")
        return self


class PdfLayoutConsumerCapabilities(BaseModel):
    """Actions a contract-aware downstream consumer may safely perform."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    nodes_usable: bool
    positive_relation_edges_usable: bool
    separator_exact_counts_usable: bool
    separator_lower_bounds_only: bool
    on_demand_relation_query_usable: bool
    automatic_table_candidate_allowed: bool
    fallback_required: bool
    abstention_required: bool
    structural_consumer_contract_version: str | None = None
    structural_candidate_input_usable: bool = False
    separator_evidence_usable: bool = False
    hard_resource_loss: bool = False
    limitations_must_be_propagated: bool = False
    automatic_unconditional_use_allowed: bool = False
    manual_review_recommended: bool = False
    fallback_recommended: bool = False

    @model_validator(mode="after")
    def validate_capabilities(self) -> "PdfLayoutConsumerCapabilities":
        if self.separator_exact_counts_usable and self.separator_lower_bounds_only:
            raise ValueError("separator evidence cannot be exact and lower-bound only")
        if self.automatic_table_candidate_allowed and (
            self.fallback_required or self.abstention_required
        ):
            raise ValueError(
                "automatic candidate use conflicts with fallback/abstention"
            )
        if self.abstention_required and self.nodes_usable:
            raise ValueError("mandatory abstention cannot expose usable nodes")
        if self.structural_candidate_input_usable and (
            not self.nodes_usable
            or not self.on_demand_relation_query_usable
            or self.abstention_required
        ):
            raise ValueError("structural input requires usable bounded graph evidence")
        if self.separator_evidence_usable and not self.nodes_usable:
            raise ValueError("separator evidence requires usable nodes")
        if self.hard_resource_loss and self.automatic_unconditional_use_allowed:
            raise ValueError("hard resource loss cannot be automatically accepted")
        if self.automatic_unconditional_use_allowed and (
            not self.structural_candidate_input_usable
            or self.limitations_must_be_propagated
            or self.manual_review_recommended
            or self.fallback_recommended
        ):
            raise ValueError("unconditional use conflicts with typed limitations")
        if self.hard_resource_loss and not self.limitations_must_be_propagated:
            raise ValueError("hard resource loss must be propagated")
        return self


PdfLayoutPageConsumerReadiness.model_rebuild()
PdfLayoutGraphConsumerReadiness.model_rebuild()


class PdfLayoutPairRelationEvaluation(BaseModel):
    """Bounded, read-only evaluation for a specific pair omitted from storage."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    status: PdfLayoutPairEvaluationStatus
    source_node_id: str = Field(pattern=r"^PDFLN-[0-9a-f]{24}$")
    target_node_id: str = Field(pattern=r"^PDFLN-[0-9a-f]{24}$")
    candidate_edges: tuple[PdfLayoutEdge, ...]
    relation_context_complete: bool
    separator_source_inventory_complete: bool
    separator_context_complete: bool
    relation_absence_semantics: Literal["unknown"] = "unknown"
    warning_codes: tuple[PdfWarningCode, ...] = ()

    @model_validator(mode="after")
    def validate_pair_result(self) -> "PdfLayoutPairRelationEvaluation":
        if self.source_node_id == self.target_node_id:
            raise ValueError("pair evaluation requires two distinct nodes")
        resource_limited = not (
            self.relation_context_complete
            and self.separator_source_inventory_complete
            and self.separator_context_complete
        )
        if (self.status == "resource_limited") != resource_limited:
            raise ValueError("pair evaluation status must match context completeness")
        if self.candidate_edges != tuple(
            sorted(
                self.candidate_edges,
                key=lambda edge: (
                    edge.source_node_id,
                    edge.target_node_id,
                    edge.relation_type,
                ),
            )
        ):
            raise ValueError("pair relation edges must use deterministic order")
        return self


def evaluate_layout_graph_consumer_readiness(
    graph: PdfLayoutGraphArtifact,
) -> PdfLayoutGraphConsumerReadiness:
    """Aggregate existing graph evidence without inferring document meaning."""

    pages = tuple(_evaluate_page_readiness(page) for page in graph.pages)
    graph_codes = {code for page in pages for code in page.limitation_codes}
    if graph.build_status is PdfExtractionStatus.INTERNAL_ERROR:
        graph_codes.add("graph_internal_error")
    if graph.source_document_partial_extraction:
        graph_codes.add("source_document_partial")
    if graph.build_status is PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED:
        graph_codes.add("graph_resource_truncated")
    if not pages:
        graph_codes.add("no_eligible_nodes")

    ready_count = sum(page.outcome == "ready" for page in pages)
    limited_count = sum(page.outcome == "ready_with_limitations" for page in pages)
    not_ready_count = sum(page.outcome == "not_ready" for page in pages)
    if not pages or not_ready_count == len(pages):
        outcome: PdfLayoutConsumerReadinessOutcome = "not_ready"
    elif graph_codes or limited_count or not_ready_count:
        outcome = "ready_with_limitations"
    else:
        outcome = "ready"
    page_capabilities = tuple(page.capabilities for page in pages)
    graph_recovery_required = bool(
        graph.source_document_partial_extraction
        or (
            graph.partial_build
            and graph.graph_page_count < graph.source_extracted_page_count
        )
        or graph.build_status is PdfExtractionStatus.INTERNAL_ERROR
        or not pages
    )
    graph_capabilities = PdfLayoutConsumerCapabilities(
        nodes_usable=bool(page_capabilities)
        and all(item.nodes_usable for item in page_capabilities),
        positive_relation_edges_usable=bool(page_capabilities)
        and all(item.positive_relation_edges_usable for item in page_capabilities),
        separator_exact_counts_usable=bool(page_capabilities)
        and all(item.separator_exact_counts_usable for item in page_capabilities),
        separator_lower_bounds_only=any(
            item.separator_lower_bounds_only for item in page_capabilities
        ),
        on_demand_relation_query_usable=bool(page_capabilities)
        and all(item.on_demand_relation_query_usable for item in page_capabilities),
        automatic_table_candidate_allowed=(
            outcome == "ready"
            and bool(page_capabilities)
            and all(
                item.automatic_table_candidate_allowed for item in page_capabilities
            )
        ),
        fallback_required=(
            graph_recovery_required
            or any(item.fallback_required for item in page_capabilities)
        ),
        abstention_required=(
            outcome == "not_ready"
            or any(item.abstention_required for item in page_capabilities)
        ),
        structural_consumer_contract_version=(
            PDF_LAYOUT_STRUCTURAL_CONSUMER_CONTRACT_VERSION
        ),
        structural_candidate_input_usable=bool(page_capabilities)
        and all(item.structural_candidate_input_usable for item in page_capabilities),
        separator_evidence_usable=bool(page_capabilities)
        and all(item.separator_evidence_usable for item in page_capabilities),
        hard_resource_loss=any(item.hard_resource_loss for item in page_capabilities),
        limitations_must_be_propagated=(
            outcome != "ready"
            or any(item.limitations_must_be_propagated for item in page_capabilities)
        ),
        automatic_unconditional_use_allowed=(
            outcome == "ready"
            and bool(page_capabilities)
            and all(
                item.automatic_unconditional_use_allowed for item in page_capabilities
            )
        ),
        manual_review_recommended=any(
            item.manual_review_recommended for item in page_capabilities
        ),
        fallback_recommended=any(
            item.fallback_recommended for item in page_capabilities
        )
        or graph_recovery_required,
    )
    return PdfLayoutGraphConsumerReadiness(
        outcome=outcome,
        limitation_codes=tuple(sorted(graph_codes)),
        ready_page_count=ready_count,
        limited_page_count=limited_count,
        not_ready_page_count=not_ready_count,
        capabilities=graph_capabilities,
        pages=pages,
    )


def observe_layout_relation(
    *,
    page: PdfLayoutPageGraph,
    source_node_id: str,
    target_node_id: str,
    relation_type: PdfLayoutRelationType,
) -> PdfLayoutRelationObservation:
    """Return candidate evidence or unknown; absence is never negative evidence."""

    node_ids = {node.node_id for node in page.nodes}
    if source_node_id == target_node_id:
        raise ValueError("relation observation requires two distinct nodes")
    if source_node_id not in node_ids or target_node_id not in node_ids:
        raise ValueError("relation observation references an unknown page node")
    edge = next(
        (
            item
            for item in page.edges
            if item.relation_type == relation_type
            and (
                (
                    item.source_node_id == source_node_id
                    and item.target_node_id == target_node_id
                )
                or (
                    is_symmetric_layout_relation(relation_type)
                    and item.source_node_id == target_node_id
                    and item.target_node_id == source_node_id
                )
            )
        ),
        None,
    )
    if edge is None:
        return PdfLayoutRelationObservation(status="unknown")
    return PdfLayoutRelationObservation(
        status="candidate_observed",
        edge_id=edge.edge_id,
        candidate_confidence=edge.confidence,
    )


def evaluate_layout_relation_pair(
    *,
    graph: PdfLayoutGraphArtifact,
    page_number: int,
    source_node_id: str,
    target_node_id: str,
) -> PdfLayoutPairRelationEvaluation:
    """Evaluate one pair with the existing geometry engine and bounded context."""

    page = next((item for item in graph.pages if item.page_number == page_number), None)
    if page is None:
        raise ValueError("pair evaluation references an unknown graph page")
    node_index_by_id = {node.node_id: index for index, node in enumerate(page.nodes)}
    if source_node_id == target_node_id:
        raise ValueError("pair evaluation requires two distinct nodes")
    if source_node_id not in node_index_by_id or target_node_id not in node_index_by_id:
        raise ValueError("pair evaluation references an unknown page node")

    source_index = node_index_by_id[source_node_id]
    target_index = node_index_by_id[target_node_id]
    source = page.nodes[source_index]
    target = page.nodes[target_index]
    options = graph.build_options
    limits = graph.applied_limits
    deadline = perf_counter() + (limits.max_page_build_milliseconds / 1_000)
    index = PdfPageSpatialIndex(
        nodes=page.nodes,
        page_width=page.canonical_width,
        page_height=page.canonical_height,
        columns=options.grid_columns,
        rows=options.grid_rows,
        adaptive_partitioning=options.adaptive_spatial_partitioning,
        target_nodes_per_partition=options.spatial_partition_target_nodes,
        max_partition_subdivisions=options.spatial_partition_max_subdivisions,
    )
    retained_context_indices: set[int] = set()
    relation_context_complete = True
    for corridor in layout_relation_corridors(
        first=source,
        second=target,
        options=options,
    ):
        center_x, center_y = corridor.center
        query = index.query_region(
            x0=corridor.x0,
            y0=corridor.y0,
            x1=corridor.x1,
            y1=corridor.y1,
            reference_x=center_x,
            reference_y=center_y,
            excluded_indices={source_index, target_index},
            max_buckets=limits.max_spatial_buckets_per_query,
            max_candidates=limits.max_intervening_candidates_per_relation,
            max_candidate_scan=limits.max_intervening_candidate_scan,
            deadline_reached=lambda: perf_counter() > deadline,
        )
        retained_context_indices.update(query.candidate_indices)
        relation_context_complete = relation_context_complete and not any(
            (
                query.candidate_limit_reached,
                query.bucket_limit_reached,
                query.deadline_reached,
            )
        )
    nearby_nodes = tuple(
        page.nodes[index] for index in sorted(retained_context_indices)
    )
    separator_source_complete = not (
        page.resource_usage.separator_source_inventory_truncated
    )
    separator_context_complete = (
        len(page.separator_candidates) <= limits.max_separator_scans_per_relation
        and perf_counter() <= deadline
    )
    operation_counter = PdfLayoutRelationOperationCounter()
    candidates = infer_layout_relations(
        first=source,
        second=target,
        page_width=page.canonical_width,
        page_height=page.canonical_height,
        options=options,
        nearby_nodes=nearby_nodes,
        relation_context_complete=relation_context_complete,
        operation_counter=operation_counter,
        deadline_reached=lambda: perf_counter() > deadline,
        separator_candidates=page.separator_candidates,
        separator_source_inventory_complete=separator_source_complete,
        separator_context_complete=separator_context_complete,
        max_separator_scans=limits.max_separator_scans_per_relation,
        max_separator_evidence=limits.max_separator_evidence_per_edge,
    )
    separator_context_complete = separator_context_complete and not any(
        candidate.separator_context_truncated for candidate in candidates
    )
    edges = tuple(
        sorted(
            (
                _pair_candidate_edge(page=page, candidate=candidate)
                for candidate in candidates
            ),
            key=lambda edge: (
                edge.source_node_id,
                edge.target_node_id,
                edge.relation_type,
            ),
        )
    )
    warning_codes = tuple(
        sorted(
            {
                warning
                for candidate in candidates
                for warning in candidate.warning_codes
            },
            key=lambda warning: warning.value,
        )
    )
    complete = (
        relation_context_complete
        and separator_source_complete
        and separator_context_complete
    )
    return PdfLayoutPairRelationEvaluation(
        status="evaluated" if complete else "resource_limited",
        source_node_id=source_node_id,
        target_node_id=target_node_id,
        candidate_edges=edges,
        relation_context_complete=relation_context_complete,
        separator_source_inventory_complete=separator_source_complete,
        separator_context_complete=separator_context_complete,
        warning_codes=warning_codes,
    )


def _pair_candidate_edge(
    *,
    page: PdfLayoutPageGraph,
    candidate: PdfLayoutRelationCandidate,
) -> PdfLayoutEdge:
    return PdfLayoutEdge(
        edge_id=layout_edge_identifier(
            page_graph_id=page.page_graph_id,
            source_node_id=candidate.source_node_id,
            target_node_id=candidate.target_node_id,
            relation_type=candidate.relation_type,
            method_version=PDF_LAYOUT_RELATION_METHOD_VERSION,
            adjacency_basis=candidate.adjacency_basis,
        ),
        source_node_id=candidate.source_node_id,
        target_node_id=candidate.target_node_id,
        relation_type=candidate.relation_type,
        adjacency_basis=candidate.adjacency_basis,
        confidence=candidate.confidence,
        base_confidence=candidate.base_confidence,
        separator_confidence_reduction=candidate.separator_confidence_reduction,
        separator_candidate_ids=candidate.separator_candidate_ids,
        relevant_separator_count=candidate.relevant_separator_count,
        retained_separator_evidence_count=candidate.retained_separator_evidence_count,
        separator_source_inventory_truncated=(
            candidate.separator_source_inventory_truncated
        ),
        separator_context_truncated=candidate.separator_context_truncated,
        separator_id_list_truncated=candidate.separator_id_list_truncated,
        relevant_separator_count_is_lower_bound=(
            candidate.relevant_separator_count_is_lower_bound
        ),
        separator_evidence_truncated=candidate.separator_evidence_truncated,
        geometry_evidence=candidate.geometry_evidence,
        warning_codes=candidate.warning_codes,
    )


def exact_relevant_separator_count(edge: PdfLayoutEdge) -> int:
    """Return an exact observed count or reject lower-bound evidence."""

    if edge.relevant_separator_count_is_lower_bound:
        raise ValueError("separator count is a lower bound, not an exact count")
    return edge.relevant_separator_count


def _evaluate_page_readiness(
    page: PdfLayoutPageGraph,
) -> PdfLayoutPageConsumerReadiness:
    quality = page.quality_signals
    usage = page.resource_usage
    selection = quality.text_layer_selection
    codes: set[PdfLayoutConsumerLimitationCode] = set()
    if quality.parser_quality.source_page_partial:
        codes.add("source_page_partial")
    if (
        quality.parser_quality.geometry_confidence == "low"
        or quality.parser_quality.geometry_completeness != "complete"
    ):
        codes.add("source_geometry_low_confidence")
    if selection.selected_layer_incomplete:
        codes.add("text_layer_incomplete")
    source_content_lost = bool(
        selection.source_fact_available_graph_missing_count
        or selection.supplemental_truncation_count
    )
    if source_content_lost:
        codes.add("source_content_lost")
    if selection.text_conflict_detected:
        codes.add("spatial_text_conflict")
    drawing_policy_suppressed = bool(
        usage.drawing_node_suppression_metrics_available
        and usage.drawing_node_suppressed_count > 0
    )
    if drawing_policy_suppressed:
        codes.add("drawing_node_materialization_suppressed")
    effective_eligible_fact_count = usage.eligible_fact_count - (
        usage.drawing_node_suppressed_count
        if usage.drawing_node_suppression_metrics_available
        else 0
    )
    if (
        quality.node_retention_completeness < 1
        or usage.retained_node_count < effective_eligible_fact_count
    ):
        codes.add("node_resource_truncated")
    if page.relation_observation.relation_search_truncated:
        codes.add("relation_search_truncated")
    if usage.hard_edge_limit_reached:
        codes.add("edge_inventory_hard_truncated")
    if quality.resource_truncation:
        codes.add("graph_resource_truncated")
    if usage.separator_source_inventory_truncated:
        codes.add("separator_source_inventory_truncated")
    if usage.separator_relation_context_truncation_count:
        codes.add("separator_local_context_truncated")
    if usage.separator_candidate_quality_truncation_count:
        codes.add("separator_quality_metadata_truncated")
    if any(
        warning.code is PdfWarningCode.EXTRACTION_TIMEOUT for warning in page.warnings
    ):
        codes.add("graph_timeout")
    if page.build_status is PdfExtractionStatus.INTERNAL_ERROR:
        codes.add("graph_internal_error")

    text_count = sum(
        node.node_type in {"word", "text_span", "line_candidate"} for node in page.nodes
    )
    drawing_count = sum(node.node_type == "drawing" for node in page.nodes)
    image_count = sum(node.node_type == "image_region" for node in page.nodes)
    if not page.nodes:
        codes.add("no_eligible_nodes")
    elif drawing_count and not text_count and not image_count:
        codes.add("drawing_only_page")
    elif image_count and not text_count and not drawing_count:
        codes.add("image_only_page")

    blocking = bool(
        {"graph_internal_error", "no_eligible_nodes"} & codes
        or ("graph_timeout" in codes and not page.nodes)
    )
    outcome: PdfLayoutConsumerReadinessOutcome
    if blocking:
        outcome = "not_ready"
    elif codes:
        outcome = "ready_with_limitations"
    else:
        outcome = "ready"
    nodes_usable = bool(page.nodes) and not blocking
    relation_edges_usable = nodes_usable
    separator_incomplete = bool(
        {
            "separator_source_inventory_truncated",
            "separator_local_context_truncated",
        }
        & codes
    )
    hard_resource_codes = {
        "source_content_lost",
        "node_resource_truncated",
        "edge_inventory_hard_truncated",
        "separator_source_inventory_truncated",
        "graph_timeout",
        "graph_internal_error",
        "no_eligible_nodes",
    }
    hard_resource_loss = bool(hard_resource_codes & codes)
    on_demand_relation_usable = (
        nodes_usable and not hard_resource_loss and "graph_internal_error" not in codes
    )
    structural_candidate_input_usable = (
        nodes_usable and on_demand_relation_usable and not blocking
    )
    parser_level_gap = bool(
        {
            "source_page_partial",
            "source_geometry_low_confidence",
            "text_layer_incomplete",
            "spatial_text_conflict",
        }
        & codes
    )
    parser_recovery_required = bool(parser_level_gap or hard_resource_loss)
    capabilities = PdfLayoutConsumerCapabilities(
        nodes_usable=nodes_usable,
        positive_relation_edges_usable=relation_edges_usable,
        separator_exact_counts_usable=nodes_usable and not separator_incomplete,
        separator_lower_bounds_only=nodes_usable and separator_incomplete,
        on_demand_relation_query_usable=on_demand_relation_usable,
        automatic_table_candidate_allowed=outcome == "ready",
        fallback_required=(
            outcome == "not_ready"
            or (outcome == "ready_with_limitations" and parser_recovery_required)
        ),
        abstention_required=outcome == "not_ready",
        structural_consumer_contract_version=(
            PDF_LAYOUT_STRUCTURAL_CONSUMER_CONTRACT_VERSION
        ),
        structural_candidate_input_usable=structural_candidate_input_usable,
        separator_evidence_usable=nodes_usable,
        hard_resource_loss=hard_resource_loss,
        limitations_must_be_propagated=outcome != "ready",
        automatic_unconditional_use_allowed=outcome == "ready",
        manual_review_recommended=outcome == "ready_with_limitations",
        fallback_recommended=(
            outcome == "ready_with_limitations" and parser_recovery_required
        ),
    )
    return PdfLayoutPageConsumerReadiness(
        page_number=page.page_number,
        outcome=outcome,
        limitation_codes=tuple(sorted(codes)),
        capabilities=capabilities,
    )

# ruff: noqa: EM101, I001, TRY003

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


MIN_PDF_LAYOUT_GRAPH_ARTIFACT_SERIALIZED_BYTES = 16 * 1024

PdfLayoutTextNodePolicy = Literal[
    "prefer_words",
    "prefer_text_spans",
    "prefer_line_candidates",
]


class PdfLayoutGraphOptions(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    text_node_policy: PdfLayoutTextNodePolicy = "prefer_words"
    include_drawings: bool = True
    include_image_regions: bool = True
    grid_columns: int = Field(default=32, ge=4, le=128)
    grid_rows: int = Field(default=32, ge=4, le=128)
    adaptive_spatial_partitioning: bool = True
    spatial_partition_target_nodes: int = Field(default=32, ge=4, le=4_096)
    spatial_partition_max_subdivisions: int = Field(default=8, ge=1, le=32)
    horizontal_search_radius_ratio: float = Field(default=0.08, gt=0, le=1)
    vertical_search_radius_ratio: float = Field(default=0.04, gt=0, le=1)
    node_size_search_multiplier: float = Field(default=3.0, ge=1, le=20)
    minimum_axis_overlap_ratio: float = Field(default=0.5, ge=0, le=1)
    alignment_tolerance_ratio: float = Field(default=0.35, ge=0, le=2)
    adjacency_gap_multiplier: float = Field(default=4.0, gt=0, le=20)
    maximum_mutual_nearest_gap_page_ratio: float = Field(
        default=0.75,
        gt=0,
        le=1,
    )
    mutual_nearest_boundary_band_ratio: float = Field(
        default=0.10,
        ge=0,
        le=0.5,
    )
    maximum_boundary_band_horizontal_gap_page_ratio: float = Field(
        default=0.35,
        gt=0,
        le=1,
    )
    containment_tolerance_points: float = Field(default=0.5, ge=0, le=20)
    minimum_containment_ratio: float = Field(default=0.98, ge=0.5, le=1)
    minimum_overlap_ratio: float = Field(default=0.05, ge=0, le=1)
    rotation_tolerance_degrees: float = Field(default=5.0, ge=0, le=45)
    minimum_preferred_text_layer_coverage_ratio: float = Field(
        default=0.8,
        ge=0,
        le=1,
    )
    minimum_text_layer_valid_geometry_ratio: float = Field(
        default=0.8,
        ge=0,
        le=1,
    )
    minimum_text_layer_fallback_score_improvement: float = Field(
        default=0.05,
        ge=0,
        le=1,
    )
    text_duplicate_bbox_tolerance_points: float = Field(
        default=2.0,
        ge=0,
        le=20,
    )
    text_duplicate_center_tolerance_points: float = Field(
        default=2.0,
        gt=0,
        le=20,
    )
    minimum_text_duplicate_iou_ratio: float = Field(
        default=0.85,
        ge=0,
        le=1,
    )
    maximum_preferred_text_layer_spatial_duplicate_ratio: float = Field(
        default=0.25,
        ge=0,
        le=1,
    )
    maximum_preferred_text_layer_spatial_conflict_ratio: float = Field(
        default=0.25,
        ge=0,
        le=1,
    )
    separator_minimum_length_points: float = Field(default=12.0, ge=0, le=500)
    separator_minimum_page_coverage_ratio: float = Field(
        default=0.01,
        ge=0,
        le=1,
    )
    separator_orientation_ratio: float = Field(default=4.0, ge=1, le=100)
    separator_path_minimum_axis_ratio: float = Field(default=8.0, ge=2, le=200)
    separator_thin_shape_maximum_thickness_points: float = Field(
        default=4.0,
        ge=0,
        le=50,
    )
    separator_nearby_search_points: float = Field(default=12.0, ge=0, le=100)
    separator_page_boundary_tolerance_points: float = Field(
        default=2.0,
        ge=0,
        le=20,
    )
    separator_minimum_confidence: float = Field(default=0.5, ge=0, le=1)
    separator_max_confidence_reduction: float = Field(
        default=0.35,
        ge=0,
        le=1,
    )


class PdfLayoutGraphLimits(BaseModel):
    """Page-local graph guardrails independent from PDF extraction limits."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    max_nodes_per_page: int = Field(default=25_000, ge=1)
    max_edges_per_page: int = Field(default=200_000, ge=1)
    max_candidates_per_node: int = Field(default=64, ge=1, le=4_096)
    max_relation_candidates_per_page: int = Field(
        default=200_000,
        ge=1,
        le=2_000_000,
    )
    max_retained_edges_per_node_per_relation: int = Field(
        default=4,
        ge=1,
        le=256,
    )
    max_generic_drawing_relation_nodes_per_page: int = Field(
        default=64,
        ge=0,
        le=4_096,
    )
    max_spatial_buckets_per_query: int = Field(default=1_024, ge=1, le=16_384)
    max_candidate_scan_per_node: int = Field(default=256, ge=1, le=16_384)
    max_intervening_candidates_per_relation: int = Field(
        default=32,
        ge=1,
        le=4_096,
    )
    max_intervening_candidate_scan: int = Field(
        default=128,
        ge=1,
        le=16_384,
    )
    max_text_alternatives_per_spatial_cluster: int = Field(
        default=64,
        ge=1,
        le=250_000,
    )
    max_supplemental_text_nodes_per_page: int = Field(
        default=2_048,
        ge=0,
        le=100_000,
    )
    max_supplemental_text_nodes_per_region: int = Field(
        default=4,
        ge=1,
        le=256,
    )
    max_supplemental_text_fact_scan: int = Field(
        default=100_000,
        ge=1,
        le=2_000_000,
    )
    max_separator_candidates_per_page: int = Field(
        default=4_096,
        ge=1,
        le=100_000,
    )
    max_separator_primitives_per_drawing: int = Field(default=64, ge=1, le=4_096)
    max_separator_nearby_nodes: int = Field(default=64, ge=1, le=4_096)
    max_separator_candidate_scan: int = Field(default=256, ge=1, le=16_384)
    max_separator_scans_per_relation: int = Field(
        default=64,
        ge=1,
        le=16_384,
    )
    max_separator_evidence_per_edge: int = Field(default=8, ge=1, le=1_024)
    max_separator_relation_queries_per_page: int = Field(
        default=200_000,
        ge=1,
        le=2_000_000,
    )
    max_overlaps_per_node: int = Field(default=32, ge=1, le=4_096)
    max_containment_edges_per_node: int = Field(default=32, ge=1, le=4_096)
    max_page_build_milliseconds: float = Field(default=5_000.0, gt=0)
    max_total_nodes: int = Field(default=250_000, ge=1)
    max_total_edges: int = Field(default=2_000_000, ge=1)
    max_warning_count: int = Field(default=1_000, ge=1)
    max_serialized_artifact_bytes: int = Field(
        default=256 * 1024 * 1024,
        ge=MIN_PDF_LAYOUT_GRAPH_ARTIFACT_SERIALIZED_BYTES,
    )

    @model_validator(mode="after")
    def validate_candidate_scan_budget(self) -> "PdfLayoutGraphLimits":
        if self.max_candidate_scan_per_node < self.max_candidates_per_node:
            raise ValueError(
                "candidate scan budget cannot be smaller than retained candidates"
            )
        if (
            self.max_intervening_candidate_scan
            < self.max_intervening_candidates_per_relation
        ):
            raise ValueError(
                "intervening scan budget cannot be smaller than retained context"
            )
        if self.max_separator_candidate_scan < self.max_separator_nearby_nodes:
            raise ValueError(
                "separator scan budget cannot be smaller than retained nearby nodes"
            )
        if self.max_separator_scans_per_relation < self.max_separator_evidence_per_edge:
            raise ValueError(
                "separator relation scan budget cannot be smaller than edge evidence"
            )
        return self

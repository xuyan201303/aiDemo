# ruff: noqa: C901, PLR0911, PLR0912, PLR0913, PLR0915, PLR2004

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from time import perf_counter

from document_sdk.pdf._structural_engine.facts.contracts import (
    PdfBoundingBox,
    PdfDrawingFact,
    PdfNormalizedBoundingBox,
)
from document_sdk.pdf._structural_engine.layout.contracts import (
    PdfLayoutNode,
    PdfLayoutPageBoundarySide,
    PdfLayoutSeparatorCandidate,
    PdfLayoutSeparatorOrientation,
    PdfLayoutSeparatorPrimitiveSource,
    layout_separator_sort_key,
)
from document_sdk.pdf._structural_engine.layout.identifiers import (
    layout_page_boundary_separator_identifier,
    layout_separator_identifier,
)
from document_sdk.pdf._structural_engine.layout.limits import (
    PdfLayoutGraphLimits,
    PdfLayoutGraphOptions,
)
from document_sdk.pdf._structural_engine.layout.spatial_index import PdfPageSpatialIndex


@dataclass(frozen=True)
class PdfLayoutSeparatorBuildResult:
    candidates: tuple[PdfLayoutSeparatorCandidate, ...]
    source_drawing_fact_count: int
    evaluated_drawing_fact_count: int
    retained_primitive_count: int
    drawing_primitive_extraction_milliseconds: float
    separator_generation_milliseconds: float
    query_count: int
    scanned_candidate_count: int
    scanned_partition_count: int
    query_truncation_count: int
    quality_metadata_truncation_count: int
    candidate_limit_reached: bool
    deadline_reached: bool
    source_inventory_truncated: bool
    path_geometry_incomplete_count: int
    primitive_truncation_count: int


@dataclass(frozen=True)
class _SeparatorPrimitive:
    orientation: PdfLayoutSeparatorOrientation
    bbox: PdfBoundingBox
    source_type: PdfLayoutSeparatorPrimitiveSource
    confidence_multiplier: float


def build_drawing_separator_candidates(
    *,
    page_graph_id: str,
    nodes: Sequence[PdfLayoutNode],
    drawing_facts_by_id: Mapping[str, PdfDrawingFact],
    spatial_index: PdfPageSpatialIndex,
    page_width: float,
    page_height: float,
    options: PdfLayoutGraphOptions,
    limits: PdfLayoutGraphLimits,
    deadline_reached: Callable[[], bool],
) -> PdfLayoutSeparatorBuildResult:
    started_at = perf_counter()
    drawing_primitive_extraction_milliseconds = 0.0
    node_index_by_id = {node.node_id: index for index, node in enumerate(nodes)}
    candidates = list(
        _canonical_page_boundary_candidates(
            page_graph_id=page_graph_id,
            page_width=page_width,
            page_height=page_height,
        )
    )
    query_count = 0
    scanned_candidate_count = 0
    scanned_partition_count = 0
    query_truncation_count = 0
    quality_metadata_truncation_count = 0
    hit_candidate_limit = False
    hit_deadline = False
    path_geometry_incomplete_count = 0
    primitive_truncation_count = 0
    source_geometry_truncated = False
    evaluated_drawing_fact_count = 0
    drawing_nodes = sorted(
        (node for node in nodes if node.node_type == "drawing"),
        key=lambda node: (node.source_order, node.node_id),
    )
    for node in drawing_nodes:
        if deadline_reached():
            hit_deadline = True
            break
        evaluated_drawing_fact_count += 1
        fact = drawing_facts_by_id.get(node.source_fact_id)
        if fact is None or fact.is_clipping_path or fact.paint_operation == "clip":
            continue
        primitive_started_at = perf_counter()
        all_primitives = _drawing_separator_primitives(
            node=node,
            fact=fact,
            options=options,
        )
        drawing_primitive_extraction_milliseconds += (
            perf_counter() - primitive_started_at
        ) * 1_000
        if fact.path_segment_truncated or fact.path_segment_count_is_lower_bound:
            source_geometry_truncated = True
            path_geometry_incomplete_count += 1
        elif fact.path_segment_count and not fact.path_geometry_complete:
            path_geometry_incomplete_count += 1
        if len(all_primitives) > limits.max_separator_primitives_per_drawing:
            source_geometry_truncated = True
            primitive_truncation_count += 1
        primitives = all_primitives[: limits.max_separator_primitives_per_drawing]
        for primitive in primitives:
            if deadline_reached():
                hit_deadline = True
                break
            orientation = primitive.orientation
            line_length = _bbox_axis_length(
                bbox=primitive.bbox,
                orientation=orientation,
            )
            page_axis_length = (
                page_width if orientation == "horizontal" else page_height
            )
            coverage_ratio = min(1.0, line_length / max(page_axis_length, 1.0))
            if (
                line_length < options.separator_minimum_length_points
                or coverage_ratio < options.separator_minimum_page_coverage_ratio
            ):
                continue
            if (
                _coincident_page_boundary_side(
                    primitive=primitive,
                    page_width=page_width,
                    page_height=page_height,
                    tolerance=options.separator_page_boundary_tolerance_points,
                )
                is not None
            ):
                continue
            if len(candidates) >= max(
                4,
                limits.max_separator_candidates_per_page,
            ):
                hit_candidate_limit = True
                break

            expansion = max(
                options.separator_nearby_search_points,
                _effective_stroke_width(fact) or 0.0,
            )
            center_x, center_y = _bbox_center(primitive.bbox)
            query = spatial_index.query_region(
                x0=primitive.bbox.x0 - expansion,
                y0=primitive.bbox.y0 - expansion,
                x1=primitive.bbox.x1 + expansion,
                y1=primitive.bbox.y1 + expansion,
                reference_x=center_x,
                reference_y=center_y,
                excluded_indices={node_index_by_id[node.node_id]},
                max_buckets=limits.max_spatial_buckets_per_query,
                max_candidates=limits.max_separator_nearby_nodes,
                max_candidate_scan=limits.max_separator_candidate_scan,
                deadline_reached=deadline_reached,
            )
            query_count += 1
            scanned_candidate_count += query.scanned_candidate_count
            scanned_partition_count += query.scanned_bucket_count
            if (
                query.candidate_limit_reached
                or query.bucket_limit_reached
                or query.deadline_reached
            ):
                query_truncation_count += 1
            if query.deadline_reached:
                hit_deadline = True
                break
            quality_metadata_truncated = bool(
                query.candidate_limit_reached or query.bucket_limit_reached
            )
            if quality_metadata_truncated:
                quality_metadata_truncation_count += 1
            nearby_nodes = tuple(
                nodes[index]
                for index in query.candidate_indices
                if nodes[index].node_type != "drawing"
            )
            touching_count = sum(
                _node_touches_bbox(
                    node=nearby,
                    separator_bbox=primitive.bbox,
                    tolerance=max(
                        1.0,
                        (_effective_stroke_width(fact) or 0.0) / 2,
                    ),
                )
                for nearby in nearby_nodes
            )
            confidence = (
                _separator_confidence(
                    coverage_ratio=coverage_ratio,
                    geometry_quality=node.geometry_quality,
                    nearby_node_count=len(nearby_nodes),
                    touching_node_count=touching_count,
                    paint_operation=fact.paint_operation,
                )
                * primitive.confidence_multiplier
                * _page_border_confidence_multiplier(
                    primitive=primitive,
                    page_width=page_width,
                    page_height=page_height,
                )
            )
            if confidence < options.separator_minimum_confidence:
                continue
            primitive_key = ":".join(
                (
                    primitive.source_type,
                    *(
                        f"{value:.6f}"
                        for value in (
                            primitive.bbox.x0,
                            primitive.bbox.y0,
                            primitive.bbox.x1,
                            primitive.bbox.y1,
                        )
                    ),
                )
            )
            candidates.append(
                PdfLayoutSeparatorCandidate(
                    separator_candidate_id=layout_separator_identifier(
                        page_graph_id=page_graph_id,
                        drawing_node_id=node.node_id,
                        orientation=orientation,
                        primitive_key=primitive_key,
                    ),
                    drawing_node_id=node.node_id,
                    orientation=orientation,
                    evidence_kind="drawing_separator",
                    source_kind="drawing_fact",
                    primitive_source_type=primitive.source_type,
                    bbox=primitive.bbox,
                    normalized_bbox=_normalized_bbox(
                        bbox=primitive.bbox,
                        page_width=page_width,
                        page_height=page_height,
                    ),
                    line_length=round(line_length, 6),
                    stroke_width=_effective_stroke_width(fact),
                    nearby_node_count=len(nearby_nodes),
                    crossing_or_touching_node_count=touching_count,
                    page_coverage_ratio=round(coverage_ratio, 6),
                    confidence=round(min(1.0, confidence), 6),
                    geometry_quality=node.geometry_quality,
                    paint_operation=fact.paint_operation,
                    clipping_application=fact.bbox_semantics.clipping_application,
                    quality_metadata_truncated=quality_metadata_truncated,
                )
            )
        if hit_candidate_limit or hit_deadline:
            break

    candidates.sort(key=layout_separator_sort_key)
    total_elapsed_milliseconds = (perf_counter() - started_at) * 1_000
    return PdfLayoutSeparatorBuildResult(
        candidates=tuple(candidates),
        source_drawing_fact_count=len(drawing_facts_by_id),
        evaluated_drawing_fact_count=evaluated_drawing_fact_count,
        retained_primitive_count=len(candidates),
        drawing_primitive_extraction_milliseconds=(
            drawing_primitive_extraction_milliseconds
        ),
        separator_generation_milliseconds=max(
            0.0,
            total_elapsed_milliseconds - drawing_primitive_extraction_milliseconds,
        ),
        query_count=query_count,
        scanned_candidate_count=scanned_candidate_count,
        scanned_partition_count=scanned_partition_count,
        query_truncation_count=query_truncation_count,
        quality_metadata_truncation_count=quality_metadata_truncation_count,
        candidate_limit_reached=hit_candidate_limit,
        deadline_reached=hit_deadline,
        source_inventory_truncated=bool(
            hit_candidate_limit or hit_deadline or source_geometry_truncated
        ),
        path_geometry_incomplete_count=path_geometry_incomplete_count,
        primitive_truncation_count=primitive_truncation_count,
    )


def _separator_orientation(
    *,
    node: PdfLayoutNode,
    options: PdfLayoutGraphOptions,
) -> PdfLayoutSeparatorOrientation | None:
    width = node.bbox.x1 - node.bbox.x0
    height = node.bbox.y1 - node.bbox.y0
    if width <= 0 and height <= 0:
        return None
    if height <= 0 or width >= height * options.separator_orientation_ratio:
        return "horizontal"
    if width <= 0 or height >= width * options.separator_orientation_ratio:
        return "vertical"
    return None


def _drawing_separator_primitives(
    *,
    node: PdfLayoutNode,
    fact: PdfDrawingFact,
    options: PdfLayoutGraphOptions,
) -> tuple[_SeparatorPrimitive, ...]:
    orientation = _separator_orientation(node=node, options=options)
    if fact.kind == "line":
        if orientation is None:
            return ()
        return (
            _SeparatorPrimitive(
                orientation=orientation,
                bbox=node.bbox,
                source_type="direct_line",
                confidence_multiplier=1.0,
            ),
        )

    width = max(0.0, node.bbox.x1 - node.bbox.x0)
    height = max(0.0, node.bbox.y1 - node.bbox.y0)
    thin_orientation = _line_like_orientation(
        width=width,
        height=height,
        minimum_axis_ratio=options.separator_path_minimum_axis_ratio,
        maximum_thickness=options.separator_thin_shape_maximum_thickness_points,
    )
    if fact.kind == "rectangle":
        if thin_orientation is not None and fact.paint_operation in {
            "fill",
            "fill_stroke",
            "unknown",
        }:
            return (
                _SeparatorPrimitive(
                    orientation=thin_orientation,
                    bbox=_bbox_centerline(node.bbox, thin_orientation),
                    source_type="thin_rectangle_centerline",
                    confidence_multiplier=0.9,
                ),
            )
        if fact.paint_operation not in {"stroke", "fill_stroke"}:
            return ()
        if width <= 0 or height <= 0:
            return ()
        return (
            _SeparatorPrimitive(
                "horizontal",
                _horizontal_edge(node.bbox, top=True),
                "rectangle_top_edge",
                0.95,
            ),
            _SeparatorPrimitive(
                "horizontal",
                _horizontal_edge(node.bbox, top=False),
                "rectangle_bottom_edge",
                0.95,
            ),
            _SeparatorPrimitive(
                "vertical",
                _vertical_edge(node.bbox, left=True),
                "rectangle_left_edge",
                0.95,
            ),
            _SeparatorPrimitive(
                "vertical",
                _vertical_edge(node.bbox, left=False),
                "rectangle_right_edge",
                0.95,
            ),
        )

    path_primitives = _path_segment_separator_primitives(fact)
    if path_primitives:
        return path_primitives

    if fact.kind == "curve" and thin_orientation is not None:
        return (
            _SeparatorPrimitive(
                orientation=thin_orientation,
                bbox=_bbox_centerline(node.bbox, thin_orientation),
                source_type="line_like_curve_bbox",
                confidence_multiplier=0.65,
            ),
        )
    return ()


def _canonical_page_boundary_candidates(
    *,
    page_graph_id: str,
    page_width: float,
    page_height: float,
) -> tuple[PdfLayoutSeparatorCandidate, ...]:
    boundary_inventory: tuple[
        tuple[
            PdfLayoutPageBoundarySide,
            PdfLayoutSeparatorOrientation,
            PdfBoundingBox,
            PdfNormalizedBoundingBox,
            float,
        ],
        ...,
    ] = (
        (
            "top",
            "horizontal",
            PdfBoundingBox(x0=0, y0=0, x1=page_width, y1=0),
            PdfNormalizedBoundingBox(x0=0, y0=0, x1=1, y1=0),
            page_width,
        ),
        (
            "bottom",
            "horizontal",
            PdfBoundingBox(
                x0=0,
                y0=page_height,
                x1=page_width,
                y1=page_height,
            ),
            PdfNormalizedBoundingBox(x0=0, y0=1, x1=1, y1=1),
            page_width,
        ),
        (
            "left",
            "vertical",
            PdfBoundingBox(x0=0, y0=0, x1=0, y1=page_height),
            PdfNormalizedBoundingBox(x0=0, y0=0, x1=0, y1=1),
            page_height,
        ),
        (
            "right",
            "vertical",
            PdfBoundingBox(
                x0=page_width,
                y0=0,
                x1=page_width,
                y1=page_height,
            ),
            PdfNormalizedBoundingBox(x0=1, y0=0, x1=1, y1=1),
            page_height,
        ),
    )
    return tuple(
        PdfLayoutSeparatorCandidate(
            separator_candidate_id=layout_page_boundary_separator_identifier(
                page_graph_id=page_graph_id,
                page_boundary_side=side,
            ),
            drawing_node_id=None,
            orientation=orientation,
            evidence_kind="page_boundary",
            source_kind="page_geometry",
            page_boundary_side=side,
            primitive_source_type="page_boundary_edge",
            bbox=bbox,
            normalized_bbox=normalized_bbox,
            line_length=line_length,
            stroke_width=None,
            nearby_node_count=0,
            crossing_or_touching_node_count=0,
            page_coverage_ratio=1,
            confidence=1,
            geometry_quality="precise",
            paint_operation="unknown",
            clipping_application="not_applied",
            quality_metadata_truncated=False,
        )
        for side, orientation, bbox, normalized_bbox, line_length in boundary_inventory
    )


def _coincident_page_boundary_side(
    *,
    primitive: _SeparatorPrimitive,
    page_width: float,
    page_height: float,
    tolerance: float,
) -> PdfLayoutPageBoundarySide | None:
    bbox = primitive.bbox
    if primitive.orientation == "horizontal":
        spans_page = (
            abs(bbox.x0) <= tolerance and abs(bbox.x1 - page_width) <= tolerance
        )
        if not spans_page:
            return None
        if max(abs(bbox.y0), abs(bbox.y1)) <= tolerance:
            return "top"
        if max(abs(bbox.y0 - page_height), abs(bbox.y1 - page_height)) <= tolerance:
            return "bottom"
        return None
    spans_page = abs(bbox.y0) <= tolerance and abs(bbox.y1 - page_height) <= tolerance
    if not spans_page:
        return None
    if max(abs(bbox.x0), abs(bbox.x1)) <= tolerance:
        return "left"
    if max(abs(bbox.x0 - page_width), abs(bbox.x1 - page_width)) <= tolerance:
        return "right"
    return None


def _path_segment_separator_primitives(
    fact: PdfDrawingFact,
) -> tuple[_SeparatorPrimitive, ...]:
    primitives_by_key: dict[
        tuple[str, float, float, float, float],
        _SeparatorPrimitive,
    ] = {}
    for segment in fact.path_segments:
        if segment.kind not in {"line", "close"}:
            continue
        x0, x1 = sorted((segment.start.x, segment.end.x))
        y0, y1 = sorted((segment.start.y, segment.end.y))
        width = x1 - x0
        height = y1 - y0
        if width <= 1e-6 and height <= 1e-6:
            continue
        if height <= 1e-6:
            orientation: PdfLayoutSeparatorOrientation = "horizontal"
        elif width <= 1e-6:
            orientation = "vertical"
        else:
            continue
        bbox = PdfBoundingBox(x0=x0, y0=y0, x1=x1, y1=y1)
        primitive = _SeparatorPrimitive(
            orientation=orientation,
            bbox=bbox,
            source_type="axis_aligned_path_segment",
            confidence_multiplier=(
                0.95 if segment.geometry_quality == "precise" else 0.75
            ),
        )
        key = (
            orientation,
            round(x0, 6),
            round(y0, 6),
            round(x1, 6),
            round(y1, 6),
        )
        primitives_by_key.setdefault(key, primitive)
    return tuple(primitives_by_key[key] for key in sorted(primitives_by_key))


def _page_border_confidence_multiplier(
    *,
    primitive: _SeparatorPrimitive,
    page_width: float,
    page_height: float,
) -> float:
    border_tolerance = 2.0
    if primitive.orientation == "horizontal":
        at_border = (
            primitive.bbox.y0 <= border_tolerance
            or primitive.bbox.y1 >= page_height - border_tolerance
        )
        near_full_page = (primitive.bbox.x1 - primitive.bbox.x0) >= page_width * 0.9
    else:
        at_border = (
            primitive.bbox.x0 <= border_tolerance
            or primitive.bbox.x1 >= page_width - border_tolerance
        )
        near_full_page = (primitive.bbox.y1 - primitive.bbox.y0) >= page_height * 0.9
    return 0.45 if at_border and near_full_page else 1.0


def _line_like_orientation(
    *,
    width: float,
    height: float,
    minimum_axis_ratio: float,
    maximum_thickness: float,
) -> PdfLayoutSeparatorOrientation | None:
    if width <= 0 and height <= 0:
        return None
    if height <= maximum_thickness and width >= max(height, 1e-6) * minimum_axis_ratio:
        return "horizontal"
    if width <= maximum_thickness and height >= max(width, 1e-6) * minimum_axis_ratio:
        return "vertical"
    return None


def _bbox_centerline(
    bbox: PdfBoundingBox,
    orientation: PdfLayoutSeparatorOrientation,
) -> PdfBoundingBox:
    if orientation == "horizontal":
        center = (bbox.y0 + bbox.y1) / 2
        return PdfBoundingBox(x0=bbox.x0, y0=center, x1=bbox.x1, y1=center)
    center = (bbox.x0 + bbox.x1) / 2
    return PdfBoundingBox(x0=center, y0=bbox.y0, x1=center, y1=bbox.y1)


def _horizontal_edge(bbox: PdfBoundingBox, *, top: bool) -> PdfBoundingBox:
    y = bbox.y0 if top else bbox.y1
    return PdfBoundingBox(x0=bbox.x0, y0=y, x1=bbox.x1, y1=y)


def _vertical_edge(bbox: PdfBoundingBox, *, left: bool) -> PdfBoundingBox:
    x = bbox.x0 if left else bbox.x1
    return PdfBoundingBox(x0=x, y0=bbox.y0, x1=x, y1=bbox.y1)


def _bbox_axis_length(
    *,
    bbox: PdfBoundingBox,
    orientation: PdfLayoutSeparatorOrientation,
) -> float:
    if orientation == "horizontal":
        return max(0.0, bbox.x1 - bbox.x0)
    return max(0.0, bbox.y1 - bbox.y0)


def _normalized_bbox(
    *,
    bbox: PdfBoundingBox,
    page_width: float,
    page_height: float,
) -> PdfNormalizedBoundingBox:
    return PdfNormalizedBoundingBox(
        x0=min(1.0, max(0.0, bbox.x0 / page_width)),
        y0=min(1.0, max(0.0, bbox.y0 / page_height)),
        x1=min(1.0, max(0.0, bbox.x1 / page_width)),
        y1=min(1.0, max(0.0, bbox.y1 / page_height)),
    )


def _effective_stroke_width(fact: PdfDrawingFact) -> float | None:
    effective = tuple(
        value
        for value in (
            fact.effective_stroke_width_x,
            fact.effective_stroke_width_y,
        )
        if value is not None
    )
    if effective:
        return round(sum(effective) / len(effective), 6)
    return round(fact.stroke_width, 6) if fact.stroke_width is not None else None


def _separator_confidence(
    *,
    coverage_ratio: float,
    geometry_quality: str,
    nearby_node_count: int,
    touching_node_count: int,
    paint_operation: str,
) -> float:
    length_score = min(1.0, coverage_ratio / 0.25)
    geometry_score = {
        "precise": 1.0,
        "approximate": 0.7,
        "unknown": 0.4,
    }[geometry_quality]
    nearby_score = min(1.0, nearby_node_count / 4)
    paint_score = {
        "stroke": 1.0,
        "fill_stroke": 0.9,
        "unknown": 0.6,
        "fill": 0.4,
        "clip": 0.2,
    }[paint_operation]
    touching_penalty = min(0.25, touching_node_count * 0.05)
    return min(
        1.0,
        max(
            0.0,
            0.35 * length_score
            + 0.30 * geometry_score
            + 0.20 * nearby_score
            + 0.15 * paint_score
            - touching_penalty,
        ),
    )


def _node_touches_bbox(
    *,
    node: PdfLayoutNode,
    separator_bbox: PdfBoundingBox,
    tolerance: float,
) -> bool:
    return not (
        node.bbox.x1 < separator_bbox.x0 - tolerance
        or separator_bbox.x1 + tolerance < node.bbox.x0
        or node.bbox.y1 < separator_bbox.y0 - tolerance
        or separator_bbox.y1 + tolerance < node.bbox.y0
    )


def _bbox_center(bbox: PdfBoundingBox) -> tuple[float, float]:
    return ((bbox.x0 + bbox.x1) / 2, (bbox.y0 + bbox.y1) / 2)

# ruff: noqa: C901, D202, I001, PLR0912, PLR0913, PLR0915, SIM113

from collections.abc import Callable, Sequence
from dataclasses import dataclass
import math
from typing import Literal

from document_sdk.pdf._structural_engine.layout.contracts import (
    PDF_LAYOUT_RELATION_METHOD_VERSION,
    PdfLayoutAdjacencyBasis,
    PdfLayoutGeometryEvidence,
    PdfLayoutNode,
    PdfLayoutRelationType,
    PdfLayoutSeparatorCandidate,
    finite_ratio,
)
from document_sdk.pdf._structural_engine.facts.status import PdfWarningCode
from document_sdk.pdf._structural_engine.layout.limits import PdfLayoutGraphOptions


PDF_LAYOUT_ADJACENCY_CONTRACT_VERSION = "pdf_layout_adjacency.v5"


@dataclass(frozen=True, slots=True)
class PdfLayoutRelationCandidate:
    source_node_id: str
    target_node_id: str
    relation_type: PdfLayoutRelationType
    adjacency_basis: PdfLayoutAdjacencyBasis | None
    confidence: float
    base_confidence: float
    separator_confidence_reduction: float
    separator_candidate_ids: tuple[str, ...]
    relevant_separator_count: int
    retained_separator_evidence_count: int
    separator_source_inventory_truncated: bool
    separator_context_truncated: bool
    separator_id_list_truncated: bool
    relevant_separator_count_is_lower_bound: bool
    separator_evidence_truncated: bool
    warning_codes: tuple[PdfWarningCode, ...]
    geometry_evidence: PdfLayoutGeometryEvidence
    method_version: str = PDF_LAYOUT_RELATION_METHOD_VERSION


@dataclass(frozen=True, slots=True)
class PdfLayoutRelationCorridor:
    axis: Literal["horizontal", "vertical"]
    x0: float
    y0: float
    x1: float
    y1: float

    @property
    def center(self) -> tuple[float, float]:
        return ((self.x0 + self.x1) / 2, (self.y0 + self.y1) / 2)


@dataclass(slots=True)
class PdfLayoutRelationOperationCounter:
    intervening_candidate_scans: int = 0
    separator_evidence_candidate_scans: int = 0
    separator_context_truncations: int = 0
    separator_id_list_truncations: int = 0
    maximum_retained_separator_evidence: int = 0


_ALL_GENERIC_RELATIONS: frozenset[PdfLayoutRelationType] = frozenset(
    {
        "left_of",
        "above",
        "contains",
        "overlaps",
        "adjacent_horizontal",
        "adjacent_vertical",
        "same_row_candidate",
        "same_column_candidate",
    }
)
_DRAWING_GEOMETRY_RELATIONS: frozenset[PdfLayoutRelationType] = frozenset(
    {"contains", "overlaps"}
)


def eligible_layout_relations(
    first: PdfLayoutNode,
    second: PdfLayoutNode,
) -> frozenset[PdfLayoutRelationType]:
    """Return generic relations useful for the canonical node-type pair."""

    if _is_line_drawing(first) or _is_line_drawing(second):
        return frozenset()
    if first.node_type == "drawing" or second.node_type == "drawing":
        return _DRAWING_GEOMETRY_RELATIONS
    return _ALL_GENERIC_RELATIONS


def infer_layout_relations(
    *,
    first: PdfLayoutNode,
    second: PdfLayoutNode,
    page_width: float,
    page_height: float,
    options: PdfLayoutGraphOptions,
    nearby_nodes: Sequence[PdfLayoutNode] = (),
    relation_context_complete: bool = True,
    operation_counter: PdfLayoutRelationOperationCounter | None = None,
    deadline_reached: Callable[[], bool] | None = None,
    separator_candidates: Sequence[PdfLayoutSeparatorCandidate] = (),
    separator_source_inventory_complete: bool = True,
    separator_context_complete: bool = True,
    max_separator_scans: int = 64,
    max_separator_evidence: int = 8,
) -> tuple[PdfLayoutRelationCandidate, ...]:
    if deadline_reached is not None and deadline_reached():
        return ()
    eligible_relations = eligible_layout_relations(first, second)
    if not eligible_relations:
        return ()
    evidence = _geometry_evidence(
        first=first,
        second=second,
        page_width=page_width,
        page_height=page_height,
        options=options,
    )
    candidates: list[PdfLayoutRelationCandidate] = []
    geometry_quality = min(
        _quality_weight(first.geometry_quality),
        _quality_weight(second.geometry_quality),
    )

    containing = _containing_direction(
        first=first,
        second=second,
        tolerance=options.containment_tolerance_points,
        minimum_ratio=options.minimum_containment_ratio,
    )
    if containing is not None and "contains" in eligible_relations:
        source, target, containment_ratio = containing
        candidates.append(
            _candidate(
                source=source,
                target=target,
                relation_type="contains",
                evidence=evidence.model_copy(
                    update={"containment_ratio": containment_ratio}
                ),
                confidence=(0.65 * containment_ratio + 0.35 * geometry_quality),
            )
        )

    if deadline_reached is not None and deadline_reached():
        return tuple(candidates)
    if (
        "overlaps" in eligible_relations
        and evidence.overlap_ratio >= options.minimum_overlap_ratio
    ):
        source, target = _stable_pair(first, second)
        candidates.append(
            _candidate(
                source=source,
                target=target,
                relation_type="overlaps",
                evidence=evidence,
                confidence=(0.7 * evidence.overlap_ratio + 0.3 * geometry_quality),
            )
        )

    if deadline_reached is not None and deadline_reached():
        return tuple(candidates)
    horizontal = (
        _horizontal_direction(first, second)
        if eligible_relations & {"left_of", "same_row_candidate", "adjacent_horizontal"}
        else None
    )
    if horizontal is not None:
        source, target, horizontal_gap = horizontal
        horizontal_evidence = evidence.model_copy(
            update={
                "horizontal_gap": horizontal_gap,
                "alignment_delta": abs(_center(first)[1] - _center(second)[1]),
            }
        )
        proximity = 1 - min(1.0, horizontal_gap / max(page_width, 1.0))
        cross_axis = max(
            evidence.vertical_overlap_ratio,
            1
            - min(
                1.0,
                horizontal_evidence.alignment_delta / max(page_height, 1.0),
            ),
        )
        if "left_of" in eligible_relations:
            candidates.append(
                _candidate(
                    source=source,
                    target=target,
                    relation_type="left_of",
                    evidence=horizontal_evidence,
                    confidence=(
                        0.35 * proximity + 0.35 * cross_axis + 0.30 * geometry_quality
                    ),
                )
            )
    else:
        horizontal_evidence = evidence

    vertical = (
        _vertical_direction(first, second)
        if eligible_relations & {"above", "same_column_candidate", "adjacent_vertical"}
        else None
    )
    if vertical is not None:
        source, target, vertical_gap = vertical
        vertical_evidence = evidence.model_copy(
            update={
                "vertical_gap": vertical_gap,
                "alignment_delta": abs(_center(first)[0] - _center(second)[0]),
            }
        )
        proximity = 1 - min(1.0, vertical_gap / max(page_height, 1.0))
        cross_axis = max(
            evidence.horizontal_overlap_ratio,
            1
            - min(
                1.0,
                vertical_evidence.alignment_delta / max(page_width, 1.0),
            ),
        )
        if "above" in eligible_relations:
            candidates.append(
                _candidate(
                    source=source,
                    target=target,
                    relation_type="above",
                    evidence=vertical_evidence,
                    confidence=(
                        0.35 * proximity + 0.35 * cross_axis + 0.30 * geometry_quality
                    ),
                )
            )
    else:
        vertical_evidence = evidence

    if (
        evidence.rotation_compatible
        and horizontal is not None
        and eligible_relations & {"same_row_candidate", "adjacent_horizontal"}
    ):
        source, target, horizontal_gap = horizontal
        row_alignment = _same_row_alignment(first, second, options)
        if row_alignment is not None and "same_row_candidate" in eligible_relations:
            candidates.append(
                _candidate(
                    source=source,
                    target=target,
                    relation_type="same_row_candidate",
                    evidence=horizontal_evidence,
                    confidence=(
                        0.50 * row_alignment
                        + 0.25
                        * _gap_proximity(
                            horizontal_gap,
                            max(_bbox_height(first), _bbox_height(second), 1.0)
                            * options.adjacency_gap_multiplier,
                        )
                        + 0.25 * geometry_quality
                    ),
                )
            )
            adjacency_limit = (
                max(_bbox_height(first), _bbox_height(second), 1.0)
                * options.adjacency_gap_multiplier
            )
            adjacency_basis = _adjacency_basis(
                first=first,
                second=second,
                gap=horizontal_gap,
                near_gap_limit=adjacency_limit,
                page_width=page_width,
                page_height=page_height,
                nearby_nodes=nearby_nodes,
                axis="horizontal",
                relation_context_complete=relation_context_complete,
                options=options,
                operation_counter=operation_counter,
                deadline_reached=deadline_reached,
            )
            if (
                "adjacent_horizontal" in eligible_relations
                and adjacency_basis is not None
            ):
                candidates.append(
                    _candidate(
                        source=source,
                        target=target,
                        relation_type="adjacent_horizontal",
                        adjacency_basis=adjacency_basis,
                        evidence=horizontal_evidence,
                        confidence=(
                            0.45 * row_alignment
                            + 0.35
                            * _adjacency_basis_confidence(
                                adjacency_basis=adjacency_basis,
                                gap=horizontal_gap,
                                near_gap_limit=adjacency_limit,
                            )
                            + 0.20 * geometry_quality
                        ),
                    )
                )

    if (
        evidence.rotation_compatible
        and vertical is not None
        and eligible_relations & {"same_column_candidate", "adjacent_vertical"}
    ):
        source, target, vertical_gap = vertical
        column_alignment = _same_column_alignment(first, second, options)
        if (
            column_alignment is not None
            and "same_column_candidate" in eligible_relations
        ):
            candidates.append(
                _candidate(
                    source=source,
                    target=target,
                    relation_type="same_column_candidate",
                    evidence=vertical_evidence,
                    confidence=(
                        0.50 * column_alignment
                        + 0.25
                        * _gap_proximity(
                            vertical_gap,
                            max(_bbox_width(first), _bbox_width(second), 1.0)
                            * options.adjacency_gap_multiplier,
                        )
                        + 0.25 * geometry_quality
                    ),
                )
            )
            adjacency_limit = (
                max(_bbox_width(first), _bbox_width(second), 1.0)
                * options.adjacency_gap_multiplier
            )
            adjacency_basis = _adjacency_basis(
                first=first,
                second=second,
                gap=vertical_gap,
                near_gap_limit=adjacency_limit,
                page_width=page_width,
                page_height=page_height,
                nearby_nodes=nearby_nodes,
                axis="vertical",
                relation_context_complete=relation_context_complete,
                options=options,
                operation_counter=operation_counter,
                deadline_reached=deadline_reached,
            )
            if (
                "adjacent_vertical" in eligible_relations
                and adjacency_basis is not None
            ):
                candidates.append(
                    _candidate(
                        source=source,
                        target=target,
                        relation_type="adjacent_vertical",
                        adjacency_basis=adjacency_basis,
                        evidence=vertical_evidence,
                        confidence=(
                            0.45 * column_alignment
                            + 0.35
                            * _adjacency_basis_confidence(
                                adjacency_basis=adjacency_basis,
                                gap=vertical_gap,
                                near_gap_limit=adjacency_limit,
                            )
                            + 0.20 * geometry_quality
                        ),
                    )
                )

    # The common Product path has no pair-local drawing separator.  Avoid a
    # generator tuple plus a second sorted-list allocation for every relation
    # pair; page-boundary evidence is deliberately non-adjusting.  Incomplete
    # source/context metadata still takes the full adjustment path so unknown
    # and lower-bound semantics remain unchanged.
    if (
        not separator_candidates
        and separator_source_inventory_complete
        and separator_context_complete
    ):
        adjusted_candidates = candidates
    else:
        node_by_id = {first.node_id: first, second.node_id: second}
        adjusted_candidates = [
            _apply_separator_adjustment(
                candidate=candidate,
                source=node_by_id[candidate.source_node_id],
                target=node_by_id[candidate.target_node_id],
                separator_candidates=separator_candidates,
                options=options,
                separator_source_inventory_complete=(
                    separator_source_inventory_complete
                ),
                separator_context_complete=separator_context_complete,
                max_separator_scans=max_separator_scans,
                max_separator_evidence=max_separator_evidence,
                operation_counter=operation_counter,
                deadline_reached=deadline_reached,
            )
            for candidate in candidates
        ]
    adjusted_candidates.sort(
        key=lambda item: (
            item.source_node_id,
            item.target_node_id,
            item.relation_type,
        ),
    )
    return tuple(adjusted_candidates)


def layout_relation_corridors(
    *,
    first: PdfLayoutNode,
    second: PdfLayoutNode,
    options: PdfLayoutGraphOptions,
) -> tuple[PdfLayoutRelationCorridor, ...]:
    if not _rotation_compatible(
        first.rotation,
        second.rotation,
        options.rotation_tolerance_degrees,
    ):
        return ()
    corridors: list[PdfLayoutRelationCorridor] = []
    horizontal = _horizontal_direction(first, second)
    if (
        horizontal is not None
        and _same_row_alignment(first, second, options) is not None
    ):
        source, target, _gap = horizontal
        tolerance = max(_bbox_height(first), _bbox_height(second), 1.0) * (
            options.alignment_tolerance_ratio
        )
        corridors.append(
            PdfLayoutRelationCorridor(
                axis="horizontal",
                x0=source.bbox.x1,
                y0=min(first.bbox.y0, second.bbox.y0) - tolerance,
                x1=target.bbox.x0,
                y1=max(first.bbox.y1, second.bbox.y1) + tolerance,
            )
        )
    vertical = _vertical_direction(first, second)
    if (
        vertical is not None
        and _same_column_alignment(first, second, options) is not None
    ):
        source, target, _gap = vertical
        tolerance = max(_bbox_width(first), _bbox_width(second), 1.0) * (
            options.alignment_tolerance_ratio
        )
        corridors.append(
            PdfLayoutRelationCorridor(
                axis="vertical",
                x0=min(first.bbox.x0, second.bbox.x0) - tolerance,
                y0=source.bbox.y1,
                x1=max(first.bbox.x1, second.bbox.x1) + tolerance,
                y1=target.bbox.y0,
            )
        )
    return tuple(corridors)


def is_layout_relation_axis_aligned(
    *,
    first: PdfLayoutNode,
    second: PdfLayoutNode,
    axis: Literal["horizontal", "vertical"],
    options: PdfLayoutGraphOptions,
) -> bool:
    """Return geometry-only alignment used by stored and on-demand discovery."""

    if not _rotation_compatible(
        first.rotation,
        second.rotation,
        options.rotation_tolerance_degrees,
    ):
        return False
    if axis == "horizontal":
        return _same_row_alignment(first, second, options) is not None
    return _same_column_alignment(first, second, options) is not None


def wide_adjacency_pair_is_eligible(
    *,
    first: PdfLayoutNode,
    second: PdfLayoutNode,
    axis: Literal["horizontal", "vertical"],
    page_width: float,
    page_height: float,
    options: PdfLayoutGraphOptions,
) -> bool:
    """Apply the shared bounded eligibility guard for wide adjacency evidence.

    Mutual-nearest is useful beyond the local search radius, but it must not
    connect nearly page-wide endpoints.  A stricter geometry-only horizontal
    guard prevents sparse header/footer bands from coupling a label to a page
    number without inspecting either node's text.
    """

    if not is_layout_relation_axis_aligned(
        first=first,
        second=second,
        axis=axis,
        options=options,
    ):
        return False
    if axis == "horizontal":
        direction = _horizontal_direction(first, second)
        page_extent = max(page_width, 1.0)
        scale = max(_bbox_height(first), _bbox_height(second), 1.0)
    else:
        direction = _vertical_direction(first, second)
        page_extent = max(page_height, 1.0)
        scale = max(_bbox_width(first), _bbox_width(second), 1.0)
    if direction is None:
        return False
    _source, _target, gap = direction
    if gap <= scale * options.adjacency_gap_multiplier:
        return False
    gap_page_ratio = gap / page_extent
    if gap_page_ratio > options.maximum_mutual_nearest_gap_page_ratio:
        return False
    if axis != "horizontal":
        return True

    boundary_band_height = max(page_height, 1.0) * (
        options.mutual_nearest_boundary_band_ratio
    )
    first_center_y = _center(first)[1]
    second_center_y = _center(second)[1]
    both_in_top_band = (
        first_center_y <= boundary_band_height
        and second_center_y <= boundary_band_height
    )
    bottom_band_start = max(page_height, 1.0) - boundary_band_height
    both_in_bottom_band = (
        first_center_y >= bottom_band_start and second_center_y >= bottom_band_start
    )
    return not (
        (both_in_top_band or both_in_bottom_band)
        and gap_page_ratio > options.maximum_boundary_band_horizontal_gap_page_ratio
    )


def _geometry_evidence(
    *,
    first: PdfLayoutNode,
    second: PdfLayoutNode,
    page_width: float,
    page_height: float,
    options: PdfLayoutGraphOptions,
) -> PdfLayoutGeometryEvidence:
    horizontal_gap = max(
        0.0,
        second.bbox.x0 - first.bbox.x1,
        first.bbox.x0 - second.bbox.x1,
    )
    vertical_gap = max(
        0.0,
        second.bbox.y0 - first.bbox.y1,
        first.bbox.y0 - second.bbox.y1,
    )
    horizontal_overlap = max(
        0.0,
        min(first.bbox.x1, second.bbox.x1) - max(first.bbox.x0, second.bbox.x0),
    )
    vertical_overlap = max(
        0.0,
        min(first.bbox.y1, second.bbox.y1) - max(first.bbox.y0, second.bbox.y0),
    )
    first_area = _bbox_area(first)
    second_area = _bbox_area(second)
    intersection_area = horizontal_overlap * vertical_overlap
    minimum_area = min(first_area, second_area)
    first_center = _center(first)
    second_center = _center(second)
    diagonal = max(math.hypot(page_width, page_height), 1.0)
    return PdfLayoutGeometryEvidence(
        horizontal_gap=round(horizontal_gap, 6),
        vertical_gap=round(vertical_gap, 6),
        horizontal_overlap_ratio=round(
            finite_ratio(
                horizontal_overlap,
                min(_bbox_width(first), _bbox_width(second)),
            ),
            6,
        ),
        vertical_overlap_ratio=round(
            finite_ratio(
                vertical_overlap,
                min(_bbox_height(first), _bbox_height(second)),
            ),
            6,
        ),
        overlap_ratio=round(finite_ratio(intersection_area, minimum_area), 6),
        alignment_delta=round(
            min(
                abs(first_center[0] - second_center[0]),
                abs(first_center[1] - second_center[1]),
            ),
            6,
        ),
        containment_ratio=0.0,
        normalized_distance=round(
            math.hypot(horizontal_gap, vertical_gap) / diagonal,
            6,
        ),
        rotation_compatible=_rotation_compatible(
            first.rotation,
            second.rotation,
            options.rotation_tolerance_degrees,
        ),
    )


def _same_row_alignment(
    first: PdfLayoutNode,
    second: PdfLayoutNode,
    options: PdfLayoutGraphOptions,
) -> float | None:
    vertical_overlap = max(
        0.0,
        min(first.bbox.y1, second.bbox.y1) - max(first.bbox.y0, second.bbox.y0),
    )
    overlap_ratio = finite_ratio(
        vertical_overlap,
        min(_bbox_height(first), _bbox_height(second)),
    )
    center_delta = abs(_center(first)[1] - _center(second)[1])
    tolerance = max(_bbox_height(first), _bbox_height(second), 1.0) * (
        options.alignment_tolerance_ratio
    )
    center_alignment = 1 - min(1.0, center_delta / max(tolerance, 1e-9))
    if overlap_ratio < options.minimum_axis_overlap_ratio and center_delta > tolerance:
        return None
    return max(overlap_ratio, center_alignment)


def _same_column_alignment(
    first: PdfLayoutNode,
    second: PdfLayoutNode,
    options: PdfLayoutGraphOptions,
) -> float | None:
    horizontal_overlap = max(
        0.0,
        min(first.bbox.x1, second.bbox.x1) - max(first.bbox.x0, second.bbox.x0),
    )
    overlap_ratio = finite_ratio(
        horizontal_overlap,
        min(_bbox_width(first), _bbox_width(second)),
    )
    center_delta = abs(_center(first)[0] - _center(second)[0])
    tolerance = max(_bbox_width(first), _bbox_width(second), 1.0) * (
        options.alignment_tolerance_ratio
    )
    center_alignment = 1 - min(1.0, center_delta / max(tolerance, 1e-9))
    if overlap_ratio < options.minimum_axis_overlap_ratio and center_delta > tolerance:
        return None
    return max(overlap_ratio, center_alignment)


def _containing_direction(
    *,
    first: PdfLayoutNode,
    second: PdfLayoutNode,
    tolerance: float,
    minimum_ratio: float,
) -> tuple[PdfLayoutNode, PdfLayoutNode, float] | None:
    first_ratio = _containment_ratio(first, second, tolerance)
    second_ratio = _containment_ratio(second, first, tolerance)
    if first_ratio >= minimum_ratio and _bbox_area(first) > _bbox_area(second):
        return first, second, first_ratio
    if second_ratio >= minimum_ratio and _bbox_area(second) > _bbox_area(first):
        return second, first, second_ratio
    return None


def _containment_ratio(
    container: PdfLayoutNode,
    contained: PdfLayoutNode,
    tolerance: float,
) -> float:
    intersection_width = max(
        0.0,
        min(container.bbox.x1 + tolerance, contained.bbox.x1)
        - max(container.bbox.x0 - tolerance, contained.bbox.x0),
    )
    intersection_height = max(
        0.0,
        min(container.bbox.y1 + tolerance, contained.bbox.y1)
        - max(container.bbox.y0 - tolerance, contained.bbox.y0),
    )
    return finite_ratio(
        intersection_width * intersection_height,
        _bbox_area(contained),
    )


def _horizontal_direction(
    first: PdfLayoutNode,
    second: PdfLayoutNode,
) -> tuple[PdfLayoutNode, PdfLayoutNode, float] | None:
    if first.bbox.x1 <= second.bbox.x0:
        return first, second, second.bbox.x0 - first.bbox.x1
    if second.bbox.x1 <= first.bbox.x0:
        return second, first, first.bbox.x0 - second.bbox.x1
    return None


def _vertical_direction(
    first: PdfLayoutNode,
    second: PdfLayoutNode,
) -> tuple[PdfLayoutNode, PdfLayoutNode, float] | None:
    if first.bbox.y1 <= second.bbox.y0:
        return first, second, second.bbox.y0 - first.bbox.y1
    if second.bbox.y1 <= first.bbox.y0:
        return second, first, first.bbox.y0 - second.bbox.y1
    return None


def _stable_pair(
    first: PdfLayoutNode,
    second: PdfLayoutNode,
) -> tuple[PdfLayoutNode, PdfLayoutNode]:
    return (first, second) if first.node_id < second.node_id else (second, first)


def _has_intervening_node(
    *,
    first: PdfLayoutNode,
    second: PdfLayoutNode,
    nearby_nodes: Sequence[PdfLayoutNode],
    axis: str,
    options: PdfLayoutGraphOptions,
    operation_counter: PdfLayoutRelationOperationCounter | None,
    deadline_reached: Callable[[], bool] | None,
) -> bool:
    first_center = _center(first)
    second_center = _center(second)
    if axis == "horizontal":
        lower, upper = sorted((first_center[0], second_center[0]))
        for node in nearby_nodes:
            if deadline_reached is not None and deadline_reached():
                return True
            if operation_counter is not None:
                operation_counter.intervening_candidate_scans += 1
            if node.node_type == "drawing":
                continue
            if (
                lower < _center(node)[0] < upper
                and (
                    node.node_type == "image_region"
                    or _rotation_compatible(
                        first.rotation,
                        node.rotation,
                        options.rotation_tolerance_degrees,
                    )
                )
                and _same_row_alignment(first, node, options) is not None
                and _same_row_alignment(second, node, options) is not None
            ):
                return True
        return False
    lower, upper = sorted((first_center[1], second_center[1]))
    for node in nearby_nodes:
        if deadline_reached is not None and deadline_reached():
            return True
        if operation_counter is not None:
            operation_counter.intervening_candidate_scans += 1
        if node.node_type == "drawing":
            continue
        if (
            lower < _center(node)[1] < upper
            and (
                node.node_type == "image_region"
                or _rotation_compatible(
                    first.rotation,
                    node.rotation,
                    options.rotation_tolerance_degrees,
                )
            )
            and _same_column_alignment(first, node, options) is not None
            and _same_column_alignment(second, node, options) is not None
        ):
            return True
    return False


def _adjacency_basis(
    *,
    first: PdfLayoutNode,
    second: PdfLayoutNode,
    gap: float,
    near_gap_limit: float,
    page_width: float,
    page_height: float,
    nearby_nodes: Sequence[PdfLayoutNode],
    axis: Literal["horizontal", "vertical"],
    relation_context_complete: bool,
    options: PdfLayoutGraphOptions,
    operation_counter: PdfLayoutRelationOperationCounter | None,
    deadline_reached: Callable[[], bool] | None,
) -> PdfLayoutAdjacencyBasis | None:
    """Return positive adjacency evidence without treating missing context as fact."""

    if not relation_context_complete or (
        deadline_reached is not None and deadline_reached()
    ):
        return None
    if gap <= near_gap_limit:
        return (
            None
            if _has_intervening_node(
                first=first,
                second=second,
                nearby_nodes=nearby_nodes,
                axis=axis,
                options=options,
                operation_counter=operation_counter,
                deadline_reached=deadline_reached,
            )
            else "near_gap"
        )
    if not wide_adjacency_pair_is_eligible(
        first=first,
        second=second,
        axis=axis,
        page_width=page_width,
        page_height=page_height,
        options=options,
    ):
        return None
    if _are_mutual_nearest_aligned_neighbors(
        first=first,
        second=second,
        nearby_nodes=nearby_nodes,
        axis=axis,
        options=options,
        operation_counter=operation_counter,
        deadline_reached=deadline_reached,
    ):
        return (
            "mutual_nearest_row_neighbor"
            if axis == "horizontal"
            else "mutual_nearest_column_neighbor"
        )
    return None


def _are_mutual_nearest_aligned_neighbors(
    *,
    first: PdfLayoutNode,
    second: PdfLayoutNode,
    nearby_nodes: Sequence[PdfLayoutNode],
    axis: Literal["horizontal", "vertical"],
    options: PdfLayoutGraphOptions,
    operation_counter: PdfLayoutRelationOperationCounter | None,
    deadline_reached: Callable[[], bool] | None,
) -> bool:
    """Check directional mutual-nearest evidence inside a complete corridor."""

    first_center = _center(first)
    second_center = _center(second)
    coordinate_index = 0 if axis == "horizontal" else 1
    lower, upper = sorted(
        (first_center[coordinate_index], second_center[coordinate_index])
    )
    endpoint_ids = {first.node_id, second.node_id}
    for node in nearby_nodes:
        if deadline_reached is not None and deadline_reached():
            return False
        if operation_counter is not None:
            operation_counter.intervening_candidate_scans += 1
        if node.node_id in endpoint_ids or node.node_type == "drawing":
            continue
        node_coordinate = _center(node)[coordinate_index]
        if not lower < node_coordinate < upper:
            continue
        if axis == "horizontal":
            aligned_with_first = (
                node.node_type == "image_region"
                or _rotation_compatible(
                    first.rotation,
                    node.rotation,
                    options.rotation_tolerance_degrees,
                )
            ) and _same_row_alignment(first, node, options) is not None
            aligned_with_second = (
                node.node_type == "image_region"
                or _rotation_compatible(
                    second.rotation,
                    node.rotation,
                    options.rotation_tolerance_degrees,
                )
            ) and _same_row_alignment(second, node, options) is not None
        else:
            aligned_with_first = (
                node.node_type == "image_region"
                or _rotation_compatible(
                    first.rotation,
                    node.rotation,
                    options.rotation_tolerance_degrees,
                )
            ) and _same_column_alignment(first, node, options) is not None
            aligned_with_second = (
                node.node_type == "image_region"
                or _rotation_compatible(
                    second.rotation,
                    node.rotation,
                    options.rotation_tolerance_degrees,
                )
            ) and _same_column_alignment(second, node, options) is not None
        if aligned_with_first or aligned_with_second:
            return False
    return True


def _adjacency_basis_confidence(
    *,
    adjacency_basis: PdfLayoutAdjacencyBasis,
    gap: float,
    near_gap_limit: float,
) -> float:
    if adjacency_basis == "near_gap":
        # Keep every locally observed near-gap adjacency above the weaker
        # mutual-nearest evidence band, including values immediately below
        # the near-gap boundary.
        return 0.6 + 0.4 * _gap_proximity(gap, near_gap_limit)
    # Wide mutual-nearest adjacency is useful positive evidence, but the
    # absence of an intervening aligned node is weaker than local proximity.
    return 0.3


def _candidate(
    *,
    source: PdfLayoutNode,
    target: PdfLayoutNode,
    relation_type: PdfLayoutRelationType,
    adjacency_basis: PdfLayoutAdjacencyBasis | None = None,
    evidence: PdfLayoutGeometryEvidence,
    confidence: float,
) -> PdfLayoutRelationCandidate:
    bounded_confidence = round(min(1.0, max(0.0, confidence)), 6)
    return PdfLayoutRelationCandidate(
        source_node_id=source.node_id,
        target_node_id=target.node_id,
        relation_type=relation_type,
        adjacency_basis=adjacency_basis,
        confidence=bounded_confidence,
        base_confidence=bounded_confidence,
        separator_confidence_reduction=0.0,
        separator_candidate_ids=(),
        relevant_separator_count=0,
        retained_separator_evidence_count=0,
        separator_source_inventory_truncated=False,
        separator_context_truncated=False,
        separator_id_list_truncated=False,
        relevant_separator_count_is_lower_bound=False,
        separator_evidence_truncated=False,
        warning_codes=(),
        geometry_evidence=evidence,
    )


def _apply_separator_adjustment(
    *,
    candidate: PdfLayoutRelationCandidate,
    source: PdfLayoutNode,
    target: PdfLayoutNode,
    separator_candidates: Sequence[PdfLayoutSeparatorCandidate],
    options: PdfLayoutGraphOptions,
    separator_source_inventory_complete: bool,
    separator_context_complete: bool,
    max_separator_scans: int,
    max_separator_evidence: int,
    operation_counter: PdfLayoutRelationOperationCounter | None,
    deadline_reached: Callable[[], bool] | None,
) -> PdfLayoutRelationCandidate:
    orientation = {
        "adjacent_horizontal": "vertical",
        "same_row_candidate": "vertical",
        "adjacent_vertical": "horizontal",
        "same_column_candidate": "horizontal",
    }.get(candidate.relation_type)
    if orientation is None:
        return candidate
    relevant: list[PdfLayoutSeparatorCandidate] = []
    source_inventory_truncated = not separator_source_inventory_complete
    scan_truncated = not separator_context_complete
    local_scan_count = 0
    for separator in separator_candidates:
        if deadline_reached is not None and deadline_reached():
            scan_truncated = True
            break
        if local_scan_count >= max_separator_scans:
            scan_truncated = True
            break
        local_scan_count += 1
        if operation_counter is not None:
            operation_counter.separator_evidence_candidate_scans += 1
        if (
            separator.evidence_kind == "drawing_separator"
            and separator.orientation == orientation
            and separator.confidence >= options.separator_minimum_confidence
            and _separator_lies_between(
                separator=separator,
                first=source,
                second=target,
                orientation=orientation,
                tolerance=options.containment_tolerance_points,
            )
        ):
            relevant.append(separator)
    if deadline_reached is not None and deadline_reached():
        scan_truncated = True
    relevant.sort(
        key=lambda separator: _separator_priority(
            separator=separator,
            first=source,
            second=target,
        )
    )
    if deadline_reached is not None and deadline_reached():
        scan_truncated = True
    retained = tuple(relevant[:max_separator_evidence])
    id_list_truncated = len(relevant) > len(retained)
    evidence_truncated = (
        source_inventory_truncated or scan_truncated or id_list_truncated
    )
    if operation_counter is not None:
        operation_counter.maximum_retained_separator_evidence = max(
            operation_counter.maximum_retained_separator_evidence,
            len(retained),
        )
        if scan_truncated:
            operation_counter.separator_context_truncations += 1
        if id_list_truncated:
            operation_counter.separator_id_list_truncations += 1
    if not retained and not evidence_truncated:
        return candidate
    relation_weight = (
        1.0
        if candidate.relation_type in {"adjacent_horizontal", "adjacent_vertical"}
        else 0.5
    )
    reduction = round(
        min(
            options.separator_max_confidence_reduction,
            options.separator_max_confidence_reduction
            * max((separator.confidence for separator in retained), default=0.0)
            * relation_weight,
        ),
        6,
    )
    return PdfLayoutRelationCandidate(
        source_node_id=candidate.source_node_id,
        target_node_id=candidate.target_node_id,
        relation_type=candidate.relation_type,
        adjacency_basis=candidate.adjacency_basis,
        confidence=round(candidate.base_confidence * (1 - reduction), 6),
        base_confidence=candidate.base_confidence,
        separator_confidence_reduction=reduction,
        separator_candidate_ids=tuple(
            sorted(separator.separator_candidate_id for separator in retained)
        ),
        relevant_separator_count=len(relevant),
        retained_separator_evidence_count=len(retained),
        separator_source_inventory_truncated=source_inventory_truncated,
        separator_context_truncated=scan_truncated,
        separator_id_list_truncated=id_list_truncated,
        relevant_separator_count_is_lower_bound=(
            source_inventory_truncated or scan_truncated
        ),
        separator_evidence_truncated=evidence_truncated,
        warning_codes=(
            (PdfWarningCode.TOTAL_FACT_LIMIT_REACHED,) if evidence_truncated else ()
        ),
        geometry_evidence=candidate.geometry_evidence,
    )


def _separator_priority(
    *,
    separator: PdfLayoutSeparatorCandidate,
    first: PdfLayoutNode,
    second: PdfLayoutNode,
) -> tuple[object, ...]:
    relation_center = (
        (_center(first)[0] + _center(second)[0]) / 2,
        (_center(first)[1] + _center(second)[1]) / 2,
    )
    separator_center = (
        (separator.bbox.x0 + separator.bbox.x1) / 2,
        (separator.bbox.y0 + separator.bbox.y1) / 2,
    )
    geometry_rank = {"precise": 0, "approximate": 1, "unknown": 2}
    return (
        -separator.confidence,
        math.hypot(
            separator_center[0] - relation_center[0],
            separator_center[1] - relation_center[1],
        ),
        geometry_rank[separator.geometry_quality],
        -separator.page_coverage_ratio,
        separator.separator_candidate_id,
    )


def _is_line_drawing(node: PdfLayoutNode) -> bool:
    return node.node_type == "drawing" and node.drawing_kind == "line"


def _separator_lies_between(
    *,
    separator: PdfLayoutSeparatorCandidate,
    first: PdfLayoutNode,
    second: PdfLayoutNode,
    orientation: str,
    tolerance: float,
) -> bool:
    separator_center = (
        (separator.bbox.x0 + separator.bbox.x1) / 2,
        (separator.bbox.y0 + separator.bbox.y1) / 2,
    )
    first_center = _center(first)
    second_center = _center(second)
    if orientation == "vertical":
        left, right = sorted((first, second), key=lambda node: _center(node)[0])
        return (
            left.bbox.x1 - tolerance <= separator_center[0] <= right.bbox.x0 + tolerance
            and separator.bbox.y0 - tolerance <= min(first_center[1], second_center[1])
            and separator.bbox.y1 + tolerance >= max(first_center[1], second_center[1])
        )
    upper, lower = sorted((first, second), key=lambda node: _center(node)[1])
    return (
        upper.bbox.y1 - tolerance <= separator_center[1] <= lower.bbox.y0 + tolerance
        and separator.bbox.x0 - tolerance <= min(first_center[0], second_center[0])
        and separator.bbox.x1 + tolerance >= max(first_center[0], second_center[0])
    )


def _rotation_compatible(
    first: float | None,
    second: float | None,
    tolerance: float,
) -> bool:
    if first is None or second is None:
        return False
    difference = abs(first - second) % 360
    return min(difference, 360 - difference) <= tolerance


def _quality_weight(value: str) -> float:
    return {"precise": 1.0, "approximate": 0.8, "unknown": 0.6}[value]


def _gap_proximity(gap: float, maximum_gap: float) -> float:
    return 1 - min(1.0, gap / max(maximum_gap, 1e-9))


def _bbox_width(node: PdfLayoutNode) -> float:
    return node.bbox.x1 - node.bbox.x0


def _bbox_height(node: PdfLayoutNode) -> float:
    return node.bbox.y1 - node.bbox.y0


def _bbox_area(node: PdfLayoutNode) -> float:
    return _bbox_width(node) * _bbox_height(node)


def _center(node: PdfLayoutNode) -> tuple[float, float]:
    return (
        (node.bbox.x0 + node.bbox.x1) / 2,
        (node.bbox.y0 + node.bbox.y1) / 2,
    )

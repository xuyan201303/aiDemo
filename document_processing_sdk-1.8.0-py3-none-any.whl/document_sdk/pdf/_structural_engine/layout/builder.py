# ruff: noqa: ARG002, C901, D202, EM101, F841, I001, PLR0912, PLR0913, PLR0915, TRY003, UP017

from bisect import bisect_left, bisect_right
from collections import Counter
from collections.abc import Callable, Collection
from dataclasses import dataclass
from datetime import datetime, timezone
import json
from time import perf_counter

from document_sdk.pdf._structural_engine.facts.contracts import (
    PdfFactArtifact,
    PdfPageFacts,
)
from document_sdk.pdf._structural_engine.facts.normalization import (
    PdfWarningCollector,
    make_warning,
)
from document_sdk.pdf._structural_engine.facts.status import (
    PdfExtractionStatus,
    PdfFactWarning,
    PdfWarningCode,
    PdfWarningSuppressionSummary,
)
from document_sdk.pdf._structural_engine.layout.contracts import (
    PDF_LAYOUT_DRAWING_MATERIALIZATION_POLICY_VERSION,
    PDF_LAYOUT_GRAPH_BUILDER_NAME,
    PDF_LAYOUT_GRAPH_BUILDER_VERSION,
    PDF_LAYOUT_GRAPH_SCHEMA_VERSION,
    PDF_LAYOUT_RELATION_METHOD_VERSION,
    PdfLayoutBuildResourceUsage,
    PdfLayoutEdge,
    PdfLayoutGraphArtifact,
    PdfLayoutGeometryEvidence,
    PdfLayoutNode,
    PdfLayoutPageGraph,
    PdfLayoutPageResourceUsage,
    PdfLayoutRelationObservationScope,
    PdfLayoutSeparatorCandidate,
    PdfLayoutSeparatorOrientation,
    PdfLayoutStageTimingProfile,
    layout_edge_sort_key,
    layout_separator_sort_key,
)
from document_sdk.pdf._structural_engine.layout.identifiers import (
    canonical_payload_sha256,
    layout_edge_identifier,
    layout_graph_identifier,
    layout_page_identifier,
    layout_settings_digest,
    source_fact_artifact_digest,
)
from document_sdk.pdf._structural_engine.layout.limits import (
    PdfLayoutGraphLimits,
    PdfLayoutGraphOptions,
)
from document_sdk.pdf._structural_engine.layout.normalization import (
    build_layout_node,
    is_usable_layout_geometry,
    select_page_layout_facts,
    source_page_warning_count,
)
from document_sdk.pdf._structural_engine.layout.quality import (
    build_page_quality_signals,
)
from document_sdk.pdf._structural_engine.layout.relations import (
    PdfLayoutRelationCandidate,
    PdfLayoutRelationCorridor,
    PdfLayoutRelationOperationCounter,
    eligible_layout_relations,
    infer_layout_relations,
    is_layout_relation_axis_aligned,
    layout_relation_corridors,
    wide_adjacency_pair_is_eligible,
)
from document_sdk.pdf._structural_engine.layout.separators import (
    build_drawing_separator_candidates,
)
from document_sdk.pdf._structural_engine.layout.spatial_index import PdfPageSpatialIndex


@dataclass(frozen=True)
class _BuiltPage:
    graph: PdfLayoutPageGraph
    serialized_size_bytes: int
    deterministic_payload: dict[str, object]


@dataclass(frozen=True)
class _RelationContext:
    nodes: tuple[PdfLayoutNode, ...]
    complete: bool
    deadline_reached: bool
    scanned_candidate_count: int
    scanned_bucket_count: int
    query_count: int


@dataclass(frozen=True)
class _SeparatorRelationContext:
    candidates: tuple[PdfLayoutSeparatorCandidate, ...]
    source_inventory_complete: bool
    complete: bool
    deadline_reached: bool
    scanned_candidate_count: int
    scanned_bucket_count: int
    query_count: int


@dataclass(frozen=True)
class _CompleteRegionQuery:
    candidate_indices: tuple[int, ...]
    scanned_candidate_count: int


@dataclass(frozen=True)
class _WideAdjacencyEndpointSearch:
    candidate_pairs: frozenset[tuple[int, int]]
    directed_endpoint_counts: tuple[tuple[int, int], ...]
    truncated_node_indices: frozenset[int]
    scanned_candidate_count: int
    deadline_reached: bool


@dataclass(frozen=True, slots=True)
class _BoundCachedRelationCandidate:
    """Cheap endpoint binding; materialized only after sparse retention."""

    source_node_id: str
    target_node_id: str
    relation_type: str
    confidence: float
    geometry_evidence: PdfLayoutGeometryEvidence
    template: PdfLayoutRelationCandidate


@dataclass(frozen=True)
class _DrawingNodeRetention:
    nodes: list[PdfLayoutNode]
    retained_count: int
    suppressed_count: int
    near_identical_suppressed_count: int
    repeated_decorative_suppressed_count: int
    relation_ineligible_suppressed_count: int


@dataclass(frozen=True)
class _PageNodeCenterIndex:
    """Exact bounded center-range index for complete corridor lookups."""

    nodes: tuple[PdfLayoutNode, ...]
    centers: tuple[tuple[float, float], ...]
    x_values: tuple[float, ...]
    x_indices: tuple[int, ...]
    y_values: tuple[float, ...]
    y_indices: tuple[int, ...]

    @classmethod
    def build(
        cls,
        *,
        nodes: list[PdfLayoutNode],
        indexed_node_indices: tuple[int, ...],
    ) -> "_PageNodeCenterIndex":
        frozen_nodes = tuple(nodes)
        centers = tuple(
            (
                (node.bbox.x0 + node.bbox.x1) / 2,
                (node.bbox.y0 + node.bbox.y1) / 2,
            )
            for node in frozen_nodes
        )
        x_indices = tuple(
            sorted(
                indexed_node_indices,
                key=lambda index: (
                    centers[index][0],
                    frozen_nodes[index].source_order,
                    frozen_nodes[index].node_id,
                ),
            )
        )
        y_indices = tuple(
            sorted(
                indexed_node_indices,
                key=lambda index: (
                    centers[index][1],
                    frozen_nodes[index].source_order,
                    frozen_nodes[index].node_id,
                ),
            )
        )
        return cls(
            nodes=frozen_nodes,
            centers=centers,
            x_values=tuple(centers[index][0] for index in x_indices),
            x_indices=x_indices,
            y_values=tuple(centers[index][1] for index in y_indices),
            y_indices=y_indices,
        )

    def query_complete_region(
        self,
        *,
        x0: float,
        y0: float,
        x1: float,
        y1: float,
        excluded_indices: Collection[int],
        max_candidates: int,
        max_candidate_scan: int,
        deadline_reached: Callable[[], bool],
    ) -> _CompleteRegionQuery | None:
        minimum_x, maximum_x = sorted((x0, x1))
        minimum_y, maximum_y = sorted((y0, y1))
        x_start = bisect_left(self.x_values, minimum_x)
        x_end = bisect_right(self.x_values, maximum_x)
        y_start = bisect_left(self.y_values, minimum_y)
        y_end = bisect_right(self.y_values, maximum_y)
        if x_end - x_start <= y_end - y_start:
            candidate_axis_indices = self.x_indices[x_start:x_end]
        else:
            candidate_axis_indices = self.y_indices[y_start:y_end]
        if len(candidate_axis_indices) > max_candidate_scan:
            return None

        matches: list[int] = []
        scanned_candidate_count = 0
        if deadline_reached():
            return None
        for node_index in candidate_axis_indices:
            if node_index in excluded_indices:
                continue
            # This exact lookup is bounded by max_candidate_scan.  Sampling the
            # cooperative deadline every 16 retained scans avoids a clock call
            # per center while keeping timeout overshoot explicitly bounded.
            if (
                scanned_candidate_count
                and scanned_candidate_count % 16 == 0
                and deadline_reached()
            ):
                return None
            scanned_candidate_count += 1
            center_x, center_y = self.centers[node_index]
            if (
                minimum_x <= center_x <= maximum_x
                and minimum_y <= center_y <= maximum_y
            ):
                matches.append(node_index)
                if len(matches) > max_candidates:
                    return None
        return _CompleteRegionQuery(
            candidate_indices=tuple(matches),
            scanned_candidate_count=scanned_candidate_count,
        )


def _wide_adjacency_endpoint_pairs(
    *,
    center_index: _PageNodeCenterIndex,
    page_width: float,
    page_height: float,
    options: PdfLayoutGraphOptions,
    max_candidate_scan_per_direction: int,
    deadline_reached: Callable[[], bool],
) -> _WideAdjacencyEndpointSearch:
    """Find reciprocal row/column endpoint neighbors outside local search.

    Cross-axis geometry buckets keep the center-ordered work sparse.  Each
    bucket is scanned in both primary-axis directions and only reciprocal
    nearest aligned endpoints survive.  The shared wide-pair guard then applies
    the page-gap and boundary-band rules used by on-demand inference.
    Incomplete scans are explicit resource truncation, never evidence that an
    endpoint has no nearer neighbor.
    """

    choices: dict[tuple[PdfLayoutSeparatorOrientation, int, int], int] = {}
    truncated_node_indices: set[int] = set()
    scanned_candidate_count = 0
    hit_deadline = False
    scan_counts: Counter[tuple[PdfLayoutSeparatorOrientation, int, int]] = Counter()
    axis_inventory: tuple[
        tuple[
            PdfLayoutSeparatorOrientation,
            tuple[int, ...],
            int,
            float,
            int,
        ],
        ...,
    ] = (
        (
            "horizontal",
            center_index.x_indices,
            0,
            max(page_height, 1.0),
            max(1, options.grid_rows * 2),
        ),
        (
            "vertical",
            center_index.y_indices,
            1,
            max(page_width, 1.0),
            max(1, options.grid_columns * 2),
        ),
    )
    for (
        axis,
        ordered_indices,
        coordinate_index,
        cross_extent,
        bucket_count,
    ) in axis_inventory:
        buckets: dict[int, list[int]] = {}
        bucket_size = cross_extent / bucket_count
        required_relation = (
            "adjacent_horizontal" if axis == "horizontal" else "adjacent_vertical"
        )
        for node_index in ordered_indices:
            node = center_index.nodes[node_index]
            if required_relation not in eligible_layout_relations(node, node):
                continue
            if axis == "horizontal":
                cross_start = node.bbox.y0
                cross_end = node.bbox.y1
            else:
                cross_start = node.bbox.x0
                cross_end = node.bbox.x1
            tolerance = max(cross_end - cross_start, 1.0) * (
                options.alignment_tolerance_ratio
            )
            first_bucket = min(
                bucket_count - 1,
                max(0, int(max(0.0, cross_start - tolerance) / bucket_size)),
            )
            last_bucket = min(
                bucket_count - 1,
                max(0, int(min(cross_extent, cross_end + tolerance) / bucket_size)),
            )
            for bucket in range(first_bucket, last_bucket + 1):
                buckets.setdefault(bucket, []).append(node_index)

        for bucket_indices in buckets.values():
            for position, node_index in enumerate(bucket_indices):
                first = center_index.nodes[node_index]
                first_coordinate = center_index.centers[node_index][coordinate_index]
                for direction in (-1, 1):
                    choice_key = (axis, node_index, direction)
                    cursor = position + direction
                    while 0 <= cursor < len(bucket_indices):
                        if scan_counts[choice_key] >= max_candidate_scan_per_direction:
                            truncated_node_indices.add(node_index)
                            break
                        if scanned_candidate_count % 16 == 0 and deadline_reached():
                            hit_deadline = True
                            break
                        candidate_index = bucket_indices[cursor]
                        candidate = center_index.nodes[candidate_index]
                        scanned_candidate_count += 1
                        scan_counts[choice_key] += 1
                        candidate_coordinate = center_index.centers[candidate_index][
                            coordinate_index
                        ]
                        cursor += direction
                        if not (
                            (direction < 0 and candidate_coordinate < first_coordinate)
                            or (
                                direction > 0
                                and candidate_coordinate > first_coordinate
                            )
                        ):
                            continue
                        if required_relation not in eligible_layout_relations(
                            first, candidate
                        ) or not is_layout_relation_axis_aligned(
                            first=first,
                            second=candidate,
                            axis=axis,
                            options=options,
                        ):
                            continue
                        current = choices.get(choice_key)
                        if current is None or abs(
                            candidate_coordinate - first_coordinate
                        ) < abs(
                            center_index.centers[current][coordinate_index]
                            - first_coordinate
                        ):
                            choices[choice_key] = candidate_index
                        break
                    if hit_deadline:
                        break
                if hit_deadline:
                    break
            if hit_deadline:
                break
        if hit_deadline:
            break

    candidate_pairs: set[tuple[int, int]] = set()
    directed_endpoint_counts: Counter[int] = Counter()
    if not hit_deadline:
        for (axis, node_index, direction), candidate_index in choices.items():
            if choices.get((axis, candidate_index, -direction)) != node_index:
                continue
            pair = (
                (node_index, candidate_index)
                if node_index < candidate_index
                else (candidate_index, node_index)
            )
            if pair in candidate_pairs:
                continue
            if not wide_adjacency_pair_is_eligible(
                first=center_index.nodes[pair[0]],
                second=center_index.nodes[pair[1]],
                axis=axis,
                page_width=page_width,
                page_height=page_height,
                options=options,
            ):
                continue
            candidate_pairs.add(pair)
            directed_endpoint_counts[pair[0]] += 1
            directed_endpoint_counts[pair[1]] += 1

    return _WideAdjacencyEndpointSearch(
        candidate_pairs=frozenset(candidate_pairs),
        directed_endpoint_counts=tuple(sorted(directed_endpoint_counts.items())),
        truncated_node_indices=frozenset(truncated_node_indices),
        scanned_candidate_count=scanned_candidate_count,
        deadline_reached=hit_deadline,
    )


_INTERVENING_CONTEXT_RELATIONS = frozenset({"adjacent_horizontal", "adjacent_vertical"})
_SEPARATOR_CONTEXT_RELATIONS = frozenset(
    {
        "adjacent_horizontal",
        "adjacent_vertical",
        "same_row_candidate",
        "same_column_candidate",
    }
)
_EMPTY_RELATION_CONTEXT = _RelationContext(
    nodes=(),
    complete=True,
    deadline_reached=False,
    scanned_candidate_count=0,
    scanned_bucket_count=0,
    query_count=0,
)
_EMPTY_SEPARATOR_CONTEXT_COMPLETE = _SeparatorRelationContext(
    candidates=(),
    source_inventory_complete=True,
    complete=True,
    deadline_reached=False,
    scanned_candidate_count=0,
    scanned_bucket_count=0,
    query_count=0,
)
_EMPTY_SEPARATOR_CONTEXT_INCOMPLETE_SOURCE = _SeparatorRelationContext(
    candidates=(),
    source_inventory_complete=False,
    complete=True,
    deadline_reached=False,
    scanned_candidate_count=0,
    scanned_bucket_count=0,
    query_count=0,
)
_MAX_RELATION_CORRIDOR_AXIS_CACHE_ENTRIES = 4_096
_MAX_RELATION_INFERENCE_CACHE_ENTRIES = 4_096


class PdfLayoutGraphBuilder:
    """Build a bounded page-local physical graph from canonical PDF Facts."""

    def __init__(
        self,
        *,
        clock: Callable[[], float] = perf_counter,
    ) -> None:
        self._clock = clock

    @property
    def builder_name(self) -> str:
        return PDF_LAYOUT_GRAPH_BUILDER_NAME

    @property
    def builder_version(self) -> str:
        return PDF_LAYOUT_GRAPH_BUILDER_VERSION

    def build(
        self,
        artifact: PdfFactArtifact,
        *,
        limits: PdfLayoutGraphLimits | None = None,
        options: PdfLayoutGraphOptions | None = None,
    ) -> PdfLayoutGraphArtifact:
        effective_limits = limits or PdfLayoutGraphLimits()
        effective_options = options or PdfLayoutGraphOptions()
        started_at = self._clock()
        source_digest = source_fact_artifact_digest(artifact)
        settings_digest = layout_settings_digest(
            limits=effective_limits,
            options=effective_options,
        )
        layout_graph_id = layout_graph_identifier(
            source_fact_digest=source_digest,
            builder_name=self.builder_name,
            builder_version=self.builder_version,
            settings_digest=settings_digest,
        )
        warning_limit = min(
            effective_limits.max_warning_count,
            max(
                1,
                effective_limits.max_serialized_artifact_bytes // 2_048,
            ),
        )
        collector = PdfWarningCollector(
            parser_name=self.builder_name,
            limit=warning_limit,
        )
        graph_pages: list[PdfLayoutPageGraph] = []
        deterministic_page_payloads: list[dict[str, object]] = []
        pages_attempted = 0
        total_nodes = 0
        total_edges = 0
        total_separator_candidates = 0
        total_candidate_pairs = 0
        status = PdfExtractionStatus.SUCCESS
        partial_build = False
        page_bytes = 0
        page_size_budget = max(
            0,
            effective_limits.max_serialized_artifact_bytes
            - min(
                1024 * 1024,
                max(
                    8_192,
                    effective_limits.max_serialized_artifact_bytes // 2,
                ),
            ),
        )

        if artifact.extraction_status is not PdfExtractionStatus.SUCCESS:
            status = PdfExtractionStatus.PARTIAL
            partial_build = True
            collector.add_fields(
                code=PdfWarningCode.PAGE_PARTIALLY_PARSED,
                message=(
                    "The source PDF Fact artifact is incomplete; the layout graph "
                    "covers only retained canonical Facts."
                ),
            )

        for page in sorted(artifact.pages, key=lambda item: item.page_number):
            if (
                total_nodes >= effective_limits.max_total_nodes
                or total_edges >= effective_limits.max_total_edges
            ):
                collector.add_fields(
                    code=PdfWarningCode.TOTAL_FACT_LIMIT_REACHED,
                    message=(
                        "The layout graph total node or edge limit stopped further "
                        "page construction."
                    ),
                    recoverable=False,
                )
                status = PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED
                partial_build = True
                break
            pages_attempted += 1
            built_page = self._build_page(
                artifact=artifact,
                page=page,
                layout_graph_id=layout_graph_id,
                collector=collector,
                limits=effective_limits,
                options=effective_options,
                node_limit=min(
                    effective_limits.max_nodes_per_page,
                    effective_limits.max_total_nodes - total_nodes,
                ),
                edge_limit=min(
                    effective_limits.max_edges_per_page,
                    effective_limits.max_total_edges - total_edges,
                ),
            )
            serialized_page_bytes = built_page.serialized_size_bytes
            if page_bytes + serialized_page_bytes > page_size_budget:
                collector.add_fields(
                    code=PdfWarningCode.ARTIFACT_SIZE_LIMIT_REACHED,
                    message=(
                        "The serialized layout graph limit stopped further page "
                        "retention."
                    ),
                    recoverable=False,
                )
                status = PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED
                partial_build = True
                break
            graph_pages.append(built_page.graph)
            deterministic_page_payloads.append(built_page.deterministic_payload)
            page_bytes += serialized_page_bytes
            total_nodes += len(built_page.graph.nodes)
            total_edges += len(built_page.graph.edges)
            total_separator_candidates += len(built_page.graph.separator_candidates)
            total_candidate_pairs += (
                built_page.graph.resource_usage.candidate_pair_count
            )
            if (
                built_page.graph.build_status
                is PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED
            ):
                status = PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED
                partial_build = True
            elif (
                built_page.graph.build_status is PdfExtractionStatus.PARTIAL
                and status is PdfExtractionStatus.SUCCESS
            ):
                status = PdfExtractionStatus.PARTIAL
                partial_build = True

        if len(graph_pages) != artifact.extracted_page_count:
            partial_build = True
            if status is PdfExtractionStatus.SUCCESS:
                status = PdfExtractionStatus.PARTIAL

        warnings = tuple(collector.final_items())
        warning_suppression = collector.suppression_summary()
        result = self._artifact(
            source=artifact,
            source_digest=source_digest,
            layout_graph_id=layout_graph_id,
            limits=effective_limits,
            options=effective_options,
            status=status,
            partial_build=partial_build,
            pages=tuple(graph_pages),
            deterministic_page_payloads=tuple(deterministic_page_payloads),
            warnings=warnings,
            warning_suppression=warning_suppression,
            pages_attempted=pages_attempted,
            total_candidate_pairs=total_candidate_pairs,
            total_separator_candidates=total_separator_candidates,
            elapsed_milliseconds=(self._clock() - started_at) * 1_000,
        )
        if layout_graph_artifact_serialized_size(
            result,
            page_serialized_size_bytes=page_bytes,
        ) > (effective_limits.max_serialized_artifact_bytes):
            raise RuntimeError(
                "minimum retained layout graph envelope exceeds its hard size limit"
            )
        return result

    def _build_page(
        self,
        *,
        artifact: PdfFactArtifact,
        page: PdfPageFacts,
        layout_graph_id: str,
        collector: PdfWarningCollector,
        limits: PdfLayoutGraphLimits,
        options: PdfLayoutGraphOptions,
        node_limit: int,
        edge_limit: int,
    ) -> _BuiltPage:
        page_started_at = self._clock()
        deadline = page_started_at + (limits.max_page_build_milliseconds / 1_000)
        deadline_callback_count = 0
        deadline_callback_reached = False

        def sampled_deadline_reached() -> bool:
            nonlocal deadline_callback_count, deadline_callback_reached
            if deadline_callback_reached:
                return True
            deadline_callback_count += 1
            if deadline_callback_count % 16:
                return False
            deadline_callback_reached = self._clock() > deadline
            return deadline_callback_reached

        page_graph_id = layout_page_identifier(
            layout_graph_id=layout_graph_id,
            source_page_id=page.page_id,
        )
        page_warnings: list[PdfFactWarning] = []
        selection = select_page_layout_facts(
            page=page,
            parser_capabilities=artifact.parser_capabilities,
            artifact_warnings=artifact.warnings,
            options=options,
            limits=limits,
        )
        selected_facts = selection.facts
        text_conflict_truncated = bool(
            selection.text_layer_selection.spatial_text_conflict_suppressed_occurrence_count
        )
        supplemental_text_truncated = bool(
            selection.text_layer_selection.supplemental_truncation_count
        )
        if text_conflict_truncated:
            collector.add_page(
                make_warning(
                    code=PdfWarningCode.TOTAL_FACT_LIMIT_REACHED,
                    parser_name=self.builder_name,
                    message=(
                        "The text-alternative limit truncated a spatial text "
                        "conflict cluster."
                    ),
                    page_number=page.page_number,
                    recoverable=False,
                ),
                target=page_warnings,
            )
        if supplemental_text_truncated:
            collector.add_page(
                make_warning(
                    code=PdfWarningCode.TOTAL_FACT_LIMIT_REACHED,
                    parser_name=self.builder_name,
                    message=(
                        "The supplemental text gap-fill limit left source text "
                        "regions unrepresented in the graph."
                    ),
                    page_number=page.page_number,
                    recoverable=False,
                ),
                target=page_warnings,
            )
        eligible_fact_count = len(selected_facts)
        source_fact_count = sum(
            len(facts)
            for facts in (
                page.text_spans,
                page.words,
                page.line_candidates,
                page.characters,
                page.drawings,
                page.image_regions,
            )
        )
        invalid_geometry_count = 0
        node_truncated = False
        timed_out = False
        nodes: list[PdfLayoutNode] = []
        text_length_by_node_id: dict[str, int] = {}

        node_construction_started_at = self._clock()
        for selected in selected_facts:
            if self._clock() > deadline:
                timed_out = True
                break
            if not is_usable_layout_geometry(selected):
                invalid_geometry_count += 1
                collector.add_page(
                    make_warning(
                        code=PdfWarningCode.INVALID_BBOX,
                        parser_name=self.builder_name,
                        message=(
                            "A canonical Fact did not have usable geometry for its "
                            "layout node type."
                        ),
                        page_number=page.page_number,
                        fact_id=selected.fact.fact_id,
                    ),
                    target=page_warnings,
                )
                if not selected.retain_zero_width_text_anchor:
                    continue
            if len(nodes) >= node_limit:
                node_truncated = True
                break
            node = build_layout_node(
                selected=selected,
                artifact=artifact,
                page_graph_id=page_graph_id,
            )
            nodes.append(node)
            if selected.text_length is not None:
                text_length_by_node_id[node.node_id] = selected.text_length
        node_construction_milliseconds = (
            self._clock() - node_construction_started_at
        ) * 1_000

        if node_truncated:
            collector.add_page(
                make_warning(
                    code=PdfWarningCode.TOTAL_FACT_LIMIT_REACHED,
                    parser_name=self.builder_name,
                    message="The page layout node limit truncated canonical Facts.",
                    page_number=page.page_number,
                    recoverable=False,
                ),
                target=page_warnings,
            )
        if timed_out:
            collector.add_page(
                make_warning(
                    code=PdfWarningCode.EXTRACTION_TIMEOUT,
                    parser_name=self.builder_name,
                    message="The cooperative page layout build time limit was reached.",
                    page_number=page.page_number,
                    recoverable=False,
                ),
                target=page_warnings,
            )

        # select_page_layout_facts() already returns the canonical source-order
        # sequence and filtering invalid/truncated facts preserves that order.
        # Sorting the fully materialized Pydantic nodes repeated the same
        # O(N log N) work on every high-node page.
        # Separator primitives must see the complete valid source drawing
        # inventory before repeated decorative drawing nodes are compacted.
        # Only content nodes participate in nearby-quality queries; drawing
        # primitives themselves are evaluated directly from their source Facts.
        separator_neighbor_indices = tuple(
            index for index, node in enumerate(nodes) if node.node_type != "drawing"
        )
        spatial_index_construction_milliseconds = 0.0
        spatial_index_started_at = self._clock()
        separator_source_index = PdfPageSpatialIndex(
            nodes=nodes,
            page_width=page.canonical_width,
            page_height=page.canonical_height,
            columns=options.grid_columns,
            rows=options.grid_rows,
            adaptive_partitioning=options.adaptive_spatial_partitioning,
            target_nodes_per_partition=options.spatial_partition_target_nodes,
            max_partition_subdivisions=(options.spatial_partition_max_subdivisions),
            indexed_node_indices=separator_neighbor_indices,
        )
        spatial_index_construction_milliseconds += (
            self._clock() - spatial_index_started_at
        ) * 1_000
        candidate_pairs: set[tuple[int, int]] = set()
        candidate_truncated_node_indices: set[int] = set()
        directed_candidate_count = 0
        directed_candidate_counts: Counter[int] = Counter()
        nodes_with_directed_candidates: set[int] = set()
        maximum_directed_candidates_per_node = 0
        spatial_bucket_scan_count = 0
        separator_result = build_drawing_separator_candidates(
            page_graph_id=page_graph_id,
            nodes=nodes,
            drawing_facts_by_id=selection.drawing_facts_by_id,
            spatial_index=separator_source_index,
            page_width=page.canonical_width,
            page_height=page.canonical_height,
            options=options,
            limits=limits,
            deadline_reached=sampled_deadline_reached,
        )
        separator_candidates = tuple(
            sorted(
                separator_result.candidates,
                key=layout_separator_sort_key,
            )
        )
        # Canonical page-boundary evidence is public separator inventory, but
        # it never reduces an internal relation's confidence.  Keep only real
        # drawing separators in the relation-query index so boundary-only pages
        # do not execute thousands of empty separator corridor lookups.
        relation_separator_candidates = tuple(
            candidate
            for candidate in separator_candidates
            if candidate.evidence_kind == "drawing_separator"
        )
        separator_source_nodes = nodes
        drawing_retention = _retain_layout_drawing_nodes(
            nodes=nodes,
            separator_candidates=separator_candidates,
            page_width=page.canonical_width,
            page_height=page.canonical_height,
            limits=limits,
            options=options,
        )
        nodes = drawing_retention.nodes
        non_line_drawing_indices = tuple(
            index
            for index, node in enumerate(nodes)
            if node.node_type == "drawing" and node.drawing_kind != "line"
        )
        retained_drawing_relation_indices = (
            non_line_drawing_indices
            if len(non_line_drawing_indices)
            <= limits.max_generic_drawing_relation_nodes_per_page
            else ()
        )
        generic_drawing_relation_node_suppressed_count = len(
            non_line_drawing_indices
        ) - len(retained_drawing_relation_indices)
        retained_drawing_relation_index_set = frozenset(
            retained_drawing_relation_indices
        )
        relation_node_indices = tuple(
            index
            for index, node in enumerate(nodes)
            if node.node_type != "drawing"
            or index in retained_drawing_relation_index_set
        )
        relation_node_index_set = frozenset(relation_node_indices)
        relation_candidate_query_limit = _relation_candidate_query_limit(
            relation_node_count=len(relation_node_indices),
            limits=limits,
        )
        spatial_index_started_at = self._clock()
        index = (
            separator_source_index
            if nodes is separator_source_nodes
            and relation_node_indices == separator_neighbor_indices
            else PdfPageSpatialIndex(
                nodes=nodes,
                page_width=page.canonical_width,
                page_height=page.canonical_height,
                columns=options.grid_columns,
                rows=options.grid_rows,
                adaptive_partitioning=options.adaptive_spatial_partitioning,
                target_nodes_per_partition=(options.spatial_partition_target_nodes),
                max_partition_subdivisions=(options.spatial_partition_max_subdivisions),
                indexed_node_indices=relation_node_indices,
            )
        )
        spatial_index_construction_milliseconds += (
            self._clock() - spatial_index_started_at
        ) * 1_000
        row_column_index_started_at = self._clock()
        relation_context_index = _PageNodeCenterIndex.build(
            nodes=nodes,
            indexed_node_indices=relation_node_indices,
        )
        row_column_neighbor_index_milliseconds = (
            self._clock() - row_column_index_started_at
        ) * 1_000
        separator_index_complete = index.index_separator_candidates(
            relation_separator_candidates,
            deadline_reached=sampled_deadline_reached,
        )
        spatial_bucket_scan_count += separator_result.scanned_partition_count
        separator_source_inventory_truncated = (
            separator_result.source_inventory_truncated or node_truncated
        )
        separator_quality_metadata_truncated = bool(
            separator_result.quality_metadata_truncation_count
        )
        separator_truncated = any(
            (
                separator_source_inventory_truncated,
                separator_quality_metadata_truncated,
                not separator_index_complete,
            )
        )
        if separator_result.deadline_reached or not separator_index_complete:
            timed_out = True
        if separator_source_inventory_truncated:
            collector.add_page(
                make_warning(
                    code=PdfWarningCode.TOTAL_FACT_LIMIT_REACHED,
                    parser_name=self.builder_name,
                    message=(
                        "The page-level separator source inventory was truncated."
                    ),
                    page_number=page.page_number,
                    recoverable=False,
                ),
                target=page_warnings,
            )
        if separator_quality_metadata_truncated:
            collector.add_page(
                make_warning(
                    code=PdfWarningCode.TOTAL_FACT_LIMIT_REACHED,
                    parser_name=self.builder_name,
                    message=(
                        "Nearby-node quality metadata was truncated for one or "
                        "more separator candidates."
                    ),
                    page_number=page.page_number,
                    recoverable=False,
                ),
                target=page_warnings,
            )
        if not separator_index_complete:
            collector.add_page(
                make_warning(
                    code=PdfWarningCode.TOTAL_FACT_LIMIT_REACHED,
                    parser_name=self.builder_name,
                    message="The separator spatial index build was incomplete.",
                    page_number=page.page_number,
                    recoverable=False,
                ),
                target=page_warnings,
            )
        generic_relation_search_started_at = self._clock()
        if not timed_out:
            for node_index, node in enumerate(nodes):
                if self._clock() > deadline:
                    timed_out = True
                    break
                if node_index not in relation_node_index_set:
                    continue
                width = node.bbox.x1 - node.bbox.x0
                height = node.bbox.y1 - node.bbox.y0
                query = index.query(
                    node_index=node_index,
                    expand_x=max(
                        page.canonical_width * options.horizontal_search_radius_ratio,
                        width * options.node_size_search_multiplier,
                    ),
                    expand_y=max(
                        page.canonical_height * options.vertical_search_radius_ratio,
                        height * options.node_size_search_multiplier,
                    ),
                    max_buckets=limits.max_spatial_buckets_per_query,
                    max_candidates=relation_candidate_query_limit,
                    max_candidate_scan=limits.max_candidate_scan_per_node,
                    deadline_reached=sampled_deadline_reached,
                )
                spatial_bucket_scan_count += query.scanned_bucket_count
                directed_candidate_count += len(query.candidate_indices)
                directed_candidate_counts[node_index] += len(query.candidate_indices)
                if query.candidate_indices:
                    nodes_with_directed_candidates.add(node_index)
                maximum_directed_candidates_per_node = max(
                    maximum_directed_candidates_per_node,
                    len(query.candidate_indices),
                )
                if query.candidate_limit_reached or query.bucket_limit_reached:
                    candidate_truncated_node_indices.add(node_index)
                if query.deadline_reached:
                    timed_out = True
                for candidate_index in query.candidate_indices:
                    candidate_pairs.add(
                        (node_index, candidate_index)
                        if node_index < candidate_index
                        else (candidate_index, node_index)
                    )
                if timed_out:
                    break
        # The row/column endpoint pass is independent of the local candidate
        # inventory.  Keep it available for the medium-density local bound so
        # reciprocal wide neighbors are still observed even when a 16-way
        # local query reports its intentionally bounded observation scope.
        # Extremely dense pages retain the historical behavior: an incomplete
        # four-way local scan skips this supplemental pass, while a complete
        # sparse local scan may still add its independently verified endpoints.
        if not timed_out and (
            not candidate_truncated_node_indices
            or len(relation_node_indices) * limits.max_candidates_per_node
            <= limits.max_relation_candidates_per_page
        ):
            wide_endpoint_search = _wide_adjacency_endpoint_pairs(
                center_index=relation_context_index,
                page_width=page.canonical_width,
                page_height=page.canonical_height,
                options=options,
                max_candidate_scan_per_direction=(limits.max_candidate_scan_per_node),
                deadline_reached=sampled_deadline_reached,
            )
            candidate_truncated_node_indices.update(
                wide_endpoint_search.truncated_node_indices
            )
            if wide_endpoint_search.deadline_reached:
                timed_out = True
            else:
                wide_directed_counts = dict(
                    wide_endpoint_search.directed_endpoint_counts
                )
                for pair in sorted(wide_endpoint_search.candidate_pairs):
                    if pair in candidate_pairs:
                        continue
                    if len(candidate_pairs) >= limits.max_relation_candidates_per_page:
                        candidate_truncated_node_indices.update(pair)
                        continue
                    if any(
                        directed_candidate_counts[node_index]
                        >= limits.max_candidates_per_node
                        for node_index in pair
                    ):
                        candidate_truncated_node_indices.update(pair)
                        continue
                    candidate_pairs.add(pair)
                    for node_index in pair:
                        directed_candidate_count += 1
                        directed_candidate_counts[node_index] += 1
                        nodes_with_directed_candidates.add(node_index)
                # The search result counts are a consistency check on its
                # reciprocal two-endpoint accounting; only newly stored pairs
                # are reflected in the public directed-candidate metrics.
                if sum(wide_directed_counts.values()) != (
                    len(wide_endpoint_search.candidate_pairs) * 2
                ):
                    candidate_truncated_node_indices.update(wide_directed_counts)
        maximum_directed_candidates_per_node = max(
            directed_candidate_counts.values(),
            default=0,
        )
        candidate_truncated_nodes = len(candidate_truncated_node_indices)
        generic_relation_candidate_search_milliseconds = (
            self._clock() - generic_relation_search_started_at
        ) * 1_000

        if candidate_truncated_nodes:
            collector.add_page(
                make_warning(
                    code=PdfWarningCode.TOTAL_FACT_LIMIT_REACHED,
                    parser_name=self.builder_name,
                    message=(
                        "The bounded spatial index truncated one or more node "
                        "candidate searches."
                    ),
                    page_number=page.page_number,
                    recoverable=False,
                ),
                target=page_warnings,
            )

        relation_candidates: list[
            PdfLayoutRelationCandidate | _BoundCachedRelationCandidate
        ] = []
        inferred_relation_candidate_count = 0
        relation_candidate_limit_reached = False
        hard_edge_limit_reached = False
        relation_operation_counter = PdfLayoutRelationOperationCounter()
        corridor_query_count = 0
        maximum_relation_context_nodes = 0
        relation_context_truncation_count = 0
        relation_context_candidate_scans = 0
        separator_relation_query_count = 0
        separator_relation_candidate_scans = 0
        separator_relation_context_truncation_count = 0
        retained_separator_evidence_truncation_count = 0
        retained_separator_source_inventory_truncation_count = 0
        retained_separator_context_truncation_count = 0
        retained_separator_id_list_truncation_count = 0
        node_ids = tuple(node.node_id for node in nodes)
        relation_inference_cache: dict[
            tuple[object, ...],
            tuple[
                str,
                str,
                tuple[PdfLayoutRelationCandidate, ...],
            ],
        ] = {}
        relation_corridor_axis_cache: dict[
            tuple[object, ...],
            tuple[str, ...],
        ] = {}
        relation_inference_cache_enabled = (
            len(candidate_pairs) <= _MAX_RELATION_INFERENCE_CACHE_ENTRIES
        )
        relation_inference_started_at = self._clock()
        for first_index, second_index in sorted(
            candidate_pairs,
            key=lambda item: (
                node_ids[item[0]],
                node_ids[item[1]],
            ),
        ):
            if self._clock() > deadline:
                timed_out = True
                break
            eligible_relations = eligible_layout_relations(
                nodes[first_index],
                nodes[second_index],
            )
            needs_intervening_context = bool(
                eligible_relations & _INTERVENING_CONTEXT_RELATIONS
            )
            needs_separator_context = bool(
                relation_separator_candidates
                and eligible_relations & _SEPARATOR_CONTEXT_RELATIONS
            )
            first_node = nodes[first_index]
            second_node = nodes[second_index]
            pair_geometry_key = _relation_pair_geometry_cache_key(
                first=first_node,
                second=second_node,
            )
            # Both context builders previously derived the same corridors for
            # each pair.  Materialize them once, and skip them entirely for
            # drawing-only contains/overlaps pairs where they cannot affect an
            # inferred relation.
            corridors = (
                _cached_relation_corridors(
                    cache=relation_corridor_axis_cache,
                    pair_geometry_key=pair_geometry_key,
                    first=first_node,
                    second=second_node,
                    options=options,
                )
                if needs_intervening_context or needs_separator_context
                else ()
            )
            relation_context = (
                self._build_relation_context(
                    index=index,
                    context_index=relation_context_index,
                    nodes=nodes,
                    first_index=first_index,
                    second_index=second_index,
                    corridors=corridors,
                    limits=limits,
                    deadline=deadline,
                )
                if corridors
                else _EMPTY_RELATION_CONTEXT
            )
            spatial_bucket_scan_count += relation_context.scanned_bucket_count
            corridor_query_count += relation_context.query_count
            relation_context_candidate_scans += relation_context.scanned_candidate_count
            maximum_relation_context_nodes = max(
                maximum_relation_context_nodes,
                len(relation_context.nodes),
            )
            if not relation_context.complete:
                relation_context_truncation_count += 1
            if relation_context.deadline_reached:
                timed_out = True
                break
            separator_context = (
                self._build_separator_relation_context(
                    index=index,
                    nodes=nodes,
                    first_index=first_index,
                    second_index=second_index,
                    eligible_relations=eligible_relations,
                    corridors=corridors,
                    limits=limits,
                    deadline=deadline,
                    separator_candidates_available=True,
                    separator_source_inventory_complete=(
                        not separator_source_inventory_truncated
                    ),
                    remaining_page_queries=(
                        limits.max_separator_relation_queries_per_page
                        - separator_relation_query_count
                    ),
                )
                if needs_separator_context and corridors
                else (
                    _EMPTY_SEPARATOR_CONTEXT_COMPLETE
                    if not separator_source_inventory_truncated
                    else _EMPTY_SEPARATOR_CONTEXT_INCOMPLETE_SOURCE
                )
            )
            separator_relation_query_count += separator_context.query_count
            separator_relation_candidate_scans += (
                separator_context.scanned_candidate_count
            )
            spatial_bucket_scan_count += separator_context.scanned_bucket_count
            if not separator_context.complete:
                separator_relation_context_truncation_count += 1
            if separator_context.deadline_reached:
                timed_out = True
                break
            pair_drawing_separators = tuple(
                candidate
                for candidate in separator_context.candidates
                if candidate.evidence_kind == "drawing_separator"
            )
            cache_key = (
                _relation_inference_cache_key(
                    first=first_node,
                    second=second_node,
                    pair_geometry_key=pair_geometry_key,
                    nearby_nodes=relation_context.nodes,
                    relation_context_complete=relation_context.complete,
                    page_width=page.canonical_width,
                    page_height=page.canonical_height,
                    options=options,
                )
                if (
                    relation_inference_cache_enabled
                    and relation_context.complete
                    and separator_context.complete
                    and separator_context.source_inventory_complete
                    and not pair_drawing_separators
                )
                else None
            )
            cached_inference = (
                relation_inference_cache.get(cache_key)
                if cache_key is not None
                else None
            )
            inferred_candidates: tuple[
                PdfLayoutRelationCandidate | _BoundCachedRelationCandidate,
                ...,
            ]
            if cached_inference is None:
                inferred_candidates = infer_layout_relations(
                    first=first_node,
                    second=second_node,
                    page_width=page.canonical_width,
                    page_height=page.canonical_height,
                    options=options,
                    nearby_nodes=relation_context.nodes,
                    relation_context_complete=relation_context.complete,
                    operation_counter=relation_operation_counter,
                    deadline_reached=sampled_deadline_reached,
                    separator_candidates=pair_drawing_separators,
                    separator_source_inventory_complete=(
                        separator_context.source_inventory_complete
                    ),
                    separator_context_complete=separator_context.complete,
                    max_separator_scans=limits.max_separator_scans_per_relation,
                    max_separator_evidence=(limits.max_separator_evidence_per_edge),
                )
                if (
                    cache_key is not None
                    and self._clock() <= deadline
                    and len(relation_inference_cache)
                    < _MAX_RELATION_INFERENCE_CACHE_ENTRIES
                ):
                    relation_inference_cache[cache_key] = (
                        first_node.node_id,
                        second_node.node_id,
                        inferred_candidates,
                    )
            else:
                inferred_candidates = _rebind_cached_relation_candidates(
                    cached=cached_inference,
                    first_node_id=first_node.node_id,
                    second_node_id=second_node.node_id,
                )
            if self._clock() > deadline:
                timed_out = True
            else:
                remaining_relation_capacity = (
                    limits.max_relation_candidates_per_page - len(relation_candidates)
                )
                if len(inferred_candidates) <= remaining_relation_capacity:
                    inferred_relation_candidate_count += len(inferred_candidates)
                    relation_candidates.extend(inferred_candidates)
                else:
                    # Preserve the historical counter's first rejected
                    # candidate while extending the retained prefix in C.
                    inferred_relation_candidate_count += remaining_relation_capacity + 1
                    relation_candidates.extend(
                        inferred_candidates[:remaining_relation_capacity]
                    )
                    relation_candidate_limit_reached = True
            if timed_out or relation_candidate_limit_reached:
                break
        relation_inference_milliseconds = (
            self._clock() - relation_inference_started_at
        ) * 1_000

        sparse_retention_started_at = self._clock()
        (
            retained_candidates,
            sparse_relation_suppressed_count,
            maximum_retained,
            retained_edge_limit_reached,
        ) = _retain_sparse_relation_candidates(
            relation_candidates,
            limits=limits,
            edge_limit=edge_limit,
        )
        if retained_edge_limit_reached:
            hard_edge_limit_reached = True
        sparse_retention_milliseconds = (
            self._clock() - sparse_retention_started_at
        ) * 1_000

        edges: list[PdfLayoutEdge] = []
        for candidate in retained_candidates:
            template = (
                candidate.template
                if isinstance(candidate, _BoundCachedRelationCandidate)
                else candidate
            )
            edge = PdfLayoutEdge(
                edge_id=layout_edge_identifier(
                    page_graph_id=page_graph_id,
                    source_node_id=candidate.source_node_id,
                    target_node_id=candidate.target_node_id,
                    relation_type=candidate.relation_type,
                    method_version=PDF_LAYOUT_RELATION_METHOD_VERSION,
                    adjacency_basis=template.adjacency_basis,
                ),
                source_node_id=candidate.source_node_id,
                target_node_id=candidate.target_node_id,
                relation_type=template.relation_type,
                adjacency_basis=template.adjacency_basis,
                confidence=template.confidence,
                base_confidence=template.base_confidence,
                separator_confidence_reduction=(
                    template.separator_confidence_reduction
                ),
                separator_candidate_ids=template.separator_candidate_ids,
                relevant_separator_count=template.relevant_separator_count,
                retained_separator_evidence_count=(
                    template.retained_separator_evidence_count
                ),
                separator_source_inventory_truncated=(
                    template.separator_source_inventory_truncated
                ),
                separator_context_truncated=(template.separator_context_truncated),
                separator_id_list_truncated=(template.separator_id_list_truncated),
                relevant_separator_count_is_lower_bound=(
                    template.relevant_separator_count_is_lower_bound
                ),
                separator_evidence_truncated=(template.separator_evidence_truncated),
                geometry_evidence=template.geometry_evidence,
                warning_codes=template.warning_codes,
            )
            edges.append(edge)
            if edge.separator_evidence_truncated:
                retained_separator_evidence_truncation_count += 1
            if edge.separator_source_inventory_truncated:
                retained_separator_source_inventory_truncation_count += 1
            if edge.separator_context_truncated:
                retained_separator_context_truncation_count += 1
            if edge.separator_id_list_truncated:
                retained_separator_id_list_truncation_count += 1

        if relation_candidate_limit_reached:
            collector.add_page(
                make_warning(
                    code=PdfWarningCode.TOTAL_FACT_LIMIT_REACHED,
                    parser_name=self.builder_name,
                    message=(
                        "The bounded relation candidate inventory reached its "
                        "configured observation scope."
                    ),
                    page_number=page.page_number,
                    recoverable=True,
                ),
                target=page_warnings,
            )
        if hard_edge_limit_reached:
            collector.add_page(
                make_warning(
                    code=PdfWarningCode.TOTAL_FACT_LIMIT_REACHED,
                    parser_name=self.builder_name,
                    message="The page layout edge limit truncated spatial relations.",
                    page_number=page.page_number,
                    recoverable=False,
                ),
                target=page_warnings,
            )
        if relation_context_truncation_count:
            collector.add_page(
                make_warning(
                    code=PdfWarningCode.TOTAL_FACT_LIMIT_REACHED,
                    parser_name=self.builder_name,
                    message=(
                        "The bounded relation corridor context was truncated for "
                        "one or more candidate pairs."
                    ),
                    page_number=page.page_number,
                    recoverable=False,
                ),
                target=page_warnings,
            )
        separator_context_truncated = bool(
            separator_relation_context_truncation_count
            or relation_operation_counter.separator_context_truncations
        )
        if separator_context_truncated:
            collector.add_page(
                make_warning(
                    code=PdfWarningCode.TOTAL_FACT_LIMIT_REACHED,
                    parser_name=self.builder_name,
                    message=(
                        "The bounded relation separator context search was "
                        "incomplete for one or more candidate relations."
                    ),
                    page_number=page.page_number,
                    recoverable=False,
                ),
                target=page_warnings,
            )
        if timed_out and not any(
            warning.code is PdfWarningCode.EXTRACTION_TIMEOUT
            for warning in page_warnings
        ):
            collector.add_page(
                make_warning(
                    code=PdfWarningCode.EXTRACTION_TIMEOUT,
                    parser_name=self.builder_name,
                    message="The cooperative page layout build time limit was reached.",
                    page_number=page.page_number,
                    recoverable=False,
                ),
                target=page_warnings,
            )

        edges.sort(key=layout_edge_sort_key)
        relation_search_truncated = any(
            (
                timed_out,
                bool(candidate_truncated_nodes),
                relation_candidate_limit_reached,
                hard_edge_limit_reached,
                bool(relation_context_truncation_count),
            )
        )
        resource_truncation = any(
            (
                node_truncated,
                text_conflict_truncated,
                supplemental_text_truncated,
                separator_source_inventory_truncated,
                timed_out,
                hard_edge_limit_reached,
            )
        )
        if resource_truncation:
            page_status = PdfExtractionStatus.RESOURCE_LIMIT_EXCEEDED
        elif (
            invalid_geometry_count
            or page.extraction_status is not PdfExtractionStatus.SUCCESS
            or selection.text_layer_selection.selected_layer_incomplete
        ):
            page_status = PdfExtractionStatus.PARTIAL
        else:
            page_status = PdfExtractionStatus.SUCCESS
        quality_started_at = self._clock()
        quality_eligible_fact_count = max(
            0,
            eligible_fact_count - drawing_retention.suppressed_count,
        )
        quality = build_page_quality_signals(
            page=page,
            nodes=nodes,
            edges=edges,
            text_length_by_node_id=text_length_by_node_id,
            text_layer_selection=selection.text_layer_selection,
            source_fact_count=source_fact_count,
            # Intentional, provenance-preserving drawing materialization policy
            # is not Fact loss or a node resource truncation.  Keep the full
            # inventory in resource_usage while evaluating retention against
            # the policy-adjusted materialization inventory.
            eligible_fact_count=quality_eligible_fact_count,
            invalid_geometry_count=invalid_geometry_count,
            resource_truncation=resource_truncation,
            source_document_partial=(
                artifact.partial_extraction
                or not artifact.extraction_scope_result.source_document_fully_extracted
            ),
            source_warning_count=source_page_warning_count(page),
            text_bbox_quality=artifact.parser_capabilities.text_bbox_quality,
            drawing_bbox_quality=(artifact.parser_capabilities.drawing_bbox_quality),
        )
        quality_calculation_milliseconds = (self._clock() - quality_started_at) * 1_000
        normalization_timings = selection.stage_timings
        profiled_stage_values = (
            normalization_timings.text_layer_metrics,
            normalization_timings.hard_duplicate_grouping,
            normalization_timings.spatial_conflict_analysis,
            normalization_timings.supplemental_gap_fill,
            node_construction_milliseconds,
            separator_result.drawing_primitive_extraction_milliseconds,
            separator_result.separator_generation_milliseconds,
            spatial_index_construction_milliseconds,
            row_column_neighbor_index_milliseconds,
            generic_relation_candidate_search_milliseconds,
            relation_inference_milliseconds,
            sparse_retention_milliseconds,
            quality_calculation_milliseconds,
        )
        stage_timings = PdfLayoutStageTimingProfile(
            text_layer_metrics=normalization_timings.text_layer_metrics,
            hard_duplicate_grouping=(normalization_timings.hard_duplicate_grouping),
            spatial_conflict_analysis=(normalization_timings.spatial_conflict_analysis),
            supplemental_gap_fill=normalization_timings.supplemental_gap_fill,
            node_construction=node_construction_milliseconds,
            drawing_primitive_extraction=(
                separator_result.drawing_primitive_extraction_milliseconds
            ),
            separator_generation=(separator_result.separator_generation_milliseconds),
            spatial_index_construction=spatial_index_construction_milliseconds,
            row_column_neighbor_index=row_column_neighbor_index_milliseconds,
            generic_relation_candidate_search=(
                generic_relation_candidate_search_milliseconds
            ),
            relation_inference=relation_inference_milliseconds,
            sparse_retention=sparse_retention_milliseconds,
            quality_calculation=quality_calculation_milliseconds,
            post_page_stages_available=False,
            artifact_construction=None,
            serialization_size_calculation=None,
            total_profiled_milliseconds=sum(profiled_stage_values),
        )
        artifact_construction_started_at = self._clock()
        graph = PdfLayoutPageGraph(
            page_graph_id=page_graph_id,
            source_page_id=page.page_id,
            page_number=page.page_number,
            canonical_width=page.canonical_width,
            canonical_height=page.canonical_height,
            rotation=page.rotation,
            nodes=tuple(nodes),
            edges=tuple(edges),
            separator_candidates=separator_candidates,
            relation_observation=PdfLayoutRelationObservationScope(
                relation_search_truncated=relation_search_truncated,
                bounded_search_completed_without_resource_truncation=(
                    not relation_search_truncated
                ),
                eligible_relation_node_count=len(relation_node_indices),
                nodes_with_directed_candidates=len(nodes_with_directed_candidates),
                nodes_without_directed_candidates=(
                    len(relation_node_indices) - len(nodes_with_directed_candidates)
                ),
                candidate_scope_ratio=(
                    round(
                        len(nodes_with_directed_candidates)
                        / len(relation_node_indices),
                        6,
                    )
                    if relation_node_indices
                    else None
                ),
            ),
            quality_signals=quality,
            build_status=page_status,
            warnings=tuple(page_warnings),
            resource_usage=PdfLayoutPageResourceUsage(
                eligible_fact_count=eligible_fact_count,
                retained_node_count=len(nodes),
                candidate_pair_count=len(candidate_pairs),
                retained_edge_count=len(edges),
                inferred_relation_candidate_count=(inferred_relation_candidate_count),
                sparse_relation_suppressed_count=(sparse_relation_suppressed_count),
                relation_candidate_limit_reached=(relation_candidate_limit_reached),
                hard_edge_limit_reached=hard_edge_limit_reached,
                generic_drawing_relation_node_suppressed_count=(
                    generic_drawing_relation_node_suppressed_count
                ),
                drawing_node_suppression_metrics_available=(
                    separator_result.source_drawing_fact_count > 0
                    and separator_result.source_drawing_fact_count
                    == sum(node.node_type == "drawing" for node in nodes)
                    + drawing_retention.suppressed_count
                ),
                source_drawing_fact_count=(separator_result.source_drawing_fact_count),
                retained_drawing_node_count=drawing_retention.retained_count,
                drawing_node_suppressed_count=drawing_retention.suppressed_count,
                drawing_node_suppression_policy_version=(
                    PDF_LAYOUT_DRAWING_MATERIALIZATION_POLICY_VERSION
                ),
                near_identical_drawing_node_suppressed_count=(
                    drawing_retention.near_identical_suppressed_count
                ),
                repeated_decorative_drawing_node_suppressed_count=(
                    drawing_retention.repeated_decorative_suppressed_count
                ),
                relation_ineligible_drawing_node_suppressed_count=(
                    drawing_retention.relation_ineligible_suppressed_count
                ),
                separator_source_drawing_fact_evaluated_count=(
                    separator_result.evaluated_drawing_fact_count
                ),
                separator_primitive_retained_count=(
                    separator_result.retained_primitive_count
                ),
                maximum_retained_edges_per_node_relation=maximum_retained,
                invalid_geometry_count=invalid_geometry_count,
                candidate_truncated_node_count=candidate_truncated_nodes,
                directed_candidate_count=directed_candidate_count,
                maximum_directed_candidates_per_node=(
                    maximum_directed_candidates_per_node
                ),
                corridor_query_count=corridor_query_count,
                maximum_relation_context_nodes=maximum_relation_context_nodes,
                total_intervening_candidate_scans=(
                    relation_context_candidate_scans
                    + relation_operation_counter.intervening_candidate_scans
                ),
                relation_context_truncation_count=(relation_context_truncation_count),
                spatial_bucket_scan_count=spatial_bucket_scan_count,
                separator_candidate_count=len(separator_candidates),
                separator_query_count=separator_result.query_count,
                separator_candidate_truncation_count=(
                    separator_result.query_truncation_count
                    + int(separator_result.candidate_limit_reached)
                    + separator_result.primitive_truncation_count
                ),
                separator_source_inventory_truncated=(
                    separator_source_inventory_truncated
                ),
                separator_candidate_quality_truncation_count=(
                    sum(
                        candidate.quality_metadata_truncated
                        for candidate in separator_candidates
                    )
                ),
                separator_path_geometry_incomplete_count=(
                    separator_result.path_geometry_incomplete_count
                ),
                separator_primitive_truncation_count=(
                    separator_result.primitive_truncation_count
                ),
                separator_relation_query_count=separator_relation_query_count,
                separator_relation_candidate_scan_count=(
                    separator_relation_candidate_scans
                ),
                separator_evidence_evaluation_scan_count=(
                    relation_operation_counter.separator_evidence_candidate_scans
                ),
                separator_relation_context_truncation_count=(
                    separator_relation_context_truncation_count
                ),
                separator_evidence_truncation_count=(
                    retained_separator_evidence_truncation_count
                ),
                separator_source_inventory_truncation_edge_count=(
                    retained_separator_source_inventory_truncation_count
                ),
                separator_context_truncation_edge_count=(
                    retained_separator_context_truncation_count
                ),
                separator_id_list_truncation_count=(
                    retained_separator_id_list_truncation_count
                ),
                maximum_retained_separator_evidence_per_edge=(
                    max(
                        (edge.retained_separator_evidence_count for edge in edges),
                        default=0,
                    )
                ),
                partition_count=index.partition_count,
                maximum_nodes_per_partition=(index.maximum_nodes_per_partition),
                refined_base_bucket_count=index.refined_base_bucket_count,
                stage_timings=stage_timings,
                build_elapsed_milliseconds=(self._clock() - page_started_at) * 1_000,
            ),
        )
        artifact_construction_milliseconds = (
            self._clock() - artifact_construction_started_at
        ) * 1_000
        serialized_payload = graph.model_dump(mode="json")
        deterministic_payload = dict(serialized_payload)
        deterministic_resource_usage = dict(serialized_payload["resource_usage"])
        deterministic_resource_usage.pop("build_elapsed_milliseconds", None)
        deterministic_resource_usage.pop("stage_timings", None)
        deterministic_payload["resource_usage"] = deterministic_resource_usage

        # Measure the same full-page JSON serialization used by the hard
        # artifact-size gate.  The timing profile is then finalized by model
        # copy because the graph contracts are frozen.  Re-serializing the
        # entire graph after inserting that non-deterministic timing would
        # create a self-referential measurement and repeat O(nodes + edges)
        # work.  Only the timing-profile JSON changes, so its exact byte delta
        # gives the final serialized size without weakening the hard limit.
        serialization_started_at = self._clock()
        provisional_serialized_size_bytes = len(graph.model_dump_json().encode("utf-8"))
        serialization_size_calculation_milliseconds = (
            self._clock() - serialization_started_at
        ) * 1_000
        final_stage_timings = stage_timings.model_copy(
            update={
                "post_page_stages_available": True,
                "artifact_construction": artifact_construction_milliseconds,
                "serialization_size_calculation": (
                    serialization_size_calculation_milliseconds
                ),
                "total_profiled_milliseconds": (
                    stage_timings.total_profiled_milliseconds
                    + artifact_construction_milliseconds
                    + serialization_size_calculation_milliseconds
                ),
            }
        )
        final_resource_usage = graph.resource_usage.model_copy(
            update={"stage_timings": final_stage_timings}
        )
        final_graph = graph.model_copy(update={"resource_usage": final_resource_usage})
        provisional_profile_size_bytes = len(
            stage_timings.model_dump_json().encode("utf-8")
        )
        final_profile_size_bytes = len(
            final_stage_timings.model_dump_json().encode("utf-8")
        )
        return _BuiltPage(
            graph=final_graph,
            serialized_size_bytes=(
                provisional_serialized_size_bytes
                - provisional_profile_size_bytes
                + final_profile_size_bytes
            ),
            deterministic_payload=deterministic_payload,
        )

    def _build_relation_context(
        self,
        *,
        index: PdfPageSpatialIndex,
        context_index: _PageNodeCenterIndex,
        nodes: list[PdfLayoutNode],
        first_index: int,
        second_index: int,
        corridors: tuple[PdfLayoutRelationCorridor, ...],
        limits: PdfLayoutGraphLimits,
        deadline: float,
    ) -> _RelationContext:
        retained_indices: set[int] = set()
        scanned_candidate_count = 0
        scanned_bucket_count = 0
        query_count = 0
        complete = True
        hit_deadline = False

        for corridor in corridors:
            if self._clock() > deadline:
                complete = False
                hit_deadline = True
                break
            remaining_candidates = limits.max_intervening_candidates_per_relation - len(
                retained_indices
            )
            remaining_scan = (
                limits.max_intervening_candidate_scan - scanned_candidate_count
            )
            if remaining_candidates <= 0 or remaining_scan <= 0:
                complete = False
                break
            reference_x, reference_y = corridor.center
            query_count += 1
            excluded_indices = {
                first_index,
                second_index,
                *retained_indices,
            }
            complete_query = context_index.query_complete_region(
                x0=corridor.x0,
                y0=corridor.y0,
                x1=corridor.x1,
                y1=corridor.y1,
                excluded_indices=excluded_indices,
                max_candidates=remaining_candidates,
                max_candidate_scan=remaining_scan,
                deadline_reached=lambda: self._clock() > deadline,
            )
            if complete_query is not None:
                retained_indices.update(complete_query.candidate_indices)
                scanned_candidate_count += complete_query.scanned_candidate_count
                continue
            query = index.query_region(
                x0=corridor.x0,
                y0=corridor.y0,
                x1=corridor.x1,
                y1=corridor.y1,
                reference_x=reference_x,
                reference_y=reference_y,
                excluded_indices=excluded_indices,
                max_buckets=limits.max_spatial_buckets_per_query,
                max_candidates=remaining_candidates,
                max_candidate_scan=remaining_scan,
                deadline_reached=lambda: self._clock() > deadline,
            )
            retained_indices.update(query.candidate_indices)
            scanned_candidate_count += query.scanned_candidate_count
            scanned_bucket_count += query.scanned_bucket_count
            if (
                query.candidate_limit_reached
                or query.bucket_limit_reached
                or query.deadline_reached
            ):
                complete = False
            if query.deadline_reached:
                hit_deadline = True
                break

        context_nodes = tuple(
            nodes[node_index]
            for node_index in sorted(
                retained_indices,
                key=lambda node_index: nodes[node_index].node_id,
            )
        )
        return _RelationContext(
            nodes=context_nodes,
            complete=complete,
            deadline_reached=hit_deadline,
            scanned_candidate_count=scanned_candidate_count,
            scanned_bucket_count=scanned_bucket_count,
            query_count=query_count,
        )

    def _build_separator_relation_context(
        self,
        *,
        index: PdfPageSpatialIndex,
        nodes: list[PdfLayoutNode],
        first_index: int,
        second_index: int,
        eligible_relations: frozenset[str],
        corridors: tuple[PdfLayoutRelationCorridor, ...],
        limits: PdfLayoutGraphLimits,
        deadline: float,
        separator_candidates_available: bool,
        separator_source_inventory_complete: bool,
        remaining_page_queries: int,
    ) -> _SeparatorRelationContext:
        if not separator_candidates_available or not (
            eligible_relations & _SEPARATOR_CONTEXT_RELATIONS
        ):
            return _SeparatorRelationContext(
                candidates=(),
                source_inventory_complete=separator_source_inventory_complete,
                complete=True,
                deadline_reached=False,
                scanned_candidate_count=0,
                scanned_bucket_count=0,
                query_count=0,
            )
        retained_by_id: dict[str, PdfLayoutSeparatorCandidate] = {}
        scanned_candidate_count = 0
        scanned_bucket_count = 0
        query_count = 0
        complete = True
        hit_deadline = False
        for corridor in corridors:
            if self._clock() > deadline:
                complete = False
                hit_deadline = True
                break
            if query_count >= remaining_page_queries:
                complete = False
                break
            remaining_scan = (
                limits.max_separator_scans_per_relation - scanned_candidate_count
            )
            if remaining_scan <= 0:
                complete = False
                break
            orientation: PdfLayoutSeparatorOrientation = (
                "vertical" if corridor.axis == "horizontal" else "horizontal"
            )
            reference_x, reference_y = corridor.center
            query_count += 1
            query = index.query_separators(
                orientation=orientation,
                x0=corridor.x0,
                y0=corridor.y0,
                x1=corridor.x1,
                y1=corridor.y1,
                reference_x=reference_x,
                reference_y=reference_y,
                max_buckets=limits.max_spatial_buckets_per_query,
                max_candidates=remaining_scan,
                max_candidate_scan=remaining_scan,
                deadline_reached=lambda: self._clock() > deadline,
            )
            scanned_candidate_count += query.scanned_candidate_count
            scanned_bucket_count += query.scanned_bucket_count
            for candidate in query.candidates:
                retained_by_id[candidate.separator_candidate_id] = candidate
            if (
                query.candidate_limit_reached
                or query.bucket_limit_reached
                or query.deadline_reached
            ):
                complete = False
            if query.deadline_reached:
                hit_deadline = True
                break
        return _SeparatorRelationContext(
            candidates=tuple(
                sorted(
                    retained_by_id.values(),
                    key=layout_separator_sort_key,
                )
            ),
            source_inventory_complete=separator_source_inventory_complete,
            complete=complete,
            deadline_reached=hit_deadline,
            scanned_candidate_count=scanned_candidate_count,
            scanned_bucket_count=scanned_bucket_count,
            query_count=query_count,
        )

    def _artifact(
        self,
        *,
        source: PdfFactArtifact,
        source_digest: str,
        layout_graph_id: str,
        limits: PdfLayoutGraphLimits,
        options: PdfLayoutGraphOptions,
        status: PdfExtractionStatus,
        partial_build: bool,
        pages: tuple[PdfLayoutPageGraph, ...],
        warnings: tuple[PdfFactWarning, ...],
        warning_suppression: PdfWarningSuppressionSummary,
        pages_attempted: int,
        total_candidate_pairs: int,
        total_separator_candidates: int,
        elapsed_milliseconds: float,
        deterministic_page_payloads: tuple[dict[str, object], ...],
    ) -> PdfLayoutGraphArtifact:
        total_nodes = sum(len(page.nodes) for page in pages)
        total_edges = sum(len(page.edges) for page in pages)
        digest_payload = {
            "schema_version": PDF_LAYOUT_GRAPH_SCHEMA_VERSION,
            "layout_graph_id": layout_graph_id,
            "source_fact_artifact_sha256": source_digest,
            "builder_name": self.builder_name,
            "builder_version": self.builder_version,
            "status": status.value,
            "limits": limits.model_dump(mode="json"),
            "options": options.model_dump(mode="json"),
            "warnings": [item.model_dump(mode="json") for item in warnings],
            "warning_suppression": warning_suppression.model_dump(mode="json"),
            "pages": list(deterministic_page_payloads),
        }
        return PdfLayoutGraphArtifact(
            schema_version=PDF_LAYOUT_GRAPH_SCHEMA_VERSION,
            layout_graph_id=layout_graph_id,
            source_fact_schema_version=source.schema_version,
            source_document_id=source.document_id,
            source_fact_artifact_sha256=source_digest,
            source_parser_name=source.parser_name,
            source_parser_version=source.parser_version,
            graph_builder_name=self.builder_name,
            graph_builder_version=self.builder_version,
            built_at=datetime.now(timezone.utc),
            build_status=status,
            source_page_count=source.page_count,
            source_extracted_page_count=source.extracted_page_count,
            source_document_partial_extraction=(
                source.partial_extraction
                or not source.extraction_scope_result.source_document_fully_extracted
            ),
            graph_page_count=len(pages),
            total_node_count=total_nodes,
            total_edge_count=total_edges,
            total_separator_candidate_count=total_separator_candidates,
            applied_limits=limits,
            build_options=options,
            warnings=warnings,
            warning_suppression=warning_suppression,
            partial_build=partial_build,
            graph_digest=canonical_payload_sha256(digest_payload),
            resource_usage=PdfLayoutBuildResourceUsage(
                pages_attempted=pages_attempted,
                pages_built=len(pages),
                total_nodes=total_nodes,
                total_edges=total_edges,
                total_separator_candidates=total_separator_candidates,
                total_candidate_pairs=total_candidate_pairs,
                elapsed_milliseconds=max(0.0, elapsed_milliseconds),
            ),
            pages=pages,
        )


def layout_graph_artifact_serialized_size(
    artifact: PdfLayoutGraphArtifact,
    *,
    page_serialized_size_bytes: int | None = None,
) -> int:
    # Key ordering does not affect byte length; pydantic-core emits the same
    # compact UTF-8 JSON representation without a second Python object walk.
    if page_serialized_size_bytes is None:
        return len(artifact.model_dump_json().encode("utf-8"))
    envelope = artifact.model_dump(mode="json", exclude={"pages"})
    envelope_size = _serialized_size(envelope)
    page_separator_bytes = max(0, len(artifact.pages) - 1)
    # Replace the envelope's closing brace with ,"pages":[...]}.
    return (
        envelope_size
        - 1
        + len(',"pages":[')
        + page_serialized_size_bytes
        + page_separator_bytes
        + len("]}")
    )


def _retain_layout_drawing_nodes(
    *,
    nodes: list[PdfLayoutNode],
    separator_candidates: tuple[PdfLayoutSeparatorCandidate, ...],
    page_width: float,
    page_height: float,
    limits: PdfLayoutGraphLimits,
    options: PdfLayoutGraphOptions,
) -> _DrawingNodeRetention:
    """Bound repeated decorative drawings after complete separator evaluation.

    Small drawing inventories remain fail-closed and retain every drawing.
    Large inventories are compacted independently of whether the page also
    contains text or images: every non-drawing node, separator provenance,
    page frame, long axis-aligned shape, and container-sized rectangle remains
    retained.
    """

    drawing_count = sum(node.node_type == "drawing" for node in nodes)
    family_limit = max(
        1,
        limits.max_generic_drawing_relation_nodes_per_page,
    )
    if drawing_count <= family_limit:
        return _DrawingNodeRetention(
            nodes=nodes,
            retained_count=drawing_count,
            suppressed_count=0,
            near_identical_suppressed_count=0,
            repeated_decorative_suppressed_count=0,
            relation_ineligible_suppressed_count=0,
        )

    required_node_ids = {
        candidate.drawing_node_id
        for candidate in separator_candidates
        if candidate.drawing_node_id is not None
    }
    retained_nodes: list[PdfLayoutNode] = []
    retained_spatial_keys: set[tuple[object, ...]] = set()
    retained_family_counts: Counter[tuple[object, ...]] = Counter()
    near_identical_suppressed_count = 0
    repeated_decorative_suppressed_count = 0
    relation_ineligible_suppressed_count = 0

    for node in nodes:
        if node.node_type != "drawing":
            retained_nodes.append(node)
            continue
        width = node.bbox.x1 - node.bbox.x0
        height = node.bbox.y1 - node.bbox.y0
        spatial_key = (
            node.drawing_kind,
            round(node.bbox.x0, 6),
            round(node.bbox.y0, 6),
            round(node.bbox.x1, 6),
            round(node.bbox.y1, 6),
            node.rotation,
        )
        family_key = (
            node.drawing_kind,
            round(width, 6),
            round(height, 6),
            node.rotation,
        )
        page_frame = (
            abs(node.bbox.x0) <= options.separator_page_boundary_tolerance_points
            and abs(node.bbox.y0) <= options.separator_page_boundary_tolerance_points
            and abs(node.bbox.x1 - page_width)
            <= options.separator_page_boundary_tolerance_points
            and abs(node.bbox.y1 - page_height)
            <= options.separator_page_boundary_tolerance_points
        )
        long_axis_aligned = max(
            width, height
        ) >= options.separator_minimum_length_points and (
            width >= max(height, 1.0) * options.separator_orientation_ratio
            or height >= max(width, 1.0) * options.separator_orientation_ratio
        )
        container_sized_rectangle = (
            node.drawing_kind == "rectangle"
            and width >= options.separator_minimum_length_points
            and height >= options.separator_minimum_length_points
        )
        required = (
            node.node_id in required_node_ids
            or page_frame
            or long_axis_aligned
            or container_sized_rectangle
        )
        if required:
            retained_nodes.append(node)
            retained_spatial_keys.add(spatial_key)
            retained_family_counts[family_key] += 1
            continue
        if spatial_key in retained_spatial_keys:
            near_identical_suppressed_count += 1
            continue
        if retained_family_counts[family_key] >= family_limit:
            if node.drawing_kind == "line":
                relation_ineligible_suppressed_count += 1
            else:
                repeated_decorative_suppressed_count += 1
            continue
        retained_nodes.append(node)
        retained_spatial_keys.add(spatial_key)
        retained_family_counts[family_key] += 1

    suppressed_count = drawing_count - sum(
        node.node_type == "drawing" for node in retained_nodes
    )
    return _DrawingNodeRetention(
        nodes=retained_nodes,
        retained_count=drawing_count - suppressed_count,
        suppressed_count=suppressed_count,
        near_identical_suppressed_count=near_identical_suppressed_count,
        repeated_decorative_suppressed_count=(repeated_decorative_suppressed_count),
        relation_ineligible_suppressed_count=(relation_ineligible_suppressed_count),
    )


def _relation_candidate_query_limit(
    *,
    relation_node_count: int,
    limits: PdfLayoutGraphLimits,
) -> int:
    """Keep candidate discovery proportional to the sparse stored inventory.

    Sparse pages retain the configured 64-way neighborhood.  A medium-density
    page uses a 16-way local observation width derived from four retained-edge
    slots.  Above one quarter of the page-wide candidate budget, a dense-medium
    page uses an eight-way observation width.  These are sparse, non-exhaustive
    inventories rather than per-family completeness guarantees; exact pairs
    remain available through on-demand evaluation, while the independent
    reciprocal row/column pass preserves wide adjacency.  Once the configured
    full neighborhood itself exceeds the page-wide relation budget, the
    existing four-way high-density observation bound still applies.
    """

    configured_candidate_work = relation_node_count * limits.max_candidates_per_node
    if configured_candidate_work <= (limits.max_relation_candidates_per_page // 8):
        return limits.max_candidates_per_node
    if configured_candidate_work <= (limits.max_relation_candidates_per_page // 4):
        medium_density_local_limit = limits.max_retained_edges_per_node_per_relation * 4
        return min(
            limits.max_candidates_per_node,
            max(
                limits.max_retained_edges_per_node_per_relation,
                medium_density_local_limit,
            ),
        )
    if configured_candidate_work <= limits.max_relation_candidates_per_page:
        dense_medium_local_limit = limits.max_retained_edges_per_node_per_relation * 2
        return min(
            limits.max_candidates_per_node,
            max(
                limits.max_retained_edges_per_node_per_relation,
                dense_medium_local_limit,
            ),
        )
    # One endpoint pair can emit multiple relation candidates.  One local peer
    # per retained edge slot keeps the high-density observation proportional to
    # its sparse stored inventory without claiming complete relation coverage.
    # Wide reciprocal endpoints are discovered separately by the bounded
    # row/column pass above whenever the local scan is complete.
    high_node_local_limit = limits.max_retained_edges_per_node_per_relation
    return min(
        limits.max_candidates_per_node,
        max(1, high_node_local_limit),
    )


def _relation_pair_geometry_cache_key(
    *,
    first: PdfLayoutNode,
    second: PdfLayoutNode,
) -> tuple[object, ...]:
    """Describe translation-invariant endpoint geometry within one page build."""

    first_x0 = first.bbox.x0
    first_y0 = first.bbox.y0
    return (
        first.node_type,
        first.drawing_kind,
        first.geometry_quality,
        first.rotation,
        second.node_type,
        second.drawing_kind,
        second.geometry_quality,
        second.rotation,
        first.bbox.x1 - first_x0,
        first.bbox.y1 - first_y0,
        second.bbox.x0 - first_x0,
        second.bbox.y0 - first_y0,
        second.bbox.x1 - first_x0,
        second.bbox.y1 - first_y0,
        first.node_id < second.node_id,
    )


def _cached_relation_corridors(
    *,
    cache: dict[tuple[object, ...], tuple[str, ...]],
    pair_geometry_key: tuple[object, ...],
    first: PdfLayoutNode,
    second: PdfLayoutNode,
    options: PdfLayoutGraphOptions,
) -> tuple[PdfLayoutRelationCorridor, ...]:
    """Cache corridor eligibility while preserving exact coordinate arithmetic."""

    axes = cache.get(pair_geometry_key)
    if axes is None:
        computed_corridors = layout_relation_corridors(
            first=first,
            second=second,
            options=options,
        )
        if len(cache) < _MAX_RELATION_CORRIDOR_AXIS_CACHE_ENTRIES:
            cache[pair_geometry_key] = tuple(
                corridor.axis for corridor in computed_corridors
            )
        return computed_corridors

    corridors: list[PdfLayoutRelationCorridor] = []
    for axis in axes:
        if axis == "horizontal":
            source, target = (
                (first, second) if first.bbox.x1 <= second.bbox.x0 else (second, first)
            )
            tolerance = (
                max(
                    first.bbox.y1 - first.bbox.y0,
                    second.bbox.y1 - second.bbox.y0,
                    1.0,
                )
                * options.alignment_tolerance_ratio
            )
            corridors.append(
                PdfLayoutRelationCorridor(
                    axis="horizontal",
                    x0=source.bbox.x1,
                    y0=min(first.bbox.y0, second.bbox.y0) - tolerance,
                    x1=target.bbox.x0,
                    y1=max(first.bbox.y1, second.bbox.y1) + tolerance,
                )
            )
        else:
            source, target = (
                (first, second) if first.bbox.y1 <= second.bbox.y0 else (second, first)
            )
            tolerance = (
                max(
                    first.bbox.x1 - first.bbox.x0,
                    second.bbox.x1 - second.bbox.x0,
                    1.0,
                )
                * options.alignment_tolerance_ratio
            )
            corridors.append(
                PdfLayoutRelationCorridor(
                    axis="vertical",
                    x0=min(first.bbox.x0, second.bbox.x0) - tolerance,
                    y0=source.bbox.y1,
                    x1=max(first.bbox.x1, second.bbox.x1) + tolerance,
                    y1=target.bbox.y0,
                )
            )
    return tuple(corridors)


def _relation_inference_cache_key(
    *,
    first: PdfLayoutNode,
    second: PdfLayoutNode,
    pair_geometry_key: tuple[object, ...] | None = None,
    nearby_nodes: tuple[PdfLayoutNode, ...] = (),
    relation_context_complete: bool = True,
    page_width: float = 1.0,
    page_height: float = 1.0,
    options: PdfLayoutGraphOptions | None = None,
) -> tuple[object, ...]:
    """Describe translation-invariant pair and complete-context geometry.

    Relation v4's mutual-nearest decision depends on the complete corridor
    inventory, not only on the endpoint pair.  Including the translated nearby
    geometry lets repeated grid fragments share inference without weakening that
    decision or treating missing context as evidence.
    """

    effective_options = options or PdfLayoutGraphOptions()
    boundary_height = max(page_height, 1.0) * (
        effective_options.mutual_nearest_boundary_band_ratio
    )
    maximum_boundary_gap_ratio = (
        effective_options.maximum_boundary_band_horizontal_gap_page_ratio
    )

    def boundary_band(node: PdfLayoutNode) -> str:
        center_y = (node.bbox.y0 + node.bbox.y1) / 2
        if center_y <= boundary_height:
            return "top"
        if center_y >= max(page_height, 1.0) - boundary_height:
            return "bottom"
        return "content"

    context_geometry: tuple[tuple[object, ...], ...] = ()
    if nearby_nodes:
        first_x0 = first.bbox.x0
        first_y0 = first.bbox.y0
        context_geometry = tuple(
            sorted(
                (
                    node.bbox.x0 - first_x0,
                    node.bbox.y0 - first_y0,
                    node.bbox.x1 - first_x0,
                    node.bbox.y1 - first_y0,
                    node.node_type,
                    node.drawing_kind or "",
                    node.geometry_quality,
                    -1.0 if node.rotation is None else node.rotation,
                )
                for node in nearby_nodes
            )
        )
    return (
        pair_geometry_key
        if pair_geometry_key is not None
        else _relation_pair_geometry_cache_key(first=first, second=second),
        relation_context_complete,
        max(page_width, 1.0),
        max(page_height, 1.0),
        effective_options.maximum_mutual_nearest_gap_page_ratio,
        effective_options.mutual_nearest_boundary_band_ratio,
        maximum_boundary_gap_ratio,
        boundary_band(first),
        boundary_band(second),
        context_geometry,
    )


def _rebind_cached_relation_candidates(
    *,
    cached: tuple[
        str,
        str,
        tuple[PdfLayoutRelationCandidate, ...],
    ],
    first_node_id: str,
    second_node_id: str,
) -> tuple[_BoundCachedRelationCandidate, ...]:
    cached_first_id, cached_second_id, candidates = cached
    rebound: list[_BoundCachedRelationCandidate] = []
    for candidate in candidates:
        if candidate.source_node_id == cached_first_id:
            source_node_id = first_node_id
        elif candidate.source_node_id == cached_second_id:
            source_node_id = second_node_id
        else:
            raise RuntimeError("cached relation candidate escaped its endpoint pair")
        if candidate.target_node_id == cached_first_id:
            target_node_id = first_node_id
        elif candidate.target_node_id == cached_second_id:
            target_node_id = second_node_id
        else:
            raise RuntimeError("cached relation candidate escaped its endpoint pair")
        rebound.append(
            _BoundCachedRelationCandidate(
                source_node_id=source_node_id,
                target_node_id=target_node_id,
                relation_type=candidate.relation_type,
                confidence=candidate.confidence,
                geometry_evidence=candidate.geometry_evidence,
                template=candidate,
            )
        )
    return tuple(rebound)


def _retain_sparse_relation_candidates(
    candidates: list[PdfLayoutRelationCandidate | _BoundCachedRelationCandidate],
    *,
    limits: PdfLayoutGraphLimits,
    edge_limit: int,
) -> tuple[
    tuple[PdfLayoutRelationCandidate | _BoundCachedRelationCandidate, ...],
    int,
    int,
    bool,
]:
    """Retain strongest local evidence while bounding each node/relation degree."""

    retained: list[PdfLayoutRelationCandidate | _BoundCachedRelationCandidate] = []
    degree: Counter[tuple[str, str]] = Counter()
    candidates_by_relation: dict[
        str,
        dict[
            tuple[float, float, float, float],
            list[PdfLayoutRelationCandidate | _BoundCachedRelationCandidate],
        ],
    ] = {}
    for candidate in candidates:
        relation_buckets = candidates_by_relation.setdefault(
            candidate.relation_type,
            {},
        )
        relation_buckets.setdefault(
            _relation_candidate_quality_key(candidate),
            [],
        ).append(candidate)
    # Degree caps are relation-local, so independent family sorts are exactly
    # equivalent to one global sort while avoiding comparison work across
    # candidates that can never compete for the same cap.
    for relation_buckets in candidates_by_relation.values():
        for quality_key in sorted(relation_buckets):
            quality_candidates = relation_buckets[quality_key]
            quality_candidates.sort(key=_relation_candidate_identity_key)
            for candidate in quality_candidates:
                cap = limits.max_retained_edges_per_node_per_relation
                if candidate.relation_type == "overlaps":
                    cap = min(cap, limits.max_overlaps_per_node)
                elif candidate.relation_type == "contains":
                    cap = min(cap, limits.max_containment_edges_per_node)
                source_degree_key = (
                    candidate.source_node_id,
                    candidate.relation_type,
                )
                target_degree_key = (
                    candidate.target_node_id,
                    candidate.relation_type,
                )
                if degree[source_degree_key] >= cap or degree[target_degree_key] >= cap:
                    continue
                retained.append(candidate)
                degree[source_degree_key] += 1
                degree[target_degree_key] += 1
    sparse_relation_suppressed_count = len(candidates) - len(retained)
    retained.sort(
        key=lambda item: (
            item.source_node_id,
            item.target_node_id,
            item.relation_type,
        )
    )
    edge_limit_reached = len(retained) > edge_limit
    if edge_limit_reached:
        retained = retained[:edge_limit]
    retained_degree: Counter[tuple[str, str]] = Counter()
    for candidate in retained:
        retained_degree[(candidate.source_node_id, candidate.relation_type)] += 1
        retained_degree[(candidate.target_node_id, candidate.relation_type)] += 1
    return (
        tuple(retained),
        sparse_relation_suppressed_count,
        max(retained_degree.values(), default=0),
        edge_limit_reached,
    )


def _relation_candidate_retention_key(
    candidate: PdfLayoutRelationCandidate | _BoundCachedRelationCandidate,
) -> tuple[object, ...]:
    evidence = candidate.geometry_evidence
    return (
        -candidate.confidence,
        evidence.normalized_distance,
        evidence.horizontal_gap + evidence.vertical_gap,
        evidence.alignment_delta,
        candidate.source_node_id,
        candidate.target_node_id,
        candidate.relation_type,
    )


def _relation_candidate_quality_key(
    candidate: PdfLayoutRelationCandidate | _BoundCachedRelationCandidate,
) -> tuple[float, float, float, float]:
    evidence = candidate.geometry_evidence
    return (
        -candidate.confidence,
        evidence.normalized_distance,
        evidence.horizontal_gap + evidence.vertical_gap,
        evidence.alignment_delta,
    )


def _relation_candidate_identity_key(
    candidate: PdfLayoutRelationCandidate | _BoundCachedRelationCandidate,
) -> tuple[str, str]:
    return (candidate.source_node_id, candidate.target_node_id)


def _serialized_size(value: object) -> int:
    return len(
        json.dumps(
            value,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        ).encode("utf-8")
    )

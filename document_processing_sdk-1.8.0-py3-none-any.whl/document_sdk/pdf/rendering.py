"""Local PDF page and normalized-region rendering."""

from __future__ import annotations

import math
from typing import TYPE_CHECKING

from document_sdk.core import (
    BoundingBox,
    DocumentProcessingError,
    PdfSourceReference,
    RenderedPage,
)
from document_sdk.pdf._bounded_io import CappedPdfBuffer
from document_sdk.pdf._dependencies import require_pdf_support
from document_sdk.pdf._document import (
    PdfPagePreflight,
    inspect_pdf_input,
    open_pdf,
    translate_pdf_errors,
)
from document_sdk.pdf._validation import _validated_pdf_limits, _validated_pdf_model
from document_sdk.pdf.errors import PdfRenderLimitExceededError
from document_sdk.pdf.models import (
    PdfProcessingLimits,  # noqa: TC001 - public annotation.
)

if TYPE_CHECKING:
    from pathlib import Path

    from pypdfium2 import PdfBitmap


def _enforce_render_limit(
    limit_name: str,
    observed: int,
    maximum: int,
) -> None:
    """Raise a render-specific error before expensive pixel work."""
    if observed > maximum:
        raise PdfRenderLimitExceededError(
            limit_name=limit_name,
            observed=observed,
            maximum=maximum,
        )


def _validate_render_parameters(
    page_number: int,
    dpi: int,
    limits: PdfProcessingLimits,
) -> None:
    """Validate strict integer page and resolution inputs."""
    if type(page_number) is not int:
        msg = "PDF page_number must be an integer"
        raise DocumentProcessingError(msg)
    if type(dpi) is not int:
        msg = "PDF dpi must be an integer"
        raise DocumentProcessingError(msg)
    if page_number < 1:
        msg = "PDF page_number must be at least 1"
        raise DocumentProcessingError(msg)
    if dpi <= 0:
        msg = "PDF dpi must be positive"
        raise DocumentProcessingError(msg)
    _enforce_render_limit("render DPI", dpi, limits.max_render_dpi)


def _enforce_render_dimensions(
    width_pixels: int,
    height_pixels: int,
    limits: PdfProcessingLimits,
) -> None:
    """Bound predicted or observed output dimensions and total pixels."""
    _enforce_render_limit(
        "render width pixels",
        width_pixels,
        limits.max_render_width,
    )
    _enforce_render_limit(
        "render height pixels",
        height_pixels,
        limits.max_render_height,
    )
    _enforce_render_limit(
        "render pixels",
        width_pixels * height_pixels,
        limits.max_render_pixels,
    )


def _full_page_dimensions(page: PdfPagePreflight, dpi: int) -> tuple[int, int]:
    """Predict PDFium's displayed full-page output dimensions."""
    scale = dpi / 72
    return (
        math.ceil(page.rendered_width_points * scale),
        math.ceil(page.rendered_height_points * scale),
    )


def _region_geometry(
    page: PdfPagePreflight,
    bounding_box: BoundingBox,
    dpi: int,
) -> tuple[tuple[float, float, float, float], int, int]:
    """Return PDFium crop values and exact predicted region dimensions."""
    page_width = page.rendered_width_points
    page_height = page.rendered_height_points
    scale = dpi / 72
    crop = (
        bounding_box.left * page_width,
        (1 - bounding_box.bottom) * page_height,
        (1 - bounding_box.right) * page_width,
        bounding_box.top * page_height,
    )
    output_width = (
        math.ceil(page_width * scale)
        - math.ceil(crop[0] * scale)
        - math.ceil(crop[2] * scale)
    )
    output_height = (
        math.ceil(page_height * scale)
        - math.ceil(crop[1] * scale)
        - math.ceil(crop[3] * scale)
    )
    return crop, output_width, output_height


def _encode_bitmap(
    bitmap: PdfBitmap,
    limits: PdfProcessingLimits,
) -> tuple[bytes, int, int]:
    """Encode one PDFium bitmap as PNG and return its pixel dimensions."""
    image = bitmap.to_pil()
    try:
        width_pixels, height_pixels = image.size
        _enforce_render_dimensions(width_pixels, height_pixels, limits)
        with CappedPdfBuffer(limits.max_output_bytes) as output:
            image.save(output, format="PNG")
            image_bytes = output.getvalue()
    finally:
        image.close()
    return image_bytes, width_pixels, height_pixels


def render_page(
    path: Path,
    page_number: int,
    *,
    dpi: int = 144,
    limits: PdfProcessingLimits | None = None,
) -> RenderedPage:
    """Render one one-based PDF page to PNG bytes.

    Args:
        path: Local PDF path.
        page_number: Public one-based page number.
        dpi: Positive output resolution.
        limits: Optional explicit PDF resource limits.

    Returns:
        An SDK-owned encoded rendered page.
    """
    effective_limits = _validated_pdf_limits(limits)
    _validate_render_parameters(page_number, dpi, effective_limits)
    require_pdf_support()
    descriptor = inspect_pdf_input(path, effective_limits)

    with (
        translate_pdf_errors(path, "render"),
        open_pdf(
            path,
            descriptor,
            effective_limits,
        ) as (pdf, preflight),
    ):
        if page_number > preflight.page_count:
            msg = (
                f"PDF page_number {page_number} exceeds page count "
                f"{preflight.page_count}"
            )
            raise DocumentProcessingError(msg)
        page_facts = preflight.pages[page_number - 1]
        output_width, output_height = _full_page_dimensions(page_facts, dpi)
        _enforce_render_dimensions(
            output_width,
            output_height,
            effective_limits,
        )
        page = pdf[page_number - 1]
        try:
            # PDFium accepts float scales; its untyped default is inferred as int.
            bitmap = page.render(
                scale=dpi / 72  # pyright: ignore[reportArgumentType]
            )
            try:
                image_bytes, width_pixels, height_pixels = _encode_bitmap(
                    bitmap,
                    effective_limits,
                )
            finally:
                bitmap.close()
        finally:
            page.close()

    return RenderedPage(
        image_bytes=image_bytes,
        width_pixels=width_pixels,
        height_pixels=height_pixels,
        dpi=dpi,
        source=PdfSourceReference(
            file_id=descriptor.file_id,
            page_number=page_number,
        ),
    )


def render_region(
    path: Path,
    page_number: int,
    bounding_box: BoundingBox,
    *,
    dpi: int = 144,
    limits: PdfProcessingLimits | None = None,
) -> RenderedPage:
    """Render a normalized top-left-origin PDF page region to PNG bytes.

    Args:
        path: Local PDF path.
        page_number: Public one-based page number.
        bounding_box: Normalized region in rendered-page coordinates.
        dpi: Positive output resolution.
        limits: Optional explicit PDF resource limits.

    Returns:
        An SDK-owned encoded region image.
    """
    effective_bounding_box = _validated_pdf_model(
        bounding_box,
        BoundingBox,
        "PDF bounding_box is invalid",
    )
    effective_limits = _validated_pdf_limits(limits)
    _validate_render_parameters(page_number, dpi, effective_limits)
    require_pdf_support()
    if (
        effective_bounding_box.left == effective_bounding_box.right
        or effective_bounding_box.top == effective_bounding_box.bottom
    ):
        msg = "PDF bounding_box must have positive area"
        raise DocumentProcessingError(msg)

    descriptor = inspect_pdf_input(path, effective_limits)
    scale = dpi / 72
    with (
        translate_pdf_errors(path, "render a region from"),
        open_pdf(
            path,
            descriptor,
            effective_limits,
        ) as (pdf, preflight),
    ):
        if page_number > preflight.page_count:
            msg = (
                f"PDF page_number {page_number} exceeds page count "
                f"{preflight.page_count}"
            )
            raise DocumentProcessingError(msg)
        page_facts = preflight.pages[page_number - 1]
        crop, output_width, output_height = _region_geometry(
            page_facts,
            effective_bounding_box,
            dpi,
        )
        if output_width < 1 or output_height < 1:
            msg = "PDF bounding_box is too small at the requested DPI"
            raise DocumentProcessingError(msg)
        _enforce_render_dimensions(
            output_width,
            output_height,
            effective_limits,
        )
        page = pdf[page_number - 1]
        try:
            # PDFium accepts float scales; its untyped default is inferred as int.
            bitmap = page.render(
                scale=scale,  # pyright: ignore[reportArgumentType]
                crop=crop,
            )
            try:
                image_bytes, width_pixels, height_pixels = _encode_bitmap(
                    bitmap,
                    effective_limits,
                )
            finally:
                bitmap.close()
        finally:
            page.close()

    return RenderedPage(
        image_bytes=image_bytes,
        width_pixels=width_pixels,
        height_pixels=height_pixels,
        dpi=dpi,
        source=PdfSourceReference(
            file_id=descriptor.file_id,
            page_number=page_number,
            bounding_box=bounding_box,
        ),
    )

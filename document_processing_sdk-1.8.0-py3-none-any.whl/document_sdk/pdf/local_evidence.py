"""Bounded SDK-owned evidence projected from the existing local PDF parser.

These values describe retained parser observations, not original PDF operators
or guaranteed glyph ink bounds. No backend response or parser metadata escapes.
"""

from __future__ import annotations

import math
from itertools import chain
from typing import TYPE_CHECKING, Literal

from pydantic import ConfigDict, Field, FiniteFloat, model_validator

from document_sdk.core.models import SdkModel

if TYPE_CHECKING:
    from document_sdk.pdf._structural_engine.facts.contracts import (
        PdfBoundingBox,
        PdfDrawingFact,
        PdfFactArtifact,
        PdfPageBox,
        PdfTextFact,
    )


type _ExtractionStatus = Literal[
    "success",
    "partial",
    "unsupported",
    "no_text_layer",
    "encrypted",
    "resource_limit_exceeded",
    "malformed",
    "parser_error",
    "internal_error",
    "invalid_request",
]
type _ScalarSemantics = Literal[
    "nominal", "effective_visual", "effective_visual_aggregate", "unavailable"
]
type _ScalarUnit = Literal["pdf_user_space", "canonical_pdf_point", "unknown"]


class _LocalEvidenceModel(SdkModel):
    """Revalidate nested public evidence, including copied/constructed models."""

    model_config = ConfigDict(revalidate_instances="always")


class PdfEvidenceBox(_LocalEvidenceModel):
    """Ordered finite rectangle; zero extent remains explicit evidence."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)
    x0: FiniteFloat
    y0: FiniteFloat
    x1: FiniteFloat
    y1: FiniteFloat

    @model_validator(mode="after")
    def validate_order(self) -> PdfEvidenceBox:
        """Reject reversed bounds without manufacturing a positive extent."""
        if self.x0 > self.x1 or self.y0 > self.y1:
            message = "PDF evidence box coordinates must be ordered"
            raise ValueError(message)
        return self


class PdfLocalTextEvidence(_LocalEvidenceModel):
    """Text and effective visual geometry in top-left PDF points."""

    fact_id: str = Field(pattern=r"^PDFF-[0-9a-f]{24}$")
    source_order: int = Field(ge=0)
    text: str = Field(min_length=1, max_length=1_000_000)
    bbox: PdfEvidenceBox
    font_name: str | None = Field(max_length=256)
    nominal_font_size_points: FiniteFloat | None = Field(ge=0)
    parser_font_size: FiniteFloat | None = Field(ge=0)
    parser_font_size_semantics: _ScalarSemantics
    parser_font_size_unit: _ScalarUnit
    effective_font_size_x: FiniteFloat | None = Field(ge=0)
    effective_font_size_y: FiniteFloat | None = Field(ge=0)
    effective_font_scale_x: FiniteFloat | None = Field(ge=0)
    effective_font_scale_y: FiniteFloat | None = Field(ge=0)
    parser_text_matrix: (
        tuple[
            FiniteFloat, FiniteFloat, FiniteFloat, FiniteFloat, FiniteFloat, FiniteFloat
        ]
        | None
    )
    rotation: FiniteFloat | None = Field(ge=0, lt=360)
    writing_direction: Literal[
        "left_to_right", "right_to_left", "top_to_bottom", "bottom_to_top", "unknown"
    ]
    warnings: tuple[str, ...]

    @model_validator(mode="after")
    def validate_scalar_evidence(self) -> PdfLocalTextEvidence:
        """Preserve the existing Facts scalar availability and paired axes."""
        if (
            (self.effective_font_size_x is None) != (self.effective_font_size_y is None)
            or (self.effective_font_scale_x is None)
            != (self.effective_font_scale_y is None)
            or (
                self.effective_font_size_x is not None
                and self.nominal_font_size_points is None
            )
            or (
                (self.parser_font_size_semantics == "unavailable")
                != (self.parser_font_size is None)
            )
        ):
            message = "PDF text scalar evidence is inconsistent"
            raise ValueError(message)
        return self


class PdfLocalPathSegment(_LocalEvidenceModel):
    """One retained path segment in top-left PDF points."""

    segment_index: int = Field(ge=0)
    subpath_index: int = Field(ge=0)
    kind: Literal["move", "line", "cubic_bezier", "quadratic_or_unknown_curve", "close"]
    start: tuple[FiniteFloat, FiniteFloat]
    end: tuple[FiniteFloat, FiniteFloat]
    control_points: tuple[tuple[FiniteFloat, FiniteFloat], ...] = Field(max_length=2)
    closed: bool
    geometry_quality: Literal["precise", "approximate", "unknown"]
    warnings: tuple[str, ...]

    @model_validator(mode="after")
    def validate_controls(self) -> PdfLocalPathSegment:
        """Bind control point cardinality to the segment kind."""
        cubic_control_count = 2
        if (
            self.kind == "cubic_bezier"
            and len(self.control_points) != cubic_control_count
        ) or (self.kind in {"move", "line", "close"} and self.control_points):
            message = "PDF path control point count is invalid"
            raise ValueError(message)
        return self


class PdfLocalDrawingEvidence(_LocalEvidenceModel):
    """Retained drawing geometry; nominal widths can remain unknown."""

    fact_id: str = Field(pattern=r"^PDFF-[0-9a-f]{24}$")
    source_order: int = Field(ge=0)
    kind: Literal["line", "rectangle", "curve"]
    bbox: PdfEvidenceBox
    paint_operation: Literal["stroke", "fill", "fill_stroke", "clip", "unknown"]
    bbox_kind: Literal[
        "path_geometry", "parser_object_bounds", "painted_bounds", "unknown"
    ]
    bbox_quality: Literal["precise", "approximate", "unknown"]
    stroke_inclusion: Literal["included", "excluded", "unknown"]
    clipping_application: Literal["applied", "not_applied", "unknown"]
    is_clipping_path: bool
    nominal_stroke_width_points: FiniteFloat | None = Field(ge=0)
    parser_stroke_width: FiniteFloat | None = Field(ge=0)
    parser_stroke_width_semantics: _ScalarSemantics
    parser_stroke_width_unit: _ScalarUnit
    effective_stroke_width_x: FiniteFloat | None = Field(ge=0)
    effective_stroke_width_y: FiniteFloat | None = Field(ge=0)
    path_segments: tuple[PdfLocalPathSegment, ...]
    path_segment_count: int = Field(ge=0)
    path_segment_count_is_lower_bound: bool
    path_segment_truncated: bool
    path_geometry_complete: bool
    warnings: tuple[str, ...]

    @model_validator(mode="after")
    def validate_inventory(self) -> PdfLocalDrawingEvidence:
        """Keep incomplete geometry and retained segment counts explicit."""
        if (
            (self.effective_stroke_width_x is None)
            != (self.effective_stroke_width_y is None)
            or (
                self.effective_stroke_width_x is not None
                and self.nominal_stroke_width_points is None
            )
            or (
                (self.parser_stroke_width_semantics == "unavailable")
                != (self.parser_stroke_width is None)
            )
        ):
            message = "PDF drawing scalar evidence is inconsistent"
            raise ValueError(message)
        retained = len(self.path_segments)
        indexes = tuple(s.segment_index for s in self.path_segments)
        if (
            retained > self.path_segment_count
            or (
                self.path_geometry_complete
                and (self.path_segment_truncated or retained != self.path_segment_count)
            )
            or indexes != tuple(sorted(set(indexes)))
            or (
                self.path_segment_count_is_lower_bound
                and not self.path_segment_truncated
            )
            or (self.path_segment_truncated and retained >= self.path_segment_count)
        ):
            message = "PDF drawing path inventory is inconsistent"
            raise ValueError(message)
        return self


class PdfLocalImageEvidence(_LocalEvidenceModel):
    """A parser-observed image placement, without image bytes or OCR."""

    fact_id: str = Field(pattern=r"^PDFF-[0-9a-f]{24}$")
    source_order: int = Field(ge=0)
    bbox: PdfEvidenceBox
    pixel_width: int | None = Field(ge=1)
    pixel_height: int | None = Field(ge=1)
    image_type: str | None = Field(max_length=64)
    parser_available: bool
    warnings: tuple[str, ...]


class PdfLocalPageEvidence(_LocalEvidenceModel):
    """One source page's retained observations and resolved page geometry.

    Page boxes are unrotated, bottom-left coordinates with UserUnit applied
    once. Content boxes and path points use rotated top-left effective-page
    coordinates. Resolved CropBox/UserUnit defaults do not prove the original
    dictionary explicitly declared them. Text arrays are alternative layers,
    not distinct content to concatenate or count twice.
    """

    page_number: int = Field(ge=1)
    width_points: FiniteFloat = Field(gt=0)
    height_points: FiniteFloat = Field(gt=0)
    rotation: Literal[0, 90, 180, 270]
    media_box_points: PdfEvidenceBox
    crop_box_points: PdfEvidenceBox
    effective_page_box_points: PdfEvidenceBox
    user_unit: FiniteFloat = Field(ge=1, le=75_000)
    extraction_status: _ExtractionStatus
    text_spans: tuple[PdfLocalTextEvidence, ...]
    words: tuple[PdfLocalTextEvidence, ...]
    drawings: tuple[PdfLocalDrawingEvidence, ...]
    images: tuple[PdfLocalImageEvidence, ...]
    warnings: tuple[str, ...]

    @model_validator(mode="after")
    def validate_page_geometry(self) -> PdfLocalPageEvidence:
        """Retain source Facts geometry and inventory constraints unchanged."""
        tolerance = 1e-6
        effective = self.effective_page_box_points
        for box in (self.media_box_points, self.crop_box_points, effective):
            if box.x0 >= box.x1 or box.y0 >= box.y1:
                message = "PDF evidence page box must have positive extent"
                raise ValueError(message)
            if (
                effective.x0 < box.x0 - tolerance
                or effective.y0 < box.y0 - tolerance
                or effective.x1 > box.x1 + tolerance
                or effective.y1 > box.y1 + tolerance
            ):
                message = "PDF evidence effective page box exceeds source boxes"
                raise ValueError(message)
        width, height = effective.x1 - effective.x0, effective.y1 - effective.y0
        if self.rotation in (90, 270):
            width, height = height, width
        if not math.isclose(
            self.width_points, width, abs_tol=tolerance
        ) or not math.isclose(self.height_points, height, abs_tol=tolerance):
            message = "PDF evidence dimensions do not match page rotation"
            raise ValueError(message)
        identities: set[str] = set()
        facts = chain[
            PdfLocalTextEvidence | PdfLocalDrawingEvidence | PdfLocalImageEvidence
        ](self.text_spans, self.words, self.drawings, self.images)
        for fact in facts:
            if fact.fact_id in identities:
                message = "PDF local evidence repeats a fact identity"
                raise ValueError(message)
            identities.add(fact.fact_id)
            if (
                fact.bbox.x0 < -tolerance
                or fact.bbox.y0 < -tolerance
                or fact.bbox.x1 > self.width_points + tolerance
                or fact.bbox.y1 > self.height_points + tolerance
            ):
                message = "PDF local fact bounds exceed the page"
                raise ValueError(message)
        return self


class PdfLocalEvidence(_LocalEvidenceModel):
    """Source-bound normalized observations from the existing bounded Facts run."""

    schema_version: Literal["document_sdk.pdf.local_evidence.v1"] = (
        "document_sdk.pdf.local_evidence.v1"
    )
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    extraction_status: _ExtractionStatus
    source_page_count: int = Field(ge=0)
    pages: tuple[PdfLocalPageEvidence, ...]
    warnings: tuple[str, ...]

    @model_validator(mode="after")
    def validate_source_pages(self) -> PdfLocalEvidence:
        """Bind every retained page to a unique source page number."""
        numbers = tuple(p.page_number for p in self.pages)
        if numbers != tuple(sorted(set(numbers))) or any(
            number > self.source_page_count for number in numbers
        ):
            message = "PDF local evidence page inventory is invalid"
            raise ValueError(message)
        return self


def _box(value: PdfBoundingBox | PdfPageBox) -> PdfEvidenceBox:
    return PdfEvidenceBox(x0=value.x0, y0=value.y0, x1=value.x1, y1=value.y1)


def _text(value: PdfTextFact) -> PdfLocalTextEvidence:
    scalar = value.font_size_provenance
    matrix = value.text_transform
    return PdfLocalTextEvidence(
        fact_id=value.fact_id,
        source_order=value.source_order,
        text=value.text,
        bbox=_box(value.bbox),
        font_name=value.font_name,
        nominal_font_size_points=value.font_size,
        parser_font_size=scalar.parser_native_value,
        parser_font_size_semantics=scalar.parser_native_semantics,
        parser_font_size_unit=scalar.parser_native_unit,
        effective_font_size_x=value.effective_font_size_x,
        effective_font_size_y=value.effective_font_size_y,
        effective_font_scale_x=value.effective_font_scale_x,
        effective_font_scale_y=value.effective_font_scale_y,
        parser_text_matrix=(
            (matrix.a, matrix.b, matrix.c, matrix.d, matrix.e, matrix.f)
            if matrix is not None
            else None
        ),
        rotation=value.rotation,
        writing_direction=value.writing_direction,
        warnings=tuple(w.code.value for w in value.warnings),
    )


def _drawing(value: PdfDrawingFact) -> PdfLocalDrawingEvidence:
    scalar = value.stroke_width_provenance
    return PdfLocalDrawingEvidence(
        fact_id=value.fact_id,
        source_order=value.source_order,
        kind=value.kind,
        bbox=_box(value.bbox),
        paint_operation=value.paint_operation,
        bbox_kind=value.bbox_semantics.kind,
        bbox_quality=value.bbox_semantics.quality,
        stroke_inclusion=value.bbox_semantics.stroke_inclusion,
        clipping_application=value.bbox_semantics.clipping_application,
        is_clipping_path=value.is_clipping_path,
        nominal_stroke_width_points=value.stroke_width,
        parser_stroke_width=scalar.parser_native_value,
        parser_stroke_width_semantics=scalar.parser_native_semantics,
        parser_stroke_width_unit=scalar.parser_native_unit,
        effective_stroke_width_x=value.effective_stroke_width_x,
        effective_stroke_width_y=value.effective_stroke_width_y,
        path_segments=tuple(
            PdfLocalPathSegment(
                segment_index=s.segment_index,
                subpath_index=s.subpath_index,
                kind=s.kind,
                start=(s.start.x, s.start.y),
                end=(s.end.x, s.end.y),
                control_points=tuple((p.x, p.y) for p in s.control_points),
                closed=s.closed,
                geometry_quality=s.geometry_quality,
                warnings=tuple(w.code.value for w in s.warnings),
            )
            for s in value.path_segments
        ),
        path_segment_count=value.path_segment_count,
        path_segment_count_is_lower_bound=value.path_segment_count_is_lower_bound,
        path_segment_truncated=value.path_segment_truncated,
        path_geometry_complete=value.path_geometry_complete,
        warnings=tuple(w.code.value for w in value.warnings),
    )


def _project_local_evidence(facts: PdfFactArtifact) -> PdfLocalEvidence:
    """Copy reviewed SDK fields without reopening or reparsing the PDF."""
    return PdfLocalEvidence(
        source_sha256=facts.source_sha256,
        extraction_status=facts.extraction_status.value,
        source_page_count=facts.page_count,
        pages=tuple(
            PdfLocalPageEvidence(
                page_number=p.page_number,
                width_points=p.canonical_width,
                height_points=p.canonical_height,
                rotation=p.rotation,
                media_box_points=_box(p.media_box),
                crop_box_points=_box(p.crop_box),
                effective_page_box_points=_box(p.effective_page_box),
                user_unit=p.user_unit,
                extraction_status=p.extraction_status.value,
                text_spans=tuple(_text(t) for t in p.text_spans),
                words=tuple(_text(t) for t in p.words),
                drawings=tuple(_drawing(d) for d in p.drawings),
                images=tuple(
                    PdfLocalImageEvidence(
                        fact_id=i.fact_id,
                        source_order=i.source_order,
                        bbox=_box(i.bbox),
                        pixel_width=i.pixel_width,
                        pixel_height=i.pixel_height,
                        image_type=i.image_type,
                        parser_available=i.parser_available,
                        warnings=tuple(w.code.value for w in i.warnings),
                    )
                    for i in p.image_regions
                ),
                warnings=tuple(w.code.value for w in p.warnings),
            )
            for p in facts.pages
        ),
        warnings=tuple(w.code.value for w in facts.warnings),
    )

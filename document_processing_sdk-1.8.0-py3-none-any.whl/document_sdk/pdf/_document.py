"""Private PDF document lifetime and error-boundary helpers."""

from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, Literal, cast

from document_sdk.core import (
    DocumentProcessingError,
    DocumentSdkError,
    EncryptedDocumentError,
    FileDescriptor,
    UnsupportedFileError,
)
from document_sdk.core.errors import (
    DocumentSourceChangedError,
    _raise_redacted_translation,
    safe_file_label,
)
from document_sdk.files import inspect_file
from document_sdk.files._source_identity import verify_open_binary
from document_sdk.pdf._dependencies import require_pdf_support
from document_sdk.pdf.errors import PdfLimitExceededError

if TYPE_CHECKING:
    from collections.abc import Iterator
    from pathlib import Path

    from pypdfium2 import PdfDocument, PdfPage

    from document_sdk.pdf.models import PdfProcessingLimits


@dataclass(frozen=True)
class PdfPagePreflight:
    """Safe non-rendered geometry for one one-based page."""

    page_number: int
    width_points: float
    height_points: float
    rotation: Literal[0, 90, 180, 270]

    @property
    def rendered_width_points(self) -> float:
        """Return displayed width after page rotation."""
        if self.rotation in {90, 270}:
            return self.height_points
        return self.width_points

    @property
    def rendered_height_points(self) -> float:
        """Return displayed height after page rotation."""
        if self.rotation in {90, 270}:
            return self.width_points
        return self.height_points


@dataclass(frozen=True)
class PdfDocumentPreflight:
    """Bounded page count and geometry collected before deep processing."""

    pages: tuple[PdfPagePreflight, ...]
    encrypted: bool = False

    @property
    def page_count(self) -> int:
        """Return the safely preflighted page count."""
        return len(self.pages)


def enforce_pdf_limit(
    limit_name: str,
    observed: float,
    maximum: float,
) -> None:
    """Raise a safe structured PDF processing-limit error."""
    if observed > maximum:
        raise PdfLimitExceededError(
            limit_name=limit_name,
            observed=observed,
            maximum=maximum,
        )


def _encrypted_pdf_access_message(
    *,
    password_supplied: bool,
    password_supported: bool = True,
) -> str:
    """Describe denied local access without accepting or rendering a password."""
    if not password_supported:
        return "Encrypted PDF is not supported by this operation"
    if password_supplied:
        return "Encrypted PDF password is invalid or access is unavailable"
    return "Encrypted PDF requires an explicit password"


def enforce_native_text_page_limit(
    page_count: int,
    limits: PdfProcessingLimits,
) -> None:
    """Reject whole-document native text work beyond its page budget."""
    enforce_pdf_limit(
        "native text pages",
        page_count,
        limits.max_native_text_pages,
    )


def _rotation(value: int) -> Literal[0, 90, 180, 270]:
    """Normalize a PDFium rotation to the SDK's supported values."""
    normalized = value % 360
    if normalized not in {0, 90, 180, 270}:
        normalized = 0
    return cast("Literal[0, 90, 180, 270]", normalized)


def _original_page_size(page: PdfPage) -> tuple[float, float]:
    """Return unrotated MediaBox dimensions, falling back to displayed size."""
    media_box = page.get_mediabox(fallback_ok=True)
    if media_box is not None:
        left, bottom, right, top = media_box
        width = abs(right - left)
        height = abs(top - bottom)
        if width > 0 and height > 0:
            return width, height
    width, height = page.get_size()
    return float(width), float(height)


def inspect_pdf_input(
    path: Path,
    limits: PdfProcessingLimits,
) -> FileDescriptor:
    """Inspect a local input and enforce the PDF adapter's format boundary."""
    descriptor = inspect_file(path)
    if descriptor.extension != ".pdf":
        msg = "PDF APIs require a .pdf file"
        raise UnsupportedFileError(msg)
    enforce_pdf_limit(
        "file bytes",
        descriptor.size_bytes,
        limits.max_file_bytes,
    )
    return descriptor


def preflight_pdf_structure(
    path: Path,
    limits: PdfProcessingLimits,
    *,
    expected_identity: tuple[str, int] | None = None,
) -> tuple[FileDescriptor, PdfDocumentPreflight]:
    """Validate one PDF and return bounded structure without reading page text."""
    descriptor = inspect_pdf_input(path, limits)
    if (
        expected_identity is not None
        and (
            descriptor.fingerprint.value,
            descriptor.size_bytes,
        )
        != expected_identity
    ):
        msg = "PDF source changed before preflight"
        raise DocumentSourceChangedError(msg)
    with (
        translate_pdf_errors(path, "preflight"),
        open_pdf(path, descriptor, limits) as (_pdf, preflight),
    ):
        return descriptor, preflight


@contextmanager
def translate_pdf_errors(path: Path, operation: str) -> Iterator[None]:
    """Translate backend failures without retaining sensitive cause messages."""
    try:
        yield
    except DocumentSdkError:
        raise
    except Exception as exc:  # noqa: BLE001 - adapter boundary normalizes backends.
        msg = f"Unable to {operation} PDF: {safe_file_label(path)}"
        _raise_redacted_translation(exc, DocumentProcessingError(msg))


def _preflight_document(
    pdf: PdfDocument,
    limits: PdfProcessingLimits,
) -> PdfDocumentPreflight:
    """Bound page count and every page geometry without rendering."""
    page_count = len(pdf)
    enforce_pdf_limit("page count", page_count, limits.max_pages)
    facts: list[PdfPagePreflight] = []
    for page_index in range(page_count):
        page = pdf[page_index]
        try:
            width, height = _original_page_size(page)
            area = width * height
            enforce_pdf_limit(
                "page width points",
                width,
                limits.max_page_width_points,
            )
            enforce_pdf_limit(
                "page height points",
                height,
                limits.max_page_height_points,
            )
            enforce_pdf_limit(
                "page area points",
                area,
                limits.max_page_area_points,
            )
            facts.append(
                PdfPagePreflight(
                    page_number=page_index + 1,
                    width_points=width,
                    height_points=height,
                    rotation=_rotation(page.get_rotation()),
                )
            )
        finally:
            page.close()
    return PdfDocumentPreflight(pages=tuple(facts))


@contextmanager
def open_pdf(
    path: Path,
    descriptor: FileDescriptor,
    limits: PdfProcessingLimits,
    *,
    password: str | None = None,
    password_supported: bool = False,
) -> Iterator[tuple[PdfDocument, PdfDocumentPreflight]]:
    """Open, identity-check, preflight, and close one exact PDF stream."""
    require_pdf_support()
    import pypdfium2 as pdfium
    import pypdfium2.raw as pdfium_c

    with path.open("rb") as stream:
        verify_open_binary(
            stream,
            expected_fingerprint=descriptor.fingerprint.value,
            expected_size=descriptor.size_bytes,
            mismatch_message="PDF changed after inspection",
        )
        try:
            pdf = pdfium.PdfDocument(stream, autoclose=False, password=password)
        except pdfium.PdfiumError as exc:
            if exc.err_code in {
                pdfium_c.FPDF_ERR_PASSWORD,
                pdfium_c.FPDF_ERR_SECURITY,
            }:
                msg = (
                    _encrypted_pdf_access_message(
                        password_supplied=password is not None,
                        password_supported=password_supported,
                    )
                    + f": {safe_file_label(path)}"
                )
                _raise_redacted_translation(exc, EncryptedDocumentError(msg))
            msg = f"Unable to open PDF: {safe_file_label(path)}"
            _raise_redacted_translation(exc, DocumentProcessingError(msg))

        try:
            encrypted = pdfium_c.FPDF_GetSecurityHandlerRevision(pdf.raw) != -1
            if encrypted and (not password_supported or password is None):
                msg = (
                    _encrypted_pdf_access_message(
                        password_supplied=password is not None,
                        password_supported=password_supported,
                    )
                    + f": {safe_file_label(path)}"
                )
                raise EncryptedDocumentError(msg)
            yield pdf, replace(_preflight_document(pdf, limits), encrypted=encrypted)
        finally:
            pdf.close()

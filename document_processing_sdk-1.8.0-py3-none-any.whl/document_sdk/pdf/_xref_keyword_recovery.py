"""Recover a single malformed classic-xref keyword from explicit source offsets.

This deliberately narrow recovery never searches for Info keys or object bodies.
The terminal startxref, complete xref rows, trailer references, and referenced
dictionary boundaries must all agree before a same-length in-memory repair.
"""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from io import BytesIO
from typing import TYPE_CHECKING

from document_sdk.core.errors import _raise_redacted_translation

if TYPE_CHECKING:
    from collections.abc import Callable
    from typing import Never

    from pypdf import PdfReader
    from pypdf.generic import DictionaryObject

_MAX_SOURCE_BYTES = 32 * 1_048_576
_MAX_XREF_ENTRIES = 20_000
_MAX_LINE_BYTES = 128
_TERMINAL_SEARCH_BYTES = 8192
_KEYWORD_LENGTH = 4
_XREF_OFFSET_DIGITS = 10
_XREF_GENERATION_DIGITS = 5
_PDF_HEADER_LENGTH = 8
_MAX_OBJECT_HEADER_BYTES = 64
_REFERENCE_PARTS = 3
_PAIR_LENGTH = 2
_MAX_GENERATION = 65535
_TRAILER_KEYS = frozenset((b"/Size", b"/Root", b"/Info"))


def _trailer_layout(source: bytes, start: int) -> None:
    """Check a finite bare trailer before a backend can follow history links."""
    terminal = source.rfind(
        b"startxref", max(start, len(source) - _TERMINAL_SEARCH_BYTES)
    )
    tokens = source[start:terminal].split()
    if not tokens or tokens[0] != b"<<" or tokens[-1] != b">>":
        _reject("PDF_XREF_RECOVERY_TRAILER_INVALID")
    seen: set[bytes] = set()
    index = 1
    while index < len(tokens) - 1:
        key = tokens[index]
        if key not in _TRAILER_KEYS:
            _reject("PDF_XREF_RECOVERY_TRAILER_UNSUPPORTED")
        if key in seen:
            _reject("PDF_XREF_RECOVERY_TRAILER_CONFLICT")
        seen.add(key)
        width = 1 if key == b"/Size" else _REFERENCE_PARTS
        value = tokens[index + 1 : index + 1 + width]
        if len(value) != width or not value[0].isdigit():
            _reject("PDF_XREF_RECOVERY_TRAILER_INVALID")
        if width == _REFERENCE_PARTS and (not value[1].isdigit() or value[2] != b"R"):
            _reject("PDF_XREF_RECOVERY_TRAILER_INVALID")
        index += 1 + width
    if seen != _TRAILER_KEYS:
        _reject("PDF_XREF_RECOVERY_REFERENCE_MISSING")


class XrefKeywordRecoveryError(ValueError):
    """The source does not provide a unique complete classic-xref recovery."""


@dataclass(frozen=True)
class PdfXrefRecoveryReceipt:
    """Bind the exact original bytes to a verified in-memory keyword repair."""

    original_sha256: str
    recovered_sha256: str
    keyword_offset: int
    original_keyword_hex: str
    root_object_number: int
    root_generation: int
    info_object_number: int
    info_generation: int
    entry_count: int
    method: str = "TERMINAL_STARTXREF_SINGLE_CLASSIC_TABLE_KEYWORD_REPAIR_V1"


@dataclass(frozen=True)
class _XrefEntry:
    offset: int
    generation: int
    in_use: bool


def _reject(reason: str) -> Never:
    raise XrefKeywordRecoveryError(reason)


def _terminal_offset(source: bytes) -> int:
    if len(source) > _MAX_SOURCE_BYTES:
        _reject("PDF_XREF_RECOVERY_SOURCE_LIMIT")
    terminal = source[-_TERMINAL_SEARCH_BYTES:].rsplit(b"startxref", 1)
    if len(terminal) != _PAIR_LENGTH:
        _reject("PDF_XREF_RECOVERY_TERMINAL_MISSING")
    lines = terminal[1].strip().splitlines()
    if len(lines) != _PAIR_LENGTH or not lines[0].isdigit() or lines[1] != b"%%EOF":
        _reject("PDF_XREF_RECOVERY_TERMINAL_INVALID")
    offset = int(lines[0])
    keyword = source[offset : offset + _KEYWORD_LENGTH]
    if (
        offset < _PDF_HEADER_LENGTH
        or len(keyword) != _KEYWORD_LENGTH
        or keyword == b"xref"
        or keyword[:1] != b"x"
        or source[offset + _KEYWORD_LENGTH : offset + _KEYWORD_LENGTH + 1]
        not in (b"\r", b"\n")
    ):
        _reject("PDF_XREF_RECOVERY_KEYWORD_UNSUPPORTED")
    return offset


def _line(stream: BytesIO) -> bytes:
    line = stream.readline(_MAX_LINE_BYTES)
    if not line or len(line) >= _MAX_LINE_BYTES:
        _reject("PDF_XREF_RECOVERY_TABLE_TRUNCATED_OR_LIMITED")
    return line.strip()


def _entry(
    source: bytes,
    line: bytes,
    number: int,
    xref_offset: int,
    charge_object: Callable[[], None] | None = None,
) -> _XrefEntry:
    values = line.split()
    if (
        len(values) != _REFERENCE_PARTS
        or len(values[0]) != _XREF_OFFSET_DIGITS
        or len(values[1]) != _XREF_GENERATION_DIGITS
        or not values[0].isdigit()
        or not values[1].isdigit()
        or values[2] not in (b"n", b"f")
    ):
        _reject("PDF_XREF_RECOVERY_ENTRY_INVALID")
    offset, generation = int(values[0]), int(values[1])
    if generation > _MAX_GENERATION:
        _reject("PDF_XREF_RECOVERY_GENERATION_INVALID")
    in_use = values[2] == b"n"
    if in_use:
        if charge_object is not None:
            charge_object()
        header = source[offset : offset + _MAX_OBJECT_HEADER_BYTES].split(
            maxsplit=_REFERENCE_PARTS
        )
        expected = [str(number).encode(), str(generation).encode(), b"obj"]
        if (
            offset < _PDF_HEADER_LENGTH
            or offset >= xref_offset
            or header[:3] != expected
        ):
            _reject("PDF_XREF_RECOVERY_OBJECT_BINDING_INVALID")
    return _XrefEntry(offset, generation, in_use)


def _entries(
    source: bytes, offset: int, charge_object: Callable[[], None] | None = None
) -> tuple[_XrefEntry, ...]:
    stream = BytesIO(source)
    stream.seek(offset)
    _line(stream)
    subsection = _line(stream).split()
    if (
        len(subsection) != _PAIR_LENGTH
        or subsection[0] != b"0"
        or not subsection[1].isdigit()
    ):
        _reject("PDF_XREF_RECOVERY_SUBSECTION_UNSUPPORTED")
    count = int(subsection[1])
    if not 1 < count <= _MAX_XREF_ENTRIES:
        _reject("PDF_XREF_RECOVERY_ENTRY_LIMIT")
    entries = tuple(
        _entry(source, _line(stream), number, offset, charge_object)
        for number in range(count)
    )
    if (
        entries[0].in_use
        or entries[0].generation != _MAX_GENERATION
        or _line(stream) != b"trailer"
    ):
        _reject("PDF_XREF_RECOVERY_TABLE_INCOMPLETE")
    _trailer_layout(source, stream.tell())
    return entries


def _dictionary_at(
    reader: PdfReader, entry: _XrefEntry, object_number: int
) -> DictionaryObject:
    from pypdf._utils import read_non_whitespace
    from pypdf.generic import DictionaryObject, read_object

    stream = reader.stream
    stream.seek(entry.offset)
    if reader.read_object_header(stream) != (object_number, entry.generation):
        _reject("PDF_XREF_RECOVERY_REFERENCE_HEADER_INVALID")
    value = read_object(stream, reader)
    if not isinstance(value, DictionaryObject):
        _reject("PDF_XREF_RECOVERY_REFERENCE_NOT_DICTIONARY")
    first = read_non_whitespace(stream)
    if first + stream.read(5) != b"endobj":
        _reject("PDF_XREF_RECOVERY_REFERENCE_TRUNCATED")
    return value


def _reference(
    reader: PdfReader, entries: tuple[_XrefEntry, ...], name: str
) -> tuple[int, int, DictionaryObject]:
    from pypdf.generic import IndirectObject

    if name not in reader.trailer:
        _reject("PDF_XREF_RECOVERY_REFERENCE_MISSING")
    reference = reader.trailer.raw_get(name)
    if (
        not isinstance(reference, IndirectObject)
        or not 0 < reference.idnum < len(entries)
        or not entries[reference.idnum].in_use
        or reference.generation != entries[reference.idnum].generation
    ):
        _reject("PDF_XREF_RECOVERY_REFERENCE_UNRESOLVED")
    value = _dictionary_at(reader, entries[reference.idnum], reference.idnum)
    return reference.idnum, reference.generation, value


def _validated_reader(
    recovered: bytes, entries: tuple[_XrefEntry, ...]
) -> tuple[PdfReader, int, int, int, int]:
    """Exclude backend auto-repair and redact strict dictionary parsing failures."""
    from pypdf import PdfReader
    from pypdf.errors import PdfReadError

    try:
        reader = PdfReader(BytesIO(recovered), strict=True)
        if (
            reader.is_encrypted
            or "/Prev" in reader.trailer
            or "/XRefStm" in reader.trailer
            or reader.trailer.get("/Size") != len(entries)
        ):
            _reject("PDF_XREF_RECOVERY_TRAILER_UNSUPPORTED")
        root_number, root_generation, root = _reference(reader, entries, "/Root")
        info_number, info_generation, _ = _reference(reader, entries, "/Info")
        if root.get("/Type") != "/Catalog" or root_number == info_number:
            _reject("PDF_XREF_RECOVERY_ROOT_INVALID")
    except PdfReadError as error:
        message = "PDF_XREF_RECOVERY_STRICT_VALIDATION_FAILED"
        _raise_redacted_translation(error, XrefKeywordRecoveryError(message))
    return reader, root_number, root_generation, info_number, info_generation


def recover_classic_xref_keyword(
    source_bytes: bytes,
) -> tuple[PdfReader, PdfXrefRecoveryReceipt]:
    """Return a strict reader only for one independently bound classic xref.

    Only a bare Size/Root/Info trailer is supported. Multi-revision/hybrid tables,
    encrypted dictionaries, missing or conflicting references, and incomplete
    dictionaries are outside this recovery contract.
    The caller retains original source bytes and original content identity.
    """
    offset = _terminal_offset(source_bytes)
    entries = _entries(source_bytes, offset)
    recovered = (
        source_bytes[:offset] + b"xref" + source_bytes[offset + _KEYWORD_LENGTH :]
    )
    reader, root_number, root_generation, info_number, info_generation = (
        _validated_reader(recovered, entries)
    )
    return reader, PdfXrefRecoveryReceipt(
        original_sha256=sha256(source_bytes).hexdigest(),
        recovered_sha256=sha256(recovered).hexdigest(),
        keyword_offset=offset,
        original_keyword_hex=source_bytes[offset : offset + _KEYWORD_LENGTH].hex(),
        root_object_number=root_number,
        root_generation=root_generation,
        info_object_number=info_number,
        info_generation=info_generation,
        entry_count=len(entries),
    )


def recover_truncated_classic_trailer(
    source_bytes: bytes,
    *,
    charge_object: Callable[[], None] | None = None,
) -> tuple[PdfReader, PdfXrefRecoveryReceipt]:
    """Open a complete original table with only its bare trailer tail missing.

    The appended dictionary closer and terminal locator are a parser view, never
    original history. Every in-use object must be a complete, disjoint dictionary
    or stream at its original declared offset. Unsupported trailers and ambiguous
    table candidates remain rejected by the existing strict recovery checks.
    """
    from pypdf.errors import PdfReadError

    if len(source_bytes) > _MAX_SOURCE_BYTES:
        _reject("PDF_XREF_RECOVERY_SOURCE_LIMIT")
    marker = b"\nxref\n"
    offset = source_bytes.rfind(marker) + 1
    if (
        offset <= _PDF_HEADER_LENGTH
        or source_bytes.count(marker) != 1
        or b"startxref" in source_bytes[offset:]
        or b"%%EOF" in source_bytes[offset:]
        or b">>" in source_bytes[source_bytes.rfind(b"\ntrailer\n") + 9 :]
    ):
        _reject("PDF_XREF_RECOVERY_TRUNCATED_PATTERN_UNSUPPORTED")
    recovered = source_bytes + b">>\nstartxref\n" + str(offset).encode() + b"\n%%EOF\n"
    # Charge each distinct in-use object before header checks and decoding.
    # Root/Info and the boundary pass revisit those same reserved objects.
    entries = _entries(recovered, offset, charge_object)
    try:
        reader, root_number, root_generation, info_number, info_generation = (
            _validated_reader(recovered, entries)
        )
        occupied = sorted(
            (entry.offset, number, entry)
            for number, entry in enumerate(entries)
            if entry.in_use
        )
        for index, (start, number, entry) in enumerate(occupied):
            bound = occupied[index + 1][0] if index + 1 < len(occupied) else offset
            _dictionary_at(reader, entry, number)
            if not start < reader.stream.tell() <= bound:
                _reject("PDF_XREF_RECOVERY_OBJECT_BOUNDARY_CONFLICT")
    except (PdfReadError, ValueError, TypeError, KeyError, OverflowError) as error:
        message = "PDF_XREF_RECOVERY_STRICT_VALIDATION_FAILED"
        _raise_redacted_translation(error, XrefKeywordRecoveryError(message))
    return reader, PdfXrefRecoveryReceipt(
        original_sha256=sha256(source_bytes).hexdigest(),
        recovered_sha256=sha256(recovered).hexdigest(),
        keyword_offset=offset,
        original_keyword_hex=b"xref".hex(),
        root_object_number=root_number,
        root_generation=root_generation,
        info_object_number=info_number,
        info_generation=info_generation,
        entry_count=len(entries),
        method="ORIGINAL_CLASSIC_XREF_TRUNCATED_TRAILER_PARSER_VIEW_V1",
    )


def verified_parser_view(source_bytes: bytes) -> bytes:
    """Retain normal bytes; expose only a strictly verified truncated-tail view."""
    if source_bytes.rstrip().endswith(b"%%EOF"):
        return source_bytes
    try:
        reader, _receipt = recover_truncated_classic_trailer(source_bytes)
    except XrefKeywordRecoveryError:
        return source_bytes
    reader.stream.seek(0)
    return reader.stream.read()


def recover_source_reader(
    source_bytes: bytes,
) -> tuple[PdfReader, PdfXrefRecoveryReceipt]:
    """Choose between the two existing-source-bound, explicitly named repairs."""
    if source_bytes.rstrip().endswith(b"%%EOF"):
        return recover_classic_xref_keyword(source_bytes)
    return recover_truncated_classic_trailer(source_bytes)

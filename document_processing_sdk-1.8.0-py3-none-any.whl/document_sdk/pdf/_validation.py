"""Private public-model validation boundary for local PDF operations."""

from __future__ import annotations

from pydantic import BaseModel

from document_sdk.core import DocumentProcessingError
from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.pdf.models import PdfProcessingLimits


def _validate_pdf_password(password: str | None) -> None:
    """Validate a runtime-only password without retaining or rendering it."""
    if password is not None and (type(password) is not str or "\x00" in password):
        message = "PDF password must be a string without null characters"
        raise DocumentProcessingError(message)


def _validated_pdf_model[ModelT: BaseModel](
    value: BaseModel,
    expected_type: type[ModelT],
    message: str,
) -> ModelT:
    """Revalidate one public PDF model without invoking instance hooks."""
    try:
        return _revalidate_model_instance_json(value, expected_type, message)
    except Exception as exc:  # noqa: BLE001 - public model boundary is redacted.
        _raise_redacted_translation(exc, DocumentProcessingError(message))


def _validated_pdf_limits(
    limits: PdfProcessingLimits | None,
) -> PdfProcessingLimits:
    """Return trusted PDF limits before dependencies, files, or rendering."""
    if limits is None:
        return PdfProcessingLimits()
    message = "PDF processing limits are invalid"
    return _validated_pdf_model(limits, PdfProcessingLimits, message)

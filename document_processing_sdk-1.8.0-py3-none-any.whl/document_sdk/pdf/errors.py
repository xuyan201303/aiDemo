"""Caller-visible PDF resource-limit errors."""

from __future__ import annotations

from document_sdk.core import DocumentSdkError


class PdfLimitExceededError(DocumentSdkError):
    """Raised before PDF processing would exceed a configured limit."""

    def __init__(
        self,
        *,
        limit_name: str,
        observed: float,
        maximum: float,
    ) -> None:
        """Create a safe structured PDF limit failure."""
        self.limit_name = limit_name
        self.observed = observed
        self.maximum = maximum
        message = (
            f"PDF {limit_name} limit exceeded: observed {observed}, maximum {maximum}"
        )
        super().__init__(message)


class PdfRenderLimitExceededError(PdfLimitExceededError):
    """Raised before PDF rendering or encoding exceeds a configured limit."""

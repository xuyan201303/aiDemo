"""Versioned, bounded SDK-owned source-member and table-selection evidence.

V1 text objects remain unchanged. Native members are observations of parser
character extents, not guaranteed glyph ink. Each relation has explicit source
identity, projection and availability; truncation never creates a success label.
"""

from __future__ import annotations

import json
from collections import defaultdict
from collections.abc import Mapping
from dataclasses import dataclass, field
from math import ulp
from types import MappingProxyType
from typing import (
    TYPE_CHECKING,
    Annotated,
    Any,
    Literal,
    NoReturn,
    Self,
)

from pydantic import (
    Field,
    FiniteFloat,
    field_serializer,
    field_validator,
    model_validator,
)

from document_sdk.pdf._structural_engine.facts.coordinates import (
    pdfminer_native_origin_to_canonical,
)
from document_sdk.pdf._structural_engine.facts.native_text_contracts import (
    PdfNativeTextEventEvidence,
    PdfNativeTextShowEvent,
)
from document_sdk.pdf.local_evidence import (
    PdfEvidenceBox,
    PdfLocalEvidence,
    PdfLocalImageEvidence,
    PdfLocalPageEvidence,
    _box,
    _drawing,
    _ExtractionStatus,
    _LocalEvidenceModel,
    _project_local_evidence,
    _text,
)

if TYPE_CHECKING:
    from collections.abc import Iterable, Iterator

    from document_sdk.pdf._structural_engine.canonical.contracts import (
        CanonicalDocument,
    )
    from document_sdk.pdf._structural_engine.canonical.projection import (
        CanonicalArtifactBundle,
    )
    from document_sdk.pdf._structural_engine.facts.contracts import (
        PdfPageFacts,
        PdfTextMember,
        PdfTextSourceGroup,
    )


_OVERFLOW_MINIMUM_AXES = 3
_OVERFLOW_REPLAY_WORK_LIMIT = 100_000


_RECORD_FIELDS = (
    "text_members",
    "source_groups",
    "fact_memberships",
    "table_member_selections",
    "source_anchored_overflow_proofs",
    "cell_member_links",
)


def _size(value: object) -> int:
    return len(
        json.dumps(
            value,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    )


def _fail(message: str) -> NoReturn:
    raise ValueError(message)


class PdfLocalMemberProjection(_LocalEvidenceModel):
    """One exact source occurrence or explicit parser-inserted whitespace part."""

    member_id: str | None = Field(default=None, pattern=r"^PDFF-[0-9a-f]{24}$")
    output_start: int = Field(ge=0)
    output_end: int = Field(ge=0)
    transform: Literal[
        "IDENTITY", "LIGATURE_EXPANSION", "INSERTED_WHITESPACE", "OMITTED_WHITESPACE"
    ]

    @model_validator(mode="after")
    def validate_projection_part(self) -> PdfLocalMemberProjection:
        """Keep inserted output distinct from independently observed members."""
        if self.output_end < self.output_start:
            _fail("member projection interval is reversed")
        if (self.transform == "INSERTED_WHITESPACE") != (self.member_id is None):
            _fail("member projection source identity is inconsistent")
        if (
            self.transform == "OMITTED_WHITESPACE"
            and self.output_end != self.output_start
        ):
            _fail("omitted source whitespace cannot carry output")
        return self


class PdfLocalNativeTextShowEvent(PdfNativeTextShowEvent):
    """SDK-owned projection of one native text-show execution occurrence."""


class PdfLocalNativeTextEventEvidence(PdfNativeTextEventEvidence):
    """Public finite event inventory; never a backend object or decoded operands."""

    @field_validator("events", mode="before")
    @classmethod
    def project_local_events(cls, value: object) -> object:
        """Keep local event model identity across JSON roundtrips."""
        if isinstance(value, (list, tuple)):
            return tuple(
                item
                if isinstance(item, PdfLocalNativeTextShowEvent)
                else PdfLocalNativeTextShowEvent.model_validate(item)
                for item in value
            )
        return value


class PdfLocalTextMember(_LocalEvidenceModel):
    """One actual pre-deduplication parser character occurrence."""

    member_id: str = Field(pattern=r"^PDFF-[0-9a-f]{24}$")
    source_character_index: int = Field(ge=0)
    text: str = Field(min_length=1, max_length=1_000_000)
    parser_bbox: PdfEvidenceBox | None
    bbox: PdfEvidenceBox | None
    geometry_status: Literal["INSIDE", "INTERSECTS", "OUTSIDE", "ZERO_AREA", "INVALID"]
    geometry_semantics: Literal["pdfminer_character_extent_not_ink"]
    selection_state: Literal["RETAINED", "DEDUPE_SUPPRESSED", "GEOMETRY_REJECTED"]
    duplicate_of_member_id: str | None = Field(
        default=None, pattern=r"^PDFF-[0-9a-f]{24}$"
    )
    parser_text_matrix: (
        tuple[
            FiniteFloat, FiniteFloat, FiniteFloat, FiniteFloat, FiniteFloat, FiniteFloat
        ]
        | None
    )
    font_name: str | None = Field(max_length=256)
    parser_font_size: FiniteFloat | None = Field(ge=0)
    parser_advance: FiniteFloat | None = Field(default=None, ge=0, strict=True)
    source_writing_mode: Literal["HORIZONTAL", "VERTICAL", "UNKNOWN"] = "UNKNOWN"
    native_text_event_id: str | None = Field(
        default=None, pattern=r"^PDFTE-[0-9a-f]{64}$"
    )
    native_text_event_ordinal: int | None = Field(default=None, ge=0, strict=True)
    native_text_event_member_ordinal: int | None = Field(
        default=None, ge=0, strict=True
    )
    native_character_ordinal: int | None = Field(default=None, ge=0, strict=True)
    rotation: FiniteFloat | None = Field(ge=0, lt=360)
    warnings: tuple[str, ...]

    @model_validator(mode="after")
    def validate_geometry(self) -> PdfLocalTextMember:
        """Reject fabricated geometry or deduplication self-links."""
        native_refs = (
            self.native_text_event_ordinal,
            self.native_text_event_member_ordinal,
            self.native_character_ordinal,
        )
        if self.native_text_event_id is None:
            if (
                any(value is not None for value in native_refs)
                or self.source_writing_mode != "UNKNOWN"
            ):
                _fail("native source direction needs the observed event binding")
        elif any(value is None for value in native_refs):
            _fail("native source member lacks an execution ordinal")
        if (self.geometry_status == "INVALID") != (self.bbox is None):
            _fail("member geometry availability is inconsistent")
        if self.duplicate_of_member_id == self.member_id:
            _fail("member cannot duplicate itself")
        if (
            self.duplicate_of_member_id is not None
            and self.selection_state != "DEDUPE_SUPPRESSED"
        ):
            _fail("only suppressed members can link a dedupe representative")
        return self


class PdfLocalTextSourceGroup(_LocalEvidenceModel):
    """An admitted or rejected parser grouping without invented parent Facts."""

    source_group_id: str = Field(pattern=r"^PDFTG-[0-9a-f]{64}$")
    granularity: Literal["word", "text_span", "line_candidate", "character"]
    source_group_order: int = Field(ge=0)
    parent_fact_id: str | None = Field(default=None, pattern=r"^PDFF-[0-9a-f]{24}$")
    derived_from_source_group_id: str | None = Field(
        default=None, pattern=r"^PDFTG-[0-9a-f]{64}$"
    )
    text: str = Field(min_length=1, max_length=1_000_000)
    parser_bbox: PdfEvidenceBox | None
    bbox: PdfEvidenceBox | None
    geometry_status: Literal["INSIDE", "INTERSECTS", "OUTSIDE", "ZERO_AREA", "INVALID"]
    disposition: Literal[
        "ADMITTED",
        "GEOMETRY_REJECTED",
        "FACT_LIMIT_REJECTED",
        "SEGMENTATION_SUPERSEDED",
    ]
    member_ids: tuple[str, ...]
    source_member_count: int = Field(ge=0)
    member_inventory_status: Literal["COMPLETE", "PARTIAL", "NOT_CAPTURED"]
    member_projection_status: Literal[
        "EXACT", "TRANSFORMED", "UNRESOLVED", "NOT_CAPTURED"
    ]
    member_projection: tuple[PdfLocalMemberProjection, ...]

    @model_validator(mode="after")
    def validate_group(self) -> PdfLocalTextSourceGroup:
        """Keep actual Fact admission and complete source inventories explicit."""
        if (self.disposition == "ADMITTED") != (self.parent_fact_id is not None):
            _fail("source group parent disagrees with actual admission")
        if (self.geometry_status == "INVALID") != (self.bbox is None):
            _fail("source group geometry availability is inconsistent")
        if (
            len(set(self.member_ids)) != len(self.member_ids)
            or len(self.member_ids) > self.source_member_count
        ):
            _fail("source group repeats or overcounts members")
        if (
            self.member_inventory_status == "COMPLETE"
            and len(self.member_ids) != self.source_member_count
        ):
            _fail("complete group omits source members")
        self._validate_projection_inventory()
        return self

    def _validate_projection_inventory(self) -> None:
        if self.member_projection_status in {"EXACT", "TRANSFORMED"}:
            if self.member_inventory_status != "COMPLETE":
                _fail("proven projection requires complete membership")
            identities = tuple(
                part.member_id
                for part in self.member_projection
                if part.member_id is not None
            )
            if identities != self.member_ids:
                _fail("projection does not account for ordered group members")
            cursor = 0
            for part in self.member_projection:
                if part.output_start != cursor or part.output_end > len(self.text):
                    _fail("projection is not contiguous over actual group text")
                cursor = part.output_end
            if cursor != len(self.text):
                _fail("projection does not cover actual group text")
            exact = all(part.transform == "IDENTITY" for part in self.member_projection)
            if exact != (self.member_projection_status == "EXACT"):
                _fail("exact projection cannot hide transforms")
        elif self.member_projection:
            _fail("unresolved group cannot carry a proven projection")


class PdfLocalFactMembership(_LocalEvidenceModel):
    """Actual Fact and Layout identity associated with one source grouping."""

    fact_id: str = Field(pattern=r"^PDFF-[0-9a-f]{24}$")
    source_group_id: str = Field(pattern=r"^PDFTG-[0-9a-f]{64}$")
    layout_node_ids: tuple[str, ...]

    @model_validator(mode="after")
    def validate_node_ids(self) -> PdfLocalFactMembership:
        """Require explicit unique Layout IDs, without manufacturing a node."""
        if self.layout_node_ids != tuple(sorted(set(self.layout_node_ids))) or any(
            not item.startswith("PDFLN-") for item in self.layout_node_ids
        ):
            _fail("parent Layout node inventory is invalid")
        return self


class PdfLocalTableMemberSelection(_LocalEvidenceModel):
    """Typed copy of an independently reconstructable source member selection."""

    schema_version: Literal["pdf_table_member_binding.v1"] = (
        "pdf_table_member_binding.v1"
    )
    binding_id: str = Field(pattern=r"^P3C-member-selection-[0-9a-f]{64}$")
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    parent_fact_id: str = Field(pattern=r"^PDFF-[0-9a-f]{24}$")
    parent_layout_node_id: str = Field(pattern=r"^PDFLN-[0-9a-f]{24}$")
    source_group_id: str = Field(pattern=r"^PDFTG-[0-9a-f]{64}$")
    member_ids: tuple[str, ...] = Field(min_length=1, max_length=100_000)
    text: str = Field(min_length=1, max_length=1_000_000)
    geometry: PdfEvidenceBox
    partition_basis: Literal[
        "closed_physical_separator_grid", "repeated_member_whitespace_grid"
    ]
    projection: Literal["exact_member_concatenation"] = "exact_member_concatenation"

    @model_validator(mode="after")
    def validate_identity(self) -> PdfLocalTableMemberSelection:
        """Keep the exact source selection's original method identity."""
        from document_sdk.pdf._structural_engine.structure.identity import (
            canonical_sha256,
        )

        if len(self.member_ids) != len(set(self.member_ids)):
            _fail("table selection repeats source occurrences")
        expected = "P3C-member-selection-" + canonical_sha256(
            self.model_dump(exclude={"binding_id"})
        )
        if self.binding_id != expected:
            _fail("table member selection identity mismatch")
        return self


class PdfLocalCrossedPhysicalSeparator(_LocalEvidenceModel):
    """An observed crossing tied to the original physical stroke sources."""

    axis: Literal["COLUMN"] = "COLUMN"
    boundary_index: int = Field(ge=1)
    coordinate: FiniteFloat
    outer_boundary: bool
    member_id: str = Field(pattern=r"^PDFF-[0-9a-f]{24}$")
    source_drawing_fact_ids: tuple[str, ...]


class PdfLocalSourceAnchoredOverflowProof(_LocalEvidenceModel):
    """Public SDK DTO; importing it does not load private Table algorithms."""

    schema_version: Literal["pdf_source_anchored_overflow.v1"] = (
        "pdf_source_anchored_overflow.v1"
    )
    proof_id: str = Field(pattern=r"^P3C-source-anchored-overflow-[0-9a-f]{64}$")
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    grid_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    native_event_id: str = Field(pattern=r"^PDFTE-[0-9a-f]{64}$")
    native_event_ordinal: int = Field(ge=0)
    parent_fact_id: str = Field(pattern=r"^PDFF-[0-9a-f]{24}$")
    parent_layout_node_id: str = Field(pattern=r"^PDFLN-[0-9a-f]{24}$")
    member_ids: tuple[str, ...] = Field(min_length=1, max_length=100_000)
    actual_origins: tuple[tuple[FiniteFloat, FiniteFloat], ...]
    actual_member_geometry: tuple[PdfEvidenceBox, ...]
    actual_geometry: PdfEvidenceBox
    cell_geometry: PdfEvidenceBox
    row_index: int = Field(ge=0)
    column_index: int = Field(ge=0)
    text: str
    crossings: tuple[PdfLocalCrossedPhysicalSeparator, ...]
    basis: Literal["independent_native_event_repeated_physical_cell_anchors"] = (
        "independent_native_event_repeated_physical_cell_anchors"
    )
    ownership_status: Literal["SOURCE_ANCHORED_WITH_GEOMETRY_LIMITATION"] = (
        "SOURCE_ANCHORED_WITH_GEOMETRY_LIMITATION"
    )
    cell_state: Literal["AMBIGUOUS"] = "AMBIGUOUS"
    table_outcome: Literal["PARTIAL"] = "PARTIAL"
    limitation_codes: tuple[str, ...] = (
        "source_anchored_grid_contains_actual_overflow",
    )

    @model_validator(mode="after")
    def validate_proof_identity(self) -> PdfLocalSourceAnchoredOverflowProof:
        """Preserve exact proof identity without eager algorithm imports."""
        from document_sdk.pdf._structural_engine.structure.identity import (
            canonical_sha256,
        )

        if len(set(self.member_ids)) != len(self.member_ids) or not (
            len(self.member_ids)
            == len(self.actual_origins)
            == len(self.actual_member_geometry)
        ):
            _fail("public ownership proof member inventory is inconsistent")
        expected = "P3C-source-anchored-overflow-" + canonical_sha256(
            self.model_dump(exclude={"proof_id"})
        )
        if self.proof_id != expected:
            _fail("public ownership proof identity mismatch")
        return self


class PdfLocalCellTextPart(_LocalEvidenceModel):
    """One production-recorded text contributor and its exact preceding separator."""

    source_fact_id: str = Field(pattern=r"^PDFF-[0-9a-f]{24}$")
    source_layout_node_id: str = Field(pattern=r"^PDFLN-[0-9a-f]{24}$")
    member_binding_id: str | None = Field(
        default=None, pattern=r"^P3C-member-selection-[0-9a-f]{64}$"
    )
    source_anchored_overflow_id: str | None = Field(
        default=None, pattern=r"^P3C-source-anchored-overflow-[0-9a-f]{64}$"
    )
    separator_before: Literal["", " ", "\n"]


class PdfLocalCellMemberLink(_LocalEvidenceModel):
    """Map actual public cell coordinates to same-run source selections."""

    table_id: str = Field(pattern=r"^P3CE1-table-[0-9a-f]{64}$")
    source_table_id: str
    source_cell_id: str
    method: Literal[
        "ruled_cell_text.v1", "borderless_cell_text.v1", "source_anchored_cell_text.v1"
    ]
    row_index: int = Field(ge=0)
    column_index: int = Field(ge=0)
    row_span: int = Field(ge=1)
    column_span: int = Field(ge=1)
    text: str | None
    selection_ids: tuple[str, ...]
    text_parts: tuple[PdfLocalCellTextPart, ...]
    text_projection_status: Literal["RECORDED_PARTS_EXACT"] = "RECORDED_PARTS_EXACT"

    @model_validator(mode="after")
    def validate_selection_inventory(self) -> PdfLocalCellMemberLink:
        """Retain every used selection without replacing a missing proof by a label."""
        if len(set(self.selection_ids)) != len(self.selection_ids):
            _fail("cell repeats a member selection")
        referenced = tuple(
            sorted(
                {
                    part.member_binding_id
                    for part in self.text_parts
                    if part.member_binding_id is not None
                }
            )
        )
        if self.selection_ids != referenced:
            _fail("cell selections disagree with recorded production contributors")
        if self.text_parts and self.text_parts[0].separator_before:
            _fail("cell text cannot start with an unbound inserted separator")
        return self


class PdfLocalMemberRecordCounts(_LocalEvidenceModel):
    """Available records before public serialization budgeting."""

    source_anchored_overflow_proofs: int = Field(default=0, ge=0)
    native_text_events: int = Field(default=0, ge=0)
    text_members: int = Field(ge=0)
    source_groups: int = Field(ge=0)
    fact_memberships: int = Field(ge=0)
    table_member_selections: int = Field(ge=0)
    cell_member_links: int = Field(ge=0)


@dataclass
class _PublicOverflowSourceIndex:
    members: dict[str, PdfLocalTextMember]
    groups: dict[str, PdfLocalTextSourceGroup]
    facts: dict[str, PdfLocalFactMembership]
    events: dict[str, PdfNativeTextShowEvent]
    drawings: set[str]
    group_positions: dict[str, dict[str, int]] = field(default_factory=dict)

    def source_position(self, group: PdfLocalTextSourceGroup, member_id: str) -> int:
        """Index each retained source run once, not once per output cell."""
        if group.source_group_id not in self.group_positions:
            self.group_positions[group.source_group_id] = {
                key: i for i, key in enumerate(group.member_ids)
            }
        return self.group_positions[group.source_group_id].get(member_id, -1)


def _validate_complete_table_evidence_usage(
    *,
    projection_truncated: bool,
    selections: dict[str, PdfLocalTableMemberSelection],
    proofs: tuple[PdfLocalSourceAnchoredOverflowProof, ...],
    links: tuple[PdfLocalCellMemberLink, ...],
) -> None:
    """Complete public projection cannot invent unused production evidence."""
    if projection_truncated:
        return
    used_selections = {identity for link in links for identity in link.selection_ids}
    used_proofs = {
        part.source_anchored_overflow_id
        for link in links
        for part in link.text_parts
        if part.source_anchored_overflow_id is not None
    }
    if used_selections != set(selections):
        _fail("complete public evidence contains an unused table selection")
    if used_proofs != {proof.proof_id for proof in proofs}:
        _fail("complete public evidence contains an unused overflow proof")


class PdfLocalPageEvidenceV2(PdfLocalPageEvidence):
    """V1 observations plus one shared, bounded pool and explicit member relations."""

    source_page_id: str = Field(pattern=r"^PDFP-[0-9a-f]{24}$")
    text_member_method_version: str = Field(min_length=1, max_length=64)
    source_member_inventory_status: Literal[
        "COMPLETE", "TRUNCATED", "NOT_REQUESTED", "UNSUPPORTED"
    ]
    source_member_count: int = Field(ge=0)
    source_group_count: int = Field(ge=0)
    source_group_truncated: bool
    native_text_event_evidence: PdfLocalNativeTextEventEvidence | None = None
    native_text_event_capture_status: Literal["NOT_CAPTURED", "COMPLETE", "PARTIAL"] = (
        "NOT_CAPTURED"
    )
    source_anchored_overflow_proofs: tuple[PdfLocalSourceAnchoredOverflowProof, ...] = (
        Field(default=(), max_length=4096)
    )
    text_members: tuple[PdfLocalTextMember, ...]
    source_groups: tuple[PdfLocalTextSourceGroup, ...]
    fact_memberships: tuple[PdfLocalFactMembership, ...]
    table_member_selections: tuple[PdfLocalTableMemberSelection, ...]
    cell_member_links: tuple[PdfLocalCellMemberLink, ...]
    available_record_counts: PdfLocalMemberRecordCounts
    record_bytes: int = Field(ge=0)
    record_bytes_limit: int = Field(ge=256)
    projection_truncated: bool

    @model_validator(mode="after")
    def validate_member_records(self) -> PdfLocalPageEvidenceV2:
        """Check every retained relation and actual scalar projection, not labels."""
        members = {member.member_id: member for member in self.text_members}
        groups = {group.source_group_id: group for group in self.source_groups}
        facts = {fact.fact_id: fact for fact in self.fact_memberships}
        selections = {item.binding_id: item for item in self.table_member_selections}
        if any(
            len(items) != len(mapping)
            for items, mapping in (
                (self.text_members, members),
                (self.source_groups, groups),
                (self.fact_memberships, facts),
                (self.table_member_selections, selections),
            )
        ):
            _fail("public member evidence repeats an identity")
        if self.source_member_count < len(members) or self.source_group_count < len(
            groups
        ):
            _fail("public records exceed independently observed source counts")
        indices = [member.source_character_index for member in self.text_members]
        if indices != sorted(set(indices)):
            _fail("public member source ordinals must be ordered and unique")
        if (
            self.source_member_inventory_status == "COMPLETE"
            and self.available_record_counts.text_members != self.source_member_count
        ):
            _fail("complete native member inventory is missing records")
        if (
            not self.source_group_truncated
            and self.available_record_counts.source_groups != self.source_group_count
        ):
            _fail("complete native group inventory is missing records")
        self._validate_record_counts()
        expected_bytes = _record_bytes(self)
        if (
            self.record_bytes != expected_bytes
            or self.record_bytes > self.record_bytes_limit
        ):
            _fail("public member record byte accountant is inconsistent")
        self._validate_native_events(members)
        self._validate_source_relations(members, groups)
        self._validate_fact_membership_inventory(groups)

        for selection in self.table_member_selections:
            _validate_selection(selection, members, groups, facts, self.source_page_id)
        self._validate_overflow_proofs(members, groups, facts)
        _replay_public_overflow(self)
        self._validate_cell_parts(groups, facts, selections)
        _validate_complete_table_evidence_usage(
            projection_truncated=self.projection_truncated,
            selections=selections,
            proofs=self.source_anchored_overflow_proofs,
            links=self.cell_member_links,
        )
        return self

    def _validate_fact_membership_inventory(
        self, groups: dict[str, PdfLocalTextSourceGroup]
    ) -> None:
        """An admitted source is an obligation, independent of declared counts."""
        expected_memberships = {
            (group.parent_fact_id, group.source_group_id)
            for group in groups.values()
            if group.disposition == "ADMITTED" and group.parent_fact_id is not None
        }
        retained_memberships = {
            (fact.fact_id, fact.source_group_id) for fact in self.fact_memberships
        }
        if not retained_memberships <= expected_memberships or (
            not self.projection_truncated
            and retained_memberships != expected_memberships
        ):
            _fail("admitted Fact membership inventory is inconsistent")
        for fact in self.fact_memberships:
            group = groups.get(fact.source_group_id)
            if group is None or group.parent_fact_id != fact.fact_id:
                _fail("Fact membership is not bound to its actual source group")

    def _validate_native_events(self, members: dict[str, PdfLocalTextMember]) -> None:
        evidence = self.native_text_event_evidence
        events = (
            {}
            if evidence is None
            else {event.source_event_id: event for event in evidence.events}
        )
        available = self.available_record_counts.native_text_events
        if len(events) > available or (
            not self.projection_truncated and len(events) != available
        ):
            _fail("public native event record count is inconsistent")
        if evidence is None:
            if self.native_text_event_capture_status == "COMPLETE":
                _fail("missing native events cannot be complete")
        elif evidence.availability != self.native_text_event_capture_status:
            _fail("public native event status differs from its captured inventory")
        native_ordinals: set[int] = set()
        event_ordinals: set[tuple[str, int]] = set()
        for member in members.values():
            event_id = member.native_text_event_id
            if event_id is None:
                continue
            event = events.get(event_id)
            ordinal, native_ordinal = (
                member.native_text_event_member_ordinal,
                member.native_character_ordinal,
            )
            if (
                event is None
                or evidence is None
                or ordinal is None
                or native_ordinal is None
                or member.native_text_event_ordinal != event.native_event_ordinal
                or ordinal >= event.source_member_count
                or native_ordinal >= evidence.source_member_count
            ):
                _fail("public native member event or ordinal is not reconstructible")
            if (
                native_ordinal in native_ordinals
                or (event_id, ordinal) in event_ordinals
            ):
                _fail("public native occurrence is repeated")
            native_ordinals.add(native_ordinal)
            event_ordinals.add((event_id, ordinal))

    def _validate_record_counts(self) -> None:
        group_ordinals = [group.source_group_order for group in self.source_groups]
        if group_ordinals != sorted(set(group_ordinals)):
            _fail("source group native order is duplicated or reordered")
        cell_keys = [
            (link.table_id, link.row_index, link.column_index)
            for link in self.cell_member_links
        ]
        if len(cell_keys) != len(set(cell_keys)):
            _fail("public cell member links repeat an actual cell")
        for name in _RECORD_FIELDS:
            retained = len(getattr(self, name))
            available = getattr(self.available_record_counts, name)
            if retained > available or (
                not self.projection_truncated and retained != available
            ):
                _fail("public record count or truncation is inconsistent")

    def _validate_source_relations(
        self,
        members: dict[str, PdfLocalTextMember],
        groups: dict[str, PdfLocalTextSourceGroup],
    ) -> None:
        public_facts = {fact.fact_id: fact for fact in (*self.words, *self.text_spans)}
        for member in self.text_members:
            if member.duplicate_of_member_id is not None:
                target = members.get(member.duplicate_of_member_id)
                if target is None or target.selection_state == "DEDUPE_SUPPRESSED":
                    _fail("public member dedupe representative is missing")
        for group in self.source_groups:
            _validate_group_members(group, members)
            if group.derived_from_source_group_id is not None:
                original = groups.get(group.derived_from_source_group_id)
                if (
                    original is None
                    or original.disposition != "GEOMETRY_REJECTED"
                    or not set(group.member_ids) <= set(original.member_ids)
                ):
                    _fail("derived public group lost its rejected source parent")
            if (
                group.granularity in {"word", "text_span"}
                and group.parent_fact_id is not None
            ):
                actual = public_facts.get(group.parent_fact_id)
                if actual is None or actual.text != group.text:
                    _fail("source group text does not bind its actual public Fact")

    def _validate_overflow_proofs(
        self,
        members: dict[str, PdfLocalTextMember],
        groups: dict[str, PdfLocalTextSourceGroup],
        facts: dict[str, PdfLocalFactMembership],
    ) -> None:
        """Bind retained native proof observations to the same public source pool."""
        sources = _PublicOverflowSourceIndex(
            members,
            groups,
            facts,
            {}
            if self.native_text_event_evidence is None
            else {e.source_event_id: e for e in self.native_text_event_evidence.events},
            {d.fact_id for d in self.drawings},
        )
        ids: set[str] = set()
        consumed: set[str] = set()
        for proof in self.source_anchored_overflow_proofs:
            if proof.proof_id in ids or consumed.intersection(proof.member_ids):
                _fail("public native ownership repeats a source occurrence")
            ids.add(proof.proof_id)
            consumed.update(proof.member_ids)
            actual = self._overflow_members_for_proof(proof, sources)
            self._validate_overflow_member_geometry(proof, actual, sources.drawings)
        linked = [
            part.source_anchored_overflow_id
            for link in self.cell_member_links
            for part in link.text_parts
            if part.source_anchored_overflow_id is not None
        ]
        if len(linked) != len(set(linked)) or not set(linked) <= ids:
            _fail("public native ownership links are duplicated or unbound")

    def _overflow_members_for_proof(
        self,
        proof: PdfLocalSourceAnchoredOverflowProof,
        sources: _PublicOverflowSourceIndex,
    ) -> list[PdfLocalTextMember]:
        members, groups, facts = (sources.members, sources.groups, sources.facts)
        parent = facts.get(proof.parent_fact_id)
        if (
            proof.page_id != self.source_page_id
            or parent is None
            or proof.parent_layout_node_id not in parent.layout_node_ids
        ):
            _fail("public native ownership source/page/parent is inconsistent")
        group = groups[parent.source_group_id]
        if (
            group.member_inventory_status != "COMPLETE"
            or group.member_projection_status != "EXACT"
        ):
            _overflow_replay_failure()
        chosen = [members.get(key) for key in proof.member_ids]
        if any(member is None for member in chosen):
            _fail("public native ownership is missing its source members")
        actual = [member for member in chosen if member is not None]
        start = sources.source_position(group, proof.member_ids[0])
        if start < 0:
            _fail("public native ownership has a foreign source occurrence")
        if group.member_ids[start : start + len(proof.member_ids)] != proof.member_ids:
            _fail("public native ownership source run is not contiguous")
        events = sources.events
        event = events.get(proof.native_event_id)
        if (
            event is None
            or event.native_event_ordinal != proof.native_event_ordinal
            or event.completeness != "COMPLETE"
            or (event.source_member_count != len(actual))
            or (event.retained_member_count != len(actual))
            or (
                tuple(m.native_text_event_member_ordinal for m in actual)
                != tuple(range(len(actual)))
            )
            or any(m.native_text_event_id != proof.native_event_id for m in actual)
            or any(
                m.bbox is None
                or m.geometry_status != "INSIDE"
                or m.selection_state != "RETAINED"
                for m in actual
            )
        ):
            _fail("public native ownership event membership is incomplete")
        return actual

    def _validate_overflow_member_geometry(
        self,
        proof: PdfLocalSourceAnchoredOverflowProof,
        actual: list[PdfLocalTextMember],
        drawings: set[str],
    ) -> None:
        if proof.text != "".join(m.text for m in actual):
            _fail("public native ownership text differs from actual members")
        if any(
            (
                m.bbox is None or m.bbox.model_dump() != box.model_dump()
                for m, box in zip(actual, proof.actual_member_geometry, strict=True)
            )
        ):
            _fail("public native ownership geometry was changed")
        origins = []
        for member in actual:
            matrix = member.parser_text_matrix
            if matrix is None:
                _fail("public native ownership origin is missing")
            origins.append(_public_native_origin(self, matrix))
        if tuple(origins) != proof.actual_origins:
            _fail("public native ownership origins disagree with source")
        if any(not set(c.source_drawing_fact_ids) <= drawings for c in proof.crossings):
            _fail("public native ownership separator sources are missing")

    def _validate_cell_parts(
        self,
        groups: dict[str, PdfLocalTextSourceGroup],
        facts: dict[str, PdfLocalFactMembership],
        selections: dict[str, PdfLocalTableMemberSelection],
    ) -> None:
        overflows = {
            proof.proof_id: proof for proof in self.source_anchored_overflow_proofs
        }
        for link in self.cell_member_links:
            output: list[str] = []
            for part in link.text_parts:
                parent = facts.get(part.source_fact_id)
                if (
                    parent is None
                    or part.source_layout_node_id not in parent.layout_node_ids
                ):
                    _fail("cell text part lost its actual Fact/Layout parent")
                if part.source_anchored_overflow_id is not None:
                    proof = overflows.get(part.source_anchored_overflow_id)
                    if (
                        proof is None
                        or part.member_binding_id is not None
                        or (proof.parent_fact_id, proof.parent_layout_node_id)
                        != (part.source_fact_id, part.source_layout_node_id)
                        or link.method != "source_anchored_cell_text.v1"
                        or (proof.row_index, proof.column_index)
                        != (link.row_index, link.column_index)
                        or link.row_span != 1
                        or link.column_span != 1
                        or len(link.text_parts) != 1
                        or part.separator_before
                    ):
                        _fail("public overflow cell lost its exact event proof")
                    text = proof.text
                elif part.member_binding_id is None:
                    if link.method == "source_anchored_cell_text.v1":
                        _fail("public source-anchored cell lacks its proof")
                    text = groups[parent.source_group_id].text
                else:
                    selection = selections.get(part.member_binding_id)
                    if selection is None or (
                        selection.parent_fact_id,
                        selection.parent_layout_node_id,
                    ) != (part.source_fact_id, part.source_layout_node_id):
                        _fail("cell text part lost its exact source selection")
                    text = selection.text
                output.extend((part.separator_before, text))
            rebuilt = (
                None if link.text is None and not link.text_parts else "".join(output)
            )
            if rebuilt != link.text:
                _fail("actual cell text cannot be rebuilt from recorded source parts")


class _PdfLocalMemberEvidenceBase[PageEvidenceT: PdfLocalPageEvidenceV2](
    _LocalEvidenceModel
):
    """Shared source reconstruction without changing legacy wire fields."""

    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    parser_name: str = Field(min_length=1, max_length=64)
    parser_version: str = Field(min_length=1, max_length=64)
    extraction_status: _ExtractionStatus
    source_page_count: int = Field(ge=0)
    pages: tuple[PageEvidenceT, ...]
    warnings: tuple[str, ...]

    @model_validator(mode="after")
    def validate_source_identity(self) -> Self:
        """Recalculate source member and grouping identity for this input only."""
        from document_sdk.pdf._structural_engine.facts.identifiers import (
            page_identifier,
            text_member_identifier,
            text_source_group_identifier,
        )

        numbers = tuple(page.page_number for page in self.pages)
        if numbers != tuple(sorted(set(numbers))) or any(
            number > self.source_page_count for number in numbers
        ):
            _fail("public source page inventory is invalid")
        for page in self.pages:
            if page.source_page_id != page_identifier(
                source_hash=self.source_sha256,
                parser_name=self.parser_name,
                parser_version=self.parser_version,
                page_number=page.page_number,
            ):
                _fail("public source page identity mismatch")
            self._validate_native_source(page)
            if any(
                proof.source_sha256 != self.source_sha256
                for proof in page.source_anchored_overflow_proofs
            ):
                _fail("public overflow proof belongs to a different source")
            for member in page.text_members:
                box = member.parser_bbox
                expected = text_member_identifier(
                    source_hash=self.source_sha256,
                    parser_name=self.parser_name,
                    parser_version=self.parser_version,
                    method_version=page.text_member_method_version,
                    page_number=page.page_number,
                    source_character_index=member.source_character_index,
                    text=member.text,
                    parser_bbox=(box.x0, box.y0, box.x1, box.y1)
                    if box is not None
                    else None,
                    matrix=member.parser_text_matrix,
                    parser_advance=member.parser_advance,
                    source_writing_mode=member.source_writing_mode,
                    native_text_event_id=member.native_text_event_id,
                    native_text_event_ordinal=member.native_text_event_ordinal,
                    native_text_event_member_ordinal=member.native_text_event_member_ordinal,
                    native_character_ordinal=member.native_character_ordinal,
                )
                if expected != member.member_id:
                    _fail(
                        "public member identity is bound to a different input or method"
                    )
            for group in page.source_groups:
                expected = text_source_group_identifier(
                    source_hash=self.source_sha256,
                    page_id=page.source_page_id,
                    method_version=page.text_member_method_version,
                    granularity=group.granularity,
                    source_group_order=group.source_group_order,
                    text=group.text,
                )
                if expected != group.source_group_id:
                    _fail("public source group identity mismatch")
            if any(
                selection.source_sha256 != self.source_sha256
                for selection in page.table_member_selections
            ):
                _fail("public table selection belongs to a different input")
        return self

    def _validate_native_source(self, page: PdfLocalPageEvidenceV2) -> None:
        if page.native_text_event_evidence is not None:
            for event in page.native_text_event_evidence.events:
                if (
                    event.source_sha256 != self.source_sha256
                    or event.page_number != page.page_number
                ):
                    _fail("public native event source/page identity mismatch")


class PdfLocalEvidenceV2(_PdfLocalMemberEvidenceBase[PdfLocalPageEvidenceV2]):
    """Legacy v2 shape; does not claim independently replayable Fact identities."""

    schema_version: Literal["document_sdk.pdf.local_evidence.v2"] = (
        "document_sdk.pdf.local_evidence.v2"
    )


class PdfLocalPageEvidenceV3(PdfLocalPageEvidenceV2):
    """V3 adds actual Fact source order, keyed by the retained source group."""

    fact_source_orders: dict[str, Annotated[int, Field(ge=0)]]

    @field_validator("fact_source_orders", mode="before")
    @classmethod
    def copy_fact_source_orders(cls, value: object) -> object:
        """Accept this model's immutable mapping during trusted revalidation."""
        return dict(value) if isinstance(value, Mapping) else value

    @model_validator(mode="after")
    def validate_fact_source_inventory(self) -> Self:
        """Account for exactly one native order per retained Fact."""
        if set(self.fact_source_orders) != {
            fact.source_group_id for fact in self.fact_memberships
        }:
            _fail("Fact identity reconstruction source inventory mismatch")
        if len(set(self.fact_source_orders.values())) != len(self.fact_source_orders):
            _fail("Fact identity reconstruction repeats source order")
        object.__setattr__(
            self,
            "fact_source_orders",
            MappingProxyType(dict(self.fact_source_orders)),
        )
        return self

    @field_serializer("fact_source_orders")
    def serialize_fact_source_orders(self, value: dict[str, int]) -> dict[str, int]:
        """Emit the immutable Fact-order inventory as a JSON object."""
        return dict(value)


class PdfLocalEvidenceV3(_PdfLocalMemberEvidenceBase[PdfLocalPageEvidenceV3]):
    """Explicit v3: replay every retained Fact with the authoritative identifier."""

    schema_version: Literal["document_sdk.pdf.local_evidence.v3"] = (
        "document_sdk.pdf.local_evidence.v3"
    )

    @model_validator(mode="after")
    def validate_fact_identities(self) -> Self:
        """Replay PDFF inputs, then cross-check separately retained observations."""
        from document_sdk.pdf._structural_engine.facts.contracts import PdfBoundingBox
        from document_sdk.pdf._structural_engine.facts.identifiers import (
            fact_identifier,
        )

        for page in self.pages:
            groups = {group.source_group_id: group for group in page.source_groups}
            public_facts = {
                fact.fact_id: fact for fact in (*page.words, *page.text_spans)
            }
            for membership in page.fact_memberships:
                group = groups[membership.source_group_id]
                order = page.fact_source_orders[group.source_group_id]
                if group.bbox is None:
                    _fail("Fact identity reconstruction has no admitted geometry")
                expected = fact_identifier(
                    source_hash=self.source_sha256,
                    parser_name=self.parser_name,
                    parser_version=self.parser_version,
                    page_number=page.page_number,
                    fact_type=group.granularity,
                    source_order=order,
                    bbox=PdfBoundingBox.model_validate(group.bbox.model_dump()),
                    text=group.text,
                )
                public = public_facts.get(membership.fact_id)
                if expected != membership.fact_id or (
                    public is not None
                    and (
                        public.source_order != order
                        or public.bbox != group.bbox
                        or public.text != group.text
                    )
                ):
                    _fail("Fact identity reconstruction mismatch")
        return self


def _record_bytes(page: PdfLocalPageEvidenceV2) -> int:
    total = _size(
        {**{name: [] for name in _RECORD_FIELDS}, "native_text_event_evidence": None}
    )
    if isinstance(page, PdfLocalPageEvidenceV3):
        total += len(',"fact_source_orders":') + _size(dict(page.fact_source_orders))
    if page.native_text_event_evidence is not None:
        total += page.native_text_event_evidence.wire_size() - 4
    for name in _RECORD_FIELDS:
        records = getattr(page, name)
        total += max(0, len(records) - 1) + sum(
            _size(record.model_dump(mode="json")) for record in records
        )
    return total


def _validate_group_members(
    group: PdfLocalTextSourceGroup, members: dict[str, PdfLocalTextMember]
) -> None:
    from document_sdk.pdf._structural_engine.facts.contracts import (
        PDF_TEXT_MEMBER_LIGATURES,
    )

    if any(identity not in members for identity in group.member_ids):
        _fail("source group references an unavailable member")
    if group.member_projection_status not in {"EXACT", "TRANSFORMED"}:
        return
    for part in group.member_projection:
        value = group.text[part.output_start : part.output_end]
        if part.transform == "INSERTED_WHITESPACE":
            if not value or not value.isspace():
                _fail("inserted member projection is not whitespace")
            continue
        if part.member_id is None:
            _fail("member projection lacks source identity")
        source = members[part.member_id].text
        if part.transform == "IDENTITY" and source != value:
            _fail("member projection changed actual source text")
        if (
            part.transform == "LIGATURE_EXPANSION"
            and PDF_TEXT_MEMBER_LIGATURES.get(source) != value
        ):
            _fail("member projection has an unsupported text transform")
        if part.transform == "OMITTED_WHITESPACE" and (value or not source.isspace()):
            _fail("member projection omitted non-whitespace source content")


def _validate_selection(
    selection: PdfLocalTableMemberSelection,
    members: dict[str, PdfLocalTextMember],
    groups: dict[str, PdfLocalTextSourceGroup],
    facts: dict[str, PdfLocalFactMembership],
    page_id: str,
) -> None:
    parent = facts.get(selection.parent_fact_id)
    group = groups.get(selection.source_group_id)
    if (
        selection.page_id != page_id
        or parent is None
        or group is None
        or parent.source_group_id != group.source_group_id
        or selection.parent_layout_node_id not in parent.layout_node_ids
    ):
        _fail("table selection lost actual page/Fact/Layout parent binding")
    if (
        group.member_inventory_status != "COMPLETE"
        or group.member_projection_status not in {"EXACT", "TRANSFORMED"}
    ):
        _fail("table selection cannot use an unproven parent projection")
    positions = {identity: i for i, identity in enumerate(group.member_ids)}
    if any(identity not in positions for identity in selection.member_ids):
        _fail("table selection references members outside its actual parent")
    order = [positions[identity] for identity in selection.member_ids]
    if order != sorted(set(order)):
        _fail("table selection changed source occurrence order")
    if order != list(range(order[0], order[-1] + 1)):
        _fail("table selection is not a contiguous source occurrence run")
    selected = [members[identity] for identity in selection.member_ids]
    if any(
        member.selection_state != "RETAINED"
        or member.geometry_status != "INSIDE"
        or member.bbox is None
        for member in selected
    ):
        _fail("table selection contains uncertain or suppressed geometry")
    if "".join(member.text for member in selected) != selection.text:
        _fail("table selection text cannot be independently reconstructed")
    boxes = [member.bbox for member in selected if member.bbox is not None]
    expected = PdfEvidenceBox(
        x0=min(box.x0 for box in boxes),
        y0=min(box.y0 for box in boxes),
        x1=max(box.x1 for box in boxes),
        y1=max(box.y1 for box in boxes),
    )
    if expected != selection.geometry:
        _fail("table selection geometry is not the observed member union")


class _RecordBudget:
    """Stream one record at a time; admission never serializes the whole pool."""

    def __init__(self, limit: int, *, fact_identity_sources: bool = False) -> None:
        self.limit = limit
        self.records: dict[str, list[Any]] = {name: [] for name in _RECORD_FIELDS}
        self.bytes = _size({**self.records, "native_text_event_evidence": None})
        self.fact_source_orders: dict[str, int] = {}
        if fact_identity_sources:
            self.bytes += len(',"fact_source_orders":{}')
        self.native_evidence: PdfLocalNativeTextEventEvidence | None = None
        self.truncated = False

    def append_fact(self, record: PdfLocalFactMembership, source_order: int) -> bool:
        """Admit membership and its reconstruction input atomically under one cap."""
        source_cost = (
            _size({record.source_group_id: source_order})
            - 2
            + int(bool(self.fact_source_orders))
        )
        record_cost = _size(record.model_dump(mode="json")) + int(
            bool(self.records["fact_memberships"])
        )
        if self.bytes + source_cost + record_cost > self.limit:
            self.truncated = True
            return False
        if not self.append("fact_memberships", record):
            return False
        self.fact_source_orders[record.source_group_id] = source_order
        self.bytes += source_cost
        return True

    def append(self, name: str, value: Any) -> bool:
        cost = _size(value.model_dump(mode="json")) + int(bool(self.records[name]))
        if self.bytes + cost > self.limit:
            self.truncated = True
            return False
        self.records[name].append(value)
        self.bytes += cost
        return True


def _member(value: PdfTextMember) -> PdfLocalTextMember:
    matrix = value.text_transform
    return PdfLocalTextMember(
        member_id=value.member_id,
        source_character_index=value.source_character_index,
        text=value.text,
        parser_bbox=_box(value.parser_bbox) if value.parser_bbox is not None else None,
        bbox=_box(value.bbox) if value.bbox is not None else None,
        geometry_status=value.geometry_status,
        geometry_semantics=value.geometry_semantics,
        selection_state=value.selection_state,
        duplicate_of_member_id=value.duplicate_of_member_id,
        parser_text_matrix=(matrix.a, matrix.b, matrix.c, matrix.d, matrix.e, matrix.f)
        if matrix is not None
        else None,
        font_name=value.font_name,
        parser_font_size=value.parser_font_size,
        parser_advance=value.parser_advance,
        source_writing_mode=value.source_writing_mode,
        native_text_event_id=value.native_text_event_id,
        native_text_event_ordinal=value.native_text_event_ordinal,
        native_text_event_member_ordinal=value.native_text_event_member_ordinal,
        native_character_ordinal=value.native_character_ordinal,
        rotation=value.rotation,
        warnings=tuple(warning.code.value for warning in value.warnings),
    )


def _group(value: PdfTextSourceGroup) -> PdfLocalTextSourceGroup:
    return PdfLocalTextSourceGroup(
        source_group_id=value.source_group_id,
        granularity=value.granularity,
        source_group_order=value.source_group_order,
        parent_fact_id=value.parent_fact_id,
        derived_from_source_group_id=value.derived_from_source_group_id,
        text=value.text,
        parser_bbox=_box(value.parser_bbox) if value.parser_bbox is not None else None,
        bbox=_box(value.bbox) if value.bbox is not None else None,
        geometry_status=value.geometry_status,
        disposition=value.disposition,
        member_ids=value.member_ids,
        source_member_count=value.source_member_count,
        member_inventory_status=value.member_inventory_status,
        member_projection_status=value.member_projection_status,
        member_projection=tuple(
            PdfLocalMemberProjection(
                member_id=part.member_id,
                output_start=part.output_start,
                output_end=part.output_end,
                transform=part.transform,
            )
            for part in value.member_projection
        ),
    )


def _canonical_cell_links(
    bundle: CanonicalArtifactBundle, canonical: CanonicalDocument, page_number: int
) -> Iterator[PdfLocalCellMemberLink]:
    source_tables = {
        table.table_id: table for page in bundle.table_pages for table in page.tables
    }
    projections = {
        projection.cell_id: projection
        for page in bundle.table_pages
        if page.page_index == page_number - 1
        for projection in page.cell_text_projections
    }
    page_numbers = {page.page_id: page.page_number for page in canonical.pages}
    for table in canonical.tables:
        if page_numbers[table.page_id] != page_number:
            continue
        source = source_tables.get(table.source_table_id)
        if source is None:
            continue
        source_cells = {cell.cell_id: cell for cell in source.cells}
        for cell in table.cells:
            actual = source_cells.get(cell.source_cell_id)
            if actual is None:
                _fail("Canonical cell lost its actual source cell")
            projection = projections.get(cell.source_cell_id)
            if projection is None:
                if any(
                    item.startswith("member_selection:")
                    for item in actual.text_assignment_evidence
                ):
                    _fail("member-based cell lost its recorded production projection")
                continue
            parts = tuple(
                PdfLocalCellTextPart(
                    source_fact_id=part.source_fact_id,
                    source_layout_node_id=part.source_layout_node_id,
                    member_binding_id=part.member_binding_id,
                    source_anchored_overflow_id=part.source_anchored_overflow_id,
                    separator_before=part.separator_before,
                )
                for part in projection.parts
            )
            identities = tuple(
                sorted(
                    {
                        part.member_binding_id
                        for part in parts
                        if part.member_binding_id is not None
                    }
                )
            )
            yield PdfLocalCellMemberLink(
                table_id=table.table_id,
                source_table_id=table.source_table_id,
                source_cell_id=cell.source_cell_id,
                method=projection.method,
                row_index=cell.row_index,
                column_index=cell.column_index,
                row_span=cell.row_span,
                column_span=cell.column_span,
                text=cell.text,
                selection_ids=identities,
                text_parts=parts,
            )


def _append_member_sources(
    page: PdfPageFacts, budget: _RecordBudget
) -> tuple[set[str], set[str]]:
    member_ids: set[str] = set()
    groups: set[str] = set()
    # Representatives can appear after suppressed native occurrences. Admit the
    # representatives first, then serialize the retained pool in source order.
    ordered = sorted(
        page.text_members,
        key=lambda value: (
            value.selection_state == "DEDUPE_SUPPRESSED",
            value.source_character_index,
        ),
    )
    event_ids = (
        set()
        if budget.native_evidence is None
        else {event.source_event_id for event in budget.native_evidence.events}
    )
    for value in ordered:
        if (
            value.native_text_event_id is not None
            and value.native_text_event_id not in event_ids
        ):
            budget.truncated = True
            continue
        if (
            value.duplicate_of_member_id is not None
            and value.duplicate_of_member_id not in member_ids
        ):
            budget.truncated = True
            continue
        if budget.append("text_members", _member(value)):
            member_ids.add(value.member_id)
    budget.records["text_members"].sort(key=lambda value: value.source_character_index)
    for source_group in page.text_source_groups:
        if not set(source_group.member_ids) <= member_ids or (
            source_group.derived_from_source_group_id is not None
            and source_group.derived_from_source_group_id not in groups
        ):
            budget.truncated = True
            continue
        if budget.append("source_groups", _group(source_group)):
            groups.add(source_group.source_group_id)
    return member_ids, groups


def _layout_nodes_by_fact(
    page: PdfPageFacts, bundle: CanonicalArtifactBundle
) -> dict[str, list[str]]:
    node_ids: dict[str, list[str]] = defaultdict(list)
    if bundle.layout is not None:
        for layout_page in bundle.layout.pages:
            if layout_page.source_page_id == page.page_id:
                for node in layout_page.nodes:
                    node_ids[node.source_fact_id].append(node.node_id)
    return node_ids


def _retain_public_native_evidence(page: PdfPageFacts, budget: _RecordBudget) -> None:
    if page.native_text_event_evidence is not None:
        source_native = page.native_text_event_evidence
        native = PdfLocalNativeTextEventEvidence.model_validate(
            {
                **source_native.model_dump(mode="python", exclude={"events"}),
                "events": tuple(
                    PdfLocalNativeTextShowEvent.model_validate(
                        event.model_dump(mode="python")
                    )
                    for event in source_native.events
                ),
            }
        )
        cost = native.wire_size() - 4
        if budget.bytes + cost <= budget.limit:
            budget.native_evidence = native
            budget.bytes += cost
        else:
            budget.truncated = True


def _append_overflow_records(
    page: PdfPageFacts,
    bundle: CanonicalArtifactBundle,
    budget: _RecordBudget,
    facts: set[str],
    member_ids: set[str],
) -> tuple[int, set[str]]:
    """Retain only source-complete proof records within the public byte budget."""
    source_overflows = tuple(
        proof
        for sidecar in bundle.table_pages
        if sidecar.page_index == page.page_number - 1
        for proof in sidecar.source_anchored_overflow_proofs
    )
    overflow_ids: set[str] = set()
    for proof in source_overflows:
        if proof.parent_fact_id not in facts or not set(proof.member_ids) <= member_ids:
            budget.truncated = True
            continue
        overflow_record = PdfLocalSourceAnchoredOverflowProof.model_validate(
            proof.model_dump(mode="python")
        )
        if budget.append("source_anchored_overflow_proofs", overflow_record):
            overflow_ids.add(proof.proof_id)
    return len(source_overflows), overflow_ids


def _page_records(
    page: PdfPageFacts,
    bundle: CanonicalArtifactBundle,
    cell_links: Iterable[PdfLocalCellMemberLink],
) -> tuple[_RecordBudget, PdfLocalMemberRecordCounts]:
    budget = _RecordBudget(
        bundle.facts.applied_resource_limits.max_text_member_bytes_per_page,
        fact_identity_sources=True,
    )
    _retain_public_native_evidence(page, budget)
    member_ids, groups = _append_member_sources(page, budget)
    facts: set[str] = set()
    selections: set[str] = set()
    node_ids = _layout_nodes_by_fact(page, bundle)
    fact_count = 0
    for value in (
        *page.words,
        *page.text_spans,
        *page.line_candidates,
        *page.characters,
    ):
        if value.source_group_id is None:
            continue
        fact_count += 1
        if value.source_group_id not in groups:
            budget.truncated = True
            continue
        record = PdfLocalFactMembership(
            fact_id=value.fact_id,
            source_group_id=value.source_group_id,
            layout_node_ids=tuple(sorted(node_ids[value.fact_id])),
        )
        if budget.append_fact(record, value.source_order):
            facts.add(value.fact_id)
    source_selections = tuple(
        binding
        for sidecar in bundle.table_pages
        if sidecar.page_index == page.page_number - 1
        for binding in sidecar.member_bindings
    )
    for binding in source_selections:
        if (
            binding.parent_fact_id not in facts
            or not set(binding.member_ids) <= member_ids
        ):
            budget.truncated = True
            continue
        selection_record = PdfLocalTableMemberSelection.model_validate(
            binding.model_dump(mode="python")
        )
        if budget.append("table_member_selections", selection_record):
            selections.add(binding.binding_id)
    overflow_count, overflow_ids = _append_overflow_records(
        page, bundle, budget, facts, member_ids
    )
    link_count = 0
    for cell_link in cell_links:
        link_count += 1
        if (
            any(
                part.source_anchored_overflow_id is not None
                and part.source_anchored_overflow_id not in overflow_ids
                for part in cell_link.text_parts
            )
            or not set(cell_link.selection_ids) <= selections
            or any(part.source_fact_id not in facts for part in cell_link.text_parts)
        ):
            budget.truncated = True
            continue
        budget.append("cell_member_links", cell_link)
    _omit_incomplete_overflow_claims(budget, overflow_count)
    counts = PdfLocalMemberRecordCounts(
        native_text_events=len(page.native_text_event_evidence.events)
        if page.native_text_event_evidence is not None
        else 0,
        text_members=len(page.text_members),
        source_groups=len(page.text_source_groups),
        fact_memberships=fact_count,
        table_member_selections=len(source_selections),
        source_anchored_overflow_proofs=overflow_count,
        cell_member_links=link_count,
    )
    return budget, counts


def _project_local_member_evidence(
    bundle: CanonicalArtifactBundle, canonical: CanonicalDocument
) -> PdfLocalEvidence | PdfLocalEvidenceV3:
    """Project the same invocation without original PDF reads or SDK re-execution."""
    facts = bundle.facts
    if not facts.extraction_options.include_text_members:
        return _project_local_evidence(facts)
    pages = []
    for page in facts.pages:
        budget, counts = _page_records(
            page, bundle, _canonical_cell_links(bundle, canonical, page.page_number)
        )
        pages.append(
            PdfLocalPageEvidenceV3(
                fact_source_orders=budget.fact_source_orders,
                page_number=page.page_number,
                width_points=page.canonical_width,
                height_points=page.canonical_height,
                rotation=page.rotation,
                media_box_points=_box(page.media_box),
                crop_box_points=_box(page.crop_box),
                effective_page_box_points=_box(page.effective_page_box),
                user_unit=page.user_unit,
                extraction_status=page.extraction_status.value,
                text_spans=tuple(_text(value) for value in page.text_spans),
                words=tuple(_text(value) for value in page.words),
                drawings=tuple(_drawing(value) for value in page.drawings),
                images=tuple(
                    PdfLocalImageEvidence(
                        fact_id=value.fact_id,
                        source_order=value.source_order,
                        bbox=_box(value.bbox),
                        pixel_width=value.pixel_width,
                        pixel_height=value.pixel_height,
                        image_type=value.image_type,
                        parser_available=value.parser_available,
                        warnings=tuple(w.code.value for w in value.warnings),
                    )
                    for value in page.image_regions
                ),
                warnings=tuple(w.code.value for w in page.warnings),
                source_page_id=page.page_id,
                native_text_event_evidence=budget.native_evidence,
                native_text_event_capture_status=budget.native_evidence.availability
                if budget.native_evidence is not None
                else (
                    "PARTIAL"
                    if page.native_text_event_evidence is not None
                    else page.native_text_event_capture_status
                ),
                text_member_method_version=page.text_member_method_version,
                source_member_inventory_status=page.text_member_inventory_status,
                source_member_count=page.source_text_member_count,
                source_group_count=page.source_text_group_count,
                source_group_truncated=page.text_source_group_truncated,
                **{name: tuple(values) for name, values in budget.records.items()},
                available_record_counts=counts,
                record_bytes=budget.bytes,
                record_bytes_limit=budget.limit,
                projection_truncated=budget.truncated,
            )
        )
    return PdfLocalEvidenceV3(
        source_sha256=facts.source_sha256,
        parser_name=facts.parser_name,
        parser_version=facts.parser_version,
        extraction_status=facts.extraction_status.value,
        source_page_count=facts.page_count,
        pages=tuple(pages),
        warnings=tuple(w.code.value for w in facts.warnings),
    )


def _overflow_replay_failure() -> NoReturn:
    _fail("public overflow source replay does not reconstruct retained proof")


def _overflow_strokes(
    page: PdfLocalPageEvidenceV2,
) -> dict[tuple[str, float], list[tuple[float, float, str]]]:
    support: dict[tuple[str, float], list[tuple[float, float, str]]] = {}
    for drawing in page.drawings:
        if (
            drawing.kind != "line"
            or drawing.paint_operation != "stroke"
            or drawing.is_clipping_path
            or drawing.warnings
            or not drawing.path_geometry_complete
            or drawing.path_segment_truncated
            or drawing.bbox_kind != "path_geometry"
            or drawing.bbox_quality != "precise"
        ):
            continue
        box = drawing.bbox
        if box.y0 == box.y1 and box.x0 < box.x1:
            key, start, end = ("ROW", box.y0), box.x0, box.x1
        elif box.x0 == box.x1 and box.y0 < box.y1:
            key, start, end = ("COLUMN", box.x0), box.y0, box.y1
        else:
            continue
        support.setdefault(key, []).append((start, end, drawing.fact_id))
    return support


def _overflow_support_ids(
    support: dict[tuple[str, float], list[tuple[float, float, str]]],
    rows: tuple[float, ...],
    columns: tuple[float, ...],
) -> tuple[str, ...]:
    ids: set[str] = set()
    for axis, coordinates, low, high in (
        ("ROW", rows, columns[0], columns[-1]),
        ("COLUMN", columns, rows[0], rows[-1]),
    ):
        for coordinate in coordinates:
            segments = support.get((axis, coordinate), [])
            cursor = low
            for start, end, _ in sorted(segments):
                if start > cursor:
                    break
                cursor = max(cursor, end)
                if cursor >= high:
                    break
            if cursor < high:
                _overflow_replay_failure()
            ids.update(identity for _, _, identity in segments)
    return tuple(sorted(ids))


def _overflow_equal(left: float, right: float) -> bool:
    return abs(left - right) <= 4 * max(ulp(left), ulp(right))


def _overflow_overlap(left: PdfEvidenceBox, right: PdfEvidenceBox) -> bool:
    return min(left.x1, right.x1) > max(left.x0, right.x0) and min(
        left.y1, right.y1
    ) > max(left.y0, right.y0)


def _public_native_origin(
    page: PdfLocalPageEvidence,
    matrix: tuple[float, float, float, float, float, float],
) -> tuple[float, float]:
    """Replay the retained native matrix against bound page boxes and units."""
    media, effective = page.media_box_points, page.effective_page_box_points
    return pdfminer_native_origin_to_canonical(
        parser_origin=(matrix[4], matrix[5]),
        media_box=(media.x0, media.y0, media.x1, media.y1),
        effective_box=(effective.x0, effective.y0, effective.x1, effective.y1),
        page_rotation=page.rotation,
        user_unit=page.user_unit,
    )


def _overflow_event_members(
    page: PdfLocalPageEvidenceV2,
    proof: PdfLocalSourceAnchoredOverflowProof,
    by_event: dict[str | None, list[PdfLocalTextMember]],
) -> list[PdfLocalTextMember]:
    actual = by_event.get(proof.native_event_id, [])
    report = page.native_text_event_evidence
    event = (
        next(
            (e for e in report.events if e.source_event_id == proof.native_event_id),
            None,
        )
        if report
        else None
    )
    if (
        event is None
        or event.operator not in {"Tj", "TJ"}
        or event.string_segment_count != 1
        or event.numeric_adjustment_count
        or event.limitation_codes
        or event.source_sha256 != proof.source_sha256
        or event.page_number != page.page_number
        or tuple(m.member_id for m in actual) != proof.member_ids
    ):
        _overflow_replay_failure()
    previous = None
    for member in actual:
        matrix = member.parser_text_matrix
        if (
            matrix is None
            or matrix[:4] != (1, 0, 0, 1)
            or member.rotation != 0
            or member.source_writing_mode != "HORIZONTAL"
            or member.parser_advance is None
            or member.parser_advance <= 0
            or member.warnings
            or member.duplicate_of_member_id is not None
            or member.native_character_ordinal is None
            or member.native_text_event_ordinal != event.native_event_ordinal
        ):
            _overflow_replay_failure()
        origin = _public_native_origin(page, matrix)
        if previous is not None and (
            member.native_character_ordinal != previous[0] + 1
            or not _overflow_equal(origin[1], previous[1][1])
            or origin[0] <= previous[1][0]
        ):
            _overflow_replay_failure()
        previous = (member.native_character_ordinal, origin)
        cell = proof.cell_geometry
        if not (cell.x0 < origin[0] < cell.x1 and cell.y0 < origin[1] < cell.y1):
            _overflow_replay_failure()
    return actual


def _overflow_crossings(
    page: PdfLocalPageEvidenceV2,
    proof: PdfLocalSourceAnchoredOverflowProof,
    actual: list[PdfLocalTextMember],
    support: dict[tuple[str, float], list[tuple[float, float, str]]],
    neighbor: PdfLocalSourceAnchoredOverflowProof | None,
) -> None:
    boxes = [m.bbox for m in actual if m.bbox is not None]
    if not boxes or proof.actual_geometry != PdfEvidenceBox(
        x0=min(b.x0 for b in boxes),
        y0=min(b.y0 for b in boxes),
        x1=max(b.x1 for b in boxes),
        y1=max(b.y1 for b in boxes),
    ):
        _overflow_replay_failure()
    cell = proof.cell_geometry
    crossings = []
    ids = set(proof.member_ids)
    for ordinal, member in enumerate(actual):
        box = member.bbox
        if box is None:
            _overflow_replay_failure()
        if (
            cell.x0 <= box.x0 <= box.x1 <= cell.x1
            and cell.y0 <= box.y0 <= box.y1 <= cell.y1
        ):
            continue
        if (
            ordinal != len(actual) - 1
            or not (
                cell.x0 <= box.x0 < cell.x1 < box.x1
                and cell.y0 <= box.y0 < box.y1 <= cell.y1
            )
            or (neighbor is not None and box.x1 >= neighbor.actual_origins[0][0])
        ):
            _overflow_replay_failure()
        if any(
            other.member_id not in ids
            and other.bbox is not None
            and _overflow_overlap(box, other.bbox)
            for other in page.text_members
        ):
            _overflow_replay_failure()
        crossings.append(
            PdfLocalCrossedPhysicalSeparator(
                boundary_index=proof.column_index + 1,
                coordinate=cell.x1,
                outer_boundary=neighbor is None,
                member_id=member.member_id,
                source_drawing_fact_ids=tuple(
                    sorted(identity for _, _, identity in support[("COLUMN", cell.x1)])
                ),
            )
        )
    if tuple(crossings) != proof.crossings:
        _overflow_replay_failure()


def _replay_public_overflow_grid(
    page: PdfLocalPageEvidenceV2,
    proofs: list[PdfLocalSourceAnchoredOverflowProof],
    by_event: dict[str | None, list[PdfLocalTextMember]],
) -> None:
    from document_sdk.pdf._structural_engine.structure.identity import canonical_sha256

    rows = tuple(
        sorted({v for p in proofs for v in (p.cell_geometry.y0, p.cell_geometry.y1)})
    )
    columns = tuple(
        sorted({v for p in proofs for v in (p.cell_geometry.x0, p.cell_geometry.x1)})
    )
    cells = {(p.row_index, p.column_index): p for p in proofs}
    if (
        len(rows) < _OVERFLOW_MINIMUM_AXES
        or len(columns) < _OVERFLOW_MINIMUM_AXES
        or len(cells) != len(proofs)
        or (len(rows) - 1) * (len(columns) - 1) != len(proofs)
        or rows[0] < 0
        or columns[0] < 0
        or rows[-1] > page.height_points
        or columns[-1] > page.width_points
    ):
        _overflow_replay_failure()
    support = _overflow_strokes(page)
    drawing_ids = _overflow_support_ids(support, rows, columns)
    grid = canonical_sha256(
        {
            "source_sha256": proofs[0].source_sha256,
            "page_id": page.source_page_id,
            "rows": rows,
            "columns": columns,
            "source_drawing_fact_ids": drawing_ids,
        }
    )
    for row in range(len(rows) - 1):
        for column in range(len(columns) - 1):
            proof = cells.get((row, column))
            expected = PdfEvidenceBox(
                x0=columns[column],
                y0=rows[row],
                x1=columns[column + 1],
                y1=rows[row + 1],
            )
            if (
                proof is None
                or proof.grid_identity != grid
                or proof.cell_geometry != expected
            ):
                _overflow_replay_failure()
            actual = _overflow_event_members(page, proof, by_event)
            _overflow_crossings(
                page, proof, actual, support, cells.get((row, column + 1))
            )
            origin = proof.actual_origins[0]
            if (
                not _overflow_equal(origin[0], cells[(0, column)].actual_origins[0][0])
                or not _overflow_equal(origin[1], cells[(row, 0)].actual_origins[0][1])
                or not _overflow_equal(
                    origin[1] - rows[row], cells[(0, 0)].actual_origins[0][1] - rows[0]
                )
            ):
                _overflow_replay_failure()
    # Reject competing or unassociated source events within this grid.
    selected = {m for p in proofs for m in p.member_ids}
    grid_box = PdfEvidenceBox(x0=columns[0], y0=rows[0], x1=columns[-1], y1=rows[-1])
    if any(
        m.member_id not in selected
        and m.bbox is not None
        and _overflow_overlap(m.bbox, grid_box)
        for m in page.text_members
    ):
        _overflow_replay_failure()


def _replay_public_overflow(page: PdfLocalPageEvidenceV2) -> None:
    """Replay physical claims; source anchors never prove painted ink or intent.

    Retained strokes and complete event/member observations are prerequisites.
    Grid/cell boxes are proposals checked against these independent observations.
    Missing evidence is rejected, never replaced with the proof's own hash.
    """
    if not page.source_anchored_overflow_proofs:
        return
    if (
        page.source_member_inventory_status != "COMPLETE"
        or page.native_text_event_capture_status != "COMPLETE"
        or page.native_text_event_evidence is None
        or page.native_text_event_evidence.truncated
        or page.native_text_event_evidence.availability != "COMPLETE"
        or len(page.text_members) != page.source_member_count
    ):
        _overflow_replay_failure()
    by_id = {p.proof_id: p for p in page.source_anchored_overflow_proofs}
    tables: dict[str, list[PdfLocalSourceAnchoredOverflowProof]] = defaultdict(list)
    for link in page.cell_member_links:
        for part in link.text_parts:
            if part.source_anchored_overflow_id in by_id:
                tables[link.table_id].append(by_id[part.source_anchored_overflow_id])
    if {p.proof_id for proofs in tables.values() for p in proofs} != set(by_id):
        _overflow_replay_failure()
    by_event: dict[str | None, list[PdfLocalTextMember]] = defaultdict(list)
    for member in page.text_members:
        by_event[member.native_text_event_id].append(member)
    if len(by_id) * len(page.text_members) > _OVERFLOW_REPLAY_WORK_LIMIT:
        _overflow_replay_failure()
    for proofs in tables.values():
        _replay_public_overflow_grid(page, proofs, by_event)


def _omit_incomplete_overflow_claims(
    budget: _RecordBudget, overflow_count: int
) -> None:
    """Keep truncation/counts, but never expose an unreplayable grid fragment."""
    if not overflow_count or not budget.truncated:
        return
    for name in ("source_anchored_overflow_proofs", "cell_member_links"):
        previous = budget.records[name]
        retained = (
            []
            if name == "source_anchored_overflow_proofs"
            else [
                item
                for item in previous
                if isinstance(item, PdfLocalCellMemberLink)
                and not any(
                    part.source_anchored_overflow_id for part in item.text_parts
                )
            ]
        )
        budget.bytes -= sum(
            _size(item.model_dump(mode="json")) for item in previous
        ) + max(0, len(previous) - 1)
        budget.bytes += sum(
            _size(item.model_dump(mode="json")) for item in retained
        ) + max(0, len(retained) - 1)
        budget.records[name] = retained

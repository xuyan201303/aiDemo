"""Read real PDF xref-chain and security declarations without invented history."""

from __future__ import annotations

from hashlib import sha256
from io import BytesIO
from typing import TYPE_CHECKING, Literal

from document_sdk.pdf._source_objects_v7 import (
    PdfSourceFileHistoryV7,
    PdfXrefRevisionV7,
)
from document_sdk.pdf._source_objects_v7_values import (
    SourceBudget,
    SourceLimitError,
    SourceReadError,
    dictionary,
    field,
    payload,
    read_dictionary_declaration,
    retain_stream_length,
    source,
    value,
)

if TYPE_CHECKING:
    from typing import Any

    from pypdf import PdfReader

    from document_sdk.pdf._document_objects_v6 import PdfObjectSource
    from document_sdk.pdf._source_objects_v7 import (
        PdfSourceHistoryRecoveryV7,
        SourceState,
    )

_HEADER_TOKEN_COUNT = 3
_SUBSECTION_TOKEN_COUNT = 2


def _startxref(data: bytes) -> int:
    marker = data.rfind(b"startxref")
    if marker < 0:
        message = "SOURCE_STARTXREF_UNAVAILABLE"
        raise SourceReadError(message)
    tail = data[marker + len(b"startxref") :]
    values = tail.split(None, 1)
    if not values or not values[0].isdigit():
        message = "SOURCE_STARTXREF_INVALID"
        raise SourceReadError(message)
    offset = int(values[0])
    if offset >= len(data):
        message = "SOURCE_STARTXREF_OUTSIDE_INPUT"
        raise SourceReadError(message)
    return offset


def _xref_table(stream: BytesIO, reader: PdfReader, *, check_offsets: bool) -> Any:
    from pypdf.generic import DictionaryObject

    number = 0
    remaining = 0
    while True:
        position = stream.tell()
        line = stream.readline()
        if not line:
            message = "SOURCE_XREF_TRAILER_UNAVAILABLE"
            raise SourceReadError(message)
        parts = line.split()
        if remaining and len(parts) == _HEADER_TOKEN_COUNT:
            if check_offsets and parts[2] == b"n":
                declared = int(parts[0])
                original = stream.getvalue()[declared : declared + 64].split(None, 3)
                if (
                    len(original) < _HEADER_TOKEN_COUNT
                    or not all(token.isdigit() for token in original[:2])
                    or original[2] != b"obj"
                    or (int(original[0]), int(original[1])) != (number, int(parts[1]))
                ):
                    message = "SOURCE_XREF_ROW_OFFSET_OR_GENERATION_CONFLICT"
                    raise SourceReadError(message)
            number += 1
            remaining -= 1
        elif len(parts) == _SUBSECTION_TOKEN_COUNT and all(
            part.isdigit() for part in parts
        ):
            number, remaining = (int(part) for part in parts)
        if line.lstrip().startswith(b"trailer"):
            prefix = line.find(b"trailer") + len(b"trailer")
            stream.seek(position + prefix)
            while stream.read(1) in b"\x00\t\n\x0c\r ":
                if stream.tell() >= len(stream.getbuffer()):
                    message = "SOURCE_XREF_TRAILER_TRUNCATED"
                    raise SourceReadError(message)
            stream.seek(-1, 1)
            return DictionaryObject.read_from_stream(stream, reader)


def _xref_stream(
    stream: BytesIO, first_line: bytes, reader: PdfReader, budget: SourceBudget
) -> tuple[Any, int, int]:
    from pypdf.generic import read_object

    tokens = first_line.split()
    if len(tokens) != _HEADER_TOKEN_COUNT or tokens[2] != b"obj":
        message = "SOURCE_XREF_STREAM_OBJECT_HEADER_INVALID"
        raise SourceReadError(message)
    obj, generation = int(tokens[0]), int(tokens[1])
    position = stream.tell()
    declaration = read_dictionary_declaration(stream, reader, budget)
    stream.seek(position)
    parsed = read_object(stream, reader)
    trailer = dictionary(parsed)
    if str(trailer.get("/Type")) != "/XRef":
        message = "SOURCE_XREF_STREAM_TYPE_INVALID"
        raise SourceReadError(message)
    return retain_stream_length(trailer, declaration), obj, generation


def _revision(
    data: bytes,
    offset: int,
    reader: PdfReader,
    budget: SourceBudget,
    *,
    check_offsets: bool = True,
) -> PdfXrefRevisionV7:
    from document_sdk.pdf._document_objects_v6 import PdfObjectSource

    if offset < 0 or offset >= len(data):
        message = "SOURCE_XREF_OFFSET_OUTSIDE_INPUT"
        raise SourceReadError(message)
    budget.object()
    stream = BytesIO(data)
    stream.seek(offset)
    first = stream.readline().strip()
    if first == b"xref":
        trailer = _xref_table(stream, reader, check_offsets=check_offsets)
        kind: Literal["TABLE", "STREAM"] = "TABLE"
        location = PdfObjectSource(source_path=f"/File/Xref/{offset}")
    else:
        trailer, obj, generation = _xref_stream(stream, first, reader, budget)
        kind = "STREAM"
        location = PdfObjectSource(
            source_path=f"/File/Xref/{offset}", object_number=obj, generation=generation
        )
    raw = data[offset : stream.tell()]
    budget.encoded(len(raw))
    previous = int(trailer["/Prev"]) if "/Prev" in trailer else None
    hybrid = int(trailer["/XRefStm"]) if "/XRefStm" in trailer else None
    return PdfXrefRevisionV7(
        offset=offset,
        kind=kind,
        source=location,
        previous_offset=previous,
        hybrid_stream_offset=hybrid,
        raw_section=payload(raw),
        trailer=value(trailer, budget),
    )


def _revisions(
    data: bytes, reader: PdfReader, budget: SourceBudget
) -> tuple[PdfXrefRevisionV7, ...]:
    offset: int | None = _startxref(data)
    seen: set[int] = set()
    result: list[PdfXrefRevisionV7] = []
    while offset is not None:
        if offset in seen:
            message = "SOURCE_XREF_PREV_CYCLE"
            raise SourceReadError(message)
        if len(result) >= budget.limits.max_depth:
            message = "SOURCE_XREF_REVISION_DEPTH_LIMIT"
            raise SourceLimitError(message)
        seen.add(offset)
        revision = _revision(data, offset, reader, budget)
        result.append(revision)
        if revision.hybrid_stream_offset is not None:
            hybrid = _revision(data, revision.hybrid_stream_offset, reader, budget)
            if hybrid.offset in seen:
                message = "SOURCE_XREF_HYBRID_CYCLE"
                raise SourceReadError(message)
            result.append(hybrid)
            seen.add(hybrid.offset)
        offset = revision.previous_offset
    return tuple(result)


def _security(reader: PdfReader) -> tuple[Any, PdfObjectSource | None]:
    if "/Encrypt" not in reader.trailer:
        return None, None
    ref = reader.trailer.raw_get("/Encrypt")
    return dictionary(ref), source(ref, "/Trailer/Encrypt")


def _recover_revisions(
    data: bytes, budget: SourceBudget
) -> tuple[tuple[PdfXrefRevisionV7, ...], PdfSourceHistoryRecoveryV7]:
    """Reuse strict keyword recovery while retaining original revision bytes."""
    from document_sdk.pdf._source_objects_v7_history_recovery import (
        recover_history_chain,
    )
    from document_sdk.pdf._xref_keyword_recovery import (
        XrefKeywordRecoveryError,
        recover_classic_xref_keyword,
    )

    parsing = data
    try:
        reader, receipt, offsets = recover_history_chain(data, budget)
    except SourceReadError as original_error:
        try:
            _reader, keyword = recover_classic_xref_keyword(data)
        except XrefKeywordRecoveryError:
            raise original_error from None
        offset = keyword.keyword_offset
        parsing = data[:offset] + b"xref" + data[offset + 4 :]
        reader, receipt, offsets = recover_history_chain(parsing, budget)
        receipt = receipt.model_copy(
            update={"original_sha256": sha256(data).hexdigest()}
        )
    revisions = tuple(
        _revision(parsing, offset, reader, budget, check_offsets=False)
        for offset in offsets
    )
    if parsing != data:
        revisions = tuple(
            revision.model_copy(
                update={
                    "raw_section": payload(
                        data[
                            revision.offset : revision.offset
                            + revision.raw_section.content_size
                        ]
                    )
                }
            )
            for revision in revisions
        )
    return revisions, receipt


def read_file_history(
    data: bytes, reader: PdfReader, budget: SourceBudget
) -> PdfSourceFileHistoryV7:
    """Follow actual /Prev and /XRefStm declarations and preserve raw xref bytes."""
    security, reference = _security(reader)
    mapping = security if security is not None else {}
    revisions: tuple[PdfXrefRevisionV7, ...] = ()
    reasons: tuple[str, ...] = ()
    recovered: tuple[PdfXrefRevisionV7, ...] = ()
    recovery = None
    recovery_reasons: tuple[str, ...] = ()
    recovered_state: Literal["COMPLETE", "INCOMPLETE"] | None = None
    try:
        revisions = _revisions(data, reader, budget)
    except SourceReadError as error:
        reasons = (str(error),)
        recovered_state = "INCOMPLETE"
        try:
            recovered, recovery = _recover_revisions(data, budget)
            recovered_state = "COMPLETE"
        except (SourceReadError, SourceLimitError) as recovery_error:
            recovery_reasons = (str(recovery_error),)
            revisions = _truncated_original_revision(data, budget)
    state: SourceState = "INCOMPLETE" if reasons else "COMPLETE"
    return PdfSourceFileHistoryV7(
        header=data.splitlines()[0].decode("latin-1") if data else "",
        encrypted=bool(reader.is_encrypted),
        encryption_source=reference,
        encryption_filter=field(mapping, "/Filter", budget),
        encryption_subfilter=field(mapping, "/SubFilter", budget),
        encryption_version=int(mapping["/V"]) if "/V" in mapping else None,
        encryption_revision=int(mapping["/R"]) if "/R" in mapping else None,
        encryption_key_bits=int(mapping["/Length"]) if "/Length" in mapping else None,
        crypt_filters=field(mapping, "/CF", budget),
        stream_crypt_filter=field(mapping, "/StmF", budget),
        string_crypt_filter=field(mapping, "/StrF", budget),
        revisions=revisions,
        state=state,
        limitation_codes=reasons,
        recovered_revisions=recovered,
        recovered_state=recovered_state,
        recovery=recovery,
        recovery_limitation_codes=recovery_reasons,
    )


def _truncated_original_revision(
    data: bytes, budget: SourceBudget
) -> tuple[PdfXrefRevisionV7, ...]:
    """Preserve a proved original section without inventing terminal history.

    The partial dictionary is retained as raw original text, not a dictionary
    decoded from synthetic closing markers. The caller keeps INCOMPLETE history
    and no complete recovered-chain receipt.
    """
    from document_sdk.pdf._document_objects_v6 import PdfObjectSource, PdfObjectValue
    from document_sdk.pdf._xref_keyword_recovery import (
        XrefKeywordRecoveryError,
        recover_truncated_classic_trailer,
    )

    try:
        _reader, receipt = recover_truncated_classic_trailer(
            data, charge_object=budget.object
        )
    except XrefKeywordRecoveryError:
        return ()
    budget.object()
    original = data[receipt.keyword_offset :]
    budget.encoded(len(original))
    dictionary_start = data.rfind(b"\ntrailer\n") + len(b"\ntrailer\n")
    return (
        PdfXrefRevisionV7(
            offset=receipt.keyword_offset,
            kind="TABLE",
            source=PdfObjectSource(source_path=f"/File/Xref/{receipt.keyword_offset}"),
            raw_section=payload(original),
            trailer=PdfObjectValue(
                state="PRESENT",
                type_name="truncated_dictionary",
                text=data[dictionary_start:].decode("latin-1"),
            ),
        ),
    )

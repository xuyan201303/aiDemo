"""Private bounded native-text extraction helpers."""

from __future__ import annotations

from typing import TYPE_CHECKING

from document_sdk.pdf._document import enforce_pdf_limit

if TYPE_CHECKING:
    from pypdfium2 import PdfTextPage

    from document_sdk.pdf.models import PdfProcessingLimits


def extract_bounded_page_text(
    text_page: PdfTextPage,
    *,
    characters_so_far: int,
    limits: PdfProcessingLimits,
) -> tuple[str, int]:
    """Extract one page only after its advertised character count fits."""
    advertised_count = text_page.count_chars()
    enforce_pdf_limit(
        "native text characters",
        characters_so_far + advertised_count,
        limits.max_native_text_characters,
    )
    text = text_page.get_text_range(
        index=0,
        count=advertised_count,
    ).replace("\r\n", "\n")
    total_characters = characters_so_far + len(text)
    enforce_pdf_limit(
        "native text characters",
        total_characters,
        limits.max_native_text_characters,
    )
    return text, total_characters

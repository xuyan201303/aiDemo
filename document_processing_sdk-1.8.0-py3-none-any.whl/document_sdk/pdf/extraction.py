"""Local native PDF text extraction."""

from __future__ import annotations

from typing import TYPE_CHECKING

from document_sdk.core import (
    Document,
    DocumentPage,
    PageDimensions,
    PdfSourceReference,
    TextBlock,
)
from document_sdk.pdf._dependencies import require_pdf_support
from document_sdk.pdf._document import (
    enforce_native_text_page_limit,
    inspect_pdf_input,
    open_pdf,
    translate_pdf_errors,
)
from document_sdk.pdf._text import extract_bounded_page_text
from document_sdk.pdf._validation import _validate_pdf_password, _validated_pdf_limits
from document_sdk.pdf.models import (
    PdfProcessingLimits,  # noqa: TC001 - public annotation.
)

if TYPE_CHECKING:
    from pathlib import Path


def extract_native_text(
    path: Path,
    *,
    limits: PdfProcessingLimits | None = None,
    password: str | None = None,
) -> Document:
    """Extract PDFium native text into traceable SDK document models.

    Args:
        path: Local PDF path.
        limits: Optional explicit PDF resource limits.
        password: Explicit runtime-only local PDF password; never stored in results.

    Returns:
        A normalized document with one text block per non-empty page.
    """
    effective_limits = _validated_pdf_limits(limits)
    _validate_pdf_password(password)
    require_pdf_support()
    descriptor = inspect_pdf_input(path, effective_limits)
    document_pages: list[DocumentPage] = []
    native_text_characters = 0

    with (
        translate_pdf_errors(path, "extract native text from"),
        open_pdf(
            path,
            descriptor,
            effective_limits,
            password=password,
            password_supported=True,
        ) as (pdf, preflight),
    ):
        enforce_native_text_page_limit(preflight.page_count, effective_limits)
        for page_index, page_facts in enumerate(preflight.pages):
            page = pdf[page_index]
            try:
                source = PdfSourceReference(
                    file_id=descriptor.file_id,
                    page_number=page_facts.page_number,
                )
                text_page = page.get_textpage()
                try:
                    text, native_text_characters = extract_bounded_page_text(
                        text_page,
                        characters_so_far=native_text_characters,
                        limits=effective_limits,
                    )
                finally:
                    text_page.close()
                blocks = (TextBlock(text=text, source=source),) if text else ()
                document_pages.append(
                    DocumentPage(
                        page_number=page_facts.page_number,
                        dimensions=PageDimensions(
                            width=page_facts.width_points,
                            height=page_facts.height_points,
                            rotation=page_facts.rotation,
                        ),
                        text_blocks=blocks,
                        source=source,
                    )
                )
            finally:
                page.close()

    return Document(file=descriptor, pages=tuple(document_pages))

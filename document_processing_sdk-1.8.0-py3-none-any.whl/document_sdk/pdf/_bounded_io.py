"""Private seekable output buffers with an immediate encoded-byte cap."""

from __future__ import annotations

from io import BytesIO
from typing import TYPE_CHECKING

from document_sdk.pdf.errors import PdfRenderLimitExceededError

if TYPE_CHECKING:
    from collections.abc import Buffer


class CappedPdfBuffer(BytesIO):
    """A seekable in-memory encoder target that fails before an oversized write."""

    def __init__(self, maximum: int) -> None:
        super().__init__()
        self._maximum = maximum
        self._high_water = 0

    def write(self, data: Buffer) -> int:
        observed = max(self._high_water, self.tell() + memoryview(data).nbytes)
        if observed > self._maximum:
            raise PdfRenderLimitExceededError(
                limit_name="output bytes",
                observed=observed,
                maximum=self._maximum,
            )
        written = super().write(data)
        self._high_water = max(self._high_water, self.tell())
        return written

    def truncate(self, size: int | None = None) -> int:
        target = self.tell() if size is None else size
        if target > self._maximum:
            raise PdfRenderLimitExceededError(
                limit_name="output bytes",
                observed=target,
                maximum=self._maximum,
            )
        truncated = super().truncate(size)
        self._high_water = min(self._high_water, truncated)
        return truncated

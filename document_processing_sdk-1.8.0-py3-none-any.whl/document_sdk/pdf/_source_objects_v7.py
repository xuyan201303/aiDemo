"""Exact bounded source declarations added by the opt-in v7 PDF view.

Coordinates and content operators retain PDF user-space semantics. These
records do not promote inferred geometry, decoded text, or object references
into independent proof of physical ownership or author intent.
"""

from __future__ import annotations

from base64 import b64decode
from binascii import Error as Base64Error
from hashlib import sha256
from typing import Literal, Self

from pydantic import Field, model_validator

from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.core.models import SdkModel
from document_sdk.pdf._document_objects_v6 import PdfObjectSource, PdfObjectValue

type SourceChannelName = Literal[
    "page_boxes", "images", "graphics", "text_state", "file_history"
]
type SourceState = Literal["COMPLETE", "ABSENT", "INCOMPLETE", "LIMITED", "UNSUPPORTED"]
type Matrix = tuple[float, float, float, float, float, float]
type Box = tuple[float, float, float, float]


class PdfSourceObjectLimitsV7(SdkModel):
    """Finite source decoding, traversal, and operation budgets per document."""

    max_objects: int = Field(default=20_000, ge=1)
    max_operations: int = Field(default=200_000, ge=1)
    max_depth: int = Field(default=32, ge=1, le=128)
    max_encoded_bytes: int = Field(default=128 * 1_048_576, ge=1)
    max_decoded_bytes: int = Field(default=128 * 1_048_576, ge=1)
    max_image_pixels: int = Field(default=16_777_216, ge=1)


class PdfSourcePayloadV7(SdkModel):
    """Complete bytes with their exact byte-count and digest, never a preview."""

    content_base64: str
    content_size: int = Field(ge=0)
    content_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_bytes(self) -> Self:
        """Reject altered public size, digest, or content declarations."""
        try:
            raw = b64decode(self.content_base64, validate=True)
        except (ValueError, Base64Error) as error:
            message = "source payload base64 is invalid"
            _raise_redacted_translation(error, ValueError(message))
        if (
            len(raw) != self.content_size
            or sha256(raw).hexdigest() != self.content_sha256
        ):
            message = "source payload byte count or digest mismatch"
            raise ValueError(message)
        return self


class PdfSourceChannelV7(SdkModel):
    """Completeness of one source inventory, including explicit extraction gaps."""

    name: SourceChannelName
    state: SourceState
    limitation_codes: tuple[str, ...] = ()


class PdfPageBoxDeclarationV7(SdkModel):
    """A raw page-box declaration and separately specified effective default."""

    name: Literal["MediaBox", "CropBox", "ArtBox", "BleedBox", "TrimBox"]
    source: PdfObjectSource
    declaration_state: Literal["MISSING", "NULL", "PRESENT", "UNSUPPORTED"]
    raw_coordinates: Box | None
    effective_coordinates: Box | None
    effective_basis: Literal[
        "DECLARED", "INHERITED", "MEDIA_BOX_DEFAULT", "CROP_BOX_DEFAULT", "UNAVAILABLE"
    ]
    coordinate_basis: Literal["UNROTATED_PDF_USER_SPACE_BEFORE_USER_UNIT"] = (
        "UNROTATED_PDF_USER_SPACE_BEFORE_USER_UNIT"
    )


class PdfSourcePageBoxesV7(SdkModel):
    """Raw page coordinates with rotation and UserUnit kept as separate values."""

    page_number: int = Field(ge=1)
    page_source: PdfObjectSource
    user_unit: float = Field(gt=0)
    rotation: int
    boxes: tuple[PdfPageBoxDeclarationV7, ...]


class PdfContentLocatorV7(SdkModel):
    """One content operation occurrence, including repeated Form invocations."""

    page_number: int = Field(ge=1)
    stream_source: PdfObjectSource
    operator_index: int = Field(ge=0)
    invocation_path: tuple[PdfObjectSource, ...] = ()
    invocation_indices: tuple[int, ...] = ()


class PdfSourceStreamRecoveryV7(SdkModel):
    """An original-byte envelope, not a repaired exact PDF /Length declaration."""

    method: Literal["XREF_BOUND_UNFILTERED_STREAM_ENVELOPE_RECOVERY_V1"] = (
        "XREF_BOUND_UNFILTERED_STREAM_ENVELOPE_RECOVERY_V1"
    )
    original_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    object_offset: int = Field(ge=0)
    next_object_offset: int = Field(ge=0)
    next_object: PdfObjectSource
    xref_binding_basis: Literal[
        "BACKEND_XREF_OFFSETS_VERIFIED_AGAINST_UNIQUE_ORIGINAL_HEADERS"
    ] = "BACKEND_XREF_OFFSETS_VERIFIED_AGAINST_UNIQUE_ORIGINAL_HEADERS"
    declared_length: int = Field(ge=0)
    original_dictionary_base64: str
    dictionary_state: Literal["COMMENT_HIDDEN_CLOSER"] = "COMMENT_HIDDEN_CLOSER"
    payload_start: int = Field(ge=0)
    payload_end: int = Field(ge=0)
    boundary_state: Literal["RECOVERED_TRAILING_EOL_UNRESOLVED"] = (
        "RECOVERED_TRAILING_EOL_UNRESOLVED"
    )
    limitation_codes: tuple[str, ...] = (
        "SOURCE_STREAM_ORIGINAL_LENGTH_INVALID",
        "SOURCE_STREAM_RECOVERED_TRAILING_EOL_UNRESOLVED",
    )


class PdfSourceContentStreamV7(SdkModel):
    """Source encoded and decoded stream bytes with their real filter declaration."""

    source: PdfObjectSource
    filters: PdfObjectValue
    decode_parameters: PdfObjectValue
    encoded: PdfSourcePayloadV7
    decoded: PdfSourcePayloadV7 | None
    decoding_state: SourceState
    encoding_basis: Literal[
        "AFTER_PDF_SECURITY_HANDLER", "RECOVERED_ORIGINAL_INPUT_BYTE_RANGE"
    ] = "AFTER_PDF_SECURITY_HANDLER"
    recovery: PdfSourceStreamRecoveryV7 | None = None

    @model_validator(mode="after")
    def validate_recovery_binding(self) -> Self:
        """Keep recovered envelopes separate from normal declared stream bytes."""
        receipt = self.recovery
        recovered = self.encoding_basis == "RECOVERED_ORIGINAL_INPUT_BYTE_RANGE"
        if recovered != (receipt is not None):
            message = "source stream recovery basis and receipt disagree"
            raise ValueError(message)
        if receipt is not None and not (
            receipt.object_offset
            < receipt.payload_start
            <= receipt.payload_end
            < receipt.next_object_offset
            and receipt.payload_end - receipt.payload_start == self.encoded.content_size
        ):
            message = "source stream recovered payload range is inconsistent"
            raise ValueError(message)
        return self


class PdfFormInvocationV7(SdkModel):
    """A Form call occurrence, separate from its reusable source resource."""

    locator: PdfContentLocatorV7
    resource_name: str
    form_source: PdfObjectSource
    matrix: Matrix
    effective_ctm: Matrix
    raw_bbox: Box | None


class PdfImageOccurrenceV7(SdkModel):
    """Image samples and encoding from the source object, not a page screenshot."""

    locator: PdfContentLocatorV7
    kind: Literal["XOBJECT", "INLINE"]
    resource_name: str | None
    source: PdfObjectSource
    width: int = Field(ge=1)
    height: int = Field(ge=1)
    bits_per_component: int | None = Field(default=None, ge=1)
    colorspace: PdfObjectValue
    filters: PdfObjectValue
    decode_parameters: PdfObjectValue
    image_dictionary: PdfObjectValue
    encoded: PdfSourcePayloadV7
    decoded_samples: PdfSourcePayloadV7 | None
    sample_layout: Literal[
        "RGB", "GRAY", "CMYK", "PACKED_SOURCE_SAMPLES", "UNAVAILABLE"
    ]
    decoding_state: SourceState
    ctm: Matrix
    unit_square_corners: tuple[tuple[float, float], ...]
    encoding_basis: Literal["AFTER_PDF_SECURITY_HANDLER"] = "AFTER_PDF_SECURITY_HANDLER"


class PdfSourceFontV7(SdkModel):
    """Original font resource declarations and complete supported CMap bytes."""

    source: PdfObjectSource
    resource_name: str
    subtype: PdfObjectValue
    base_font: PdfObjectValue
    encoding: PdfObjectValue
    encoding_source: PdfObjectSource | None = None
    to_unicode_source: PdfObjectSource | None
    to_unicode_encoded: PdfSourcePayloadV7 | None
    to_unicode_decoded: PdfSourcePayloadV7 | None
    to_unicode_state: SourceState
    to_unicode_filters: PdfObjectValue = PdfObjectValue(state="MISSING")
    to_unicode_decode_parameters: PdfObjectValue = PdfObjectValue(state="MISSING")
    font_dictionary: PdfObjectValue
    char_procedures: tuple[PdfSourceContentStreamV7, ...] = ()


class PdfSourcePathOperatorV7(SdkModel):
    """One original path construction operator with unmodified numeric operands."""

    locator: PdfContentLocatorV7
    operator: str
    operands: tuple[float, ...]
    ctm: Matrix


class PdfSourceGraphicsStateV7(SdkModel):
    """State effective at a source paint operation without inferred geometry."""

    ctm: Matrix
    line_width: float
    dash_array: tuple[float, ...]
    dash_phase: float
    line_cap: int
    line_join: int
    miter_limit: float
    stroke_alpha: float
    fill_alpha: float
    blend_mode: PdfObjectValue
    stroke_color: tuple[float, ...]
    fill_color: tuple[float, ...]
    stroke_colorspace: str
    fill_colorspace: str
    active_clip_ids: tuple[str, ...]
    unsupported_state_operators: tuple[str, ...] = ()


class PdfSourcePathPaintV7(SdkModel):
    """A complete compound path tied to its paint operator and graphics state."""

    locator: PdfContentLocatorV7
    operator: str
    path: tuple[PdfSourcePathOperatorV7, ...]
    fill_rule: Literal["NONZERO", "EVEN_ODD", "NOT_FILLED"]
    state: PdfSourceGraphicsStateV7


class PdfSourceClipV7(SdkModel):
    """A clipping path declaration and the operation that installs its scope."""

    clip_id: str
    locator: PdfContentLocatorV7
    activation_locator: PdfContentLocatorV7
    path: tuple[PdfSourcePathOperatorV7, ...]
    fill_rule: Literal["NONZERO", "EVEN_ODD"]
    kind: Literal["CONTENT_PATH", "FORM_BBOX"] = "CONTENT_PATH"
    raw_bbox: Box | None = None
    bbox_source: PdfObjectSource | None = None


class PdfMarkedSourceScopeV7(SdkModel):
    """A marked-content tag and its original property/resource reference."""

    tag: str
    properties: PdfObjectValue
    property_source: PdfObjectSource | None = None


class PdfSourceTextStateV7(SdkModel):
    """Text-show state; declared matrix is not an inferred post-glyph advance."""

    locator: PdfContentLocatorV7
    operator: str
    operands: tuple[PdfObjectValue, ...]
    font_source: PdfObjectSource | None
    font_resource_name: str | None
    nominal_font_size: float
    character_spacing: float
    word_spacing: float
    horizontal_scale_percent: float
    leading: float
    rendering_mode: int
    rise: float
    declared_text_matrix: Matrix | None
    positioning_operators: tuple[str, ...]
    ctm: Matrix
    active_clip_ids: tuple[str, ...]
    marked_scopes: tuple[PdfMarkedSourceScopeV7, ...]
    matrix_basis: Literal["LAST_DECLARED_TM_WITH_POSITIONING_HISTORY"] = (
        "LAST_DECLARED_TM_WITH_POSITIONING_HISTORY"
    )


class PdfXrefRevisionV7(SdkModel):
    """An independently verified original xref section and its declarations.

    In INCOMPLETE history this need not belong to a terminal-linked chain.
    Synthetic parser-view delimiters are never part of its original bytes.
    """

    offset: int = Field(ge=0)
    kind: Literal["TABLE", "STREAM"]
    source: PdfObjectSource
    previous_offset: int | None = Field(default=None, ge=0)
    hybrid_stream_offset: int | None = Field(default=None, ge=0)
    raw_section: PdfSourcePayloadV7
    trailer: PdfObjectValue


class PdfRecoveredXrefEntryV7(SdkModel):
    """One original classic-table row, including free entries and generations."""

    revision_offset: int = Field(ge=0)
    object_number: int = Field(ge=0)
    generation: int = Field(ge=0, le=65535)
    offset: int = Field(ge=0)
    in_use: bool
    resolved_offset: int | None = Field(default=None, ge=0)


class PdfSourceHistoryRecoveryV7(SdkModel):
    """Verified original table chain, separate from an invalid startxref claim."""

    method: Literal[
        "ORIGINAL_CLASSIC_XREF_CHAIN_RECOVERY_V1",
        "ORIGINAL_CLASSIC_XREF_CHAIN_RECOVERY_V2",
    ] = "ORIGINAL_CLASSIC_XREF_CHAIN_RECOVERY_V1"
    original_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    declared_startxref: int = Field(ge=0)
    declaration_start: int = Field(ge=0)
    declaration_end: int = Field(ge=0)
    recovered_startxref: int = Field(ge=0)
    entries: tuple[PdfRecoveredXrefEntryV7, ...]


class PdfSourceFileHistoryV7(SdkModel):
    """Current security declarations and independently verified original sections.

    COMPLETE history describes a terminal-linked revision chain. INCOMPLETE
    history may retain verified original xref sections without terminal
    declarations; parser-view repairs do not supply original history evidence.
    """

    header: str
    encrypted: bool
    encryption_source: PdfObjectSource | None
    encryption_filter: PdfObjectValue
    encryption_subfilter: PdfObjectValue
    encryption_version: int | None
    encryption_revision: int | None
    encryption_key_bits: int | None
    crypt_filters: PdfObjectValue
    stream_crypt_filter: PdfObjectValue
    string_crypt_filter: PdfObjectValue
    revisions: tuple[PdfXrefRevisionV7, ...]
    state: SourceState
    limitation_codes: tuple[str, ...] = ()
    recovered_revisions: tuple[PdfXrefRevisionV7, ...] = ()
    recovered_state: Literal["COMPLETE", "INCOMPLETE"] | None = None
    recovery: PdfSourceHistoryRecoveryV7 | None = None
    recovery_limitation_codes: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_recovered_inventory(self) -> Self:
        """Do not let a recovery receipt rewrite the original declaration state."""
        if self.recovery is None:
            if self.recovered_revisions or self.recovered_state == "COMPLETE":
                message = "recovered history requires its original-byte receipt"
                raise ValueError(message)
            return self
        offsets = tuple(revision.offset for revision in self.recovered_revisions)
        identities = tuple(
            (entry.revision_offset, entry.object_number)
            for entry in self.recovery.entries
        )
        if (
            self.state != "INCOMPLETE"
            or self.recovered_state != "COMPLETE"
            or not offsets
            or offsets[0] != self.recovery.recovered_startxref
            or len(set(offsets)) != len(offsets)
            or len(set(identities)) != len(identities)
            or {entry.revision_offset for entry in self.recovery.entries}
            != set(offsets)
            or self.recovery.declaration_start >= self.recovery.declaration_end
            or self.recovery_limitation_codes
        ):
            message = "recovered history inventory or declaration binding differs"
            raise ValueError(message)
        return self


class PdfSourceObjectsV7(SdkModel):
    """Additive source-output channels that retain exact input content identity."""

    schema_version: Literal["document_sdk.pdf.source_objects.v1"] = (
        "document_sdk.pdf.source_objects.v1"
    )
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    channels: tuple[PdfSourceChannelV7, ...]
    page_boxes: tuple[PdfSourcePageBoxesV7, ...] = ()
    images: tuple[PdfImageOccurrenceV7, ...] = ()
    path_paints: tuple[PdfSourcePathPaintV7, ...] = ()
    clips: tuple[PdfSourceClipV7, ...] = ()
    text_states: tuple[PdfSourceTextStateV7, ...] = ()
    fonts: tuple[PdfSourceFontV7, ...] = ()
    form_invocations: tuple[PdfFormInvocationV7, ...] = ()
    content_streams: tuple[PdfSourceContentStreamV7, ...] = ()
    file_history: PdfSourceFileHistoryV7 | None = None

    @model_validator(mode="after")
    def validate_inventory(self) -> Self:
        """Require one explicit state for each new output capability."""
        names = tuple(channel.name for channel in self.channels)
        required = {"page_boxes", "images", "graphics", "text_state", "file_history"}
        if len(names) != len(required) or set(names) != required:
            message = "source output channel inventory is incomplete or duplicated"
            raise ValueError(message)
        if (
            self.file_history is not None
            and self.file_history.recovery is not None
            and self.file_history.recovery.original_sha256 != self.source_sha256
        ):
            message = "recovered history input identity differs"
            raise ValueError(message)
        return self


def extract_source_objects(
    data: bytes,
    password: str | None,
    *,
    limits: PdfSourceObjectLimitsV7 | None = None,
) -> PdfSourceObjectsV7:
    """Read source bytes using existing local dependencies and finite budgets."""
    from document_sdk.pdf._source_objects_v7_reader import read_source_objects

    return read_source_objects(data, password, _checked_limits(limits))


def _checked_limits(limits: object) -> PdfSourceObjectLimitsV7:
    """Revalidate caller limits at the public boundary, including constructed models."""
    if limits is not None and not isinstance(limits, PdfSourceObjectLimitsV7):
        message = "source output limits must be PdfSourceObjectLimitsV7"
        raise TypeError(message)
    return (
        PdfSourceObjectLimitsV7.model_validate_json(limits.model_dump_json())
        if limits is not None
        else PdfSourceObjectLimitsV7()
    )


PdfSourceObjectsV7.model_rebuild(
    _types_namespace={
        "PdfObjectSource": PdfObjectSource,
        "PdfObjectValue": PdfObjectValue,
    }
)

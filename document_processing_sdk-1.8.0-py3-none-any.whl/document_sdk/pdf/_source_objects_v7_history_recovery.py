"""Recover only complete classic xref chains bound to original object offsets.

The invalid terminal declaration is never edited in the caller's input. A strict
backend view uses a temporary terminal offset only after independent row/header
and chain checks; its source sections still come from the original bytes.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from hashlib import sha256
from io import BytesIO
from typing import TYPE_CHECKING

from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.pdf._source_objects_v7 import (
    PdfRecoveredXrefEntryV7,
    PdfSourceHistoryRecoveryV7,
)
from document_sdk.pdf._source_objects_v7_values import SourceReadError

if TYPE_CHECKING:
    from typing import Never

    from pypdf import PdfReader

    from document_sdk.pdf._source_objects_v7_values import SourceBudget

_WHITESPACE = b"\x00\t\n\x0c\r "
_TERMINAL = re.compile(rb"startxref\s+([0-9]+)\s+%%EOF[\r\n\t ]*\Z")
_MARKER = re.compile(rb"(?m)^xref[\t ]*(?:\r\n|\n|\r)")
_HEADER = re.compile(rb"(?m)^([0-9]+)[\t ]+([0-9]+)[\t ]+obj(?:[\r\n\t ])")
_ROW = re.compile(rb"([0-9]{10}) ([0-9]{5}) ([nf])(?:[ \r\n]*)\Z")
_TRAILER_KEYS = frozenset((b"/Size", b"/Root", b"/Info", b"/Prev"))
_REFERENCE_KEYS = frozenset((b"/Root", b"/Info"))
_REFERENCE_WIDTH = 3
_SUBSECTION_WIDTH = 2
_MAX_LINE = 128
_FREE_GENERATION = 65535


@dataclass(frozen=True)
class _Section:
    offset: int
    end: int
    entries: tuple[PdfRecoveredXrefEntryV7, ...]
    trailer: dict[bytes, tuple[int, ...]]


def _reject(reason: str) -> Never:
    raise SourceReadError("SOURCE_HISTORY_RECOVERY_" + reason)


def _line(stream: BytesIO) -> bytes:
    line = stream.readline(_MAX_LINE)
    if not line or len(line) >= _MAX_LINE:
        _reject("TABLE_TRUNCATED_OR_LIMITED")
    return line.strip()


def _trailer(stream: BytesIO) -> dict[bytes, tuple[int, ...]]:
    start = stream.tell()
    raw = stream.getvalue()
    end = raw.find(b">>", start)
    if end < 0:
        _reject("TRAILER_TRUNCATED")
    tokens = raw[start : end + 2].split()
    if not tokens or tokens[0] != b"<<" or tokens[-1] != b">>":
        _reject("TRAILER_UNSUPPORTED")
    result: dict[bytes, tuple[int, ...]] = {}
    index = 1
    while index < len(tokens) - 1:
        key = tokens[index]
        if key not in _TRAILER_KEYS or key in result:
            _reject("TRAILER_UNSUPPORTED_OR_DUPLICATE")
        width = _REFERENCE_WIDTH if key in _REFERENCE_KEYS else 1
        values = tokens[index + 1 : index + width + 1]
        numeric = values[:-1] if width == _REFERENCE_WIDTH else values
        if (
            len(values) != width
            or not all(item.isdigit() for item in numeric)
            or (width == _REFERENCE_WIDTH and values[-1] != b"R")
        ):
            _reject("TRAILER_INVALID")
        result[key] = tuple(int(item) for item in numeric)
        index += width + 1
    if b"/Size" not in result:
        _reject("TRAILER_SIZE_MISSING")
    stream.seek(end + 2)
    return result


def _rows(
    data: bytes,
    stream: BytesIO,
    offset: int,
    budget: SourceBudget,
    headers: dict[tuple[int, int], list[int]],
) -> tuple[PdfRecoveredXrefEntryV7, ...]:
    result: list[PdfRecoveredXrefEntryV7] = []
    seen: set[int] = set()
    while True:
        position = stream.tell()
        line = _line(stream)
        if line == b"trailer":
            return tuple(result)
        tokens = line.split()
        if len(tokens) != _SUBSECTION_WIDTH or not all(
            item.isdigit() for item in tokens
        ):
            _reject("SUBSECTION_INVALID")
        start, count = (int(item) for item in tokens)
        if count <= 0 or count > budget.limits.max_objects - len(result):
            _reject("ENTRY_LIMIT")
        for number in range(start, start + count):
            budget.object()
            row = _ROW.fullmatch(_line(stream))
            if row is None or number in seen:
                _reject("ENTRY_INVALID_OR_DUPLICATE")
            seen.add(number)
            location, generation = int(row[1]), int(row[2])
            in_use = row[3] == b"n"
            resolved = None
            if in_use:
                header = _HEADER.match(data, location)
                if (
                    location >= offset
                    or header is None
                    or (int(header[1]), int(header[2])) != (number, generation)
                ):
                    resolved = _unique_header(
                        data, (number, generation), offset, budget, headers
                    )
            result.append(
                PdfRecoveredXrefEntryV7(
                    revision_offset=offset,
                    object_number=number,
                    generation=generation,
                    offset=location,
                    in_use=in_use,
                    resolved_offset=resolved,
                )
            )
        if stream.tell() <= position:
            _reject("TABLE_NO_PROGRESS")


def _unique_header(
    data: bytes,
    identity: tuple[int, int],
    revision: int,
    budget: SourceBudget,
    headers: dict[tuple[int, int], list[int]],
) -> int:
    """Resolve a stale row only through one bounded, exact original header."""
    if not headers:
        for count, match in enumerate(_HEADER.finditer(data), 1):
            if count > budget.limits.max_objects:
                _reject("HEADER_INVENTORY_LIMIT")
            headers.setdefault((int(match[1]), int(match[2])), []).append(match.start())
    candidates = headers.get(identity, [])
    if len(candidates) != 1 or candidates[0] >= revision:
        _reject("OBJECT_OFFSET_OR_GENERATION_CONFLICT")
    return candidates[0]


def _section(
    data: bytes,
    offset: int,
    budget: SourceBudget,
    headers: dict[tuple[int, int], list[int]],
) -> _Section:
    stream = BytesIO(data)
    stream.seek(offset)
    if _line(stream) != b"xref":
        _reject("MARKER_INVALID")
    entries = _rows(data, stream, offset, budget, headers)
    trailer = _trailer(stream)
    if not 0 < trailer[b"/Size"][0] <= budget.limits.max_objects:
        _reject("SIZE_OUTSIDE_LIMIT")
    return _Section(offset, stream.tell(), entries, trailer)


def _chain(
    sections: dict[int, _Section], terminal: _Section, budget: SourceBudget
) -> tuple[_Section, ...]:
    result: list[_Section] = []
    seen: set[int] = set()
    section = terminal
    while True:
        if section.offset in seen or len(result) >= budget.limits.max_depth:
            _reject("PREV_CYCLE_OR_DEPTH")
        seen.add(section.offset)
        result.append(section)
        previous = section.trailer.get(b"/Prev")
        if previous is None:
            break
        if previous[0] >= section.offset:
            _reject("PREV_NOT_EARLIER_REVISION")
        if previous[0] not in sections:
            _reject("PREV_UNRESOLVED")
        section = sections[previous[0]]
    if seen != set(sections):
        _reject("UNLINKED_OR_AMBIGUOUS_TABLE")
    return tuple(result)


def _reference_inventory(sections: tuple[_Section, ...]) -> None:
    active: dict[int, PdfRecoveredXrefEntryV7] = {}
    inherited: dict[bytes, tuple[int, ...]] = {}
    for section in reversed(sections):
        active.update((entry.object_number, entry) for entry in section.entries)
        for key in _REFERENCE_KEYS:
            if key in section.trailer:
                inherited[key] = section.trailer[key]
        if b"/Root" not in inherited:
            _reject("ROOT_MISSING")
        for number, generation in inherited.values():
            entry = active.get(number)
            if entry is None or not entry.in_use or entry.generation != generation:
                _reject("TRAILER_REFERENCE_CONFLICT")


def _inventory(data: bytes, sections: tuple[_Section, ...]) -> None:
    active: dict[int, PdfRecoveredXrefEntryV7] = {}
    offsets: set[tuple[int, int, int]] = set()
    size = sections[0].trailer[b"/Size"][0]
    for section in sections:
        if section.trailer[b"/Size"][0] > size:
            _reject("SIZE_CONFLICT")
        for entry in section.entries:
            active.setdefault(entry.object_number, entry)
            if entry.in_use:
                offsets.add((entry.object_number, entry.generation, _resolved(entry)))
    if set(active) != set(range(size)):
        _reject("OBJECT_INVENTORY_INCOMPLETE")
    zero = active[0]
    if zero.in_use or zero.generation != _FREE_GENERATION:
        _reject("FREE_ENTRY_INVALID")
    actual_headers = {
        (int(match[1]), int(match[2]), match.start())
        for match in _HEADER.finditer(data)
    }
    if actual_headers != offsets:
        _reject("OBJECT_HEADERS_UNBOUND_OR_AMBIGUOUS")
    _reference_inventory(sections)


def _object_range(
    data: bytes, reader: PdfReader, entry: PdfRecoveredXrefEntryV7, budget: SourceBudget
) -> int:
    from pypdf.errors import PdfReadError
    from pypdf.generic import IndirectObject, read_object

    from document_sdk.pdf._source_objects_v7_values import recover_content_stream

    stream = BytesIO(data)
    stream.seek(_resolved(entry))
    if reader.read_object_header(stream) != (entry.object_number, entry.generation):
        _reject("REFERENCE_HEADER_CONFLICT")
    try:
        read_object(stream, reader)
    except PdfReadError:
        # Reuse the existing uniquely xref-bound original stream envelope rule.
        _, receipt = recover_content_stream(
            reader,
            IndirectObject(entry.object_number, entry.generation, reader),
            budget,
            data,
        )
        return (
            data.index(b"endobj", receipt.payload_end, receipt.next_object_offset) + 6
        )
    while stream.read(1) in _WHITESPACE:
        if stream.tell() >= len(data):
            _reject("OBJECT_TRUNCATED")
    stream.seek(-1, 1)
    if stream.read(6) != b"endobj":
        _reject("OBJECT_TERMINATOR_INVALID")
    return stream.tell()


def _strict_reader(
    data: bytes,
    terminal_start: int,
    recovered_offset: int,
    sections: tuple[_Section, ...],
    budget: SourceBudget,
) -> PdfReader:
    from pypdf import PdfReader
    from pypdf.errors import PdfReadError
    from pypdf.generic import DictionaryObject

    repaired = bytearray(data[:terminal_start])
    for section in sections:
        _repair_rows(repaired, section)
    repaired.extend(f"startxref\n{recovered_offset}\n%%EOF\n".encode())
    try:
        reader = PdfReader(BytesIO(repaired), strict=True)
        if reader.is_encrypted:
            _reject("ENCRYPTION_UNSUPPORTED")
        _object_boundaries(data, reader, sections, budget)
        root = reader.trailer.raw_get("/Root").get_object()
        if not isinstance(root, DictionaryObject) or root.get("/Type") != "/Catalog":
            _reject("ROOT_NOT_CATALOG")
    except PdfReadError as error:
        message = "SOURCE_HISTORY_RECOVERY_STRICT_VALIDATION_FAILED"
        _raise_redacted_translation(error, SourceReadError(message))
    return reader


def _object_boundaries(
    data: bytes, reader: PdfReader, sections: tuple[_Section, ...], budget: SourceBudget
) -> None:
    ranges: dict[int, int] = {}
    for section in sections:
        for entry in section.entries:
            location = _resolved(entry)
            if entry.in_use and location not in ranges:
                ranges[location] = _object_range(data, reader, entry, budget)
    previous_end = 0
    for offset, end in sorted(ranges.items()):
        if offset < previous_end:
            _reject("OVERLAPPING_OBJECT_RANGES")
        if any(offset < section.offset < end for section in sections):
            _reject("XREF_INSIDE_OBJECT")
        previous_end = end


def _resolved(entry: PdfRecoveredXrefEntryV7) -> int:
    """Keep original row offsets distinct from resolved original header positions."""
    return entry.offset if entry.resolved_offset is None else entry.resolved_offset


def _repair_rows(repaired: bytearray, section: _Section) -> None:
    """Repair only row offset digits in the private strict backend view."""
    stream = BytesIO(repaired)
    stream.seek(section.offset)
    _line(stream)
    for entry in section.entries:
        if _ROW.fullmatch(_line(stream)) is None:
            _line(stream)
        if entry.resolved_offset is not None:
            end = stream.tell()
            row_start = bytes(repaired).rfind(b"\n", section.offset, end - 1) + 1
            repaired[row_start : row_start + 10] = (
                f"{entry.resolved_offset:010d}".encode()
            )


def recover_history_chain(
    data: bytes,
    budget: SourceBudget,
) -> tuple[PdfReader, PdfSourceHistoryRecoveryV7, tuple[int, ...]]:
    """Return a uniquely bound original classic chain, not a repaired declaration."""
    if len(data) > budget.limits.max_encoded_bytes:
        _reject("INPUT_LIMIT")
    declaration = _TERMINAL.search(data)
    if declaration is None:
        _reject("TERMINAL_DECLARATION_UNSUPPORTED")
    offsets = [match.start() for match in _MARKER.finditer(data)]
    if not offsets or len(offsets) > budget.limits.max_depth:
        _reject("MARKER_INVENTORY_UNAVAILABLE_OR_LIMITED")
    headers: dict[tuple[int, int], list[int]] = {}
    sections = {offset: _section(data, offset, budget, headers) for offset in offsets}
    terminal = [
        section
        for section in sections.values()
        if not data[section.end : declaration.start()].strip(_WHITESPACE)
        and section.end <= declaration.start()
    ]
    if len(terminal) != 1:
        _reject("TERMINAL_TABLE_AMBIGUOUS")
    chain = _chain(sections, terminal[0], budget)
    _inventory(data, chain)
    reader = _strict_reader(data, declaration.start(), chain[0].offset, chain, budget)
    receipt = PdfSourceHistoryRecoveryV7(
        method=(
            "ORIGINAL_CLASSIC_XREF_CHAIN_RECOVERY_V2"
            if any(
                entry.resolved_offset is not None
                for section in chain
                for entry in section.entries
            )
            else "ORIGINAL_CLASSIC_XREF_CHAIN_RECOVERY_V1"
        ),
        original_sha256=sha256(data).hexdigest(),
        declared_startxref=int(declaration[1]),
        declaration_start=declaration.start(),
        declaration_end=declaration.end(),
        recovered_startxref=chain[0].offset,
        entries=tuple(entry for section in chain for entry in section.entries),
    )
    return reader, receipt, tuple(section.offset for section in chain)

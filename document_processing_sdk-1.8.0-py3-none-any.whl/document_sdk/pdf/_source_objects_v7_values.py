"""Bounded PDF backend conversion and exact stream-byte retention for v7."""

from __future__ import annotations

import json
import math
import re
import zlib
from base64 import a85decode, b64encode
from dataclasses import dataclass
from hashlib import sha256
from typing import TYPE_CHECKING

from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.pdf._document_objects_v6 import PdfObjectSource, PdfObjectValue
from document_sdk.pdf._source_objects_v7 import (
    PdfSourcePayloadV7,
    PdfSourceStreamRecoveryV7,
)

if TYPE_CHECKING:
    from io import BytesIO
    from typing import IO, Any

    from pypdf import PdfReader

    from document_sdk.pdf._source_objects_v7 import (
        Box,
        Matrix,
        PdfSourceObjectLimitsV7,
    )

IDENTITY: Matrix = (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)
_BOX_SIZE = 4
_MATRIX_SIZE = 6
_MAX_BYTE = 256
_RUN_LITERAL_MAX = 127
_RUN_END = 128
_OBJECT_HEADER = re.compile(
    rb"(?m)^([0-9]+)[ \t]+([0-9]+)[ \t]+obj[ \t]*(?:\r\n|\r|\n)"
)
_RECOVERY_LENGTH_DIGITS = 18


class SourceReadError(Exception):
    """An unsupported, malformed, or incomplete source declaration."""


class SourceLimitError(Exception):
    """An explicit finite source-output extraction budget was exhausted."""


@dataclass
class SourceBudget:
    """Charge source work before accumulating public bytes or operator records."""

    limits: PdfSourceObjectLimitsV7
    objects: int = 0
    operations: int = 0
    encoded_bytes: int = 0
    decoded_bytes: int = 0

    def object(self) -> None:
        """Charge one source object or structured value."""
        self.objects += 1
        if self.objects > self.limits.max_objects:
            message = "SOURCE_OBJECT_COUNT_LIMIT"
            raise SourceLimitError(message)

    def operation(self) -> None:
        """Charge one content operation, including repeated Form occurrences."""
        self.operations += 1
        if self.operations > self.limits.max_operations:
            message = "SOURCE_CONTENT_OPERATION_LIMIT"
            raise SourceLimitError(message)

    def encoded(self, size: int) -> None:
        """Charge retained encoded bytes before constructing their public payload."""
        self.encoded_bytes += size
        if self.encoded_bytes > self.limits.max_encoded_bytes:
            message = "SOURCE_ENCODED_BYTES_LIMIT"
            raise SourceLimitError(message)

    def decoded(self, size: int) -> None:
        """Charge complete decoded bytes before retaining them."""
        self.decoded_bytes += size
        if self.decoded_bytes > self.limits.max_decoded_bytes:
            message = "SOURCE_DECODED_BYTES_LIMIT"
            raise SourceLimitError(message)


def resolve(value: Any) -> Any:
    """Resolve a local PDF indirect object without importing a parser globally."""
    from pypdf.generic import IndirectObject

    return value.get_object() if isinstance(value, IndirectObject) else value


def dictionary(value: Any) -> Any:
    """Require a real dictionary from the local backend boundary."""
    from pypdf.generic import DictionaryObject

    resolved = resolve(value)
    if isinstance(resolved, dict) and not isinstance(resolved, DictionaryObject):
        resolved = DictionaryObject(resolved)
    if not isinstance(resolved, DictionaryObject):
        message = "SOURCE_DICTIONARY_UNAVAILABLE"
        raise SourceReadError(message)
    return resolved


def _declaration_token(stream: IO[bytes] | BytesIO) -> bytes:
    token = stream.read(1)
    while token and token in b"\x00\t\n\x0c\r %":
        if token == b"%":
            while token not in (b"\r", b"\n", b""):
                token = stream.read(1)
        token = stream.read(1)
    return token


def read_dictionary_declaration(
    stream: IO[bytes] | BytesIO, reader: PdfReader, budget: SourceBudget
) -> Any:
    """Read dictionary tokens without consuming its following stream or /Length."""
    from pypdf.generic import DictionaryObject, NameObject, read_object

    token = _declaration_token(stream)
    if token != b"<" or stream.read(1) != b"<":
        message = "SOURCE_STREAM_DICTIONARY_DECLARATION_UNAVAILABLE"
        raise SourceReadError(message)
    result = DictionaryObject()
    while True:
        token = _declaration_token(stream)
        if token == b">" and stream.read(1) == b">":
            return result
        if not token:
            message = "SOURCE_STREAM_DICTIONARY_DECLARATION_TRUNCATED"
            raise SourceReadError(message)
        budget.object()
        stream.seek(-1, 1)
        key = read_object(stream, reader)
        if not isinstance(key, NameObject) or key in result:
            message = "SOURCE_STREAM_DICTIONARY_KEY_INVALID_OR_DUPLICATE"
            raise SourceReadError(message)
        if not _declaration_token(stream):
            message = "SOURCE_STREAM_DICTIONARY_DECLARATION_TRUNCATED"
            raise SourceReadError(message)
        stream.seek(-1, 1)
        result[key] = read_object(stream, reader)


def retain_stream_length(mapping: Any, declaration: Any) -> Any:
    """Retain only the original /Length field lost by backend stream conversion."""
    from pypdf.generic import DictionaryObject, NameObject

    result = DictionaryObject(dict(mapping.items()))
    if "/Length" in declaration:
        result[NameObject("/Length")] = declaration.raw_get("/Length")
    return result


def stream_dictionary(
    mapping: Any, reference: Any, reader: PdfReader, budget: SourceBudget
) -> Any:
    """Restore a source stream declaration using its exact bound xref location."""
    from pypdf.generic import IndirectObject, StreamObject

    if not isinstance(mapping, StreamObject):
        return mapping
    ref = (
        reference
        if isinstance(reference, IndirectObject)
        else getattr(reference, "indirect_reference", None)
    )
    if not isinstance(ref, IndirectObject):
        message = "SOURCE_STREAM_DICTIONARY_IDENTITY_UNAVAILABLE"
        raise SourceReadError(message)
    offset = reader.xref.get(ref.generation, {}).get(ref.idnum)
    if offset is None:
        message = "SOURCE_STREAM_DICTIONARY_OFFSET_UNAVAILABLE"
        raise SourceReadError(message)
    previous = reader.stream.tell()
    try:
        reader.stream.seek(offset)
        identity = reader.read_object_header(reader.stream)
        if identity != (ref.idnum, ref.generation):
            message = "SOURCE_STREAM_DICTIONARY_IDENTITY_MISMATCH"
            raise SourceReadError(message)
        declaration = read_dictionary_declaration(reader.stream, reader, budget)
    finally:
        reader.stream.seek(previous)
    return retain_stream_length(mapping, declaration)


def _recovery_source(reader: PdfReader, budget: SourceBudget) -> bytes:
    """Bound the fallback's original-byte inspection before materializing it."""
    previous = reader.stream.tell()
    try:
        size = reader.stream.seek(0, 2)
        if size > budget.limits.max_encoded_bytes:
            message = "SOURCE_STREAM_RECOVERY_INPUT_LIMIT"
            raise SourceLimitError(message)
        reader.stream.seek(0)
        return reader.stream.read(size)
    finally:
        reader.stream.seek(previous)


def _recovery_envelope(
    reader: PdfReader, ref: Any, data: bytes, budget: SourceBudget
) -> tuple[int, int, PdfObjectSource, int]:
    """Require unique referenced and adjacent object headers at active xref offsets."""
    from pypdf.generic import IndirectObject

    if not isinstance(ref, IndirectObject) or reader.is_encrypted:
        message = "SOURCE_STREAM_RECOVERY_REFERENCE_UNSUPPORTED"
        raise SourceReadError(message)
    offset = reader.xref.get(ref.generation, {}).get(ref.idnum)
    rows = [
        (position, number, generation)
        for generation, entries in reader.xref.items()
        for number, position in entries.items()
        if offset is not None and position > offset
    ]
    if offset is None or not rows:
        message = "SOURCE_STREAM_RECOVERY_ADJACENT_BOUNDARY_UNAVAILABLE"
        raise SourceReadError(message)
    next_offset = min(row[0] for row in rows)
    next_rows = [row for row in rows if row[0] == next_offset]
    if len(next_rows) != 1:
        message = "SOURCE_STREAM_RECOVERY_XREF_CONFLICT"
        raise SourceReadError(message)
    _, next_number, next_generation = next_rows[0]
    headers = []
    for header in _OBJECT_HEADER.finditer(data):
        budget.object()
        headers.append(header)
    target = [header for header in headers if int(header[1]) == ref.idnum]
    following = [header for header in headers if int(header[1]) == next_number]
    if (
        len(target) != 1
        or len(following) != 1
        or target[0].start() != offset
        or int(target[0][2]) != ref.generation
        or following[0].start() != next_offset
        or int(following[0][2]) != next_generation
        or any(offset < header.start() < next_offset for header in headers)
    ):
        message = "SOURCE_STREAM_RECOVERY_OBJECT_BINDING_CONFLICT"
        raise SourceReadError(message)
    return (
        offset,
        next_offset,
        PdfObjectSource(
            object_number=next_number,
            generation=next_generation,
            source_path="/Recovery/AdjacentObject",
        ),
        target[0].end(),
    )


def _recovery_payload(
    data: bytes, dictionary_start: int, next_offset: int
) -> tuple[bytes, int, int, int, bytes]:
    """Accept only one unfiltered, comment-obscured, oversized-length envelope."""
    envelope = data[dictionary_start:next_offset]
    opening = re.search(rb"(?m)^stream(?:\r\n|\r|\n)", envelope)
    if opening is None:
        message = "SOURCE_STREAM_RECOVERY_STREAM_START_UNAVAILABLE"
        raise SourceReadError(message)
    declaration = envelope[: opening.start()]
    match = re.fullmatch(
        rb"[\x00\t\n\f\r ]*<<[\x00\t\n\f\r ]*/Length[ \t]+"
        rb"([0-9]+)[ \t]+%[^\r\n]*>>[ \t]*(?:\r\n|\r|\n)",
        declaration,
    )
    if match is None or len(match[1]) > _RECOVERY_LENGTH_DIGITS:
        message = "SOURCE_STREAM_RECOVERY_DECLARATION_UNSUPPORTED"
        raise SourceReadError(message)
    length = int(match[1])
    if length <= len(data):
        message = "SOURCE_STREAM_RECOVERY_LENGTH_NOT_PROVED_INVALID"
        raise SourceReadError(message)
    tokens = re.findall(
        rb"(?<![A-Za-z])(?:stream|endstream|endobj)(?![A-Za-z])", envelope
    )
    if tokens != [b"stream", b"endstream", b"endobj"]:
        message = "SOURCE_STREAM_RECOVERY_TOKEN_BOUNDARY_AMBIGUOUS"
        raise SourceReadError(message)
    ending = re.search(rb"endstream[\x00\t\n\f\r ]+endobj[\x00\t\n\f\r ]*\Z", envelope)
    if ending is None or envelope[ending.start() - 1 : ending.start()] not in (
        b"\r",
        b"\n",
    ):
        message = "SOURCE_STREAM_RECOVERY_TERMINATOR_UNAVAILABLE"
        raise SourceReadError(message)
    start, end = dictionary_start + opening.end(), dictionary_start + ending.start()
    if start >= end:
        message = "SOURCE_STREAM_RECOVERY_PAYLOAD_UNAVAILABLE"
        raise SourceReadError(message)
    return data[start:end], start, end, length, declaration


def recover_content_stream(
    reader: PdfReader,
    reference: Any,
    budget: SourceBudget,
    original: bytes | None = None,
) -> tuple[Any, PdfSourceStreamRecoveryV7]:
    """Recover a unique original-byte envelope without claiming exact PDF length.

    Only a bare unfiltered dictionary with an oversized /Length and its closing
    delimiter hidden in a comment is supported. The complete range before the
    unique endstream token is retained, including any ambiguous trailing EOL.
    Original bytes, object identity and adjacent boundaries remain unchanged.
    """
    from pypdf.generic import (
        DecodedStreamObject,
        IndirectObject,
        NameObject,
        NumberObject,
    )

    ref = (
        reference
        if isinstance(reference, IndirectObject)
        else getattr(reference, "indirect_reference", None)
    )
    data = _recovery_source(reader, budget) if original is None else original
    if len(data) > budget.limits.max_encoded_bytes:
        message = "SOURCE_STREAM_RECOVERY_INPUT_LIMIT"
        raise SourceLimitError(message)
    offset, next_offset, next_object, dictionary_start = _recovery_envelope(
        reader, ref, data, budget
    )
    raw, start, end, length, declaration = _recovery_payload(
        data, dictionary_start, next_offset
    )
    budget.encoded(len(declaration))
    stream = DecodedStreamObject()
    stream[NameObject("/Length")] = NumberObject(length)
    stream.set_data(raw)
    stream.indirect_reference = ref
    return stream, PdfSourceStreamRecoveryV7(
        original_sha256=sha256(data).hexdigest(),
        object_offset=offset,
        next_object_offset=next_offset,
        next_object=next_object,
        declared_length=length,
        original_dictionary_base64=b64encode(declaration).decode("ascii"),
        payload_start=start,
        payload_end=end,
    )


def source(value: Any, path: str) -> PdfObjectSource:
    """Keep indirect identity or the exact deterministic direct-object location."""
    from pypdf.generic import IndirectObject

    ref = (
        value
        if isinstance(value, IndirectObject)
        else getattr(value, "indirect_reference", None)
    )
    if isinstance(ref, IndirectObject):
        return PdfObjectSource(
            source_path=path, object_number=ref.idnum, generation=ref.generation
        )
    return PdfObjectSource(source_path=path)


def payload(raw: bytes) -> PdfSourcePayloadV7:
    """Retain exact bytes and their independently checkable identity declarations."""
    return PdfSourcePayloadV7(
        content_base64=b64encode(raw).decode("ascii"),
        content_size=len(raw),
        content_sha256=sha256(raw).hexdigest(),
    )


def _structure(value: Any, budget: SourceBudget, depth: int) -> object:
    from pypdf.generic import (
        ByteStringObject,
        IndirectObject,
        NullObject,
        TextStringObject,
    )

    budget.object()
    if depth > budget.limits.max_depth:
        message = "SOURCE_VALUE_DEPTH_LIMIT"
        raise SourceLimitError(message)
    if isinstance(value, IndirectObject):
        return {"object_number": value.idnum, "generation": value.generation}
    if isinstance(value, NullObject) or value is None:
        return None
    if isinstance(value, ByteStringObject | bytes):
        return {"bytes_base64": b64encode(bytes(value)).decode("ascii")}
    if isinstance(value, TextStringObject):
        return {
            "text": str(value),
            "bytes_base64": b64encode(value.get_original_bytes()).decode("ascii"),
        }
    if isinstance(value, str | bool | int | float):
        if isinstance(value, float) and not math.isfinite(value):
            message = "SOURCE_NUMBER_NONFINITE"
            raise SourceReadError(message)
        return value
    if isinstance(value, list | tuple | dict):
        return (
            {
                str(key): _structure(item, budget, depth + 1)
                for key, item in value.items()
            }
            if isinstance(value, dict)
            else [_structure(item, budget, depth + 1) for item in value]
        )
    message = "SOURCE_VALUE_TYPE_UNSUPPORTED"
    raise SourceReadError(message)


def value(value: Any, budget: SourceBudget, *, present: bool = True) -> PdfObjectValue:
    """Convert a backend value without conflating missing, null, or empty text."""
    from pypdf.generic import ByteStringObject, NullObject, TextStringObject

    if not present:
        return PdfObjectValue(state="MISSING")
    if value is None or isinstance(value, NullObject):
        return PdfObjectValue(state="NULL", type_name="null")
    if isinstance(value, ByteStringObject | bytes):
        budget.encoded(len(value))
        return PdfObjectValue(
            state="PRESENT",
            type_name="bytes",
            bytes_base64=b64encode(bytes(value)).decode("ascii"),
        )
    if isinstance(value, TextStringObject):
        raw = value.get_original_bytes()
        budget.encoded(len(raw))
        return PdfObjectValue(
            state="PRESENT",
            type_name="string",
            text=str(value),
            bytes_base64=b64encode(raw).decode("ascii"),
        )
    text = json.dumps(
        _structure(value, budget, 0),
        ensure_ascii=False,
        allow_nan=False,
        separators=(",", ":"),
    )
    budget.encoded(len(text.encode("utf-8")))
    return PdfObjectValue(state="PRESENT", type_name="json", text=text)


def field(mapping: Any, name: str, budget: SourceBudget) -> PdfObjectValue:
    """Read a declared field without turning source absence into a default value."""
    return (
        value(mapping.raw_get(name), budget)
        if name in mapping
        else value(None, budget, present=False)
    )


def numbers(value: Any, count: int | None = None) -> tuple[float, ...]:
    """Read exact finite numeric operands from the source syntax."""
    items = resolve(value)
    if not isinstance(items, list | tuple):
        message = "SOURCE_NUMERIC_ARRAY_UNAVAILABLE"
        raise SourceReadError(message)
    converted = tuple(float(resolve(item)) for item in items)
    if (count is not None and len(converted) != count) or not all(
        math.isfinite(item) for item in converted
    ):
        message = "SOURCE_NUMERIC_ARRAY_INVALID"
        raise SourceReadError(message)
    return converted


def box(value: Any) -> Box:
    """Keep a source rectangle in its original, untransformed coordinate space."""
    raw = numbers(value, _BOX_SIZE)
    return raw[0], raw[1], raw[2], raw[3]


def matrix(value: Any) -> Matrix:
    """Read a six-component source affine transform."""
    raw = numbers(value, _MATRIX_SIZE)
    return raw[0], raw[1], raw[2], raw[3], raw[4], raw[5]


def multiply(left: Matrix, right: Matrix) -> Matrix:
    """Compose PDF row-vector transforms in source operator order."""
    a, b, c, d, e, f = left
    g, h, i, j, k, ell = right
    return (
        a * g + b * i,
        a * h + b * j,
        c * g + d * i,
        c * h + d * j,
        e * g + f * i + k,
        e * h + f * j + ell,
    )


def corners(ctm: Matrix) -> tuple[tuple[float, float], ...]:
    """Transform an image's PDF unit square without inventing an axis-aligned box."""
    a, b, c, d, e, f = ctm
    return ((e, f), (a + e, b + f), (a + c + e, b + d + f), (c + e, d + f))


def encoded_bytes(stream: Any, budget: SourceBudget) -> bytes:
    """Read encoded stream bytes after the backend's PDF security handler."""
    raw = getattr(stream, "_data", None)
    if not isinstance(raw, bytes):
        message = "SOURCE_STREAM_BYTES_UNAVAILABLE"
        raise SourceReadError(message)
    budget.encoded(len(raw))
    return raw


def _flate(raw: bytes, remaining: int) -> bytes:
    decoder = zlib.decompressobj()
    decoded = decoder.decompress(raw, remaining + 1)
    if len(decoded) > remaining or decoder.unconsumed_tail:
        message = "SOURCE_DECODED_BYTES_LIMIT"
        raise SourceLimitError(message)
    decoded += decoder.flush(remaining - len(decoded) + 1)
    if len(decoded) > remaining:
        message = "SOURCE_DECODED_BYTES_LIMIT"
        raise SourceLimitError(message)
    if not decoder.eof or decoder.unused_data:
        message = "SOURCE_FLATE_STREAM_INCOMPLETE"
        raise SourceReadError(message)
    return decoded


def _run_length(raw: bytes, remaining: int) -> bytes:
    output = bytearray()
    index = 0
    while index < len(raw):
        length = raw[index]
        index += 1
        if length == _RUN_END:
            return bytes(output)
        if length <= _RUN_LITERAL_MAX:
            end = index + length + 1
            output.extend(raw[index:end])
            if end > len(raw):
                break
            index = end
        else:
            if index >= len(raw):
                break
            output.extend(raw[index : index + 1] * (_MAX_BYTE + 1 - length))
            index += 1
        if len(output) > remaining:
            message = "SOURCE_DECODED_BYTES_LIMIT"
            raise SourceLimitError(message)
    message = "SOURCE_RUN_LENGTH_STREAM_INCOMPLETE"
    raise SourceReadError(message)


def _decode_filter(raw: bytes, name: str, remaining: int) -> bytes:
    if name in ("/FlateDecode", "/Fl"):
        return _flate(raw, remaining)
    if name in ("/ASCII85Decode", "/A85"):
        stripped = raw.strip()
        return a85decode(
            stripped if stripped.startswith(b"<~") else b"<~" + stripped, adobe=True
        )
    if name in ("/ASCIIHexDecode", "/AHx"):
        compact = b"".join(raw.split()).removesuffix(b">")
        return bytes.fromhex(
            (compact + (b"0" if len(compact) % 2 else b"")).decode("ascii")
        )
    if name in ("/RunLengthDecode", "/RL"):
        return _run_length(raw, remaining)
    message = "SOURCE_STREAM_FILTER_UNSUPPORTED"
    raise SourceReadError(message)


def decode_stream(raw: bytes, mapping: Any, budget: SourceBudget) -> bytes:
    """Decode bounded source filters; unsupported predictors remain explicit gaps."""
    filters = resolve(mapping.get("/Filter", mapping.get("/F")))
    parameters = resolve(mapping.get("/DecodeParms", mapping.get("/DP")))
    if parameters not in (None, {}, []):
        message = "SOURCE_STREAM_DECODE_PARAMETERS_UNSUPPORTED"
        raise SourceReadError(message)
    names = (
        list(filters)
        if isinstance(filters, list | tuple)
        else ([] if filters is None else [filters])
    )
    remaining = budget.limits.max_decoded_bytes - budget.decoded_bytes
    decoded = raw
    for name in names:
        try:
            decoded = _decode_filter(decoded, str(name), remaining)
        except (zlib.error, ValueError) as error:
            message = "SOURCE_STREAM_FILTER_DATA_INVALID"
            _raise_redacted_translation(error, SourceReadError(message))
        if len(decoded) > remaining:
            message = "SOURCE_DECODED_BYTES_LIMIT"
            raise SourceLimitError(message)
    budget.decoded(len(decoded))
    return decoded

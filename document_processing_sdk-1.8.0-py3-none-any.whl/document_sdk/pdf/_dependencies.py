"""Optional PDF dependency loading."""

from importlib import import_module

from document_sdk.core import DependencyNotInstalledError
from document_sdk.core.errors import _raise_redacted_translation

PDF_DEPENDENCY_MESSAGE = (
    "PDF support is not installed.\n"
    "Install it with:\n"
    '  pip install "document-processing-sdk[pdf]"\n'
    "or:\n"
    '  uv add "document-processing-sdk[pdf]"'
)


def require_pdf_support() -> None:
    """Raise the documented SDK error when the PDF extra is incomplete."""
    try:
        import_module("pypdfium2")
        import_module("PIL")
    except ImportError as exc:
        _raise_redacted_translation(
            exc,
            DependencyNotInstalledError(PDF_DEPENDENCY_MESSAGE),
        )

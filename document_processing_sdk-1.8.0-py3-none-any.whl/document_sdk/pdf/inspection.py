"""Local PDF structure and text-layer inspection."""

from __future__ import annotations

from typing import TYPE_CHECKING

from document_sdk.core import (
    PageDimensions,
    PdfInspection,
    PdfPageInspection,
    PdfSourceReference,
)
from document_sdk.pdf._dependencies import require_pdf_support
from document_sdk.pdf._document import (
    enforce_native_text_page_limit,
    inspect_pdf_input,
    open_pdf,
    translate_pdf_errors,
)
from document_sdk.pdf._text import extract_bounded_page_text
from document_sdk.pdf._validation import _validate_pdf_password, _validated_pdf_limits
from document_sdk.pdf.models import (
    PdfProcessingLimits,  # noqa: TC001 - public annotation.
)

if TYPE_CHECKING:
    from pathlib import Path

MIN_USABLE_NATIVE_TEXT_CHARACTERS = 10


def inspect_pdf(
    path: Path,
    *,
    limits: PdfProcessingLimits | None = None,
    password: str | None = None,
) -> PdfInspection:
    """Inspect pages, dimensions, rotation, and native text availability.

    Args:
        path: Local PDF path.
        limits: Optional explicit PDF resource limits.
        password: Explicit runtime-only local PDF password; never stored in results.

    Returns:
        SDK-owned PDF inspection data.
    """
    effective_limits = _validated_pdf_limits(limits)
    _validate_pdf_password(password)
    require_pdf_support()
    descriptor = inspect_pdf_input(path, effective_limits)
    pages: list[PdfPageInspection] = []
    native_text_characters = 0

    with (
        translate_pdf_errors(path, "inspect"),
        open_pdf(
            path,
            descriptor,
            effective_limits,
            password=password,
            password_supported=True,
        ) as (pdf, preflight),
    ):
        enforce_native_text_page_limit(preflight.page_count, effective_limits)
        for page_index, page_facts in enumerate(preflight.pages):
            page = pdf[page_index]
            try:
                text_page = page.get_textpage()
                try:
                    text, native_text_characters = extract_bounded_page_text(
                        text_page,
                        characters_so_far=native_text_characters,
                        limits=effective_limits,
                    )
                finally:
                    text_page.close()
                source = PdfSourceReference(
                    file_id=descriptor.file_id,
                    page_number=page_facts.page_number,
                )
                meaningful_character_count = sum(
                    not character.isspace() for character in text
                )
                pages.append(
                    PdfPageInspection(
                        page_number=page_facts.page_number,
                        dimensions=PageDimensions(
                            width=page_facts.width_points,
                            height=page_facts.height_points,
                            rotation=page_facts.rotation,
                        ),
                        has_text_layer=bool(text.strip()),
                        native_text_character_count=len(text),
                        ocr_candidate=(
                            meaningful_character_count
                            < MIN_USABLE_NATIVE_TEXT_CHARACTERS
                        ),
                        source=source,
                    )
                )
            finally:
                page.close()

    has_text_layer = any(page.has_text_layer for page in pages)
    native_text_page_numbers = tuple(
        page.page_number for page in pages if not page.ocr_candidate
    )
    ocr_candidate_page_numbers = tuple(
        page.page_number for page in pages if page.ocr_candidate
    )
    fully_scanned = len(ocr_candidate_page_numbers) == len(pages)
    return PdfInspection(
        file=descriptor,
        page_count=len(pages),
        encrypted=preflight.encrypted,
        has_text_layer=has_text_layer,
        scanned_pdf_candidate=fully_scanned,
        native_text_page_numbers=native_text_page_numbers,
        ocr_candidate_page_numbers=ocr_candidate_page_numbers,
        fully_scanned=fully_scanned,
        partially_scanned=bool(native_text_page_numbers and ocr_candidate_page_numbers),
        pages=tuple(pages),
        file_size_within_limit=True,
        page_count_within_limit=True,
        largest_page_width_points=max(page.width_points for page in preflight.pages),
        largest_page_height_points=max(page.height_points for page in preflight.pages),
        largest_page_area_points=max(
            page.width_points * page.height_points for page in preflight.pages
        ),
    )

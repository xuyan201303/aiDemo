"""Strict public PDF resource-limit models."""

from __future__ import annotations

from typing import Self

from pydantic import Field, model_validator

from document_sdk.core.models import SdkModel


class PdfProcessingLimits(SdkModel):
    """Explicit bounds for local PDF inspection, text, and rendering."""

    max_file_bytes: int = Field(default=512_000_000, gt=0, le=10_000_000_000)
    max_pages: int = Field(default=1_000, gt=0, le=100_000)
    max_page_width_points: float = Field(default=10_000, gt=0, le=1_000_000)
    max_page_height_points: float = Field(default=10_000, gt=0, le=1_000_000)
    max_page_area_points: float = Field(
        default=50_000_000,
        gt=0,
        le=1_000_000_000_000,
    )
    max_native_text_pages: int = Field(default=1_000, gt=0, le=100_000)
    max_native_text_characters: int = Field(
        default=20_000_000,
        gt=0,
        le=1_000_000_000,
    )
    max_render_dpi: int = Field(default=300, gt=0, le=2_400)
    max_render_width: int = Field(default=20_000, gt=0, le=1_000_000)
    max_render_height: int = Field(default=20_000, gt=0, le=1_000_000)
    max_render_pixels: int = Field(
        default=25_000_000,
        gt=0,
        le=1_000_000_000_000,
    )
    max_output_bytes: int = Field(
        default=20_000_000,
        gt=0,
        le=10_000_000_000,
    )

    @model_validator(mode="after")
    def validate_nested_limits(self) -> Self:
        """Reject a text-page budget that exceeds the document page budget."""
        if self.max_native_text_pages > self.max_pages:
            msg = "max_native_text_pages must not exceed max_pages"
            raise ValueError(msg)
        return self

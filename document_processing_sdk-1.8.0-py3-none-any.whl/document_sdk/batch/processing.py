"""Deterministic local batch discovery, processing, and resume."""

# ruff: noqa: BLE001, C901, EM101, PLR0912, PLR0913, PLR0915, PTH105, SLF001, TC003, TRY003

from __future__ import annotations

import hashlib
import inspect
import json
import math
import os
import stat
import tempfile
import unicodedata
from collections import Counter
from collections.abc import Iterable
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path
from threading import Lock
from typing import Any, Literal, TypedDict, cast

import document_sdk.document.processing as document_processing
from document_sdk import __version__
from document_sdk.batch.errors import (
    BatchConfigurationError,
    BatchManifestError,
    BatchProcessingLimitError,
)
from document_sdk.batch.models import (
    BatchDocumentInput,
    BatchItemIssue,
    BatchItemResult,
    BatchItemStatus,
    BatchManifestItem,
    BatchProcessingLimits,
    BatchProcessingManifest,
    BatchProcessingOptions,
    BatchProcessingResult,
    _aggregate_counts,
    _azure_fallback_aggregate,
    _cloud_logical_operation_key,
    _consumed_input_bytes,
    _local_ocr_preprocessing_aggregate,
    _local_ocr_quality_aggregate,
    _provider_usage_totals,
    _status_counts,
    _workflow_intake_operations,
    _workflow_intake_result_fingerprint,
    _workflow_preprocessing_summary,
    compute_batch_fingerprint,
    normalize_relative_name,
)
from document_sdk.core import (
    CloudExecutionAttemptEvidence,
    CloudExecutionAttemptStatus,
    CloudExecutionPolicy,
    DocumentProcessingError,
    LocalOcrIntrinsicQualityPolicy,
    ProviderUsage,
    ProviderUsageTotals,
)
from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.core.local_ocr_quality import local_ocr_quality_identity
from document_sdk.document import (
    DocumentAnalysisOptions,
    DocumentFormat,
    DocumentSourceChangedError,
    DocumentType,
    UnsupportedDocumentTypeError,
)
from document_sdk.document._exceptions import _redact_exception
from document_sdk.document.models import (
    ImageDocumentInspection,
    OperationCount,
    PdfAnalysisMode,
    PdfDocumentInspection,
    _canonical_document_result_fingerprint,
)
from document_sdk.document.processing import (
    _analyze_prepared_document,
    _DocumentIdentityLimitError,
    _PreparedDocument,
    _UnsupportedDocumentIdentityError,
    _validate_quality_request_before_detection,
    _validate_request,
)
from document_sdk.docx import DocxResourceLimitError
from document_sdk.extraction import (
    ExtractionSchema,
    ExtractionStrategy,
    StructuredExtractionOptions,
)
from document_sdk.extraction.extraction import _validate_local_quality_provider
from document_sdk.ocr import (
    LocalOcrLimitExceededError,
    LocalOcrPreprocessingLimitError,
    LocalOcrPreprocessingPolicy,
    LocalOcrProcessingLimits,
    OcrProvider,
)
from document_sdk.ocr._azure_execution import (
    read_cloud_execution_attempt,
    read_completed_cloud_result,
)
from document_sdk.ocr._provider_boundary import (
    _LocalOcrInvocationState,
    _read_provider_context_projection_safely,
)
from document_sdk.ocr.azure import AzureDocumentIntelligenceProvider
from document_sdk.ocr.fallback import _is_actual_azure_provider
from document_sdk.ocr.fallback_errors import (
    AzureFallbackConfigurationError,
    AzureFallbackError,
    AzureFallbackLimitError,
)
from document_sdk.ocr.fallback_models import (
    AzureFallbackAttemptEvidence,
    AzurePageFallbackPolicy,
    AzurePageFallbackReport,
    _validate_azure_fallback_policy,
)
from document_sdk.ocr.local import (
    LocalOcrProvider,
    _is_exact_local_ocr_provider_instance,
    _LocalOcrUsageBudget,
)
from document_sdk.ocr.local_errors import (
    LocalOcrQualityConfigurationError,
    _attempt_usage,
)
from document_sdk.workflow.artifacts import (  # noqa: TC001 - public annotation is introspected at runtime.
    WorkflowArtifactStore,
)
from document_sdk.workflow.models import (
    DocumentWorkflowIntakeResult,
    DocumentWorkflowIntakeStatus,
    DocumentWorkflowManifest,
    DocumentWorkflowRequest,
    DocumentWorkflowResult,
    WorkflowOcrRoute,
    WorkflowPdfProcessingMode,
    WorkflowProviderCategory,
    WorkflowSourceIdentity,
    WorkflowStageKind,
    WorkflowStageResult,
    workflow_source_identity_from_descriptor,
    workflow_usage_from_stages,
)
from document_sdk.workflow.planning import _detected_source_descriptor
from document_sdk.workflow.processing import (
    DocumentWorkflowProviders,
    WorkflowLocalOcrProvider,
    _intake_preplan_exception_result,
    _run_document_workflow_intake_with_local_budget,
    _validate_intake_caller_inputs,
)
from document_sdk.workflow.processing import (
    _ocr_provider_identity as _workflow_ocr_provider_identity,
)
from document_sdk.workflow.processing import (
    _validated_providers as _validated_workflow_providers,
)
from document_sdk.workflow.processing import (
    _validated_request as _validated_workflow_request,
)

_PDF_ANALYSIS_LOCK = Lock()
_prepare_document = document_processing._prepare_document


@dataclass(frozen=True, slots=True)
class _WorkflowBatchMode:
    request: DocumentWorkflowRequest
    providers: DocumentWorkflowProviders
    artifact_store: WorkflowArtifactStore | None
    identity: str
    local_provider: LocalOcrProvider | None


@dataclass(frozen=True, slots=True)
class _WorkflowLocalOcrDemand:
    """Exact baseline Local OCR demand available from prepared evidence."""

    source_kind: Literal["image", "pdf"]
    operation_count: int
    pixel_count: int


def _fallback_attempt_evidence(  # noqa: PLR0911
    exc: BaseException,
) -> AzureFallbackAttemptEvidence | None:
    """Read only SDK-created safe fallback attempt evidence."""
    actual_exception_type = type(exc)
    try:
        is_fallback_error = issubclass(actual_exception_type, AzureFallbackError)
    except TypeError:
        is_fallback_error = False
    if not is_fallback_error:
        return None
    sentinel = object()
    try:
        static_evidence = inspect.getattr_static(exc, "attempt_evidence", sentinel)
    except Exception:
        return None
    actual_evidence_type = type(static_evidence)
    try:
        is_attempt_evidence = issubclass(
            actual_evidence_type,
            AzureFallbackAttemptEvidence,
        )
    except TypeError:
        is_attempt_evidence = False
    if static_evidence is sentinel or not is_attempt_evidence:
        return None
    try:
        instance_storage = object.__getattribute__(exc, "__dict__")
    except Exception:
        return None
    if type(instance_storage) is not dict:
        return None
    evidence = instance_storage.get("attempt_evidence", sentinel)
    if evidence is sentinel or evidence is not static_evidence:
        return None
    try:
        return _revalidate_model_instance_json(
            evidence,
            AzureFallbackAttemptEvidence,
            "Azure fallback attempt evidence is invalid",
        )
    except Exception:
        return None


def _attempt_confirmed_usages(
    evidence: AzureFallbackAttemptEvidence | None,
) -> tuple[ProviderUsage, ...]:
    if evidence is None:
        return ()
    current = evidence.current_attempt_usage
    return evidence.completed_azure_usages + (
        ()
        if current is None
        or (not current.azure_operation_count and not current.paid_operation_count)
        else (current,)
    )


def _attempt_budget_values(
    evidence: AzureFallbackAttemptEvidence | None,
) -> tuple[int, int, int, int, int, int]:
    if evidence is None:
        return (0, 0, 0, 0, 0, 0)
    usages = _attempt_confirmed_usages(evidence)
    return (
        len(evidence.prepared_pages),
        len(evidence.prepared_frames),
        evidence.provider_invocation_count,
        sum(usage.azure_operation_count for usage in usages),
        sum(usage.paid_operation_count for usage in usages),
        evidence.payload_byte_count,
    )


def _completed_report_attempt_evidence(
    report: AzurePageFallbackReport | None,
    usages: tuple[ProviderUsage, ...],
    cloud_attempts: tuple[CloudExecutionAttemptEvidence, ...],
) -> tuple[
    AzureFallbackAttemptEvidence | None,
    tuple[CloudExecutionAttemptEvidence, ...],
]:
    """Project one prior completed Report into durable historical Attempt evidence."""
    if report is None or not (report.submitted_pages or report.submitted_frames):
        return None, cloud_attempts
    identity = report.provider_identity_summary
    if identity is None:
        raise BatchManifestError("Prior Azure fallback identity evidence is incomplete")
    is_page = bool(report.submitted_pages)
    indexes = report.submitted_pages or report.submitted_frames
    remaining = list(usages)
    remaining_cloud_attempts = list(cloud_attempts)
    confirmed: list[ProviderUsage] = []
    confirmed_cloud_attempts: list[CloudExecutionAttemptEvidence] = []
    for index in indexes:
        expected = ProviderUsage(
            provider_name=identity.provider_name,
            profile_id=identity.profile_id,
            model_id=identity.model_id,
            api_version=identity.api_version,
            provider_resource_identity=identity.provider_resource_identity,
            submitted_pages=(index,) if is_page else (),
            returned_pages=(index,) if is_page else (),
            submitted_frames=() if is_page else (index,),
            returned_frames=() if is_page else (index,),
            requested_features=tuple(
                feature.value for feature in report.requested_features
            ),
            query_field_count=report.query_field_count,
            azure_operation_count=1,
            paid_operation_count=1,
            cloud_logical_operation_count=1,
            cloud_submitted_operation_count=1,
            cloud_paid_or_possibly_paid_operation_count=1,
            cloud_transport_retry_count=0,
        )
        try:
            remaining.remove(expected)
        except ValueError:
            raise BatchManifestError(
                "Prior Azure fallback Usage evidence is incomplete"
            ) from None
        confirmed.append(expected)
        expected_pages = (index,) if is_page else ()
        expected_frames = () if is_page else (index,)
        matching_cloud_attempts = tuple(
            attempt
            for attempt in remaining_cloud_attempts
            if (
                attempt.status is CloudExecutionAttemptStatus.COMPLETED
                and attempt.provider_name == identity.provider_name
                and attempt.profile_id == identity.profile_id
                and attempt.model_id == identity.model_id
                and attempt.api_version == identity.api_version
                and attempt.provider_resource_identity
                == identity.provider_resource_identity
                and not attempt.requested_entire_input
                and attempt.requested_pages == expected_pages
                and attempt.requested_frames == expected_frames
                and attempt.submitted_pages == expected_pages
                and attempt.submitted_frames == expected_frames
            )
        )
        if len(matching_cloud_attempts) != 1:
            raise BatchManifestError(
                "Prior Azure fallback cloud evidence is incomplete"
            )
        matching_cloud_attempt = matching_cloud_attempts[0]
        remaining_cloud_attempts.remove(matching_cloud_attempt)
        confirmed_cloud_attempts.append(matching_cloud_attempt)
    return (
        AzureFallbackAttemptEvidence(
            source_kind="page" if is_page else "frame",
            provider_invocation_count=report.provider_invocation_count,
            trigger_quality_summary=report.trigger_quality_summary,
            provider_identity_summary=identity,
            requested_features=report.requested_features,
            query_field_count=report.query_field_count,
            completed_azure_usages=tuple(confirmed),
            completed_cloud_execution_attempts=tuple(confirmed_cloud_attempts),
            prepared_pages=indexes if is_page else (),
            prepared_frames=() if is_page else indexes,
            invoked_pages=indexes if is_page else (),
            invoked_frames=() if is_page else indexes,
            prepared_payload_byte_counts=tuple(
                attempt.input_bytes for attempt in confirmed_cloud_attempts
            ),
            payload_count=report.payload_count,
            payload_byte_count=report.payload_byte_count,
        ),
        tuple(remaining_cloud_attempts),
    )


@dataclass(frozen=True)
class _RetainedCloudHistories:
    fallback_attempts: tuple[AzureFallbackAttemptEvidence, ...]
    standalone_cloud_attempts: tuple[CloudExecutionAttemptEvidence, ...]


def _retained_cloud_histories(
    prior: BatchManifestItem | BatchItemResult | None,
) -> _RetainedCloudHistories:
    """Partition prior fallback and standalone cloud attempts exactly once."""
    if prior is None:
        return _RetainedCloudHistories((), ())
    fallback_attempts = prior.retained_azure_fallback_attempts + (
        () if prior.azure_fallback_attempt is None else (prior.azure_fallback_attempt,)
    )
    standalone = (
        prior.retained_cloud_execution_attempts + prior.cloud_execution_attempts
    )
    completed, standalone = _completed_report_attempt_evidence(
        prior.azure_fallback_summary,
        prior.provider_usage_breakdown,
        standalone,
    )
    return _RetainedCloudHistories(
        fallback_attempts + (() if completed is None else (completed,)),
        standalone,
    )


def _fallback_cloud_attempt_history(
    attempt: AzureFallbackAttemptEvidence | None,
) -> tuple[CloudExecutionAttemptEvidence, ...]:
    if attempt is None:
        return ()
    return attempt.completed_cloud_execution_attempts + (
        ()
        if attempt.current_cloud_execution_attempt is None
        else (attempt.current_cloud_execution_attempt,)
    )


def _has_protected_remote_attempt(
    attempts: tuple[CloudExecutionAttemptEvidence, ...],
    fallback_attempts: tuple[AzureFallbackAttemptEvidence, ...],
) -> bool:
    all_attempts = attempts + tuple(
        cloud_attempt
        for fallback_attempt in fallback_attempts
        for cloud_attempt in _fallback_cloud_attempt_history(fallback_attempt)
    )
    return any(
        attempt.status
        in {
            CloudExecutionAttemptStatus.SUBMITTED,
            CloudExecutionAttemptStatus.POSSIBLY_PAID,
            CloudExecutionAttemptStatus.COMPLETED,
        }
        for attempt in all_attempts
    )


def _fallback_cloud_attempts(
    attempts: tuple[AzureFallbackAttemptEvidence, ...],
) -> tuple[CloudExecutionAttemptEvidence, ...]:
    """Flatten trusted fallback lifecycle evidence into cloud attempts."""
    return tuple(
        cloud_attempt
        for attempt in attempts
        for cloud_attempt in _fallback_cloud_attempt_history(attempt)
    )


def _direct_cloud_failure_evidence(
    error: BaseException,
) -> tuple[tuple[ProviderUsage, ...], tuple[CloudExecutionAttemptEvidence, ...]]:
    """Recover one confirmed direct Usage pair or one standalone safe attempt."""
    completed = read_completed_cloud_result(error)
    if completed is not None:
        usage, attempt = completed
        return (usage,), (attempt,)
    standalone_attempt = read_cloud_execution_attempt(error)
    return (), (() if standalone_attempt is None else (standalone_attempt,))


def _batch_evidence_cloud_attempts(
    item: BatchManifestItem | BatchItemResult,
) -> tuple[CloudExecutionAttemptEvidence, ...]:
    """Return all actual cloud attempts represented by one non-duplicate item."""
    if item.status is BatchItemStatus.DUPLICATE:
        return ()
    fallback_attempts = item.retained_azure_fallback_attempts + (
        () if item.azure_fallback_attempt is None else (item.azure_fallback_attempt,)
    )
    return (
        item.retained_cloud_execution_attempts
        + item.cloud_execution_attempts
        + _fallback_cloud_attempts(fallback_attempts)
    )


def _current_result_cloud_attempts(
    item: BatchItemResult,
) -> tuple[CloudExecutionAttemptEvidence, ...]:
    """Return only attempts created during the current Batch invocation."""
    fallback_attempts = (
        () if item.azure_fallback_attempt is None else (item.azure_fallback_attempt,)
    )
    return item.cloud_execution_attempts + _fallback_cloud_attempts(fallback_attempts)


@dataclass
class _CloudExecutionBudgetState:
    """Track cumulative explicit Cloud Policy consumption across one Batch chain."""

    logical_keys: set[tuple[object, ...]]
    submitted_operations: int = 0
    paid_or_possibly_paid_operations: int = 0
    submitted_pages_or_frames: int = 0
    submitted_input_bytes: int = 0

    @classmethod
    def from_manifest_items(
        cls,
        items: Iterable[BatchManifestItem],
    ) -> _CloudExecutionBudgetState:
        state = cls(logical_keys=set())
        for item in items:
            state.record(
                item.input_id,
                _batch_evidence_cloud_attempts(item),
            )
        return state

    def record(
        self,
        input_id: str,
        attempts: tuple[CloudExecutionAttemptEvidence, ...],
    ) -> None:
        """Consume each newly trusted attempt exactly once."""
        for attempt in attempts:
            self.logical_keys.add(_cloud_logical_operation_key(input_id, attempt))
            self.submitted_operations += attempt.submitted_operation_count
            self.paid_or_possibly_paid_operations += (
                attempt.paid_or_possibly_paid_operation_count
            )
            if attempt.submitted_operation_count:
                self.submitted_pages_or_frames += len(attempt.submitted_pages) + len(
                    attempt.submitted_frames
                )
                self.submitted_input_bytes += attempt.input_bytes

    def remaining_logical_operations(
        self,
        policy: CloudExecutionPolicy,
        *,
        retry_credit: int,
    ) -> int:
        """Return new logical capacity plus bounded same-item retry capacity."""
        return max(
            0,
            policy.max_logical_cloud_operations - len(self.logical_keys) + retry_credit,
        )

    def permits_direct_submit(
        self,
        policy: CloudExecutionPolicy,
        *,
        page_or_frame_count: int,
        input_bytes: int,
        retry_credit: int,
    ) -> bool:
        """Check one direct operation before Provider invocation."""
        return bool(
            self.remaining_logical_operations(
                policy,
                retry_credit=retry_credit,
            )
            >= 1
            and self.submitted_operations < policy.max_submitted_operations
            and self.paid_or_possibly_paid_operations
            < policy.max_paid_or_possibly_paid_operations
            and self.submitted_pages_or_frames + page_or_frame_count
            <= policy.max_pages_or_frames
            and self.submitted_input_bytes + input_bytes <= policy.max_input_bytes
        )


def _current_provider_usage_history(
    item: BatchManifestItem | BatchItemResult,
) -> tuple[ProviderUsage, ...]:
    return item.provider_usage_breakdown or (
        () if item.provider_usage is None else (item.provider_usage,)
    )


def _is_local_only_usage_history(usages: tuple[ProviderUsage, ...]) -> bool:
    """Return whether history proves only non-cloud Local OCR execution."""
    return bool(usages) and all(
        usage.provider_name == "local_ocr"
        and usage.local_operation_count > 0
        and usage.azure_operation_count == 0
        and usage.paid_operation_count == 0
        and usage.cloud_logical_operation_count == 0
        and usage.cloud_submitted_operation_count == 0
        and usage.cloud_paid_or_possibly_paid_operation_count == 0
        and usage.cloud_transport_retry_count == 0
        for usage in usages
    )


def _fallback_budgeted_options(
    options: DocumentAnalysisOptions,
    *,
    used_pages: int,
    used_frames: int,
    used_invocations: int,
    used_azure_operations: int,
    used_paid_operations: int,
    used_payload_bytes: int,
    limits: BatchProcessingLimits,
    cloud_policy: CloudExecutionPolicy | None = None,
    cloud_budget: _CloudExecutionBudgetState | None = None,
    cloud_retry_credit: int = 0,
) -> DocumentAnalysisOptions:
    """Tighten one item policy to the remaining cumulative Batch budget."""
    policy = options.azure_fallback_policy
    if policy is None:
        return options
    policy = _validate_azure_fallback_policy(policy)
    remaining_pages = max(0, limits.max_total_azure_fallback_pages - used_pages)
    remaining_frames = max(0, limits.max_total_azure_fallback_frames - used_frames)
    remaining_inputs = max(
        0,
        limits.max_total_azure_fallback_inputs - used_pages - used_frames,
    )
    remaining_operations = max(
        0,
        limits.max_total_azure_fallback_operations
        - max(used_invocations, used_azure_operations),
    )
    remaining_paid = max(0, limits.max_total_paid_operations - used_paid_operations)
    remaining_payload = max(
        0,
        limits.max_total_azure_fallback_payload_bytes - used_payload_bytes,
    )
    cloud_remaining_inputs = 10_000
    cloud_remaining_operations = 10_000
    cloud_remaining_payload = 1_000_000_000
    if cloud_policy is not None and cloud_budget is not None:
        cloud_remaining_inputs = max(
            0,
            cloud_policy.max_pages_or_frames - cloud_budget.submitted_pages_or_frames,
        )
        cloud_remaining_operations = min(
            cloud_budget.remaining_logical_operations(
                cloud_policy,
                retry_credit=cloud_retry_credit,
            ),
            max(
                0,
                cloud_policy.max_submitted_operations
                - cloud_budget.submitted_operations,
            ),
            max(
                0,
                cloud_policy.max_paid_or_possibly_paid_operations
                - cloud_budget.paid_or_possibly_paid_operations,
            ),
        )
        cloud_remaining_payload = max(
            0,
            cloud_policy.max_input_bytes - cloud_budget.submitted_input_bytes,
        )
    max_pages = min(policy.max_fallback_pages_per_document, remaining_pages)
    max_frames = min(policy.max_fallback_frames_per_document, remaining_frames)
    max_inputs = min(
        policy.max_fallback_inputs_per_document,
        remaining_inputs,
        cloud_remaining_inputs,
        max_pages + max_frames,
    )
    max_operations = min(
        policy.max_fallback_operations_per_document,
        remaining_operations,
        remaining_paid,
        cloud_remaining_operations,
    )
    max_inputs = min(max_inputs, max_operations)
    if remaining_payload == 0:
        max_inputs = 0
    max_pages = min(max_pages, max_inputs)
    max_frames = min(max_frames, max_inputs)
    payload_per_input = min(
        policy.max_payload_bytes_per_input,
        remaining_payload,
        cloud_remaining_payload,
    )
    payload_per_document = min(
        policy.max_payload_bytes_per_document,
        remaining_payload,
        cloud_remaining_payload,
    )
    bounded = AzurePageFallbackPolicy.model_validate(
        policy.model_dump(mode="python")
        | {
            "max_fallback_pages_per_document": max_pages,
            "max_fallback_frames_per_document": max_frames,
            "max_fallback_inputs_per_document": max_inputs,
            "max_fallback_operations_per_document": max_operations,
            "max_payload_bytes_per_input": payload_per_input,
            "max_payload_bytes_per_document": payload_per_document,
        }
    )
    return DocumentAnalysisOptions.model_validate(
        options.model_dump(mode="python") | {"azure_fallback_policy": bounded}
    )


@dataclass(frozen=True)
class _PendingItem:
    index: int
    item: BatchDocumentInput
    prepared: _PreparedDocument
    retained_provider_usage: tuple[ProviderUsage, ...] = ()
    retained_azure_fallback_attempts: tuple[AzureFallbackAttemptEvidence, ...] = ()
    retained_cloud_execution_attempts: tuple[CloudExecutionAttemptEvidence, ...] = ()
    retry_prior_local_limit_cancellation: bool = False


def _pending_cloud_retry_credit(
    pending: _PendingItem,
    *,
    policy: CloudExecutionPolicy | None,
) -> int:
    """Credit retained same-operation work under its lifecycle retry contract."""
    attempts = pending.retained_cloud_execution_attempts + _fallback_cloud_attempts(
        pending.retained_azure_fallback_attempts
    )
    grouped: dict[tuple[object, ...], list[CloudExecutionAttemptEvidence]] = {}
    for attempt in attempts:
        key = _cloud_logical_operation_key(pending.item.input_id, attempt)
        grouped.setdefault(key, []).append(attempt)
    unsubmitted = {
        CloudExecutionAttemptStatus.NOT_SUBMITTED,
        CloudExecutionAttemptStatus.FAILED_BEFORE_SUBMIT,
    }
    allow_protected = policy is not None and policy.allow_retry_possibly_paid
    return sum(
        all(attempt.status in unsubmitted for attempt in group) or allow_protected
        for group in grouped.values()
    )


def _pending_direct_cloud_input_count(pending: _PendingItem) -> int:
    """Return the inspected page/frame count for one direct Azure input."""
    inspection = pending.prepared.inspection
    return inspection.pdf_page_count or inspection.image_frame_count or 1


class _FamilyEvidence(TypedDict):
    document_type: DocumentType
    document_format: DocumentFormat
    pdf_page_count: int | None
    excel_worksheet_count: int | None
    image_frame_count: int | None
    docx_block_count: int | None


def _safe_issue(code: str, category: str, message: str) -> BatchItemIssue:
    return BatchItemIssue(code=code, category=category, message=message)


def _is_hidden(relative: Path) -> bool:
    return any(part.startswith(".") for part in relative.parts)


def _input_id(relative_name: str) -> str:
    return hashlib.sha256(relative_name.encode()).hexdigest()[:24]


def _resolve_batch_root(root: Path) -> Path:
    try:
        return root.resolve()
    except Exception as exc:
        _redact_exception(exc)
    raise BatchConfigurationError(
        "The batch root could not be resolved safely"
    ) from OSError("redacted")


def _is_batch_directory(root: Path) -> bool:
    try:
        return root.is_dir()
    except Exception as exc:
        _redact_exception(exc)
    raise BatchConfigurationError(
        "The batch root could not be inspected safely"
    ) from OSError("redacted")


def _discovered_relative_name(candidate: Path, root: Path) -> str:
    try:
        relative = candidate.relative_to(root)
        return normalize_relative_name(
            unicodedata.normalize("NFKC", relative.as_posix())
        )
    except Exception as exc:
        _redact_exception(exc)
    raise BatchConfigurationError(
        "A discovered relative name is invalid"
    ) from ValueError("redacted")


def _resolve_discovered_source(candidate: Path, resolved_root: Path) -> None:
    try:
        candidate.resolve().relative_to(resolved_root)
    except Exception as exc:
        _redact_exception(exc)
    else:
        return
    raise BatchConfigurationError(
        "A discovered source resolves outside the batch root"
    ) from OSError("redacted")


def discover_documents(
    root: Path,
    *,
    options: BatchProcessingOptions | None = None,
    limits: BatchProcessingLimits | None = None,
) -> tuple[BatchDocumentInput, ...]:
    """Discover caller-authorized files in normalized deterministic order."""
    try:
        effective_options = (
            BatchProcessingOptions()
            if options is None
            else _revalidate_model_instance_json(
                options,
                BatchProcessingOptions,
                "Batch discovery options are invalid",
            )
        )
        effective_limits = (
            BatchProcessingLimits()
            if limits is None
            else _revalidate_model_instance_json(
                limits,
                BatchProcessingLimits,
                "Batch discovery limits are invalid",
            )
        )
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            BatchConfigurationError("Batch discovery request is invalid"),
        )
    if not _is_batch_directory(root):
        raise BatchConfigurationError("The batch root is not a valid directory")
    resolved_root = _resolve_batch_root(root)
    candidates: list[tuple[str, Path]] = []
    iterator = root.rglob("*") if effective_options.recursive else root.iterdir()
    inspected_entries = 0
    discovery_complete = False
    try:
        for candidate in iterator:
            inspected_entries += 1
            if inspected_entries > effective_limits.max_files * 20:
                raise BatchProcessingLimitError(  # noqa: TRY301
                    "Directory discovery exceeded its bounded traversal limit"
                )
            relative_name = _discovered_relative_name(candidate, root)
            if not effective_options.include_hidden and _is_hidden(Path(relative_name)):
                continue
            if candidate.is_symlink() or not candidate.is_file():
                continue
            _resolve_discovered_source(candidate, resolved_root)
            if not effective_options.include_unsupported:
                try:
                    document_processing._detect_identity(candidate)
                except UnsupportedDocumentTypeError:
                    continue
            candidates.append((relative_name, candidate))
            if len(candidates) > effective_limits.max_files:
                raise BatchProcessingLimitError(  # noqa: TRY301
                    "Document discovery exceeded the configured file limit"
                )
    except (BatchConfigurationError, BatchProcessingLimitError):
        raise
    except Exception as exc:
        _redact_exception(exc)
    else:
        discovery_complete = True
    if not discovery_complete:
        raise BatchConfigurationError(
            "Batch directory traversal failed safely"
        ) from OSError("redacted")
    candidates.sort(key=lambda item: (item[0].casefold(), item[0]))
    names = tuple(name for name, _ in candidates)
    if len(names) != len(set(names)):
        raise BatchConfigurationError(
            "Discovered names collide after Unicode normalization"
        )
    return tuple(
        BatchDocumentInput(
            input_id=_input_id(relative_name),
            relative_name=relative_name,
            source=source,
        )
        for relative_name, source in candidates
    )


def _provider_processing_identity(
    provider: OcrProvider | None,
) -> tuple[str | None, str | None]:
    """Return one validated profile and safe deterministic Resume fingerprint."""
    if provider is None:
        return None, None
    projection = _read_provider_context_projection_safely(
        provider,
        error=BatchConfigurationError("OCR Provider processing identity is invalid"),
    )
    return projection.metadata.profile_id, projection.resume_fingerprint


def _bounded_workflow_local_provider(
    provider: object | None,
) -> LocalOcrProvider | None:
    """Accept only the Local Provider whose private budget can be enforced."""
    if provider is not None and type(provider) is not LocalOcrProvider:
        raise BatchConfigurationError(
            "Workflow Batch Local OCR requires the built-in bounded Provider"
        )
    return provider


def _workflow_batch_mode(
    *,
    request: DocumentWorkflowRequest | None,
    providers: DocumentWorkflowProviders | None,
    artifact_store: WorkflowArtifactStore | None,
) -> _WorkflowBatchMode | None:
    """Validate one optional Workflow execution mode without source access."""
    if request is None and providers is None:
        if artifact_store is not None:
            raise BatchConfigurationError(
                "Workflow Artifact Store requires Workflow Batch mode"
            )
        return None
    if request is None or providers is None:
        raise BatchConfigurationError(
            "Workflow Batch mode requires a request and Provider bundle"
        )
    try:
        validated_request = _validated_workflow_request(request)
        validated_providers = _validated_workflow_providers(providers)
        identity_payload: dict[str, object] = {
            "request_identity": validated_request.fingerprint(),
        }
        local_provider: LocalOcrProvider | None = None
        if validated_request.ocr_route is WorkflowOcrRoute.LOCAL:
            declared_local = validated_providers.local_ocr
            runtime_local = (
                None
                if declared_local is None
                else declared_local.provider
                if type(declared_local) is WorkflowLocalOcrProvider
                else declared_local
            )
            local_provider = _bounded_workflow_local_provider(runtime_local)
            identity_payload["local_ocr"] = (
                None
                if runtime_local is None
                else _workflow_ocr_provider_identity(runtime_local)
            )
        if (
            validated_request.ocr_route is WorkflowOcrRoute.AZURE
            or validated_request.pdf_processing_mode
            is WorkflowPdfProcessingMode.AZURE_FIRST
        ):
            azure = validated_providers.azure
            identity_payload["azure"] = (
                None if azure is None else _workflow_ocr_provider_identity(azure)
            )
        identity = hashlib.sha256(
            b"document-sdk:batch-workflow-mode:v1\0"
            + json.dumps(
                identity_payload,
                ensure_ascii=False,
                separators=(",", ":"),
                sort_keys=True,
            ).encode()
        ).hexdigest()
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            BatchConfigurationError("Workflow Batch configuration is invalid"),
        )
    return _WorkflowBatchMode(
        request=validated_request,
        providers=validated_providers,
        artifact_store=artifact_store,
        identity=identity,
        local_provider=local_provider,
    )


def _cloud_execution_policy(
    provider: object | None,
) -> CloudExecutionPolicy | None:
    """Read the trusted Azure policy from the existing Provider projection."""
    if provider is None or not _is_actual_azure_provider(provider):
        return None
    if type(provider) is not AzureDocumentIntelligenceProvider:
        return None
    try:
        projection = _read_provider_context_projection_safely(
            provider,
            error=BatchConfigurationError("Azure cloud execution policy is invalid"),
        )
        config = projection.processing_identity.get("config")
        if type(config) is not dict:
            if type(provider) is AzureDocumentIntelligenceProvider:
                raise ValueError(  # noqa: TRY301
                    "Azure Provider configuration is unavailable"
                )
            return None
        policy = config.get("cloud_execution_policy")
        if type(policy) is not dict:
            if type(provider) is AzureDocumentIntelligenceProvider:
                raise ValueError(  # noqa: TRY301
                    "Azure cloud execution policy is unavailable"
                )
            return None
        return CloudExecutionPolicy.model_validate(policy)
    except BatchConfigurationError:
        raise
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            BatchConfigurationError("Azure cloud execution policy is invalid"),
        )


def _add_local_usage(
    totals: ProviderUsageTotals,
    usage: ProviderUsage | None,
) -> ProviderUsageTotals:
    """Add one content-free Local OCR usage projection exactly once."""
    if usage is None:
        return totals
    return totals.model_copy(
        update={
            "local_operation_count": (
                totals.local_operation_count + usage.local_operation_count
            ),
            "local_page_count": totals.local_page_count + usage.local_page_count,
            "local_frame_count": totals.local_frame_count + usage.local_frame_count,
            "local_region_count": (
                totals.local_region_count + usage.local_region_count
            ),
            "local_attempted_region_count": (
                totals.local_attempted_region_count + usage.local_attempted_region_count
            ),
            "local_input_pixel_count": (
                totals.local_input_pixel_count + usage.local_input_pixel_count
            ),
            "local_output_character_count": (
                totals.local_output_character_count + usage.local_output_character_count
            ),
            "local_attempted_output_character_count": (
                totals.local_attempted_output_character_count
                + usage.local_attempted_output_character_count
            ),
            "local_preprocessing_attempt_count": (
                totals.local_preprocessing_attempt_count
                + usage.local_preprocessing_attempt_count
            ),
            "local_preprocessing_operation_count": (
                totals.local_preprocessing_operation_count
                + usage.local_preprocessing_operation_count
            ),
            "local_preprocessing_pixel_count": (
                totals.local_preprocessing_pixel_count
                + usage.local_preprocessing_pixel_count
            ),
        }
    )


def _add_local_usages(
    totals: ProviderUsageTotals,
    usages: tuple[ProviderUsage, ...],
) -> ProviderUsageTotals:
    """Add an ordered retained attempt history exactly once."""
    for usage in usages:
        totals = _add_local_usage(totals, usage)
    return totals


def _failed_local_usage(
    error: BaseException,
    invocation_state: _LocalOcrInvocationState | None,
) -> ProviderUsage | None:
    """Recover error-carried or validated invocation usage without content."""
    usage = _attempt_usage(error)
    if usage is None and invocation_state is not None:
        usage = invocation_state.provider_usage
    return usage


def _validated_local_provider_limits(
    provider: LocalOcrProvider,
) -> LocalOcrProcessingLimits:
    """Read and rebuild the SDK base limits slot without subclass dispatch."""
    try:
        limits_slot = LocalOcrProvider.__dict__["_LocalOcrProvider__limits"]
        value = limits_slot.__get__(provider, LocalOcrProvider)
        return _revalidate_model_instance_json(
            value,
            LocalOcrProcessingLimits,
            "Local OCR Provider limits are invalid",
        )
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            BatchConfigurationError("Local OCR Provider limits are invalid"),
        )


def _validated_local_preprocessing_policy(
    provider: LocalOcrProvider,
) -> LocalOcrPreprocessingPolicy:
    """Read and rebuild the SDK preprocessing policy without property dispatch."""
    try:
        policy_slot = LocalOcrProvider.__dict__[
            "_LocalOcrProvider__preprocessing_policy"
        ]
        value = policy_slot.__get__(provider, LocalOcrProvider)
        return _revalidate_model_instance_json(
            value,
            LocalOcrPreprocessingPolicy,
            "Local OCR Provider preprocessing policy is invalid",
        )
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            BatchConfigurationError(
                "Local OCR Provider preprocessing policy is invalid"
            ),
        )


def _batch_local_limit_was_narrowed(
    error: LocalOcrLimitExceededError,
    provider: LocalOcrProvider,
    invocation_state: _LocalOcrInvocationState,
) -> bool:
    """Classify only limits narrowed by the cumulative private Batch budget."""
    if type(error) not in (
        LocalOcrLimitExceededError,
        LocalOcrPreprocessingLimitError,
    ):
        return False
    if error.limit_name not in invocation_state.batch_narrowed_limit_names:
        return False
    budget = invocation_state.usage_budget
    if not isinstance(budget, _LocalOcrUsageBudget):
        return False
    provider_limits = _validated_local_provider_limits(provider)
    narrowed = {
        "operation count": budget.operations < provider_limits.max_operations,
        "total regions": budget.regions < provider_limits.max_total_regions,
        "total pixels": budget.pixels < provider_limits.max_total_pixels,
        "total text characters": (
            budget.characters < provider_limits.max_total_text_characters
        ),
    }
    if error.limit_name in {
        "preprocessing attempts per document",
        "total preprocessing pixels",
        "preprocessing operations",
    }:
        preprocessing_limits = _validated_local_preprocessing_policy(provider).limits
        narrowed.update(
            {
                "preprocessing attempts per document": (
                    budget.preprocessing_attempts
                    < preprocessing_limits.max_extra_attempts_per_document
                ),
                "total preprocessing pixels": (
                    budget.preprocessing_pixels
                    < preprocessing_limits.max_total_preprocessing_pixels
                ),
                "preprocessing operations": (
                    budget.preprocessing_operations
                    < preprocessing_limits.max_extra_attempts_per_document
                ),
            }
        )
    return narrowed.get(error.limit_name, False)


def _local_usage_at_limit(
    totals: ProviderUsageTotals,
    limits: BatchProcessingLimits,
) -> bool:
    """Return whether any cumulative Local OCR budget is exhausted."""
    return (
        totals.local_operation_count >= limits.max_total_local_ocr_operations
        or totals.local_attempted_region_count >= limits.max_total_local_ocr_regions
        or totals.local_input_pixel_count >= limits.max_total_local_ocr_pixels
        or totals.local_attempted_output_character_count
        >= limits.max_total_local_ocr_characters
    )


def _local_usage_exceeds_limit(
    totals: ProviderUsageTotals,
    limits: BatchProcessingLimits,
) -> bool:
    """Return whether successful Local usage crossed a cumulative hard limit."""
    return (
        totals.local_operation_count > limits.max_total_local_ocr_operations
        or totals.local_attempted_region_count > limits.max_total_local_ocr_regions
        or totals.local_input_pixel_count > limits.max_total_local_ocr_pixels
        or totals.local_attempted_output_character_count
        > limits.max_total_local_ocr_characters
    )


def _local_window_size(
    provider: LocalOcrProvider,
    *,
    totals: ProviderUsageTotals,
    limits: BatchProcessingLimits,
) -> int:
    """Bound in-flight work by remaining Batch and per-document maxima."""
    # Prepared Batch evidence intentionally contains no runtime raster. Without
    # an exact per-item pixel requirement, concurrent preprocessing reservation
    # would either oversell the shared cap or give the first invocation all
    # remaining headroom. Serialize only the opt-in preprocessing path so each
    # completed item's unused reservation becomes deterministically available
    # to the next item/window.
    if provider.preprocessing_policy.enabled:
        return 1
    local_limits = _validated_local_provider_limits(provider)
    capacities = (
        (limits.max_total_local_ocr_operations - totals.local_operation_count)
        // local_limits.max_operations,
        (limits.max_total_local_ocr_regions - totals.local_attempted_region_count)
        // local_limits.max_total_regions,
        (limits.max_total_local_ocr_pixels - totals.local_input_pixel_count)
        // local_limits.max_total_pixels,
        (
            limits.max_total_local_ocr_characters
            - totals.local_attempted_output_character_count
        )
        // local_limits.max_total_text_characters,
        max(
            1,
            limits.max_total_local_preprocessing_attempts
            - totals.local_preprocessing_attempt_count,
        ),
    )
    return min(limits.max_workers, max(1, min(capacities)))


def _local_window_invocations(
    provider: LocalOcrProvider,
    *,
    count: int,
    totals: ProviderUsageTotals,
    limits: BatchProcessingLimits,
) -> tuple[_LocalOcrInvocationState, ...]:
    """Reserve disjoint worst-case headroom for every in-flight Local call."""
    remaining_operations = (
        limits.max_total_local_ocr_operations - totals.local_operation_count
    )
    remaining_regions = (
        limits.max_total_local_ocr_regions - totals.local_attempted_region_count
    )
    remaining_pixels = (
        limits.max_total_local_ocr_pixels - totals.local_input_pixel_count
    )
    remaining_characters = (
        limits.max_total_local_ocr_characters
        - totals.local_attempted_output_character_count
    )
    remaining_preprocessing_attempts = (
        limits.max_total_local_preprocessing_attempts
        - totals.local_preprocessing_attempt_count
    )
    remaining_preprocessing_pixels = (
        limits.max_total_local_preprocessing_pixels
        - totals.local_preprocessing_pixel_count
    )
    remaining_preprocessing_operations = (
        limits.max_total_local_preprocessing_operations
        - totals.local_preprocessing_operation_count
    )
    local_limits = _validated_local_provider_limits(provider)
    preprocessing_policy = _validated_local_preprocessing_policy(provider)
    preprocessing_limits = preprocessing_policy.limits
    invocations: list[_LocalOcrInvocationState] = []
    for _ in range(count):
        budget = _LocalOcrUsageBudget(
            operations=min(local_limits.max_operations, remaining_operations),
            regions=min(local_limits.max_total_regions, remaining_regions),
            pixels=min(local_limits.max_total_pixels, remaining_pixels),
            characters=min(
                local_limits.max_total_text_characters,
                remaining_characters,
            ),
            preprocessing_attempts=max(0, remaining_preprocessing_attempts),
            preprocessing_pixels=max(0, remaining_preprocessing_pixels),
            preprocessing_operations=max(0, remaining_preprocessing_operations),
        )
        narrowed_limit_names = frozenset(
            name
            for name, reserved, maximum in (
                ("operation count", budget.operations, local_limits.max_operations),
                ("total regions", budget.regions, local_limits.max_total_regions),
                ("total pixels", budget.pixels, local_limits.max_total_pixels),
                (
                    "total text characters",
                    budget.characters,
                    local_limits.max_total_text_characters,
                ),
                *(
                    (
                        (
                            "preprocessing attempts per document",
                            budget.preprocessing_attempts,
                            preprocessing_limits.max_extra_attempts_per_document,
                        ),
                        (
                            "total preprocessing pixels",
                            budget.preprocessing_pixels,
                            preprocessing_limits.max_total_preprocessing_pixels,
                        ),
                        (
                            "preprocessing operations",
                            budget.preprocessing_operations,
                            preprocessing_limits.max_extra_attempts_per_document,
                        ),
                    )
                    if preprocessing_policy.enabled
                    else ()
                ),
            )
            if reserved < maximum
        )
        invocations.append(
            _LocalOcrInvocationState(
                usage_budget=budget,
                batch_narrowed_limit_names=narrowed_limit_names,
            )
        )
        remaining_operations -= budget.operations
        remaining_regions -= budget.regions
        remaining_pixels -= budget.pixels
        remaining_characters -= budget.characters
        remaining_preprocessing_attempts -= budget.preprocessing_attempts
        remaining_preprocessing_pixels -= budget.preprocessing_pixels
        remaining_preprocessing_operations -= budget.preprocessing_operations
    return tuple(invocations)


def _pending_requires_local_ocr(
    pending: _PendingItem,
    *,
    options: DocumentAnalysisOptions,
    schema: ExtractionSchema | None,
) -> bool:
    """Determine Local OCR demand from prepared facts without Provider access."""
    document_type = pending.prepared.detection.envelope.document_type
    if document_type is DocumentType.IMAGE:
        return True
    if document_type is not DocumentType.PDF:
        return False
    payload = pending.prepared.inspection.inspection
    if not isinstance(payload, PdfDocumentInspection):
        raise BatchConfigurationError(
            "Prepared PDF inspection evidence is inconsistent"
        )
    has_ocr_candidates = bool(payload.inspection.ocr_candidate_page_numbers)
    if schema is None:
        return options.pdf_mode is PdfAnalysisMode.HYBRID and has_ocr_candidates
    structured = options.structured_extraction_options or StructuredExtractionOptions()
    if structured.strategy is ExtractionStrategy.HYBRID_EXISTING:
        return has_ocr_candidates
    return True


def _fingerprints(
    *,
    analysis_options: DocumentAnalysisOptions,
    batch_options: BatchProcessingOptions,
    limits: BatchProcessingLimits,
    schema: ExtractionSchema | None,
    provider_profile_id: str | None,
    provider_resume_fingerprint: str | None,
    workflow_identity: str | None = None,
    preprocessing_enabled: bool = False,
) -> tuple[str, str | None]:
    analysis_options = _revalidate_model_instance_json(
        analysis_options,
        DocumentAnalysisOptions,
        "Document analysis options are invalid",
    )
    schema_fingerprint = (
        None
        if schema is None
        else hashlib.sha256(schema.model_dump_json(by_alias=True).encode()).hexdigest()
    )
    limit_payload = limits.model_dump(mode="json")
    if not preprocessing_enabled:
        for name in (
            "max_total_local_preprocessing_attempts",
            "max_total_local_preprocessing_pixels",
            "max_total_local_preprocessing_operations",
        ):
            limit_payload.pop(name)
    evidence = {
        "sdk_version": __version__,
        "analysis_options": document_processing._analysis_options_identity_payload(
            analysis_options
        ),
        "batch_options": batch_options.model_dump(mode="json"),
        "limits": limit_payload,
        "schema_id": None if schema is None else schema.schema_id,
        "schema_version": None if schema is None else schema.schema_version,
        "schema_fingerprint": schema_fingerprint,
        "provider_profile_id": provider_profile_id,
        "provider_resume_fingerprint": provider_resume_fingerprint,
    }
    if workflow_identity is not None:
        evidence["workflow_identity"] = workflow_identity
    structured_options = analysis_options.structured_extraction_options
    structured_quality_policy = (
        None
        if structured_options is None
        else structured_options.local_ocr_quality_policy
    )
    if structured_quality_policy is not None:
        evidence["local_ocr_quality_identity"] = local_ocr_quality_identity(
            intrinsic_policy=LocalOcrIntrinsicQualityPolicy(),
            structured_policy=structured_quality_policy,
        )
    options_fingerprint = hashlib.sha256(
        json.dumps(evidence, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    return options_fingerprint, schema_fingerprint


def _validate_inputs(
    inputs: tuple[BatchDocumentInput, ...],
) -> tuple[BatchDocumentInput, ...]:
    ids = Counter(item.input_id for item in inputs)
    names = Counter(item.relative_name for item in inputs)
    if any(count > 1 for count in ids.values()):
        raise BatchConfigurationError(
            "Batch input identifiers must be unique before processing"
        )
    if any(count > 1 for count in names.values()):
        raise BatchConfigurationError(
            "Batch relative names must be unique before processing"
        )
    return tuple(
        sorted(
            inputs,
            key=lambda item: (
                item.relative_name.casefold(),
                item.relative_name,
                item.input_id,
            ),
        )
    )


def _revalidate_batch_request(
    inputs: Iterable[BatchDocumentInput],
    *,
    analysis_options: DocumentAnalysisOptions | None,
    extraction_schema: ExtractionSchema | None,
    batch_options: BatchProcessingOptions | None,
    limits: BatchProcessingLimits | None,
) -> tuple[
    tuple[BatchDocumentInput, ...],
    DocumentAnalysisOptions,
    ExtractionSchema | None,
    BatchProcessingOptions,
    BatchProcessingLimits,
]:
    """Rebuild every caller-controlled model before any file or Provider access."""
    try:
        validated_inputs = tuple(
            BatchDocumentInput.model_validate(item) for item in tuple(inputs)
        )
        effective_analysis = (
            DocumentAnalysisOptions()
            if analysis_options is None
            else _revalidate_model_instance_json(
                analysis_options,
                DocumentAnalysisOptions,
                "Document analysis options are invalid",
            )
        )
        effective_schema = (
            None
            if extraction_schema is None
            else _revalidate_model_instance_json(
                extraction_schema,
                ExtractionSchema,
                "Extraction schema is invalid",
            )
        )
        effective_batch = (
            BatchProcessingOptions()
            if batch_options is None
            else _revalidate_model_instance_json(
                batch_options,
                BatchProcessingOptions,
                "Batch processing options are invalid",
            )
        )
        effective_limits = (
            BatchProcessingLimits()
            if limits is None
            else _revalidate_model_instance_json(
                limits,
                BatchProcessingLimits,
                "Batch processing limits are invalid",
            )
        )
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            BatchConfigurationError("Batch processing request is invalid"),
        )
    return (
        _validate_inputs(validated_inputs),
        effective_analysis,
        effective_schema,
        effective_batch,
        effective_limits,
    )


def _revalidate_resume_boundary(
    manifest: BatchProcessingManifest | None,
) -> BatchProcessingManifest | None:
    if manifest is None:
        return None
    try:
        return _revalidate_model_instance_json(
            manifest,
            BatchProcessingManifest,
            "The resume manifest is invalid",
        )
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            BatchManifestError("The resume manifest is invalid"),
        )


def _validate_resume(
    manifest: BatchProcessingManifest | None,
    *,
    options_fingerprint: str,
    schema: ExtractionSchema | None,
    schema_fingerprint: str | None,
    provider_profile_id: str | None,
) -> dict[str, BatchManifestItem]:
    if manifest is None:
        return {}
    if (
        manifest.manifest_version != "3"
        or manifest.sdk_version != __version__
        or manifest.processing_options_fingerprint != options_fingerprint
        or manifest.schema_id != (None if schema is None else schema.schema_id)
        or manifest.schema_version
        != (None if schema is None else schema.schema_version)
        or manifest.schema_fingerprint != schema_fingerprint
        or manifest.provider_profile_id != provider_profile_id
    ):
        raise BatchManifestError(
            "The resume manifest is incompatible with this batch configuration"
        )
    eligible_statuses = {
        BatchItemStatus.SUCCEEDED,
        BatchItemStatus.SKIPPED_PREVIOUS_SUCCESS,
    }
    if any(
        item.resume_eligible_success and item.status not in eligible_statuses
        for item in manifest.items
    ):
        raise BatchManifestError(
            "The resume manifest contains invalid success evidence"
        )
    return {item.input_id: item for item in manifest.items}


def _result_fingerprint(result: object) -> str:
    return _canonical_document_result_fingerprint(result)  # type: ignore[arg-type]


def _family_evidence(
    prepared: _PreparedDocument,
) -> _FamilyEvidence:
    inspection = prepared.inspection
    return {
        "document_type": prepared.detection.envelope.document_type,
        "document_format": prepared.detection.envelope.document_format,
        "pdf_page_count": inspection.pdf_page_count,
        "excel_worksheet_count": inspection.excel_worksheet_count,
        "image_frame_count": inspection.image_frame_count,
        "docx_block_count": inspection.docx_block_count,
    }


def _detection_evidence(detection: object) -> dict[str, Any]:
    envelope = detection.envelope  # type: ignore[attr-defined]
    return {
        "source_sha256": envelope.sha256,
        "byte_size": envelope.byte_size,
        "document_type": envelope.document_type,
        "document_format": envelope.document_format,
    }


def _prior_family_evidence(prior: BatchManifestItem) -> _FamilyEvidence:
    if prior.document_type is None or prior.document_format is None:
        raise BatchManifestError(
            "The prior family evidence is incomplete"
        ) from ValueError("redacted")
    return {
        "document_type": prior.document_type,
        "document_format": prior.document_format,
        "pdf_page_count": prior.pdf_page_count,
        "excel_worksheet_count": prior.excel_worksheet_count,
        "image_frame_count": prior.image_frame_count,
        "docx_block_count": prior.docx_block_count,
    }


def _completed_operations(*names: str) -> tuple[OperationCount, ...]:
    return tuple(OperationCount(name=name, count=1) for name in sorted(names))


def _cancelled(
    item: BatchDocumentInput,
    *,
    prepared: _PreparedDocument | None = None,
    prior: BatchManifestItem | None = None,
    byte_size: int | None = None,
    consumed_input_bytes: int = 0,
    provider_usage: ProviderUsage | None = None,
    retained_provider_usage: tuple[ProviderUsage, ...] = (),
    retained_azure_fallback_attempts: tuple[AzureFallbackAttemptEvidence, ...] = (),
    retained_cloud_execution_attempts: tuple[CloudExecutionAttemptEvidence, ...] = (),
) -> BatchItemResult:
    payload: dict[str, Any] = {
        "input_id": item.input_id,
        "relative_name": item.relative_name,
        "status": BatchItemStatus.CANCELLED_BY_LIMIT,
        "byte_size": byte_size,
        "consumed_input_bytes": consumed_input_bytes,
        "issues": (
            _safe_issue(
                "batch.cancelled_by_limit",
                "limit",
                "The item was not processed because a batch limit was reached.",
            ),
        ),
        "provider_usage": provider_usage,
        "provider_operation_counts": (
            _completed_operations("provider_analysis")
            if provider_usage is not None
            else ()
        ),
        "retained_provider_usage": retained_provider_usage,
        "retained_azure_fallback_attempts": retained_azure_fallback_attempts,
        "retained_cloud_execution_attempts": retained_cloud_execution_attempts,
    }
    if prepared is not None:
        payload.update(
            {
                "source_sha256": prepared.detection.envelope.sha256,
                "byte_size": prepared.detection.envelope.byte_size,
                "consumed_input_bytes": prepared.detection.envelope.byte_size,
                "performed_operation_counts": _completed_operations(
                    "detection", "inspection"
                ),
                **_family_evidence(prepared),
            }
        )
    elif prior is not None:
        payload.update(
            {
                "source_sha256": prior.source_sha256,
                "byte_size": prior.byte_size,
                "consumed_input_bytes": prior.byte_size,
                "performed_operation_counts": _completed_operations("detection"),
                **_prior_family_evidence(prior),
            }
        )
    return BatchItemResult.model_validate(payload)


def _failed(
    item: BatchDocumentInput,
    *,
    prepared: _PreparedDocument | None = None,
    prior: BatchManifestItem | None = None,
    detection: object | None = None,
    category: str = "processing",
    byte_size: int | None = None,
    consumed_input_bytes: int = 0,
    provider_usage: ProviderUsage | None = None,
    provider_usage_breakdown: tuple[ProviderUsage, ...] = (),
    workflow_provider_evidence: bool = False,
    retained_provider_usage: tuple[ProviderUsage, ...] = (),
    retained_azure_fallback_attempts: tuple[AzureFallbackAttemptEvidence, ...] = (),
    azure_fallback_attempt: AzureFallbackAttemptEvidence | None = None,
    retained_cloud_execution_attempts: tuple[CloudExecutionAttemptEvidence, ...] = (),
    cloud_execution_attempts: tuple[CloudExecutionAttemptEvidence, ...] = (),
) -> BatchItemResult:
    source_changed = category == "source_changed"
    payload: dict[str, Any] = {
        "input_id": item.input_id,
        "relative_name": item.relative_name,
        "status": BatchItemStatus.FAILED,
        "byte_size": byte_size,
        "consumed_input_bytes": consumed_input_bytes,
        "issues": (
            _safe_issue(
                ("batch.source_changed" if source_changed else "batch.item_failed"),
                category,
                (
                    "The source changed before its result could be committed."
                    if source_changed
                    else "The item could not be processed safely."
                ),
            ),
        ),
        "provider_usage": provider_usage,
        "provider_usage_breakdown": provider_usage_breakdown,
        "retained_provider_usage": retained_provider_usage,
        "retained_azure_fallback_attempts": retained_azure_fallback_attempts,
        "azure_fallback_attempt": azure_fallback_attempt,
        "retained_cloud_execution_attempts": retained_cloud_execution_attempts,
        "cloud_execution_attempts": cloud_execution_attempts,
        "local_ocr_quality_summary": (
            None
            if azure_fallback_attempt is None
            else azure_fallback_attempt.trigger_quality_summary
        ),
        "provider_operation_counts": (
            _completed_operations(
                "workflow_provider_analysis"
                if workflow_provider_evidence
                else "provider_analysis"
            )
            if (
                (provider_usage_breakdown or cloud_execution_attempts)
                if workflow_provider_evidence
                else provider_usage is not None
            )
            else ()
        ),
    }
    if prepared is not None:
        payload.update(
            {
                "source_sha256": prepared.detection.envelope.sha256,
                "byte_size": prepared.detection.envelope.byte_size,
                "consumed_input_bytes": prepared.detection.envelope.byte_size,
                "performed_operation_counts": _completed_operations(
                    "detection", "inspection"
                ),
                **_family_evidence(prepared),
            }
        )
    elif detection is not None:
        payload.update(_detection_evidence(detection))
        if prior is not None:
            payload.update(
                {
                    **_prior_family_evidence(prior),
                    "retained_prior_operation_counts": (
                        prior.retained_prior_operation_counts
                        or prior.performed_operation_counts
                    ),
                }
            )
        payload["consumed_input_bytes"] = max(
            consumed_input_bytes,
            payload["byte_size"],
        )
        payload["performed_operation_counts"] = _completed_operations("detection")
    return BatchItemResult.model_validate(payload)


def _is_regular_batch_source(path: Path) -> bool:
    try:
        mode = path.lstat().st_mode
    except OSError:
        return False
    return stat.S_ISREG(mode) and not stat.S_ISLNK(mode)


def _source_identity_matches(
    item: BatchDocumentInput,
    *,
    sha256: str,
    byte_size: int,
) -> bool:
    """Recheck one source with a bounded read and no family processing."""
    if not _is_regular_batch_source(item.source):
        return False
    try:
        actual = document_processing._raw_identity(
            item.source,
            max_bytes=byte_size,
        )
    except Exception:
        return False
    return actual == (sha256, byte_size)


def _batch_family_analysis_options(
    document_type: DocumentType,
    options: DocumentAnalysisOptions,
) -> DocumentAnalysisOptions:
    """Apply PDF routing only to PDF items in a heterogeneous Batch."""
    if document_type is DocumentType.PDF or (
        options.pdf_mode is PdfAnalysisMode.NATIVE
        and options.hybrid_pdf_options is None
    ):
        return options
    return DocumentAnalysisOptions.model_validate(
        options.model_dump(mode="json")
        | {
            "pdf_mode": PdfAnalysisMode.NATIVE.value,
            "hybrid_pdf_options": None,
        }
    )


def _analyze_pending(
    pending: _PendingItem,
    *,
    options: DocumentAnalysisOptions,
    schema: ExtractionSchema | None,
    provider: OcrProvider | None,
    azure_fallback_provider: object | None,
    local_invocation_state: _LocalOcrInvocationState | None = None,
) -> BatchItemResult:
    if not _is_regular_batch_source(pending.item.source):
        raise BatchConfigurationError(
            "The batch source is no longer a regular non-symlink file"
        )
    document_type = pending.prepared.detection.envelope.document_type
    item_options = _batch_family_analysis_options(document_type, options)
    if document_type is DocumentType.PDF:
        with _PDF_ANALYSIS_LOCK:
            result = _analyze_prepared_document(
                pending.prepared,
                options=item_options,
                extraction_schema=schema,
                ocr_provider=provider,
                azure_fallback_provider=azure_fallback_provider,
                limits=None,
                local_invocation_state=local_invocation_state,
            )
    else:
        result = _analyze_prepared_document(
            pending.prepared,
            options=item_options,
            extraction_schema=schema,
            ocr_provider=provider,
            azure_fallback_provider=azure_fallback_provider,
            limits=None,
            local_invocation_state=local_invocation_state,
        )
    envelope = result.envelope
    performed = result.processing_manifest.operation_counts
    provider_counts = (
        (OperationCount(name="provider_analysis", count=1),)
        if result.provider_usage_breakdown or result.provider_usage is not None
        else ()
    )
    return BatchItemResult(
        input_id=pending.item.input_id,
        relative_name=pending.item.relative_name,
        status=BatchItemStatus.SUCCEEDED,
        result=result,
        source_sha256=envelope.sha256,
        byte_size=envelope.byte_size,
        consumed_input_bytes=envelope.byte_size,
        result_fingerprint=_result_fingerprint(result),
        resume_eligible_success=True,
        performed_operation_counts=performed,
        provider_operation_counts=provider_counts,
        provider_usage=result.provider_usage,
        provider_usage_breakdown=result.provider_usage_breakdown,
        azure_fallback_summary=result.azure_fallback_report,
        retained_provider_usage=pending.retained_provider_usage,
        retained_azure_fallback_attempts=(pending.retained_azure_fallback_attempts),
        retained_cloud_execution_attempts=(pending.retained_cloud_execution_attempts),
        cloud_execution_attempts=result.cloud_execution_attempts,
        local_ocr_quality_summary=(
            result.processing_manifest.local_ocr_quality_summary
        ),
        local_ocr_preprocessing_summary=(
            result.processing_manifest.local_ocr_preprocessing_summary
        ),
        **_family_evidence(pending.prepared),
    )


def _workflow_intake_issue_projection(
    intake: DocumentWorkflowIntakeResult,
) -> tuple[BatchItemIssue, ...]:
    workflow = intake.workflow_result
    issues = intake.issues if workflow is None else workflow.issues
    return tuple(
        _safe_issue(
            issue.code,
            issue.category.value,
            issue.message,
        )
        for issue in issues
    )


def _workflow_source_changed_batch_item(
    item: BatchDocumentInput,
    *,
    intake: DocumentWorkflowIntakeResult | None,
    local_invocation_state: _LocalOcrInvocationState | None,
    error: BaseException | None,
    consumed_input_bytes: int,
    retained_provider_usage: tuple[ProviderUsage, ...],
    retained_azure_fallback_attempts: tuple[AzureFallbackAttemptEvidence, ...],
    retained_cloud_execution_attempts: tuple[CloudExecutionAttemptEvidence, ...],
) -> BatchItemResult:
    """Discard stale payload identity while retaining attempted Workflow work."""
    workflow = None if intake is None else intake.workflow_result
    current_usage: tuple[ProviderUsage, ...] = ()
    current_attempts: tuple[CloudExecutionAttemptEvidence, ...] = ()
    if intake is not None and workflow is not None:
        current_usage = workflow.usage.current_provider_usage
        current_attempts = workflow.usage.current_cloud_attempts
        retained_provider_usage += workflow.usage.retained_provider_usage
        retained_cloud_execution_attempts += workflow.usage.retained_cloud_attempts
    else:
        local_usage = (
            None
            if local_invocation_state is None
            else local_invocation_state.provider_usage
        )
        direct_usage: tuple[ProviderUsage, ...] = ()
        direct_attempts: tuple[CloudExecutionAttemptEvidence, ...] = ()
        fallback_attempt = None
        if error is not None:
            error_usage = _attempt_usage(error)
            if error_usage is not None:
                local_usage = error_usage
            direct_usage, direct_attempts = _direct_cloud_failure_evidence(error)
            fallback_attempt = _fallback_attempt_evidence(error)
        current_usage = (() if local_usage is None else (local_usage,)) + direct_usage
        current_attempts = direct_attempts
        if fallback_attempt is not None:
            retained_provider_usage += _attempt_confirmed_usages(fallback_attempt)
            retained_azure_fallback_attempts += (fallback_attempt,)

    return _failed(
        item,
        category="source_changed",
        consumed_input_bytes=consumed_input_bytes,
        provider_usage_breakdown=current_usage,
        workflow_provider_evidence=True,
        retained_provider_usage=retained_provider_usage,
        retained_azure_fallback_attempts=retained_azure_fallback_attempts,
        retained_cloud_execution_attempts=retained_cloud_execution_attempts,
        cloud_execution_attempts=current_attempts,
    )


def _workflow_batch_item_from_intake(
    item: BatchDocumentInput,
    intake: DocumentWorkflowIntakeResult,
    *,
    prepared: _PreparedDocument | None,
    measured_byte_size: int,
    retained_provider_usage: tuple[ProviderUsage, ...] = (),
) -> BatchItemResult:
    if retained_provider_usage:
        if not _is_local_only_usage_history(retained_provider_usage):
            raise BatchConfigurationError(
                "Workflow Batch retry history is not Local-only"
            )
        workflow = intake.workflow_result
        if workflow is None:
            raise BatchConfigurationError(
                "Workflow Batch retry lacks a completed Workflow result"
            )
        stages: list[WorkflowStageResult] = []
        retained_stage_count = 0
        for stage in workflow.stage_results:
            validated_stage = stage
            if (
                stage.kind is WorkflowStageKind.OCR_OR_AZURE
                and stage.provider_category is WorkflowProviderCategory.LOCAL_OCR
            ):
                retained_stage_count += 1
                validated_stage = WorkflowStageResult.model_validate(
                    stage.model_dump(mode="json")
                    | {
                        "retained_provider_usage": tuple(
                            item.model_dump(mode="json")
                            for item in retained_provider_usage
                            + stage.retained_provider_usage
                        )
                    }
                )
            stages.append(validated_stage)
        if retained_stage_count != 1:
            raise BatchConfigurationError(
                "Workflow Batch Local retry stage is inconsistent"
            )
        stage_results = tuple(stages)
        usage = workflow_usage_from_stages(stage_results)
        manifest = DocumentWorkflowManifest.model_validate(
            workflow.manifest.model_dump(mode="json")
            | {
                "stages": tuple(
                    stage.model_dump(mode="json") for stage in stage_results
                ),
                "usage": usage.model_dump(mode="json"),
            }
        )
        workflow = DocumentWorkflowResult.model_validate(
            workflow.model_dump(mode="json")
            | {
                "stage_results": tuple(
                    stage.model_dump(mode="json") for stage in stage_results
                ),
                "usage": usage.model_dump(mode="json"),
                "manifest": manifest.model_dump(mode="json"),
            }
        )
        intake = DocumentWorkflowIntakeResult.model_validate(
            intake.model_dump(mode="json")
            | {"workflow_result": workflow.model_dump(mode="json")}
        )
    workflow = intake.workflow_result
    batch_status = {
        DocumentWorkflowIntakeStatus.SUCCEEDED: BatchItemStatus.SUCCEEDED,
        DocumentWorkflowIntakeStatus.PARTIAL: BatchItemStatus.SUCCEEDED,
        DocumentWorkflowIntakeStatus.REVIEW_REQUIRED: BatchItemStatus.SUCCEEDED,
        DocumentWorkflowIntakeStatus.UNSUPPORTED: (BatchItemStatus.SKIPPED_UNSUPPORTED),
        DocumentWorkflowIntakeStatus.REJECTED: BatchItemStatus.FAILED,
        DocumentWorkflowIntakeStatus.FAILED: BatchItemStatus.FAILED,
    }[intake.status]
    payload: dict[str, Any] = {
        "input_id": item.input_id,
        "relative_name": item.relative_name,
        "status": batch_status,
        "intake_status": intake.status,
        "result": intake,
        "byte_size": measured_byte_size,
        "consumed_input_bytes": measured_byte_size,
        "result_fingerprint": _workflow_intake_result_fingerprint(intake),
        "resume_eligible_success": batch_status is BatchItemStatus.SUCCEEDED,
        "issues": _workflow_intake_issue_projection(intake),
    }
    if workflow is None:
        if prepared is not None:
            raise BatchConfigurationError(
                "Pre-Plan Workflow intake retained prepared evidence"
            )
        return BatchItemResult.model_validate(payload)
    if prepared is None:
        raise BatchConfigurationError("Planned Workflow intake lacks Batch evidence")
    envelope = prepared.detection.envelope
    if (
        workflow.source.sha256 != envelope.sha256
        or workflow.source.byte_size != envelope.byte_size
        or workflow.detected_document_type is not envelope.document_type
        or workflow.detected_document_format is not envelope.document_format
    ):
        raise DocumentSourceChangedError(
            "The Workflow Batch source changed during execution"
        )
    current_usage = workflow.usage.current_provider_usage
    current_attempts = workflow.usage.current_cloud_attempts
    payload.update(
        {
            "source_sha256": envelope.sha256,
            "byte_size": envelope.byte_size,
            "consumed_input_bytes": envelope.byte_size,
            "performed_operation_counts": _workflow_intake_operations(),
            "provider_operation_counts": (
                _completed_operations("workflow_provider_analysis")
                if current_usage or current_attempts
                else ()
            ),
            "provider_usage_breakdown": current_usage,
            "retained_provider_usage": workflow.usage.retained_provider_usage,
            "cloud_execution_attempts": current_attempts,
            "retained_cloud_execution_attempts": (
                workflow.usage.retained_cloud_attempts
            ),
            "local_ocr_quality_summary": (workflow.manifest.local_ocr_quality_summary),
            "local_ocr_preprocessing_summary": (
                _workflow_preprocessing_summary(intake)
            ),
            **_family_evidence(prepared),
        }
    )
    return BatchItemResult.model_validate(payload)


def _workflow_preplan_batch_item(
    item: BatchDocumentInput,
    *,
    mode: _WorkflowBatchMode,
    error: BaseException,
    measured_byte_size: int,
    expected_identity: tuple[str, int] | None,
) -> BatchItemResult:
    _validate_intake_caller_inputs(
        mode.request,
        mode.providers,
        mode.artifact_store,
        None,
    )
    if expected_identity is not None and not _source_identity_matches(
        item,
        sha256=expected_identity[0],
        byte_size=expected_identity[1],
    ):
        return _workflow_source_changed_batch_item(
            item,
            intake=None,
            local_invocation_state=None,
            error=None,
            consumed_input_bytes=measured_byte_size,
            retained_provider_usage=(),
            retained_azure_fallback_attempts=(),
            retained_cloud_execution_attempts=(),
        )
    intake = _intake_preplan_exception_result(
        error,
        local_invocation_state=None,
    )
    if intake is None or intake.workflow_result is not None:
        raise BatchConfigurationError(
            "Workflow Batch pre-Plan failure mapping is inconsistent"
        )
    return _workflow_batch_item_from_intake(
        item,
        intake,
        prepared=None,
        measured_byte_size=measured_byte_size,
    )


def _workflow_prepared_source_identity(
    prepared: _PreparedDocument,
) -> WorkflowSourceIdentity:
    """Project Batch-prepared detection into the exact Workflow identity."""
    return workflow_source_identity_from_descriptor(
        _detected_source_descriptor(prepared.detection)
    )


def _workflow_cloud_slot_count(
    pending: _PendingItem,
    request: DocumentWorkflowRequest,
) -> int:
    envelope = pending.prepared.detection.envelope
    azure = bool(
        (
            envelope.document_type is DocumentType.PDF
            and request.pdf_processing_mode is WorkflowPdfProcessingMode.AZURE_FIRST
        )
        or (
            request.ocr_route is WorkflowOcrRoute.AZURE
            and envelope.document_type in {DocumentType.PDF, DocumentType.IMAGE}
            and envelope.document_format is not DocumentFormat.WEBP
        )
    )
    return int(azure)


def _workflow_requires_local_ocr(
    pending: _PendingItem,
    request: DocumentWorkflowRequest,
) -> bool:
    """Identify Local OCR demand from already prepared Workflow evidence."""
    if request.ocr_route is not WorkflowOcrRoute.LOCAL:
        return False
    document_type = pending.prepared.detection.envelope.document_type
    if document_type is DocumentType.IMAGE:
        return True
    if document_type is not DocumentType.PDF:
        return False
    payload = pending.prepared.inspection.inspection
    if not isinstance(payload, PdfDocumentInspection):
        raise BatchConfigurationError(
            "Prepared Workflow PDF inspection evidence is inconsistent"
        )
    return bool(payload.inspection.ocr_candidate_page_numbers)


def _workflow_local_ocr_pixel_counts(
    pending: _PendingItem,
    *,
    provider_limits: LocalOcrProcessingLimits,
) -> tuple[int, ...]:
    """Calculate exact Local OCR part pixels from prepared facts."""
    document_type = pending.prepared.detection.envelope.document_type
    payload = pending.prepared.inspection.inspection
    if document_type is DocumentType.IMAGE:
        if not isinstance(payload, ImageDocumentInspection):
            raise BatchConfigurationError(
                "Prepared Workflow image inspection evidence is inconsistent"
            )
        return tuple(frame.pixel_count for frame in payload.inspection.frames)
    if document_type is not DocumentType.PDF or not isinstance(
        payload, PdfDocumentInspection
    ):
        raise BatchConfigurationError(
            "Prepared Workflow Local OCR evidence is inconsistent"
        )
    inspection = payload.inspection
    page_numbers = inspection.ocr_candidate_page_numbers
    scale = provider_limits.pdf_render_dpi / 72
    pixel_counts: list[int] = []
    for page_number in page_numbers:
        page = inspection.pages[page_number - 1]
        width_points = page.dimensions.width
        height_points = page.dimensions.height
        if page.dimensions.rotation in {90, 270}:
            width_points, height_points = height_points, width_points
        pixel_counts.append(
            math.ceil(width_points * scale) * math.ceil(height_points * scale)
        )
    return tuple(pixel_counts)


def _workflow_local_ocr_demand(
    pending: _PendingItem,
    *,
    provider_limits: LocalOcrProcessingLimits,
) -> _WorkflowLocalOcrDemand:
    """Calculate exact baseline operations and pixels from prepared facts."""
    source_kind: Literal["image", "pdf"] = (
        "image"
        if pending.prepared.detection.envelope.document_type is DocumentType.IMAGE
        else "pdf"
    )
    pixel_counts = _workflow_local_ocr_pixel_counts(
        pending,
        provider_limits=provider_limits,
    )
    return _WorkflowLocalOcrDemand(
        source_kind=source_kind,
        operation_count=len(pixel_counts),
        pixel_count=sum(pixel_counts),
    )


def _workflow_local_demand_exceeds_remaining(
    demand: _WorkflowLocalOcrDemand,
    *,
    totals: ProviderUsageTotals,
    limits: BatchProcessingLimits,
    provider_limits: LocalOcrProcessingLimits,
) -> bool:
    """Return true only when a valid item cannot fit the remaining Batch budget."""
    provider_operation_limit = min(
        provider_limits.max_operations,
        (
            provider_limits.max_frames
            if demand.source_kind == "image"
            else provider_limits.max_pages
        ),
    )
    if (
        demand.operation_count > provider_operation_limit
        or demand.pixel_count > provider_limits.max_total_pixels
    ):
        return False
    remaining_operations = (
        limits.max_total_local_ocr_operations - totals.local_operation_count
    )
    remaining_pixels = (
        limits.max_total_local_ocr_pixels - totals.local_input_pixel_count
    )
    return (
        demand.operation_count > remaining_operations
        or demand.pixel_count > remaining_pixels
    )


def _workflow_local_invocation(
    provider: LocalOcrProvider,
    *,
    totals: ProviderUsageTotals,
    limits: BatchProcessingLimits,
) -> _LocalOcrInvocationState | None:
    """Bind one Workflow invocation to the actual remaining Batch capacity."""
    if _local_usage_at_limit(totals, limits):
        return None
    return _local_window_invocations(
        provider,
        count=1,
        totals=totals,
        limits=limits,
    )[0]


def _prior_local_cancellation_cannot_retry_preprocessing(
    pending: _PendingItem,
    provider: LocalOcrProvider,
    *,
    totals: ProviderUsageTotals,
    limits: BatchProcessingLimits,
    provider_limits: LocalOcrProcessingLimits,
) -> bool:
    """Reject a known retry only when no current preprocessing slot can fit."""
    if not pending.retry_prior_local_limit_cancellation:
        return False
    policy = _validated_local_preprocessing_policy(provider)
    if not policy.enabled:
        return False
    if (
        totals.local_preprocessing_attempt_count
        >= limits.max_total_local_preprocessing_attempts
        or totals.local_preprocessing_operation_count
        >= limits.max_total_local_preprocessing_operations
    ):
        return True
    pixel_counts = _workflow_local_ocr_pixel_counts(
        pending,
        provider_limits=provider_limits,
    )
    minimum_retry_pixels = min(pixel_counts, default=0)
    remaining_pixels = (
        limits.max_total_local_preprocessing_pixels
        - totals.local_preprocessing_pixel_count
    )
    return bool(minimum_retry_pixels and minimum_retry_pixels > remaining_pixels)


def _run_workflow_pending_items(
    pending: list[_PendingItem],
    results: list[BatchItemResult | None],
    *,
    mode: _WorkflowBatchMode,
    limits: BatchProcessingLimits,
    initial_failures: int,
    retained_paid_operations: int,
    initial_local_usage: ProviderUsageTotals,
) -> None:
    failures = initial_failures
    paid_operations = retained_paid_operations
    local_usage = initial_local_usage
    local_provider_limits = (
        None
        if mode.local_provider is None
        else _validated_local_provider_limits(mode.local_provider)
    )
    stop = False
    for entry in pending:
        if stop or failures >= limits.max_failures:
            results[entry.index] = _cancelled(
                entry.item,
                prepared=entry.prepared,
                retained_provider_usage=entry.retained_provider_usage,
                retained_azure_fallback_attempts=(
                    entry.retained_azure_fallback_attempts
                ),
                retained_cloud_execution_attempts=(
                    entry.retained_cloud_execution_attempts
                ),
            )
            continue
        requires_local = bool(
            mode.local_provider is not None
            and _workflow_requires_local_ocr(entry, mode.request)
        )
        if (
            requires_local
            and mode.local_provider is not None
            and local_provider_limits is not None
            and _prior_local_cancellation_cannot_retry_preprocessing(
                entry,
                mode.local_provider,
                totals=local_usage,
                limits=limits,
                provider_limits=local_provider_limits,
            )
        ):
            results[entry.index] = _cancelled(
                entry.item,
                prepared=entry.prepared,
                retained_provider_usage=entry.retained_provider_usage,
                retained_azure_fallback_attempts=(
                    entry.retained_azure_fallback_attempts
                ),
                retained_cloud_execution_attempts=(
                    entry.retained_cloud_execution_attempts
                ),
            )
            continue
        if (
            requires_local
            and mode.local_provider is not None
            and local_provider_limits is not None
            and _workflow_local_demand_exceeds_remaining(
                _workflow_local_ocr_demand(
                    entry,
                    provider_limits=local_provider_limits,
                ),
                totals=local_usage,
                limits=limits,
                provider_limits=local_provider_limits,
            )
        ):
            results[entry.index] = _cancelled(
                entry.item,
                prepared=entry.prepared,
                retained_provider_usage=entry.retained_provider_usage,
                retained_azure_fallback_attempts=(
                    entry.retained_azure_fallback_attempts
                ),
                retained_cloud_execution_attempts=(
                    entry.retained_cloud_execution_attempts
                ),
            )
            continue
        local_invocation = (
            None
            if not requires_local or mode.local_provider is None
            else _workflow_local_invocation(
                mode.local_provider,
                totals=local_usage,
                limits=limits,
            )
        )
        if requires_local and local_invocation is None:
            results[entry.index] = _cancelled(
                entry.item,
                prepared=entry.prepared,
                retained_provider_usage=entry.retained_provider_usage,
                retained_azure_fallback_attempts=(
                    entry.retained_azure_fallback_attempts
                ),
                retained_cloud_execution_attempts=(
                    entry.retained_cloud_execution_attempts
                ),
            )
            continue
        required_cloud_slots = _workflow_cloud_slot_count(entry, mode.request)
        if paid_operations + required_cloud_slots > limits.max_total_paid_operations:
            stop = True
            results[entry.index] = _cancelled(
                entry.item,
                prepared=entry.prepared,
                retained_provider_usage=entry.retained_provider_usage,
                retained_azure_fallback_attempts=(
                    entry.retained_azure_fallback_attempts
                ),
                retained_cloud_execution_attempts=(
                    entry.retained_cloud_execution_attempts
                ),
            )
            continue
        if (
            entry.retained_azure_fallback_attempts
            or entry.retained_cloud_execution_attempts
            or (
                entry.retained_provider_usage
                and not _is_local_only_usage_history(entry.retained_provider_usage)
            )
        ):
            results[entry.index] = _failed(
                entry.item,
                prepared=entry.prepared,
                category="cloud_retry_denied",
                retained_provider_usage=entry.retained_provider_usage,
                retained_azure_fallback_attempts=(
                    entry.retained_azure_fallback_attempts
                ),
                retained_cloud_execution_attempts=(
                    entry.retained_cloud_execution_attempts
                ),
            )
            failures += 1
            continue
        if not _source_identity_matches(
            entry.item,
            sha256=entry.prepared.detection.envelope.sha256,
            byte_size=entry.prepared.detection.envelope.byte_size,
        ):
            results[entry.index] = _failed(
                entry.item,
                category="source_changed",
                consumed_input_bytes=entry.prepared.detection.envelope.byte_size,
                retained_provider_usage=entry.retained_provider_usage,
                retained_azure_fallback_attempts=(
                    entry.retained_azure_fallback_attempts
                ),
                retained_cloud_execution_attempts=(
                    entry.retained_cloud_execution_attempts
                ),
            )
            failures += 1
            continue
        intake: DocumentWorkflowIntakeResult | None = None
        try:
            intake = _run_document_workflow_intake_with_local_budget(
                entry.item.source,
                mode.request,
                providers=mode.providers,
                artifact_store=mode.artifact_store,
                local_invocation_state=local_invocation,
                expected_source_identity=_workflow_prepared_source_identity(
                    entry.prepared
                ),
            )
            if not _source_identity_matches(
                entry.item,
                sha256=entry.prepared.detection.envelope.sha256,
                byte_size=entry.prepared.detection.envelope.byte_size,
            ):
                result = _workflow_source_changed_batch_item(
                    entry.item,
                    intake=intake,
                    local_invocation_state=local_invocation,
                    error=None,
                    consumed_input_bytes=(entry.prepared.detection.envelope.byte_size),
                    retained_provider_usage=entry.retained_provider_usage,
                    retained_azure_fallback_attempts=(
                        entry.retained_azure_fallback_attempts
                    ),
                    retained_cloud_execution_attempts=(
                        entry.retained_cloud_execution_attempts
                    ),
                )
            else:
                result = _workflow_batch_item_from_intake(
                    entry.item,
                    intake,
                    prepared=(
                        entry.prepared if intake.workflow_result is not None else None
                    ),
                    measured_byte_size=entry.prepared.detection.envelope.byte_size,
                    retained_provider_usage=entry.retained_provider_usage,
                )
        except DocumentSourceChangedError as exc:
            result = _workflow_source_changed_batch_item(
                entry.item,
                intake=intake,
                local_invocation_state=local_invocation,
                error=exc,
                consumed_input_bytes=entry.prepared.detection.envelope.byte_size,
                retained_provider_usage=entry.retained_provider_usage,
                retained_azure_fallback_attempts=(
                    entry.retained_azure_fallback_attempts
                ),
                retained_cloud_execution_attempts=(
                    entry.retained_cloud_execution_attempts
                ),
            )
        except LocalOcrLimitExceededError as exc:
            if (
                mode.local_provider is None
                or local_invocation is None
                or not _batch_local_limit_was_narrowed(
                    exc,
                    mode.local_provider,
                    local_invocation,
                )
            ):
                raise BatchConfigurationError(
                    "Workflow Batch Local OCR limit projection is inconsistent"
                ) from None
            usage = _failed_local_usage(exc, local_invocation)
            local_usage = _add_local_usage(local_usage, usage)
            results[entry.index] = _cancelled(
                entry.item,
                prepared=entry.prepared,
                provider_usage=usage,
                retained_provider_usage=entry.retained_provider_usage,
                retained_azure_fallback_attempts=(
                    entry.retained_azure_fallback_attempts
                ),
                retained_cloud_execution_attempts=(
                    entry.retained_cloud_execution_attempts
                ),
            )
            continue
        results[entry.index] = result
        local_usage = _add_local_usages(
            local_usage,
            result.provider_usage_breakdown,
        )
        if (
            requires_local
            and result.status is not BatchItemStatus.FAILED
            and _local_usage_exceeds_limit(local_usage, limits)
        ):
            raise BatchConfigurationError(
                "Workflow Batch Local OCR accounting exceeded its bound"
            )
        paid_operations += sum(
            attempt.paid_or_possibly_paid_operation_count
            for attempt in result.cloud_execution_attempts
        )
        if paid_operations > limits.max_total_paid_operations:
            raise BatchConfigurationError(
                "Workflow Batch cloud accounting exceeded its preflight bound"
            )
        if result.status is BatchItemStatus.FAILED:
            failures += 1


def _manifest_item(item: BatchItemResult) -> BatchManifestItem:
    return BatchManifestItem.model_validate(
        item.model_dump(mode="json", exclude={"result"})
    )


def _has_final_source_identity(result: BatchItemResult) -> bool:
    """Return whether one result claims a complete current source identity."""
    return result.source_sha256 is not None and result.byte_size is not None


def _final_source_changed_result(
    item: BatchDocumentInput,
    result: BatchItemResult,
) -> BatchItemResult:
    """Discard stale current identity while retaining actual safe work once."""
    source_changed_issue = _safe_issue(
        "batch.source_changed",
        "source_changed",
        "The source changed before its result could be committed.",
    )
    retained_issues = tuple(
        issue
        for issue in result.issues
        if issue.code != source_changed_issue.code
        and issue.category != source_changed_issue.category
    )
    retained_operations = _completed_operations(
        *sorted(
            {
                count.name
                for count in (
                    result.retained_prior_operation_counts
                    + result.performed_operation_counts
                )
            }
        )
    )
    if result.status is BatchItemStatus.DUPLICATE:
        current_usage: tuple[ProviderUsage, ...] = ()
        histories = _RetainedCloudHistories((), ())
        retained_provider_usage: tuple[ProviderUsage, ...] = ()
    else:
        current_usage = _current_provider_usage_history(result)
        histories = _retained_cloud_histories(result)
        retained_provider_usage = result.retained_provider_usage + current_usage
    return BatchItemResult.model_validate(
        {
            "input_id": item.input_id,
            "relative_name": item.relative_name,
            "status": BatchItemStatus.FAILED,
            "issues": (source_changed_issue, *retained_issues),
            "consumed_input_bytes": result.consumed_input_bytes,
            "retained_prior_operation_counts": retained_operations,
            "retained_provider_usage": retained_provider_usage,
            "retained_azure_fallback_attempts": histories.fallback_attempts,
            "retained_cloud_execution_attempts": (histories.standalone_cloud_attempts),
        }
    )


def _finalize_identity_sensitive_results(
    inputs: tuple[BatchDocumentInput, ...],
    results: tuple[BatchItemResult, ...],
) -> tuple[BatchItemResult, ...]:
    """Recheck source-bound results immediately before Manifest evidence."""
    finalized: list[BatchItemResult] = []
    for item, result in zip(inputs, results, strict=True):
        finalized_result = result
        if _has_final_source_identity(finalized_result):
            source_sha256 = cast("str", finalized_result.source_sha256)
            byte_size = cast("int", finalized_result.byte_size)
            if not _source_identity_matches(
                item,
                sha256=source_sha256,
                byte_size=byte_size,
            ):
                finalized_result = _final_source_changed_result(item, finalized_result)
        finalized.append(finalized_result)

    prior_by_id: dict[str, BatchItemResult] = {}
    consistent: list[BatchItemResult] = []
    for item, result in zip(inputs, finalized, strict=True):
        consistent_result = result
        if consistent_result.status is BatchItemStatus.DUPLICATE:
            target = prior_by_id.get(consistent_result.duplicate_of or "")
            target_operations = (
                frozenset()
                if target is None
                else {
                    count.name
                    for count in (
                        target.performed_operation_counts
                        + target.retained_prior_operation_counts
                    )
                }
            )
            if (
                target is None
                or target.status is BatchItemStatus.DUPLICATE
                or "inspection" not in target_operations
                or target.source_sha256 != consistent_result.source_sha256
                or target.byte_size != consistent_result.byte_size
            ):
                consistent_result = _final_source_changed_result(
                    item,
                    consistent_result,
                )
            elif (
                consistent_result.local_ocr_quality_summary
                != target.local_ocr_quality_summary
                or consistent_result.local_ocr_preprocessing_summary
                != target.local_ocr_preprocessing_summary
                or consistent_result.azure_fallback_summary
                != target.azure_fallback_summary
            ):
                consistent_result = BatchItemResult.model_validate(
                    consistent_result.model_dump(mode="json")
                    | {
                        "local_ocr_quality_summary": (
                            None
                            if target.local_ocr_quality_summary is None
                            else target.local_ocr_quality_summary.model_dump(
                                mode="json"
                            )
                        ),
                        "local_ocr_preprocessing_summary": (
                            None
                            if target.local_ocr_preprocessing_summary is None
                            else target.local_ocr_preprocessing_summary.model_dump(
                                mode="json"
                            )
                        ),
                        "azure_fallback_summary": (
                            None
                            if target.azure_fallback_summary is None
                            else target.azure_fallback_summary.model_dump(mode="json")
                        ),
                    }
                )
        consistent.append(consistent_result)
        prior_by_id[consistent_result.input_id] = consistent_result
    return tuple(consistent)


def process_batch(  # pyright: ignore[reportGeneralTypeIssues]
    inputs: Iterable[BatchDocumentInput],
    *,
    analysis_options: DocumentAnalysisOptions | None = None,
    extraction_schema: ExtractionSchema | None = None,
    ocr_provider: OcrProvider | None = None,
    azure_fallback_provider: object | None = None,
    batch_options: BatchProcessingOptions | None = None,
    limits: BatchProcessingLimits | None = None,
    resume_manifest: BatchProcessingManifest | None = None,
    workflow_request: DocumentWorkflowRequest | None = None,
    workflow_providers: DocumentWorkflowProviders | None = None,
    workflow_artifact_store: WorkflowArtifactStore | None = None,
) -> BatchProcessingResult:
    """Process inputs with identity-first resume and deduplication decisions."""
    workflow_mode = _workflow_batch_mode(
        request=workflow_request,
        providers=workflow_providers,
        artifact_store=workflow_artifact_store,
    )
    if workflow_mode is not None and any(
        value is not None
        for value in (
            analysis_options,
            extraction_schema,
            ocr_provider,
            azure_fallback_provider,
        )
    ):
        raise BatchConfigurationError(
            "Workflow Batch mode cannot combine with legacy analysis arguments"
        )
    local_ocr_provider: LocalOcrProvider | None = (
        None if workflow_mode is None else workflow_mode.local_provider
    )
    if workflow_mode is None and _is_exact_local_ocr_provider_instance(ocr_provider):
        local_ocr_provider = ocr_provider
    (
        items,
        effective_analysis,
        validated_schema,
        effective_batch,
        effective_limits,
    ) = _revalidate_batch_request(
        inputs,
        analysis_options=(
            analysis_options
            if workflow_mode is None
            else workflow_mode.request.analysis_options
        ),
        extraction_schema=extraction_schema,
        batch_options=batch_options,
        limits=limits,
    )
    validated_resume = _revalidate_resume_boundary(resume_manifest)
    if workflow_mode is None:
        try:
            _validate_quality_request_before_detection(
                options=effective_analysis,
                extraction_schema=validated_schema,
                ocr_provider=ocr_provider,
            )
        except LocalOcrQualityConfigurationError as exc:
            _raise_redacted_translation(
                exc,
                BatchConfigurationError("Local OCR quality configuration is invalid"),
            )
    if effective_analysis.azure_fallback_policy is not None and (
        azure_fallback_provider is None
        or not _is_actual_azure_provider(azure_fallback_provider)
    ):
        raise AzureFallbackConfigurationError(
            "Azure fallback requires an explicit built-in Azure Provider"
        )
    structured_options = effective_analysis.structured_extraction_options
    if (
        structured_options is not None
        and structured_options.local_ocr_quality_policy is not None
    ):
        if validated_schema is None:
            raise BatchConfigurationError(
                "Structured Local OCR quality policy requires an extraction schema"
            )
        _validate_local_quality_provider(structured_options, ocr_provider)
    if (
        ocr_provider is not None
        and local_ocr_provider is None
        and effective_limits.max_workers > 1
    ):
        raise BatchConfigurationError(
            "Provider-backed batch processing requires max_workers=1"
        )
    if workflow_mode is None:
        ocr_profile_id, ocr_resume_fingerprint = _provider_processing_identity(
            ocr_provider
        )
        provider_profile_id = ocr_profile_id
        provider_resume_fingerprint = ocr_resume_fingerprint
        cloud_policy = _cloud_execution_policy(
            ocr_provider
            if _is_actual_azure_provider(ocr_provider)
            else azure_fallback_provider
        )
        manifest_schema = validated_schema
    else:
        provider_profile_id = None
        provider_resume_fingerprint = workflow_mode.identity
        cloud_policy = None
        manifest_schema = workflow_mode.request.extraction_schema
    options_fingerprint, schema_fingerprint = _fingerprints(
        analysis_options=effective_analysis,
        batch_options=effective_batch,
        limits=effective_limits,
        schema=manifest_schema,
        provider_profile_id=provider_profile_id,
        provider_resume_fingerprint=provider_resume_fingerprint,
        workflow_identity=(None if workflow_mode is None else workflow_mode.identity),
        preprocessing_enabled=(
            local_ocr_provider is not None
            and local_ocr_provider.preprocessing_policy.enabled
        ),
    )
    prior_items = _validate_resume(
        validated_resume,
        options_fingerprint=options_fingerprint,
        schema=manifest_schema,
        schema_fingerprint=schema_fingerprint,
        provider_profile_id=provider_profile_id,
    )
    cloud_budget = _CloudExecutionBudgetState.from_manifest_items(prior_items.values())
    results: list[BatchItemResult | None] = [None] * len(items)
    pending: list[_PendingItem] = []
    canonical_hashes: dict[str, tuple[str, _FamilyEvidence]] = {}
    total_bytes = total_pages = total_sheets = total_frames = total_docx_blocks = 0
    local_usage = ProviderUsageTotals()
    fallback_pages = fallback_frames = fallback_invocations = fallback_azure = 0
    fallback_paid = 0
    fallback_payload_bytes = 0
    for prior_evidence in prior_items.values():
        if prior_evidence.status is BatchItemStatus.DUPLICATE:
            continue
        summary = prior_evidence.azure_fallback_summary
        if summary is not None:
            fallback_pages += len(summary.submitted_pages)
            fallback_frames += len(summary.submitted_frames)
            fallback_invocations += summary.provider_invocation_count
            fallback_azure += summary.azure_operation_count
            fallback_paid += summary.paid_page_count + summary.paid_frame_count
            fallback_payload_bytes += summary.payload_byte_count
        attempts = prior_evidence.retained_azure_fallback_attempts + (
            ()
            if prior_evidence.azure_fallback_attempt is None
            else (prior_evidence.azure_fallback_attempt,)
        )
        for attempt in attempts:
            pages, frames, invocations, azure, paid, payload = _attempt_budget_values(
                attempt
            )
            fallback_pages += pages
            fallback_frames += frames
            fallback_invocations += invocations
            fallback_azure += azure
            fallback_paid += paid
            fallback_payload_bytes += payload
    preflight_failures = 0
    stop = False
    for index, item in enumerate(items):
        prior = prior_items.get(item.input_id)
        prior_current_usage = (
            () if prior is None else _current_provider_usage_history(prior)
        )
        prior_usage_history = (
            () if prior is None else prior.retained_provider_usage + prior_current_usage
        )
        histories = _retained_cloud_histories(prior)
        prior_fallback_attempts = histories.fallback_attempts
        prior_cloud_attempts = histories.standalone_cloud_attempts
        if local_ocr_provider is not None:
            local_usage = _add_local_usages(local_usage, prior_usage_history)
        if stop or index >= effective_limits.max_files:
            results[index] = _cancelled(
                item,
                retained_provider_usage=prior_usage_history,
                retained_azure_fallback_attempts=prior_fallback_attempts,
                retained_cloud_execution_attempts=prior_cloud_attempts,
            )
            continue
        if not _is_regular_batch_source(item.source):
            results[index] = _failed(
                item,
                category=("source_changed" if prior is not None else "processing"),
                retained_provider_usage=prior_usage_history,
                retained_azure_fallback_attempts=prior_fallback_attempts,
                retained_cloud_execution_attempts=prior_cloud_attempts,
            )
            preflight_failures += 1
            stop = preflight_failures >= effective_limits.max_failures
            continue
        try:
            byte_size = item.source.lstat().st_size
        except OSError:
            results[index] = _failed(
                item,
                category=("source_changed" if prior is not None else "processing"),
                retained_provider_usage=prior_usage_history,
                retained_azure_fallback_attempts=prior_fallback_attempts,
                retained_cloud_execution_attempts=prior_cloud_attempts,
            )
            preflight_failures += 1
            stop = preflight_failures >= effective_limits.max_failures
            continue
        if (
            prior is not None
            and (prior_fallback_attempts or prior_cloud_attempts)
            and prior.byte_size is not None
            and byte_size != prior.byte_size
        ):
            total_bytes += byte_size
            results[index] = _failed(
                item,
                category="source_changed",
                byte_size=byte_size,
                consumed_input_bytes=byte_size,
                retained_provider_usage=prior_usage_history,
                retained_azure_fallback_attempts=prior_fallback_attempts,
                retained_cloud_execution_attempts=prior_cloud_attempts,
            )
            preflight_failures += 1
            stop = preflight_failures >= effective_limits.max_failures
            continue
        remaining_bytes = effective_limits.max_total_input_bytes - total_bytes
        if byte_size > remaining_bytes:
            total_bytes += byte_size
            stop = True
            results[index] = _cancelled(
                item,
                byte_size=byte_size,
                consumed_input_bytes=byte_size,
                retained_provider_usage=prior_usage_history,
                retained_azure_fallback_attempts=prior_fallback_attempts,
                retained_cloud_execution_attempts=prior_cloud_attempts,
            )
            continue
        total_bytes += byte_size
        item_consumed_bytes = byte_size
        if byte_size > effective_limits.max_file_bytes:
            results[index] = _failed(
                item,
                category="limit",
                byte_size=byte_size,
                consumed_input_bytes=item_consumed_bytes,
                retained_provider_usage=prior_usage_history,
                retained_azure_fallback_attempts=prior_fallback_attempts,
                retained_cloud_execution_attempts=prior_cloud_attempts,
            )
            preflight_failures += 1
            stop = preflight_failures >= effective_limits.max_failures
            continue
        identity_limit = min(
            effective_limits.max_file_bytes,
            byte_size + effective_limits.max_total_input_bytes - total_bytes,
        )
        detection: object | None = None
        safe_preplan_identity: tuple[str, int] | None = None
        try:
            detection = document_processing._detect_identity(
                item.source,
                max_bytes=identity_limit,
                ooxml_limits=document_processing._ooxml_classification_limits(
                    effective_limits.docx_limits
                ),
            )
            envelope = detection.envelope
            safe_preplan_identity = (envelope.sha256, envelope.byte_size)
            if envelope.byte_size != byte_size:
                raise DocumentSourceChangedError(  # noqa: TRY301
                    "The batch source changed during identity detection"
                )
            if (
                prior is not None
                and (prior_fallback_attempts or prior_cloud_attempts)
                and prior.source_sha256 != envelope.sha256
            ):
                raise DocumentSourceChangedError(  # noqa: TRY301
                    "The resumed fallback source changed"
                )
            if workflow_mode is None:
                _validate_request(
                    envelope.document_type,
                    options=_batch_family_analysis_options(
                        envelope.document_type,
                        effective_analysis,
                    ),
                    extraction_schema=validated_schema,
                    ocr_provider=ocr_provider,
                )
            if (
                prior is not None
                and prior.status
                in {
                    BatchItemStatus.FAILED,
                    BatchItemStatus.CANCELLED_BY_LIMIT,
                }
                and _has_protected_remote_attempt(
                    prior_cloud_attempts,
                    prior_fallback_attempts,
                )
                and (cloud_policy is None or not cloud_policy.allow_retry_possibly_paid)
            ):
                results[index] = _failed(
                    item,
                    prior=prior,
                    detection=detection,
                    category="cloud_retry_denied",
                    consumed_input_bytes=item_consumed_bytes,
                    retained_provider_usage=prior_usage_history,
                    retained_azure_fallback_attempts=prior_fallback_attempts,
                    retained_cloud_execution_attempts=prior_cloud_attempts,
                )
                preflight_failures += 1
                stop = preflight_failures >= effective_limits.max_failures
                continue
            retry_prior_local_limit_cancellation = bool(
                workflow_mode is not None
                and workflow_mode.local_provider is not None
                and prior is not None
                and prior.status is BatchItemStatus.CANCELLED_BY_LIMIT
                and prior.relative_name == item.relative_name
                and prior.source_sha256 == envelope.sha256
                and prior.byte_size == envelope.byte_size
                and prior.document_type is envelope.document_type
                and prior.document_format is envelope.document_format
                and not prior_fallback_attempts
                and not prior_cloud_attempts
                and _is_local_only_usage_history(prior_usage_history)
            )
            if (
                prior is not None
                and prior.status
                in {
                    BatchItemStatus.SUCCEEDED,
                    BatchItemStatus.SKIPPED_PREVIOUS_SUCCESS,
                }
                and prior.resume_eligible_success
                and prior.relative_name == item.relative_name
                and prior.source_sha256 == envelope.sha256
                and prior.byte_size == envelope.byte_size
                and prior.document_type is envelope.document_type
                and prior.document_format is envelope.document_format
                and (
                    workflow_mode is None
                    or prior.intake_status
                    in {
                        DocumentWorkflowIntakeStatus.SUCCEEDED,
                        DocumentWorkflowIntakeStatus.PARTIAL,
                        DocumentWorkflowIntakeStatus.REVIEW_REQUIRED,
                    }
                )
            ):
                next_pages = total_pages + (prior.pdf_page_count or 0)
                next_sheets = total_sheets + (prior.excel_worksheet_count or 0)
                next_frames = total_frames + (prior.image_frame_count or 0)
                next_docx_blocks = total_docx_blocks + (prior.docx_block_count or 0)
                if (
                    next_pages > effective_limits.max_total_pdf_pages
                    or next_sheets > effective_limits.max_total_excel_sheets
                    or next_frames > effective_limits.max_total_image_frames
                    or next_docx_blocks > effective_limits.max_total_docx_blocks
                ):
                    stop = True
                    results[index] = _cancelled(
                        item,
                        prior=prior,
                        retained_provider_usage=prior_usage_history,
                        retained_azure_fallback_attempts=prior_fallback_attempts,
                        retained_cloud_execution_attempts=prior_cloud_attempts,
                    )
                    continue
                if not _source_identity_matches(
                    item,
                    sha256=envelope.sha256,
                    byte_size=envelope.byte_size,
                ):
                    results[index] = _failed(
                        item,
                        category="source_changed",
                        consumed_input_bytes=item_consumed_bytes,
                        retained_provider_usage=prior_usage_history,
                        retained_azure_fallback_attempts=prior_fallback_attempts,
                        retained_cloud_execution_attempts=prior_cloud_attempts,
                    )
                    preflight_failures += 1
                    stop = preflight_failures >= effective_limits.max_failures
                    continue
                total_pages, total_sheets, total_frames, total_docx_blocks = (
                    next_pages,
                    next_sheets,
                    next_frames,
                    next_docx_blocks,
                )
                if workflow_mode is not None:
                    results[index] = BatchItemResult(
                        input_id=item.input_id,
                        relative_name=item.relative_name,
                        status=BatchItemStatus.SKIPPED_PREVIOUS_SUCCESS,
                        intake_status=prior.intake_status,
                        source_sha256=envelope.sha256,
                        byte_size=envelope.byte_size,
                        consumed_input_bytes=envelope.byte_size,
                        result_fingerprint=prior.result_fingerprint,
                        resume_eligible_success=True,
                        issues=prior.issues,
                        performed_operation_counts=_completed_operations("detection"),
                        retained_prior_operation_counts=(
                            prior.retained_prior_operation_counts
                            or prior.performed_operation_counts
                        ),
                        retained_provider_usage=prior_usage_history,
                        retained_cloud_execution_attempts=prior_cloud_attempts,
                        local_ocr_quality_summary=prior.local_ocr_quality_summary,
                        local_ocr_preprocessing_summary=(
                            prior.local_ocr_preprocessing_summary
                        ),
                        **_prior_family_evidence(prior),
                    )
                else:
                    results[index] = BatchItemResult(
                        input_id=item.input_id,
                        relative_name=item.relative_name,
                        status=BatchItemStatus.SKIPPED_PREVIOUS_SUCCESS,
                        source_sha256=envelope.sha256,
                        byte_size=envelope.byte_size,
                        consumed_input_bytes=envelope.byte_size,
                        result_fingerprint=prior.result_fingerprint,
                        resume_eligible_success=True,
                        performed_operation_counts=_completed_operations("detection"),
                        retained_prior_operation_counts=(
                            prior.retained_prior_operation_counts
                            or prior.performed_operation_counts
                        ),
                        provider_usage=prior.provider_usage,
                        retained_provider_usage=prior.retained_provider_usage,
                        provider_usage_breakdown=prior.provider_usage_breakdown,
                        local_ocr_quality_summary=prior.local_ocr_quality_summary,
                        local_ocr_preprocessing_summary=(
                            prior.local_ocr_preprocessing_summary
                        ),
                        azure_fallback_summary=prior.azure_fallback_summary,
                        retained_azure_fallback_attempts=(
                            prior.retained_azure_fallback_attempts
                        ),
                        retained_cloud_execution_attempts=(
                            prior.retained_cloud_execution_attempts
                            + prior.cloud_execution_attempts
                        ),
                        **_prior_family_evidence(prior),
                    )
                canonical_hashes.setdefault(
                    envelope.sha256,
                    (item.input_id, _prior_family_evidence(prior)),
                )
                continue
            canonical = canonical_hashes.get(envelope.sha256)
            if (
                effective_batch.deduplicate_sha256
                and canonical is not None
                and not prior_fallback_attempts
                and not prior_cloud_attempts
            ):
                duplicate_of, canonical_evidence = canonical
                if not _source_identity_matches(
                    item,
                    sha256=envelope.sha256,
                    byte_size=envelope.byte_size,
                ):
                    results[index] = _failed(
                        item,
                        category="source_changed",
                        consumed_input_bytes=item_consumed_bytes,
                        retained_provider_usage=prior_usage_history,
                        retained_azure_fallback_attempts=prior_fallback_attempts,
                        retained_cloud_execution_attempts=prior_cloud_attempts,
                    )
                    preflight_failures += 1
                    stop = preflight_failures >= effective_limits.max_failures
                    continue
                results[index] = BatchItemResult(
                    input_id=item.input_id,
                    relative_name=item.relative_name,
                    status=BatchItemStatus.DUPLICATE,
                    duplicate_of=duplicate_of,
                    source_sha256=envelope.sha256,
                    byte_size=envelope.byte_size,
                    consumed_input_bytes=envelope.byte_size,
                    performed_operation_counts=_completed_operations("detection"),
                    **canonical_evidence,
                )
                continue
            if not _is_regular_batch_source(item.source):
                raise BatchConfigurationError(  # noqa: TRY301
                    "The batch source is no longer a regular non-symlink file"
                )
            docx_analysis = None
            local_ocr_source = None
            if envelope.document_type is DocumentType.WORD:
                inspection, docx_analysis = document_processing._analyze_docx_detected(
                    item.source,
                    detection,
                    options=effective_analysis.docx_options,
                    limits=effective_limits.docx_limits,
                )
            elif local_ocr_provider is not None and envelope.document_type in {
                DocumentType.PDF,
                DocumentType.IMAGE,
            }:
                local_ocr_source = local_ocr_provider._prepare_source(
                    item.source,
                    detection,
                    limits=None,
                )
                inspection = document_processing._local_ocr_inspection_result(
                    local_ocr_source
                )
            else:
                inspection = document_processing._inspect_detected(
                    item.source,
                    detection,
                    limits=None,
                )
            prepared = _PreparedDocument(
                source=item.source,
                detection=detection,
                inspection=inspection,
                docx_analysis=docx_analysis,
                local_ocr_source=local_ocr_source,
            )
            next_pages = total_pages + (prepared.inspection.pdf_page_count or 0)
            next_sheets = total_sheets + (
                prepared.inspection.excel_worksheet_count or 0
            )
            next_frames = total_frames + (prepared.inspection.image_frame_count or 0)
            next_docx_blocks = total_docx_blocks + (
                prepared.inspection.docx_block_count or 0
            )
            if (
                next_pages > effective_limits.max_total_pdf_pages
                or next_sheets > effective_limits.max_total_excel_sheets
                or next_frames > effective_limits.max_total_image_frames
                or next_docx_blocks > effective_limits.max_total_docx_blocks
            ):
                stop = True
                results[index] = _cancelled(
                    item,
                    prepared=prepared,
                    retained_provider_usage=prior_usage_history,
                    retained_azure_fallback_attempts=prior_fallback_attempts,
                    retained_cloud_execution_attempts=prior_cloud_attempts,
                )
                continue
            total_pages, total_sheets, total_frames, total_docx_blocks = (
                next_pages,
                next_sheets,
                next_frames,
                next_docx_blocks,
            )
            canonical_hashes[envelope.sha256] = (
                item.input_id,
                _family_evidence(prepared),
            )
            pending.append(
                _PendingItem(
                    index,
                    item,
                    prepared,
                    retained_provider_usage=prior_usage_history,
                    retained_azure_fallback_attempts=prior_fallback_attempts,
                    retained_cloud_execution_attempts=prior_cloud_attempts,
                    retry_prior_local_limit_cancellation=(
                        retry_prior_local_limit_cancellation
                    ),
                )
            )
        except _UnsupportedDocumentIdentityError as exc:
            if exc.byte_size > item_consumed_bytes:
                total_bytes += exc.byte_size - item_consumed_bytes
                item_consumed_bytes = exc.byte_size
            if prior is not None and (prior_fallback_attempts or prior_cloud_attempts):
                results[index] = _failed(
                    item,
                    category="source_changed",
                    byte_size=exc.byte_size,
                    consumed_input_bytes=item_consumed_bytes,
                    retained_provider_usage=prior_usage_history,
                    retained_azure_fallback_attempts=prior_fallback_attempts,
                    retained_cloud_execution_attempts=prior_cloud_attempts,
                )
                preflight_failures += 1
                stop = preflight_failures >= effective_limits.max_failures
            elif workflow_mode is not None:
                preplan_result = _workflow_preplan_batch_item(
                    item,
                    mode=workflow_mode,
                    error=exc,
                    measured_byte_size=exc.byte_size,
                    expected_identity=(exc.sha256, exc.byte_size),
                )
                results[index] = preplan_result
                if preplan_result.status is BatchItemStatus.FAILED:
                    preflight_failures += 1
                    stop = preflight_failures >= effective_limits.max_failures
            else:
                results[index] = BatchItemResult(
                    input_id=item.input_id,
                    relative_name=item.relative_name,
                    status=BatchItemStatus.SKIPPED_UNSUPPORTED,
                    byte_size=exc.byte_size,
                    consumed_input_bytes=item_consumed_bytes,
                    issues=(
                        _safe_issue(
                            "batch.unsupported",
                            "unsupported",
                            "The item is not a supported document type.",
                        ),
                    ),
                    retained_provider_usage=prior_usage_history,
                    retained_azure_fallback_attempts=prior_fallback_attempts,
                    retained_cloud_execution_attempts=prior_cloud_attempts,
                )
        except DocxResourceLimitError as exc:
            if workflow_mode is not None and not (
                prior_fallback_attempts or prior_cloud_attempts
            ):
                results[index] = _workflow_preplan_batch_item(
                    item,
                    mode=workflow_mode,
                    error=exc,
                    measured_byte_size=item_consumed_bytes,
                    expected_identity=safe_preplan_identity,
                )
            else:
                results[index] = _failed(
                    item,
                    category="limit",
                    consumed_input_bytes=item_consumed_bytes,
                    retained_provider_usage=prior_usage_history,
                    retained_azure_fallback_attempts=prior_fallback_attempts,
                    retained_cloud_execution_attempts=prior_cloud_attempts,
                )
            preflight_failures += 1
            stop = preflight_failures >= effective_limits.max_failures
        except UnsupportedDocumentTypeError as exc:
            if (
                detection is None
                and prior is not None
                and (prior_fallback_attempts or prior_cloud_attempts)
            ):
                results[index] = _failed(
                    item,
                    category="source_changed",
                    byte_size=byte_size,
                    consumed_input_bytes=item_consumed_bytes,
                    retained_provider_usage=prior_usage_history,
                    retained_azure_fallback_attempts=prior_fallback_attempts,
                    retained_cloud_execution_attempts=prior_cloud_attempts,
                )
                preflight_failures += 1
                stop = preflight_failures >= effective_limits.max_failures
            elif workflow_mode is not None:
                preplan_result = _workflow_preplan_batch_item(
                    item,
                    mode=workflow_mode,
                    error=exc,
                    measured_byte_size=byte_size,
                    expected_identity=safe_preplan_identity,
                )
                results[index] = preplan_result
                if preplan_result.status is BatchItemStatus.FAILED:
                    preflight_failures += 1
                    stop = preflight_failures >= effective_limits.max_failures
            elif detection is None:
                results[index] = BatchItemResult(
                    input_id=item.input_id,
                    relative_name=item.relative_name,
                    status=BatchItemStatus.SKIPPED_UNSUPPORTED,
                    byte_size=byte_size,
                    consumed_input_bytes=item_consumed_bytes,
                    issues=(
                        _safe_issue(
                            "batch.unsupported",
                            "unsupported",
                            "The item is not a supported document type.",
                        ),
                    ),
                    retained_provider_usage=prior_usage_history,
                    retained_azure_fallback_attempts=prior_fallback_attempts,
                    retained_cloud_execution_attempts=prior_cloud_attempts,
                )
            else:
                results[index] = _failed(
                    item,
                    detection=detection,
                    consumed_input_bytes=item_consumed_bytes,
                    retained_provider_usage=prior_usage_history,
                    retained_azure_fallback_attempts=prior_fallback_attempts,
                    retained_cloud_execution_attempts=prior_cloud_attempts,
                )
                preflight_failures += 1
                stop = preflight_failures >= effective_limits.max_failures
        except _DocumentIdentityLimitError as exc:
            if exc.byte_size > item_consumed_bytes:
                total_bytes += exc.byte_size - item_consumed_bytes
                item_consumed_bytes = exc.byte_size
            if prior is not None and (prior_fallback_attempts or prior_cloud_attempts):
                results[index] = _failed(
                    item,
                    category="source_changed",
                    byte_size=exc.byte_size,
                    consumed_input_bytes=item_consumed_bytes,
                    retained_provider_usage=prior_usage_history,
                    retained_azure_fallback_attempts=prior_fallback_attempts,
                    retained_cloud_execution_attempts=prior_cloud_attempts,
                )
                preflight_failures += 1
                stop = preflight_failures >= effective_limits.max_failures
            elif total_bytes > effective_limits.max_total_input_bytes:
                results[index] = _cancelled(
                    item,
                    consumed_input_bytes=item_consumed_bytes,
                    retained_provider_usage=prior_usage_history,
                    retained_azure_fallback_attempts=prior_fallback_attempts,
                    retained_cloud_execution_attempts=prior_cloud_attempts,
                )
                stop = True
            elif workflow_mode is not None:
                preplan_result = _workflow_preplan_batch_item(
                    item,
                    mode=workflow_mode,
                    error=exc,
                    measured_byte_size=exc.byte_size,
                    expected_identity=None,
                )
                results[index] = preplan_result
                if preplan_result.status is BatchItemStatus.FAILED:
                    preflight_failures += 1
                    stop = preflight_failures >= effective_limits.max_failures
            else:
                results[index] = _failed(
                    item,
                    category="limit",
                    consumed_input_bytes=item_consumed_bytes,
                    retained_provider_usage=prior_usage_history,
                    retained_azure_fallback_attempts=prior_fallback_attempts,
                    retained_cloud_execution_attempts=prior_cloud_attempts,
                )
                preflight_failures += 1
                stop = preflight_failures >= effective_limits.max_failures
        except DocumentSourceChangedError as exc:
            fallback_attempt = _fallback_attempt_evidence(exc)
            confirmed = _attempt_confirmed_usages(fallback_attempt)
            direct_usages, direct_attempts = _direct_cloud_failure_evidence(exc)
            pages, frames, invocations, azure, paid, payload = _attempt_budget_values(
                fallback_attempt
            )
            fallback_pages += pages
            fallback_frames += frames
            fallback_invocations += invocations
            fallback_azure += azure
            fallback_paid += paid
            fallback_payload_bytes += payload
            results[index] = _failed(
                item,
                category="source_changed",
                consumed_input_bytes=item_consumed_bytes,
                retained_provider_usage=(
                    prior_usage_history + confirmed + direct_usages
                ),
                retained_azure_fallback_attempts=prior_fallback_attempts,
                retained_cloud_execution_attempts=prior_cloud_attempts,
                cloud_execution_attempts=direct_attempts,
                azure_fallback_attempt=fallback_attempt,
            )
            preflight_failures += 1
            stop = preflight_failures >= effective_limits.max_failures
        except DocumentProcessingError as exc:
            if workflow_mode is not None and not (
                prior_fallback_attempts or prior_cloud_attempts
            ):
                preplan_result = _workflow_preplan_batch_item(
                    item,
                    mode=workflow_mode,
                    error=exc,
                    measured_byte_size=item_consumed_bytes,
                    expected_identity=safe_preplan_identity,
                )
                results[index] = preplan_result
                if preplan_result.status is BatchItemStatus.FAILED:
                    preflight_failures += 1
                    stop = preflight_failures >= effective_limits.max_failures
            else:
                results[index] = _failed(
                    item,
                    detection=detection,
                    consumed_input_bytes=item_consumed_bytes,
                    retained_provider_usage=prior_usage_history,
                    retained_azure_fallback_attempts=prior_fallback_attempts,
                    retained_cloud_execution_attempts=prior_cloud_attempts,
                )
                preflight_failures += 1
                stop = preflight_failures >= effective_limits.max_failures
        except Exception as exc:
            direct_usages, direct_attempts = _direct_cloud_failure_evidence(exc)
            results[index] = _failed(
                item,
                detection=detection,
                consumed_input_bytes=item_consumed_bytes,
                retained_provider_usage=prior_usage_history + direct_usages,
                retained_azure_fallback_attempts=prior_fallback_attempts,
                retained_cloud_execution_attempts=prior_cloud_attempts,
                cloud_execution_attempts=direct_attempts,
            )
            preflight_failures += 1
            stop = preflight_failures >= effective_limits.max_failures

    if workflow_mode is not None:
        _run_workflow_pending_items(
            pending,
            results,
            mode=workflow_mode,
            limits=effective_limits,
            initial_failures=preflight_failures,
            retained_paid_operations=(cloud_budget.paid_or_possibly_paid_operations),
            initial_local_usage=local_usage,
        )
        pending.clear()

    failures = preflight_failures
    executor_workers = (
        1
        if (
            effective_analysis.azure_fallback_policy is not None
            or (ocr_provider is not None and local_ocr_provider is None)
        )
        else effective_limits.max_workers
    )
    with ThreadPoolExecutor(max_workers=executor_workers) as executor:
        start = 0
        local_budget_reached = False
        while start < len(pending):
            if failures >= effective_limits.max_failures:
                for entry in pending[start:]:
                    results[entry.index] = _cancelled(
                        entry.item,
                        prepared=entry.prepared,
                        retained_provider_usage=entry.retained_provider_usage,
                        retained_azure_fallback_attempts=(
                            entry.retained_azure_fallback_attempts
                        ),
                        retained_cloud_execution_attempts=(
                            entry.retained_cloud_execution_attempts
                        ),
                    )
                break
            if local_ocr_provider is not None and (
                local_budget_reached
                or _local_usage_at_limit(
                    local_usage,
                    effective_limits,
                )
            ):
                for entry in pending[start:]:
                    if _pending_requires_local_ocr(
                        entry,
                        options=effective_analysis,
                        schema=validated_schema,
                    ):
                        results[entry.index] = _cancelled(
                            entry.item,
                            prepared=entry.prepared,
                            retained_provider_usage=entry.retained_provider_usage,
                            retained_azure_fallback_attempts=(
                                entry.retained_azure_fallback_attempts
                            ),
                            retained_cloud_execution_attempts=(
                                entry.retained_cloud_execution_attempts
                            ),
                        )
                        continue
                    zero_budget_invocation = _LocalOcrInvocationState(
                        usage_budget=_LocalOcrUsageBudget(
                            operations=0,
                            regions=0,
                            pixels=0,
                            characters=0,
                        )
                    )
                    try:
                        item_analysis = _fallback_budgeted_options(
                            effective_analysis,
                            used_pages=fallback_pages,
                            used_frames=fallback_frames,
                            used_invocations=fallback_invocations,
                            used_azure_operations=fallback_azure,
                            used_paid_operations=fallback_paid,
                            used_payload_bytes=fallback_payload_bytes,
                            limits=effective_limits,
                            cloud_policy=cloud_policy,
                            cloud_budget=cloud_budget,
                            cloud_retry_credit=_pending_cloud_retry_credit(
                                entry,
                                policy=cloud_policy,
                            ),
                        )
                        analyzed = _analyze_pending(
                            entry,
                            options=item_analysis,
                            schema=validated_schema,
                            provider=local_ocr_provider,
                            azure_fallback_provider=azure_fallback_provider,
                            local_invocation_state=zero_budget_invocation,
                        )
                        results[entry.index] = analyzed
                        local_usage = _add_local_usage(
                            local_usage,
                            analyzed.provider_usage,
                        )
                        fallback_summary = analyzed.azure_fallback_summary
                        if fallback_summary is not None:
                            fallback_pages += fallback_summary.paid_page_count
                            fallback_frames += fallback_summary.paid_frame_count
                            fallback_invocations += (
                                fallback_summary.provider_invocation_count
                            )
                            fallback_azure += fallback_summary.azure_operation_count
                            fallback_paid += (
                                fallback_summary.paid_page_count
                                + fallback_summary.paid_frame_count
                            )
                            fallback_payload_bytes += (
                                fallback_summary.payload_byte_count
                            )
                    except DocumentSourceChangedError as exc:
                        usage = _failed_local_usage(exc, zero_budget_invocation)
                        fallback_attempt = _fallback_attempt_evidence(exc)
                        confirmed = _attempt_confirmed_usages(fallback_attempt)
                        direct_usages, direct_attempts = _direct_cloud_failure_evidence(
                            exc
                        )
                        pages, frames, invocations, azure, paid, payload = (
                            _attempt_budget_values(fallback_attempt)
                        )
                        fallback_pages += pages
                        fallback_frames += frames
                        fallback_invocations += invocations
                        fallback_azure += azure
                        fallback_paid += paid
                        fallback_payload_bytes += payload
                        local_usage = _add_local_usage(local_usage, usage)
                        local_usage = _add_local_usages(local_usage, confirmed)
                        failures += 1
                        results[entry.index] = _failed(
                            entry.item,
                            prepared=entry.prepared,
                            category="source_changed",
                            provider_usage=usage,
                            retained_provider_usage=(
                                entry.retained_provider_usage
                                + confirmed
                                + direct_usages
                            ),
                            retained_azure_fallback_attempts=(
                                entry.retained_azure_fallback_attempts
                            ),
                            retained_cloud_execution_attempts=(
                                entry.retained_cloud_execution_attempts
                            ),
                            cloud_execution_attempts=direct_attempts,
                            azure_fallback_attempt=fallback_attempt,
                        )
                    except LocalOcrLimitExceededError as exc:
                        usage = _failed_local_usage(exc, zero_budget_invocation)
                        local_usage = _add_local_usage(local_usage, usage)
                        failures += 1
                        results[entry.index] = _failed(
                            entry.item,
                            prepared=entry.prepared,
                            category="limit",
                            provider_usage=usage,
                            retained_provider_usage=entry.retained_provider_usage,
                            retained_azure_fallback_attempts=(
                                entry.retained_azure_fallback_attempts
                            ),
                            retained_cloud_execution_attempts=(
                                entry.retained_cloud_execution_attempts
                            ),
                        )
                    except AzureFallbackLimitError as exc:
                        usage = _failed_local_usage(exc, zero_budget_invocation)
                        local_usage = _add_local_usage(local_usage, usage)
                        fallback_attempt = _fallback_attempt_evidence(exc)
                        confirmed = _attempt_confirmed_usages(fallback_attempt)
                        pages, frames, invocations, azure, paid, payload = (
                            _attempt_budget_values(fallback_attempt)
                        )
                        fallback_pages += pages
                        fallback_frames += frames
                        fallback_invocations += invocations
                        fallback_azure += azure
                        fallback_paid += paid
                        fallback_payload_bytes += payload
                        failures += 1
                        results[entry.index] = _failed(
                            entry.item,
                            prepared=entry.prepared,
                            category="limit",
                            provider_usage=usage,
                            retained_provider_usage=(
                                entry.retained_provider_usage + confirmed
                            ),
                            retained_azure_fallback_attempts=(
                                entry.retained_azure_fallback_attempts
                            ),
                            retained_cloud_execution_attempts=(
                                entry.retained_cloud_execution_attempts
                            ),
                            azure_fallback_attempt=fallback_attempt,
                        )
                    except Exception as exc:
                        usage = _failed_local_usage(exc, zero_budget_invocation)
                        fallback_attempt = _fallback_attempt_evidence(exc)
                        confirmed = _attempt_confirmed_usages(fallback_attempt)
                        pages, frames, invocations, azure, paid, payload = (
                            _attempt_budget_values(fallback_attempt)
                        )
                        fallback_pages += pages
                        fallback_frames += frames
                        fallback_invocations += invocations
                        fallback_azure += azure
                        fallback_paid += paid
                        fallback_payload_bytes += payload
                        local_usage = _add_local_usage(local_usage, usage)
                        local_usage = _add_local_usages(local_usage, confirmed)
                        failures += 1
                        direct_usages, direct_attempts = _direct_cloud_failure_evidence(
                            exc
                        )
                        results[entry.index] = _failed(
                            entry.item,
                            prepared=entry.prepared,
                            provider_usage=usage,
                            retained_provider_usage=entry.retained_provider_usage
                            + confirmed
                            + direct_usages,
                            retained_azure_fallback_attempts=(
                                entry.retained_azure_fallback_attempts
                            ),
                            retained_cloud_execution_attempts=(
                                entry.retained_cloud_execution_attempts
                            ),
                            cloud_execution_attempts=direct_attempts,
                            azure_fallback_attempt=fallback_attempt,
                        )
                    current_result = results[entry.index]
                    if current_result is not None:
                        cloud_budget.record(
                            entry.item.input_id,
                            _current_result_cloud_attempts(current_result),
                        )
                break
            if (
                cloud_policy is not None
                and cloud_policy.allow_cloud_execution
                and type(ocr_provider) is AzureDocumentIntelligenceProvider
            ):
                entry = pending[start]
                retry_credit = _pending_cloud_retry_credit(
                    entry,
                    policy=cloud_policy,
                )
                permitted = cloud_budget.permits_direct_submit(
                    cloud_policy,
                    page_or_frame_count=_pending_direct_cloud_input_count(entry),
                    input_bytes=entry.prepared.detection.envelope.byte_size,
                    retry_credit=retry_credit,
                )
                if not permitted:
                    results[entry.index] = _failed(
                        entry.item,
                        prepared=entry.prepared,
                        category="cloud_limit",
                        retained_provider_usage=entry.retained_provider_usage,
                        retained_azure_fallback_attempts=(
                            entry.retained_azure_fallback_attempts
                        ),
                        retained_cloud_execution_attempts=(
                            entry.retained_cloud_execution_attempts
                        ),
                    )
                    failures += 1
                    start += 1
                    continue
            window_size = (
                1
                if effective_analysis.azure_fallback_policy is not None
                else _local_window_size(
                    local_ocr_provider,
                    totals=local_usage,
                    limits=effective_limits,
                )
                if local_ocr_provider is not None
                else executor_workers
            )
            window = pending[start : start + window_size]
            window_invocations = (
                _local_window_invocations(
                    local_ocr_provider,
                    count=len(window),
                    totals=local_usage,
                    limits=effective_limits,
                )
                if local_ocr_provider is not None
                else (None,) * len(window)
            )
            item_analysis = _fallback_budgeted_options(
                effective_analysis,
                used_pages=fallback_pages,
                used_frames=fallback_frames,
                used_invocations=fallback_invocations,
                used_azure_operations=fallback_azure,
                used_paid_operations=fallback_paid,
                used_payload_bytes=fallback_payload_bytes,
                limits=effective_limits,
                cloud_policy=cloud_policy,
                cloud_budget=cloud_budget,
                cloud_retry_credit=(
                    0
                    if not window
                    else _pending_cloud_retry_credit(
                        window[0],
                        policy=cloud_policy,
                    )
                ),
            )
            futures: list[Future[BatchItemResult]] = [
                executor.submit(
                    _analyze_pending,
                    entry,
                    options=item_analysis,
                    schema=validated_schema,
                    provider=ocr_provider,
                    azure_fallback_provider=azure_fallback_provider,
                    local_invocation_state=window_invocation,
                )
                for entry, window_invocation in zip(
                    window,
                    window_invocations,
                    strict=True,
                )
            ]
            for entry, future, window_invocation in zip(
                window,
                futures,
                window_invocations,
                strict=True,
            ):
                try:
                    analyzed = future.result()
                    results[entry.index] = analyzed
                    if local_ocr_provider is not None:
                        local_usage = _add_local_usage(
                            local_usage,
                            analyzed.provider_usage,
                        )
                    fallback_summary = analyzed.azure_fallback_summary
                    if fallback_summary is not None:
                        fallback_pages += fallback_summary.paid_page_count
                        fallback_frames += fallback_summary.paid_frame_count
                        fallback_invocations += (
                            fallback_summary.provider_invocation_count
                        )
                        fallback_azure += fallback_summary.azure_operation_count
                        fallback_paid += (
                            fallback_summary.paid_page_count
                            + fallback_summary.paid_frame_count
                        )
                        fallback_payload_bytes += fallback_summary.payload_byte_count
                except DocumentSourceChangedError as exc:
                    usage = (
                        _failed_local_usage(exc, window_invocation)
                        if local_ocr_provider is not None
                        else None
                    )
                    fallback_attempt = _fallback_attempt_evidence(exc)
                    confirmed = _attempt_confirmed_usages(fallback_attempt)
                    direct_usages, direct_attempts = _direct_cloud_failure_evidence(exc)
                    pages, frames, invocations, azure, paid, payload = (
                        _attempt_budget_values(fallback_attempt)
                    )
                    fallback_pages += pages
                    fallback_frames += frames
                    fallback_invocations += invocations
                    fallback_azure += azure
                    fallback_paid += paid
                    fallback_payload_bytes += payload
                    if local_ocr_provider is not None:
                        local_usage = _add_local_usage(local_usage, usage)
                        local_usage = _add_local_usages(local_usage, confirmed)
                    failures += 1
                    results[entry.index] = _failed(
                        entry.item,
                        prepared=entry.prepared,
                        category="source_changed",
                        provider_usage=usage,
                        retained_provider_usage=entry.retained_provider_usage
                        + confirmed
                        + direct_usages,
                        retained_azure_fallback_attempts=(
                            entry.retained_azure_fallback_attempts
                        ),
                        retained_cloud_execution_attempts=(
                            entry.retained_cloud_execution_attempts
                        ),
                        cloud_execution_attempts=direct_attempts,
                        azure_fallback_attempt=fallback_attempt,
                    )
                except LocalOcrLimitExceededError as exc:
                    usage = (
                        _failed_local_usage(exc, window_invocation)
                        if local_ocr_provider is not None
                        else None
                    )
                    if local_ocr_provider is not None:
                        local_usage = _add_local_usage(local_usage, usage)
                        if (
                            window_invocation is not None
                            and _batch_local_limit_was_narrowed(
                                exc,
                                local_ocr_provider,
                                window_invocation,
                            )
                        ):
                            local_budget_reached = True
                    failures += 1
                    results[entry.index] = _failed(
                        entry.item,
                        prepared=entry.prepared,
                        category="limit",
                        provider_usage=usage,
                        retained_provider_usage=entry.retained_provider_usage,
                        retained_azure_fallback_attempts=(
                            entry.retained_azure_fallback_attempts
                        ),
                        retained_cloud_execution_attempts=(
                            entry.retained_cloud_execution_attempts
                        ),
                    )
                except AzureFallbackLimitError as exc:
                    usage = (
                        _failed_local_usage(exc, window_invocation)
                        if local_ocr_provider is not None
                        else None
                    )
                    if local_ocr_provider is not None:
                        local_usage = _add_local_usage(local_usage, usage)
                    fallback_attempt = _fallback_attempt_evidence(exc)
                    confirmed = _attempt_confirmed_usages(fallback_attempt)
                    pages, frames, invocations, azure, paid, payload = (
                        _attempt_budget_values(fallback_attempt)
                    )
                    fallback_pages += pages
                    fallback_frames += frames
                    fallback_invocations += invocations
                    fallback_azure += azure
                    fallback_paid += paid
                    fallback_payload_bytes += payload
                    failures += 1
                    results[entry.index] = _failed(
                        entry.item,
                        prepared=entry.prepared,
                        category="limit",
                        provider_usage=usage,
                        retained_provider_usage=entry.retained_provider_usage
                        + confirmed,
                        retained_azure_fallback_attempts=(
                            entry.retained_azure_fallback_attempts
                        ),
                        retained_cloud_execution_attempts=(
                            entry.retained_cloud_execution_attempts
                        ),
                        azure_fallback_attempt=fallback_attempt,
                    )
                except Exception as exc:
                    usage = (
                        _failed_local_usage(exc, window_invocation)
                        if local_ocr_provider is not None
                        else None
                    )
                    if local_ocr_provider is not None:
                        local_usage = _add_local_usage(local_usage, usage)
                    fallback_attempt = _fallback_attempt_evidence(exc)
                    confirmed = _attempt_confirmed_usages(fallback_attempt)
                    pages, frames, invocations, azure, paid, payload = (
                        _attempt_budget_values(fallback_attempt)
                    )
                    fallback_pages += pages
                    fallback_frames += frames
                    fallback_invocations += invocations
                    fallback_azure += azure
                    fallback_paid += paid
                    fallback_payload_bytes += payload
                    local_usage = _add_local_usages(local_usage, confirmed)
                    failures += 1
                    direct_usages, direct_attempts = _direct_cloud_failure_evidence(exc)
                    results[entry.index] = _failed(
                        entry.item,
                        prepared=entry.prepared,
                        provider_usage=usage,
                        retained_provider_usage=entry.retained_provider_usage
                        + confirmed
                        + direct_usages,
                        retained_azure_fallback_attempts=(
                            entry.retained_azure_fallback_attempts
                        ),
                        retained_cloud_execution_attempts=(
                            entry.retained_cloud_execution_attempts
                        ),
                        cloud_execution_attempts=direct_attempts,
                        azure_fallback_attempt=fallback_attempt,
                    )
            for entry in window:
                current_result = results[entry.index]
                if current_result is not None:
                    cloud_budget.record(
                        entry.item.input_id,
                        _current_result_cloud_attempts(current_result),
                    )
            start += len(window)

    completed = tuple(result for result in results if result is not None)
    if len(completed) != len(items):
        raise BatchConfigurationError("Batch processing did not produce every item")
    completed = _finalize_identity_sensitive_results(items, completed)
    manifest_items = tuple(_manifest_item(item) for item in completed)
    status_counts = _status_counts(manifest_items)
    performed_counts = _aggregate_counts(manifest_items, "performed_operation_counts")
    retained_counts = _aggregate_counts(
        manifest_items, "retained_prior_operation_counts"
    )
    provider_counts = _aggregate_counts(manifest_items, "provider_operation_counts")
    provider_usage_totals = _provider_usage_totals(manifest_items)
    local_ocr_quality_aggregate = _local_ocr_quality_aggregate(manifest_items)
    local_ocr_preprocessing_aggregate = _local_ocr_preprocessing_aggregate(
        manifest_items
    )
    azure_fallback_aggregate = _azure_fallback_aggregate(manifest_items)
    consumed_input_bytes = _consumed_input_bytes(manifest_items)
    batch_fingerprint = compute_batch_fingerprint(
        sdk_version=__version__,
        processing_options_fingerprint=options_fingerprint,
        schema_id=None if manifest_schema is None else manifest_schema.schema_id,
        schema_version=(
            None if manifest_schema is None else manifest_schema.schema_version
        ),
        schema_fingerprint=schema_fingerprint,
        provider_profile_id=provider_profile_id,
        items=manifest_items,
        status_counts=status_counts,
        performed_operation_counts=performed_counts,
        retained_prior_operation_counts=retained_counts,
        provider_operation_counts=provider_counts,
        provider_usage_totals=provider_usage_totals,
        local_ocr_quality_aggregate=local_ocr_quality_aggregate,
        local_ocr_preprocessing_aggregate=local_ocr_preprocessing_aggregate,
        azure_fallback_aggregate=azure_fallback_aggregate,
        consumed_input_bytes=consumed_input_bytes,
    )
    manifest = BatchProcessingManifest(
        sdk_version=__version__,
        batch_fingerprint=batch_fingerprint,
        processing_options_fingerprint=options_fingerprint,
        schema_id=None if manifest_schema is None else manifest_schema.schema_id,
        schema_version=(
            None if manifest_schema is None else manifest_schema.schema_version
        ),
        schema_fingerprint=schema_fingerprint,
        provider_profile_id=provider_profile_id,
        items=manifest_items,
        status_counts=status_counts,
        performed_operation_counts=performed_counts,
        retained_prior_operation_counts=retained_counts,
        provider_operation_counts=provider_counts,
        provider_usage_totals=provider_usage_totals,
        local_ocr_quality_aggregate=local_ocr_quality_aggregate,
        local_ocr_preprocessing_aggregate=local_ocr_preprocessing_aggregate,
        azure_fallback_aggregate=azure_fallback_aggregate,
        consumed_input_bytes=consumed_input_bytes,
    )
    return BatchProcessingResult(
        items=completed,
        manifest=manifest,
        status_counts=status_counts,
        performed_operation_counts=performed_counts,
        retained_prior_operation_counts=retained_counts,
        provider_operation_counts=provider_counts,
        provider_usage_totals=provider_usage_totals,
        local_ocr_quality_aggregate=local_ocr_quality_aggregate,
        local_ocr_preprocessing_aggregate=local_ocr_preprocessing_aggregate,
        azure_fallback_aggregate=azure_fallback_aggregate,
        consumed_input_bytes=consumed_input_bytes,
    )


def save_batch_manifest(
    manifest: BatchProcessingManifest,
    path: Path,
) -> None:
    """Atomically persist a safe JSON manifest."""
    try:
        validated = _revalidate_model_instance_json(
            manifest,
            BatchProcessingManifest,
            "The batch manifest is invalid",
        )
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            BatchManifestError("The batch manifest is invalid"),
        )
    temporary: str | None = None
    save_failed = False
    cleanup_failed = False
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=path.parent,
            prefix=".batch-manifest-",
            suffix=".tmp",
            delete=False,
        ) as stream:
            temporary = stream.name
            stream.write(validated.model_dump_json(indent=2))
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        temporary = None
    except Exception as exc:
        _redact_exception(exc)
        save_failed = True
        if temporary is not None:
            try:
                Path(temporary).unlink(missing_ok=True)
            except Exception as cleanup_error:
                _redact_exception(cleanup_error)
                cleanup_failed = True
    if save_failed:
        failure = BatchManifestError("The batch manifest could not be saved safely")
        if cleanup_failed:
            failure.add_note("Temporary batch manifest cleanup also failed safely.")
        raise failure from OSError("redacted")


def load_batch_manifest(path: Path) -> BatchProcessingManifest:
    """Load and validate a safe JSON manifest."""
    loaded: BatchProcessingManifest | None = None
    try:
        loaded = BatchProcessingManifest.model_validate_json(
            path.read_text(encoding="utf-8")
        )
    except Exception as exc:
        _redact_exception(exc)
    if loaded is None:
        raise BatchManifestError("The batch manifest is invalid") from ValueError(
            "redacted"
        )
    return loaded

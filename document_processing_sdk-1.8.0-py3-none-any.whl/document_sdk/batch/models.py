"""Strict safe models and integrity rules for deterministic batch processing."""

# ruff: noqa: C901, D107, EM101, PLR0912, PLR0913, PLR2004, TC003, TRY003

from __future__ import annotations

import hashlib
import json
import unicodedata
from collections import Counter
from collections.abc import Mapping
from enum import StrEnum
from pathlib import Path, PurePosixPath
from typing import Annotated, Any, Literal, Self, cast

from pydantic import (
    AfterValidator,
    ConfigDict,
    Field,
    PrivateAttr,
    field_validator,
    model_validator,
)
from pydantic.config import ExtraValues  # noqa: TC002

from document_sdk.batch.errors import (
    BatchConfigurationError,
    BatchResultValidationError,
)
from document_sdk.core import (
    CloudExecutionAttemptEvidence,
    CloudExecutionAttemptStatus,
    LocalOcrQualityDecision,
    LocalOcrQualityIssueCode,
    LocalOcrQualityIssueCount,
    LocalOcrQualitySummary,
    ProviderUsage,
    ProviderUsageTotals,
)
from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.local_ocr_quality import (
    _local_ocr_quality_usage_matches,
    _validate_provider_usage,
    _validate_quality_summary,
)
from document_sdk.document import DocumentAnalysisResult, DocumentFormat, DocumentType
from document_sdk.document._exceptions import _redact_exception
from document_sdk.document._validation import SanitizedPublicModel
from document_sdk.document.models import (
    OperationCount,
    _azure_breakdown_matches_report,
    _canonical_document_result_fingerprint,
    _partition_completed_fallback_cloud_attempts,
    _validate_direct_cloud_attempt_bindings,
)
from document_sdk.docx.models import DocxProcessingLimits
from document_sdk.ocr.fallback_models import (
    AzureFallbackAttemptEvidence,
    AzurePageFallbackReport,
    AzurePageFallbackStatus,
    _validate_azure_fallback_attempt,
    _validate_azure_fallback_report,
)
from document_sdk.ocr.preprocessing_models import (
    LocalOcrPreprocessingProfile,
    LocalOcrPreprocessingProfileCount,
    LocalOcrPreprocessingSummary,
)
from document_sdk.workflow.models import (
    DocumentWorkflowIntakeResult,
    DocumentWorkflowIntakeStatus,
    WorkflowImageNativeResult,
    WorkflowPdfNativeResult,
)

_StrictModel = ConfigDict(
    extra="forbid",
    frozen=True,
    strict=False,
    validate_default=True,
    hide_input_in_errors=True,
)
NonEmptyString = Annotated[str, Field(min_length=1)]
Sha256 = Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]
PositiveLimit = Annotated[int, Field(strict=True, ge=1, le=10_000_000_000)]
PreprocessingAttemptLimit = Annotated[int, Field(strict=True, ge=0, le=1_000_000)]
PreprocessingOperationLimit = Annotated[int, Field(strict=True, ge=0, le=1_000_000)]
PreprocessingPixelLimit = Annotated[int, Field(strict=True, ge=0, le=10_000_000_000)]
_MAX_PREPROCESSING_PROFILE_COUNTS = len(tuple(LocalOcrPreprocessingProfile))
_MAX_PREPROCESSING_SAFE_FAILURE_COUNTS = 1


def _validate_batch_preprocessing_collections(data: object) -> object:
    """Preflight exact public containers before serialization or item parsing."""
    if type(data) is not dict:
        return data
    for field_name, maximum in (
        ("selected_profile_counts", _MAX_PREPROCESSING_PROFILE_COUNTS),
        ("safe_failure_counts", _MAX_PREPROCESSING_SAFE_FAILURE_COUNTS),
    ):
        value = data.get(field_name, ())
        if type(value) not in {list, tuple}:
            raise ValueError("Batch preprocessing evidence is invalid")
        if len(value) > maximum:
            raise ValueError("Batch preprocessing evidence exceeds its limit")
    return data


class _PublicModel(SanitizedPublicModel):
    """Public Batch model with sanitized validation failures."""

    _validation_error_type = BatchResultValidationError
    _validation_error_message = "Batch result validation failed"


def _validate_batch_input_id(value: str) -> str:
    normalized = unicodedata.normalize("NFKC", value)
    if (
        normalized != value
        or not value
        or len(value) > 128
        or value in {".", ".."}
        or value != value.strip()
        or "/" in value
        or "\\" in value
        or PurePosixPath(value).is_absolute()
        or any(ord(character) < 32 or ord(character) == 127 for character in value)
    ):
        raise ValueError("input_id must be a normalized safe identifier")
    return value


BatchInputId = Annotated[
    str,
    Field(strict=True, min_length=1, max_length=128),
    AfterValidator(_validate_batch_input_id),
]


def normalize_relative_name(value: str) -> str:
    """Return one canonical safe POSIX relative name."""
    if "\\" in value:
        raise ValueError("relative_name must not contain a backslash")
    normalized = unicodedata.normalize("NFKC", value)
    candidate = PurePosixPath(normalized)
    if (
        not normalized
        or normalized.startswith("/")
        or candidate.is_absolute()
        or any(segment in {"", ".", ".."} for segment in normalized.split("/"))
        or any(ord(character) < 32 or ord(character) == 127 for character in normalized)
    ):
        raise ValueError("relative_name must be a normalized safe relative path")
    return normalized


def _validate_relative_name(value: str) -> str:
    normalized = normalize_relative_name(value)
    if normalized != value:
        raise ValueError("relative_name must already be Unicode NFKC normalized")
    return normalized


def _batch_input_storage(
    value: object,
    expected_type: type[object],
) -> dict[str, object]:
    """Read only exact Pydantic storage from an actual Batch input model."""
    actual_type = type(value)
    if not issubclass(actual_type, expected_type):
        raise TypeError("Unexpected BatchDocumentInput type")
    storage = object.__getattribute__(value, "__dict__")
    private_storage = object.__getattribute__(value, "__pydantic_private__")
    if (
        type(storage) is not dict
        or set(storage) != {"input_id", "relative_name", "_source"}
        or type(private_storage) is not dict
        or private_storage
        or type(storage["_source"]) is not type(Path())
    ):
        raise ValueError("BatchDocumentInput runtime state is invalid")
    return storage


def _counts_are_canonical(counts: tuple[OperationCount, ...]) -> bool:
    names = tuple(item.name for item in counts)
    return names == tuple(sorted(set(names)))


def _operation_names(counts: tuple[OperationCount, ...]) -> frozenset[str]:
    if any(item.count != 1 for item in counts):
        return frozenset()
    return frozenset(item.name for item in counts)


def _family_count(
    document_type: DocumentType | None,
    pdf_page_count: int | None,
    excel_worksheet_count: int | None,
    image_frame_count: int | None,
    docx_block_count: int | None,
) -> bool:
    counts = (
        pdf_page_count,
        excel_worksheet_count,
        image_frame_count,
        docx_block_count,
    )
    if document_type is None:
        return all(count is None for count in counts)
    if sum(count is not None for count in counts) != 1:
        return False
    return (
        (document_type is DocumentType.PDF and pdf_page_count is not None)
        or (document_type is DocumentType.EXCEL and excel_worksheet_count is not None)
        or (document_type is DocumentType.IMAGE and image_frame_count is not None)
        or (document_type is DocumentType.WORD and docx_block_count is not None)
    )


def _complete_result_operations(
    document_type: DocumentType,
    names: frozenset[str],
) -> bool:
    local = frozenset({"detection", "inspection"})
    if document_type is DocumentType.EXCEL:
        return names == local
    if document_type is DocumentType.IMAGE:
        return names in {
            local,
            local | {"ocr_provider"},
            local | {"ocr_provider", "structured_extraction"},
        }
    if document_type is DocumentType.WORD:
        return names in {
            local | {"docx_analysis"},
            local | {"docx_analysis", "structured_extraction"},
        }
    return names in {
        local | {"native_pdf"},
        local | {"hybrid_pdf"},
        local | {"structured_extraction"},
    }


def _source_changed_operation_history_is_valid(names: frozenset[str]) -> bool:
    """Validate content-free operations retained after final identity loss."""
    return names in {
        frozenset(),
        frozenset({"detection"}),
        frozenset({"detection", "inspection"}),
        frozenset({"detection", "inspection", "workflow_intake"}),
    } or any(
        _complete_result_operations(document_type, names)
        for document_type in (
            DocumentType.PDF,
            DocumentType.EXCEL,
            DocumentType.IMAGE,
            DocumentType.WORD,
        )
    )


def _quality_evidence_matches_item(  # noqa: PLR0911
    *,
    status: BatchItemStatus,
    document_type: DocumentType | None,
    pdf_page_count: int | None,
    image_frame_count: int | None,
    summary: LocalOcrQualitySummary | None,
    provider_usage: ProviderUsage | None,
    preprocessing: LocalOcrPreprocessingSummary | None = None,
    fallback_attempt: AzureFallbackAttemptEvidence | None = None,
) -> bool:
    if summary is None:
        return preprocessing is None
    allowed_statuses = {
        BatchItemStatus.SUCCEEDED,
        BatchItemStatus.SKIPPED_PREVIOUS_SUCCESS,
        BatchItemStatus.DUPLICATE,
    }
    if fallback_attempt is not None:
        allowed_statuses.add(BatchItemStatus.FAILED)
    if status not in allowed_statuses or document_type not in {
        DocumentType.PDF,
        DocumentType.IMAGE,
    }:
        return False
    if status is BatchItemStatus.DUPLICATE:
        if provider_usage is not None:
            return False
    else:
        failed_after_preprocessing = (
            status is BatchItemStatus.FAILED
            and fallback_attempt is not None
            and preprocessing is None
            and provider_usage is not None
        )
        if failed_after_preprocessing and provider_usage is not None:
            preprocessing_attempt_count = (
                provider_usage.local_preprocessing_attempt_count
            )
            preprocessing_operation_count = (
                provider_usage.local_preprocessing_operation_count
            )
            preprocessing_pixel_count = provider_usage.local_preprocessing_pixel_count
        elif preprocessing is None:
            preprocessing_attempt_count = 0
            preprocessing_operation_count = 0
            preprocessing_pixel_count = 0
        else:
            preprocessing_attempt_count = preprocessing.extra_attempt_count
            preprocessing_operation_count = preprocessing.extra_operation_count
            preprocessing_pixel_count = preprocessing.preprocessing_pixel_count
        if not _local_ocr_quality_usage_matches(
            summary=summary,
            usage=provider_usage,
            preprocessing_attempt_count=preprocessing_attempt_count,
            preprocessing_operation_count=preprocessing_operation_count,
            preprocessing_pixel_count=preprocessing_pixel_count,
        ):
            return False
    evaluated_input_count = len(summary.evaluated_pages) + len(summary.evaluated_frames)
    if preprocessing is not None and (
        preprocessing.attempted_input_count != evaluated_input_count
    ):
        return False
    if document_type is DocumentType.PDF:
        return (
            pdf_page_count is not None
            and not summary.evaluated_frames
            and not summary.failed_frames
            and not summary.recommended_retry_frames
            and all(index <= pdf_page_count for index in summary.evaluated_pages)
            and (
                preprocessing is None
                or (
                    preprocessing.source_page_count == len(summary.evaluated_pages)
                    and preprocessing.source_frame_count == 0
                )
            )
        )
    return (
        image_frame_count is not None
        and summary.decision is not LocalOcrQualityDecision.NOT_APPLICABLE
        and not summary.evaluated_pages
        and not summary.failed_pages
        and not summary.recommended_retry_pages
        and all(index <= image_frame_count for index in summary.evaluated_frames)
        and (
            preprocessing is None
            or (
                preprocessing.source_frame_count == len(summary.evaluated_frames)
                and preprocessing.source_page_count == 0
            )
        )
    )


def _fallback_attempt_matches_family(
    *,
    attempt: AzureFallbackAttemptEvidence,
    document_type: DocumentType | None,
    pdf_page_count: int | None,
    image_frame_count: int | None,
) -> bool:
    """Bind one historical attempt to the item's exact source family and range."""
    trigger = attempt.trigger_quality_summary
    if document_type is DocumentType.PDF:
        if (
            pdf_page_count is None
            or attempt.source_kind != "page"
            or trigger.evaluated_frames
            or trigger.failed_frames
            or trigger.recommended_retry_frames
        ):
            return False
        indexes = (
            trigger.evaluated_pages
            + trigger.failed_pages
            + trigger.recommended_retry_pages
            + attempt.prepared_pages
            + attempt.invoked_pages
        )
        return all(index <= pdf_page_count for index in indexes)
    if document_type is DocumentType.IMAGE:
        if (
            image_frame_count is None
            or attempt.source_kind != "frame"
            or trigger.evaluated_pages
            or trigger.failed_pages
            or trigger.recommended_retry_pages
        ):
            return False
        indexes = (
            trigger.evaluated_frames
            + trigger.failed_frames
            + trigger.recommended_retry_frames
            + attempt.prepared_frames
            + attempt.invoked_frames
        )
        return all(index <= image_frame_count for index in indexes)
    return False


def _validate_fallback_attempt_bindings(
    *,
    retained_attempts: tuple[AzureFallbackAttemptEvidence, ...],
    current_attempt: AzureFallbackAttemptEvidence | None,
    completed_report: AzurePageFallbackReport | None,
    document_type: DocumentType | None,
    pdf_page_count: int | None,
    image_frame_count: int | None,
) -> None:
    """Require one immutable trigger and Provider contract across attempt history."""
    attempts = retained_attempts + (
        () if current_attempt is None else (current_attempt,)
    )
    if not attempts:
        return
    if document_type is None:
        if current_attempt is not None:
            raise ValueError("Current fallback attempt lacks source family evidence")
    elif any(
        not _fallback_attempt_matches_family(
            attempt=attempt,
            document_type=document_type,
            pdf_page_count=pdf_page_count,
            image_frame_count=image_frame_count,
        )
        for attempt in attempts
    ):
        raise ValueError("Fallback attempt source evidence is inconsistent")
    reference = attempts[0]
    if any(
        attempt.trigger_quality_summary != reference.trigger_quality_summary
        or attempt.provider_identity_summary != reference.provider_identity_summary
        or attempt.requested_features != reference.requested_features
        or attempt.query_field_count != reference.query_field_count
        for attempt in attempts[1:]
    ):
        raise ValueError("Fallback attempt history identity is inconsistent")
    if completed_report is not None and (
        completed_report.trigger_quality_summary != reference.trigger_quality_summary
        or completed_report.provider_identity_summary
        != reference.provider_identity_summary
        or completed_report.requested_features != reference.requested_features
        or completed_report.query_field_count != reference.query_field_count
    ):
        raise ValueError("Fallback report and attempt history are inconsistent")


class BatchItemStatus(StrEnum):
    """Stable per-item outcome categories."""

    SUCCEEDED = "succeeded"
    FAILED = "failed"
    SKIPPED_UNSUPPORTED = "skipped_unsupported"
    SKIPPED_PREVIOUS_SUCCESS = "skipped_previous_success"
    DUPLICATE = "duplicate"
    CANCELLED_BY_LIMIT = "cancelled_by_limit"


class BatchItemIssue(_PublicModel):
    """Content-free per-item issue."""

    model_config = _StrictModel

    code: NonEmptyString
    category: NonEmptyString
    message: NonEmptyString


class BatchLocalOcrQualityAggregate(_PublicModel):
    """Content-free Local OCR quality totals across Batch item projections."""

    model_config = _StrictModel

    quality_evaluated_item_count: Annotated[int, Field(strict=True, ge=0)] = 0
    quality_passed_item_count: Annotated[int, Field(strict=True, ge=0)] = 0
    quality_failed_item_count: Annotated[int, Field(strict=True, ge=0)] = 0
    quality_not_applicable_item_count: Annotated[int, Field(strict=True, ge=0)] = 0
    quality_issue_counts: tuple[LocalOcrQualityIssueCount, ...] = Field(
        default=(), max_length=len(LocalOcrQualityIssueCode)
    )
    recommended_retry_page_count: Annotated[int, Field(strict=True, ge=0)] = 0
    recommended_retry_frame_count: Annotated[int, Field(strict=True, ge=0)] = 0

    @model_validator(mode="after")
    def _consistent_quality_totals(self) -> BatchLocalOcrQualityAggregate:
        codes = tuple(item.code for item in self.quality_issue_counts)
        expected_codes = tuple(
            code for code in LocalOcrQualityIssueCode if code in codes
        )
        if (
            self.quality_evaluated_item_count
            != self.quality_passed_item_count + self.quality_failed_item_count
            or codes != expected_codes
            or any(item.count == 0 for item in self.quality_issue_counts)
            or any(
                item.count > self.quality_failed_item_count
                for item in self.quality_issue_counts
            )
            or (
                self.quality_failed_item_count == 0
                and (
                    self.quality_issue_counts
                    or self.recommended_retry_page_count
                    or self.recommended_retry_frame_count
                )
            )
            or (
                self.quality_failed_item_count > 0
                and (
                    not self.quality_issue_counts
                    or sum(item.count for item in self.quality_issue_counts)
                    < self.quality_failed_item_count
                    or self.recommended_retry_page_count
                    + self.recommended_retry_frame_count
                    < self.quality_failed_item_count
                )
            )
        ):
            raise ValueError("Batch Local OCR quality totals are inconsistent")
        return self


class BatchLocalOcrPreprocessingAggregate(_PublicModel):
    """Recomputable content-free preprocessing totals across Batch items."""

    model_config = _StrictModel

    evaluated_item_count: int = Field(default=0, ge=0)
    not_needed_item_count: int = Field(default=0, ge=0)
    preprocessing_attempted_item_count: int = Field(default=0, ge=0)
    improved_item_count: int = Field(default=0, ge=0)
    pass_after_preprocessing_item_count: int = Field(default=0, ge=0)
    still_failed_item_count: int = Field(default=0, ge=0)
    failed_item_count: int = Field(default=0, ge=0)
    page_count: int = Field(default=0, ge=0)
    frame_count: int = Field(default=0, ge=0)
    attempt_count: int = Field(default=0, ge=0)
    preprocessing_pixel_count: int = Field(default=0, ge=0)
    extra_operation_count: int = Field(default=0, ge=0)
    selected_profile_counts: tuple[LocalOcrPreprocessingProfileCount, ...] = Field(
        default=(), max_length=_MAX_PREPROCESSING_PROFILE_COUNTS
    )
    safe_failure_counts: tuple[OperationCount, ...] = Field(
        default=(), max_length=_MAX_PREPROCESSING_SAFE_FAILURE_COUNTS
    )

    @classmethod
    def model_validate(
        cls,
        obj: Any,
        *,
        strict: bool | None = None,
        extra: ExtraValues | None = None,
        from_attributes: bool | None = None,
        context: Any | None = None,
        by_alias: bool | None = None,
        by_name: bool | None = None,
    ) -> Self:
        """Bound exact collections before sanitized dictionary normalization."""
        try:
            _validate_batch_preprocessing_collections(obj)
            validated = super().model_validate(
                obj,
                strict=strict,
                extra=extra,
                from_attributes=from_attributes,
                context=context,
                by_alias=by_alias,
                by_name=by_name,
            )
        except Exception as exc:  # noqa: BLE001 - sanitized public boundary.
            _redact_exception(exc)
        else:
            return validated
        raise BatchResultValidationError(
            "Batch result validation failed"
        ) from ValueError("redacted")

    @model_validator(mode="before")
    @classmethod
    def validate_bounded_collections_before_parsing(cls, data: object) -> object:
        """Reject oversized or non-standard collections before nested parsing."""
        return _validate_batch_preprocessing_collections(data)

    @model_validator(mode="after")
    def validate_aggregate(self) -> Self:
        """Require exact outcome partitions and selected-profile cardinality."""
        if self.evaluated_item_count != (
            self.not_needed_item_count + self.preprocessing_attempted_item_count
        ):
            raise ValueError("Batch preprocessing item counts are inconsistent")
        if self.pass_after_preprocessing_item_count != self.improved_item_count:
            raise ValueError("Batch preprocessing improvement counts are inconsistent")
        profiles = tuple(item.profile for item in self.selected_profile_counts)
        expected_profiles = tuple(
            profile
            for profile in LocalOcrPreprocessingProfile
            if profile in set(profiles)
        )
        if profiles != expected_profiles:
            raise ValueError("Batch preprocessing profile counts are not canonical")
        if (
            sum(item.count for item in self.selected_profile_counts)
            != self.page_count + self.frame_count
        ):
            raise ValueError("Batch preprocessing profile counts are inconsistent")
        failure_names = tuple(item.name for item in self.safe_failure_counts)
        if (
            failure_names != tuple(sorted(set(failure_names)))
            or sum(item.count for item in self.safe_failure_counts)
            != self.failed_item_count
        ):
            raise ValueError("Batch preprocessing failure counts are inconsistent")
        if self.evaluated_item_count == 0 and (
            self.not_needed_item_count
            or self.preprocessing_attempted_item_count
            or self.improved_item_count
            or self.pass_after_preprocessing_item_count
            or self.still_failed_item_count
            or self.page_count
            or self.frame_count
            or self.selected_profile_counts
        ):
            raise ValueError("Empty Batch preprocessing evidence is inconsistent")
        return self


class BatchDocumentInput(_PublicModel):
    """One input whose local source exists only as private runtime state."""

    model_config = _StrictModel

    input_id: BatchInputId
    relative_name: NonEmptyString
    _source: Path = PrivateAttr()

    def __init__(
        self,
        *,
        input_id: str,
        relative_name: str,
        source: Path | str,
    ) -> None:
        public_fields: dict[str, object] = {
            "input_id": input_id,
            "relative_name": relative_name,
        }
        super().__init__(**public_fields)
        object.__setattr__(self, "_source", Path(source))

    @property
    def source(self) -> Path:
        """Return the caller-authorized runtime source path."""
        return self._source

    @classmethod
    def model_validate(
        cls,
        obj: Any,
        *,
        strict: bool | None = None,
        extra: ExtraValues | None = None,
        from_attributes: bool | None = None,
        context: Any | None = None,
        by_alias: bool | None = None,
        by_name: bool | None = None,
    ) -> Self:
        """Reconstruct and validate an exact runtime request."""
        del strict, extra, from_attributes, context, by_alias, by_name
        try:
            storage = _batch_input_storage(obj, cls)
            return cls(
                input_id=cast("str", storage["input_id"]),
                relative_name=cast("str", storage["relative_name"]),
                source=cast("Path", storage["_source"]),
            )
        except Exception as exc:  # noqa: BLE001 - public runtime request boundary.
            _redact_exception(exc)
        raise BatchConfigurationError(
            "BatchDocumentInput runtime request is invalid"
        ) from ValueError("redacted")

    @classmethod
    def model_validate_json(
        cls,
        json_data: str | bytes | bytearray,
        *,
        strict: bool | None = None,
        extra: ExtraValues | None = None,
        context: Any | None = None,
        by_alias: bool | None = None,
        by_name: bool | None = None,
    ) -> Self:
        """Reject persisted reconstruction without caller-owned runtime state."""
        del json_data, strict, extra, context, by_alias, by_name
        raise BatchConfigurationError(
            "BatchDocumentInput requires a runtime source"
        ) from ValueError("redacted")

    def model_copy(
        self,
        *,
        update: Mapping[str, Any] | None = None,
        deep: bool = False,
    ) -> Self:
        """Copy only without accepting unvalidated field updates."""
        if update:
            raise BatchConfigurationError(
                "BatchDocumentInput field updates are not supported"
            ) from ValueError("redacted")
        del deep
        return type(self).model_validate(self)

    @model_validator(mode="after")
    def _normalized_name(self) -> BatchDocumentInput:
        _validate_relative_name(self.relative_name)
        return self


class BatchProcessingOptions(_PublicModel):
    """Explicit deterministic discovery and processing policy."""

    model_config = _StrictModel

    recursive: bool = False
    include_hidden: bool = False
    include_unsupported: bool = True
    deduplicate_sha256: bool = True


class BatchProcessingLimits(_PublicModel):
    """Finite batch and cumulative resource limits."""

    model_config = _StrictModel

    max_files: PositiveLimit = 1_000
    max_total_input_bytes: PositiveLimit = 5_000_000_000
    max_file_bytes: PositiveLimit = 512_000_000
    max_total_pdf_pages: PositiveLimit = 10_000
    max_total_excel_sheets: PositiveLimit = 10_000
    max_total_image_frames: PositiveLimit = 10_000
    max_total_docx_blocks: PositiveLimit = 1_000_000
    max_total_local_ocr_operations: PositiveLimit = 1_000_000
    max_total_local_ocr_regions: PositiveLimit = 100_000_000
    max_total_local_ocr_pixels: PositiveLimit = 10_000_000_000
    max_total_local_ocr_characters: PositiveLimit = 10_000_000_000
    max_total_local_preprocessing_attempts: PreprocessingAttemptLimit = 1_000_000
    max_total_local_preprocessing_pixels: PreprocessingPixelLimit = 10_000_000_000
    max_total_local_preprocessing_operations: PreprocessingOperationLimit = 1_000_000
    max_total_azure_fallback_pages: PositiveLimit = 10_000
    max_total_azure_fallback_frames: PositiveLimit = 10_000
    max_total_azure_fallback_inputs: PositiveLimit = 10_000
    max_total_azure_fallback_operations: PositiveLimit = 10_000
    max_total_azure_fallback_payload_bytes: PositiveLimit = 1_000_000_000
    max_total_paid_operations: PositiveLimit = 10_000
    docx_limits: DocxProcessingLimits = Field(default_factory=DocxProcessingLimits)
    max_failures: PositiveLimit = 100
    max_workers: Annotated[int, Field(strict=True, ge=1, le=32)] = 1


class BatchAzureFallbackAggregate(_PublicModel):
    """Content-free aggregate of explicit Azure fallback outcomes."""

    model_config = _StrictModel

    evaluated: Annotated[int, Field(strict=True, ge=0)] = 0
    not_needed: Annotated[int, Field(strict=True, ge=0)] = 0
    completed: Annotated[int, Field(strict=True, ge=0)] = 0
    unresolved: Annotated[int, Field(strict=True, ge=0)] = 0
    failed: Annotated[int, Field(strict=True, ge=0)] = 0
    page_count: Annotated[int, Field(strict=True, ge=0)] = 0
    frame_count: Annotated[int, Field(strict=True, ge=0)] = 0
    provider_invocation_count: Annotated[int, Field(strict=True, ge=0)] = 0
    confirmed_azure_operation_count: Annotated[int, Field(strict=True, ge=0)] = 0
    confirmed_paid_operation_count: Annotated[int, Field(strict=True, ge=0)] = 0
    payload_count: Annotated[int, Field(strict=True, ge=0)] = 0
    payload_byte_count: Annotated[int, Field(strict=True, ge=0)] = 0
    reason_counts: tuple[LocalOcrQualityIssueCount, ...] = Field(
        default=(), max_length=len(LocalOcrQualityIssueCode)
    )

    @model_validator(mode="after")
    def _consistent_aggregate(self) -> BatchAzureFallbackAggregate:
        if self.evaluated != (
            self.not_needed + self.completed + self.unresolved + self.failed
        ):
            raise ValueError("Azure fallback aggregate status counts are inconsistent")
        expected = tuple(sorted(self.reason_counts, key=lambda item: item.code.value))
        if self.reason_counts != expected or len(
            {item.code for item in expected}
        ) != len(expected):
            raise ValueError("Azure fallback aggregate reasons are not canonical")
        if self.confirmed_paid_operation_count != self.confirmed_azure_operation_count:
            raise ValueError(
                "Azure fallback confirmed operation counts are inconsistent"
            )
        if self.confirmed_azure_operation_count > self.provider_invocation_count:
            raise ValueError("Azure fallback confirmed usage exceeds invocations")
        if self.payload_count != self.page_count + self.frame_count:
            raise ValueError("Azure fallback payload aggregate is inconsistent")
        if self.provider_invocation_count > self.payload_count:
            raise ValueError("Azure fallback invocations exceed prepared payloads")
        if (self.payload_count == 0 and self.payload_byte_count != 0) or (
            self.payload_count > 0 and self.payload_byte_count < self.payload_count
        ):
            raise ValueError("Azure fallback payload bytes are inconsistent")
        successful = self.completed + self.unresolved
        active = successful + self.failed
        resource_evidence = (
            self.page_count,
            self.frame_count,
            self.provider_invocation_count,
            self.confirmed_azure_operation_count,
            self.confirmed_paid_operation_count,
            self.payload_count,
            self.payload_byte_count,
        )
        if active == 0 and (any(resource_evidence) or self.reason_counts):
            raise ValueError("Azure fallback inactive aggregate has resource evidence")
        if successful > 0 and any(
            value < successful
            for value in (
                self.payload_count,
                self.provider_invocation_count,
                self.confirmed_azure_operation_count,
                self.confirmed_paid_operation_count,
            )
        ):
            raise ValueError(
                "Azure fallback successful outcomes lack resource evidence"
            )
        failing_evidence = self.completed + self.unresolved + self.failed
        if any(item.count > failing_evidence for item in self.reason_counts):
            raise ValueError("Azure fallback aggregate reason count is inconsistent")
        if failing_evidence and sum(item.count for item in self.reason_counts) < (
            failing_evidence
        ):
            raise ValueError("Azure fallback aggregate reasons do not cover outcomes")
        return self


def _validated_batch_usage(
    usage: ProviderUsage | None,
    retained_usage: tuple[ProviderUsage, ...],
) -> tuple[ProviderUsage | None, tuple[ProviderUsage, ...]]:
    return (
        _validate_provider_usage(usage),
        tuple(
            validated
            for item in retained_usage
            if (validated := _validate_provider_usage(item)) is not None
        ),
    )


def _validate_fallback_attempt_usage_retention(
    *,
    retained_usage: tuple[ProviderUsage, ...],
    attempts: tuple[AzureFallbackAttemptEvidence, ...],
) -> None:
    """Require one retained Usage occurrence for every confirmed Attempt Usage."""
    if not attempts:
        return
    unmatched = Counter(usage.model_dump_json() for usage in retained_usage)
    for attempt in attempts:
        confirmed = attempt.completed_azure_usages + (
            ()
            if attempt.current_attempt_usage is None
            else (attempt.current_attempt_usage,)
        )
        for usage in confirmed:
            key = usage.model_dump_json()
            if unmatched[key] == 0:
                raise ValueError("Fallback attempt confirmed Usage is not retained")
            unmatched[key] -= 1
    if any(
        unmatched[usage.model_dump_json()] > 0
        and (usage.azure_operation_count or usage.paid_operation_count)
        for usage in retained_usage
    ):
        raise ValueError("Fallback attempt retained Usage is duplicated")


def _cloud_usage_key(usage: ProviderUsage) -> tuple[object, ...]:
    """Project fields that bind one cloud Usage to one lifecycle attempt."""
    return (
        usage.provider_name,
        usage.profile_id,
        usage.model_id,
        usage.api_version,
        usage.provider_resource_identity,
        usage.submitted_pages,
        usage.submitted_frames,
        usage.cloud_logical_operation_count,
        usage.cloud_submitted_operation_count,
        usage.cloud_paid_or_possibly_paid_operation_count,
        usage.cloud_transport_retry_count,
    )


def _cloud_attempt_key(attempt: CloudExecutionAttemptEvidence) -> tuple[object, ...]:
    """Project the matching lifecycle fields without customer content."""
    return (
        attempt.provider_name,
        attempt.profile_id,
        attempt.model_id,
        attempt.api_version,
        attempt.provider_resource_identity,
        attempt.submitted_pages,
        attempt.submitted_frames,
        attempt.logical_operation_count,
        attempt.submitted_operation_count,
        attempt.paid_or_possibly_paid_operation_count,
        attempt.transport_retry_count,
    )


def _cloud_logical_operation_key(
    input_id: str,
    attempt: CloudExecutionAttemptEvidence,
) -> tuple[object, ...]:
    """Identify one logical cloud input independently of its submit attempts."""
    requested_indexes = attempt.requested_pages or attempt.requested_frames
    return (
        ("batch-input-id-v1", input_id),
        attempt.provider_name,
        attempt.profile_id,
        attempt.model_id,
        attempt.api_version,
        attempt.provider_resource_identity,
        attempt.policy_fingerprint,
        attempt.requested_entire_input,
        requested_indexes,
    )


class _BatchEvidence(_PublicModel):
    model_config = _StrictModel

    input_id: BatchInputId
    relative_name: NonEmptyString
    status: BatchItemStatus
    intake_status: DocumentWorkflowIntakeStatus | None = Field(
        default=None,
        exclude_if=lambda value: value is None,
    )
    duplicate_of: BatchInputId | None = None
    duplicate_identity_kind: Literal["source_sha256"] | None = None
    issues: tuple[BatchItemIssue, ...] = ()
    source_sha256: Sha256 | None = None
    byte_size: Annotated[int | None, Field(strict=True, ge=0)] = None
    consumed_input_bytes: Annotated[int, Field(strict=True, ge=0)] = 0
    document_type: DocumentType | None = None
    document_format: DocumentFormat | None = None
    pdf_page_count: Annotated[int | None, Field(strict=True, ge=1)] = None
    excel_worksheet_count: Annotated[int | None, Field(strict=True, ge=0)] = None
    image_frame_count: Annotated[int | None, Field(strict=True, ge=1)] = None
    docx_block_count: Annotated[int | None, Field(strict=True, ge=0)] = None
    result_fingerprint: Sha256 | None = None
    resume_eligible_success: bool = False
    performed_operation_counts: tuple[OperationCount, ...] = ()
    retained_prior_operation_counts: tuple[OperationCount, ...] = ()
    provider_operation_counts: tuple[OperationCount, ...] = ()
    provider_usage: ProviderUsage | None = None
    retained_provider_usage: tuple[ProviderUsage, ...] = ()
    provider_usage_breakdown: tuple[ProviderUsage, ...] = ()
    retained_cloud_execution_attempts: tuple[CloudExecutionAttemptEvidence, ...] = (
        Field(default=(), max_length=10_000)
    )
    cloud_execution_attempts: tuple[CloudExecutionAttemptEvidence, ...] = Field(
        default=(), max_length=10_000
    )
    local_ocr_quality_summary: LocalOcrQualitySummary | None = None
    local_ocr_preprocessing_summary: LocalOcrPreprocessingSummary | None = None
    azure_fallback_summary: AzurePageFallbackReport | None = None
    retained_azure_fallback_attempts: tuple[AzureFallbackAttemptEvidence, ...] = Field(
        default=(), max_length=10_000
    )
    azure_fallback_attempt: AzureFallbackAttemptEvidence | None = None

    def _validate_workflow_intake_evidence(  # noqa: PLR0915
        self,
        *,
        retained_usage: tuple[ProviderUsage, ...],
        breakdown: tuple[ProviderUsage, ...],
        retained_cloud_attempts: tuple[CloudExecutionAttemptEvidence, ...],
        cloud_attempts: tuple[CloudExecutionAttemptEvidence, ...],
    ) -> None:
        intake_status = self.intake_status
        if intake_status is None:
            raise ValueError("Workflow intake status is unavailable")
        if (
            self.provider_usage is not None
            or self.azure_fallback_summary is not None
            or self.retained_azure_fallback_attempts
            or self.azure_fallback_attempt is not None
        ):
            raise ValueError("Workflow intake evidence duplicates legacy evidence")
        current_provider_evidence = bool(breakdown or cloud_attempts)
        expected_provider_operations = (
            frozenset({"workflow_provider_analysis"})
            if current_provider_evidence
            else frozenset()
        )
        performed = _operation_names(self.performed_operation_counts)
        retained = _operation_names(self.retained_prior_operation_counts)
        provider = _operation_names(self.provider_operation_counts)
        if provider != expected_provider_operations:
            raise ValueError("Workflow intake Provider operations are inconsistent")
        if any(
            not _counts_are_canonical(counts) or any(item.count != 1 for item in counts)
            for counts in (
                self.performed_operation_counts,
                self.retained_prior_operation_counts,
                self.provider_operation_counts,
            )
        ):
            raise ValueError("operation counts must have unique sorted names")
        if self.document_format is not None and self.document_type is None:
            raise ValueError("document format requires a document type")
        if self.byte_size is not None and self.consumed_input_bytes < self.byte_size:
            raise ValueError("consumed input bytes cannot be below measured bytes")
        complete_family = _family_count(
            self.document_type,
            self.pdf_page_count,
            self.excel_worksheet_count,
            self.image_frame_count,
            self.docx_block_count,
        )
        has_identity = all(
            value is not None
            for value in (
                self.source_sha256,
                self.byte_size,
                self.document_type,
                self.document_format,
            )
        )
        has_any_identity = any(
            value is not None
            for value in (
                self.source_sha256,
                self.document_type,
                self.document_format,
                self.pdf_page_count,
                self.excel_worksheet_count,
                self.image_frame_count,
                self.docx_block_count,
            )
        )
        completed_operations = frozenset({"detection", "inspection", "workflow_intake"})
        successful_statuses = {
            DocumentWorkflowIntakeStatus.SUCCEEDED,
            DocumentWorkflowIntakeStatus.PARTIAL,
            DocumentWorkflowIntakeStatus.REVIEW_REQUIRED,
        }
        if self.status is BatchItemStatus.SUCCEEDED:
            if (
                intake_status not in successful_statuses
                or not has_identity
                or not complete_family
                or self.result_fingerprint is None
                or self.duplicate_of is not None
                or not self.resume_eligible_success
                or self.consumed_input_bytes != self.byte_size
                or performed != completed_operations
                or retained
            ):
                raise ValueError("succeeded Workflow intake evidence is incomplete")
        elif self.status is BatchItemStatus.FAILED:
            if (
                intake_status
                not in {
                    DocumentWorkflowIntakeStatus.REJECTED,
                    DocumentWorkflowIntakeStatus.FAILED,
                }
                or not self.issues
                or self.result_fingerprint is None
                or self.duplicate_of is not None
                or self.resume_eligible_success
                or retained
                or (
                    has_identity
                    and (
                        not complete_family
                        or performed != completed_operations
                        or self.consumed_input_bytes != self.byte_size
                    )
                )
                or (
                    not has_identity
                    and (
                        has_any_identity
                        or performed
                        or current_provider_evidence
                        or retained_usage
                        or retained_cloud_attempts
                    )
                )
            ):
                raise ValueError("failed Workflow intake evidence is inconsistent")
        elif self.status is BatchItemStatus.SKIPPED_UNSUPPORTED:
            if (
                intake_status is not DocumentWorkflowIntakeStatus.UNSUPPORTED
                or not self.issues
                or any(item.category != "unsupported" for item in self.issues)
                or self.result_fingerprint is None
                or self.duplicate_of is not None
                or self.resume_eligible_success
                or retained
                or current_provider_evidence
                or (
                    has_identity
                    and (
                        not complete_family
                        or performed != completed_operations
                        or self.consumed_input_bytes != self.byte_size
                    )
                )
                or (
                    not has_identity
                    and (
                        has_any_identity
                        or performed
                        or retained_usage
                        or retained_cloud_attempts
                    )
                )
            ):
                raise ValueError("unsupported Workflow intake evidence is inconsistent")
        elif self.status is BatchItemStatus.SKIPPED_PREVIOUS_SUCCESS:
            if (
                intake_status not in successful_statuses
                or not has_identity
                or not complete_family
                or self.result_fingerprint is None
                or self.duplicate_of is not None
                or not self.resume_eligible_success
                or performed != frozenset({"detection"})
                or retained != completed_operations
                or provider
                or breakdown
                or cloud_attempts
                or self.consumed_input_bytes != self.byte_size
            ):
                raise ValueError("resumed Workflow intake evidence is incomplete")
        else:
            raise ValueError("Orchestration-only item cannot claim Workflow intake")

        if self.document_type is not None:
            _validate_direct_cloud_attempt_bindings(
                retained_cloud_attempts + cloud_attempts,
                document_type=self.document_type,
                pdf_page_count=self.pdf_page_count,
                image_frame_count=self.image_frame_count,
                byte_size=self.byte_size,
            )
        all_usages = retained_usage + breakdown
        all_attempts = retained_cloud_attempts + cloud_attempts
        cloud_usages = Counter(
            _cloud_usage_key(item)
            for item in all_usages
            if item.cloud_logical_operation_count
        )
        usage_backed_attempts = Counter(
            _cloud_attempt_key(attempt)
            for attempt in all_attempts
            if attempt.status
            in {
                CloudExecutionAttemptStatus.COMPLETED,
                CloudExecutionAttemptStatus.POSSIBLY_PAID,
            }
        )
        completed_attempts = Counter(
            _cloud_attempt_key(attempt)
            for attempt in all_attempts
            if attempt.status is CloudExecutionAttemptStatus.COMPLETED
        )
        if any(
            count > usage_backed_attempts[key] for key, count in cloud_usages.items()
        ) or any(
            count > cloud_usages[key] for key, count in completed_attempts.items()
        ):
            raise ValueError("Workflow intake cloud evidence is inconsistent")
        if intake_status in {
            DocumentWorkflowIntakeStatus.SUCCEEDED,
            DocumentWorkflowIntakeStatus.PARTIAL,
        } and any(
            attempt.status is not CloudExecutionAttemptStatus.COMPLETED
            for attempt in cloud_attempts
        ):
            raise ValueError("Completed Workflow intake has protected cloud evidence")
        current_quality_usages = tuple(
            item
            for item in breakdown
            if item.provider_name == "local_ocr" and item.local_operation_count
        )
        retained_quality_usages = tuple(
            item
            for item in retained_usage
            if item.provider_name == "local_ocr" and item.local_operation_count
        )
        matching_retained_quality_usages = tuple(
            item
            for item in retained_quality_usages
            if _quality_evidence_matches_item(
                status=self.status,
                document_type=self.document_type,
                pdf_page_count=self.pdf_page_count,
                image_frame_count=self.image_frame_count,
                summary=self.local_ocr_quality_summary,
                provider_usage=item,
                preprocessing=self.local_ocr_preprocessing_summary,
            )
        )
        quality_usage = (
            current_quality_usages[0]
            if len(current_quality_usages) == 1
            else matching_retained_quality_usages[0]
            if not current_quality_usages and len(matching_retained_quality_usages) == 1
            else None
        )
        if not _quality_evidence_matches_item(
            status=self.status,
            document_type=self.document_type,
            pdf_page_count=self.pdf_page_count,
            image_frame_count=self.image_frame_count,
            summary=self.local_ocr_quality_summary,
            provider_usage=quality_usage,
            preprocessing=self.local_ocr_preprocessing_summary,
        ):
            raise ValueError("Workflow intake Local OCR quality is inconsistent")

    @model_validator(mode="after")
    def _valid_evidence(self) -> _BatchEvidence:  # noqa: PLR0915
        source_changed_failure = bool(
            self.status is BatchItemStatus.FAILED
            and self.intake_status is None
            and self.issues
            and self.issues[0].code == "batch.source_changed"
            and self.issues[0].category == "source_changed"
        )
        source_changed_issue_count = sum(
            issue.code == "batch.source_changed" or issue.category == "source_changed"
            for issue in self.issues
        )
        if source_changed_issue_count and (
            not source_changed_failure or source_changed_issue_count != 1
        ):
            raise ValueError("Source-change issue evidence is inconsistent")
        duplicate_identity_kind = self.duplicate_identity_kind
        if self.status is BatchItemStatus.DUPLICATE:
            if duplicate_identity_kind is None:
                duplicate_identity_kind = "source_sha256"
                object.__setattr__(
                    self,
                    "duplicate_identity_kind",
                    duplicate_identity_kind,
                )
            if duplicate_identity_kind != "source_sha256":
                raise ValueError("Duplicate identity evidence is inconsistent")
        elif duplicate_identity_kind is not None:
            raise ValueError("Duplicate identity kind requires a duplicate item")
        usage, retained_usage = _validated_batch_usage(
            self.provider_usage,
            self.retained_provider_usage,
        )
        object.__setattr__(self, "provider_usage", usage)
        object.__setattr__(self, "retained_provider_usage", retained_usage)
        breakdown = tuple(
            validated
            for item in self.provider_usage_breakdown
            if (validated := _validate_provider_usage(item)) is not None
        )
        object.__setattr__(self, "provider_usage_breakdown", breakdown)
        retained_cloud_attempts = tuple(
            _revalidate_model_instance_json(
                attempt,
                CloudExecutionAttemptEvidence,
                "Retained cloud execution attempt is invalid",
            )
            for attempt in self.retained_cloud_execution_attempts
        )
        cloud_attempts = tuple(
            _revalidate_model_instance_json(
                attempt,
                CloudExecutionAttemptEvidence,
                "Cloud execution attempt is invalid",
            )
            for attempt in self.cloud_execution_attempts
        )
        object.__setattr__(
            self,
            "retained_cloud_execution_attempts",
            retained_cloud_attempts,
        )
        object.__setattr__(self, "cloud_execution_attempts", cloud_attempts)
        if self.local_ocr_quality_summary is not None:
            object.__setattr__(
                self,
                "local_ocr_quality_summary",
                _validate_quality_summary(self.local_ocr_quality_summary),
            )
        if self.local_ocr_preprocessing_summary is not None:
            object.__setattr__(
                self,
                "local_ocr_preprocessing_summary",
                _revalidate_model_instance_json(
                    self.local_ocr_preprocessing_summary,
                    LocalOcrPreprocessingSummary,
                    "Local OCR preprocessing summary is invalid",
                ),
            )
        if self.azure_fallback_summary is not None:
            object.__setattr__(
                self,
                "azure_fallback_summary",
                _validate_azure_fallback_report(self.azure_fallback_summary),
            )
        if self.intake_status is not None:
            self._validate_workflow_intake_evidence(
                retained_usage=retained_usage,
                breakdown=breakdown,
                retained_cloud_attempts=retained_cloud_attempts,
                cloud_attempts=cloud_attempts,
            )
            return self
        retained_attempts = tuple(
            _validate_azure_fallback_attempt(item)
            for item in self.retained_azure_fallback_attempts
        )
        object.__setattr__(
            self,
            "retained_azure_fallback_attempts",
            retained_attempts,
        )
        if self.azure_fallback_attempt is not None:
            object.__setattr__(
                self,
                "azure_fallback_attempt",
                _validate_azure_fallback_attempt(self.azure_fallback_attempt),
            )
        if (
            self.azure_fallback_summary is not None
            and self.azure_fallback_attempt is not None
        ):
            raise ValueError("Completed fallback cannot retain failed attempt evidence")
        _validate_fallback_attempt_bindings(
            retained_attempts=retained_attempts,
            current_attempt=self.azure_fallback_attempt,
            completed_report=self.azure_fallback_summary,
            document_type=self.document_type,
            pdf_page_count=self.pdf_page_count,
            image_frame_count=self.image_frame_count,
        )
        _validate_fallback_attempt_usage_retention(
            retained_usage=retained_usage,
            attempts=retained_attempts
            + (
                ()
                if self.azure_fallback_attempt is None
                else (self.azure_fallback_attempt,)
            ),
        )
        if self.azure_fallback_summary is not None:
            expected_fallback_quality = (
                self.azure_fallback_summary.structured_recheck_summary
                if self.azure_fallback_summary.structured_recheck_performed
                else self.azure_fallback_summary.trigger_quality_summary
            )
            if self.local_ocr_quality_summary != expected_fallback_quality:
                raise ValueError("Fallback summary quality evidence is inconsistent")
        local_breakdown = () if usage is None else (usage,)
        fallback = self.azure_fallback_summary
        provider_operations = _operation_names(self.provider_operation_counts)
        workflow_source_changed = bool(
            source_changed_failure
            and self.provider_usage is None
            and (
                (
                    bool(breakdown or cloud_attempts)
                    and provider_operations == frozenset({"workflow_provider_analysis"})
                )
                or (not breakdown and not cloud_attempts and not provider_operations)
            )
        )
        if self.status is BatchItemStatus.DUPLICATE:
            if usage is not None or retained_usage or breakdown:
                raise ValueError("Duplicate Provider usage is inconsistent")
        elif fallback is None:
            if not workflow_source_changed and breakdown not in ((), local_breakdown):
                raise ValueError("Provider usage breakdown is inconsistent")
        elif fallback.status is AzurePageFallbackStatus.NOT_APPLICABLE:
            if breakdown != local_breakdown:
                raise ValueError("Provider usage breakdown is inconsistent")
        else:
            azure_usages = breakdown[len(local_breakdown) :]
            if (
                breakdown[: len(local_breakdown)] != local_breakdown
                or len(azure_usages) != fallback.azure_operation_count
                or not _azure_breakdown_matches_report(fallback, azure_usages)
                or sum(len(item.submitted_pages) for item in azure_usages)
                != fallback.paid_page_count
                or sum(len(item.submitted_frames) for item in azure_usages)
                != fallback.paid_frame_count
            ):
                raise ValueError("Azure fallback usage breakdown is inconsistent")
        if (
            self.azure_fallback_attempt is not None
            and self.status is not BatchItemStatus.FAILED
        ):
            raise ValueError("Fallback attempt evidence requires a failed item")
        if (
            self.azure_fallback_attempt is not None
            and self.local_ocr_quality_summary
            != self.azure_fallback_attempt.trigger_quality_summary
        ):
            raise ValueError("Fallback attempt quality evidence is inconsistent")
        if self.status is BatchItemStatus.DUPLICATE and retained_attempts:
            raise ValueError("Duplicate items cannot repeat fallback attempts")
        fallback_cloud_attempts = tuple(
            cloud_attempt
            for attempt in retained_attempts
            + (
                ()
                if self.azure_fallback_attempt is None
                else (self.azure_fallback_attempt,)
            )
            for cloud_attempt in attempt.completed_cloud_execution_attempts
            + (
                ()
                if attempt.current_cloud_execution_attempt is None
                else (attempt.current_cloud_execution_attempt,)
            )
        )
        all_cloud_attempts = (
            retained_cloud_attempts + cloud_attempts + fallback_cloud_attempts
        )
        standalone_cloud_attempts = retained_cloud_attempts + cloud_attempts
        if self.status is not BatchItemStatus.DUPLICATE:
            standalone_cloud_attempts = _partition_completed_fallback_cloud_attempts(
                fallback,
                standalone_cloud_attempts,
            )
        if self.document_type is not None:
            _validate_direct_cloud_attempt_bindings(
                standalone_cloud_attempts,
                document_type=self.document_type,
                pdf_page_count=self.pdf_page_count,
                image_frame_count=self.image_frame_count,
                byte_size=self.byte_size,
            )
        all_usages = retained_usage + (breakdown or (() if usage is None else (usage,)))
        cloud_usages = Counter(
            _cloud_usage_key(item)
            for item in all_usages
            if item.cloud_logical_operation_count
        )
        usage_backed_attempts = Counter(
            _cloud_attempt_key(attempt)
            for attempt in all_cloud_attempts
            if attempt.status
            in {
                CloudExecutionAttemptStatus.COMPLETED,
                CloudExecutionAttemptStatus.POSSIBLY_PAID,
            }
        )
        completed_attempts = Counter(
            _cloud_attempt_key(attempt)
            for attempt in all_cloud_attempts
            if attempt.status is CloudExecutionAttemptStatus.COMPLETED
        )
        if any(
            count > usage_backed_attempts[key] for key, count in cloud_usages.items()
        ) or any(
            count > cloud_usages[key] for key, count in completed_attempts.items()
        ):
            raise ValueError("Batch cloud attempt and usage evidence is inconsistent")
        if self.status is BatchItemStatus.SUCCEEDED and any(
            attempt.status is not CloudExecutionAttemptStatus.COMPLETED
            for attempt in cloud_attempts
        ):
            raise ValueError("Succeeded item has incomplete cloud attempt evidence")
        if self.status is BatchItemStatus.DUPLICATE and all_cloud_attempts:
            raise ValueError("Duplicate items cannot repeat cloud attempts")
        if (
            self.status
            not in {
                BatchItemStatus.SUCCEEDED,
                BatchItemStatus.FAILED,
            }
            and cloud_attempts
        ):
            raise ValueError("Non-executed item has current cloud attempt evidence")
        _validate_relative_name(self.relative_name)
        for counts in (
            self.performed_operation_counts,
            self.retained_prior_operation_counts,
            self.provider_operation_counts,
        ):
            if not _counts_are_canonical(counts) or any(
                count.count != 1 for count in counts
            ):
                raise ValueError("operation counts must have unique sorted names")
        if self.document_format is not None and self.document_type is None:
            raise ValueError("document format requires a document type")
        if self.byte_size is not None and self.consumed_input_bytes < self.byte_size:
            raise ValueError("consumed input bytes cannot be below measured bytes")
        complete_family = _family_count(
            self.document_type,
            self.pdf_page_count,
            self.excel_worksheet_count,
            self.image_frame_count,
            self.docx_block_count,
        )
        has_identity = all(
            value is not None
            for value in (
                self.source_sha256,
                self.byte_size,
                self.document_type,
                self.document_format,
            )
        )
        has_any_identity = any(
            value is not None
            for value in (
                self.source_sha256,
                self.byte_size,
                self.document_type,
                self.document_format,
                self.pdf_page_count,
                self.excel_worksheet_count,
                self.image_frame_count,
                self.docx_block_count,
            )
        )
        performed = _operation_names(self.performed_operation_counts)
        retained = _operation_names(self.retained_prior_operation_counts)
        provider = provider_operations
        retry_denied_with_prior = (
            len(self.issues) == 1
            and self.issues[0].category == "cloud_retry_denied"
            and performed == frozenset({"detection"})
            and {"detection", "inspection"}.issubset(retained)
            and complete_family
        )
        if self.status is BatchItemStatus.SUCCEEDED:
            if (
                not has_identity
                or not complete_family
                or self.result_fingerprint is None
                or self.duplicate_of is not None
                or self.issues
                or not self.resume_eligible_success
                or self.document_type is None
                or self.consumed_input_bytes != self.byte_size
                or not _complete_result_operations(self.document_type, performed)
                or retained
            ):
                raise ValueError("succeeded item evidence is incomplete")
        elif self.status is BatchItemStatus.FAILED:
            if (
                not self.issues
                or self.duplicate_of is not None
                or self.resume_eligible_success
                or self.result_fingerprint is not None
                or (
                    self.retained_prior_operation_counts
                    and not retry_denied_with_prior
                    and not source_changed_failure
                )
                or (
                    source_changed_failure
                    and not _source_changed_operation_history_is_valid(retained)
                )
                or (has_any_identity and self.byte_size is None)
                or performed
                not in {
                    frozenset(),
                    frozenset({"detection"}),
                    frozenset({"detection", "inspection"}),
                }
                or (
                    not performed
                    and any(
                        value is not None
                        for value in (
                            self.source_sha256,
                            self.document_type,
                            self.document_format,
                            self.pdf_page_count,
                            self.excel_worksheet_count,
                            self.image_frame_count,
                            self.docx_block_count,
                        )
                    )
                )
                or (
                    performed == frozenset({"detection"})
                    and (
                        not has_identity
                        or (complete_family and not retry_denied_with_prior)
                    )
                )
                or (
                    performed == frozenset({"detection", "inspection"})
                    and (not has_identity or not complete_family)
                )
            ):
                raise ValueError("failed item evidence is inconsistent")
        elif self.status is BatchItemStatus.SKIPPED_UNSUPPORTED:
            if (
                len(self.issues) != 1
                or self.issues[0].category != "unsupported"
                or self.duplicate_of is not None
                or self.resume_eligible_success
                or self.result_fingerprint is not None
                or self.performed_operation_counts
                or self.retained_prior_operation_counts
                or self.provider_operation_counts
                or any(
                    value is not None
                    for value in (
                        self.source_sha256,
                        self.document_type,
                        self.document_format,
                        self.pdf_page_count,
                        self.excel_worksheet_count,
                        self.image_frame_count,
                        self.docx_block_count,
                    )
                )
            ):
                raise ValueError("unsupported item evidence is inconsistent")
        elif self.status is BatchItemStatus.SKIPPED_PREVIOUS_SUCCESS:
            if (
                not has_identity
                or not complete_family
                or self.result_fingerprint is None
                or self.duplicate_of is not None
                or not self.resume_eligible_success
                or performed != frozenset({"detection"})
                or not {"detection", "inspection"}.issubset(retained)
                or self.document_type is None
                or not _complete_result_operations(self.document_type, retained)
                or self.provider_operation_counts
                or self.issues
                or self.consumed_input_bytes != self.byte_size
            ):
                raise ValueError("resumed item evidence is incomplete")
        elif self.status is BatchItemStatus.DUPLICATE:
            if (
                not has_identity
                or not complete_family
                or not self.duplicate_of
                or self.duplicate_of == self.input_id
                or self.resume_eligible_success
                or self.result_fingerprint is not None
                or self.issues
                or performed != frozenset({"detection"})
                or self.retained_prior_operation_counts
                or self.provider_operation_counts
                or self.consumed_input_bytes != self.byte_size
            ):
                raise ValueError("duplicate item evidence is inconsistent")
        elif (
            len(self.issues) != 1
            or self.issues[0].category != "limit"
            or self.duplicate_of is not None
            or self.resume_eligible_success
            or self.result_fingerprint is not None
            or self.retained_prior_operation_counts
            or performed
            not in {
                frozenset(),
                frozenset({"detection"}),
                frozenset({"detection", "inspection"}),
            }
            or (
                not performed
                and any(
                    value is not None
                    for value in (
                        self.source_sha256,
                        self.document_type,
                        self.document_format,
                        self.pdf_page_count,
                        self.excel_worksheet_count,
                        self.image_frame_count,
                        self.docx_block_count,
                    )
                )
            )
            or (
                performed == frozenset({"detection"})
                and (not has_identity or not complete_family)
            )
            or (
                performed == frozenset({"detection", "inspection"})
                and (not has_identity or not complete_family)
            )
        ):
            raise ValueError("cancelled item evidence is inconsistent")
        if workflow_source_changed:
            expected_provider = (
                frozenset({"workflow_provider_analysis"})
                if breakdown or cloud_attempts
                else frozenset()
            )
            if provider != expected_provider:
                raise ValueError(
                    "Workflow source-change Provider evidence is inconsistent"
                )
        elif provider and provider != frozenset({"provider_analysis"}):
            raise ValueError("Provider operation evidence is inconsistent")
        if self.status is BatchItemStatus.SUCCEEDED:
            if bool(provider) != (self.provider_usage is not None):
                raise ValueError("succeeded Provider usage evidence is inconsistent")
        elif self.status is BatchItemStatus.FAILED:
            if not workflow_source_changed and bool(provider) != (
                self.provider_usage is not None
            ):
                raise ValueError("failed Provider usage evidence is inconsistent")
            if (
                self.provider_usage is not None
                and self.provider_usage.local_operation_count == 0
            ):
                raise ValueError("failed Provider usage requires an actual attempt")
        elif self.status is BatchItemStatus.SKIPPED_PREVIOUS_SUCCESS:
            provider_routes = {
                "ocr_provider",
                "hybrid_pdf",
                "structured_extraction",
            }
            if self.provider_usage is not None and not provider_routes.intersection(
                retained
            ):
                raise ValueError("retained Provider usage evidence is inconsistent")
        elif self.status is BatchItemStatus.CANCELLED_BY_LIMIT:
            if bool(provider) != (self.provider_usage is not None):
                raise ValueError("cancelled Provider usage evidence is inconsistent")
            if (
                self.provider_usage is not None
                and self.provider_usage.local_operation_count == 0
            ):
                raise ValueError("cancelled Provider usage requires an actual attempt")
        elif self.provider_usage is not None:
            raise ValueError("non-Provider item cannot retain Provider usage")
        if not _quality_evidence_matches_item(
            status=self.status,
            document_type=self.document_type,
            pdf_page_count=self.pdf_page_count,
            image_frame_count=self.image_frame_count,
            summary=self.local_ocr_quality_summary,
            provider_usage=self.provider_usage,
            preprocessing=self.local_ocr_preprocessing_summary,
            fallback_attempt=self.azure_fallback_attempt,
        ):
            raise ValueError("Local OCR quality item evidence is inconsistent")
        return self


def _workflow_intake_operations() -> tuple[OperationCount, ...]:
    return tuple(
        OperationCount(name=name, count=1)
        for name in ("detection", "inspection", "workflow_intake")
    )


def _workflow_intake_result_fingerprint(
    result: DocumentWorkflowIntakeResult,
) -> str:
    return hashlib.sha256(
        b"document-sdk:batch-workflow-intake-result:v1\0"
        + json.dumps(
            result.model_dump(mode="json"),
            allow_nan=False,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        ).encode()
    ).hexdigest()


def _workflow_preprocessing_summary(
    intake: DocumentWorkflowIntakeResult,
) -> LocalOcrPreprocessingSummary | None:
    workflow = intake.workflow_result
    if workflow is None or workflow.native_result is None:
        return None
    native = workflow.native_result
    processing = None
    if type(native) is WorkflowPdfNativeResult:
        processing = native.analysis.processing_result
    elif type(native) is WorkflowImageNativeResult:
        processing = native.analysis.ocr_result
    if processing is None:
        return None
    report = processing.metadata.local_ocr_preprocessing_report
    return None if report is None else report.summary()


class BatchItemResult(_BatchEvidence):
    """One item outcome retaining exactly one legacy or Workflow payload."""

    result: DocumentAnalysisResult | DocumentWorkflowIntakeResult | None = None

    @field_validator("result", mode="before")
    @classmethod
    def accept_result_json(cls, value: object) -> object:
        """Rebuild exactly one supported result shape from public JSON."""
        if type(value) is not dict:
            return value
        payload = json.dumps(
            value,
            allow_nan=False,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        )
        if "contract_version" in value and "status" in value:
            return DocumentWorkflowIntakeResult.model_validate_json(payload)
        return DocumentAnalysisResult.model_validate_json(payload)

    @model_validator(mode="after")
    def _result_by_status(self) -> BatchItemResult:
        if type(self.result) is DocumentWorkflowIntakeResult:
            result = DocumentWorkflowIntakeResult.model_validate_json(
                self.result.model_dump_json()
            )
            object.__setattr__(self, "result", result)
            workflow = result.workflow_result
            expected_issues = tuple(
                BatchItemIssue(
                    code=issue.code,
                    category=issue.category.value,
                    message=issue.message,
                )
                for issue in (result.issues if workflow is None else workflow.issues)
            )
            expected_fingerprint = _workflow_intake_result_fingerprint(result)
            expected_status = {
                DocumentWorkflowIntakeStatus.SUCCEEDED: BatchItemStatus.SUCCEEDED,
                DocumentWorkflowIntakeStatus.PARTIAL: BatchItemStatus.SUCCEEDED,
                DocumentWorkflowIntakeStatus.REVIEW_REQUIRED: (
                    BatchItemStatus.SUCCEEDED
                ),
                DocumentWorkflowIntakeStatus.UNSUPPORTED: (
                    BatchItemStatus.SKIPPED_UNSUPPORTED
                ),
                DocumentWorkflowIntakeStatus.REJECTED: BatchItemStatus.FAILED,
                DocumentWorkflowIntakeStatus.FAILED: BatchItemStatus.FAILED,
            }[result.status]
            current_usage = (
                () if workflow is None else workflow.usage.current_provider_usage
            )
            retained_usage = (
                () if workflow is None else workflow.usage.retained_provider_usage
            )
            current_attempts = (
                () if workflow is None else workflow.usage.current_cloud_attempts
            )
            retained_attempts = (
                () if workflow is None else workflow.usage.retained_cloud_attempts
            )
            expected_quality = (
                None
                if workflow is None
                else workflow.manifest.local_ocr_quality_summary
            )
            expected_preprocessing = _workflow_preprocessing_summary(result)
            planned = workflow is not None
            expected_performed = _workflow_intake_operations() if planned else ()
            expected_provider = (
                (OperationCount(name="workflow_provider_analysis", count=1),)
                if current_usage or current_attempts
                else ()
            )
            if (
                self.intake_status is not result.status
                or self.status is not expected_status
                or self.result_fingerprint != expected_fingerprint
                or self.issues != expected_issues
                or self.performed_operation_counts != expected_performed
                or self.provider_operation_counts != expected_provider
                or self.provider_usage is not None
                or self.provider_usage_breakdown != current_usage
                or self.retained_provider_usage != retained_usage
                or self.cloud_execution_attempts != current_attempts
                or self.retained_cloud_execution_attempts != retained_attempts
                or self.local_ocr_quality_summary != expected_quality
                or self.local_ocr_preprocessing_summary != expected_preprocessing
                or self.azure_fallback_summary is not None
                or self.azure_fallback_attempt is not None
                or self.retained_azure_fallback_attempts
            ):
                raise ValueError("Workflow intake item result evidence is inconsistent")
            if workflow is None:
                if any(
                    value is not None
                    for value in (
                        self.source_sha256,
                        self.document_type,
                        self.document_format,
                        self.pdf_page_count,
                        self.excel_worksheet_count,
                        self.image_frame_count,
                        self.docx_block_count,
                    )
                ):
                    raise ValueError("Pre-Plan Workflow intake has fabricated identity")
            elif (
                self.source_sha256 != workflow.source.sha256
                or self.byte_size != workflow.source.byte_size
                or self.document_type is not workflow.detected_document_type
                or self.document_format is not workflow.detected_document_format
            ):
                raise ValueError("Workflow intake source evidence is inconsistent")
            return self
        if self.status is BatchItemStatus.SUCCEEDED:
            if type(self.result) is not DocumentAnalysisResult:
                raise ValueError("succeeded item requires a complete result")
            envelope = self.result.envelope
            inspection = self.result.inspection
            expected_provider_counts = (
                (OperationCount(name="provider_analysis", count=1),)
                if self.result.provider_usage is not None
                else ()
            )
            if (
                self.source_sha256 != envelope.sha256
                or self.byte_size != envelope.byte_size
                or self.document_type is not envelope.document_type
                or self.document_format is not envelope.document_format
                or self.pdf_page_count != inspection.pdf_page_count
                or self.excel_worksheet_count != inspection.excel_worksheet_count
                or self.image_frame_count != inspection.image_frame_count
                or self.docx_block_count != inspection.docx_block_count
                or self.result_fingerprint
                != _canonical_document_result_fingerprint(self.result)
                or self.performed_operation_counts
                != self.result.processing_manifest.operation_counts
                or self.provider_operation_counts != expected_provider_counts
                or self.provider_usage != self.result.provider_usage
                or self.cloud_execution_attempts != self.result.cloud_execution_attempts
                or self.local_ocr_quality_summary
                != self.result.processing_manifest.local_ocr_quality_summary
                or self.local_ocr_preprocessing_summary
                != self.result.processing_manifest.local_ocr_preprocessing_summary
                or self.provider_usage_breakdown != self.result.provider_usage_breakdown
                or self.azure_fallback_summary != self.result.azure_fallback_report
                or self.azure_fallback_summary
                != self.result.processing_manifest.azure_fallback_summary
                or self.provider_usage_breakdown
                != self.result.processing_manifest.provider_usage_breakdown
            ):
                raise ValueError("succeeded item result evidence is inconsistent")
        elif self.result is not None:
            raise ValueError("non-succeeded item cannot contain a full result")
        return self


class BatchManifestItem(_BatchEvidence):
    """Content-free resume evidence for one prior input."""


def _count_map(counts: tuple[OperationCount, ...]) -> dict[str, int]:
    return {item.name: item.count for item in counts}


def _aggregate_counts(
    items: tuple[_BatchEvidence, ...],
    field: Literal[
        "performed_operation_counts",
        "retained_prior_operation_counts",
        "provider_operation_counts",
    ],
) -> tuple[OperationCount, ...]:
    totals: dict[str, int] = {}
    for item in items:
        for count in getattr(item, field):
            totals[count.name] = totals.get(count.name, 0) + count.count
    return tuple(
        OperationCount(name=name, count=totals[name]) for name in sorted(totals)
    )


def _provider_usage_totals(
    items: tuple[_BatchEvidence, ...],
) -> ProviderUsageTotals:
    """Aggregate each item's one current-or-retained safe usage projection once."""
    cloud_fields = {
        "cloud_logical_operation_count",
        "cloud_submitted_operation_count",
        "cloud_paid_or_possibly_paid_operation_count",
        "cloud_transport_retry_count",
    }
    field_names = tuple(ProviderUsageTotals.model_fields)
    direct_usage_fields = tuple(
        name for name in field_names if name not in cloud_fields
    )
    totals = dict.fromkeys(field_names, 0)
    cloud_logical_keys: set[tuple[object, ...]] = set()
    for item in items:
        for usage in _item_provider_usages(item):
            for name in direct_usage_fields:
                totals[name] += getattr(usage, name)
        cloud_attempts = _item_cloud_execution_attempts(item)
        cloud_logical_keys.update(
            _cloud_logical_operation_key(item.input_id, attempt)
            for attempt in cloud_attempts
        )
        for attempt in cloud_attempts:
            totals["cloud_submitted_operation_count"] += (
                attempt.submitted_operation_count
            )
            totals["cloud_paid_or_possibly_paid_operation_count"] += (
                attempt.paid_or_possibly_paid_operation_count
            )
            totals["cloud_transport_retry_count"] += attempt.transport_retry_count
    totals["cloud_logical_operation_count"] = len(cloud_logical_keys)
    return ProviderUsageTotals(**totals)


def _item_provider_usages(item: _BatchEvidence) -> tuple[ProviderUsage, ...]:
    """Return actual retained/current Usage once; duplicates consume nothing."""
    if item.status is BatchItemStatus.DUPLICATE:
        return ()
    current = item.provider_usage_breakdown or (
        () if item.provider_usage is None else (item.provider_usage,)
    )
    return item.retained_provider_usage + current


def _item_cloud_execution_attempts(
    item: _BatchEvidence,
) -> tuple[CloudExecutionAttemptEvidence, ...]:
    """Return retained and current cloud attempts without duplicate projections."""
    if item.status is BatchItemStatus.DUPLICATE:
        return ()
    fallback_attempts = item.retained_azure_fallback_attempts + (
        () if item.azure_fallback_attempt is None else (item.azure_fallback_attempt,)
    )
    nested = tuple(
        cloud_attempt
        for attempt in fallback_attempts
        for cloud_attempt in attempt.completed_cloud_execution_attempts
        + (
            ()
            if attempt.current_cloud_execution_attempt is None
            else (attempt.current_cloud_execution_attempt,)
        )
    )
    return (
        item.retained_cloud_execution_attempts + item.cloud_execution_attempts + nested
    )


def _local_ocr_quality_aggregate(
    items: tuple[_BatchEvidence, ...],
) -> BatchLocalOcrQualityAggregate:
    """Aggregate each item quality projection exactly once."""
    evaluated = passed = failed = not_applicable = 0
    retry_pages = retry_frames = 0
    issue_counts: dict[LocalOcrQualityIssueCode, int] = {}
    for item in items:
        summary = item.local_ocr_quality_summary
        if summary is None:
            continue
        if summary.decision is LocalOcrQualityDecision.NOT_APPLICABLE:
            not_applicable += 1
        else:
            evaluated += 1
            if summary.decision is LocalOcrQualityDecision.PASS:
                passed += 1
            else:
                failed += 1
        for issue in summary.issue_counts_by_code:
            issue_counts[issue.code] = issue_counts.get(issue.code, 0) + 1
        retry_pages += len(summary.recommended_retry_pages)
        retry_frames += len(summary.recommended_retry_frames)
    return BatchLocalOcrQualityAggregate(
        quality_evaluated_item_count=evaluated,
        quality_passed_item_count=passed,
        quality_failed_item_count=failed,
        quality_not_applicable_item_count=not_applicable,
        quality_issue_counts=tuple(
            LocalOcrQualityIssueCount(code=code, count=issue_counts[code])
            for code in LocalOcrQualityIssueCode
            if code in issue_counts
        ),
        recommended_retry_page_count=retry_pages,
        recommended_retry_frame_count=retry_frames,
    )


def _local_ocr_preprocessing_aggregate(
    items: tuple[_BatchEvidence, ...],
) -> BatchLocalOcrPreprocessingAggregate | None:
    """Recompute preprocessing outcomes and resources without duplicate work."""
    summaries = tuple(
        item.local_ocr_preprocessing_summary
        for item in items
        if item.status is not BatchItemStatus.DUPLICATE
        and item.local_ocr_preprocessing_summary is not None
    )
    failed_items = tuple(
        item
        for item in items
        if item.status is not BatchItemStatus.DUPLICATE
        and item.local_ocr_preprocessing_summary is None
        and any(
            usage.local_preprocessing_attempt_count
            for usage in _item_provider_usages(item)
        )
    )
    if not summaries and not failed_items:
        return None
    profile_counts: Counter[LocalOcrPreprocessingProfile] = Counter()
    for summary in summaries:
        for count in summary.selected_profile_counts:
            profile_counts[count.profile] += count.count
    usages = tuple(usage for item in items for usage in _item_provider_usages(item))
    return BatchLocalOcrPreprocessingAggregate(
        evaluated_item_count=len(summaries),
        not_needed_item_count=sum(
            item.preprocessing_attempted_input_count == 0 for item in summaries
        ),
        preprocessing_attempted_item_count=sum(
            item.preprocessing_attempted_input_count > 0 for item in summaries
        ),
        improved_item_count=sum(item.improved_input_count > 0 for item in summaries),
        pass_after_preprocessing_item_count=sum(
            item.pass_after_preprocessing_input_count > 0 for item in summaries
        ),
        still_failed_item_count=sum(
            item.still_failed_input_count > 0 for item in summaries
        ),
        failed_item_count=len(failed_items),
        page_count=sum(item.source_page_count for item in summaries),
        frame_count=sum(item.source_frame_count for item in summaries),
        attempt_count=sum(usage.local_preprocessing_attempt_count for usage in usages),
        preprocessing_pixel_count=sum(
            usage.local_preprocessing_pixel_count for usage in usages
        ),
        extra_operation_count=sum(
            usage.local_preprocessing_operation_count for usage in usages
        ),
        selected_profile_counts=tuple(
            LocalOcrPreprocessingProfileCount(
                profile=profile, count=profile_counts[profile]
            )
            for profile in LocalOcrPreprocessingProfile
            if profile_counts[profile]
        ),
        safe_failure_counts=(
            ()
            if not failed_items
            else (OperationCount(name="preprocessing_failed", count=len(failed_items)),)
        ),
    )


def _preprocessing_resources_match_usage(
    aggregate: BatchLocalOcrPreprocessingAggregate | None,
    usage: ProviderUsageTotals,
) -> bool:
    """Cross-check durable preprocessing resources against exact safe Usage."""
    expected = (
        usage.local_preprocessing_attempt_count,
        usage.local_preprocessing_pixel_count,
        usage.local_preprocessing_operation_count,
    )
    if aggregate is None:
        return expected == (0, 0, 0)
    return (
        aggregate.attempt_count,
        aggregate.preprocessing_pixel_count,
        aggregate.extra_operation_count,
    ) == expected


def _azure_fallback_aggregate(
    items: tuple[_BatchEvidence, ...],
) -> BatchAzureFallbackAggregate:
    evaluated = not_needed = completed = unresolved = failed = 0
    pages = frames = invocations = azure = paid = payloads = payload_bytes = 0
    reasons: dict[LocalOcrQualityIssueCode, int] = {}
    for item in items:
        if item.status is BatchItemStatus.DUPLICATE:
            continue
        summary = item.azure_fallback_summary
        attempts = item.retained_azure_fallback_attempts + (
            ()
            if item.azure_fallback_attempt is None
            else (item.azure_fallback_attempt,)
        )
        item_reasons: set[LocalOcrQualityIssueCode] = set()
        if summary is not None:
            evaluated += 1
            if summary.status is AzurePageFallbackStatus.NOT_APPLICABLE:
                not_needed += 1
            elif summary.status is AzurePageFallbackStatus.COMPLETED:
                completed += 1
            else:
                unresolved += 1
            pages += len(summary.submitted_pages)
            frames += len(summary.submitted_frames)
            invocations += summary.provider_invocation_count
            azure += summary.azure_operation_count
            paid += summary.paid_page_count + summary.paid_frame_count
            payloads += summary.payload_count
            payload_bytes += summary.payload_byte_count
            item_reasons.update(summary.reason_codes)
        elif attempts:
            evaluated += 1
            failed += 1
            for attempt in attempts:
                item_reasons.update(attempt.trigger_quality_summary.reason_codes)
        for attempt in attempts:
            pages += len(attempt.prepared_pages)
            frames += len(attempt.prepared_frames)
            invocations += attempt.provider_invocation_count
            usages = attempt.completed_azure_usages + (
                ()
                if attempt.current_attempt_usage is None
                else (attempt.current_attempt_usage,)
            )
            azure += sum(usage.azure_operation_count for usage in usages)
            paid += sum(usage.paid_operation_count for usage in usages)
            payloads += attempt.payload_count
            payload_bytes += attempt.payload_byte_count
        for reason in item_reasons:
            reasons[reason] = reasons.get(reason, 0) + 1
    return BatchAzureFallbackAggregate(
        evaluated=evaluated,
        not_needed=not_needed,
        completed=completed,
        unresolved=unresolved,
        failed=failed,
        page_count=pages,
        frame_count=frames,
        provider_invocation_count=invocations,
        confirmed_azure_operation_count=azure,
        confirmed_paid_operation_count=paid,
        payload_count=payloads,
        payload_byte_count=payload_bytes,
        reason_counts=tuple(
            LocalOcrQualityIssueCount(code=code, count=reasons[code])
            for code in sorted(reasons, key=lambda item: item.value)
        ),
    )


def _status_counts(items: tuple[_BatchEvidence, ...]) -> tuple[OperationCount, ...]:
    totals: dict[str, int] = {}
    for item in items:
        totals[item.status.value] = totals.get(item.status.value, 0) + 1
    return tuple(
        OperationCount(name=name, count=totals[name]) for name in sorted(totals)
    )


def _consumed_input_bytes(items: tuple[_BatchEvidence, ...]) -> int:
    return sum(item.consumed_input_bytes for item in items)


def _item_fingerprint_payload(
    item: BatchManifestItem,
    *,
    include_local_ocr_quality: bool,
    include_local_ocr_preprocessing: bool,
) -> dict[str, Any]:
    excluded: dict[str, bool] = {}
    if not include_local_ocr_quality:
        excluded["local_ocr_quality_summary"] = True
    if not include_local_ocr_preprocessing:
        excluded["local_ocr_preprocessing_summary"] = True
    return item.model_dump(
        mode="json",
        exclude=excluded or None,
    )


def compute_batch_fingerprint(
    *,
    sdk_version: str,
    processing_options_fingerprint: str,
    schema_id: str | None,
    schema_version: str | None,
    schema_fingerprint: str | None,
    provider_profile_id: str | None,
    items: tuple[BatchManifestItem, ...],
    status_counts: tuple[OperationCount, ...],
    performed_operation_counts: tuple[OperationCount, ...],
    retained_prior_operation_counts: tuple[OperationCount, ...],
    provider_operation_counts: tuple[OperationCount, ...],
    provider_usage_totals: ProviderUsageTotals,
    local_ocr_quality_aggregate: BatchLocalOcrQualityAggregate,
    local_ocr_preprocessing_aggregate: BatchLocalOcrPreprocessingAggregate | None,
    azure_fallback_aggregate: BatchAzureFallbackAggregate,
    consumed_input_bytes: int,
) -> str:
    """Compute the canonical safe fingerprint for one manifest."""
    include_local_ocr_quality = any(
        item.local_ocr_quality_summary is not None for item in items
    )
    include_local_ocr_preprocessing = local_ocr_preprocessing_aggregate is not None
    payload = {
        "manifest_version": "3",
        "sdk_version": sdk_version,
        "processing_options_fingerprint": processing_options_fingerprint,
        "schema_id": schema_id,
        "schema_version": schema_version,
        "schema_fingerprint": schema_fingerprint,
        "provider_profile_id": provider_profile_id,
        "items": [
            _item_fingerprint_payload(
                item,
                include_local_ocr_quality=include_local_ocr_quality,
                include_local_ocr_preprocessing=include_local_ocr_preprocessing,
            )
            for item in items
        ],
        "status_counts": [count.model_dump(mode="json") for count in status_counts],
        "performed_operation_counts": [
            count.model_dump(mode="json") for count in performed_operation_counts
        ],
        "retained_prior_operation_counts": [
            count.model_dump(mode="json") for count in retained_prior_operation_counts
        ],
        "provider_operation_counts": [
            count.model_dump(mode="json") for count in provider_operation_counts
        ],
        "provider_usage_totals": provider_usage_totals.model_dump(mode="json"),
        "consumed_input_bytes": consumed_input_bytes,
    }
    if include_local_ocr_quality:
        payload["local_ocr_quality_aggregate"] = local_ocr_quality_aggregate.model_dump(
            mode="json"
        )
    if local_ocr_preprocessing_aggregate is not None:
        payload["local_ocr_preprocessing_aggregate"] = (
            local_ocr_preprocessing_aggregate.model_dump(mode="json")
        )
    payload["azure_fallback_aggregate"] = azure_fallback_aggregate.model_dump(
        mode="json"
    )
    return hashlib.sha256(
        json.dumps(
            payload,
            sort_keys=True,
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode()
    ).hexdigest()


class BatchProcessingManifest(_PublicModel):
    """Serializable safe batch evidence used for compatible resume."""

    model_config = _StrictModel

    manifest_version: Literal["3"] = "3"
    sdk_version: NonEmptyString
    batch_fingerprint: Sha256
    processing_options_fingerprint: Sha256
    schema_id: str | None = None
    schema_version: str | None = None
    schema_fingerprint: Sha256 | None = None
    provider_profile_id: str | None = None
    items: tuple[BatchManifestItem, ...]
    status_counts: tuple[OperationCount, ...] = ()
    performed_operation_counts: tuple[OperationCount, ...] = ()
    retained_prior_operation_counts: tuple[OperationCount, ...] = ()
    provider_operation_counts: tuple[OperationCount, ...] = ()
    provider_usage_totals: ProviderUsageTotals = Field(
        default_factory=ProviderUsageTotals
    )
    local_ocr_quality_aggregate: BatchLocalOcrQualityAggregate = Field(
        default_factory=BatchLocalOcrQualityAggregate
    )
    local_ocr_preprocessing_aggregate: BatchLocalOcrPreprocessingAggregate | None = None
    azure_fallback_aggregate: BatchAzureFallbackAggregate = Field(
        default_factory=BatchAzureFallbackAggregate
    )
    consumed_input_bytes: Annotated[int, Field(strict=True, ge=0)] = 0

    @model_validator(mode="after")
    def _integrity(self) -> BatchProcessingManifest:
        usage_totals = _revalidate_model_instance_json(
            self.provider_usage_totals,
            ProviderUsageTotals,
            "Provider usage totals are invalid",
        )
        object.__setattr__(self, "provider_usage_totals", usage_totals)
        ids = tuple(item.input_id for item in self.items)
        names = tuple(item.relative_name for item in self.items)
        if len(ids) != len(set(ids)):
            raise ValueError("manifest input IDs must be unique")
        if len(names) != len(set(names)):
            raise ValueError("manifest relative names must be unique")
        expected_order = tuple(
            sorted(
                self.items,
                key=lambda item: (
                    item.relative_name.casefold(),
                    item.relative_name,
                    item.input_id,
                ),
            )
        )
        if self.items != expected_order:
            raise ValueError("manifest items must use canonical ordering")
        prior_by_id: dict[str, BatchManifestItem] = {}
        for item in self.items:
            if item.status is BatchItemStatus.DUPLICATE:
                target = prior_by_id.get(item.duplicate_of or "")
                target_operations = (
                    frozenset()
                    if target is None
                    else _operation_names(target.performed_operation_counts)
                    | _operation_names(target.retained_prior_operation_counts)
                )
                if (
                    target is None
                    or target.status is BatchItemStatus.DUPLICATE
                    or "inspection" not in target_operations
                    or not _family_count(
                        target.document_type,
                        target.pdf_page_count,
                        target.excel_worksheet_count,
                        target.image_frame_count,
                        target.docx_block_count,
                    )
                    or target.source_sha256 != item.source_sha256
                    or target.byte_size != item.byte_size
                    or target.document_type is not item.document_type
                    or target.document_format is not item.document_format
                    or target.pdf_page_count != item.pdf_page_count
                    or target.excel_worksheet_count != item.excel_worksheet_count
                    or target.image_frame_count != item.image_frame_count
                    or target.docx_block_count != item.docx_block_count
                    or target.local_ocr_quality_summary
                    != item.local_ocr_quality_summary
                    or target.local_ocr_preprocessing_summary
                    != item.local_ocr_preprocessing_summary
                    or target.azure_fallback_summary != item.azure_fallback_summary
                ):
                    raise ValueError("duplicate target evidence is inconsistent")
            prior_by_id[item.input_id] = item
        schema_values = (
            self.schema_id,
            self.schema_version,
            self.schema_fingerprint,
        )
        if any(value is None for value in schema_values) and any(
            value is not None for value in schema_values
        ):
            raise ValueError("schema projections must be all present or absent")
        expected_status = _status_counts(self.items)
        expected_performed = _aggregate_counts(self.items, "performed_operation_counts")
        expected_retained = _aggregate_counts(
            self.items, "retained_prior_operation_counts"
        )
        expected_provider = _aggregate_counts(self.items, "provider_operation_counts")
        expected_usage = _provider_usage_totals(self.items)
        expected_quality = _local_ocr_quality_aggregate(self.items)
        expected_preprocessing = _local_ocr_preprocessing_aggregate(self.items)
        expected_fallback = _azure_fallback_aggregate(self.items)
        expected_consumed = _consumed_input_bytes(self.items)
        if (
            self.status_counts != expected_status
            or self.performed_operation_counts != expected_performed
            or self.retained_prior_operation_counts != expected_retained
            or self.provider_operation_counts != expected_provider
            or self.provider_usage_totals != expected_usage
            or self.local_ocr_quality_aggregate != expected_quality
            or self.local_ocr_preprocessing_aggregate != expected_preprocessing
            or not _preprocessing_resources_match_usage(
                self.local_ocr_preprocessing_aggregate,
                self.provider_usage_totals,
            )
            or self.azure_fallback_aggregate != expected_fallback
            or self.consumed_input_bytes != expected_consumed
        ):
            raise ValueError("manifest aggregate counts are inconsistent")
        expected_fingerprint = compute_batch_fingerprint(
            sdk_version=self.sdk_version,
            processing_options_fingerprint=self.processing_options_fingerprint,
            schema_id=self.schema_id,
            schema_version=self.schema_version,
            schema_fingerprint=self.schema_fingerprint,
            provider_profile_id=self.provider_profile_id,
            items=self.items,
            status_counts=self.status_counts,
            performed_operation_counts=self.performed_operation_counts,
            retained_prior_operation_counts=self.retained_prior_operation_counts,
            provider_operation_counts=self.provider_operation_counts,
            provider_usage_totals=self.provider_usage_totals,
            local_ocr_quality_aggregate=self.local_ocr_quality_aggregate,
            local_ocr_preprocessing_aggregate=(self.local_ocr_preprocessing_aggregate),
            azure_fallback_aggregate=self.azure_fallback_aggregate,
            consumed_input_bytes=self.consumed_input_bytes,
        )
        if self.batch_fingerprint != expected_fingerprint:
            raise ValueError("batch fingerprint is invalid")
        return self


class BatchProcessingResult(_PublicModel):
    """Complete deterministic batch outcome and its resumable safe manifest."""

    model_config = _StrictModel

    items: tuple[BatchItemResult, ...]
    manifest: BatchProcessingManifest
    status_counts: tuple[OperationCount, ...] = ()
    performed_operation_counts: tuple[OperationCount, ...] = ()
    retained_prior_operation_counts: tuple[OperationCount, ...] = ()
    provider_operation_counts: tuple[OperationCount, ...] = ()
    provider_usage_totals: ProviderUsageTotals = Field(
        default_factory=ProviderUsageTotals
    )
    local_ocr_quality_aggregate: BatchLocalOcrQualityAggregate = Field(
        default_factory=BatchLocalOcrQualityAggregate
    )
    local_ocr_preprocessing_aggregate: BatchLocalOcrPreprocessingAggregate | None = None
    azure_fallback_aggregate: BatchAzureFallbackAggregate = Field(
        default_factory=BatchAzureFallbackAggregate
    )
    consumed_input_bytes: Annotated[int, Field(strict=True, ge=0)] = 0

    @model_validator(mode="after")
    def _consistent_result(self) -> BatchProcessingResult:
        usage_totals = _revalidate_model_instance_json(
            self.provider_usage_totals,
            ProviderUsageTotals,
            "Provider usage totals are invalid",
        )
        object.__setattr__(self, "provider_usage_totals", usage_totals)
        if len(self.items) != len(self.manifest.items):
            raise ValueError("batch result and manifest item counts differ")
        for result, manifest in zip(
            self.items,
            self.manifest.items,
            strict=True,
        ):
            result_evidence = result.model_dump(mode="json", exclude={"result"})
            manifest_evidence = manifest.model_dump(mode="json")
            if result_evidence != manifest_evidence:
                raise ValueError("batch result and manifest item evidence differ")
        expected_status = _status_counts(self.items)
        expected_performed = _aggregate_counts(self.items, "performed_operation_counts")
        expected_retained = _aggregate_counts(
            self.items, "retained_prior_operation_counts"
        )
        expected_provider = _aggregate_counts(self.items, "provider_operation_counts")
        expected_usage = _provider_usage_totals(self.items)
        expected_quality = _local_ocr_quality_aggregate(self.items)
        expected_preprocessing = _local_ocr_preprocessing_aggregate(self.items)
        expected_fallback = _azure_fallback_aggregate(self.items)
        expected_consumed = _consumed_input_bytes(self.items)
        if (
            self.status_counts != expected_status
            or self.performed_operation_counts != expected_performed
            or self.retained_prior_operation_counts != expected_retained
            or self.provider_operation_counts != expected_provider
            or self.provider_usage_totals != expected_usage
            or self.local_ocr_quality_aggregate != expected_quality
            or self.local_ocr_preprocessing_aggregate != expected_preprocessing
            or not _preprocessing_resources_match_usage(
                self.local_ocr_preprocessing_aggregate,
                self.provider_usage_totals,
            )
            or self.azure_fallback_aggregate != expected_fallback
            or self.manifest.status_counts != self.status_counts
            or self.manifest.performed_operation_counts
            != self.performed_operation_counts
            or self.manifest.retained_prior_operation_counts
            != self.retained_prior_operation_counts
            or self.manifest.provider_operation_counts != self.provider_operation_counts
            or self.manifest.provider_usage_totals != self.provider_usage_totals
            or self.manifest.local_ocr_quality_aggregate
            != self.local_ocr_quality_aggregate
            or self.manifest.local_ocr_preprocessing_aggregate
            != self.local_ocr_preprocessing_aggregate
            or self.manifest.azure_fallback_aggregate != self.azure_fallback_aggregate
            or self.consumed_input_bytes != expected_consumed
            or self.manifest.consumed_input_bytes != self.consumed_input_bytes
        ):
            raise ValueError("batch result aggregate counts are inconsistent")
        return self

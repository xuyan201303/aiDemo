"""Provider-independent deterministic batch processing."""

from document_sdk.batch.errors import (
    BatchConfigurationError,
    BatchManifestError,
    BatchProcessingLimitError,
    BatchResultValidationError,
)
from document_sdk.batch.models import (
    BatchAzureFallbackAggregate,
    BatchDocumentInput,
    BatchItemIssue,
    BatchItemResult,
    BatchItemStatus,
    BatchLocalOcrPreprocessingAggregate,
    BatchLocalOcrQualityAggregate,
    BatchManifestItem,
    BatchProcessingLimits,
    BatchProcessingManifest,
    BatchProcessingOptions,
    BatchProcessingResult,
)
from document_sdk.batch.processing import (
    discover_documents,
    load_batch_manifest,
    process_batch,
    save_batch_manifest,
)

__all__ = [
    "BatchAzureFallbackAggregate",
    "BatchConfigurationError",
    "BatchDocumentInput",
    "BatchItemIssue",
    "BatchItemResult",
    "BatchItemStatus",
    "BatchLocalOcrPreprocessingAggregate",
    "BatchLocalOcrQualityAggregate",
    "BatchManifestError",
    "BatchManifestItem",
    "BatchProcessingLimitError",
    "BatchProcessingLimits",
    "BatchProcessingManifest",
    "BatchProcessingOptions",
    "BatchProcessingResult",
    "BatchResultValidationError",
    "discover_documents",
    "load_batch_manifest",
    "process_batch",
    "save_batch_manifest",
]

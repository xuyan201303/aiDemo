"""Sanitized errors for batch document processing."""

from document_sdk.core import DocumentSdkError


class BatchConfigurationError(DocumentSdkError):
    """Raised for invalid global batch configuration."""


class BatchProcessingLimitError(DocumentSdkError):
    """Raised when discovery cannot remain inside a global safety limit."""


class BatchResultValidationError(DocumentSdkError):
    """Raised when public Batch evidence is inconsistent."""


class BatchManifestError(DocumentSdkError):
    """Raised when a persisted manifest is invalid or incompatible."""

"""Caller-visible document pipeline errors."""

from document_sdk.core import DocumentProcessingError


class OcrProviderRequiredError(DocumentProcessingError):
    """Raised when OCR-candidate PDF pages require an explicit Provider."""

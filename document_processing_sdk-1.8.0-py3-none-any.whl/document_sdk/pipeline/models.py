"""Strict public options for document analysis pipelines."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, field_validator

from document_sdk.ocr.models import DocumentAnalysisFeature  # noqa: TC001


class HybridPdfAnalysisOptions(BaseModel):
    """Provider-neutral options for local-first hybrid PDF analysis."""

    model_config = ConfigDict(
        extra="forbid",
        frozen=True,
        hide_input_in_errors=True,
        strict=True,
    )

    locale: str | None = None
    features: tuple[DocumentAnalysisFeature, ...] = ()

    @field_validator("locale")
    @classmethod
    def normalize_locale(cls, value: str | None) -> str | None:
        """Normalize a non-empty OCR locale hint."""
        if value is None:
            return None
        normalized = value.strip()
        if not normalized:
            msg = "Hybrid PDF locale must not be blank"
            raise ValueError(msg)
        return normalized

    @field_validator("features")
    @classmethod
    def normalize_features(
        cls,
        value: tuple[DocumentAnalysisFeature, ...],
    ) -> tuple[DocumentAnalysisFeature, ...]:
        """Store explicit optional features uniquely and deterministically."""
        return tuple(sorted(set(value), key=lambda feature: feature.value))

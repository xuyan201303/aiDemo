"""Local native PDF text plus explicitly selected OCR page analysis."""

from __future__ import annotations

from dataclasses import dataclass
from time import perf_counter
from typing import TYPE_CHECKING, Never, cast

from document_sdk.core import (
    CloudExecutionAttemptEvidence,
    Document,
    DocumentContentScope,
    DocumentPage,
    DocumentProcessingError,
    DocumentSpan,
    FileDescriptor,
    LocalOcrIntrinsicQualityPolicy,
    PdfSourceReference,
    ProcessingError,
    ProcessingMetadata,
    ProcessingResult,
    ProcessingWarning,
    ProviderUsage,
)
from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.core.local_ocr_quality import (
    _validate_local_ocr_provider_quality_result,
    _validate_provider_usage,
)
from document_sdk.ocr import DocumentAnalysisFeature, OcrAnalysisOptions
from document_sdk.ocr._provider_boundary import (
    _invoke_ocr_provider_safely,
    _LocalOcrInvocationState,
    _read_provider_identity_safely,
)
from document_sdk.pdf import PdfProcessingLimits, extract_native_text, inspect_pdf
from document_sdk.pdf._validation import _validated_pdf_limits
from document_sdk.pipeline.errors import OcrProviderRequiredError
from document_sdk.pipeline.models import HybridPdfAnalysisOptions

if TYPE_CHECKING:
    from pathlib import Path

    from pydantic import JsonValue

    from document_sdk.core import (
        LocalOcrQualityReport,
        PdfInspection,
        PdfPageInspection,
        SourceReference,
    )
    from document_sdk.ocr import OcrProvider
    from document_sdk.ocr.preprocessing_models import LocalOcrPreprocessingReport

_PIPELINE_NAME = "hybrid_pdf_local_native_plus_explicit_ocr"


@dataclass(frozen=True, slots=True)
class _OcrFacts:
    pages: dict[int, DocumentPage]
    document: Document | None
    warnings: tuple[ProcessingWarning, ...]
    errors: tuple[ProcessingError, ...]
    provider_name: str | None
    profile_id: str | None
    model_id: str | None
    usage: ProviderUsage | None
    cloud_execution_attempt: CloudExecutionAttemptEvidence | None
    quality_report: LocalOcrQualityReport | None
    preprocessing_report: LocalOcrPreprocessingReport | None


@dataclass(frozen=True, slots=True)
class _ProviderIdentity:
    provider_name: str
    profile_id: str
    model_id: str | None


def _fail(message: str) -> Never:
    """Raise one controlled, content-free merge failure."""
    raise DocumentProcessingError(message)


def _validated_options(
    options: HybridPdfAnalysisOptions | None,
) -> HybridPdfAnalysisOptions:
    """Return strict pipeline options before any document processing."""
    if options is None:
        return HybridPdfAnalysisOptions()
    try:
        return _revalidate_model_instance_json(
            options,
            HybridPdfAnalysisOptions,
            "Hybrid PDF options are invalid",
        )
    except Exception as exc:  # noqa: BLE001 - public input is untrusted.
        msg = "Hybrid PDF options are invalid"
        _raise_redacted_translation(exc, DocumentProcessingError(msg))


def _provider_context_identity(provider: OcrProvider) -> _ProviderIdentity:
    """Read only immutable, non-secret Provider identity metadata."""
    provider_name, profile_id, model_id = _read_provider_identity_safely(
        provider,
        error=DocumentProcessingError(
            "Hybrid PDF OCR Provider Context metadata is invalid"
        ),
    )
    return _ProviderIdentity(
        provider_name=provider_name,
        profile_id=profile_id,
        model_id=model_id,
    )


def _validate_result_provider_identity(
    result: ProcessingResult[Document],
    *,
    expected: _ProviderIdentity,
) -> None:
    """Require normalized OCR metadata to match its owning Context exactly."""
    try:
        metadata = result.metadata
        matches = (
            metadata.provider_name == expected.provider_name
            and metadata.profile_id == expected.profile_id
            and metadata.model_id == expected.model_id
        )
    except Exception as exc:  # noqa: BLE001 - provider boundary is redacted.
        msg = "Hybrid PDF OCR Provider result metadata is unavailable"
        _raise_redacted_translation(exc, DocumentProcessingError(msg))
    if not matches:
        _fail("Hybrid PDF OCR Provider result identity is inconsistent")


def _validated_provider_usage(
    result: ProcessingResult[Document],
    *,
    identity: _ProviderIdentity,
    pages: frozenset[int],
    requested_features: tuple[str, ...],
) -> ProviderUsage:
    """Validate safe Provider usage against the actual hybrid OCR request."""
    try:
        usage = _validate_provider_usage(result.metadata.provider_usage)
    except Exception as exc:  # noqa: BLE001 - provider boundary is redacted.
        msg = "Hybrid PDF OCR Provider usage is unavailable"
        _raise_redacted_translation(exc, DocumentProcessingError(msg))
    if usage is None:
        _fail("Hybrid PDF OCR Provider usage is missing")
    expected_pages = tuple(sorted(pages))
    if (
        usage.provider_name != identity.provider_name
        or usage.profile_id != identity.profile_id
        or usage.model_id != identity.model_id
        or usage.submitted_pages != expected_pages
        or usage.returned_pages != expected_pages
        or usage.requested_features != tuple(sorted(requested_features))
        or usage.query_field_count != 0
    ):
        _fail("Hybrid PDF OCR Provider usage is inconsistent")
    return usage


def _validate_descriptor(
    actual: FileDescriptor,
    *,
    expected: FileDescriptor,
    origin: str,
) -> None:
    """Require logical and byte identity without exposing either value."""
    if actual.file_id != expected.file_id:
        _fail(f"Hybrid PDF {origin} logical file identity is inconsistent")
    if actual.fingerprint != expected.fingerprint:
        _fail(f"Hybrid PDF {origin} fingerprint is inconsistent")
    if actual.size_bytes != expected.size_bytes:
        _fail(f"Hybrid PDF {origin} byte size is inconsistent")


def _validate_pdf_source(
    source: SourceReference,
    *,
    file_id: str,
    page_number: int,
    origin: str,
) -> None:
    """Require one source to identify its owning original PDF page."""
    if (
        not isinstance(source, PdfSourceReference)
        or source.file_id != file_id
        or source.page_number != page_number
    ):
        _fail(f"Hybrid PDF {origin} source is inconsistent")


def _validate_page_sources(
    page: DocumentPage,
    *,
    file_id: str,
    origin: str,
) -> None:
    """Validate every nested source before reusing normalized content."""
    _validate_pdf_source(
        page.source,
        file_id=file_id,
        page_number=page.page_number,
        origin=origin,
    )
    for block in page.text_blocks:
        _validate_pdf_source(
            block.source,
            file_id=file_id,
            page_number=page.page_number,
            origin=origin,
        )
    for table in page.tables:
        _validate_pdf_source(
            table.source,
            file_id=file_id,
            page_number=page.page_number,
            origin=origin,
        )
        for cell in table.cells:
            _validate_pdf_source(
                cell.source,
                file_id=file_id,
                page_number=page.page_number,
                origin=origin,
            )


def _pages_by_number(
    document: Document,
    *,
    allowed_pages: frozenset[int],
    required_pages: frozenset[int],
    expected_file: FileDescriptor,
    origin: str,
) -> dict[int, DocumentPage]:
    """Validate one normalized document and index its unique pages."""
    _validate_descriptor(
        document.file,
        expected=expected_file,
        origin=origin,
    )
    indexed: dict[int, DocumentPage] = {}
    for page in document.pages:
        if page.page_number in indexed:
            _fail(f"Hybrid PDF {origin} contains duplicate pages")
        if page.page_number not in allowed_pages:
            _fail(f"Hybrid PDF {origin} contains a page outside the input")
        _validate_page_sources(
            page,
            file_id=expected_file.file_id,
            origin=origin,
        )
        indexed[page.page_number] = page
    if not required_pages.issubset(indexed):
        _fail(f"Hybrid PDF {origin} is missing required pages")
    return indexed


def _warning_key(warning: ProcessingWarning) -> str:
    """Return a stable complete key for a normalized safe warning."""
    return warning.model_dump_json()


def _error_key(error: ProcessingError) -> str:
    """Return a stable complete key for a normalized safe error."""
    return error.model_dump_json()


def _deduplicate_warnings(
    warnings: tuple[ProcessingWarning, ...],
) -> tuple[ProcessingWarning, ...]:
    """Deduplicate and order safe warnings independently of provider order."""
    unique = {_warning_key(warning): warning for warning in warnings}
    return tuple(unique[key] for key in sorted(unique))


def _deduplicate_errors(
    errors: tuple[ProcessingError, ...],
) -> tuple[ProcessingError, ...]:
    """Deduplicate and order normalized non-fatal errors."""
    unique = {_error_key(error): error for error in errors}
    return tuple(unique[key] for key in sorted(unique))


def _validate_result_source(
    source: SourceReference | None,
    *,
    file_id: str,
    requested_pages: frozenset[int],
    origin: str,
) -> None:
    """Validate an optional warning/error source from the OCR result."""
    if source is None:
        return
    if (
        not isinstance(source, PdfSourceReference)
        or source.file_id != file_id
        or source.page_number not in requested_pages
    ):
        _fail(f"Hybrid PDF {origin} result source is inconsistent")


def _validated_inspection(
    inspection: PdfInspection,
) -> tuple[
    dict[int, PdfPageInspection],
    frozenset[int],
    frozenset[int],
    frozenset[int],
]:
    """Validate page coverage, classification, and inspection sources."""
    input_pages = frozenset(range(1, inspection.page_count + 1))
    inspection_pages = {page.page_number: page for page in inspection.pages}
    if frozenset(inspection_pages) != input_pages:
        _fail("Hybrid PDF inspection page coverage is inconsistent")
    for page_number, page in inspection_pages.items():
        _validate_pdf_source(
            page.source,
            file_id=inspection.file.file_id,
            page_number=page_number,
            origin="inspection",
        )
    ocr_pages = frozenset(inspection.ocr_candidate_page_numbers)
    native_pages = frozenset(inspection.native_text_page_numbers)
    if native_pages | ocr_pages != input_pages or native_pages & ocr_pages:
        _fail("Hybrid PDF inspection page classification is inconsistent")
    return inspection_pages, input_pages, native_pages, ocr_pages


def _run_ocr(  # noqa: PLR0913
    path: Path,
    *,
    provider: OcrProvider,
    pages: frozenset[int],
    locale: str | None,
    features: tuple[DocumentAnalysisFeature, ...],
    expected_file: FileDescriptor,
    prepared_source: object | None = None,
    enable_local_ocr_quality: bool = False,
    local_invocation_state: _LocalOcrInvocationState | None = None,
) -> _OcrFacts:
    """Run one explicit OCR call and validate its complete normalized result."""
    identity = _provider_context_identity(provider)
    request_options = OcrAnalysisOptions(
        pages=tuple(sorted(pages)),
        locale=locale,
        features=features,
    )
    if prepared_source is None:
        result = _invoke_ocr_provider_safely(
            provider,
            "analyze",
            path,
            options=request_options,
            error_message="Hybrid PDF OCR Provider failed",
        )
    else:
        result = _invoke_ocr_provider_safely(
            provider,
            "_analyze_prepared",
            path,
            prepared_source,
            options=request_options,
            usage_budget=None,
            enable_quality=enable_local_ocr_quality,
            error_message="Hybrid PDF OCR Provider failed",
            invocation_state=local_invocation_state,
        )
    _validate_result_provider_identity(result, expected=identity)
    usage = _validated_provider_usage(
        result,
        identity=identity,
        pages=pages,
        requested_features=tuple(feature.value for feature in features),
    )
    from document_sdk.ocr.local import _local_ocr_quality_policy  # noqa: PLC0415

    expected_quality_policy = _local_ocr_quality_policy(provider)
    if expected_quality_policy is None and enable_local_ocr_quality:
        expected_quality_policy = LocalOcrIntrinsicQualityPolicy()
    quality_valid = True
    try:
        _validate_local_ocr_provider_quality_result(
            report=result.metadata.local_ocr_quality_report,
            usage=usage,
            expected_policy=expected_quality_policy,
            preprocessing_report=result.metadata.local_ocr_preprocessing_report,
        )
    except ValueError:
        quality_valid = False
    if not quality_valid:
        _fail("Hybrid PDF OCR Provider Local quality evidence is inconsistent")
    if result.data is None:
        _fail("Hybrid PDF OCR Provider returned no document")
    try:
        normalized_document = Document.model_validate(result.data.model_dump())
    except Exception as exc:  # noqa: BLE001 - provider boundary is redacted.
        msg = "Hybrid PDF OCR Provider document invariants are invalid"
        _raise_redacted_translation(exc, DocumentProcessingError(msg))
    indexed = _pages_by_number(
        normalized_document,
        allowed_pages=pages,
        required_pages=pages,
        expected_file=expected_file,
        origin="OCR result",
    )
    if frozenset(indexed) != pages:
        _fail("Hybrid PDF OCR result page coverage is inconsistent")
    for warning in result.warnings:
        _validate_result_source(
            warning.source,
            file_id=expected_file.file_id,
            requested_pages=pages,
            origin="OCR warning",
        )
    for error in result.errors:
        _validate_result_source(
            error.source,
            file_id=expected_file.file_id,
            requested_pages=pages,
            origin="OCR error",
        )
    return _OcrFacts(
        pages=indexed,
        document=normalized_document,
        warnings=result.warnings,
        errors=result.errors,
        provider_name=identity.provider_name,
        profile_id=identity.profile_id,
        model_id=identity.model_id,
        usage=usage,
        cloud_execution_attempt=result.metadata.cloud_execution_attempt,
        quality_report=result.metadata.local_ocr_quality_report,
        preprocessing_report=result.metadata.local_ocr_preprocessing_report,
    )


def _local_scopes(
    pages: dict[int, DocumentPage],
    *,
    native_pages: frozenset[int],
) -> tuple[dict[int, DocumentPage], tuple[DocumentContentScope, ...]]:
    """Create explicit local per-page offset spaces without guessing globally."""
    scoped_pages = dict(pages)
    scopes: list[DocumentContentScope] = []
    for page_number in sorted(native_pages):
        page = pages[page_number]
        scope_id = f"local-native-page-{page_number}"
        content_parts: list[str] = []
        blocks = []
        offset = 0
        for index, block in enumerate(page.text_blocks):
            if content_parts:
                content_parts.append("\n")
                offset += 1
            content_parts.append(block.text)
            blocks.append(
                block.model_copy(
                    update={
                        "element_id": (
                            block.element_id
                            or f"local-text-block-p{page_number}-{index + 1}"
                        ),
                        "spans": (
                            DocumentSpan(
                                scope_id=scope_id,
                                offset=offset,
                                length=len(block.text),
                            ),
                        ),
                    }
                )
            )
            offset += len(block.text)
        scopes.append(
            DocumentContentScope(
                scope_id=scope_id,
                content="".join(content_parts),
                indexed_length=offset,
                string_index_type="unicodeCodePoint",
                origin="local_native",
                page_numbers=(page_number,),
            )
        )
        scoped_pages[page_number] = page.model_copy(
            update={
                "text_blocks": tuple(blocks),
                "content_spans": (
                    DocumentSpan(
                        scope_id=scope_id,
                        offset=0,
                        length=offset,
                    ),
                ),
            }
        )
    return scoped_pages, tuple(scopes)


def _replacement_warnings(
    *,
    local_pages: dict[int, DocumentPage],
    ocr_pages: frozenset[int],
) -> tuple[ProcessingWarning, ...]:
    """Report replaced non-empty low-text content without copying it."""
    replacement_count = sum(
        any(block.text.strip() for block in local_pages[page_number].text_blocks)
        for page_number in sorted(ocr_pages & local_pages.keys())
    )
    if not replacement_count:
        return ()
    return (
        ProcessingWarning(
            code="hybrid_pdf.ocr_replaced_native_low_text",
            message="OCR-candidate pages replaced non-empty local low-text content.",
            category="ocr_replaced_native_low_text",
            count=replacement_count,
        ),
    )


def _merge_document(  # noqa: PLR0913
    *,
    inspection: PdfInspection,
    inspection_pages: dict[int, PdfPageInspection],
    local_pages: dict[int, DocumentPage],
    ocr: _OcrFacts,
    ocr_page_numbers: frozenset[int],
    local_scopes: tuple[DocumentContentScope, ...],
) -> Document:
    """Build the complete ordered document using local authoritative geometry."""
    merged_pages: list[DocumentPage] = []
    try:
        for page_number in range(1, inspection.page_count + 1):
            page_inspection = inspection_pages[page_number]
            content_page = (
                ocr.pages[page_number]
                if page_number in ocr_page_numbers
                else local_pages[page_number]
            )
            merged_pages.append(
                DocumentPage(
                    page_number=page_number,
                    dimensions=page_inspection.dimensions,
                    text_blocks=content_page.text_blocks,
                    tables=(
                        content_page.tables if page_number in ocr_page_numbers else ()
                    ),
                    selection_marks=(
                        content_page.selection_marks
                        if page_number in ocr_page_numbers
                        else ()
                    ),
                    barcodes=(
                        content_page.barcodes if page_number in ocr_page_numbers else ()
                    ),
                    formulas=(
                        content_page.formulas if page_number in ocr_page_numbers else ()
                    ),
                    content_spans=content_page.content_spans,
                    source=PdfSourceReference(
                        file_id=inspection.file.file_id,
                        page_number=page_number,
                    ),
                )
            )
        document = Document(
            file=inspection.file,
            pages=tuple(merged_pages),
            content_scopes=local_scopes
            + (() if ocr.document is None else ocr.document.content_scopes),
            paragraphs=() if ocr.document is None else ocr.document.paragraphs,
            key_value_pairs=(
                () if ocr.document is None else ocr.document.key_value_pairs
            ),
            figures=() if ocr.document is None else ocr.document.figures,
            sections=() if ocr.document is None else ocr.document.sections,
            languages=() if ocr.document is None else ocr.document.languages,
            styles=() if ocr.document is None else ocr.document.styles,
            analyzed_documents=(
                () if ocr.document is None else ocr.document.analyzed_documents
            ),
        )
    except Exception as exc:  # noqa: BLE001 - merge boundary is redacted.
        msg = "Hybrid PDF content could not be merged safely"
        _raise_redacted_translation(exc, DocumentProcessingError(msg))
    if tuple(page.page_number for page in document.pages) != tuple(
        range(1, inspection.page_count + 1)
    ):
        _fail("Hybrid PDF final page coverage is inconsistent")
    return document


def _analyze_pdf_hybrid_prepared(  # noqa: PLR0913
    path: Path,
    *,
    inspection: PdfInspection,
    ocr_provider: OcrProvider | None = None,
    options: HybridPdfAnalysisOptions | None = None,
    limits: PdfProcessingLimits | None = None,
    local_prepared_source: object | None = None,
    enable_local_ocr_quality: bool = False,
    local_invocation_state: _LocalOcrInvocationState | None = None,
) -> ProcessingResult[Document]:
    """Analyze one already inspected PDF without repeating source inspection."""
    effective_options = _validated_options(options)
    started = perf_counter()
    inspection_pages, input_pages, native_pages, ocr_pages = _validated_inspection(
        inspection
    )
    if ocr_pages and ocr_provider is None:
        msg = "An explicit OCR Provider is required for OCR-candidate PDF pages"
        raise OcrProviderRequiredError(msg)

    local_document = extract_native_text(path, limits=limits)
    local_by_page = _pages_by_number(
        local_document,
        allowed_pages=input_pages,
        required_pages=native_pages,
        expected_file=inspection.file,
        origin="native extraction",
    )
    local_by_page, local_scopes = _local_scopes(
        local_by_page,
        native_pages=native_pages,
    )

    ocr = _OcrFacts(
        pages={},
        document=None,
        warnings=(),
        errors=(),
        provider_name=None,
        profile_id=None,
        model_id=None,
        usage=None,
        cloud_execution_attempt=None,
        quality_report=None,
        preprocessing_report=None,
    )
    if ocr_pages:
        if ocr_provider is None:  # pragma: no cover - narrowed above.
            msg = "An explicit OCR Provider is required for OCR-candidate PDF pages"
            raise OcrProviderRequiredError(msg)
        ocr = _run_ocr(
            path,
            provider=ocr_provider,
            pages=ocr_pages,
            locale=effective_options.locale,
            features=effective_options.features,
            expected_file=inspection.file,
            prepared_source=local_prepared_source,
            enable_local_ocr_quality=enable_local_ocr_quality,
            local_invocation_state=local_invocation_state,
        )

    quality_report = ocr.quality_report
    if not ocr_pages:
        from document_sdk.core.local_ocr_quality import (  # noqa: PLC0415
            not_applicable_local_ocr_quality_report,
        )
        from document_sdk.ocr.local import _local_ocr_quality_policy  # noqa: PLC0415

        provider_quality_policy = _local_ocr_quality_policy(ocr_provider)
        if enable_local_ocr_quality or provider_quality_policy is not None:
            quality_report = not_applicable_local_ocr_quality_report(
                intrinsic_policy=provider_quality_policy,
            )

    pipeline_warnings = _replacement_warnings(
        local_pages=local_by_page,
        ocr_pages=ocr_pages,
    )
    document = _merge_document(
        inspection=inspection,
        inspection_pages=inspection_pages,
        local_pages=local_by_page,
        ocr=ocr,
        ocr_page_numbers=ocr_pages,
        local_scopes=local_scopes,
    )

    attributes: dict[str, JsonValue] = {
        "pipeline_name": _PIPELINE_NAME,
        "page_count": inspection.page_count,
        "native_page_numbers": cast("list[JsonValue]", sorted(native_pages)),
        "ocr_page_numbers": cast("list[JsonValue]", sorted(ocr_pages)),
        "native_page_count": len(native_pages),
        "ocr_page_count": len(ocr_pages),
        "ocr_provider_name": ocr.provider_name,
    }
    if ocr.profile_id is not None:
        attributes["ocr_profile_id"] = ocr.profile_id
    if ocr.model_id is not None:
        attributes["ocr_model_id"] = ocr.model_id
    return ProcessingResult[Document](
        data=document,
        warnings=_deduplicate_warnings(ocr.warnings + pipeline_warnings),
        errors=_deduplicate_errors(ocr.errors),
        metadata=ProcessingMetadata(
            operation="pipeline.analyze_pdf_hybrid",
            provider_usage=ocr.usage,
            cloud_execution_attempt=ocr.cloud_execution_attempt,
            local_ocr_quality_report=quality_report,
            local_ocr_preprocessing_report=ocr.preprocessing_report,
            duration_ms=(perf_counter() - started) * 1_000,
            attributes=attributes,
        ),
    )


def analyze_pdf_hybrid(
    path: Path,
    *,
    ocr_provider: OcrProvider | None = None,
    options: HybridPdfAnalysisOptions | None = None,
    limits: PdfProcessingLimits | None = None,
) -> ProcessingResult[Document]:
    """Combine local native text with explicit OCR for heuristic candidate pages."""
    return _analyze_pdf_hybrid_effective(
        path,
        ocr_provider=ocr_provider,
        options=options,
        limits=limits,
        enable_local_ocr_quality=False,
    )


def _analyze_pdf_hybrid_effective(  # noqa: PLR0913
    path: Path,
    *,
    ocr_provider: OcrProvider | None,
    options: HybridPdfAnalysisOptions | None,
    limits: PdfProcessingLimits | None,
    enable_local_ocr_quality: bool,
    local_invocation_state: _LocalOcrInvocationState | None = None,
) -> ProcessingResult[Document]:
    """Run hybrid analysis with one private Structured-quality enable signal."""
    effective_options = _validated_options(options)
    effective_limits = None if limits is None else _validated_pdf_limits(limits)
    from document_sdk.ocr.local import (  # noqa: PLC0415
        _uses_local_ocr_prepared_route,
    )

    if not _uses_local_ocr_prepared_route(ocr_provider):
        inspection = inspect_pdf(path, limits=effective_limits)
        return _analyze_pdf_hybrid_prepared(
            path,
            inspection=inspection,
            ocr_provider=ocr_provider,
            options=effective_options,
            limits=effective_limits,
            enable_local_ocr_quality=enable_local_ocr_quality,
            local_invocation_state=local_invocation_state,
        )

    from document_sdk.document.processing import (  # noqa: PLC0415
        _adapter_path,
        _assert_source_unchanged,
        _detect_identity,
        _prepare_local_ocr_source,
    )

    detection = _detect_identity(path)
    prepared_source = _prepare_local_ocr_source(
        ocr_provider,
        path,
        detection,
        limits=effective_limits,
        error_message="Hybrid PDF Local OCR source preparation failed",
    )
    envelope = detection.envelope
    with _adapter_path(
        path,
        envelope.document_format,
        envelope.sha256,
        envelope.byte_size,
        always_snapshot=True,
    ) as adapter:
        _assert_source_unchanged(path, envelope)
        result = _analyze_pdf_hybrid_prepared(
            adapter,
            inspection=cast("PdfInspection", prepared_source.inspection),
            ocr_provider=ocr_provider,
            options=effective_options,
            limits=cast("PdfProcessingLimits", prepared_source.inspection_limits),
            local_prepared_source=prepared_source,
            enable_local_ocr_quality=enable_local_ocr_quality,
            local_invocation_state=local_invocation_state,
        )
    _assert_source_unchanged(path, envelope)
    return result

"""SDK exception hierarchy."""

from __future__ import annotations

from typing import TYPE_CHECKING, Never

from document_sdk.core._exceptions import redact_exception

if TYPE_CHECKING:
    from pathlib import Path

    from document_sdk.core.models import CloudExecutionAttemptEvidence


def safe_file_label(path: Path) -> str:
    """Return a non-sensitive file label for an error message."""
    return path.name or "<unnamed file>"


class _RedactedCauseError(Exception):
    """A safe exception-chain placeholder without backend message data."""


def redacted_cause(exc: BaseException) -> Exception:
    """Return a fixed placeholder without inspecting caller-controlled identity."""
    del exc
    return _RedactedCauseError("External exception details redacted")


def _raise_redacted_translation(exc: BaseException, error: Exception) -> Never:
    """Raise a translated error without retaining its untrusted context graph."""
    cause = redacted_cause(exc)
    redact_exception(exc)
    try:
        raise error from cause
    finally:
        error.__context__ = None


class DocumentSdkError(Exception):
    """Base class for all expected SDK failures."""

    cloud_execution_attempt: CloudExecutionAttemptEvidence | None


class UnsupportedFileError(DocumentSdkError):
    """Raised when a file type is outside an API's supported formats."""


class FileAccessError(DocumentSdkError):
    """Raised when a local file cannot be accessed safely."""


class EncryptedDocumentError(DocumentSdkError):
    """Raised when an encrypted document cannot be processed."""


class DependencyNotInstalledError(DocumentSdkError):
    """Raised when an optional feature dependency is unavailable."""


class ProviderUnavailableError(DocumentSdkError):
    """Raised when an explicitly selected provider cannot be reached or used."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        error_code: str | None = None,
        retryable: bool = True,
    ) -> None:
        """Create a provider failure containing only safe structured facts."""
        self.status_code = status_code
        self.error_code = error_code
        self.retryable = retryable
        super().__init__(message)


class ProviderAuthenticationError(DocumentSdkError):
    """Raised when a provider rejects the resolved authentication."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int = 401,
        error_code: str | None = None,
    ) -> None:
        """Create a non-retryable authentication failure."""
        self.status_code = status_code
        self.error_code = error_code
        self.retryable = False
        super().__init__(message)


class ProviderAuthorizationError(DocumentSdkError):
    """Raised when the resolved identity cannot perform the operation."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int = 403,
        error_code: str | None = None,
    ) -> None:
        """Create a non-retryable authorization failure."""
        self.status_code = status_code
        self.error_code = error_code
        self.retryable = False
        super().__init__(message)


class ProviderRateLimitError(ProviderUnavailableError):
    """Raised when a provider rate limit temporarily rejects work."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int = 429,
        error_code: str | None = None,
    ) -> None:
        """Create a retryable provider throttling failure."""
        super().__init__(
            message,
            status_code=status_code,
            error_code=error_code,
            retryable=True,
        )


class ProviderTimeoutError(ProviderUnavailableError):
    """Raised when a provider operation exceeds its configured wait."""

    def __init__(self, message: str) -> None:
        """Create a retryable provider timeout failure."""
        super().__init__(message, retryable=True)


class ProviderRequestError(DocumentSdkError):
    """Raised when a provider rejects a non-authentication request."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        error_code: str | None = None,
    ) -> None:
        """Create a non-retryable provider request failure."""
        self.status_code = status_code
        self.error_code = error_code
        self.retryable = False
        super().__init__(message)


class ProviderResponseError(DocumentSdkError):
    """Raised when a provider returns malformed or unsafe result data."""

    def __init__(self, message: str) -> None:
        """Create a non-retryable malformed provider-response failure."""
        self.status_code = None
        self.error_code = None
        self.retryable = False
        super().__init__(message)


class ProviderConfigurationError(DocumentSdkError):
    """Raised when provider configuration is invalid for an operation."""


class CredentialResolutionError(DocumentSdkError):
    """Raised when a runtime credential resolver cannot resolve credentials."""


class InvalidSourceReferenceError(DocumentSdkError):
    """Raised when source information cannot identify a valid origin."""


class DocumentProcessingError(DocumentSdkError):
    """Raised when document processing fails after input validation."""


class DocumentSourceChangedError(DocumentSdkError):
    """Raised when source bytes change during one document operation."""


class ImageProcessingError(DocumentProcessingError):
    """Raised when local image inspection cannot complete safely."""


class ImageLimitExceededError(ImageProcessingError):
    """Raised before image decoding would exceed a configured limit."""

    def __init__(
        self,
        *,
        limit_name: str,
        observed: int,
        maximum: int,
    ) -> None:
        """Create a safe structured image-limit failure."""
        self.limit_name = limit_name
        self.observed = observed
        self.maximum = maximum
        message = (
            f"Image {limit_name} limit exceeded: observed {observed}, maximum {maximum}"
        )
        super().__init__(message)


class ExcelCellLimitExceededError(DocumentSdkError):
    """Raised before an Excel read would exceed its configured cell limit."""

    def __init__(self, *, requested_cells: int, max_cells: int) -> None:
        """Create a safe structured Excel cell-limit failure."""
        self.requested_cells = requested_cells
        self.max_cells = max_cells
        message = (
            f"Excel read requested {requested_cells} cells, "
            f"exceeding the configured maximum of {max_cells}"
        )
        super().__init__(message)

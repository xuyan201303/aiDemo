"""Private exception sanitation shared by local document adapters."""

from __future__ import annotations

from contextlib import suppress


def _redact_single_exception(error: BaseException) -> None:
    """Clear one node after its outgoing graph edges have been recorded."""
    with suppress(Exception):
        error.args = ("redacted",)
    with suppress(Exception):
        error.__dict__.clear()
    for attribute in ("__cause__", "__context__", "__traceback__"):
        with suppress(Exception):
            setattr(error, attribute, None)

    for cls in type(error).__mro__:
        slots = cls.__dict__.get("__slots__", ())
        if isinstance(slots, str):
            slots = (slots,)
        for slot in slots:
            if slot in {
                "__cause__",
                "__context__",
                "__dict__",
                "__traceback__",
                "args",
            }:
                continue
            with suppress(Exception):
                setattr(error, slot, None)


def redact_exception(error: BaseException) -> None:
    """Remove untrusted evidence from a complete caught exception graph."""
    pending = [error]
    seen: set[int] = set()
    while pending:
        current = pending.pop()
        identity = id(current)
        if identity in seen:
            continue
        seen.add(identity)

        for attribute in ("__cause__", "__context__"):
            with suppress(Exception):
                nested = object.__getattribute__(current, attribute)
                if issubclass(type(nested), BaseException):
                    pending.append(nested)
        if issubclass(type(current), BaseExceptionGroup):
            with suppress(Exception):
                pending.extend(object.__getattribute__(current, "exceptions"))

        _redact_single_exception(current)

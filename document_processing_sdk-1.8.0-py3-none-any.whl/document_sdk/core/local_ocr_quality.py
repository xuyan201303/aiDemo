"""Strict content-free evidence for the provider-neutral Local OCR quality gate."""

# ruff: noqa: C901, EM101, PLR0912, PLR0913, PLR0915, SIM102, TRY003

from __future__ import annotations

import hashlib
import json
from decimal import ROUND_HALF_UP, Decimal
from enum import StrEnum
from typing import TYPE_CHECKING, Any, Final, Literal, Self

from pydantic import ConfigDict, Field, JsonValue, field_validator, model_validator

from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.models import ProviderUsage, SdkModel

if TYPE_CHECKING:
    from collections.abc import Mapping

    from pydantic.config import ExtraValues

LOCAL_OCR_QUALITY_ALGORITHM_VERSION: Final = "local-ocr-quality-v1"
LOCAL_OCR_QUALITY_RATIO_PRECISION = 6
LOCAL_OCR_QUALITY_CONFIDENCE_SCALE = 1_000_000
LOCAL_OCR_QUALITY_AREA_SCALE = 1_000_000
LOCAL_OCR_QUALITY_COVERAGE_CALCULATION = "capped_summed_shoelace"
LOCAL_OCR_QUALITY_SUSPICIOUS_CHARACTER_POLICY = (
    "unicode-replacement-surrogate-noncharacter-control-v1"
)


class _QualityModel(SdkModel):
    """Give strict models equivalent JSON-string and JSON-dictionary loading."""

    model_config = ConfigDict(revalidate_instances="always")

    @classmethod
    def model_validate(
        cls,
        obj: Any,
        *,
        strict: bool | None = None,
        extra: ExtraValues | None = None,
        from_attributes: bool | None = None,
        context: Any | None = None,
        by_alias: bool | None = None,
        by_name: bool | None = None,
    ) -> Self:
        """Restore a finite JSON-shaped dictionary through JSON validation."""
        if from_attributes is not True and type(obj) is dict:
            try:
                payload = json.dumps(
                    obj,
                    allow_nan=False,
                    ensure_ascii=False,
                    separators=(",", ":"),
                )
            except (TypeError, ValueError):
                pass
            else:
                return cls.model_validate_json(
                    payload,
                    strict=strict,
                    extra=extra,
                    context=context,
                    by_alias=by_alias,
                    by_name=by_name,
                )
        return super().model_validate(
            obj,
            strict=strict,
            extra=extra,
            from_attributes=from_attributes,
            context=context,
            by_alias=by_alias,
            by_name=by_name,
        )


class LocalOcrQualityDecision(StrEnum):
    """Provider-neutral decision for explicitly enabled Local OCR quality."""

    NOT_APPLICABLE = "not_applicable"
    PASS = "pass"  # noqa: S105 - quality decision, not a credential.
    FAIL = "fail"


class LocalOcrQualityIssueCode(StrEnum):
    """Stable content-free Local OCR quality issue categories."""

    EMPTY_RESULT = "empty_result"
    INSUFFICIENT_TEXT = "insufficient_text"
    LOW_CONFIDENCE = "low_confidence"
    EXCESSIVE_LOW_CONFIDENCE_TEXT = "excessive_low_confidence_text"
    GARBLED_TEXT = "garbled_text"
    INSUFFICIENT_REGION_COVERAGE = "insufficient_region_coverage"
    REQUIRED_FIELDS_MISSING = "required_fields_missing"
    TABLE_INCOMPLETE = "table_incomplete"


_ISSUE_ORDER = tuple(LocalOcrQualityIssueCode)
_ISSUE_POSITION = {code: index for index, code in enumerate(_ISSUE_ORDER)}
_INTRINSIC_ISSUES = frozenset(_ISSUE_ORDER[:6])
_STRUCTURED_ISSUES = frozenset(_ISSUE_ORDER[6:])
_LOCAL_OCR_INTRINSIC_ISSUE_LIMIT = len(_INTRINSIC_ISSUES)
_LOCAL_OCR_STRUCTURED_ISSUE_LIMIT = len(_STRUCTURED_ISSUES)
_LOCAL_OCR_TOTAL_ISSUE_LIMIT = len(LocalOcrQualityIssueCode)


def _validate_intrinsic_issue_metric_evidence(
    *,
    issue_counts: Mapping[LocalOcrQualityIssueCode, int],
    evaluated_input_count: int,
    empty_result_count: int,
    character_count: int,
    confidence_weighted_character_count: int,
    low_confidence_character_count: int,
    suspicious_character_count: int,
    region_area_numerator: int,
    region_area_denominator: int,
) -> None:
    """Require issue categories to have universally necessary metric evidence."""
    low_confidence_count = issue_counts.get(LocalOcrQualityIssueCode.LOW_CONFIDENCE, 0)
    low_ratio_count = issue_counts.get(
        LocalOcrQualityIssueCode.EXCESSIVE_LOW_CONFIDENCE_TEXT, 0
    )
    garbled_count = issue_counts.get(LocalOcrQualityIssueCode.GARBLED_TEXT, 0)
    coverage_count = issue_counts.get(
        LocalOcrQualityIssueCode.INSUFFICIENT_REGION_COVERAGE, 0
    )
    nonempty_input_count = evaluated_input_count - empty_result_count
    if any(
        count > nonempty_input_count
        for count in (low_confidence_count, low_ratio_count, garbled_count)
    ):
        raise ValueError("Local OCR intrinsic issue count lacks input evidence")
    confidence_deficit = (
        character_count * LOCAL_OCR_QUALITY_CONFIDENCE_SCALE
        - confidence_weighted_character_count
    )
    if low_confidence_count > confidence_deficit:
        raise ValueError("Local OCR low-confidence issue lacks metric evidence")
    if low_ratio_count > low_confidence_character_count:
        raise ValueError("Local OCR low-confidence ratio issue lacks metric evidence")
    if garbled_count > suspicious_character_count:
        raise ValueError("Local OCR garbled-text issue lacks metric evidence")
    if coverage_count > region_area_denominator - region_area_numerator:
        raise ValueError("Local OCR coverage issue lacks metric evidence")


class LocalOcrIntrinsicQualityPolicy(_QualityModel):
    """Explicit intrinsic rules; optional thresholds are disabled by default."""

    minimum_characters_per_input: int | None = Field(default=None, ge=0)
    minimum_mean_confidence: float | None = Field(default=None, ge=0, le=1)
    low_confidence_threshold: float | None = Field(default=None, ge=0, le=1)
    maximum_low_confidence_character_ratio: float | None = Field(
        default=None,
        ge=0,
        le=1,
    )
    maximum_suspicious_character_ratio: float | None = Field(
        default=None,
        ge=0,
        le=1,
    )
    minimum_region_area_ratio: float | None = Field(default=None, ge=0, le=1)
    include_private_use_characters: bool = False

    @field_validator(
        "minimum_mean_confidence",
        "low_confidence_threshold",
        "maximum_low_confidence_character_ratio",
        "maximum_suspicious_character_ratio",
        "minimum_region_area_ratio",
    )
    @classmethod
    def canonicalize_zero_ratio(cls, value: float | None) -> float | None:
        """Canonicalize policy ratios to the quality gate's fixed-point grid."""
        return _canonical_ratio(value)

    @model_validator(mode="after")
    def validate_low_confidence_rule(self) -> Self:
        """Require an explicit definition before applying a low-confidence ratio."""
        if (
            self.maximum_low_confidence_character_ratio is not None
            and self.low_confidence_threshold is None
        ):
            msg = "A low-confidence threshold is required for its character ratio"
            raise ValueError(msg)
        return self


class LocalOcrStructuredQualityPolicy(_QualityModel):
    """Explicit Structured Extraction and table-completeness quality rules."""

    maximum_missing_required_fields: int | None = Field(default=None, ge=0)
    minimum_table_count: int | None = Field(default=None, ge=0)
    maximum_empty_table_cell_ratio: float | None = Field(
        default=None,
        ge=0,
        le=1,
    )

    @field_validator("maximum_empty_table_cell_ratio")
    @classmethod
    def canonicalize_zero_ratio(cls, value: float | None) -> float | None:
        """Canonicalize policy ratios to the quality gate's fixed-point grid."""
        return _canonical_ratio(value)


class LocalOcrQualityPolicy(_QualityModel):
    """Complete auditable Local OCR quality policy used by one report."""

    intrinsic: LocalOcrIntrinsicQualityPolicy = Field(
        default_factory=LocalOcrIntrinsicQualityPolicy
    )
    structured: LocalOcrStructuredQualityPolicy | None = None


class LocalOcrQualityIssueCount(_QualityModel):
    """One deterministic non-zero issue-category count."""

    code: LocalOcrQualityIssueCode
    count: int = Field(gt=0)


class LocalOcrInputQualityAssessment(_QualityModel):
    """Content-free quality evidence for one submitted Local OCR input."""

    assessment_id: str = Field(pattern=r"^(pdf|image):[1-9][0-9]*$")
    source_kind: Literal["pdf", "image"]
    source_index: int = Field(ge=1)
    character_count: int = Field(ge=0)
    region_count: int = Field(ge=0)
    confidence_weighted_character_count: int = Field(ge=0)
    low_confidence_character_count: int = Field(ge=0)
    suspicious_character_count: int = Field(ge=0)
    region_area_numerator: int = Field(ge=0)
    region_area_denominator: int = Field(gt=0)
    mean_confidence: float | None = Field(default=None, ge=0, le=1)
    low_confidence_character_ratio: float | None = Field(default=None, ge=0, le=1)
    suspicious_character_ratio: float | None = Field(default=None, ge=0, le=1)
    region_area_ratio: float = Field(ge=0, le=1)
    decision: LocalOcrQualityDecision
    issue_codes: tuple[LocalOcrQualityIssueCode, ...] = Field(
        default=(), max_length=_LOCAL_OCR_INTRINSIC_ISSUE_LIMIT
    )

    @field_validator(
        "mean_confidence",
        "low_confidence_character_ratio",
        "suspicious_character_ratio",
        "region_area_ratio",
    )
    @classmethod
    def canonicalize_zero_ratio(cls, value: float | None) -> float | None:
        """Canonicalize public ratios to the quality gate's fixed-point grid."""
        return _canonical_ratio(value)

    @model_validator(mode="after")
    def validate_projection(self) -> Self:
        """Require exact identifiers, count relationships, and issue ordering."""
        if self.assessment_id != f"{self.source_kind}:{self.source_index}":
            msg = "Local OCR quality assessment identity is inconsistent"
            raise ValueError(msg)
        if self.issue_codes != _ordered_unique_issues(self.issue_codes):
            msg = "Local OCR quality assessment issues are not ordered uniquely"
            raise ValueError(msg)
        if any(code not in _INTRINSIC_ISSUES for code in self.issue_codes):
            msg = "Local OCR input assessment contains a structured issue"
            raise ValueError(msg)
        if self.low_confidence_character_count > self.character_count:
            msg = "Local OCR low-confidence character count is inconsistent"
            raise ValueError(msg)
        if self.suspicious_character_count > self.character_count:
            msg = "Local OCR suspicious character count is inconsistent"
            raise ValueError(msg)
        if self.confidence_weighted_character_count > (
            self.character_count * LOCAL_OCR_QUALITY_CONFIDENCE_SCALE
        ):
            msg = "Local OCR confidence numerator is inconsistent"
            raise ValueError(msg)
        if self.region_area_numerator > self.region_area_denominator:
            msg = "Local OCR region area evidence is inconsistent"
            raise ValueError(msg)
        if (
            self.region_area_denominator < LOCAL_OCR_QUALITY_AREA_SCALE
            or self.region_area_denominator % LOCAL_OCR_QUALITY_AREA_SCALE
        ):
            msg = "Local OCR region area denominator scale is inconsistent"
            raise ValueError(msg)
        if self.region_count == 0 and self.region_area_numerator != 0:
            msg = "Local OCR empty region area evidence is inconsistent"
            raise ValueError(msg)
        if self.character_count > 0 and self.region_count == 0:
            msg = "Local OCR character and region counts are inconsistent"
            raise ValueError(msg)
        empty = self.region_count == 0 or self.character_count == 0
        if empty != (LocalOcrQualityIssueCode.EMPTY_RESULT in self.issue_codes):
            msg = "Local OCR empty-result evidence is inconsistent"
            raise ValueError(msg)
        if self.character_count == 0:
            ratios_are_empty = (
                self.mean_confidence is None
                and self.low_confidence_character_ratio is None
                and self.suspicious_character_ratio is None
            )
            if not ratios_are_empty or self.confidence_weighted_character_count != 0:
                msg = "Local OCR empty confidence evidence is inconsistent"
                raise ValueError(msg)
        else:
            expected_mean = _rounded_ratio(
                self.confidence_weighted_character_count,
                self.character_count * LOCAL_OCR_QUALITY_CONFIDENCE_SCALE,
            )
            expected_suspicious = _rounded_ratio(
                self.suspicious_character_count,
                self.character_count,
            )
            if (
                self.mean_confidence != expected_mean
                or self.suspicious_character_ratio != expected_suspicious
            ):
                msg = "Local OCR non-empty quality ratios are inconsistent"
                raise ValueError(msg)
            expected_low = _rounded_ratio(
                self.low_confidence_character_count,
                self.character_count,
            )
            if (
                self.low_confidence_character_ratio is None
                and self.low_confidence_character_count != 0
            ) or self.low_confidence_character_ratio not in {None, expected_low}:
                msg = "Local OCR low-confidence ratio is inconsistent"
                raise ValueError(msg)
        if self.region_area_ratio != _rounded_ratio(
            self.region_area_numerator,
            self.region_area_denominator,
        ):
            msg = "Local OCR region-area ratio is inconsistent"
            raise ValueError(msg)
        _validate_intrinsic_issue_metric_evidence(
            issue_counts=dict.fromkeys(self.issue_codes, 1),
            evaluated_input_count=1,
            empty_result_count=int(
                LocalOcrQualityIssueCode.EMPTY_RESULT in self.issue_codes
            ),
            character_count=self.character_count,
            confidence_weighted_character_count=(
                self.confidence_weighted_character_count
            ),
            low_confidence_character_count=self.low_confidence_character_count,
            suspicious_character_count=self.suspicious_character_count,
            region_area_numerator=self.region_area_numerator,
            region_area_denominator=self.region_area_denominator,
        )
        if bool(self.issue_codes) != (self.decision is LocalOcrQualityDecision.FAIL):
            msg = "Local OCR input quality decision is inconsistent"
            raise ValueError(msg)
        if self.decision is LocalOcrQualityDecision.NOT_APPLICABLE:
            msg = "Submitted Local OCR input cannot be not applicable"
            raise ValueError(msg)
        return self


class LocalOcrQualitySummary(_QualityModel):
    """Content-free durable projection suitable for manifests and Resume."""

    algorithm_version: Literal["local-ocr-quality-v1"] = (
        LOCAL_OCR_QUALITY_ALGORITHM_VERSION
    )
    policy_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    decision: LocalOcrQualityDecision
    evaluated_input_count: int = Field(ge=0)
    passed_input_count: int = Field(ge=0)
    failed_input_count: int = Field(ge=0)
    evaluated_pages: tuple[int, ...] = ()
    evaluated_frames: tuple[int, ...] = ()
    issue_counts_by_code: tuple[LocalOcrQualityIssueCount, ...] = Field(
        default=(), max_length=_LOCAL_OCR_TOTAL_ISSUE_LIMIT
    )
    reason_codes: tuple[LocalOcrQualityIssueCode, ...] = Field(
        default=(), max_length=_LOCAL_OCR_TOTAL_ISSUE_LIMIT
    )
    failed_pages: tuple[int, ...] = ()
    failed_frames: tuple[int, ...] = ()
    retry_recommended: bool = False
    recommended_retry_pages: tuple[int, ...] = ()
    recommended_retry_frames: tuple[int, ...] = ()
    character_count: int = Field(ge=0)
    region_count: int = Field(ge=0)
    confidence_weighted_character_count: int = Field(ge=0)
    low_confidence_character_count: int = Field(ge=0)
    suspicious_character_count: int = Field(ge=0)
    region_area_numerator: int = Field(ge=0)
    region_area_denominator: int = Field(ge=0)
    required_field_count: int = Field(ge=0)
    missing_required_field_count: int = Field(ge=0)
    ambiguous_required_field_count: int = Field(ge=0)
    constrained_required_field_issue_count: int = Field(ge=0)
    table_count: int = Field(ge=0)
    table_cell_count: int = Field(ge=0)
    empty_table_cell_count: int = Field(ge=0)

    @model_validator(mode="after")
    def validate_summary(self) -> Self:
        """Require deterministic ordering and internally consistent totals."""
        if self.evaluated_input_count != (
            self.passed_input_count + self.failed_input_count
        ):
            msg = "Local OCR quality input totals are inconsistent"
            raise ValueError(msg)
        if self.failed_input_count != (
            len(self.failed_pages) + len(self.failed_frames)
        ):
            msg = "Local OCR failed input indexes are inconsistent"
            raise ValueError(msg)
        if self.issue_counts_by_code != _ordered_issue_counts(
            self.issue_counts_by_code
        ):
            msg = "Local OCR quality issue counts are not ordered uniquely"
            raise ValueError(msg)
        counted_codes = tuple(item.code for item in self.issue_counts_by_code)
        if self.reason_codes != counted_codes:
            msg = "Local OCR quality reason codes are inconsistent"
            raise ValueError(msg)
        index_tuples = (
            self.evaluated_pages,
            self.evaluated_frames,
            self.failed_pages,
            self.failed_frames,
            self.recommended_retry_pages,
            self.recommended_retry_frames,
        )
        if any(values != _positive_sorted_unique(values) for values in index_tuples):
            msg = "Local OCR quality indexes are not positive sorted unique values"
            raise ValueError(msg)
        if self.evaluated_input_count != (
            len(self.evaluated_pages) + len(self.evaluated_frames)
        ):
            msg = "Local OCR evaluated input indexes are inconsistent"
            raise ValueError(msg)
        if self.evaluated_pages and self.evaluated_frames:
            msg = "Local OCR quality summary mixes source families"
            raise ValueError(msg)
        if not set(self.failed_pages).issubset(self.evaluated_pages) or not set(
            self.recommended_retry_pages
        ).issubset(self.evaluated_pages):
            msg = "Local OCR quality page indexes are outside evaluated inputs"
            raise ValueError(msg)
        if not set(self.failed_frames).issubset(self.evaluated_frames) or not set(
            self.recommended_retry_frames
        ).issubset(self.evaluated_frames):
            msg = "Local OCR quality frame indexes are outside evaluated inputs"
            raise ValueError(msg)
        retry_indexes = bool(
            self.recommended_retry_pages or self.recommended_retry_frames
        )
        if self.retry_recommended != retry_indexes:
            msg = "Local OCR quality retry evidence is inconsistent"
            raise ValueError(msg)
        if (
            self.low_confidence_character_count > self.character_count
            or self.suspicious_character_count > self.character_count
            or self.confidence_weighted_character_count
            > self.character_count * LOCAL_OCR_QUALITY_CONFIDENCE_SCALE
            or self.region_area_numerator > self.region_area_denominator
            or (self.region_count == 0 and self.region_area_numerator != 0)
            or (self.character_count > 0 and self.region_count == 0)
        ):
            msg = "Local OCR quality aggregate metrics are inconsistent"
            raise ValueError(msg)
        local_metrics = (
            self.character_count,
            self.region_count,
            self.confidence_weighted_character_count,
            self.low_confidence_character_count,
            self.suspicious_character_count,
            self.region_area_numerator,
            self.region_area_denominator,
        )
        if (self.evaluated_input_count == 0 and any(local_metrics)) or (
            self.evaluated_input_count > 0
            and (
                self.region_area_denominator
                < self.evaluated_input_count * LOCAL_OCR_QUALITY_AREA_SCALE
                or self.region_area_denominator % LOCAL_OCR_QUALITY_AREA_SCALE
            )
        ):
            msg = "Local OCR quality aggregate input evidence is inconsistent"
            raise ValueError(msg)
        _validate_intrinsic_issue_metric_evidence(
            issue_counts={item.code: item.count for item in self.issue_counts_by_code},
            evaluated_input_count=self.evaluated_input_count,
            empty_result_count=next(
                (
                    item.count
                    for item in self.issue_counts_by_code
                    if item.code is LocalOcrQualityIssueCode.EMPTY_RESULT
                ),
                0,
            ),
            character_count=self.character_count,
            confidence_weighted_character_count=(
                self.confidence_weighted_character_count
            ),
            low_confidence_character_count=self.low_confidence_character_count,
            suspicious_character_count=self.suspicious_character_count,
            region_area_numerator=self.region_area_numerator,
            region_area_denominator=self.region_area_denominator,
        )
        _validate_quality_count_evidence(
            decision=self.decision,
            evaluated_input_count=self.evaluated_input_count,
            passed_input_count=self.passed_input_count,
            failed_input_count=self.failed_input_count,
            issue_counts_by_code=self.issue_counts_by_code,
            evaluated_pages=self.evaluated_pages,
            evaluated_frames=self.evaluated_frames,
            failed_pages=self.failed_pages,
            failed_frames=self.failed_frames,
            retry_recommended=self.retry_recommended,
            recommended_retry_pages=self.recommended_retry_pages,
            recommended_retry_frames=self.recommended_retry_frames,
            character_count=self.character_count,
            region_count=self.region_count,
            required_field_count=self.required_field_count,
            missing_required_field_count=self.missing_required_field_count,
            ambiguous_required_field_count=self.ambiguous_required_field_count,
            constrained_required_field_issue_count=(
                self.constrained_required_field_issue_count
            ),
            table_count=self.table_count,
            table_cell_count=self.table_cell_count,
            empty_table_cell_count=self.empty_table_cell_count,
        )
        return self


class LocalOcrQualityReport(_QualityModel):
    """Complete explicit Local OCR quality report without recognized content."""

    algorithm_version: Literal["local-ocr-quality-v1"] = (
        LOCAL_OCR_QUALITY_ALGORITHM_VERSION
    )
    policy: LocalOcrQualityPolicy
    input_assessments: tuple[LocalOcrInputQualityAssessment, ...] = ()
    structural_issue_codes: tuple[LocalOcrQualityIssueCode, ...] = Field(
        default=(), max_length=_LOCAL_OCR_STRUCTURED_ISSUE_LIMIT
    )
    required_field_count: int = Field(default=0, ge=0)
    missing_required_field_count: int = Field(default=0, ge=0)
    ambiguous_required_field_count: int = Field(default=0, ge=0)
    constrained_required_field_issue_count: int = Field(default=0, ge=0)
    table_count: int = Field(default=0, ge=0)
    table_cell_count: int = Field(default=0, ge=0)
    empty_table_cell_count: int = Field(default=0, ge=0)
    summary_evidence: LocalOcrQualitySummary

    @model_validator(mode="after")
    def validate_report(self) -> Self:
        """Cross-check every deterministic input, structural, and summary field."""
        ordered = tuple(
            sorted(
                self.input_assessments,
                key=lambda item: (
                    0 if item.source_kind == "pdf" else 1,
                    item.source_index,
                ),
            )
        )
        if self.input_assessments != ordered:
            msg = "Local OCR quality assessments are not deterministically ordered"
            raise ValueError(msg)
        if any(
            assessment.issue_codes
            != _expected_intrinsic_issues(assessment, self.policy.intrinsic)
            for assessment in self.input_assessments
        ):
            msg = "Local OCR input issues do not match the intrinsic policy"
            raise ValueError(msg)
        low_threshold_enabled = (
            self.policy.intrinsic.low_confidence_threshold is not None
        )
        if any(
            (
                assessment.character_count > 0
                and (
                    assessment.low_confidence_character_ratio is None
                    or assessment.low_confidence_character_ratio
                    != _rounded_ratio(
                        assessment.low_confidence_character_count,
                        assessment.character_count,
                    )
                )
            )
            if low_threshold_enabled
            else (
                assessment.low_confidence_character_count != 0
                or assessment.low_confidence_character_ratio is not None
            )
            for assessment in self.input_assessments
        ):
            msg = "Local OCR low-confidence evidence does not match the policy"
            raise ValueError(msg)
        assessment_ids = tuple(item.assessment_id for item in self.input_assessments)
        if len(assessment_ids) != len(set(assessment_ids)):
            msg = "Local OCR quality assessment identities must be unique"
            raise ValueError(msg)
        if len({item.source_kind for item in self.input_assessments}) > 1:
            msg = "Local OCR quality report mixes source families"
            raise ValueError(msg)
        if self.structural_issue_codes != _ordered_unique_issues(
            self.structural_issue_codes
        ) or any(
            code not in _STRUCTURED_ISSUES for code in self.structural_issue_codes
        ):
            msg = "Local OCR structured quality issues are invalid"
            raise ValueError(msg)
        if self.structural_issue_codes != _expected_structured_issues(
            policy=self.policy.structured,
            has_local_inputs=bool(self.input_assessments),
            missing_required_field_count=self.missing_required_field_count,
            table_count=self.table_count,
            table_cell_count=self.table_cell_count,
            empty_table_cell_count=self.empty_table_cell_count,
        ):
            msg = "Local OCR structured issues do not match the policy"
            raise ValueError(msg)
        if self.missing_required_field_count > self.required_field_count:
            msg = "Local OCR missing required field count is inconsistent"
            raise ValueError(msg)
        if self.ambiguous_required_field_count > self.required_field_count:
            msg = "Local OCR ambiguous required field count is inconsistent"
            raise ValueError(msg)
        if self.empty_table_cell_count > self.table_cell_count:
            msg = "Local OCR empty table cell count is inconsistent"
            raise ValueError(msg)
        if self.policy.structured is None and any(
            (
                self.required_field_count,
                self.missing_required_field_count,
                self.ambiguous_required_field_count,
                self.constrained_required_field_issue_count,
                self.table_count,
                self.table_cell_count,
                self.empty_table_cell_count,
            )
        ):
            msg = "Local OCR report has structural counts without a policy"
            raise ValueError(msg)
        summary = self.summary_evidence
        _validate_quality_count_evidence(
            decision=summary.decision,
            evaluated_input_count=summary.evaluated_input_count,
            passed_input_count=summary.passed_input_count,
            failed_input_count=summary.failed_input_count,
            issue_counts_by_code=summary.issue_counts_by_code,
            evaluated_pages=summary.evaluated_pages,
            evaluated_frames=summary.evaluated_frames,
            failed_pages=summary.failed_pages,
            failed_frames=summary.failed_frames,
            retry_recommended=summary.retry_recommended,
            recommended_retry_pages=summary.recommended_retry_pages,
            recommended_retry_frames=summary.recommended_retry_frames,
            character_count=summary.character_count,
            region_count=summary.region_count,
            required_field_count=self.required_field_count,
            missing_required_field_count=self.missing_required_field_count,
            ambiguous_required_field_count=self.ambiguous_required_field_count,
            constrained_required_field_issue_count=(
                self.constrained_required_field_issue_count
            ),
            table_count=self.table_count,
            table_cell_count=self.table_cell_count,
            empty_table_cell_count=self.empty_table_cell_count,
        )
        expected = _quality_summary(
            policy=self.policy,
            assessments=self.input_assessments,
            structural_issue_codes=self.structural_issue_codes,
            required_field_count=self.required_field_count,
            missing_required_field_count=self.missing_required_field_count,
            ambiguous_required_field_count=self.ambiguous_required_field_count,
            constrained_required_field_issue_count=(
                self.constrained_required_field_issue_count
            ),
            table_count=self.table_count,
            table_cell_count=self.table_cell_count,
            empty_table_cell_count=self.empty_table_cell_count,
        )
        if self.summary_evidence != expected:
            msg = "Local OCR quality summary projection is inconsistent"
            raise ValueError(msg)
        return self

    @property
    def summary(self) -> LocalOcrQualitySummary:
        """Return the validated immutable manifest-safe projection."""
        return self.summary_evidence


def local_ocr_quality_identity(
    *,
    intrinsic_policy: LocalOcrIntrinsicQualityPolicy,
    structured_policy: LocalOcrStructuredQualityPolicy | None,
) -> dict[str, JsonValue]:
    """Return stable content-free quality semantics for processing identity."""
    intrinsic_policy = _validate_intrinsic_quality_policy(intrinsic_policy)
    structured_policy = _validate_structured_quality_policy(structured_policy)
    return {
        "algorithm_version": LOCAL_OCR_QUALITY_ALGORITHM_VERSION,
        "ratio_precision": LOCAL_OCR_QUALITY_RATIO_PRECISION,
        "confidence_scale": LOCAL_OCR_QUALITY_CONFIDENCE_SCALE,
        "region_area_scale": LOCAL_OCR_QUALITY_AREA_SCALE,
        "coverage_calculation": LOCAL_OCR_QUALITY_COVERAGE_CALCULATION,
        "suspicious_character_policy": (LOCAL_OCR_QUALITY_SUSPICIOUS_CHARACTER_POLICY),
        "include_private_use_characters": (
            intrinsic_policy.include_private_use_characters
        ),
        "intrinsic_policy": intrinsic_policy.model_dump(mode="json"),
        "structured_policy": (
            None
            if structured_policy is None
            else structured_policy.model_dump(mode="json")
        ),
    }


def local_ocr_quality_policy_fingerprint(
    policy: LocalOcrQualityPolicy,
) -> str:
    """Hash only policy and algorithm semantics, never observed OCR evidence."""
    policy = _validate_quality_policy(policy)
    payload = local_ocr_quality_identity(
        intrinsic_policy=policy.intrinsic,
        structured_policy=policy.structured,
    )
    return hashlib.sha256(
        json.dumps(
            payload,
            allow_nan=False,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        ).encode()
    ).hexdigest()


def _validate_local_ocr_provider_quality_result(
    *,
    report: LocalOcrQualityReport | None,
    usage: ProviderUsage | None,
    expected_policy: LocalOcrIntrinsicQualityPolicy | None,
    preprocessing_report: Any | None = None,
) -> None:
    """Validate exact intrinsic coverage at a caller-owned Provider boundary."""
    if expected_policy is None:
        if report is not None:
            msg = "Unexpected Local OCR quality evidence"
            raise ValueError(msg)
        return
    if report is None or usage is None:
        msg = "Required Local OCR quality evidence is unavailable"
        raise ValueError(msg)
    if report.policy != LocalOcrQualityPolicy(intrinsic=expected_policy):
        msg = "Local OCR quality policy evidence is inconsistent"
        raise ValueError(msg)
    summary = report.summary
    preprocessing_attempt_count = (
        0
        if preprocessing_report is None
        else sum(
            item.attempt_count - 1 for item in preprocessing_report.input_summaries
        )
    )
    preprocessing_operation_count = (
        0
        if preprocessing_report is None
        else preprocessing_report.total_extra_ocr_operations
    )
    preprocessing_pixel_count = (
        0
        if preprocessing_report is None
        else preprocessing_report.total_preprocessing_pixels
    )
    if summary.evaluated_input_count == 0 or not _local_ocr_quality_usage_matches(
        summary=summary,
        usage=usage,
        preprocessing_attempt_count=preprocessing_attempt_count,
        preprocessing_operation_count=preprocessing_operation_count,
        preprocessing_pixel_count=preprocessing_pixel_count,
    ):
        msg = "Local OCR quality coverage is inconsistent"
        raise ValueError(msg)


def _local_ocr_quality_usage_matches(
    *,
    summary: LocalOcrQualitySummary,
    usage: ProviderUsage | None,
    preprocessing_attempt_count: int = 0,
    preprocessing_operation_count: int = 0,
    preprocessing_pixel_count: int = 0,
) -> bool:
    """Match applicable quality evidence to exact content-free Local OCR usage."""
    if summary.decision is LocalOcrQualityDecision.NOT_APPLICABLE:
        return usage is None
    return usage is not None and (
        usage.provider_name == "local_ocr"
        and usage.submitted_pages == summary.evaluated_pages
        and usage.returned_pages == summary.evaluated_pages
        and usage.submitted_frames == summary.evaluated_frames
        and usage.returned_frames == summary.evaluated_frames
        and usage.local_operation_count
        == summary.evaluated_input_count + preprocessing_operation_count
        and usage.local_page_count
        == len(summary.evaluated_pages)
        + (preprocessing_operation_count if summary.evaluated_pages else 0)
        and usage.local_frame_count
        == len(summary.evaluated_frames)
        + (preprocessing_operation_count if summary.evaluated_frames else 0)
        and usage.local_preprocessing_attempt_count == preprocessing_attempt_count
        and usage.local_preprocessing_operation_count == preprocessing_operation_count
        and usage.local_preprocessing_pixel_count == preprocessing_pixel_count
        and usage.local_region_count == summary.region_count
        and (
            usage.local_attempted_region_count >= summary.region_count
            if preprocessing_operation_count
            else usage.local_attempted_region_count == summary.region_count
        )
        and usage.local_input_pixel_count >= summary.evaluated_input_count
        and summary.region_area_denominator
        == (usage.local_input_pixel_count - preprocessing_pixel_count)
        * LOCAL_OCR_QUALITY_AREA_SCALE
        and usage.local_output_character_count == summary.character_count
        and (
            usage.local_attempted_output_character_count >= summary.character_count
            if preprocessing_operation_count
            else usage.local_attempted_output_character_count == summary.character_count
        )
        and usage.query_field_count == 0
        and usage.requested_features == ()
        and usage.azure_operation_count == 0
        and usage.paid_operation_count == 0
    )


def _validate_provider_usage(usage: ProviderUsage | None) -> ProviderUsage | None:
    """Revalidate possibly copied Provider usage without trusting the instance."""
    if usage is None:
        return None
    return _revalidate_model_instance_json(
        usage,
        ProviderUsage,
        "Local OCR Provider usage is invalid",
    )


def _validate_intrinsic_quality_policy(
    policy: LocalOcrIntrinsicQualityPolicy,
) -> LocalOcrIntrinsicQualityPolicy:
    """Revalidate a possibly model-copied intrinsic policy without trusting it."""
    return _revalidate_model_instance_json(
        policy,
        LocalOcrIntrinsicQualityPolicy,
        "Local OCR intrinsic quality policy is invalid",
    )


def _validate_structured_quality_policy(
    policy: LocalOcrStructuredQualityPolicy | None,
) -> LocalOcrStructuredQualityPolicy | None:
    """Revalidate a possibly model-copied structured policy without trusting it."""
    if policy is None:
        return None
    return _revalidate_model_instance_json(
        policy,
        LocalOcrStructuredQualityPolicy,
        "Local OCR structured quality policy is invalid",
    )


def _validate_quality_policy(policy: LocalOcrQualityPolicy) -> LocalOcrQualityPolicy:
    """Revalidate a complete nested policy through its canonical JSON boundary."""
    intrinsic = _validate_intrinsic_quality_policy(policy.intrinsic)
    structured = _validate_structured_quality_policy(policy.structured)
    return LocalOcrQualityPolicy(intrinsic=intrinsic, structured=structured)


def _validate_quality_assessment(
    assessment: LocalOcrInputQualityAssessment,
) -> LocalOcrInputQualityAssessment:
    """Revalidate one possibly model-copied assessment."""
    return _revalidate_model_instance_json(
        assessment,
        LocalOcrInputQualityAssessment,
        "Local OCR input quality assessment is invalid",
    )


def _validate_quality_summary(
    summary: LocalOcrQualitySummary,
) -> LocalOcrQualitySummary:
    """Revalidate one possibly model-copied durable summary."""
    return _revalidate_model_instance_json(
        summary,
        LocalOcrQualitySummary,
        "Local OCR quality summary is invalid",
    )


def _validate_quality_report(report: LocalOcrQualityReport) -> LocalOcrQualityReport:
    """Revalidate one possibly model-copied full report and every nested model."""
    return _revalidate_model_instance_json(
        report,
        LocalOcrQualityReport,
        "Local OCR quality report is invalid",
    )


def create_local_ocr_input_quality_assessment(
    *,
    policy: LocalOcrIntrinsicQualityPolicy,
    source_kind: Literal["pdf", "image"],
    source_index: int,
    character_count: int,
    region_count: int,
    confidence_weighted_character_count: int,
    low_confidence_character_count: int,
    suspicious_character_count: int,
    region_area_numerator: int,
    region_area_denominator: int,
) -> LocalOcrInputQualityAssessment:
    """Evaluate one safe fixed-size accumulator without recognized content."""
    mean_confidence = (
        None
        if character_count == 0
        else _rounded_ratio(
            confidence_weighted_character_count,
            character_count * LOCAL_OCR_QUALITY_CONFIDENCE_SCALE,
        )
    )
    low_ratio = (
        None
        if character_count == 0 or policy.low_confidence_threshold is None
        else _rounded_ratio(low_confidence_character_count, character_count)
    )
    suspicious_ratio = (
        None
        if character_count == 0
        else _rounded_ratio(suspicious_character_count, character_count)
    )
    area_ratio = _rounded_ratio(region_area_numerator, region_area_denominator)
    issues = _intrinsic_issues(
        policy=policy,
        character_count=character_count,
        region_count=region_count,
        confidence_weighted_character_count=(confidence_weighted_character_count),
        low_confidence_character_count=low_confidence_character_count,
        suspicious_character_count=suspicious_character_count,
        region_area_numerator=region_area_numerator,
        region_area_denominator=region_area_denominator,
    )
    return LocalOcrInputQualityAssessment(
        assessment_id=f"{source_kind}:{source_index}",
        source_kind=source_kind,
        source_index=source_index,
        character_count=character_count,
        region_count=region_count,
        confidence_weighted_character_count=(confidence_weighted_character_count),
        low_confidence_character_count=low_confidence_character_count,
        suspicious_character_count=suspicious_character_count,
        region_area_numerator=region_area_numerator,
        region_area_denominator=region_area_denominator,
        mean_confidence=mean_confidence,
        low_confidence_character_ratio=low_ratio,
        suspicious_character_ratio=suspicious_ratio,
        region_area_ratio=area_ratio,
        decision=(
            LocalOcrQualityDecision.FAIL if issues else LocalOcrQualityDecision.PASS
        ),
        issue_codes=issues,
    )


def create_local_ocr_quality_report(
    *,
    intrinsic_policy: LocalOcrIntrinsicQualityPolicy,
    assessments: tuple[LocalOcrInputQualityAssessment, ...],
    structured_policy: LocalOcrStructuredQualityPolicy | None = None,
    structural_issue_codes: tuple[LocalOcrQualityIssueCode, ...] = (),
    required_field_count: int = 0,
    missing_required_field_count: int = 0,
    ambiguous_required_field_count: int = 0,
    constrained_required_field_issue_count: int = 0,
    table_count: int = 0,
    table_cell_count: int = 0,
    empty_table_cell_count: int = 0,
) -> LocalOcrQualityReport:
    """Create one completely cross-validated quality report from safe counts."""
    intrinsic_policy = _validate_intrinsic_quality_policy(intrinsic_policy)
    structured_policy = _validate_structured_quality_policy(structured_policy)
    assessments = tuple(_validate_quality_assessment(item) for item in assessments)
    policy = LocalOcrQualityPolicy(
        intrinsic=intrinsic_policy,
        structured=structured_policy,
    )
    ordered_assessments = tuple(
        sorted(
            assessments,
            key=lambda item: (
                0 if item.source_kind == "pdf" else 1,
                item.source_index,
            ),
        )
    )
    ordered_structural_issues = _ordered_unique_issues(structural_issue_codes)
    summary = _quality_summary(
        policy=policy,
        assessments=ordered_assessments,
        structural_issue_codes=ordered_structural_issues,
        required_field_count=required_field_count,
        missing_required_field_count=missing_required_field_count,
        ambiguous_required_field_count=ambiguous_required_field_count,
        constrained_required_field_issue_count=(constrained_required_field_issue_count),
        table_count=table_count,
        table_cell_count=table_cell_count,
        empty_table_cell_count=empty_table_cell_count,
    )
    return LocalOcrQualityReport(
        policy=policy,
        input_assessments=ordered_assessments,
        structural_issue_codes=ordered_structural_issues,
        required_field_count=required_field_count,
        missing_required_field_count=missing_required_field_count,
        ambiguous_required_field_count=ambiguous_required_field_count,
        constrained_required_field_issue_count=(constrained_required_field_issue_count),
        table_count=table_count,
        table_cell_count=table_cell_count,
        empty_table_cell_count=empty_table_cell_count,
        summary_evidence=summary,
    )


def not_applicable_local_ocr_quality_report(
    *,
    intrinsic_policy: LocalOcrIntrinsicQualityPolicy | None = None,
    structured_policy: LocalOcrStructuredQualityPolicy | None = None,
) -> LocalOcrQualityReport:
    """Create explicit no-Local-input evidence without claiming a quality pass."""
    intrinsic_policy = _validate_intrinsic_quality_policy(
        intrinsic_policy or LocalOcrIntrinsicQualityPolicy()
    )
    structured_policy = _validate_structured_quality_policy(structured_policy)
    return create_local_ocr_quality_report(
        intrinsic_policy=intrinsic_policy,
        structured_policy=structured_policy,
        assessments=(),
    )


def merge_local_ocr_structured_quality(
    *,
    intrinsic_report: LocalOcrQualityReport | None,
    policy: LocalOcrStructuredQualityPolicy,
    required_field_count: int,
    missing_required_field_count: int,
    ambiguous_required_field_count: int,
    constrained_required_field_issue_count: int,
    table_count: int,
    table_cell_count: int,
    empty_table_cell_count: int,
) -> LocalOcrQualityReport:
    """Merge existing intrinsic evidence with one already-computed extraction."""
    validated_policy = _validate_structured_quality_policy(policy)
    if validated_policy is None:
        raise ValueError("Local OCR structured quality policy is invalid")
    policy = validated_policy
    base = (
        _validate_quality_report(intrinsic_report)
        if intrinsic_report is not None
        else not_applicable_local_ocr_quality_report()
    )
    issues: list[LocalOcrQualityIssueCode] = []
    missing_limit = policy.maximum_missing_required_fields
    if missing_limit is not None and missing_required_field_count > missing_limit:
        issues.append(LocalOcrQualityIssueCode.REQUIRED_FIELDS_MISSING)
    table_incomplete = (
        policy.minimum_table_count is not None
        and table_count < policy.minimum_table_count
    )
    empty_ratio_limit = policy.maximum_empty_table_cell_ratio
    if empty_ratio_limit is not None:
        threshold_micro = _ratio_micro(empty_ratio_limit)
        table_incomplete = (
            table_incomplete
            or table_cell_count == 0
            or _ratio_micro_from_fraction(
                empty_table_cell_count,
                table_cell_count,
            )
            > threshold_micro
        )
    if table_incomplete:
        issues.append(LocalOcrQualityIssueCode.TABLE_INCOMPLETE)
    if not base.input_assessments:
        issues.clear()
    return create_local_ocr_quality_report(
        intrinsic_policy=base.policy.intrinsic,
        structured_policy=policy,
        assessments=base.input_assessments,
        structural_issue_codes=tuple(issues),
        required_field_count=required_field_count,
        missing_required_field_count=missing_required_field_count,
        ambiguous_required_field_count=ambiguous_required_field_count,
        constrained_required_field_issue_count=(constrained_required_field_issue_count),
        table_count=table_count,
        table_cell_count=table_cell_count,
        empty_table_cell_count=empty_table_cell_count,
    )


def _quality_summary(
    *,
    policy: LocalOcrQualityPolicy,
    assessments: tuple[LocalOcrInputQualityAssessment, ...],
    structural_issue_codes: tuple[LocalOcrQualityIssueCode, ...],
    required_field_count: int,
    missing_required_field_count: int,
    ambiguous_required_field_count: int,
    constrained_required_field_issue_count: int,
    table_count: int,
    table_cell_count: int,
    empty_table_cell_count: int,
) -> LocalOcrQualitySummary:
    issue_counts = dict.fromkeys(_ISSUE_ORDER, 0)
    for assessment in assessments:
        for code in assessment.issue_codes:
            issue_counts[code] += 1
    if assessments:
        for code in structural_issue_codes:
            issue_counts[code] += 1
    count_evidence = tuple(
        LocalOcrQualityIssueCount(code=code, count=issue_counts[code])
        for code in _ISSUE_ORDER
        if issue_counts[code]
    )
    failed_pages = tuple(
        assessment.source_index
        for assessment in assessments
        if assessment.source_kind == "pdf"
        and assessment.decision is LocalOcrQualityDecision.FAIL
    )
    failed_frames = tuple(
        assessment.source_index
        for assessment in assessments
        if assessment.source_kind == "image"
        and assessment.decision is LocalOcrQualityDecision.FAIL
    )
    all_pages = tuple(
        assessment.source_index
        for assessment in assessments
        if assessment.source_kind == "pdf"
    )
    all_frames = tuple(
        assessment.source_index
        for assessment in assessments
        if assessment.source_kind == "image"
    )
    if structural_issue_codes and assessments:
        retry_pages = all_pages
        retry_frames = all_frames
    else:
        retry_pages = failed_pages
        retry_frames = failed_frames
    passed = sum(
        assessment.decision is LocalOcrQualityDecision.PASS
        for assessment in assessments
    )
    failed = len(assessments) - passed
    if not assessments:
        decision = LocalOcrQualityDecision.NOT_APPLICABLE
        retry_pages = ()
        retry_frames = ()
    elif failed or structural_issue_codes:
        decision = LocalOcrQualityDecision.FAIL
    else:
        decision = LocalOcrQualityDecision.PASS
    return LocalOcrQualitySummary(
        policy_fingerprint=local_ocr_quality_policy_fingerprint(policy),
        decision=decision,
        evaluated_input_count=len(assessments),
        passed_input_count=passed,
        failed_input_count=failed,
        evaluated_pages=_positive_sorted_unique(all_pages),
        evaluated_frames=_positive_sorted_unique(all_frames),
        issue_counts_by_code=count_evidence,
        reason_codes=tuple(item.code for item in count_evidence),
        failed_pages=_positive_sorted_unique(failed_pages),
        failed_frames=_positive_sorted_unique(failed_frames),
        retry_recommended=bool(retry_pages or retry_frames),
        recommended_retry_pages=_positive_sorted_unique(retry_pages),
        recommended_retry_frames=_positive_sorted_unique(retry_frames),
        character_count=sum(item.character_count for item in assessments),
        region_count=sum(item.region_count for item in assessments),
        confidence_weighted_character_count=sum(
            item.confidence_weighted_character_count for item in assessments
        ),
        low_confidence_character_count=sum(
            item.low_confidence_character_count for item in assessments
        ),
        suspicious_character_count=sum(
            item.suspicious_character_count for item in assessments
        ),
        region_area_numerator=sum(item.region_area_numerator for item in assessments),
        region_area_denominator=sum(
            item.region_area_denominator for item in assessments
        ),
        required_field_count=required_field_count,
        missing_required_field_count=missing_required_field_count,
        ambiguous_required_field_count=ambiguous_required_field_count,
        constrained_required_field_issue_count=(constrained_required_field_issue_count),
        table_count=table_count,
        table_cell_count=table_cell_count,
        empty_table_cell_count=empty_table_cell_count,
    )


def _ordered_unique_issues(
    issues: tuple[LocalOcrQualityIssueCode, ...],
) -> tuple[LocalOcrQualityIssueCode, ...]:
    return tuple(sorted(set(issues), key=_ISSUE_POSITION.__getitem__))


def _expected_intrinsic_issues(
    assessment: LocalOcrInputQualityAssessment,
    policy: LocalOcrIntrinsicQualityPolicy,
) -> tuple[LocalOcrQualityIssueCode, ...]:
    return _intrinsic_issues(
        policy=policy,
        character_count=assessment.character_count,
        region_count=assessment.region_count,
        confidence_weighted_character_count=(
            assessment.confidence_weighted_character_count
        ),
        low_confidence_character_count=assessment.low_confidence_character_count,
        suspicious_character_count=assessment.suspicious_character_count,
        region_area_numerator=assessment.region_area_numerator,
        region_area_denominator=assessment.region_area_denominator,
    )


def _intrinsic_issues(
    *,
    policy: LocalOcrIntrinsicQualityPolicy,
    character_count: int,
    region_count: int,
    confidence_weighted_character_count: int,
    low_confidence_character_count: int,
    suspicious_character_count: int,
    region_area_numerator: int,
    region_area_denominator: int,
) -> tuple[LocalOcrQualityIssueCode, ...]:
    issues: list[LocalOcrQualityIssueCode] = []
    mean_confidence_micro = _ratio_micro_from_fraction(
        confidence_weighted_character_count,
        character_count * LOCAL_OCR_QUALITY_CONFIDENCE_SCALE,
    )
    low_confidence_micro = _ratio_micro_from_fraction(
        low_confidence_character_count,
        character_count,
    )
    suspicious_micro = _ratio_micro_from_fraction(
        suspicious_character_count,
        character_count,
    )
    region_area_micro = _ratio_micro_from_fraction(
        region_area_numerator,
        region_area_denominator,
    )
    if region_count == 0 or character_count == 0:
        issues.append(LocalOcrQualityIssueCode.EMPTY_RESULT)
    minimum_characters = policy.minimum_characters_per_input
    if minimum_characters is not None and character_count < minimum_characters:
        issues.append(LocalOcrQualityIssueCode.INSUFFICIENT_TEXT)
    minimum_confidence = policy.minimum_mean_confidence
    if (
        minimum_confidence is not None
        and character_count > 0
        and mean_confidence_micro < _ratio_micro(minimum_confidence)
    ):
        issues.append(LocalOcrQualityIssueCode.LOW_CONFIDENCE)
    maximum_low_ratio = policy.maximum_low_confidence_character_ratio
    if (
        maximum_low_ratio is not None
        and character_count > 0
        and low_confidence_micro > _ratio_micro(maximum_low_ratio)
    ):
        issues.append(LocalOcrQualityIssueCode.EXCESSIVE_LOW_CONFIDENCE_TEXT)
    maximum_suspicious = policy.maximum_suspicious_character_ratio
    if (
        maximum_suspicious is not None
        and character_count > 0
        and suspicious_micro > _ratio_micro(maximum_suspicious)
    ):
        issues.append(LocalOcrQualityIssueCode.GARBLED_TEXT)
    minimum_area = policy.minimum_region_area_ratio
    if minimum_area is not None and region_area_micro < _ratio_micro(minimum_area):
        issues.append(LocalOcrQualityIssueCode.INSUFFICIENT_REGION_COVERAGE)
    return tuple(issues)


def _expected_structured_issues(
    *,
    policy: LocalOcrStructuredQualityPolicy | None,
    has_local_inputs: bool,
    missing_required_field_count: int,
    table_count: int,
    table_cell_count: int,
    empty_table_cell_count: int,
) -> tuple[LocalOcrQualityIssueCode, ...]:
    if policy is None or not has_local_inputs:
        return ()
    issues: list[LocalOcrQualityIssueCode] = []
    if (
        policy.maximum_missing_required_fields is not None
        and missing_required_field_count > policy.maximum_missing_required_fields
    ):
        issues.append(LocalOcrQualityIssueCode.REQUIRED_FIELDS_MISSING)
    table_incomplete = (
        policy.minimum_table_count is not None
        and table_count < policy.minimum_table_count
    )
    if policy.maximum_empty_table_cell_ratio is not None:
        empty_ratio_micro = _ratio_micro_from_fraction(
            empty_table_cell_count,
            table_cell_count,
        )
        table_incomplete = (
            table_incomplete
            or table_cell_count == 0
            or empty_ratio_micro > _ratio_micro(policy.maximum_empty_table_cell_ratio)
        )
    if table_incomplete:
        issues.append(LocalOcrQualityIssueCode.TABLE_INCOMPLETE)
    return tuple(issues)


def _ordered_issue_counts(
    counts: tuple[LocalOcrQualityIssueCount, ...],
) -> tuple[LocalOcrQualityIssueCount, ...]:
    return tuple(
        sorted(
            {item.code: item for item in counts}.values(),
            key=lambda item: _ISSUE_POSITION[item.code],
        )
    )


def _validate_quality_count_evidence(
    *,
    decision: LocalOcrQualityDecision,
    evaluated_input_count: int,
    passed_input_count: int,
    failed_input_count: int,
    issue_counts_by_code: tuple[LocalOcrQualityIssueCount, ...],
    evaluated_pages: tuple[int, ...],
    evaluated_frames: tuple[int, ...],
    failed_pages: tuple[int, ...],
    failed_frames: tuple[int, ...],
    retry_recommended: bool,
    recommended_retry_pages: tuple[int, ...],
    recommended_retry_frames: tuple[int, ...],
    character_count: int,
    region_count: int,
    required_field_count: int,
    missing_required_field_count: int,
    ambiguous_required_field_count: int,
    constrained_required_field_issue_count: int,
    table_count: int,
    table_cell_count: int,
    empty_table_cell_count: int,
) -> None:
    """Validate shared report/summary count, decision, and retry invariants."""
    counts = {item.code: item.count for item in issue_counts_by_code}
    intrinsic_total = sum(
        count for code, count in counts.items() if code in _INTRINSIC_ISSUES
    )
    structural_present = any(code in _STRUCTURED_ISSUES for code in counts)
    if any(count != 1 for code, count in counts.items() if code in _STRUCTURED_ISSUES):
        raise ValueError("Local OCR structured issue count is inconsistent")
    empty_count = counts.get(LocalOcrQualityIssueCode.EMPTY_RESULT, 0)
    intrinsic_counts = (
        count for code, count in counts.items() if code in _INTRINSIC_ISSUES
    )
    if (
        any(count > failed_input_count for count in intrinsic_counts)
        or (failed_input_count == 0 and intrinsic_total)
        or (failed_input_count > 0 and intrinsic_total < failed_input_count)
    ):
        raise ValueError("Local OCR intrinsic issue counts are inconsistent")
    if empty_count > failed_input_count:
        raise ValueError("Local OCR empty-result issue count is inconsistent")
    if (
        empty_count == evaluated_input_count
        and evaluated_input_count > 0
        and (
            character_count != 0
            or failed_input_count != evaluated_input_count
            or passed_input_count != 0
            or decision is not LocalOcrQualityDecision.FAIL
        )
    ):
        raise ValueError("Local OCR all-empty aggregate evidence is inconsistent")
    nonempty_input_count = evaluated_input_count - empty_count
    if character_count < nonempty_input_count or region_count < nonempty_input_count:
        raise ValueError("Local OCR aggregate content evidence is inconsistent")
    if evaluated_input_count > 0 and (character_count == 0 or region_count == 0):
        if (
            empty_count != evaluated_input_count
            or failed_input_count != evaluated_input_count
            or decision is not LocalOcrQualityDecision.FAIL
        ):
            raise ValueError("Local OCR all-empty evidence is inconsistent")
    required_states = (
        missing_required_field_count,
        ambiguous_required_field_count,
        constrained_required_field_issue_count,
    )
    if (
        any(count > required_field_count for count in required_states)
        or sum(required_states) > required_field_count
    ):
        raise ValueError("Local OCR required-field evidence is inconsistent")
    if (
        LocalOcrQualityIssueCode.REQUIRED_FIELDS_MISSING in counts
        and missing_required_field_count == 0
    ):
        raise ValueError("Local OCR missing-field issue lacks evidence")
    if (
        (table_count == 0 and table_cell_count != 0)
        or (table_cell_count == 0 and empty_table_cell_count != 0)
        or empty_table_cell_count > table_cell_count
    ):
        raise ValueError("Local OCR table evidence is inconsistent")
    expected_retry = (
        (evaluated_pages, evaluated_frames)
        if structural_present
        else (failed_pages, failed_frames)
    )
    if (recommended_retry_pages, recommended_retry_frames) != expected_retry:
        if structural_present:
            raise ValueError("Local OCR structured retry evidence is inconsistent")
        raise ValueError("Local OCR intrinsic retry evidence is inconsistent")
    retry_indexes = bool(recommended_retry_pages or recommended_retry_frames)
    if retry_recommended != retry_indexes:
        raise ValueError("Local OCR retry recommendation is inconsistent")
    if decision is LocalOcrQualityDecision.NOT_APPLICABLE:
        if (
            evaluated_input_count
            or passed_input_count
            or failed_input_count
            or issue_counts_by_code
            or retry_recommended
            or character_count
            or region_count
        ):
            raise ValueError("Not-applicable Local OCR evidence is inconsistent")
    elif evaluated_input_count == 0:
        raise ValueError("Applicable Local OCR quality requires evaluated inputs")
    elif decision is LocalOcrQualityDecision.PASS:
        if (
            failed_input_count
            or issue_counts_by_code
            or retry_recommended
            or character_count < evaluated_input_count
            or region_count < evaluated_input_count
        ):
            raise ValueError("Passing Local OCR quality evidence is inconsistent")
    elif not issue_counts_by_code or not retry_recommended:
        raise ValueError("Failing Local OCR quality evidence is incomplete")


def _positive_sorted_unique(values: tuple[int, ...]) -> tuple[int, ...]:
    if any(type(value) is not int or value < 1 for value in values):
        return ()
    return tuple(sorted(set(values)))


def _ratio_micro(value: float) -> int:
    canonical = Decimal(str(value)).quantize(
        Decimal("0.000001"),
        rounding=ROUND_HALF_UP,
    )
    return min(
        LOCAL_OCR_QUALITY_CONFIDENCE_SCALE,
        max(0, int(canonical * LOCAL_OCR_QUALITY_CONFIDENCE_SCALE)),
    )


def _rounded_ratio(numerator: int, denominator: int) -> float:
    return _ratio_micro_from_fraction(numerator, denominator) / (
        LOCAL_OCR_QUALITY_CONFIDENCE_SCALE
    )


def _ratio_micro_from_fraction(numerator: int, denominator: int) -> int:
    """Round one non-negative rational ratio to millionths using integer HALF_UP."""
    if denominator <= 0:
        return 0
    quotient, remainder = divmod(
        numerator * LOCAL_OCR_QUALITY_CONFIDENCE_SCALE,
        denominator,
    )
    if remainder * 2 >= denominator:
        quotient += 1
    return min(LOCAL_OCR_QUALITY_CONFIDENCE_SCALE, max(0, quotient))


def _canonical_ratio(value: float | None) -> float | None:
    """Return one canonical six-decimal HALF_UP ratio representation."""
    if value is None:
        return None
    result = float(
        Decimal(str(value)).quantize(
            Decimal("0.000001"),
            rounding=ROUND_HALF_UP,
        )
    )
    return 0.0 if result == 0 else result

"""Private helpers for immutable and safely serializable JSON metadata."""

from __future__ import annotations

import re
from collections.abc import Mapping
from pathlib import PurePosixPath, PureWindowsPath
from types import MappingProxyType
from typing import TYPE_CHECKING, cast

if TYPE_CHECKING:
    from pydantic import JsonValue

_SAFE_TOKEN_USAGE_KEYS = frozenset(
    {
        "allowpostresponselimitenforcement",
        "cachedinputtokens",
        "completiontokencount",
        "inputtokens",
        "maxinputtokens",
        "maxoutputtokens",
        "maxtotaltokens",
        "outputtokens",
        "prompttokencount",
        "reasoningtokens",
        "requirepreflightinputtokens",
        "tokencount",
        "tokenpolicy",
        "totaltokens",
    }
)
_SENSITIVE_KEY_SUFFIXES = (
    "authorization",
    "certificate",
    "credential",
    "credentials",
    "password",
    "passwd",
    "secret",
    "serviceaccountjson",
)
_SENSITIVE_KEY_FRAGMENTS = (
    "accesskey",
    "accesstoken",
    "authorization",
    "apitoken",
    "apikey",
    "authtoken",
    "bearertoken",
    "certificate",
    "clientsecret",
    "clienttoken",
    "credential",
    "idtoken",
    "oauthtoken",
    "passwd",
    "password",
    "privatekey",
    "refreshtoken",
    "sastoken",
    "secretaccesskey",
    "serviceaccountjson",
    "subscriptionkey",
    "tenantsecret",
)
_SENSITIVE_KEY_COMPONENTS = frozenset(
    {
        "authorization",
        "certificate",
        "credential",
        "credentials",
        "passwd",
        "password",
        "secret",
        "token",
    }
)
_SENSITIVE_KEYS = frozenset(
    {
        "authorization",
        "bearer",
        "clientsecret",
        "credential",
        "credentials",
        "password",
        "passwd",
        "secret",
        "serviceaccount",
        "token",
        "tenantsecret",
    }
)


def _normalize_metadata_key(key: str) -> str:
    """Normalize separators and camel-case spelling to lowercase alphanumerics."""
    separated = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", "_", key)
    return re.sub(r"[^a-z0-9]", "", separated.casefold())


def _metadata_key_components(key: str) -> tuple[str, ...]:
    """Split separators and camelCase into lowercase semantic components."""
    separated = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", "_", key)
    return tuple(
        component
        for component in re.split(r"[^a-z0-9]+", separated.casefold())
        if component
    )


def _is_sensitive_metadata_key(key: str) -> bool:
    """Recognize credential-shaped keys while allowing explicit usage metrics."""
    normalized = _normalize_metadata_key(key)
    if normalized in _SAFE_TOKEN_USAGE_KEYS:
        return False
    components = _metadata_key_components(key)
    return (
        normalized in _SENSITIVE_KEYS
        or normalized.endswith(_SENSITIVE_KEY_SUFFIXES)
        or any(component in _SENSITIVE_KEY_COMPONENTS for component in components)
        or any(fragment in normalized for fragment in _SENSITIVE_KEY_FRAGMENTS)
    )


def _looks_like_absolute_path(value: str) -> bool:
    """Return whether a string is an absolute local-path representation."""
    lowered = value.casefold()
    return (
        lowered.startswith("file://")
        or PurePosixPath(value).is_absolute()
        or PureWindowsPath(value).is_absolute()
    )


def validate_safe_metadata(value: Mapping[str, JsonValue]) -> None:
    """Reject credential-shaped keys and absolute paths recursively."""

    def validate_item(item: JsonValue) -> None:
        if isinstance(item, dict):
            for key, nested in item.items():
                if _looks_like_absolute_path(key):
                    msg = "metadata must not contain an absolute local path"
                    raise ValueError(msg)
                if _is_sensitive_metadata_key(key):
                    msg = "metadata contains a sensitive key"
                    raise ValueError(msg)
                validate_item(nested)
        elif isinstance(item, list):
            for nested in item:
                validate_item(nested)
        elif isinstance(item, str) and _looks_like_absolute_path(item):
            msg = "metadata must not contain an absolute local path"
            raise ValueError(msg)

    validate_item(dict(value))


def _freeze_json(value: JsonValue) -> JsonValue:
    """Recursively copy JSON data into immutable runtime containers."""
    if isinstance(value, dict):
        frozen = {key: _freeze_json(nested) for key, nested in value.items()}
        return cast("JsonValue", MappingProxyType(frozen))
    if isinstance(value, list):
        return cast("JsonValue", tuple(_freeze_json(nested) for nested in value))
    return value


def freeze_json_mapping(
    value: Mapping[str, JsonValue],
) -> Mapping[str, JsonValue]:
    """Return a deeply immutable copy of a JSON mapping."""
    frozen = {key: _freeze_json(nested) for key, nested in value.items()}
    return MappingProxyType(frozen)


def _thaw_json(value: object) -> JsonValue:
    """Convert immutable runtime metadata back to ordinary JSON containers."""
    if isinstance(value, Mapping):
        return {str(key): _thaw_json(nested) for key, nested in value.items()}
    if isinstance(value, tuple):
        return [_thaw_json(nested) for nested in value]
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    msg = "metadata contains a non-JSON value"
    raise TypeError(msg)


def thaw_json_mapping(
    value: Mapping[str, JsonValue],
) -> dict[str, JsonValue]:
    """Return a mutable JSON representation for Pydantic serialization."""
    return {key: _thaw_json(nested) for key, nested in value.items()}

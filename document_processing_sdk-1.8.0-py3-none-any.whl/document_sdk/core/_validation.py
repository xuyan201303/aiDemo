"""Private sanitized validation boundary shared by public SDK models."""

# ruff: noqa: PLR0913

from __future__ import annotations

import json
import math
from collections.abc import Mapping
from datetime import date, datetime, time
from decimal import Decimal
from typing import TYPE_CHECKING, Any, ClassVar, Self, cast

from pydantic import BaseModel, ValidationError

from document_sdk.core._exceptions import redact_exception
from document_sdk.core.errors import (  # noqa: TC001 - public runtime type hints.
    DocumentSdkError,
)

if TYPE_CHECKING:
    from pydantic._internal._model_construction import (
        ModelMetaclass as _BaseModelMetaclass,
    )
    from pydantic.config import ExtraValues

else:
    _BaseModelMetaclass = type(BaseModel)


def _require_expected_model_type(
    actual_type: type[object],
    expected_type: type[BaseModel],
) -> None:
    if not issubclass(actual_type, expected_type):
        message = "unexpected model type"
        raise TypeError(message)


def _unseen_projection_identities(
    value: object,
    seen: set[int] | None,
) -> set[int] | None:
    identities = seen if seen is not None else set()
    identity = id(value)
    if identity in identities:
        return None
    identities.add(identity)
    return identities


def _validate_projection_leaf(value: object, actual_type: type[object]) -> bool:
    if issubclass(actual_type, float):
        if not math.isfinite(cast("float", value)):
            message = "non-finite float"
            raise ValueError(message)
        return True
    if issubclass(actual_type, Decimal):
        if not Decimal.is_finite(cast("Decimal", value)):
            message = "non-finite decimal"
            raise ValueError(message)
        return True
    return issubclass(actual_type, (date, datetime, time)) or not issubclass(
        actual_type,
        (Mapping, list, tuple),
    )


def _require_finite_projection(
    value: object,
    *,
    seen: set[int] | None = None,
) -> None:
    """Reject non-finite numbers in one trusted Python serialization."""
    actual_type = type(value)
    if _validate_projection_leaf(value, actual_type):
        return

    identities = _unseen_projection_identities(value, seen)
    if identities is None:
        return
    if issubclass(actual_type, Mapping):
        mapping = cast("Mapping[object, object]", value)
        for key, item in mapping.items():
            _require_finite_projection(key, seen=identities)
            _require_finite_projection(item, seen=identities)
        return
    sequence = cast("list[object] | tuple[object, ...]", value)
    for item in sequence:
        _require_finite_projection(item, seen=identities)


def _revalidate_model_instance_json[ModelT: BaseModel](
    value: BaseModel,
    expected_type: type[ModelT],
    stable_error_message: str,
) -> ModelT:
    """Revalidate a model instance without lossy non-finite JSON coercion."""
    try:
        actual_type = type(value)
        _require_expected_model_type(actual_type, expected_type)
        serializer = expected_type.__pydantic_serializer__
        payload = serializer.to_python(
            value,
            mode="python",
            round_trip=True,
            warnings="error",
        )
        _require_finite_projection(payload)
        serializer.to_json(
            value,
            round_trip=True,
            warnings="error",
            ensure_ascii=False,
        )
        return cast(
            "ModelT",
            expected_type.__pydantic_validator__.validate_python(payload),
        )
    except Exception as exc:  # noqa: BLE001 - sanitized public boundary.
        redact_exception(exc)
    raise ValueError(stable_error_message) from ValueError("redacted")


class _SanitizedModelMetaclass(_BaseModelMetaclass):
    _validation_error_type: type[DocumentSdkError]
    _validation_error_message: str

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        try:
            return super().__call__(*args, **kwargs)
        except ValidationError as exc:
            redact_exception(exc)
        raise self._validation_error_type(
            self._validation_error_message
        ) from ValueError("redacted")


class SanitizedPublicModel(BaseModel, metaclass=_SanitizedModelMetaclass):
    """Prevent submitted model payloads from escaping through validation errors."""

    _validation_error_type: ClassVar[type[DocumentSdkError]]
    _validation_error_message: ClassVar[str]

    @classmethod
    def model_validate(
        cls,
        obj: Any,
        *,
        strict: bool | None = None,
        extra: ExtraValues | None = None,
        from_attributes: bool | None = None,
        context: Any | None = None,
        by_alias: bool | None = None,
        by_name: bool | None = None,
    ) -> Self:
        try:
            if from_attributes is not True and type(obj) is dict:
                try:
                    payload = json.dumps(
                        obj,
                        allow_nan=False,
                        ensure_ascii=False,
                        separators=(",", ":"),
                    )
                except (TypeError, ValueError):
                    pass
                else:
                    return cls.model_validate_json(
                        payload,
                        strict=strict,
                        extra=extra,
                        context=context,
                        by_alias=by_alias,
                        by_name=by_name,
                    )
            return super().model_validate(
                obj,
                strict=strict,
                extra=extra,
                from_attributes=from_attributes,
                context=context,
                by_alias=by_alias,
                by_name=by_name,
            )
        except ValidationError as exc:
            redact_exception(exc)
        raise cls._validation_error_type(cls._validation_error_message) from ValueError(
            "redacted"
        )

    @classmethod
    def model_validate_json(
        cls,
        json_data: str | bytes | bytearray,
        *,
        strict: bool | None = None,
        extra: ExtraValues | None = None,
        context: Any | None = None,
        by_alias: bool | None = None,
        by_name: bool | None = None,
    ) -> Self:
        try:
            return super().model_validate_json(
                json_data,
                strict=strict,
                extra=extra,
                context=context,
                by_alias=by_alias,
                by_name=by_name,
            )
        except ValidationError as exc:
            redact_exception(exc)
        raise cls._validation_error_type(cls._validation_error_message) from ValueError(
            "redacted"
        )

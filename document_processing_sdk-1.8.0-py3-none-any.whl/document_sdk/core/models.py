"""Stable, serializable public data models."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from datetime import date, datetime, time
from decimal import Decimal
from enum import StrEnum
from types import MappingProxyType
from typing import Annotated, Literal, Self

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    StringConstraints,
    ValidationInfo,
    field_serializer,
    field_validator,
    model_validator,
)

from document_sdk.core._excel_coordinates import (
    MAX_EXCEL_COLUMN,
    MAX_EXCEL_ROW,
    excel_range_bounds,
    format_excel_range,
    normalize_excel_coordinate,
    normalize_excel_range,
)

type NonEmptyString = Annotated[
    str,
    StringConstraints(strip_whitespace=True, min_length=1),
]
type WorksheetName = Annotated[
    str,
    StringConstraints(
        min_length=1,
        max_length=31,
        pattern=r"^[^\\/*?:\[\]\x00-\x1f]+$",
    ),
]
type ExcelValue = str | int | float | bool | date | datetime | time | None
MAX_WORKSHEET_NAME_LENGTH = 31
MAX_EXCEL_COLUMN_NAME_LENGTH = 3


class SdkModel(BaseModel):
    """Base for strict, immutable SDK value models."""

    model_config = ConfigDict(
        allow_inf_nan=False,
        extra="forbid",
        frozen=True,
        hide_input_in_errors=True,
        strict=True,
    )


class FileFingerprint(SdkModel):
    """A stable cryptographic fingerprint for file contents."""

    algorithm: Literal["sha256"] = "sha256"
    value: str = Field(pattern=r"^[0-9a-f]{64}$")


class FileDescriptor(SdkModel):
    """Safe file metadata that deliberately excludes the local path."""

    file_id: NonEmptyString
    filename: NonEmptyString
    extension: str
    mime_type: NonEmptyString
    size_bytes: int = Field(ge=0)
    fingerprint: FileFingerprint

    @field_validator("filename")
    @classmethod
    def validate_safe_filename(cls, value: str) -> str:
        """Reject path components so serialization cannot expose a local path."""
        if value in {".", ".."} or "/" in value or "\\" in value:
            msg = "filename must not contain path components"
            raise ValueError(msg)
        return value


class PageDimensions(SdkModel):
    """Original page geometry and clockwise rotation."""

    width: float = Field(gt=0)
    height: float = Field(gt=0)
    unit: Literal["points", "pixels"] = "points"
    rotation: Literal[0, 90, 180, 270] = 0
    angle_degrees: float | None = Field(default=None, ge=-180, le=180)


class BoundingBox(SdkModel):
    """Top-left-origin normalized coordinates within a page."""

    left: float = Field(ge=0, le=1)
    top: float = Field(ge=0, le=1)
    right: float = Field(ge=0, le=1)
    bottom: float = Field(ge=0, le=1)

    @model_validator(mode="after")
    def validate_order(self) -> Self:
        """Reject horizontally or vertically reversed coordinates."""
        if self.left > self.right:
            msg = "left must be less than or equal to right"
            raise ValueError(msg)
        if self.top > self.bottom:
            msg = "top must be less than or equal to bottom"
            raise ValueError(msg)
        return self


class PdfSourceReference(SdkModel):
    """A location in a PDF using a one-based page number."""

    source_type: Literal["pdf"] = "pdf"
    file_id: NonEmptyString
    page_number: int = Field(ge=1)
    bounding_box: BoundingBox | None = None


class ImageSourceReference(SdkModel):
    """A location in an image using a one-based frame number."""

    source_type: Literal["image"] = "image"
    file_id: NonEmptyString
    frame_number: int = Field(ge=1)
    bounding_box: BoundingBox | None = None


class ExcelSourceReference(SdkModel):
    """A sheet and cell or range location in an Excel workbook."""

    source_type: Literal["excel"] = "excel"
    file_id: NonEmptyString
    sheet_name: WorksheetName
    cell_range: NonEmptyString

    @field_validator("cell_range")
    @classmethod
    def validate_cell_range(cls, value: str) -> str:
        """Validate Excel bounds and normalize the range to uppercase."""
        return normalize_excel_range(value)


class DocxSourceReference(SdkModel):
    """A structural location in one DOCX story without fabricated pagination."""

    source_type: Literal["docx"] = "docx"
    file_id: NonEmptyString
    source_role: Literal["story", "section", "custom_property"] = "story"
    package_part: NonEmptyString | None = None
    story_type: NonEmptyString
    story_id: NonEmptyString
    block_index: int = Field(ge=0)
    paragraph_index: int | None = Field(default=None, ge=0)
    run_index: int | None = Field(default=None, ge=0)
    table_index: int | None = Field(default=None, ge=0)
    table_path: tuple[Annotated[int, Field(ge=0)], ...] = ()
    row_index: int | None = Field(default=None, ge=0)
    cell_index: int | None = Field(default=None, ge=0)
    character_start: int | None = Field(default=None, ge=0)
    character_end: int | None = Field(default=None, ge=0)
    resource_id: NonEmptyString | None = None

    @model_validator(mode="after")
    def validate_character_range(self) -> Self:
        """Require complete, ordered character offsets when either is present."""
        if (self.character_start is None) != (self.character_end is None):
            msg = "DOCX character offsets must be both present or absent"
            raise ValueError(msg)
        if (
            self.character_start is not None
            and self.character_end is not None
            and self.character_end < self.character_start
        ):
            msg = "DOCX character offsets must be ordered"
            raise ValueError(msg)
        if self.table_path and self.table_index != self.table_path[-1]:
            msg = "DOCX table index must match the final table path component"
            raise ValueError(msg)
        if (
            self.row_index is not None or self.cell_index is not None
        ) and not self.table_path:
            msg = "DOCX table row and cell locations require a table path"
            raise ValueError(msg)
        if self.source_role == "custom_property" and self.package_part is None:
            msg = "DOCX custom-property sources require a package part"
            raise ValueError(msg)
        return self


type SourceReference = Annotated[
    PdfSourceReference
    | ImageSourceReference
    | ExcelSourceReference
    | DocxSourceReference,
    Field(discriminator="source_type"),
]
type DocumentSourceReference = Annotated[
    PdfSourceReference | ImageSourceReference | DocxSourceReference,
    Field(discriminator="source_type"),
]


def _document_source_number(source: SourceReference) -> int | None:
    """Return a PDF page or image frame number, excluding workbook sources."""
    if isinstance(source, PdfSourceReference):
        return source.page_number
    if isinstance(source, ImageSourceReference):
        return source.frame_number
    return None


def _source_sort_key(source: DocumentSourceReference) -> tuple[object, ...]:
    """Return a stable ordering key for PDF/image source evidence."""
    if isinstance(source, DocxSourceReference):
        return (
            source.source_type,
            source.source_role,
            source.package_part or "",
            source.story_type,
            source.story_id,
            source.block_index,
            source.paragraph_index if source.paragraph_index is not None else -1,
            source.run_index if source.run_index is not None else -1,
            source.table_index if source.table_index is not None else -1,
            source.table_path,
            source.row_index if source.row_index is not None else -1,
            source.cell_index if source.cell_index is not None else -1,
            source.character_start if source.character_start is not None else -1,
            source.character_end if source.character_end is not None else -1,
            source.resource_id or "",
        )
    number = _document_source_number(source)
    box = source.bounding_box
    coordinates = (
        (-1.0, -1.0, -1.0, -1.0)
        if box is None
        else (box.left, box.top, box.right, box.bottom)
    )
    return (source.source_type, number, *coordinates)


def _normalized_sources(
    sources: tuple[DocumentSourceReference, ...],
) -> tuple[DocumentSourceReference, ...]:
    """Deduplicate and deterministically order document source evidence."""
    unique = {source.model_dump_json(): source for source in sources}
    normalized = tuple(sorted(unique.values(), key=_source_sort_key))
    if normalized and len({source.file_id for source in normalized}) != 1:
        msg = "document element sources must use one file_id"
        raise ValueError(msg)
    return normalized


class DocumentContentScope(SdkModel):
    """One unambiguous processor-owned concatenated-content offset space."""

    scope_id: NonEmptyString
    content: str
    indexed_length: int = Field(ge=0)
    string_index_type: Literal[
        "textElements",
        "unicodeCodePoint",
        "utf16CodeUnit",
    ]
    origin: Literal["local_native", "ocr_provider"]
    page_numbers: tuple[int, ...] = ()
    frame_numbers: tuple[int, ...] = ()
    provider_name: NonEmptyString | None = None
    profile_id: NonEmptyString | None = None
    model_id: NonEmptyString | None = None

    @model_validator(mode="after")
    def validate_scope(self) -> Self:
        """Require one deterministic location domain and safe provider identity."""
        expected_length = None
        if self.string_index_type == "unicodeCodePoint":
            expected_length = len(self.content)
        elif self.string_index_type == "utf16CodeUnit":
            expected_length = len(self.content.encode("utf-16-le")) // 2
        if expected_length is not None and self.indexed_length != expected_length:
            msg = "content scope indexed_length does not match its index type"
            raise ValueError(msg)
        if bool(self.page_numbers) == bool(self.frame_numbers):
            msg = "content scope must identify pages or frames, but not both"
            raise ValueError(msg)
        numbers = self.page_numbers or self.frame_numbers
        if any(type(number) is not int or number < 1 for number in numbers):
            msg = "content scope numbers must be positive one-based integers"
            raise ValueError(msg)
        if numbers != tuple(sorted(set(numbers))):
            msg = "content scope numbers must be sorted and unique"
            raise ValueError(msg)
        identities = (self.provider_name, self.profile_id, self.model_id)
        if self.origin == "local_native" and any(
            value is not None for value in identities
        ):
            msg = "local content scopes cannot contain Provider identity"
            raise ValueError(msg)
        if self.origin == "ocr_provider" and (
            self.provider_name is None or self.profile_id is None
        ):
            msg = "OCR content scopes require Provider and profile identity"
            raise ValueError(msg)
        return self


class DocumentSpan(SdkModel):
    """A bounded range in one declared document content scope."""

    scope_id: NonEmptyString
    offset: int = Field(ge=0)
    length: int = Field(ge=0)


class DocumentElementReference(SdkModel):
    """A provider-independent reference to another mapped document element."""

    element_type: Literal[
        "text_block",
        "table",
        "paragraph",
        "key_value_pair",
        "figure",
        "section",
        "analyzed_document",
    ]
    element_id: NonEmptyString


class _MultiSourceElement(SdkModel):
    """Shared deterministic multi-region evidence behavior."""

    sources: tuple[DocumentSourceReference, ...] = ()

    @field_validator("sources")
    @classmethod
    def normalize_sources(
        cls,
        value: tuple[DocumentSourceReference, ...],
    ) -> tuple[DocumentSourceReference, ...]:
        """Store all unique regions in deterministic order."""
        return _normalized_sources(value)

    @property
    def source(self) -> DocumentSourceReference | None:
        """Return the deterministic primary source without discarding evidence."""
        return self.sources[0] if self.sources else None


class DocumentParagraph(_MultiSourceElement):
    """Reading-order paragraph and optional semantic role."""

    element_id: NonEmptyString
    content: str
    role: str | None = None
    spans: tuple[DocumentSpan, ...] = ()


class DocumentSelectionMark(_MultiSourceElement):
    """One selected or unselected page mark."""

    element_id: NonEmptyString
    state: Literal["selected", "unselected"]
    confidence: float | None = Field(default=None, ge=0, le=1)
    span: DocumentSpan


class DocumentBarcode(_MultiSourceElement):
    """One provider-observed barcode without business interpretation."""

    element_id: NonEmptyString
    kind: NonEmptyString
    value: str
    confidence: float | None = Field(default=None, ge=0, le=1)
    span: DocumentSpan


class DocumentFormula(_MultiSourceElement):
    """One unevaluated inline or display formula."""

    element_id: NonEmptyString
    kind: NonEmptyString
    value: str
    confidence: float | None = Field(default=None, ge=0, le=1)
    span: DocumentSpan


class DocumentLanguage(_MultiSourceElement):
    """A detected locale over one or more content spans."""

    locale: NonEmptyString
    confidence: float | None = Field(default=None, ge=0, le=1)
    spans: tuple[DocumentSpan, ...] = ()


class DocumentTextStyle(_MultiSourceElement):
    """Observed text styling over one or more content spans."""

    is_handwritten: bool | None = None
    font_family: str | None = None
    font_style: str | None = None
    font_weight: str | None = None
    foreground_color: str | None = None
    background_color: str | None = None
    confidence: float | None = Field(default=None, ge=0, le=1)
    spans: tuple[DocumentSpan, ...] = ()


class DocumentKeyValueElement(_MultiSourceElement):
    """One key or value with complete content evidence."""

    content: str
    spans: tuple[DocumentSpan, ...] = ()


class DocumentKeyValuePair(_MultiSourceElement):
    """One mapped key and optional value."""

    element_id: NonEmptyString
    key: DocumentKeyValueElement
    value: DocumentKeyValueElement | None = None
    confidence: float | None = Field(default=None, ge=0, le=1)
    spans: tuple[DocumentSpan, ...] = ()


class DocumentCaption(_MultiSourceElement):
    """Figure or table caption with resolved child references."""

    element_id: NonEmptyString
    content: str
    spans: tuple[DocumentSpan, ...] = ()
    elements: tuple[DocumentElementReference, ...] = ()


class DocumentFootnote(_MultiSourceElement):
    """Figure or table footnote with resolved child references."""

    element_id: NonEmptyString
    content: str
    spans: tuple[DocumentSpan, ...] = ()
    elements: tuple[DocumentElementReference, ...] = ()


class DocumentFigure(_MultiSourceElement):
    """A figure descriptor without downloaded figure image bytes."""

    element_id: NonEmptyString
    spans: tuple[DocumentSpan, ...] = ()
    elements: tuple[DocumentElementReference, ...] = ()
    caption: DocumentCaption | None = None
    footnotes: tuple[DocumentFootnote, ...] = ()


class DocumentSection(_MultiSourceElement):
    """A reading-order section with resolved child references."""

    element_id: NonEmptyString
    spans: tuple[DocumentSpan, ...] = ()
    elements: tuple[DocumentElementReference, ...] = ()


class DocumentCurrencyValue(SdkModel):
    """A precision-preserving currency value."""

    amount: Decimal
    currency_code: str | None = None
    currency_symbol: str | None = None


class DocumentAddressValue(SdkModel):
    """Documented structured address components."""

    house_number: str | None = None
    po_box: str | None = None
    road: str | None = None
    city: str | None = None
    state: str | None = None
    postal_code: str | None = None
    country_region: str | None = None
    street_address: str | None = None
    unit: str | None = None
    city_district: str | None = None
    state_district: str | None = None
    suburb: str | None = None
    house: str | None = None
    level: str | None = None


class DocumentField(_MultiSourceElement):
    """One strongly typed recursive analyzed-document field."""

    field_type: NonEmptyString
    normalization_status: (
        Literal[
            "normalized",
            "raw_only",
            "unsupported_type",
        ]
        | None
    ) = None
    value: (
        str
        | date
        | time
        | Decimal
        | int
        | bool
        | tuple[str, ...]
        | tuple[DocumentField, ...]
        | Mapping[str, DocumentField]
        | DocumentCurrencyValue
        | DocumentAddressValue
        | None
    ) = None
    content: str | None = None
    confidence: float | None = Field(default=None, ge=0, le=1)
    spans: tuple[DocumentSpan, ...] = ()
    unsupported: bool = False

    @field_validator("value", mode="before")
    @classmethod
    def restore_json_scalar(  # noqa: C901, PLR0911
        cls,
        value: object,
        info: ValidationInfo,
    ) -> object:
        """Restore JSON scalar encodings without coercing Python callers."""
        if info.mode != "json" or not isinstance(value, str):
            if info.mode != "json":
                return value
            field_type = info.data.get("field_type")
            if field_type == "array" and isinstance(value, list):
                return tuple(
                    cls.model_validate_json(json.dumps(item)) for item in value
                )
            if field_type == "object" and isinstance(value, dict):
                return {
                    name: cls.model_validate_json(json.dumps(item))
                    for name, item in value.items()
                }
            if field_type == "selectionGroup" and isinstance(value, list):
                return tuple(value)
            if field_type == "currency" and isinstance(value, dict):
                currency = dict(value)
                if isinstance(currency.get("amount"), str):
                    currency["amount"] = Decimal(currency["amount"])
                return DocumentCurrencyValue.model_validate(currency)
            if field_type == "address" and isinstance(value, dict):
                return DocumentAddressValue.model_validate(value)
            return value
        field_type = info.data.get("field_type")
        if field_type == "date":
            return date.fromisoformat(value)
        if field_type == "time":
            return time.fromisoformat(value)
        if field_type == "number":
            return Decimal(value)
        return value

    @model_validator(mode="after")
    def validate_typed_value(self) -> Self:
        """Require the normalized value shape declared by field_type."""
        value = self.value
        status = self.normalization_status
        if status is None:
            status = (
                "unsupported_type"
                if self.unsupported
                else ("raw_only" if value is None else "normalized")
            )
            object.__setattr__(self, "normalization_status", status)
        valid = {
            "string": isinstance(value, str),
            "date": isinstance(value, date) and not isinstance(value, datetime),
            "time": isinstance(value, time),
            "phoneNumber": isinstance(value, str),
            "number": isinstance(value, Decimal),
            "integer": type(value) is int,
            "selectionMark": isinstance(value, str),
            "countryRegion": isinstance(value, str),
            "signature": isinstance(value, str),
            "array": isinstance(value, tuple)
            and all(isinstance(item, DocumentField) for item in value),
            "object": isinstance(value, Mapping)
            and all(
                isinstance(name, str) and isinstance(item, DocumentField)
                for name, item in value.items()
            ),
            "currency": isinstance(value, DocumentCurrencyValue),
            "address": isinstance(value, DocumentAddressValue),
            "boolean": type(value) is bool,
            "selectionGroup": isinstance(value, tuple)
            and all(isinstance(item, str) for item in value),
        }
        if self.field_type in valid:
            if status == "normalized" and (
                self.unsupported or not valid[self.field_type]
            ):
                msg = "document field value does not match field_type"
                raise ValueError(msg)
            if status == "raw_only" and (self.unsupported or value is not None):
                msg = "raw-only document fields cannot contain a normalized value"
                raise ValueError(msg)
            if status == "unsupported_type":
                msg = "known document field types cannot be unsupported"
                raise ValueError(msg)
        elif status != "unsupported_type" or not self.unsupported or value is not None:
            msg = "unknown document field types require an unsupported value"
            raise ValueError(msg)
        if self.field_type == "object" and isinstance(value, Mapping):
            object.__setattr__(self, "value", MappingProxyType(dict(value)))
        return self

    @field_serializer("value")
    def serialize_value(self, value: object) -> object:
        """Serialize immutable object fields as ordinary JSON mappings."""
        if isinstance(value, Mapping):
            return dict(value)
        return value


class AnalyzedDocument(_MultiSourceElement):
    """One classified document and its recursively typed fields."""

    element_id: NonEmptyString
    document_type: NonEmptyString
    confidence: float | None = Field(default=None, ge=0, le=1)
    spans: tuple[DocumentSpan, ...] = ()
    fields: Mapping[str, DocumentField] = Field(default_factory=dict)

    @model_validator(mode="after")
    def freeze_fields(self) -> Self:
        """Freeze the field-name mapping while preserving deterministic order."""
        normalized = dict(sorted(self.fields.items()))
        if any(not name for name in normalized):
            msg = "analyzed document field names must not be empty"
            raise ValueError(msg)
        object.__setattr__(self, "fields", MappingProxyType(normalized))
        return self

    @field_serializer("fields")
    def serialize_fields(
        self,
        value: Mapping[str, DocumentField],
    ) -> dict[str, DocumentField]:
        """Serialize immutable fields as an ordinary JSON object."""
        return dict(value)


class CloudExecutionAttemptStatus(StrEnum):
    """Content-safe lifecycle state for one logical cloud operation."""

    NOT_SUBMITTED = "not_submitted"
    FAILED_BEFORE_SUBMIT = "failed_before_submit"
    SUBMITTED = "submitted"
    COMPLETED = "completed"
    POSSIBLY_PAID = "possibly_paid"


class CloudCancellationStatus(StrEnum):
    """Best-effort cancellation outcome without implying billing reversal."""

    NOT_ATTEMPTED = "not_attempted"
    NOT_SUPPORTED = "not_supported"
    REQUESTED = "requested"
    SUCCEEDED = "succeeded"
    FAILED = "failed"


class CloudExecutionPolicy(SdkModel):
    """Provider-neutral, explicitly authorized finite cloud execution policy."""

    allow_cloud_execution: bool = False
    allow_cloud_fallback: bool = False
    max_logical_cloud_operations: int = Field(
        default=0, strict=True, ge=0, le=1_000_000
    )
    max_submitted_operations: int = Field(default=0, strict=True, ge=0, le=1_000_000)
    max_paid_or_possibly_paid_operations: int = Field(
        default=0,
        strict=True,
        ge=0,
        le=1_000_000,
    )
    max_pages_or_frames: int = Field(default=0, strict=True, ge=0, le=1_000_000)
    max_input_bytes: int = Field(default=0, strict=True, ge=0, le=2_000_000_000)
    allow_retry_possibly_paid: bool = False
    policy_version: Literal["cloud-execution-policy-v2"] = "cloud-execution-policy-v2"

    @model_validator(mode="after")
    def validate_authorization_and_bounds(self) -> Self:
        """Reject partial authorization and internally inconsistent budgets."""
        operation_limits = (
            self.max_logical_cloud_operations,
            self.max_submitted_operations,
            self.max_paid_or_possibly_paid_operations,
        )
        if not self.allow_cloud_execution:
            if (
                self.allow_cloud_fallback
                or self.allow_retry_possibly_paid
                or any(operation_limits)
                or self.max_pages_or_frames
                or self.max_input_bytes
            ):
                msg = "Cloud execution limits require explicit cloud authorization"
                raise ValueError(msg)
            return self
        if any(limit == 0 for limit in operation_limits):
            msg = "Authorized cloud execution requires positive operation limits"
            raise ValueError(msg)
        if not (self.max_pages_or_frames and self.max_input_bytes):
            msg = "Authorized cloud execution requires bounded page/frame input"
            raise ValueError(msg)
        if self.max_submitted_operations < self.max_logical_cloud_operations:
            msg = "Cloud submitted-operation limit is below logical limit"
            raise ValueError(msg)
        if (
            self.max_paid_or_possibly_paid_operations
            < self.max_logical_cloud_operations
            or self.max_paid_or_possibly_paid_operations > self.max_submitted_operations
        ):
            msg = "Cloud paid-operation limit is inconsistent"
            raise ValueError(msg)
        if self.allow_retry_possibly_paid and (
            self.max_submitted_operations <= self.max_logical_cloud_operations
            or self.max_paid_or_possibly_paid_operations
            <= self.max_logical_cloud_operations
        ):
            msg = "Possibly-paid retry requires additional submit budget"
            raise ValueError(msg)
        return self

    def fingerprint(self) -> str:
        """Return a domain-separated deterministic policy fingerprint."""
        payload = json.dumps(
            self.model_dump(mode="json"),
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        ).encode()
        return hashlib.sha256(b"document-sdk:cloud-policy:v2\0" + payload).hexdigest()


class CloudExecutionAttemptEvidence(SdkModel):
    """Content-free evidence for one attempted cloud execution boundary."""

    evidence_version: Literal["cloud-execution-attempt-v3"]
    provider_name: NonEmptyString
    profile_id: NonEmptyString
    model_id: NonEmptyString | None = None
    api_version: NonEmptyString | None = None
    provider_resource_identity: str = Field(pattern=r"^[0-9a-f]{64}$")
    policy_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    status: CloudExecutionAttemptStatus
    logical_operation_count: int = Field(default=1, strict=True, ge=1, le=1)
    submitted_operation_count: int = Field(default=0, strict=True, ge=0, le=1)
    paid_or_possibly_paid_operation_count: int = Field(
        default=0,
        strict=True,
        ge=0,
        le=1,
    )
    transport_retry_count: int = Field(default=0, strict=True, ge=0, le=0)
    requested_entire_input: bool
    requested_pages: tuple[int, ...] = ()
    requested_frames: tuple[int, ...] = ()
    submitted_pages: tuple[int, ...] = ()
    submitted_frames: tuple[int, ...] = ()
    input_bytes: int = Field(default=0, strict=True, ge=0, le=2_000_000_000)
    cancellation_status: CloudCancellationStatus = CloudCancellationStatus.NOT_ATTEMPTED

    @model_validator(mode="after")
    def validate_lifecycle(self) -> Self:  # noqa: C901, PLR0912
        """Bind lifecycle state to conservative submitted and paid counters."""
        for field_name in (
            "requested_pages",
            "requested_frames",
            "submitted_pages",
            "submitted_frames",
        ):
            values = getattr(self, field_name)
            if any(type(value) is not int or value < 1 for value in values):
                msg = "Cloud execution indexes must be positive integers"
                raise ValueError(msg)
            if tuple(sorted(set(values))) != values:
                msg = "Cloud execution indexes must be canonical"
                raise ValueError(msg)
        if self.requested_pages and self.requested_frames:
            msg = "Cloud execution request cannot mix pages and frames"
            raise ValueError(msg)
        if self.requested_entire_input == bool(
            self.requested_pages or self.requested_frames
        ):
            msg = "Cloud execution requested scope is invalid"
            raise ValueError(msg)
        submitted_family_count = sum(
            (
                bool(self.submitted_pages),
                bool(self.submitted_frames),
            )
        )
        if submitted_family_count > 1:
            msg = "Cloud execution submission cannot mix pages and frames"
            raise ValueError(msg)
        if self.submitted_pages and (
            self.requested_frames
            or (self.requested_pages and self.submitted_pages != self.requested_pages)
        ):
            msg = "Cloud execution submitted pages do not match the request"
            raise ValueError(msg)
        if self.submitted_frames and (
            self.requested_pages
            or (
                self.requested_frames and self.submitted_frames != self.requested_frames
            )
        ):
            msg = "Cloud execution submitted frames do not match the request"
            raise ValueError(msg)
        if self.status in {
            CloudExecutionAttemptStatus.NOT_SUBMITTED,
            CloudExecutionAttemptStatus.FAILED_BEFORE_SUBMIT,
        }:
            if (
                self.submitted_operation_count
                or self.paid_or_possibly_paid_operation_count
                or self.submitted_pages
                or self.submitted_frames
                or self.cancellation_status is not CloudCancellationStatus.NOT_ATTEMPTED
            ):
                msg = "Unsubmitted cloud execution has remote evidence"
                raise ValueError(msg)
        else:
            if submitted_family_count != 1:
                msg = "Submitted cloud execution requires one input family"
                raise ValueError(msg)
            if self.input_bytes == 0:
                msg = "Submitted cloud execution requires input bytes"
                raise ValueError(msg)
            if self.status is CloudExecutionAttemptStatus.SUBMITTED:
                if (
                    self.submitted_operation_count != 1
                    or self.paid_or_possibly_paid_operation_count != 0
                ):
                    msg = "Submitted cloud execution counters are invalid"
                    raise ValueError(msg)
            elif (
                self.submitted_operation_count != 1
                or self.paid_or_possibly_paid_operation_count != 1
            ):
                msg = "Completed cloud execution counters are invalid"
                raise ValueError(msg)
        if (
            self.cancellation_status is not CloudCancellationStatus.NOT_ATTEMPTED
            and self.status is not CloudExecutionAttemptStatus.POSSIBLY_PAID
        ):
            msg = "Cloud cancellation requires possibly-paid evidence"
            raise ValueError(msg)
        return self


class ProviderUsage(SdkModel):
    """Safe structured evidence for one explicit Provider operation."""

    model_config = ConfigDict(revalidate_instances="always")

    provider_name: NonEmptyString
    profile_id: NonEmptyString
    model_id: NonEmptyString | None = None
    api_version: NonEmptyString | None = None
    provider_resource_identity: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )
    submitted_pages: tuple[int, ...] = ()
    returned_pages: tuple[int, ...] = ()
    submitted_frames: tuple[int, ...] = ()
    returned_frames: tuple[int, ...] = ()
    requested_features: tuple[NonEmptyString, ...] = ()
    query_field_count: int = Field(default=0, ge=0)
    local_operation_count: int = Field(default=0, ge=0)
    local_page_count: int = Field(default=0, ge=0)
    local_frame_count: int = Field(default=0, ge=0)
    local_region_count: int = Field(default=0, ge=0)
    local_attempted_region_count: int = Field(default=0, ge=0)
    local_input_pixel_count: int = Field(default=0, ge=0)
    local_output_character_count: int = Field(default=0, ge=0)
    local_attempted_output_character_count: int = Field(default=0, ge=0)
    local_preprocessing_attempt_count: int = Field(default=0, ge=0)
    local_preprocessing_operation_count: int = Field(default=0, ge=0)
    local_preprocessing_pixel_count: int = Field(default=0, ge=0)
    azure_operation_count: int = Field(default=0, ge=0)
    paid_operation_count: int = Field(default=0, ge=0)
    cloud_logical_operation_count: int = Field(default=0, ge=0)
    cloud_submitted_operation_count: int = Field(default=0, ge=0)
    cloud_paid_or_possibly_paid_operation_count: int = Field(default=0, ge=0)
    cloud_transport_retry_count: int = Field(default=0, ge=0)

    def _validate_local_cardinality(self) -> None:
        """Require content-free Local OCR count cardinality relationships."""
        if (
            self.local_operation_count
            and self.local_input_pixel_count < self.local_operation_count
        ):
            msg = "Local OCR input pixels must cover every operation"
            raise ValueError(msg)
        if self.local_output_character_count and not self.local_region_count:
            msg = "Returned Local OCR characters require a returned region"
            raise ValueError(msg)
        if (
            self.local_attempted_output_character_count
            and not self.local_attempted_region_count
        ):
            msg = "Attempted Local OCR characters require an attempted region"
            raise ValueError(msg)
        if (self.local_region_count or self.local_output_character_count) and not (
            self.returned_pages or self.returned_frames
        ):
            msg = "Returned Local OCR content requires a returned input"
            raise ValueError(msg)

    def _validate_builtin_local_identity(self) -> None:
        """Require deterministic usage for the built-in Local OCR Provider."""
        if self.provider_name != "local_ocr":
            return
        if not self.local_operation_count:
            msg = "Built-in Local OCR usage requires an operation"
            raise ValueError(msg)
        if self.query_field_count or self.requested_features:
            msg = "Built-in Local OCR usage cannot contain service features"
            raise ValueError(msg)
        if self.azure_operation_count or self.paid_operation_count:
            msg = "Built-in Local OCR usage cannot contain cloud operations"
            raise ValueError(msg)

    @model_validator(mode="after")
    def normalize_usage(self) -> Self:  # noqa: C901, PLR0912
        """Store page sets and requested features deterministically."""
        for field_name in (
            "submitted_pages",
            "returned_pages",
            "submitted_frames",
            "returned_frames",
        ):
            values = getattr(self, field_name)
            if any(type(value) is not int or value < 1 for value in values):
                msg = "Provider usage indexes must be positive one-based integers"
                raise ValueError(msg)
            object.__setattr__(self, field_name, tuple(sorted(set(values))))
        object.__setattr__(
            self,
            "requested_features",
            tuple(sorted(set(self.requested_features))),
        )
        if (self.submitted_pages or self.returned_pages) and (
            self.submitted_frames or self.returned_frames
        ):
            msg = "Provider usage cannot mix PDF pages and image frames"
            raise ValueError(msg)
        if self.local_operation_count and (
            self.local_page_count < len(self.submitted_pages)
            or self.local_frame_count < len(self.submitted_frames)
            or not set(self.returned_pages).issubset(self.submitted_pages)
            or not set(self.returned_frames).issubset(self.submitted_frames)
        ):
            msg = "Local OCR counts and returned indexes must match submissions"
            raise ValueError(msg)
        if (
            self.local_attempted_region_count < self.local_region_count
            or self.local_attempted_output_character_count
            < self.local_output_character_count
        ):
            msg = "Attempted Local OCR counts cannot be below returned counts"
            raise ValueError(msg)
        if self.local_operation_count != (
            self.local_page_count + self.local_frame_count
        ):
            msg = "Local OCR operation count must match local pages and frames"
            raise ValueError(msg)
        if (
            self.local_preprocessing_operation_count
            > self.local_preprocessing_attempt_count
            or self.local_preprocessing_operation_count > self.local_operation_count
        ):
            msg = "Local OCR preprocessing operations are inconsistent"
            raise ValueError(msg)
        if bool(self.local_preprocessing_attempt_count) != bool(
            self.local_preprocessing_pixel_count
        ):
            msg = "Local OCR preprocessing pixel evidence is inconsistent"
            raise ValueError(msg)
        self._validate_local_cardinality()
        self._validate_builtin_local_identity()
        if self.local_operation_count and (
            self.azure_operation_count or self.paid_operation_count
        ):
            msg = "Local OCR usage cannot contain Azure or paid operations"
            raise ValueError(msg)
        if not self.local_operation_count and any(
            (
                self.local_page_count,
                self.local_frame_count,
                self.local_region_count,
                self.local_attempted_region_count,
                self.local_input_pixel_count,
                self.local_output_character_count,
                self.local_attempted_output_character_count,
                self.local_preprocessing_attempt_count,
                self.local_preprocessing_operation_count,
                self.local_preprocessing_pixel_count,
            )
        ):
            msg = "Local OCR detail counts require a Local OCR operation"
            raise ValueError(msg)
        if self.paid_operation_count > self.azure_operation_count:
            msg = "Paid OCR operations cannot exceed Azure operations"
            raise ValueError(msg)
        if (
            self.cloud_submitted_operation_count > self.cloud_logical_operation_count
            or self.cloud_paid_or_possibly_paid_operation_count
            > self.cloud_submitted_operation_count
        ):
            msg = "Cloud Provider usage operation counts are inconsistent"
            raise ValueError(msg)
        input_family_count = sum(
            (
                bool(self.submitted_pages),
                bool(self.submitted_frames),
            )
        )
        if self.cloud_submitted_operation_count and input_family_count != 1:
            msg = "Submitted Cloud Provider usage requires one input family"
            raise ValueError(msg)
        if self.cloud_transport_retry_count:
            msg = "SDK Provider usage cannot claim unverified transport retries"
            raise ValueError(msg)
        if bool(self.provider_resource_identity) != bool(
            self.cloud_logical_operation_count
        ):
            msg = "Cloud Provider usage requires safe resource identity"
            raise ValueError(msg)
        return self


class ProviderUsageTotals(SdkModel):
    """Content-free aggregate Provider operation evidence for Batch manifests."""

    model_config = ConfigDict(revalidate_instances="always")

    local_operation_count: int = Field(default=0, ge=0)
    local_page_count: int = Field(default=0, ge=0)
    local_frame_count: int = Field(default=0, ge=0)
    local_region_count: int = Field(default=0, ge=0)
    local_attempted_region_count: int = Field(default=0, ge=0)
    local_input_pixel_count: int = Field(default=0, ge=0)
    local_output_character_count: int = Field(default=0, ge=0)
    local_attempted_output_character_count: int = Field(default=0, ge=0)
    local_preprocessing_attempt_count: int = Field(default=0, ge=0)
    local_preprocessing_operation_count: int = Field(default=0, ge=0)
    local_preprocessing_pixel_count: int = Field(default=0, ge=0)
    azure_operation_count: int = Field(default=0, ge=0)
    paid_operation_count: int = Field(default=0, ge=0)
    cloud_logical_operation_count: int = Field(default=0, ge=0)
    cloud_submitted_operation_count: int = Field(default=0, ge=0)
    cloud_paid_or_possibly_paid_operation_count: int = Field(default=0, ge=0)
    cloud_transport_retry_count: int = Field(default=0, ge=0)

    @model_validator(mode="after")
    def validate_totals(self) -> Self:  # noqa: C901
        """Require content-free aggregate usage relationships."""
        if self.local_operation_count != (
            self.local_page_count + self.local_frame_count
        ):
            msg = "Local OCR total operations must match total pages and frames"
            raise ValueError(msg)
        local_detail_counts = (
            self.local_region_count,
            self.local_attempted_region_count,
            self.local_input_pixel_count,
            self.local_output_character_count,
            self.local_attempted_output_character_count,
            self.local_preprocessing_attempt_count,
            self.local_preprocessing_operation_count,
            self.local_preprocessing_pixel_count,
        )
        if not self.local_operation_count and any(local_detail_counts):
            msg = "Local OCR total detail counts require an operation"
            raise ValueError(msg)
        if (
            self.local_preprocessing_operation_count
            > self.local_preprocessing_attempt_count
            or self.local_preprocessing_operation_count > self.local_operation_count
        ):
            msg = "Local OCR total preprocessing operations are inconsistent"
            raise ValueError(msg)
        if bool(self.local_preprocessing_attempt_count) != bool(
            self.local_preprocessing_pixel_count
        ):
            msg = "Local OCR total preprocessing pixel evidence is inconsistent"
            raise ValueError(msg)
        if self.local_attempted_region_count < self.local_region_count:
            msg = "Attempted Local OCR total regions cannot be below returned regions"
            raise ValueError(msg)
        if (
            self.local_attempted_output_character_count
            < self.local_output_character_count
        ):
            msg = (
                "Attempted Local OCR total characters cannot be below returned "
                "characters"
            )
            raise ValueError(msg)
        if (
            self.local_operation_count
            and self.local_input_pixel_count < self.local_operation_count
        ):
            msg = "Local OCR total input pixels must cover every operation"
            raise ValueError(msg)
        if self.local_output_character_count and not self.local_region_count:
            msg = "Returned Local OCR total characters require a returned region"
            raise ValueError(msg)
        if (
            self.local_attempted_output_character_count
            and not self.local_attempted_region_count
        ):
            msg = "Attempted Local OCR total characters require an attempted region"
            raise ValueError(msg)
        if self.paid_operation_count > self.azure_operation_count:
            msg = "Paid OCR total operations cannot exceed Azure operations"
            raise ValueError(msg)
        if (
            (
                not self.cloud_logical_operation_count
                and self.cloud_submitted_operation_count
            )
            or self.cloud_paid_or_possibly_paid_operation_count
            > self.cloud_submitted_operation_count
            or self.cloud_transport_retry_count
        ):
            msg = "Cloud Provider total operation counts are inconsistent"
            raise ValueError(msg)
        return self


class TextBlock(SdkModel):
    """A text fragment with its original document location."""

    text: str
    source: SourceReference
    confidence: float | None = Field(default=None, ge=0, le=1)
    element_id: NonEmptyString | None = None
    spans: tuple[DocumentSpan, ...] = ()


class TableCell(SdkModel):
    """A normalized table cell with one-based row and column indices."""

    row: int = Field(ge=1)
    column: int = Field(ge=1)
    row_span: int = Field(default=1, ge=1)
    column_span: int = Field(default=1, ge=1)
    text: str
    source: SourceReference
    kind: NonEmptyString | None = None
    confidence: float | None = Field(default=None, ge=0, le=1)
    spans: tuple[DocumentSpan, ...] = ()
    sources: tuple[SourceReference, ...] = ()
    elements: tuple[DocumentElementReference, ...] = ()


class Table(SdkModel):
    """A normalized collection of table cells."""

    cells: tuple[TableCell, ...] = ()
    source: SourceReference
    row_count: int | None = Field(default=None, ge=1)
    column_count: int | None = Field(default=None, ge=1)
    element_id: NonEmptyString | None = None
    spans: tuple[DocumentSpan, ...] = ()
    sources: tuple[SourceReference, ...] = ()
    caption: DocumentCaption | None = None
    footnotes: tuple[DocumentFootnote, ...] = ()

    @model_validator(mode="after")
    def validate_cell_sources(self) -> Self:  # noqa: C901, PLR0912, PLR0915
        """Ensure every cell belongs to the table's source document location."""
        table_sources = self.sources or (self.source,)
        if any(source.file_id != self.source.file_id for source in table_sources):
            msg = "table sources must use the table file_id"
            raise ValueError(msg)
        object.__setattr__(
            self,
            "sources",
            tuple(
                sorted(
                    {
                        source.model_dump_json(): source for source in table_sources
                    }.values(),
                    key=lambda source: source.model_dump_json(),
                )
            ),
        )
        for cell in self.cells:
            if (
                self.row_count is not None
                and cell.row + cell.row_span - 1 > self.row_count
            ):
                msg = "table cell row span exceeds row_count"
                raise ValueError(msg)
            if (
                self.column_count is not None
                and cell.column + cell.column_span - 1 > self.column_count
            ):
                msg = "table cell column span exceeds column_count"
                raise ValueError(msg)
            if cell.source.source_type != self.source.source_type:
                msg = "table cells must use the table source type"
                raise ValueError(msg)
            if cell.source.file_id != self.source.file_id:
                msg = "table cells must use the table file_id"
                raise ValueError(msg)
            if isinstance(self.source, PdfSourceReference):
                if not isinstance(cell.source, PdfSourceReference):
                    msg = "PDF table cells must use PDF sources"
                    raise ValueError(msg)  # noqa: TRY004 - Pydantic validator.
                if cell.source.page_number != self.source.page_number:
                    msg = "PDF table cells must use the table page_number"
                    raise ValueError(msg)
            elif isinstance(self.source, ImageSourceReference):
                if not isinstance(cell.source, ImageSourceReference):
                    msg = "image table cells must use image sources"
                    raise ValueError(msg)  # noqa: TRY004 - Pydantic validator.
                if cell.source.frame_number != self.source.frame_number:
                    msg = "image table cells must use the table frame_number"
                    raise ValueError(msg)
            elif isinstance(self.source, ExcelSourceReference):
                if not isinstance(cell.source, ExcelSourceReference):
                    msg = "Excel table cells must use Excel sources"
                    raise ValueError(msg)  # noqa: TRY004 - Pydantic validator.
                if cell.source.sheet_name != self.source.sheet_name:
                    msg = "Excel table cells must use the table sheet_name"
                    raise ValueError(msg)
            elif isinstance(self.source, DocxSourceReference):
                if not isinstance(cell.source, DocxSourceReference):
                    msg = "DOCX table cells must use DOCX sources"
                    raise ValueError(msg)  # noqa: TRY004 - Pydantic validator.
                if (
                    cell.source.story_type != self.source.story_type
                    or cell.source.story_id != self.source.story_id
                ):
                    msg = "DOCX table cells must use the table story"
                    raise ValueError(msg)
            cell_sources = cell.sources or (cell.source,)
            if any(source.file_id != cell.source.file_id for source in cell_sources):
                msg = "table cell sources must use the cell file_id"
                raise ValueError(msg)
            object.__setattr__(
                cell,
                "sources",
                tuple(
                    sorted(
                        {
                            source.model_dump_json(): source for source in cell_sources
                        }.values(),
                        key=lambda source: source.model_dump_json(),
                    )
                ),
            )
        return self


class DocumentPage(SdkModel):
    """One normalized document page."""

    page_number: int = Field(ge=1)
    dimensions: PageDimensions | None = None
    text_blocks: tuple[TextBlock, ...] = ()
    tables: tuple[Table, ...] = ()
    selection_marks: tuple[DocumentSelectionMark, ...] = ()
    barcodes: tuple[DocumentBarcode, ...] = ()
    formulas: tuple[DocumentFormula, ...] = ()
    content_spans: tuple[DocumentSpan, ...] = ()
    source: DocumentSourceReference

    @model_validator(mode="after")
    def validate_page_sources(self) -> Self:  # noqa: C901
        """Ensure all page content traces to this PDF page or image frame."""
        source_number = _document_source_number(self.source)
        if source_number != self.page_number:
            msg = "document page source number must match page_number"
            raise ValueError(msg)
        for block in self.text_blocks:
            if type(block.source) is not type(self.source):
                msg = "document page text blocks must use the page source type"
                raise ValueError(msg)
            block_number = _document_source_number(block.source)
            if block.source.file_id != self.source.file_id or (
                block_number != self.page_number
            ):
                msg = "document page text block source does not match its page"
                raise ValueError(msg)
        for table in self.tables:
            if type(table.source) is not type(self.source):
                msg = "document page tables must use the page source type"
                raise ValueError(msg)
            table_number = _document_source_number(table.source)
            if table.source.file_id != self.source.file_id or (
                table_number != self.page_number
            ):
                msg = "document page table source does not match its page"
                raise ValueError(msg)
        advanced = (*self.selection_marks, *self.barcodes, *self.formulas)
        for element in advanced:
            for source in element.sources:
                if type(source) is not type(self.source):
                    msg = "document page advanced content must use the page source type"
                    raise ValueError(msg)
                if source.file_id != self.source.file_id or (
                    _document_source_number(source) != self.page_number
                ):
                    msg = "document page advanced source does not match its page"
                    raise ValueError(msg)
        return self


class Document(SdkModel):
    """A normalized document with a safe file descriptor."""

    file: FileDescriptor
    pages: tuple[DocumentPage, ...] = ()
    tables: tuple[Table, ...] = ()
    content_scopes: tuple[DocumentContentScope, ...] = ()
    paragraphs: tuple[DocumentParagraph, ...] = ()
    key_value_pairs: tuple[DocumentKeyValuePair, ...] = ()
    figures: tuple[DocumentFigure, ...] = ()
    sections: tuple[DocumentSection, ...] = ()
    languages: tuple[DocumentLanguage, ...] = ()
    styles: tuple[DocumentTextStyle, ...] = ()
    analyzed_documents: tuple[AnalyzedDocument, ...] = ()

    @model_validator(mode="after")
    def validate_document_sources(self) -> Self:  # noqa: C901, PLR0912, PLR0915
        """Validate complete page, scope, source, ID, span, and reference invariants."""
        page_numbers = [page.page_number for page in self.pages]
        if len(page_numbers) != len(set(page_numbers)):
            msg = "document page numbers must be unique"
            raise ValueError(msg)
        if any(page.source.file_id != self.file.file_id for page in self.pages):
            msg = "document page file_id must match document file_id"
            raise ValueError(msg)
        if not self.pages:
            valid_numbers: set[int] = set()
            source_type = None
        else:
            valid_numbers = set(page_numbers)
            source_types = {page.source.source_type for page in self.pages}
            if len(source_types) != 1:
                msg = "document pages must use one source type"
                raise ValueError(msg)
            source_type = next(iter(source_types))

        scopes = {scope.scope_id: scope for scope in self.content_scopes}
        if len(scopes) != len(self.content_scopes):
            msg = "document content scope IDs must be unique"
            raise ValueError(msg)
        for scope in self.content_scopes:
            numbers = scope.page_numbers or scope.frame_numbers
            if any(number not in valid_numbers for number in numbers):
                msg = "document content scope references an unknown page or frame"
                raise ValueError(msg)
            if source_type == "pdf" and not scope.page_numbers:
                msg = "PDF document content scopes must use page_numbers"
                raise ValueError(msg)
            if source_type == "image" and not scope.frame_numbers:
                msg = "image document content scopes must use frame_numbers"
                raise ValueError(msg)

        spans: list[DocumentSpan] = []
        sources: list[DocumentSourceReference] = []
        ids: dict[str, str] = {}
        references: list[DocumentElementReference] = []

        def add_id(element_id: str | None, element_type: str) -> None:
            if element_id is None:
                return
            if element_id in ids:
                msg = "document element IDs must be unique"
                raise ValueError(msg)
            ids[element_id] = element_type

        def add_multi_source(element: _MultiSourceElement) -> None:
            sources.extend(element.sources)

        def visit_field(field: DocumentField) -> None:
            spans.extend(field.spans)
            add_multi_source(field)
            if field.field_type == "array" and isinstance(field.value, tuple):
                for item in field.value:
                    if isinstance(item, DocumentField):
                        visit_field(item)
            elif field.field_type == "object" and isinstance(field.value, Mapping):
                for item in field.value.values():
                    visit_field(item)

        for page in self.pages:
            spans.extend(page.content_spans)
            for block in page.text_blocks:
                add_id(block.element_id, "text_block")
                spans.extend(block.spans)
            for table in page.tables:
                add_id(table.element_id, "table")
                spans.extend(table.spans)
                sources.extend(
                    source
                    for source in table.sources
                    if isinstance(source, PdfSourceReference | ImageSourceReference)
                )
                for cell in table.cells:
                    spans.extend(cell.spans)
                    references.extend(cell.elements)
                    sources.extend(
                        source
                        for source in cell.sources
                        if isinstance(
                            source,
                            PdfSourceReference | ImageSourceReference,
                        )
                    )
                if table.caption is not None:
                    add_id(table.caption.element_id, "caption")
                    spans.extend(table.caption.spans)
                    add_multi_source(table.caption)
                    references.extend(table.caption.elements)
                for footnote in table.footnotes:
                    add_id(footnote.element_id, "footnote")
                    spans.extend(footnote.spans)
                    add_multi_source(footnote)
                    references.extend(footnote.elements)
            for mark in page.selection_marks:
                add_id(mark.element_id, "selection_mark")
                spans.append(mark.span)
                add_multi_source(mark)
            for barcode in page.barcodes:
                add_id(barcode.element_id, "barcode")
                spans.append(barcode.span)
                add_multi_source(barcode)
            for formula in page.formulas:
                add_id(formula.element_id, "formula")
                spans.append(formula.span)
                add_multi_source(formula)
        for table in self.tables:
            add_id(table.element_id, "table")
            spans.extend(table.spans)
            sources.extend(
                source
                for source in table.sources
                if isinstance(
                    source,
                    PdfSourceReference | ImageSourceReference | DocxSourceReference,
                )
            )
            for cell in table.cells:
                spans.extend(cell.spans)
                references.extend(cell.elements)
                sources.extend(
                    source
                    for source in cell.sources
                    if isinstance(
                        source,
                        PdfSourceReference | ImageSourceReference | DocxSourceReference,
                    )
                )
        for paragraph in self.paragraphs:
            add_id(paragraph.element_id, "paragraph")
            spans.extend(paragraph.spans)
            add_multi_source(paragraph)
        for pair in self.key_value_pairs:
            add_id(pair.element_id, "key_value_pair")
            spans.extend(pair.spans)
            add_multi_source(pair)
            spans.extend(pair.key.spans)
            add_multi_source(pair.key)
            if pair.value is not None:
                spans.extend(pair.value.spans)
                add_multi_source(pair.value)
        for figure in self.figures:
            add_id(figure.element_id, "figure")
            spans.extend(figure.spans)
            add_multi_source(figure)
            references.extend(figure.elements)
            if figure.caption is not None:
                add_id(figure.caption.element_id, "caption")
                spans.extend(figure.caption.spans)
                add_multi_source(figure.caption)
                references.extend(figure.caption.elements)
            for footnote in figure.footnotes:
                add_id(footnote.element_id, "footnote")
                spans.extend(footnote.spans)
                add_multi_source(footnote)
                references.extend(footnote.elements)
        for section in self.sections:
            add_id(section.element_id, "section")
            spans.extend(section.spans)
            add_multi_source(section)
            references.extend(section.elements)
        for language in self.languages:
            spans.extend(language.spans)
            add_multi_source(language)
        for style in self.styles:
            spans.extend(style.spans)
            add_multi_source(style)
        for analyzed in self.analyzed_documents:
            add_id(analyzed.element_id, "analyzed_document")
            spans.extend(analyzed.spans)
            add_multi_source(analyzed)
            for field in analyzed.fields.values():
                visit_field(field)

        for source in sources:
            if source.file_id != self.file.file_id:
                msg = "document element source file_id must match document file_id"
                raise ValueError(msg)
            if isinstance(source, DocxSourceReference):
                if self.pages:
                    msg = "DOCX structural sources cannot be combined with pages"
                    raise ValueError(msg)
                continue
            if _document_source_number(source) not in valid_numbers:
                msg = "document element source references an unknown page or frame"
                raise ValueError(msg)
            if source.source_type != source_type:
                msg = "document element sources must match document source type"
                raise ValueError(msg)

        for span in spans:
            target_scope = scopes.get(span.scope_id)
            if target_scope is None:
                msg = "document span references an unknown content scope"
                raise ValueError(msg)
            if span.offset + span.length > target_scope.indexed_length:
                msg = "document span exceeds its content scope"
                raise ValueError(msg)

        allowed_reference_types = {
            "text_block": "text_block",
            "table": "table",
            "paragraph": "paragraph",
            "key_value_pair": "key_value_pair",
            "figure": "figure",
            "section": "section",
            "analyzed_document": "analyzed_document",
        }
        for reference in references:
            if (
                ids.get(reference.element_id)
                != allowed_reference_types[reference.element_type]
            ):
                msg = "document element reference target is invalid"
                raise ValueError(msg)
        section_graph = {
            section.element_id: tuple(
                reference.element_id
                for reference in section.elements
                if reference.element_type == "section"
            )
            for section in self.sections
        }
        visiting: set[str] = set()
        visited: set[str] = set()

        def visit_section(element_id: str) -> None:
            if element_id in visiting:
                msg = "document sections must not contain circular references"
                raise ValueError(msg)
            if element_id in visited:
                return
            visiting.add(element_id)
            for target in section_graph[element_id]:
                visit_section(target)
            visiting.remove(element_id)
            visited.add(element_id)

        for element_id in section_graph:
            visit_section(element_id)
        return self


class RenderedPage(SdkModel):
    """A rendered page or page region backed by encoded image bytes."""

    image_bytes: bytes = Field(repr=False, exclude=True)
    content_type: Literal["image/png"] = "image/png"
    width_pixels: int = Field(gt=0)
    height_pixels: int = Field(gt=0)
    dpi: int = Field(gt=0)
    source: PdfSourceReference


class PdfPageInspection(SdkModel):
    """Inspection facts for one PDF page."""

    page_number: int = Field(ge=1)
    dimensions: PageDimensions
    has_text_layer: bool
    native_text_character_count: int = Field(ge=0)
    ocr_candidate: bool
    source: PdfSourceReference

    @model_validator(mode="after")
    def validate_source_page(self) -> Self:
        """Ensure the inspection source identifies this page."""
        if self.source.page_number != self.page_number:
            msg = "PDF inspection source page_number must match page_number"
            raise ValueError(msg)
        return self


class PdfInspection(SdkModel):
    """Local PDF inspection facts."""

    file: FileDescriptor
    page_count: int = Field(ge=1)
    encrypted: bool
    has_text_layer: bool
    scanned_pdf_candidate: bool
    native_text_page_numbers: tuple[int, ...]
    ocr_candidate_page_numbers: tuple[int, ...]
    fully_scanned: bool
    partially_scanned: bool
    pages: tuple[PdfPageInspection, ...]
    file_size_within_limit: bool = True
    page_count_within_limit: bool = True
    largest_page_width_points: float = Field(default=0, ge=0)
    largest_page_height_points: float = Field(default=0, ge=0)
    largest_page_area_points: float = Field(default=0, ge=0)

    @model_validator(mode="after")
    def validate_pages(self) -> Self:
        """Ensure page count and file sources are internally consistent."""
        if len(self.pages) != self.page_count:
            msg = "PDF inspection page_count must match pages"
            raise ValueError(msg)
        if any(page.source.file_id != self.file.file_id for page in self.pages):
            msg = "PDF inspection page file_id must match inspected file"
            raise ValueError(msg)
        native_pages = tuple(
            page.page_number for page in self.pages if not page.ocr_candidate
        )
        ocr_pages = tuple(page.page_number for page in self.pages if page.ocr_candidate)
        if self.native_text_page_numbers != native_pages:
            msg = "native_text_page_numbers must match page inspection facts"
            raise ValueError(msg)
        if self.ocr_candidate_page_numbers != ocr_pages:
            msg = "ocr_candidate_page_numbers must match page inspection facts"
            raise ValueError(msg)
        if self.fully_scanned != (len(ocr_pages) == self.page_count):
            msg = "fully_scanned must match page inspection facts"
            raise ValueError(msg)
        if self.partially_scanned != bool(native_pages and ocr_pages):
            msg = "partially_scanned must match page inspection facts"
            raise ValueError(msg)
        if self.scanned_pdf_candidate != self.fully_scanned:
            msg = "scanned_pdf_candidate must equal fully_scanned"
            raise ValueError(msg)
        return self


class ImageProcessingLimits(SdkModel):
    """Explicit bounds applied before full image-frame decoding."""

    max_frames: int = Field(default=100, gt=0)
    max_pixels_per_frame: int = Field(default=25_000_000, gt=0)
    max_total_pixels: int = Field(default=100_000_000, gt=0)
    max_working_pixels: int = Field(default=50_000_000, gt=0)
    max_output_bytes: int = Field(default=50_000_000, gt=0)
    max_output_width: int = Field(default=20_000, gt=0)
    max_output_height: int = Field(default=20_000, gt=0)


class ImageFrameInspection(SdkModel):
    """Normalized facts for one encoded image frame."""

    frame_number: int = Field(ge=1)
    width: int = Field(gt=0)
    height: int = Field(gt=0)
    mode: NonEmptyString
    pixel_count: int = Field(gt=0)
    has_alpha: bool
    exif_orientation: Annotated[int, Field(ge=1, le=8)] | None = None
    decode_verified: bool
    source: ImageSourceReference

    @model_validator(mode="after")
    def validate_frame(self) -> Self:
        """Ensure geometry and source information describe this exact frame."""
        if self.pixel_count != self.width * self.height:
            msg = "image frame pixel_count must equal width times height"
            raise ValueError(msg)
        if self.source.frame_number != self.frame_number:
            msg = "image frame source must match frame_number"
            raise ValueError(msg)
        if self.source.bounding_box is not None:
            msg = "image frame inspection source cannot use a bounding box"
            raise ValueError(msg)
        return self


class ImageInspection(SdkModel):
    """Local image inspection facts without Pillow-owned objects."""

    file: FileDescriptor
    format: Literal["PNG", "JPEG", "TIFF", "BMP", "WEBP"]
    mime_type: Literal[
        "image/png",
        "image/jpeg",
        "image/tiff",
        "image/bmp",
        "image/webp",
    ]
    frame_count: int = Field(ge=1)
    animated: bool
    frames: tuple[ImageFrameInspection, ...] = Field(min_length=1)
    warnings: tuple[NonEmptyString, ...] = ()

    @model_validator(mode="after")
    def validate_frames(self) -> Self:
        """Ensure frame order, sources, and aggregate facts are consistent."""
        if len(self.frames) != self.frame_count:
            msg = "image frame_count must match frame inspections"
            raise ValueError(msg)
        frame_numbers = tuple(frame.frame_number for frame in self.frames)
        if frame_numbers != tuple(range(1, self.frame_count + 1)):
            msg = "image frame numbers must be consecutive and one-based"
            raise ValueError(msg)
        if any(frame.source.file_id != self.file.file_id for frame in self.frames):
            msg = "image frame file_id must match inspected file"
            raise ValueError(msg)
        if self.animated != (self.frame_count > 1):
            msg = "animated must match image frame_count"
            raise ValueError(msg)
        if self.mime_type != self.file.mime_type:
            msg = "image MIME type must match inspected file"
            raise ValueError(msg)
        expected_mime_type = {
            "BMP": "image/bmp",
            "PNG": "image/png",
            "JPEG": "image/jpeg",
            "TIFF": "image/tiff",
            "WEBP": "image/webp",
        }[self.format]
        if self.mime_type != expected_mime_type:
            msg = "image format must match MIME type"
            raise ValueError(msg)
        return self


class WorksheetInspection(SdkModel):
    """Workbook structure facts for one worksheet."""

    name: WorksheetName
    used_range: str | None
    max_row: int = Field(ge=0, le=MAX_EXCEL_ROW)
    max_column: int = Field(ge=0, le=MAX_EXCEL_COLUMN)
    merged_ranges: tuple[str, ...] = ()
    hidden_rows: tuple[int, ...] = ()
    hidden_columns: tuple[str, ...] = ()
    formula_cell_count: int = Field(ge=0)

    @field_validator(
        "merged_ranges",
        "hidden_rows",
        "hidden_columns",
        mode="before",
    )
    @classmethod
    def accept_json_arrays(cls, value: object) -> object:
        """Accept JSON arrays emitted by model_dump in dictionary round-trips."""
        return tuple(value) if isinstance(value, list) else value

    @field_validator("used_range")
    @classmethod
    def validate_used_range(cls, value: str | None) -> str | None:
        """Normalize the optional represented-cell bounds."""
        return None if value is None else normalize_excel_range(value)

    @field_validator("merged_ranges")
    @classmethod
    def validate_merged_ranges(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        """Normalize worksheet merged ranges."""
        return tuple(normalize_excel_range(item) for item in value)

    @field_validator("hidden_rows")
    @classmethod
    def validate_hidden_rows(cls, value: tuple[int, ...]) -> tuple[int, ...]:
        """Require sorted unique hidden rows inside Excel bounds."""
        if any(row < 1 or row > MAX_EXCEL_ROW for row in value):
            msg = "hidden row is outside Excel bounds"
            raise ValueError(msg)
        if value != tuple(sorted(set(value))):
            msg = "hidden rows must be sorted and unique"
            raise ValueError(msg)
        return value

    @field_validator("hidden_columns")
    @classmethod
    def validate_hidden_columns(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        """Normalize sorted unique hidden worksheet columns."""
        if any(
            not column.isascii()
            or not column.isalpha()
            or len(column) > MAX_EXCEL_COLUMN_NAME_LENGTH
            for column in value
        ):
            msg = "hidden columns must contain letters only"
            raise ValueError(msg)
        normalized = tuple(
            normalize_excel_coordinate(f"{column}1").removesuffix("1")
            for column in value
        )
        indexes = tuple(
            excel_range_bounds(f"{column}1").min_column for column in normalized
        )
        if indexes != tuple(sorted(set(indexes))):
            msg = "hidden columns must be sorted and unique"
            raise ValueError(msg)
        return normalized

    @model_validator(mode="after")
    def validate_bounds(self) -> Self:
        """Keep used-range and maximum-coordinate facts consistent."""
        if self.used_range is None:
            if self.max_row != 0 or self.max_column != 0:
                msg = "empty worksheet bounds must use zero maxima"
                raise ValueError(msg)
            return self
        bounds = excel_range_bounds(self.used_range)
        if self.max_row != bounds.max_row or self.max_column != bounds.max_column:
            msg = "worksheet maxima must match used_range"
            raise ValueError(msg)
        return self


class WorkbookInspection(SdkModel):
    """Local workbook structure and safe file metadata.

    ``sheet_names`` retains complete workbook order, while ``worksheets`` contains
    only cell-bearing worksheets and excludes Chartsheets.
    """

    file: FileDescriptor
    sheet_names: tuple[WorksheetName, ...]
    worksheets: tuple[WorksheetInspection, ...]

    @field_validator("sheet_names", "worksheets", mode="before")
    @classmethod
    def accept_json_arrays(cls, value: object) -> object:
        """Accept JSON arrays emitted by model_dump in dictionary round-trips."""
        return tuple(value) if isinstance(value, list) else value

    @model_validator(mode="after")
    def validate_worksheets(self) -> Self:
        """Ensure worksheet inspections form an ordered subset of all sheets."""
        worksheet_names = tuple(worksheet.name for worksheet in self.worksheets)
        normalized_names = [name.casefold() for name in self.sheet_names]
        if len(normalized_names) != len(set(normalized_names)):
            msg = "workbook sheet names must be unique"
            raise ValueError(msg)
        positions = {
            name.casefold(): index for index, name in enumerate(self.sheet_names)
        }
        try:
            worksheet_positions = tuple(
                positions[name.casefold()] for name in worksheet_names
            )
        except KeyError:
            msg = "worksheet inspections must identify workbook sheets"
            raise ValueError(msg) from None
        if worksheet_positions != tuple(sorted(set(worksheet_positions))):
            msg = "worksheet inspections must preserve workbook order"
            raise ValueError(msg)
        if any(
            self.sheet_names[positions[name.casefold()]] != name
            for name in worksheet_names
        ):
            msg = "worksheet names must exactly match workbook sheet names"
            raise ValueError(msg)
        return self


class ExcelTemporalSource(SdkModel):
    """Caller-declared temporal source text, separate from normalized values.

    The model validates structure, not source-file authenticity or raw lexical
    validity. Streaming capture uses the existing decoder before declaring it.
    """

    kind: Literal["excel_serial", "iso8601"]
    raw_value: str
    date_system: Literal["1900", "1904"] | None = None
    origin: Literal["value", "formula_cache"]

    @model_validator(mode="after")
    def validate_date_system(self) -> Self:
        """Require a serial epoch without assigning one to ISO source text."""
        if self.kind == "excel_serial" and self.date_system is None:
            msg = "excel_serial temporal source requires date_system"
            raise ValueError(msg)
        if self.kind == "iso8601" and self.date_system is not None:
            msg = "iso8601 temporal source cannot specify date_system"
            raise ValueError(msg)
        return self


class ExcelCell(SdkModel):
    """A normalized Excel cell that distinguishes values and formulas."""

    coordinate: NonEmptyString
    value: ExcelValue = None
    formula: str | None = None
    formula_text: str | None = None
    cached_value: ExcelValue = None
    has_cached_value: bool = False
    cache_available: bool = False
    formula_kind: Literal["ordinary", "shared", "array", "dynamic_array"] | None = None
    external_reference: bool = False
    requires_recalculation: bool = False
    data_type: NonEmptyString
    style_id: int | None = Field(default=None, ge=0)
    number_format: str | None = None
    source: ExcelSourceReference
    temporal_source: ExcelTemporalSource | None = None

    @field_validator("coordinate")
    @classmethod
    def validate_coordinate(cls, value: str) -> str:
        """Validate Excel bounds and normalize the coordinate to uppercase."""
        return normalize_excel_coordinate(value)

    @model_validator(mode="before")
    @classmethod
    def populate_formula_compatibility_fields(
        cls,
        data: object,
    ) -> object:
        """Synchronize additive formula/cache fields with legacy names."""
        if not isinstance(data, dict):
            return data
        values = dict(data)
        formula = values.get("formula")
        formula_text = values.get("formula_text")
        if formula is None and formula_text is not None:
            values["formula"] = formula_text
        elif formula_text is None and formula is not None:
            values["formula_text"] = formula
        has_cached_value = values.get("has_cached_value")
        cache_available = values.get("cache_available")
        if has_cached_value is None and cache_available is not None:
            values["has_cached_value"] = cache_available
        elif cache_available is None and has_cached_value is not None:
            values["cache_available"] = has_cached_value
        if values.get("formula") is not None and values.get("formula_kind") is None:
            values["formula_kind"] = "ordinary"
        if (
            values.get("formula") is not None or values.get("formula_kind") is not None
        ) and "requires_recalculation" not in values:
            values["requires_recalculation"] = True
        return values

    @model_validator(mode="after")
    def validate_formula_alias_state(self) -> Self:
        """Keep formula/cache compatibility fields internally consistent."""
        if self.formula != self.formula_text:
            msg = "formula and formula_text must match"
            raise ValueError(msg)
        if self.has_cached_value != self.cache_available:
            msg = "has_cached_value and cache_available must match"
            raise ValueError(msg)
        if self.formula is not None and not self.formula.startswith("="):
            msg = "formula must start with '='"
            raise ValueError(msg)
        if self.formula is not None and self.value is not None:
            msg = "formula cells cannot also contain an ordinary value"
            raise ValueError(msg)
        return self

    @model_validator(mode="after")
    def validate_formula_projection_state(self) -> Self:
        """Reject formula-specific state on ordinary cells."""
        is_formula_cell = self.formula is not None or self.formula_kind is not None
        if is_formula_cell and not self.requires_recalculation:
            msg = "formula cells must require external recalculation"
            raise ValueError(msg)
        if not is_formula_cell and (
            self.has_cached_value or self.cached_value is not None
        ):
            msg = "ordinary cells cannot report cached formula state"
            raise ValueError(msg)
        if (
            self.formula is not None
            and not self.has_cached_value
            and self.cached_value is not None
        ):
            msg = "cached formula values require has_cached_value"
            raise ValueError(msg)
        if not is_formula_cell and (
            self.formula_kind is not None
            or self.external_reference
            or self.requires_recalculation
        ):
            msg = "ordinary cells cannot report formula metadata"
            raise ValueError(msg)
        if self.formula is None and is_formula_cell:
            if self.has_cached_value and self.value != self.cached_value:
                msg = "cached formula projection must match cached_value"
                raise ValueError(msg)
            if not self.has_cached_value and (
                self.value is not None or self.cached_value is not None
            ):
                msg = "missing formula cache cannot expose a projected value"
                raise ValueError(msg)
        if self.coordinate != self.source.cell_range:
            msg = "cell coordinate must match its source cell_range"
            raise ValueError(msg)
        return self

    @model_validator(mode="after")
    def validate_temporal_source_projection(self) -> Self:
        """Keep source origins consistent with exposed value/cache state."""
        if self.temporal_source is None:
            return self
        is_formula_cell = self.formula is not None or self.formula_kind is not None
        if self.temporal_source.origin == "value":
            if is_formula_cell or self.value is None:
                msg = "value temporal source requires an ordinary exposed value"
                raise ValueError(msg)
        elif (
            not is_formula_cell
            or not self.has_cached_value
            or self.cached_value is None
        ):
            msg = "formula_cache temporal source requires an exposed formula cache"
            raise ValueError(msg)
        return self


class WorksheetData(SdkModel):
    """Normalized cell data from one worksheet."""

    file: FileDescriptor
    sheet_name: WorksheetName
    used_range: str | None
    cells: tuple[ExcelCell, ...] = ()

    @field_validator("cells", mode="before")
    @classmethod
    def accept_json_cells(cls, value: object) -> object:
        """Accept the JSON cell array emitted by model_dump."""
        return tuple(value) if isinstance(value, list) else value

    @field_validator("used_range")
    @classmethod
    def validate_used_range(cls, value: str | None) -> str | None:
        """Normalize the optional non-empty cell bounds."""
        return None if value is None else normalize_excel_range(value)

    @model_validator(mode="after")
    def validate_cell_sources(self) -> Self:
        """Ensure every cell traces to this workbook and worksheet."""
        coordinates = [cell.coordinate.casefold() for cell in self.cells]
        if len(coordinates) != len(set(coordinates)):
            msg = "worksheet cell coordinates must be unique"
            raise ValueError(msg)
        positions = tuple(
            (
                excel_range_bounds(cell.coordinate).min_row,
                excel_range_bounds(cell.coordinate).min_column,
            )
            for cell in self.cells
        )
        if positions != tuple(sorted(positions)):
            msg = "worksheet cells must use deterministic row-major order"
            raise ValueError(msg)
        for cell in self.cells:
            if cell.source.file_id != self.file.file_id:
                msg = "worksheet cell file_id must match workbook file_id"
                raise ValueError(msg)
            if cell.source.sheet_name != self.sheet_name:
                msg = "worksheet cell sheet_name must match worksheet"
                raise ValueError(msg)
        expected_range = None
        if positions:
            expected_range = format_excel_range(
                min(column for _row, column in positions),
                min(row for row, _column in positions),
                max(column for _row, column in positions),
                max(row for row, _column in positions),
            )
        if self.used_range != expected_range:
            msg = "worksheet used_range must match represented cells"
            raise ValueError(msg)
        return self


class CellWriteRequest(SdkModel):
    """A value to write to one Excel coordinate."""

    coordinate: NonEmptyString
    value: ExcelValue

    @field_validator("coordinate")
    @classmethod
    def validate_coordinate(cls, value: str) -> str:
        """Validate Excel bounds and normalize the coordinate to uppercase."""
        return normalize_excel_coordinate(value)


class SheetWriteRequest(SdkModel):
    """One worksheet to create in a workbook."""

    name: NonEmptyString
    cells: tuple[CellWriteRequest, ...] = ()

    @model_validator(mode="after")
    def validate_sheet(self) -> Self:
        """Reject invalid names and duplicate writes."""
        if len(self.name) > MAX_WORKSHEET_NAME_LENGTH:
            msg = "worksheet name must contain at most 31 characters"
            raise ValueError(msg)
        if any(character in self.name for character in r"[]:*?/\\"):
            msg = "worksheet name contains a forbidden character"
            raise ValueError(msg)
        coordinates = [cell.coordinate.upper() for cell in self.cells]
        if len(coordinates) != len(set(coordinates)):
            msg = "worksheet cell coordinates must be unique"
            raise ValueError(msg)
        return self


class WorkbookWriteRequest(SdkModel):
    """A complete local workbook creation request."""

    sheets: tuple[SheetWriteRequest, ...] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_unique_sheet_names(self) -> Self:
        """Reject duplicate worksheet names."""
        names = [sheet.name.casefold() for sheet in self.sheets]
        if len(names) != len(set(names)):
            msg = "worksheet names must be unique"
            raise ValueError(msg)
        return self

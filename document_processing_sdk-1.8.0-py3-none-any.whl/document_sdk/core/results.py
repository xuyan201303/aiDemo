"""Normalized processing result envelopes."""

from __future__ import annotations

import json
from collections.abc import Mapping  # noqa: TC003 - Pydantic resolves this at runtime.
from enum import StrEnum
from typing import Any, Self, cast

from pydantic import (
    Field,
    JsonValue,
    field_serializer,
    field_validator,
    model_validator,
)

from document_sdk.core._metadata import (
    freeze_json_mapping,
    thaw_json_mapping,
    validate_safe_metadata,
)
from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.core.local_ocr_quality import (
    LocalOcrQualityDecision,
    LocalOcrQualityReport,
    _local_ocr_quality_usage_matches,
    _validate_provider_usage,
    _validate_quality_report,
)
from document_sdk.core.models import (
    CloudExecutionAttemptEvidence,
    ProviderUsage,
    SdkModel,
    SourceReference,
)


def _validated_preprocessing_quality_lineage(
    preprocessing_report: Any | None,
    quality_report: LocalOcrQualityReport | None,
) -> tuple[Any | None, LocalOcrQualityReport | None]:
    """Validate optional preprocessing lineage without eager Core-to-OCR imports."""
    if preprocessing_report is None:
        return None, quality_report
    if quality_report is None:
        msg = "Local OCR preprocessing metadata are inconsistent"
        raise ValueError(msg)
    from document_sdk.ocr.preprocessing_models import (  # noqa: PLC0415
        _validate_preprocessing_quality_lineage,
    )

    try:
        return _validate_preprocessing_quality_lineage(
            preprocessing_report,
            quality_report,
        )
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception as exc:  # noqa: BLE001 - sanitized model boundary.
        msg = "Local OCR preprocessing metadata are inconsistent"
        _raise_redacted_translation(exc, ValueError(msg))


def _require_builtin_json_tree(value: object) -> None:
    """Reject caller-defined containers before safe JSON-mode validation."""
    actual_type = type(value)
    if (
        value is None
        or actual_type in {str, int, float, bool}
        or isinstance(value, StrEnum)
    ):
        return
    if actual_type is dict:
        mapping = cast("dict[object, object]", value)
        for key, item in mapping.items():
            if type(key) is not str:
                msg = "Local OCR preprocessing report is invalid"
                raise ValueError(msg)
            _require_builtin_json_tree(item)
        return
    if actual_type in {list, tuple}:
        sequence = cast("list[object] | tuple[object, ...]", value)
        for item in sequence:
            _require_builtin_json_tree(item)
        return
    msg = "Local OCR preprocessing report is invalid"
    raise ValueError(msg)


class ProcessingWarning(SdkModel):
    """A non-fatal processing condition."""

    code: str = Field(min_length=1)
    message: str = Field(min_length=1)
    source: SourceReference | None = None
    category: str | None = Field(default=None, min_length=1)
    count: int | None = Field(default=None, ge=1)


class ProcessingError(SdkModel):
    """A normalized processing failure description."""

    code: str = Field(min_length=1)
    message: str = Field(min_length=1)
    retryable: bool = False
    source: SourceReference | None = None


class ProcessingMetadata(SdkModel):
    """Safe operational metadata that excludes runtime credentials."""

    operation: str = Field(min_length=1)
    provider_name: str | None = None
    profile_id: str | None = None
    model_id: str | None = None
    provider_usage: ProviderUsage | None = None
    cloud_execution_attempt: CloudExecutionAttemptEvidence | None = None
    local_ocr_quality_report: LocalOcrQualityReport | None = None
    local_ocr_preprocessing_report: Any | None = None
    duration_ms: float | None = Field(default=None, ge=0)
    attributes: Mapping[str, JsonValue] = Field(default_factory=dict)

    @field_validator("local_ocr_preprocessing_report", mode="before")
    @classmethod
    def validate_preprocessing_report(cls, value: object | None) -> object | None:
        """Validate the additive report without making Core import OCR eagerly."""
        if value is None:
            return None
        from document_sdk.ocr.preprocessing_models import (  # noqa: PLC0415
            LocalOcrPreprocessingReport,
            _bound_preprocessing_report_raw_evidence,
        )

        if type(value) is LocalOcrPreprocessingReport:
            candidate = value
        elif type(value) is dict:
            try:
                bounded = _bound_preprocessing_report_raw_evidence(value)
                _require_builtin_json_tree(bounded)
                payload = json.dumps(
                    bounded,
                    allow_nan=False,
                    ensure_ascii=False,
                    separators=(",", ":"),
                )
                candidate = LocalOcrPreprocessingReport.model_validate_json(payload)
            except Exception as exc:  # noqa: BLE001 - sanitized model boundary.
                msg = "Local OCR preprocessing report is invalid"
                _raise_redacted_translation(exc, ValueError(msg))
        else:
            msg = "Local OCR preprocessing report is invalid"
            raise ValueError(msg)
        try:
            return _revalidate_model_instance_json(
                candidate,
                LocalOcrPreprocessingReport,
                "Local OCR preprocessing report is invalid",
            )
        except Exception as exc:  # noqa: BLE001 - sanitized model boundary.
            msg = "Local OCR preprocessing report is invalid"
            _raise_redacted_translation(exc, ValueError(msg))

    @model_validator(mode="after")
    def freeze_safe_attributes(self) -> Self:  # noqa: C901
        """Validate and deeply freeze safe JSON metadata."""
        usage = _validate_provider_usage(self.provider_usage)
        object.__setattr__(self, "provider_usage", usage)
        if usage is not None and (
            (
                self.provider_name is not None
                and self.provider_name != usage.provider_name
            )
            or (self.profile_id is not None and self.profile_id != usage.profile_id)
            or (self.model_id is not None and self.model_id != usage.model_id)
        ):
            msg = "Provider identity metadata are inconsistent"
            raise ValueError(msg)
        attempt = self.cloud_execution_attempt
        if attempt is not None:
            if usage is None:
                msg = "Cloud execution attempt and Provider usage are inconsistent"
                raise ValueError(msg)
            try:
                from document_sdk.ocr._azure_execution import (  # noqa: PLC0415
                    _validated_completed_cloud_result,
                )

                usage, attempt = _validated_completed_cloud_result(
                    usage,
                    attempt,
                )
            except Exception as exc:  # noqa: BLE001 - sanitized model boundary.
                _raise_redacted_translation(
                    exc,
                    ValueError(
                        "Cloud execution attempt and Provider usage are inconsistent"
                    ),
                )
            object.__setattr__(self, "provider_usage", usage)
            object.__setattr__(self, "cloud_execution_attempt", attempt)
        report = self.local_ocr_quality_report
        preprocessing_report = self.local_ocr_preprocessing_report
        if report is not None:
            report = _validate_quality_report(report)
        preprocessing_report, report = _validated_preprocessing_quality_lineage(
            preprocessing_report,
            report,
        )
        object.__setattr__(
            self,
            "local_ocr_preprocessing_report",
            preprocessing_report,
        )
        object.__setattr__(self, "local_ocr_quality_report", report)
        if report is not None:
            preprocessing_attempt_count = (
                0
                if preprocessing_report is None
                else sum(
                    item.attempt_count - 1
                    for item in preprocessing_report.input_summaries
                )
            )
            preprocessing_pixel_count = (
                0
                if preprocessing_report is None
                else preprocessing_report.total_preprocessing_pixels
            )
            preprocessing_operation_count = (
                0
                if preprocessing_report is None
                else preprocessing_report.total_extra_ocr_operations
            )
            if not _local_ocr_quality_usage_matches(
                summary=report.summary,
                usage=usage,
                preprocessing_attempt_count=preprocessing_attempt_count,
                preprocessing_operation_count=preprocessing_operation_count,
                preprocessing_pixel_count=preprocessing_pixel_count,
            ):
                msg = "Local OCR quality and Provider usage are inconsistent"
                raise ValueError(msg)
            if (
                report.summary.decision is LocalOcrQualityDecision.NOT_APPLICABLE
                and usage is not None
            ):
                msg = "Not-applicable Local OCR quality cannot contain Provider usage"
                raise ValueError(msg)
            if usage is not None and (
                (
                    self.provider_name is not None
                    and self.provider_name != usage.provider_name
                )
                or (self.profile_id is not None and self.profile_id != usage.profile_id)
                or (self.model_id is not None and self.model_id != usage.model_id)
            ):
                msg = "Local OCR Provider identity metadata are inconsistent"
                raise ValueError(msg)
            object.__setattr__(self, "local_ocr_quality_report", report)
        if preprocessing_report is not None:
            expected_attempts = sum(
                item.attempt_count - 1 for item in preprocessing_report.input_summaries
            )
            if (
                usage is None
                or report is None
                or usage.provider_name != "local_ocr"
                or usage.local_preprocessing_attempt_count != expected_attempts
                or usage.local_preprocessing_operation_count
                != preprocessing_report.total_extra_ocr_operations
                or usage.local_preprocessing_pixel_count
                != preprocessing_report.total_preprocessing_pixels
            ):
                msg = "Local OCR preprocessing metadata are inconsistent"
                raise ValueError(msg)
        elif usage is not None and (
            usage.local_preprocessing_attempt_count != 0
            or usage.local_preprocessing_operation_count != 0
            or usage.local_preprocessing_pixel_count != 0
        ):
            msg = "Local OCR preprocessing usage requires a report"
            raise ValueError(msg)
        validate_safe_metadata(self.attributes)
        object.__setattr__(
            self,
            "attributes",
            freeze_json_mapping(self.attributes),
        )
        return self

    @field_serializer("attributes")
    def serialize_attributes(
        self,
        value: Mapping[str, JsonValue],
    ) -> dict[str, JsonValue]:
        """Serialize immutable metadata as ordinary JSON objects and arrays."""
        return thaw_json_mapping(value)


class ProcessingResult[ResultT](SdkModel):
    """A normalized generic result with warnings, errors, and metadata."""

    data: ResultT | None = None
    warnings: tuple[ProcessingWarning, ...] = ()
    errors: tuple[ProcessingError, ...] = ()
    metadata: ProcessingMetadata

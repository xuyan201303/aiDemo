"""Dependency-free Excel coordinate validation."""

from __future__ import annotations

import re
from typing import NamedTuple

MAX_EXCEL_COLUMN = 16_384
MAX_EXCEL_ROW = 1_048_576
_CELL_PATTERN = re.compile(r"^([A-Za-z]+)([0-9]+)$")


class ExcelRangeBounds(NamedTuple):
    """Normalized one-based rectangular Excel range bounds."""

    normalized: str
    min_column: int
    min_row: int
    max_column: int
    max_row: int

    @property
    def cell_count(self) -> int:
        """Return the number of cells in the inclusive rectangle."""
        return (self.max_column - self.min_column + 1) * (
            self.max_row - self.min_row + 1
        )


def _column_number(letters: str) -> int:
    """Convert uppercase Excel column letters to a one-based number."""
    number = 0
    for character in letters:
        number = number * 26 + ord(character) - ord("A") + 1
    return number


def excel_column_letter(column: int) -> str:
    """Convert a validated one-based column number to Excel letters."""
    if column < 1 or column > MAX_EXCEL_COLUMN:
        msg = "Excel column is outside A:XFD"
        raise ValueError(msg)
    letters = ""
    while column:
        column, remainder = divmod(column - 1, 26)
        letters = chr(ord("A") + remainder) + letters
    return letters


def _coordinate_parts(value: str) -> tuple[int, int]:
    """Return the one-based column and row from a normalized coordinate."""
    match = _CELL_PATTERN.fullmatch(value)
    if match is None:  # pragma: no cover - callers normalize first.
        msg = "invalid Excel cell coordinate"
        raise ValueError(msg)
    column_letters, row_text = match.groups()
    return _column_number(column_letters), int(row_text)


def normalize_excel_coordinate(value: str) -> str:
    """Validate and uppercase one Excel cell coordinate."""
    match = _CELL_PATTERN.fullmatch(value)
    if match is None:
        msg = "invalid Excel cell coordinate"
        raise ValueError(msg)
    column_letters, row_text = match.groups()
    normalized_column = column_letters.upper()
    column = _column_number(normalized_column)
    row = int(row_text)
    if column < 1 or column > MAX_EXCEL_COLUMN:
        msg = "Excel column is outside A:XFD"
        raise ValueError(msg)
    if row < 1 or row > MAX_EXCEL_ROW:
        msg = "Excel row is outside 1:1048576"
        raise ValueError(msg)
    return f"{normalized_column}{row}"


def normalize_excel_range(value: str) -> str:
    """Validate, order-check, and uppercase an Excel cell or range."""
    parts = value.split(":")
    if len(parts) not in {1, 2}:
        msg = "invalid Excel cell range"
        raise ValueError(msg)
    start = normalize_excel_coordinate(parts[0])
    if len(parts) == 1:
        return start
    end = normalize_excel_coordinate(parts[1])

    start_match = _CELL_PATTERN.fullmatch(start)
    end_match = _CELL_PATTERN.fullmatch(end)
    if start_match is None or end_match is None:  # pragma: no cover - normalized.
        msg = "invalid Excel cell range"
        raise ValueError(msg)
    start_column, start_row = start_match.groups()
    end_column, end_row = end_match.groups()
    if _column_number(start_column) > _column_number(end_column) or int(
        start_row
    ) > int(end_row):
        msg = "Excel range start must not be after its end"
        raise ValueError(msg)
    return f"{start}:{end}"


def excel_range_bounds(value: str) -> ExcelRangeBounds:
    """Validate a cell range and return its normalized inclusive bounds."""
    normalized = normalize_excel_range(value)
    parts = normalized.split(":")
    start = parts[0]
    end = parts[-1]
    min_column, min_row = _coordinate_parts(start)
    max_column, max_row = _coordinate_parts(end)
    return ExcelRangeBounds(
        normalized=normalized,
        min_column=min_column,
        min_row=min_row,
        max_column=max_column,
        max_row=max_row,
    )


def format_excel_range(
    min_column: int,
    min_row: int,
    max_column: int,
    max_row: int,
) -> str:
    """Format already validated inclusive Excel bounds as a cell range."""
    start = f"{excel_column_letter(min_column)}{min_row}"
    end = f"{excel_column_letter(max_column)}{max_row}"
    return start if start == end else f"{start}:{end}"

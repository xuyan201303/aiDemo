"""Provider-free planning for the stage-aware one-file workflow."""

# ruff: noqa: BLE001, EM101, PLR0913, TRY003

from __future__ import annotations

from typing import TYPE_CHECKING, cast

from document_sdk import __version__
from document_sdk.core import FileDescriptor, FileFingerprint, ProcessingWarning
from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.document import (
    DocumentFormat,
    DocumentInspectionResult,
    DocumentSourceChangedError,
    DocumentType,
    DocumentTypeDetection,
    inspect_document,
)
from document_sdk.document.models import FORMAT_EXTENSIONS
from document_sdk.document.processing import (
    _detect_identity,
    _immutable_expected_source,
    _prepare_document,
    _raw_identity,
)
from document_sdk.ocr._azure_preflight import effective_azure_page_limit
from document_sdk.pdf import PdfProcessingLimits
from document_sdk.pdf._document import preflight_pdf_structure
from document_sdk.workflow.errors import DocumentWorkflowConfigurationError
from document_sdk.workflow.models import (
    WORKFLOW_ARTIFACT_SERIALIZATION_VERSION,
    WORKFLOW_CONTRACT_VERSION,
    WORKFLOW_PDF_PREFLIGHT_MAX_PAGES,
    DocumentWorkflowPlan,
    DocumentWorkflowRequest,
    WorkflowArtifactKind,
    WorkflowExtractionMode,
    WorkflowLimitation,
    WorkflowOcrRoute,
    WorkflowOcrScope,
    WorkflowPdfPreflight,
    WorkflowPdfProcessingMode,
    WorkflowProviderCategory,
    WorkflowProviderRequirement,
    WorkflowRoute,
    WorkflowSourceIdentity,
    WorkflowStageKind,
    WorkflowStagePlan,
    WorkflowStageStatus,
    workflow_fingerprint,
    workflow_source_identity_from_descriptor,
)

if TYPE_CHECKING:
    from pathlib import Path

    from document_sdk.document.models import PdfDocumentInspection


def _validated_request(request: DocumentWorkflowRequest) -> DocumentWorkflowRequest:
    if type(request) is not DocumentWorkflowRequest:
        raise DocumentWorkflowConfigurationError("Document workflow request is invalid")
    try:
        return _revalidate_model_instance_json(
            request,
            DocumentWorkflowRequest,
            "Document workflow request is invalid",
        )
    except DocumentWorkflowConfigurationError:
        raise
    except Exception:
        raise DocumentWorkflowConfigurationError(
            "Document workflow request is invalid"
        ) from None


def _source_identity(inspection: DocumentInspectionResult) -> WorkflowSourceIdentity:
    return workflow_source_identity_from_descriptor(
        inspection.inspection.inspection.file
    )


def _detected_source_descriptor(
    detection: DocumentTypeDetection,
) -> FileDescriptor:
    """Project content-derived detection into the released Unified descriptor."""
    envelope = detection.envelope
    return FileDescriptor(
        file_id=envelope.sha256,
        filename=envelope.source_name,
        extension=min(FORMAT_EXTENSIONS[envelope.document_format]),
        mime_type=envelope.media_type,
        size_bytes=envelope.byte_size,
        fingerprint=FileFingerprint(value=envelope.sha256),
    )


def _ocr_scope(inspection: DocumentInspectionResult) -> WorkflowOcrScope:
    if inspection.envelope.document_type is not DocumentType.PDF:
        return WorkflowOcrScope.NOT_APPLICABLE
    payload = cast("PdfDocumentInspection", inspection.inspection)
    candidate_count = len(payload.inspection.ocr_candidate_page_numbers)
    if candidate_count == 0:
        return WorkflowOcrScope.NONE
    if candidate_count == payload.inspection.page_count:
        return WorkflowOcrScope.ALL
    return WorkflowOcrScope.SOME


def _route(
    document_type: DocumentType,
    ocr_route: WorkflowOcrRoute,
    pdf_processing_mode: WorkflowPdfProcessingMode,
) -> WorkflowRoute:
    if document_type is DocumentType.EXCEL:
        return WorkflowRoute.EXCEL_LOCAL
    if document_type is DocumentType.WORD:
        return WorkflowRoute.DOCX_LOCAL
    if document_type is DocumentType.PDF:
        if pdf_processing_mode is WorkflowPdfProcessingMode.AZURE_FIRST:
            return WorkflowRoute.PDF_AZURE_FIRST
        return {
            WorkflowOcrRoute.NONE: WorkflowRoute.PDF_NATIVE,
            WorkflowOcrRoute.LOCAL: WorkflowRoute.PDF_HYBRID_LOCAL,
            WorkflowOcrRoute.AZURE: WorkflowRoute.PDF_HYBRID_AZURE,
        }[ocr_route]
    return {
        WorkflowOcrRoute.NONE: WorkflowRoute.IMAGE_INSPECTION,
        WorkflowOcrRoute.LOCAL: WorkflowRoute.IMAGE_LOCAL_OCR,
        WorkflowOcrRoute.AZURE: WorkflowRoute.IMAGE_AZURE,
    }[ocr_route]


def _limitation(code: str, message: str) -> WorkflowLimitation:
    return WorkflowLimitation(code=code, message=message)


def _route_limitations(
    *,
    document_format: DocumentFormat,
    document_type: DocumentType,
    route: WorkflowRoute,
    ocr_scope: WorkflowOcrScope,
    request: DocumentWorkflowRequest,
) -> tuple[tuple[WorkflowLimitation, ...], bool]:
    limitations: list[WorkflowLimitation] = []
    supported = True
    if document_type in {DocumentType.EXCEL, DocumentType.WORD} and (
        request.ocr_route is not WorkflowOcrRoute.NONE
    ):
        limitations.append(
            _limitation(
                "ocr_route_incompatible",
                "The selected document family does not use an OCR route",
            )
        )
        supported = False
    if (
        document_type is not DocumentType.PDF
        and request.pdf_processing_mode is WorkflowPdfProcessingMode.AZURE_FIRST
    ):
        limitations.append(
            _limitation(
                "pdf_processing_mode_incompatible",
                "Azure-first PDF processing requires a PDF source",
            )
        )
        supported = False
    if document_type is DocumentType.EXCEL and (
        request.extraction_mode is not WorkflowExtractionMode.NONE
    ):
        limitations.append(
            _limitation(
                "excel_extraction_unsupported",
                "Excel extraction is outside the workflow contract",
            )
        )
        supported = False
    if (
        route is WorkflowRoute.IMAGE_INSPECTION
        and request.extraction_mode is not WorkflowExtractionMode.NONE
    ):
        limitations.append(
            _limitation(
                "image_extraction_requires_ocr",
                "Image extraction requires an explicit OCR route",
            )
        )
        supported = False
    if route is WorkflowRoute.IMAGE_AZURE and document_format is DocumentFormat.WEBP:
        limitations.append(
            _limitation(
                "azure_image_format_unsupported",
                "Azure image analysis supports PNG, JPEG, TIFF, and BMP inputs",
            )
        )
        supported = False
    if route is WorkflowRoute.PDF_NATIVE and ocr_scope in {
        WorkflowOcrScope.SOME,
        WorkflowOcrScope.ALL,
    }:
        limitations.append(
            _limitation(
                "ocr_candidates_not_processed",
                "OCR candidate pages remain native-only in this route",
            )
        )
        if request.extraction_mode is not WorkflowExtractionMode.NONE:
            supported = False
    return tuple(sorted(limitations, key=lambda item: item.code)), supported


def _provider_requirements(
    route: WorkflowRoute,
    *,
    ocr_scope: WorkflowOcrScope,
    supported: bool,
) -> tuple[WorkflowProviderRequirement, ...]:
    if not supported:
        return ()
    requirements: list[WorkflowProviderRequirement] = []
    ocr_required = not (
        route in {WorkflowRoute.PDF_HYBRID_LOCAL, WorkflowRoute.PDF_HYBRID_AZURE}
        and ocr_scope is WorkflowOcrScope.NONE
    )
    if ocr_required and route in {
        WorkflowRoute.PDF_HYBRID_LOCAL,
        WorkflowRoute.IMAGE_LOCAL_OCR,
    }:
        requirements.append(
            WorkflowProviderRequirement(
                category=WorkflowProviderCategory.LOCAL_OCR,
                stage_kind=WorkflowStageKind.OCR_OR_AZURE,
            )
        )
    elif ocr_required and route in {
        WorkflowRoute.PDF_HYBRID_AZURE,
        WorkflowRoute.PDF_AZURE_FIRST,
        WorkflowRoute.IMAGE_AZURE,
    }:
        requirements.append(
            WorkflowProviderRequirement(
                category=WorkflowProviderCategory.AZURE_DOCUMENT_INTELLIGENCE,
                stage_kind=WorkflowStageKind.OCR_OR_AZURE,
            )
        )
    return tuple(requirements)


def _expected_document(route: WorkflowRoute) -> bool:
    return route not in {
        WorkflowRoute.EXCEL_LOCAL,
        WorkflowRoute.IMAGE_INSPECTION,
    }


def _required_artifacts(
    *,
    route: WorkflowRoute,
    request: DocumentWorkflowRequest,
    supported: bool,
) -> tuple[WorkflowArtifactKind, ...]:
    if not supported or not request.output_policy.persist_intermediate_artifacts:
        return ()
    artifacts = []
    if route is not WorkflowRoute.PDF_AZURE_FIRST:
        artifacts.append(WorkflowArtifactKind.NATIVE_RESULT)
    if _expected_document(route):
        artifacts.append(WorkflowArtifactKind.DOCUMENT)
    if request.extraction_mode is not WorkflowExtractionMode.NONE:
        artifacts.append(WorkflowArtifactKind.STRUCTURED_EXTRACTION)
    return tuple(artifacts)


def _stage_plan(
    kind: WorkflowStageKind,
    *,
    source: WorkflowSourceIdentity,
    route: WorkflowRoute,
    request_identity: str,
    provider_category: WorkflowProviderCategory | None,
    cloud: bool,
    artifacts: tuple[WorkflowArtifactKind, ...],
    skip_reason: str | None,
) -> WorkflowStagePlan:
    identity = workflow_fingerprint(
        f"planned-{kind.value}",
        {
            "provider_category": (
                None if provider_category is None else provider_category.value
            ),
            "request_identity": request_identity,
            "route": route.value,
            "sdk_version": __version__,
            "source": source.model_dump(mode="json"),
        },
    )
    return WorkflowStagePlan(
        kind=kind,
        status=(
            WorkflowStageStatus.SKIPPED
            if skip_reason is not None
            else WorkflowStageStatus.PLANNED
        ),
        stage_identity=identity,
        provider_category=None if skip_reason is not None else provider_category,
        cloud_authorization_required=False if skip_reason is not None else cloud,
        artifact_outputs=() if skip_reason is not None else artifacts,
        reason_code=skip_reason,
    )


def _stages(
    *,
    source: WorkflowSourceIdentity,
    route: WorkflowRoute,
    request: DocumentWorkflowRequest,
    request_identity: str,
    ocr_scope: WorkflowOcrScope,
    supported: bool,
) -> tuple[WorkflowStagePlan, ...]:
    ocr_provider: WorkflowProviderCategory | None = None
    if route in {WorkflowRoute.PDF_HYBRID_LOCAL, WorkflowRoute.IMAGE_LOCAL_OCR}:
        ocr_provider = WorkflowProviderCategory.LOCAL_OCR
    elif route in {
        WorkflowRoute.PDF_HYBRID_AZURE,
        WorkflowRoute.PDF_AZURE_FIRST,
        WorkflowRoute.IMAGE_AZURE,
    }:
        ocr_provider = WorkflowProviderCategory.AZURE_DOCUMENT_INTELLIGENCE
    persist = request.output_policy.persist_intermediate_artifacts and supported
    return (
        _stage_plan(
            WorkflowStageKind.DETECT,
            source=source,
            route=route,
            request_identity=request_identity,
            provider_category=None,
            cloud=False,
            artifacts=(),
            skip_reason=None,
        ),
        _stage_plan(
            WorkflowStageKind.INSPECT,
            source=source,
            route=route,
            request_identity=request_identity,
            provider_category=None,
            cloud=False,
            artifacts=(),
            skip_reason=None,
        ),
        _stage_plan(
            WorkflowStageKind.NATIVE_ANALYSIS,
            source=source,
            route=route,
            request_identity=request_identity,
            provider_category=None,
            cloud=False,
            artifacts=(WorkflowArtifactKind.NATIVE_RESULT,) if persist else (),
            skip_reason=(
                "unsupported_route"
                if not supported
                else "azure_whole_document"
                if route is WorkflowRoute.PDF_AZURE_FIRST
                else None
            ),
        ),
        _stage_plan(
            WorkflowStageKind.OCR_OR_AZURE,
            source=source,
            route=route,
            request_identity=request_identity,
            provider_category=ocr_provider,
            cloud=ocr_provider is WorkflowProviderCategory.AZURE_DOCUMENT_INTELLIGENCE,
            artifacts=(),
            skip_reason=(
                "unsupported_route"
                if not supported
                else "ocr_no_candidates"
                if route
                in {WorkflowRoute.PDF_HYBRID_LOCAL, WorkflowRoute.PDF_HYBRID_AZURE}
                and ocr_scope is WorkflowOcrScope.NONE
                else "ocr_not_requested"
                if ocr_provider is None
                else None
            ),
        ),
        _stage_plan(
            WorkflowStageKind.NORMALIZE,
            source=source,
            route=route,
            request_identity=request_identity,
            provider_category=None,
            cloud=False,
            artifacts=(WorkflowArtifactKind.DOCUMENT,) if persist else (),
            skip_reason=(
                "unsupported_route"
                if not supported
                else "document_not_produced"
                if not _expected_document(route)
                else None
            ),
        ),
        _stage_plan(
            WorkflowStageKind.STRUCTURED_EXTRACTION,
            source=source,
            route=route,
            request_identity=request_identity,
            provider_category=None,
            cloud=False,
            artifacts=(WorkflowArtifactKind.STRUCTURED_EXTRACTION,) if persist else (),
            skip_reason=(
                "unsupported_route"
                if not supported
                else "extraction_not_requested"
                if request.extraction_mode is WorkflowExtractionMode.NONE
                else None
            ),
        ),
        _stage_plan(
            WorkflowStageKind.FINALIZE,
            source=source,
            route=route,
            request_identity=request_identity,
            provider_category=None,
            cloud=False,
            artifacts=(),
            skip_reason=None,
        ),
    )


def _build_plan(
    inspection: DocumentInspectionResult | None,
    request: DocumentWorkflowRequest,
    *,
    detection: DocumentTypeDetection | None = None,
    source: WorkflowSourceIdentity | None = None,
    pdf_preflight: WorkflowPdfPreflight | None = None,
) -> DocumentWorkflowPlan:
    if inspection is not None:
        source = _source_identity(inspection)
        document_type = inspection.envelope.document_type
        document_format = inspection.envelope.document_format
        ocr_scope = _ocr_scope(inspection)
    else:
        if detection is None or source is None:
            raise DocumentWorkflowConfigurationError(
                "Workflow source preflight is incomplete"
            )
        document_type = detection.envelope.document_type
        document_format = detection.envelope.document_format
        if document_type is DocumentType.PDF:
            if pdf_preflight is None:
                raise DocumentWorkflowConfigurationError(
                    "Workflow PDF structural preflight is incomplete"
                )
            ocr_scope = WorkflowOcrScope.WHOLE_DOCUMENT
        else:
            ocr_scope = WorkflowOcrScope.NOT_APPLICABLE
    route = _route(
        document_type,
        request.ocr_route,
        request.pdf_processing_mode,
    )
    limitations, supported = _route_limitations(
        document_format=document_format,
        document_type=document_type,
        route=route,
        ocr_scope=ocr_scope,
        request=request,
    )
    request_identity = request.fingerprint()
    stages = _stages(
        source=source,
        route=route,
        request=request,
        request_identity=request_identity,
        ocr_scope=ocr_scope,
        supported=supported,
    )
    requirements = _provider_requirements(
        route,
        ocr_scope=ocr_scope,
        supported=supported,
    )
    artifacts = _required_artifacts(
        route=route,
        request=request,
        supported=supported,
    )
    plan_payload = {
        "document_format": document_format.value,
        "document_type": document_type.value,
        "limitations": [item.code for item in limitations],
        "provider_requirements": [
            {
                "category": item.category.value,
                "stage_kind": item.stage_kind.value,
            }
            for item in requirements
        ],
        "request_identity": request_identity,
        "route": route.value,
        "pdf_processing_mode": request.pdf_processing_mode.value,
        "pdf_preflight": (
            None if pdf_preflight is None else pdf_preflight.model_dump(mode="json")
        ),
        "sdk_version": __version__,
        "source": source.model_dump(mode="json"),
        "stage_identities": [stage.stage_identity for stage in stages],
        "supported": supported,
    }
    plan_identity = workflow_fingerprint("plan", plan_payload)
    workflow_identity = workflow_fingerprint(
        "planned-operation",
        {
            "plan_identity": plan_identity,
            "request_identity": request_identity,
            "artifact_serialization_version": (WORKFLOW_ARTIFACT_SERIALIZATION_VERSION),
            "contract_version": WORKFLOW_CONTRACT_VERSION,
            "sdk_version": __version__,
            "source": source.model_dump(mode="json"),
        },
    )
    return DocumentWorkflowPlan(
        source=source,
        document_type=document_type,
        document_format=document_format,
        route=route,
        pdf_processing_mode=request.pdf_processing_mode,
        pdf_preflight=pdf_preflight,
        ocr_scope=ocr_scope,
        ocr_requested=(
            request.ocr_route is not WorkflowOcrRoute.NONE
            or route is WorkflowRoute.PDF_AZURE_FIRST
        ),
        azure_permitted=request.policy.azure_execution_policy.allow_cloud_execution,
        azure_required=(
            route
            in {
                WorkflowRoute.PDF_HYBRID_AZURE,
                WorkflowRoute.PDF_AZURE_FIRST,
                WorkflowRoute.IMAGE_AZURE,
            }
            and not (
                route is WorkflowRoute.PDF_HYBRID_AZURE
                and ocr_scope is WorkflowOcrScope.NONE
            )
        ),
        extraction_mode=request.extraction_mode,
        request_identity=request_identity,
        plan_identity=plan_identity,
        workflow_identity=workflow_identity,
        provider_requirements=requirements,
        required_artifacts=artifacts,
        stages=stages,
        supported=supported,
        limitations=limitations,
    )


def _plan_document_workflow_with_warnings(
    source: Path,
    request: DocumentWorkflowRequest,
    *,
    expected_source_identity: WorkflowSourceIdentity | None = None,
    _source_is_immutable: bool = False,
) -> tuple[DocumentWorkflowPlan, tuple[ProcessingWarning, ...]]:
    """Return one plan plus trusted detection warnings needed by execution."""
    validated_request = _validated_request(request)
    expected_identity = (
        None
        if expected_source_identity is None
        else (
            expected_source_identity.sha256,
            expected_source_identity.byte_size,
        )
    )
    if expected_identity is not None and not _source_is_immutable:
        with _immutable_expected_source(source, expected_identity) as snapshot:
            return _plan_document_workflow_with_warnings(
                snapshot,
                validated_request,
                expected_source_identity=expected_source_identity,
                _source_is_immutable=True,
            )
    if validated_request.ocr_route is WorkflowOcrRoute.AZURE:
        policy = validated_request.policy.azure_execution_policy
        detection = _detect_identity(
            source,
            expected_identity=expected_identity,
            max_bytes=policy.max_input_bytes or None,
        )
        if detection.envelope.document_type is DocumentType.IMAGE:
            if _raw_identity(
                source,
                max_bytes=policy.max_input_bytes or None,
            ) != (
                detection.envelope.sha256,
                detection.envelope.byte_size,
            ):
                if expected_identity is not None:
                    raise DocumentSourceChangedError(
                        "Workflow source changed during image preflight"
                    )
                raise DocumentWorkflowConfigurationError(
                    "Workflow source changed during image preflight"
                )
            descriptor = _detected_source_descriptor(detection)
            return (
                _build_plan(
                    None,
                    validated_request,
                    detection=detection,
                    source=workflow_source_identity_from_descriptor(descriptor),
                ),
                detection.warnings,
            )
    if validated_request.pdf_processing_mode is WorkflowPdfProcessingMode.AZURE_FIRST:
        detection = _detect_identity(
            source,
            expected_identity=expected_identity,
        )
        if detection.envelope.document_type is DocumentType.PDF:
            policy = validated_request.policy.azure_execution_policy
            defaults = PdfProcessingLimits()
            max_pages = effective_azure_page_limit(
                policy.max_pages_or_frames or defaults.max_pages,
                public_model_max_pages_or_frames=(WORKFLOW_PDF_PREFLIGHT_MAX_PAGES),
            )
            max_input_bytes = policy.max_input_bytes or defaults.max_file_bytes
            limits = PdfProcessingLimits(
                max_file_bytes=max_input_bytes,
                max_pages=max_pages,
                max_native_text_pages=max_pages,
            )
            descriptor, structural = preflight_pdf_structure(
                source,
                limits,
                expected_identity=expected_identity,
            )
            source_identity = workflow_source_identity_from_descriptor(descriptor)
            envelope = detection.envelope
            if (
                envelope.sha256 != source_identity.sha256
                or envelope.byte_size != source_identity.byte_size
            ):
                if expected_identity is not None:
                    raise DocumentSourceChangedError(
                        "Workflow source changed during PDF preflight"
                    )
                raise DocumentWorkflowConfigurationError(
                    "Workflow source changed during PDF preflight"
                )
            return (
                _build_plan(
                    None,
                    validated_request,
                    detection=detection,
                    source=source_identity,
                    pdf_preflight=WorkflowPdfPreflight(
                        page_count=structural.page_count,
                        max_pages=max_pages,
                        max_input_bytes=max_input_bytes,
                    ),
                ),
                (),
            )
    inspection = (
        inspect_document(source)
        if expected_identity is None
        else _prepare_document(
            source,
            expected_identity=expected_identity,
        ).inspection
    )
    return _build_plan(inspection, validated_request), ()


def plan_document_workflow(
    source: Path,
    request: DocumentWorkflowRequest,
) -> DocumentWorkflowPlan:
    """Inspect one source and return a content-safe Provider-free workflow plan."""
    plan, _warnings = _plan_document_workflow_with_warnings(source, request)
    return plan


__all__ = ["plan_document_workflow"]

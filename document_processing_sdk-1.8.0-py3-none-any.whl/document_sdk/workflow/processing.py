"""Stage-aware one-file orchestration built from existing SDK operations."""

# ruff: noqa: BLE001, C901, EM101, PLR0912, PLR0913, PLR0915, TRY003

from __future__ import annotations

import hashlib
import inspect
import stat
from dataclasses import dataclass
from pathlib import Path
from typing import Literal, cast

from document_sdk import __version__
from document_sdk.core import (
    CloudExecutionAttemptEvidence,
    CloudExecutionAttemptStatus,
    CloudExecutionPolicy,
    Document,
    DocumentProcessingError,
    DocumentSdkError,
    EncryptedDocumentError,
    ExcelCellLimitExceededError,
    FileDescriptor,
    ImageInspection,
    ImageLimitExceededError,
    ImageProcessingError,
    LocalOcrQualityDecision,
    LocalOcrQualityReport,
    ProcessingError,
    ProcessingWarning,
    ProviderUsage,
    SourceReference,
    UnsupportedFileError,
)
from document_sdk.core._excel_coordinates import excel_range_bounds
from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.errors import (
    DocumentSourceChangedError,
    ProviderConfigurationError,
    _raise_redacted_translation,
)
from document_sdk.core.local_ocr_quality import _validate_quality_report
from document_sdk.document import (
    DocumentAnalysisOptions,
    DocumentAnalysisResult,
    DocumentFormat,
    DocumentInspectionResult,
    DocumentType,
    DocumentTypeMismatchError,
    UnsupportedDocumentOperationError,
    UnsupportedDocumentTypeError,
    analyze_document,
    inspect_document,
)
from document_sdk.document.models import (
    DocxDocumentAnalysis,
    ExcelDocumentAnalysis,
    ImageDocumentAnalysis,
    PdfAnalysisMode,
    PdfDocumentAnalysis,
)
from document_sdk.document.processing import (
    _analyze_document,
    _DocumentIdentityLimitError,
    _immutable_expected_source,
    _prepare_document,
    _raw_identity,
    _UnsupportedDocumentIdentityError,
)
from document_sdk.docx import DocxResourceLimitError, DocxUnsupportedPackageError
from document_sdk.excel import (
    ExcelPackageLimitError,
    UnsupportedWorkbookFeatureError,
    WorkbookFeatureInventory,
    inspect_workbook_features,
    read_range,
    read_sheet,
)
from document_sdk.extraction import (
    StructuredExtractionResult,
    extract_structured_fields,
)
from document_sdk.extraction.extraction import _extract_structured_fields_with_quality
from document_sdk.ocr import (
    AzureDocumentIntelligenceProvider,
    LocalOcrLimitExceededError,
    LocalOcrPreprocessingLimitError,
    LocalOcrPreprocessingReport,
    LocalOcrProvider,
    OcrProvider,
)
from document_sdk.ocr._azure_execution import (
    read_cloud_execution_attempt,
    read_completed_cloud_result,
)
from document_sdk.ocr._azure_identity import (
    AZURE_DOCUMENT_INTELLIGENCE_PROVIDER_NAME,
)
from document_sdk.ocr._azure_preflight import (
    AZURE_DOCUMENT_INTELLIGENCE_MAX_PAGES_OR_FRAMES,
    AzureInputPreflight,
    _azure_image_limits,
    effective_azure_page_limit,
)
from document_sdk.ocr._provider_boundary import (
    _LocalOcrInvocationState,
    _read_provider_context_projection_safely,
)
from document_sdk.ocr.local_errors import _attempt_usage
from document_sdk.ocr.models import OcrAnalysisOptions
from document_sdk.pdf import PdfLimitExceededError
from document_sdk.workflow.artifacts import (
    WorkflowArtifactStore,
    load_workflow_artifact,
    store_workflow_artifact,
    workflow_artifact_output_identity,
)
from document_sdk.workflow.errors import (
    DocumentWorkflowArtifactError,
    DocumentWorkflowConfigurationError,
    DocumentWorkflowError,
    DocumentWorkflowResumeError,
)
from document_sdk.workflow.models import (
    _LOCAL_OCR_QUALITY_REVIEW_CODE,
    _LOCAL_OCR_QUALITY_REVIEW_MESSAGE,
    DocumentWorkflowIntakeIssue,
    DocumentWorkflowIntakeResult,
    DocumentWorkflowIntakeStatus,
    DocumentWorkflowManifest,
    DocumentWorkflowPlan,
    DocumentWorkflowRequest,
    DocumentWorkflowResult,
    DocumentWorkflowStatus,
    ExcelWorkflowOutputMode,
    WorkflowArtifactKind,
    WorkflowArtifactReference,
    WorkflowDocxNativeResult,
    WorkflowExcelNativeResult,
    WorkflowExcelRangeData,
    WorkflowExcelRangeSelection,
    WorkflowExtractionMode,
    WorkflowImageNativeResult,
    WorkflowIssueCategory,
    WorkflowLimitation,
    WorkflowNativeResult,
    WorkflowOcrRoute,
    WorkflowOutputEvidence,
    WorkflowPdfNativeResult,
    WorkflowPdfProcessingMode,
    WorkflowProviderCategory,
    WorkflowProviderIdentity,
    WorkflowRoute,
    WorkflowSourceIdentity,
    WorkflowStageIssue,
    WorkflowStageKind,
    WorkflowStagePlan,
    WorkflowStageResult,
    WorkflowStageStatus,
    _authoritative_local_ocr_quality_usage,
    _FinalWorkflowStageStatus,
    _local_ocr_quality_evidence_binding,
    _workflow_intake_status,
    workflow_fingerprint,
    workflow_source_identity_from_descriptor,
    workflow_usage_from_stages,
)
from document_sdk.workflow.planning import (
    _detected_source_descriptor,
    _plan_document_workflow_with_warnings,
)

_PROTECTED_CLOUD_STATUSES = frozenset(
    {
        CloudExecutionAttemptStatus.SUBMITTED,
        CloudExecutionAttemptStatus.POSSIBLY_PAID,
        CloudExecutionAttemptStatus.COMPLETED,
    }
)
_AZURE_IMAGE_FORMATS: dict[
    DocumentFormat,
    Literal["BMP", "JPEG", "PNG", "TIFF"],
] = {
    DocumentFormat.BMP: "BMP",
    DocumentFormat.JPEG: "JPEG",
    DocumentFormat.PNG: "PNG",
    DocumentFormat.TIFF: "TIFF",
}


@dataclass(frozen=True, slots=True)
class WorkflowLocalOcrProvider:
    """Explicitly declare one caller-supplied OCR Provider as local-only."""

    provider: OcrProvider


@dataclass(frozen=True, slots=True)
class DocumentWorkflowProviders:
    """Runtime-only explicit Providers; unused fields are never inspected."""

    local_ocr: LocalOcrProvider | WorkflowLocalOcrProvider | None = None
    azure: AzureDocumentIntelligenceProvider | None = None


@dataclass(frozen=True, slots=True)
class _ProviderSelection:
    ocr: OcrProvider | None
    identities: tuple[WorkflowProviderIdentity, ...]
    route_identities: dict[WorkflowProviderCategory, str]


@dataclass(frozen=True, slots=True)
class _NativeExecution:
    native: WorkflowNativeResult | None
    document: Document | None
    warnings: tuple[ProcessingWarning, ...]
    usages: tuple[ProviderUsage, ...]
    attempts: tuple[CloudExecutionAttemptEvidence, ...]
    issues: tuple[WorkflowStageIssue, ...]
    excel_cell_count: int
    limitations: tuple[WorkflowLimitation, ...]
    truncated: bool


class _WorkflowSourceChangedError(DocumentWorkflowError):
    """Internal content-safe source mismatch with retained operation evidence."""

    def __init__(
        self,
        *,
        usages: tuple[ProviderUsage, ...] = (),
        attempts: tuple[CloudExecutionAttemptEvidence, ...] = (),
    ) -> None:
        super().__init__("Workflow source changed during execution")
        self.usages = usages
        self.attempts = attempts


class _WorkflowAzureImagePreflightError(DocumentWorkflowError):
    """Internal content-safe image preflight failure before Provider access."""

    def __init__(self, *, category: WorkflowIssueCategory) -> None:
        super().__init__("Workflow Azure image preflight failed")
        self.category = category


class _WorkflowLocalProviderContractError(DocumentWorkflowError):
    """Internal sanitized local-only contract failure with exact evidence."""

    def __init__(
        self,
        *,
        usages: tuple[ProviderUsage, ...],
        attempts: tuple[CloudExecutionAttemptEvidence, ...],
    ) -> None:
        super().__init__("Workflow Local OCR Provider contract failed")
        self.usages = usages
        self.attempts = attempts


class _WorkflowStructuredDocumentMismatchError(DocumentWorkflowError):
    """Internal sanitized extraction mismatch with retained operation evidence."""

    def __init__(
        self,
        *,
        usages: tuple[ProviderUsage, ...] = (),
        attempts: tuple[CloudExecutionAttemptEvidence, ...] = (),
    ) -> None:
        super().__init__("Workflow extraction Document is inconsistent")
        self.usages = usages
        self.attempts = attempts


def _validated_request(request: DocumentWorkflowRequest) -> DocumentWorkflowRequest:
    if type(request) is not DocumentWorkflowRequest:
        raise DocumentWorkflowConfigurationError("Document workflow request is invalid")
    try:
        return _revalidate_model_instance_json(
            request,
            DocumentWorkflowRequest,
            "Document workflow request is invalid",
        )
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            DocumentWorkflowConfigurationError("Document workflow request is invalid"),
        )


def _validated_providers(
    providers: DocumentWorkflowProviders,
) -> DocumentWorkflowProviders:
    if type(providers) is not DocumentWorkflowProviders:
        raise DocumentWorkflowConfigurationError("Workflow Provider bundle is invalid")
    return providers


def _validate_intake_provider_shapes(
    request: DocumentWorkflowRequest,
    providers: DocumentWorkflowProviders,
) -> None:
    """Validate only request-relevant Provider shapes without reading identity."""
    if request.ocr_route is WorkflowOcrRoute.LOCAL:
        declared_local = providers.local_ocr
        if declared_local is not None:
            if type(declared_local) is LocalOcrProvider:
                pass
            elif type(declared_local) is WorkflowLocalOcrProvider:
                local_provider = declared_local.provider
                if isinstance(local_provider, AzureDocumentIntelligenceProvider):
                    raise DocumentWorkflowConfigurationError(
                        "Workflow Local OCR route received a cloud Provider"
                    )
                try:
                    valid_local = isinstance(local_provider, OcrProvider)
                except (KeyboardInterrupt, SystemExit, GeneratorExit):
                    raise
                except Exception as exc:
                    _raise_redacted_translation(
                        exc,
                        DocumentWorkflowConfigurationError(
                            "Workflow Local OCR Provider requires an explicit "
                            "local contract"
                        ),
                    )
                if not valid_local:
                    raise DocumentWorkflowConfigurationError(
                        "Workflow Local OCR Provider requires an explicit "
                        "local contract"
                    )
            else:
                raise DocumentWorkflowConfigurationError(
                    "Workflow Local OCR Provider requires an explicit local contract"
                )
    if (
        request.ocr_route is WorkflowOcrRoute.AZURE
        or request.pdf_processing_mode is WorkflowPdfProcessingMode.AZURE_FIRST
    ):
        azure = providers.azure
        if azure is not None and type(azure) is not AzureDocumentIntelligenceProvider:
            raise DocumentWorkflowConfigurationError(
                "Workflow Azure Provider must use the built-in explicit Provider"
            )


def _ocr_provider_identity(provider: object) -> tuple[str, str]:
    projection = _read_provider_context_projection_safely(
        provider,
        error=DocumentWorkflowConfigurationError(
            "Workflow OCR Provider identity is invalid"
        ),
    )
    return projection.metadata.provider_name, projection.resume_fingerprint


def _validate_azure_provider_policy(
    provider: object,
    request: DocumentWorkflowRequest,
) -> AzureDocumentIntelligenceProvider:
    policy = request.policy.azure_execution_policy
    if not policy.allow_cloud_execution:
        raise DocumentWorkflowConfigurationError(
            "Workflow Azure execution is not authorized"
        )
    if type(provider) is not AzureDocumentIntelligenceProvider:
        raise DocumentWorkflowConfigurationError(
            "Workflow Azure Provider must use the built-in explicit Provider"
        )
    try:
        configured = AzureDocumentIntelligenceProvider._cloud_execution_policy_snapshot(  # noqa: SLF001
            provider
        )
        configured = _revalidate_model_instance_json(
            configured,
            CloudExecutionPolicy,
            "Workflow Azure cloud policy is invalid",
        )
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            DocumentWorkflowConfigurationError(
                "Workflow Azure cloud policy is invalid"
            ),
        )
    if configured != policy:
        raise DocumentWorkflowConfigurationError(
            "Workflow Azure cloud policy does not match the Provider"
        )
    return provider


def _select_providers(
    plan: DocumentWorkflowPlan,
    request: DocumentWorkflowRequest,
    providers: DocumentWorkflowProviders,
) -> _ProviderSelection:
    ocr: OcrProvider | None = None
    identities: list[WorkflowProviderIdentity] = []
    route_identities: dict[WorkflowProviderCategory, str] = {}
    ocr_stage = _plan_stage(plan, WorkflowStageKind.OCR_OR_AZURE)
    if ocr_stage.status is WorkflowStageStatus.PLANNED and plan.route in {
        WorkflowRoute.PDF_HYBRID_LOCAL,
        WorkflowRoute.IMAGE_LOCAL_OCR,
    }:
        if providers.local_ocr is None:
            raise DocumentWorkflowConfigurationError(
                "Workflow Local OCR Provider is required"
            )
        declared_local = providers.local_ocr
        local_provider: OcrProvider
        if type(declared_local) is LocalOcrProvider:
            local_provider = declared_local
        elif type(declared_local) is WorkflowLocalOcrProvider:
            local_provider = declared_local.provider
            if type(local_provider) is AzureDocumentIntelligenceProvider:
                raise DocumentWorkflowConfigurationError(
                    "Workflow Local OCR route received a cloud Provider"
                )
        else:
            raise DocumentWorkflowConfigurationError(
                "Workflow Local OCR Provider requires an explicit local contract"
            )
        provider_name, fingerprint = _ocr_provider_identity(local_provider)
        if provider_name == AZURE_DOCUMENT_INTELLIGENCE_PROVIDER_NAME:
            raise DocumentWorkflowConfigurationError(
                "Workflow Local OCR route received a cloud Provider"
            )
        ocr = local_provider
        category = WorkflowProviderCategory.LOCAL_OCR
        identities.append(
            WorkflowProviderIdentity(category=category, fingerprint=fingerprint)
        )
        route_identities[category] = fingerprint
    elif ocr_stage.status is WorkflowStageStatus.PLANNED and plan.route in {
        WorkflowRoute.PDF_HYBRID_AZURE,
        WorkflowRoute.PDF_AZURE_FIRST,
        WorkflowRoute.IMAGE_AZURE,
    }:
        if providers.azure is None:
            raise DocumentWorkflowConfigurationError(
                "Workflow Azure Provider is required"
            )
        azure = _validate_azure_provider_policy(providers.azure, request)
        provider_name, fingerprint = _ocr_provider_identity(azure)
        if provider_name != AZURE_DOCUMENT_INTELLIGENCE_PROVIDER_NAME:
            raise DocumentWorkflowConfigurationError(
                "Workflow Azure Provider identity is invalid"
            )
        ocr = azure
        category = WorkflowProviderCategory.AZURE_DOCUMENT_INTELLIGENCE
        identities.append(
            WorkflowProviderIdentity(category=category, fingerprint=fingerprint)
        )
        route_identities[category] = fingerprint
    identities.sort(key=lambda item: item.category.value)
    return _ProviderSelection(
        ocr=ocr,
        identities=tuple(identities),
        route_identities=route_identities,
    )


def _analysis_route_identity(
    plan: DocumentWorkflowPlan,
    selection: _ProviderSelection,
) -> str:
    ocr_stage = _plan_stage(plan, WorkflowStageKind.OCR_OR_AZURE)
    if ocr_stage.status is WorkflowStageStatus.SKIPPED:
        return workflow_fingerprint(
            "no-op-ocr-route",
            {
                "ocr_scope": plan.ocr_scope.value,
                "reason_code": ocr_stage.reason_code,
                "route": plan.route.value,
                "sdk_version": __version__,
                "source": plan.source.model_dump(mode="json"),
            },
        )
    category = None
    if plan.route in {WorkflowRoute.PDF_HYBRID_LOCAL, WorkflowRoute.IMAGE_LOCAL_OCR}:
        category = WorkflowProviderCategory.LOCAL_OCR
    elif plan.route in {
        WorkflowRoute.PDF_HYBRID_AZURE,
        WorkflowRoute.PDF_AZURE_FIRST,
        WorkflowRoute.IMAGE_AZURE,
    }:
        category = WorkflowProviderCategory.AZURE_DOCUMENT_INTELLIGENCE
    if category is not None:
        identity = selection.route_identities.get(category)
        if identity is not None:
            return identity
        return workflow_fingerprint(
            "unbound-route",
            {
                "route": plan.route.value,
                "sdk_version": __version__,
                "source": plan.source.model_dump(mode="json"),
            },
        )
    return workflow_fingerprint(
        "local-route",
        {"route": plan.route.value, "source": plan.source.model_dump(mode="json")},
    )


def _document_stage_identities(
    plan: DocumentWorkflowPlan,
    request: DocumentWorkflowRequest,
    selection: _ProviderSelection,
) -> dict[WorkflowStageKind, str]:
    route_identity = _analysis_route_identity(plan, selection)
    analysis_payload = {
        "analysis_options": request.analysis_options.model_dump(mode="json"),
        "excel_native_output": (
            {
                "excel_mode": request.output_policy.excel_mode.value,
                "excel_ranges": [
                    item.model_dump(mode="json")
                    for item in request.output_policy.excel_ranges
                ],
                "include_feature_inventory": (
                    request.output_policy.include_excel_feature_inventory
                ),
                "max_excel_cells": request.output_policy.max_excel_cells,
            }
            if plan.document_type is DocumentType.EXCEL
            else None
        ),
        "hybrid_pdf_options": (
            None
            if request.hybrid_pdf_options is None
            else request.hybrid_pdf_options.model_dump(mode="json")
        ),
        "ocr_route": request.ocr_route.value,
        "pdf_processing_mode": request.pdf_processing_mode.value,
        "ocr_scope": plan.ocr_scope.value,
        "ocr_stage_reason": _plan_stage(
            plan, WorkflowStageKind.OCR_OR_AZURE
        ).reason_code,
        "ocr_stage_status": _plan_stage(
            plan, WorkflowStageKind.OCR_OR_AZURE
        ).status.value,
        "route": plan.route.value,
        "route_identity": route_identity,
        "sdk_version": __version__,
        "source": plan.source.model_dump(mode="json"),
    }
    base = workflow_fingerprint("document-route", analysis_payload)
    return {
        WorkflowStageKind.DETECT: workflow_fingerprint(
            "detect-stage",
            {
                "sdk_version": __version__,
                "source": plan.source.model_dump(mode="json"),
            },
        ),
        WorkflowStageKind.INSPECT: workflow_fingerprint(
            "inspect-stage",
            {
                "document_format": plan.document_format.value,
                "sdk_version": __version__,
                "source": plan.source.model_dump(mode="json"),
            },
        ),
        WorkflowStageKind.NATIVE_ANALYSIS: workflow_fingerprint(
            "native-stage", {"document_route": base}
        ),
        WorkflowStageKind.OCR_OR_AZURE: workflow_fingerprint(
            "ocr-stage", {"document_route": base, "ocr_route": request.ocr_route.value}
        ),
        WorkflowStageKind.NORMALIZE: workflow_fingerprint(
            "normalize-stage", {"document_route": base}
        ),
    }


def _replace_stage_plan(
    stage: WorkflowStagePlan,
    *,
    identity: str,
) -> WorkflowStagePlan:
    return stage.model_copy(update={"stage_identity": identity})


def _bind_initial_plan(
    plan: DocumentWorkflowPlan,
    request: DocumentWorkflowRequest,
    selection: _ProviderSelection,
) -> DocumentWorkflowPlan:
    identities = _document_stage_identities(plan, request, selection)
    stages = tuple(
        _replace_stage_plan(
            stage,
            identity=identities.get(stage.kind, stage.stage_identity),
        )
        for stage in plan.stages
    )
    return plan.model_copy(
        update={
            "provider_identities": selection.identities,
            "stages": stages,
        }
    )


def _finalize_bound_plan(
    plan: DocumentWorkflowPlan,
    request: DocumentWorkflowRequest,
    *,
    structured_extraction_stage_identity: str,
) -> DocumentWorkflowPlan:
    stages = tuple(
        stage.model_copy(
            update={"stage_identity": structured_extraction_stage_identity}
        )
        if stage.kind is WorkflowStageKind.STRUCTURED_EXTRACTION
        else stage
        for stage in plan.stages
    )
    finalize_identity = workflow_fingerprint(
        "finalize-stage",
        {
            "output_policy": request.output_policy.model_dump(mode="json"),
            "sdk_version": __version__,
            "structured_extraction_stage_identity": (
                structured_extraction_stage_identity
            ),
            "source": plan.source.model_dump(mode="json"),
        },
    )
    stages = tuple(
        stage.model_copy(update={"stage_identity": finalize_identity})
        if stage.kind is WorkflowStageKind.FINALIZE
        else stage
        for stage in stages
    )
    plan_identity = workflow_fingerprint(
        "bound-plan",
        {
            "provider_identities": [
                item.model_dump(mode="json") for item in plan.provider_identities
            ],
            "request_identity": plan.request_identity,
            "route": plan.route.value,
            "sdk_version": __version__,
            "source": plan.source.model_dump(mode="json"),
            "stage_identities": [stage.stage_identity for stage in stages],
        },
    )
    workflow_identity = workflow_fingerprint(
        "operation",
        {
            "plan_identity": plan_identity,
            "provider_identities": [
                item.fingerprint for item in plan.provider_identities
            ],
            "sdk_version": __version__,
            "source": plan.source.model_dump(mode="json"),
        },
    )
    return plan.model_copy(
        update={
            "plan_identity": plan_identity,
            "workflow_identity": workflow_identity,
            "stages": stages,
        }
    )


def _plan_stage(
    plan: DocumentWorkflowPlan, kind: WorkflowStageKind
) -> WorkflowStagePlan:
    return next(stage for stage in plan.stages if stage.kind is kind)


def _stage_result(
    plan: DocumentWorkflowPlan,
    kind: WorkflowStageKind,
    *,
    status: _FinalWorkflowStageStatus,
    input_identity: str | None = None,
    output_identity: str | None = None,
    provider_category: WorkflowProviderCategory | None = None,
    provider_identity: str | None = None,
    current_usage: tuple[ProviderUsage, ...] = (),
    retained_usage: tuple[ProviderUsage, ...] = (),
    current_attempts: tuple[CloudExecutionAttemptEvidence, ...] = (),
    retained_attempts: tuple[CloudExecutionAttemptEvidence, ...] = (),
    references: tuple[WorkflowArtifactReference, ...] = (),
    issues: tuple[WorkflowStageIssue, ...] = (),
    retry_eligible: bool = False,
    reuse_eligible: bool = False,
) -> WorkflowStageResult:
    stage = _plan_stage(plan, kind)
    return WorkflowStageResult(
        kind=kind,
        status=status,
        input_identity=input_identity or stage.stage_identity,
        stage_identity=stage.stage_identity,
        output_identity=output_identity,
        provider_category=provider_category,
        provider_identity=provider_identity,
        current_provider_usage=current_usage,
        retained_provider_usage=retained_usage,
        current_cloud_attempts=current_attempts,
        retained_cloud_attempts=retained_attempts,
        artifact_references=references,
        issues=issues,
        retry_eligible=retry_eligible,
        reuse_eligible=reuse_eligible,
    )


def _skipped_result(
    plan: DocumentWorkflowPlan,
    kind: WorkflowStageKind,
) -> WorkflowStageResult:
    return _stage_result(plan, kind, status=WorkflowStageStatus.SKIPPED)


def _analysis_options(
    request: DocumentWorkflowRequest,
    plan: DocumentWorkflowPlan,
) -> DocumentAnalysisOptions:
    if (
        plan.route in {WorkflowRoute.PDF_HYBRID_LOCAL, WorkflowRoute.PDF_HYBRID_AZURE}
        and _plan_stage(plan, WorkflowStageKind.OCR_OR_AZURE).status
        is WorkflowStageStatus.PLANNED
    ):
        return request.analysis_options.model_copy(
            update={
                "pdf_mode": PdfAnalysisMode.HYBRID,
                "hybrid_pdf_options": request.hybrid_pdf_options,
            }
        )
    return request.analysis_options.model_copy(
        update={"pdf_mode": PdfAnalysisMode.NATIVE, "hybrid_pdf_options": None}
    )


def _document_from_analysis(result: DocumentAnalysisResult) -> Document | None:
    analysis = result.analysis
    if type(analysis) is PdfDocumentAnalysis:
        return analysis.document
    if type(analysis) is ImageDocumentAnalysis:
        return None if analysis.ocr_result is None else analysis.ocr_result.data
    if type(analysis) is DocxDocumentAnalysis:
        return analysis.docx.document
    return None


def _native_embedded_document(native: WorkflowNativeResult) -> Document | None:
    if type(native) is WorkflowPdfNativeResult:
        return native.analysis.document
    if type(native) is WorkflowImageNativeResult:
        result = native.analysis.ocr_result
        return None if result is None else result.data
    if type(native) is WorkflowDocxNativeResult:
        return native.analysis.docx.document
    return None


def _validate_native_document_alignment(
    native: WorkflowNativeResult | None,
    document: Document | None,
) -> None:
    if native is None and document is not None:
        return
    embedded = None if native is None else _native_embedded_document(native)
    if embedded != document:
        raise DocumentWorkflowResumeError(
            "Workflow native and normalized Documents are inconsistent"
        )


def _analysis_file_descriptor(result: DocumentAnalysisResult) -> FileDescriptor:
    analysis = result.analysis
    if type(analysis) is PdfDocumentAnalysis:
        return analysis.document.file
    if type(analysis) is ExcelDocumentAnalysis:
        return analysis.workbook.file
    if type(analysis) is ImageDocumentAnalysis:
        return analysis.image.file
    if type(analysis) is DocxDocumentAnalysis:
        return analysis.docx.inspection.file
    raise _WorkflowSourceChangedError


def _validate_native_execution_source(
    result: DocumentAnalysisResult,
    *,
    plan: DocumentWorkflowPlan,
    document: Document | None,
) -> None:
    usages = _analysis_usages(result)
    attempts = result.cloud_execution_attempts
    envelope = result.envelope
    try:
        result_source = workflow_source_identity_from_descriptor(
            _analysis_file_descriptor(result)
        )
        document_source = (
            None
            if document is None
            else workflow_source_identity_from_descriptor(document.file)
        )
    except Exception:
        raise _WorkflowSourceChangedError(
            usages=usages,
            attempts=attempts,
        ) from None
    if (
        result_source != plan.source
        or (document_source is not None and document_source != plan.source)
        or envelope.sha256 != plan.source.sha256
        or envelope.byte_size != plan.source.byte_size
        or envelope.document_type is not plan.document_type
        or envelope.document_format is not plan.document_format
        or envelope.source_name != _analysis_file_descriptor(result).filename
    ):
        raise _WorkflowSourceChangedError(
            usages=usages,
            attempts=attempts,
        )


def _analysis_usages(result: DocumentAnalysisResult) -> tuple[ProviderUsage, ...]:
    if result.provider_usage_breakdown:
        return result.provider_usage_breakdown
    return () if result.provider_usage is None else (result.provider_usage,)


def _validate_local_execution_contract(
    result: DocumentAnalysisResult,
    *,
    plan: DocumentWorkflowPlan,
) -> None:
    if plan.route not in {
        WorkflowRoute.PDF_HYBRID_LOCAL,
        WorkflowRoute.IMAGE_LOCAL_OCR,
    }:
        return
    usages = _analysis_usages(result)
    attempts = result.cloud_execution_attempts
    cloud_usage = any(
        usage.cloud_logical_operation_count
        or usage.cloud_submitted_operation_count
        or usage.cloud_paid_or_possibly_paid_operation_count
        or usage.cloud_transport_retry_count
        or usage.paid_operation_count
        or usage.azure_operation_count
        for usage in usages
    )
    if attempts or cloud_usage:
        raise _WorkflowLocalProviderContractError(
            usages=usages,
            attempts=attempts,
        )


def _excel_range_area(selection: WorkflowExcelRangeSelection) -> int:
    return excel_range_bounds(selection.cell_range).cell_count


def _excel_details(
    source: Path,
    analysis: ExcelDocumentAnalysis,
    request: DocumentWorkflowRequest,
) -> tuple[
    tuple[WorkflowExcelRangeData, ...],
    WorkbookFeatureInventory | None,
    int,
    tuple[WorkflowLimitation, ...],
    bool,
    bool,
]:
    policy = request.output_policy
    ranges: tuple[WorkflowExcelRangeSelection, ...] = ()
    detail_complete = False
    limitations: tuple[WorkflowLimitation, ...] = ()
    truncated = False
    if policy.excel_mode is ExcelWorkflowOutputMode.BOUNDED_RANGES:
        ranges = policy.excel_ranges
        requested_cells = sum(_excel_range_area(item) for item in ranges)
        if requested_cells > policy.max_excel_cells:
            raise DocumentWorkflowConfigurationError(
                "Workflow Excel range request exceeds its cell limit"
            )
    elif policy.excel_mode is ExcelWorkflowOutputMode.FULL_IF_WITHIN_LIMIT:
        selections: list[WorkflowExcelRangeSelection] = []
        requested_cells = 0
        for worksheet in analysis.workbook.worksheets:
            if worksheet.used_range is None:
                continue
            selection = WorkflowExcelRangeSelection(
                sheet_name=worksheet.name,
                cell_range=worksheet.used_range,
            )
            requested_cells += _excel_range_area(selection)
            selections.append(selection)
        if requested_cells > policy.max_excel_cells:
            limitations = (
                WorkflowLimitation(
                    code="excel_detail_limit_reached",
                    message="Excel full detail exceeds the explicit output limit",
                ),
            )
            truncated = True
        else:
            ranges = tuple(selections)
            detail_complete = True
    details: list[WorkflowExcelRangeData] = []
    for selection in ranges:
        data = (
            read_sheet(
                source,
                selection.sheet_name,
                max_cells=policy.max_excel_cells,
            )
            if policy.excel_mode is ExcelWorkflowOutputMode.FULL_IF_WITHIN_LIMIT
            else read_range(
                source,
                selection.sheet_name,
                selection.cell_range,
                max_cells=policy.max_excel_cells,
            )
        )
        details.append(WorkflowExcelRangeData(selection=selection, data=data))
    inventory = (
        inspect_workbook_features(source)
        if policy.include_excel_feature_inventory
        else None
    )
    return (
        tuple(details),
        inventory,
        sum(len(item.data.cells) for item in details),
        limitations,
        truncated,
        detail_complete,
    )


def _native_result(
    source: Path,
    result: DocumentAnalysisResult,
    request: DocumentWorkflowRequest,
) -> tuple[
    WorkflowNativeResult,
    int,
    tuple[WorkflowLimitation, ...],
    bool,
]:
    analysis = result.analysis
    if type(analysis) is PdfDocumentAnalysis:
        return WorkflowPdfNativeResult(analysis=analysis), 0, (), False
    if type(analysis) is ImageDocumentAnalysis:
        return WorkflowImageNativeResult(analysis=analysis), 0, (), False
    if type(analysis) is DocxDocumentAnalysis:
        return WorkflowDocxNativeResult(analysis=analysis), 0, (), False
    excel = cast("ExcelDocumentAnalysis", analysis)
    details, inventory, count, limitations, truncated, complete = _excel_details(
        source,
        excel,
        request,
    )
    return (
        WorkflowExcelNativeResult(
            analysis=excel,
            ranges=details,
            feature_inventory=inventory,
            detail_complete=complete,
        ),
        count,
        limitations,
        truncated,
    )


def _native_local_ocr_quality_evidence(
    native: WorkflowNativeResult | None,
) -> tuple[
    LocalOcrQualityReport | None,
    LocalOcrPreprocessingReport | None,
    ProviderUsage | None,
]:
    """Read the final trusted report selected by existing Local OCR processing."""
    report: LocalOcrQualityReport | None = None
    preprocessing: LocalOcrPreprocessingReport | None = None
    usage: ProviderUsage | None = None
    if type(native) is WorkflowPdfNativeResult:
        result = native.analysis.processing_result
        if result is not None:
            report = result.metadata.local_ocr_quality_report
            preprocessing = result.metadata.local_ocr_preprocessing_report
            usage = result.metadata.provider_usage
    elif type(native) is WorkflowImageNativeResult:
        result = native.analysis.ocr_result
        if result is not None:
            report = result.metadata.local_ocr_quality_report
            preprocessing = result.metadata.local_ocr_preprocessing_report
            usage = result.metadata.provider_usage
    if report is not None:
        report = _validate_quality_report(report)
    return report, preprocessing, usage


def _selected_local_ocr_quality(
    native: WorkflowNativeResult | None,
    structured: StructuredExtractionResult | None,
) -> tuple[LocalOcrQualityReport | None, WorkflowStageKind | None]:
    """Select only the final report and the existing stage that produced it."""
    native_report, _, _ = _native_local_ocr_quality_evidence(native)
    if native_report is None:
        return None, None
    if structured is not None and structured.local_ocr_quality_report is not None:
        structured_report = _validate_quality_report(
            structured.local_ocr_quality_report
        )
        if structured_report.policy.structured is not None:
            return structured_report, WorkflowStageKind.STRUCTURED_EXTRACTION
    return native_report, WorkflowStageKind.OCR_OR_AZURE


def _workflow_local_ocr_quality(
    plan: DocumentWorkflowPlan,
    native: WorkflowNativeResult | None,
    structured: StructuredExtractionResult | None,
) -> tuple[LocalOcrQualityReport | None, WorkflowStageKind | None]:
    """Select quality evidence only for routes governed by the local gate."""
    if plan.route not in {
        WorkflowRoute.PDF_HYBRID_LOCAL,
        WorkflowRoute.IMAGE_LOCAL_OCR,
    }:
        return None, None
    return _selected_local_ocr_quality(native, structured)


def _execute_native(
    source: Path,
    plan: DocumentWorkflowPlan,
    request: DocumentWorkflowRequest,
    selection: _ProviderSelection,
    *,
    local_invocation_state: _LocalOcrInvocationState | None = None,
    expected_source_identity: WorkflowSourceIdentity | None = None,
) -> _NativeExecution:
    if plan.route is WorkflowRoute.PDF_AZURE_FIRST:
        return _execute_azure_first_pdf(source, plan, selection)
    if plan.route is WorkflowRoute.IMAGE_AZURE:
        return _execute_azure_image(source, plan, request, selection)
    if local_invocation_state is None and expected_source_identity is None:
        result = analyze_document(
            source,
            options=_analysis_options(request, plan),
            ocr_provider=selection.ocr,
        )
    else:
        result = _analyze_document(
            source,
            options=_analysis_options(request, plan),
            ocr_provider=selection.ocr,
            local_invocation_state=local_invocation_state,
            expected_identity=(
                None
                if expected_source_identity is None
                else (
                    expected_source_identity.sha256,
                    expected_source_identity.byte_size,
                )
            ),
        )
    _validate_local_execution_contract(result, plan=plan)
    document = _document_from_analysis(result)
    _validate_native_execution_source(result, plan=plan, document=document)
    native, cell_count, limitations, truncated = _native_result(
        source,
        result,
        request,
    )
    issues = _analysis_issues(result, plan=plan)
    return _NativeExecution(
        native=native,
        document=document,
        warnings=(),
        usages=_analysis_usages(result),
        attempts=result.cloud_execution_attempts,
        issues=issues,
        excel_cell_count=cell_count,
        limitations=limitations,
        truncated=truncated,
    )


def _execute_azure_image(
    source: Path,
    plan: DocumentWorkflowPlan,
    request: DocumentWorkflowRequest,
    selection: _ProviderSelection,
) -> _NativeExecution:
    """Submit one Plan-bound image through the Provider's anonymous snapshot."""
    from document_sdk.document.processing import (  # noqa: PLC0415
        _adapter_path,
        _detect_identity,
        _validate_provider_result,
    )

    provider = selection.ocr
    if type(provider) is not AzureDocumentIntelligenceProvider:
        raise DocumentWorkflowConfigurationError("Workflow Azure Provider is required")
    projection = _read_provider_context_projection_safely(
        provider,
        error=DocumentWorkflowConfigurationError(
            "Workflow Azure Provider identity is invalid"
        ),
    )
    try:
        detection = _detect_identity(
            source,
            expected_identity=(plan.source.sha256, plan.source.byte_size),
            max_bytes=request.policy.azure_execution_policy.max_input_bytes or None,
        )
        if (
            detection.envelope.document_type is not DocumentType.IMAGE
            or detection.envelope.document_format is not plan.document_format
        ):
            raise DocumentSourceChangedError(  # noqa: TRY301
                "Azure image content does not match the Workflow plan"
            )
        descriptor = _detected_source_descriptor(detection)
        if workflow_source_identity_from_descriptor(descriptor) != plan.source:
            raise DocumentSourceChangedError(  # noqa: TRY301
                "Azure image source does not match the Workflow plan"
            )
        with _adapter_path(
            source,
            plan.document_format,
            plan.source.sha256,
            plan.source.byte_size,
        ) as adapter:
            image = _inspect_workflow_azure_image(
                adapter,
                plan,
                request,
                descriptor=descriptor,
            )
            prepared = AzureInputPreflight(
                descriptor=image.file,
                page_count=image.frame_count,
                source_kind="image",
                image_format=_AZURE_IMAGE_FORMATS[plan.document_format],
            )
            processed = provider._analyze_cloud(  # noqa: SLF001 - trusted boundary.
                adapter,
                options=OcrAnalysisOptions(),
                fallback=False,
                preflight_validator=lambda value: _validate_azure_image_preflight(
                    value,
                    plan,
                    image,
                ),
                immutable_input_snapshot=True,
                prepared_input_preflight=prepared,
            )
    except DocumentSourceChangedError as exc:
        attempt = read_cloud_execution_attempt(exc)
        raise _WorkflowSourceChangedError(
            attempts=() if attempt is None else (attempt,)
        ) from None
    except DocumentSdkError as exc:
        attempt = read_cloud_execution_attempt(exc)
        if attempt is not None and (
            type(exc) is not ImageProcessingError
            or attempt.status is not CloudExecutionAttemptStatus.FAILED_BEFORE_SUBMIT
        ):
            raise
        raise _WorkflowAzureImagePreflightError(
            category=_failure_category(exc, provider=False)
        ) from None
    processed = _validate_provider_result(
        processed,
        identity=(
            projection.metadata.provider_name,
            projection.metadata.profile_id,
            projection.metadata.model_id,
        ),
        expected_local_quality_policy=None,
    )
    document = processed.data
    if document is None:
        raise DocumentSdkError("Azure image Provider returned no document")
    usages = (
        ()
        if processed.metadata.provider_usage is None
        else (processed.metadata.provider_usage,)
    )
    attempts = (
        ()
        if processed.metadata.cloud_execution_attempt is None
        else (processed.metadata.cloud_execution_attempt,)
    )
    if workflow_source_identity_from_descriptor(document.file) != plan.source:
        raise _WorkflowSourceChangedError(usages=usages, attempts=attempts)
    if tuple(page.page_number for page in document.pages) != tuple(
        range(1, image.frame_count + 1)
    ):
        raise DocumentSdkError("Azure image Provider frame identity is inconsistent")
    verified_image = image.model_copy(
        update={
            "frames": tuple(
                frame.model_copy(update={"decode_verified": True})
                for frame in image.frames
            )
        }
    )
    native = WorkflowImageNativeResult(
        analysis=ImageDocumentAnalysis(
            image=verified_image,
            ocr_result=processed,
        )
    )
    return _NativeExecution(
        native=native,
        document=document,
        warnings=(),
        usages=usages,
        attempts=attempts,
        issues=_azure_first_issues(processed),
        excel_cell_count=0,
        limitations=(),
        truncated=False,
    )


def _inspect_workflow_azure_image(
    source: Path,
    plan: DocumentWorkflowPlan,
    request: DocumentWorkflowRequest,
    *,
    descriptor: FileDescriptor,
) -> ImageInspection:
    """Inspect bounded image metadata before the immutable decode boundary."""
    from document_sdk.image import inspect_image  # noqa: PLC0415

    max_frames = effective_azure_page_limit(
        request.policy.azure_execution_policy.max_pages_or_frames,
        public_model_max_pages_or_frames=(
            AZURE_DOCUMENT_INTELLIGENCE_MAX_PAGES_OR_FRAMES
        ),
    )
    inspected = inspect_image(
        source,
        limits=_azure_image_limits(max_frames),
        verify_decode=False,
    )
    image = inspected.model_copy(update={"file": descriptor})
    if workflow_source_identity_from_descriptor(image.file) != plan.source:
        raise DocumentSourceChangedError(
            "Azure image source does not match the Workflow plan"
        )
    if _AZURE_IMAGE_FORMATS.get(plan.document_format) != image.format:
        raise DocumentSourceChangedError(
            "Azure image format does not match the Workflow plan"
        )
    return image


def _validate_azure_image_preflight(
    preflight: AzureInputPreflight,
    plan: DocumentWorkflowPlan,
    image: ImageInspection,
) -> None:
    """Bind the exact Azure image snapshot to Workflow and frame evidence."""
    if workflow_source_identity_from_descriptor(preflight.descriptor) != plan.source:
        msg = "Azure image source does not match the Workflow plan"
        raise DocumentSourceChangedError(msg)
    if (
        preflight.source_kind != "image"
        or preflight.descriptor != image.file
        or preflight.page_count != image.frame_count
        or preflight.image_format != image.format
    ):
        raise DocumentSdkError("Azure image Provider preflight is inconsistent")


def _azure_first_issues(result: object) -> tuple[WorkflowStageIssue, ...]:
    from document_sdk.core import ProcessingResult  # noqa: PLC0415

    processed = cast("ProcessingResult[Document]", result)
    issues: list[WorkflowStageIssue] = []
    for supplied in processed.errors:
        error = _revalidate_model_instance_json(
            supplied,
            ProcessingError,
            "Azure-first Provider issue is invalid",
        )
        issues.append(
            _issue(
                WorkflowStageKind.OCR_OR_AZURE,
                code=_stable_lower_level_issue_code("azure_issue", error.code),
                category=WorkflowIssueCategory.PROVIDER,
                message="Azure document analysis completed with a non-fatal issue",
                retryable=error.retryable,
                provider_category=(
                    WorkflowProviderCategory.AZURE_DOCUMENT_INTELLIGENCE
                ),
                source=error.source,
            )
        )
    for supplied_warning in processed.warnings:
        warning = _revalidate_model_instance_json(
            supplied_warning,
            ProcessingWarning,
            "Azure-first Provider warning is invalid",
        )
        issues.append(
            _issue(
                WorkflowStageKind.OCR_OR_AZURE,
                code=_stable_lower_level_issue_code("azure_warning", warning.code),
                category=WorkflowIssueCategory.PROVIDER,
                message="Azure document analysis completed with a non-fatal warning",
                retryable=False,
                count=warning.count,
                provider_category=(
                    WorkflowProviderCategory.AZURE_DOCUMENT_INTELLIGENCE
                ),
                source=warning.source,
            )
        )
    return tuple(issues)


def _execute_azure_first_pdf(
    source: Path,
    plan: DocumentWorkflowPlan,
    selection: _ProviderSelection,
) -> _NativeExecution:
    """Submit one original PDF to Azure and retain its normalized Document."""
    from document_sdk.document.processing import (  # noqa: PLC0415
        _validate_provider_result,
    )

    provider = selection.ocr
    if type(provider) is not AzureDocumentIntelligenceProvider:
        raise DocumentWorkflowConfigurationError("Workflow Azure Provider is required")
    projection = _read_provider_context_projection_safely(
        provider,
        error=DocumentWorkflowConfigurationError(
            "Workflow Azure Provider identity is invalid"
        ),
    )
    try:
        processed = provider._analyze_cloud(  # noqa: SLF001 - trusted boundary.
            source,
            options=OcrAnalysisOptions(),
            fallback=False,
            preflight_validator=lambda value: _validate_azure_first_preflight(
                value,
                plan,
            ),
            immutable_input_snapshot=True,
        )
    except DocumentSourceChangedError as exc:
        attempt = read_cloud_execution_attempt(exc)
        raise _WorkflowSourceChangedError(
            attempts=() if attempt is None else (attempt,)
        ) from None
    processed = _validate_provider_result(
        processed,
        identity=(
            projection.metadata.provider_name,
            projection.metadata.profile_id,
            projection.metadata.model_id,
        ),
        expected_local_quality_policy=None,
    )
    document = processed.data
    if document is None:
        raise DocumentSdkError("Azure-first Provider returned no document")
    usages = (
        ()
        if processed.metadata.provider_usage is None
        else (processed.metadata.provider_usage,)
    )
    attempts = (
        ()
        if processed.metadata.cloud_execution_attempt is None
        else (processed.metadata.cloud_execution_attempt,)
    )
    if workflow_source_identity_from_descriptor(document.file) != plan.source:
        raise _WorkflowSourceChangedError(usages=usages, attempts=attempts)
    preflight = plan.pdf_preflight
    if preflight is None or tuple(page.page_number for page in document.pages) != tuple(
        range(1, preflight.page_count + 1)
    ):
        raise DocumentSdkError("Azure-first Provider page identity is inconsistent")
    return _NativeExecution(
        native=None,
        document=document,
        warnings=(),
        usages=usages,
        attempts=attempts,
        issues=_azure_first_issues(processed),
        excel_cell_count=0,
        limitations=(),
        truncated=False,
    )


def _validate_azure_first_preflight(
    preflight: AzureInputPreflight,
    plan: DocumentWorkflowPlan,
) -> None:
    """Bind the Provider's exact stream preflight to the Workflow plan."""
    if workflow_source_identity_from_descriptor(preflight.descriptor) != plan.source:
        msg = "Azure-first source does not match the Workflow plan"
        raise DocumentSourceChangedError(msg)
    planned = plan.pdf_preflight
    if (
        planned is None
        or preflight.source_kind != "pdf"
        or preflight.page_count != planned.page_count
    ):
        raise DocumentSdkError("Azure-first Provider preflight is inconsistent")


@dataclass(frozen=True, slots=True)
class _NativeResume:
    native: WorkflowNativeResult | None
    document: Document | None
    stages: tuple[WorkflowStageResult, ...]


@dataclass(frozen=True, slots=True)
class _NativeRetryHistory:
    usages: tuple[ProviderUsage, ...]
    attempts: tuple[CloudExecutionAttemptEvidence, ...]


@dataclass(frozen=True, slots=True)
class _NativeResumeBlocked:
    prior: WorkflowStageResult
    code: str
    message: str
    retryable: bool


@dataclass(frozen=True, slots=True)
class _StructuredExtractionExecution:
    result: StructuredExtractionResult


def _validate_artifact_store_shape(
    store: WorkflowArtifactStore | None,
) -> WorkflowArtifactStore | None:
    if store is None:
        return None
    for name in ("load", "store"):
        try:
            method = inspect.getattr_static(store, name)
        except (KeyboardInterrupt, SystemExit, GeneratorExit):
            raise
        except Exception as exc:
            _raise_redacted_translation(
                exc,
                DocumentWorkflowArtifactError("Workflow Artifact Store is invalid"),
            )
        if not callable(method):
            raise DocumentWorkflowArtifactError("Workflow Artifact Store is invalid")
    return store


def _validate_artifact_store(
    store: WorkflowArtifactStore | None,
    *,
    required: bool,
) -> WorkflowArtifactStore | None:
    validated = _validate_artifact_store_shape(store)
    if validated is None and required:
        raise DocumentWorkflowConfigurationError("Workflow Artifact Store is required")
    return validated


def _validated_resume_manifest_shape(
    manifest: DocumentWorkflowManifest | None,
) -> DocumentWorkflowManifest | None:
    if manifest is None:
        return None
    if type(manifest) is not DocumentWorkflowManifest:
        raise DocumentWorkflowResumeError("Workflow Resume Manifest is invalid")
    try:
        validated = _revalidate_model_instance_json(
            manifest,
            DocumentWorkflowManifest,
            "Workflow Resume Manifest is invalid",
        )
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            DocumentWorkflowResumeError("Workflow Resume Manifest is invalid"),
        )
    return validated


def _validated_resume_manifest(
    manifest: DocumentWorkflowManifest | None,
    *,
    plan: DocumentWorkflowPlan,
    request: DocumentWorkflowRequest,
) -> DocumentWorkflowManifest | None:
    validated = _validated_resume_manifest_shape(manifest)
    if validated is None:
        return None
    if (
        validated.sdk_version != __version__
        or validated.contract_version != plan.contract_version
        or validated.source != plan.source
        or validated.tenant_scope_identity != request.tenant_scope_identity
        or validated.document_type is not plan.document_type
        or validated.document_format is not plan.document_format
    ):
        raise DocumentWorkflowResumeError("Workflow Resume identity is incompatible")
    return validated


def _prior_stage(
    manifest: DocumentWorkflowManifest,
    kind: WorkflowStageKind,
) -> WorkflowStageResult:
    return next(stage for stage in manifest.stages if stage.kind is kind)


def _provider_identity_for_stage(
    plan: DocumentWorkflowPlan,
    kind: WorkflowStageKind,
) -> tuple[WorkflowProviderCategory | None, str | None]:
    stage = _plan_stage(plan, kind)
    category = stage.provider_category
    if category is None:
        return None, None
    identity = next(
        (
            item.fingerprint
            for item in plan.provider_identities
            if item.category is category
        ),
        None,
    )
    if identity is None:
        raise DocumentWorkflowConfigurationError(
            "Workflow Provider stage identity is incomplete"
        )
    return category, identity


def _protected_stage_evidence(stage: WorkflowStageResult) -> bool:
    return _protected_evidence(
        stage.retained_cloud_attempts + stage.current_cloud_attempts,
        stage.retained_provider_usage + stage.current_provider_usage,
    )


def _cloud_retry_budget_exhausted(
    policy: CloudExecutionPolicy,
    attempts: tuple[CloudExecutionAttemptEvidence, ...],
) -> bool:
    submitted = sum(item.submitted_operation_count for item in attempts)
    paid = sum(item.paid_or_possibly_paid_operation_count for item in attempts)
    return (
        submitted + 1 > policy.max_submitted_operations
        or paid + 1 > policy.max_paid_or_possibly_paid_operations
    )


def _native_retry_block(
    prior: WorkflowStageResult,
    *,
    request: DocumentWorkflowRequest,
) -> _NativeResumeBlocked | None:
    attempts = prior.retained_cloud_attempts + prior.current_cloud_attempts
    if any(
        issue.code == "local_ocr_provider_contract_failed" for issue in prior.issues
    ):
        return _NativeResumeBlocked(
            prior=prior,
            code="local_ocr_provider_contract_failed",
            message="Workflow Local OCR Provider violated its local-only contract",
            retryable=False,
        )
    if not _protected_stage_evidence(prior):
        return None
    if (
        prior.provider_category
        is not WorkflowProviderCategory.AZURE_DOCUMENT_INTELLIGENCE
    ):
        raise DocumentWorkflowResumeError(
            "Workflow protected native Provider evidence is inconsistent"
        )
    policy = request.policy.azure_execution_policy
    if not policy.allow_retry_possibly_paid:
        return _NativeResumeBlocked(
            prior=prior,
            code="native_retry_requires_authorization",
            message=(
                "A protected native Provider operation requires retry authorization"
            ),
            retryable=True,
        )
    if _cloud_retry_budget_exhausted(policy, attempts):
        return _NativeResumeBlocked(
            prior=prior,
            code="native_retry_budget_exhausted",
            message="The cumulative native Provider retry budget is exhausted",
            retryable=False,
        )
    return None


def _reused_stage(
    plan: DocumentWorkflowPlan,
    prior: WorkflowStageResult,
) -> WorkflowStageResult:
    current = _plan_stage(plan, prior.kind)
    if prior.stage_identity != current.stage_identity or prior.output_identity is None:
        raise DocumentWorkflowResumeError("Workflow Resume stage is incompatible")
    category, identity = _provider_identity_for_stage(plan, prior.kind)
    if prior.provider_category is not category or prior.provider_identity != identity:
        raise DocumentWorkflowResumeError(
            "Workflow Resume Provider identity is incompatible"
        )
    status: _FinalWorkflowStageStatus = (
        WorkflowStageStatus.REVIEW_REQUIRED
        if _is_local_ocr_quality_review_stage(prior)
        else WorkflowStageStatus.REUSED
    )
    return _stage_result(
        plan,
        prior.kind,
        status=status,
        input_identity=prior.input_identity,
        output_identity=prior.output_identity,
        provider_category=category,
        provider_identity=identity,
        retained_usage=(prior.retained_provider_usage + prior.current_provider_usage),
        retained_attempts=(
            prior.retained_cloud_attempts + prior.current_cloud_attempts
        ),
        references=prior.artifact_references,
        issues=prior.issues,
        reuse_eligible=True,
    )


def _single_artifact_reference(
    stage: WorkflowStageResult,
    kind: WorkflowArtifactKind,
) -> WorkflowArtifactReference | None:
    references = tuple(
        reference for reference in stage.artifact_references if reference.kind is kind
    )
    if len(references) > 1:
        raise DocumentWorkflowResumeError("Workflow Resume artifact is ambiguous")
    return None if not references else references[0]


def _load_resume_artifact(
    store: WorkflowArtifactStore | None,
    reference: WorkflowArtifactReference | None,
    *,
    kind: WorkflowArtifactKind,
    plan: DocumentWorkflowPlan,
    request: DocumentWorkflowRequest,
    stage_kind: WorkflowStageKind,
    expected_output_identity: str,
    route_identity: str,
) -> object | None:
    if reference is None:
        return None
    if store is None:
        raise DocumentWorkflowResumeError("Workflow Resume Artifact Store is required")
    return load_workflow_artifact(
        store,
        reference,
        expected_kind=kind,
        source=plan.source,
        tenant_scope_identity=request.tenant_scope_identity,
        stage_kind=stage_kind,
        stage_identity=_plan_stage(plan, stage_kind).stage_identity,
        expected_output_identity=expected_output_identity,
        route_identity=route_identity,
        max_bytes=request.output_policy.max_artifact_bytes,
    )


def _route_produces_document(route: WorkflowRoute) -> bool:
    return route not in {
        WorkflowRoute.EXCEL_LOCAL,
        WorkflowRoute.IMAGE_INSPECTION,
    }


def _resume_native_execution(  # noqa: PLR0911
    manifest: DocumentWorkflowManifest | None,
    *,
    plan: DocumentWorkflowPlan,
    request: DocumentWorkflowRequest,
    selection: _ProviderSelection,
    store: WorkflowArtifactStore | None,
) -> _NativeResume | _NativeRetryHistory | _NativeResumeBlocked | None:
    if manifest is None:
        return None
    kinds = (
        WorkflowStageKind.NATIVE_ANALYSIS,
        WorkflowStageKind.OCR_OR_AZURE,
        WorkflowStageKind.NORMALIZE,
    )
    prior = {kind: _prior_stage(manifest, kind) for kind in kinds}
    ocr_stage = prior[WorkflowStageKind.OCR_OR_AZURE]
    quality_review = _has_completed_local_ocr_quality_review(manifest)
    active = tuple(
        kind
        for kind in kinds
        if _plan_stage(plan, kind).status is WorkflowStageStatus.PLANNED
    )
    if any(
        prior[kind].stage_identity != _plan_stage(plan, kind).stage_identity
        for kind in active
    ):
        if quality_review:
            raise DocumentWorkflowResumeError(
                "Workflow quality Review artifact is unavailable"
            )
        if any(_protected_stage_evidence(prior[kind]) for kind in active):
            raise DocumentWorkflowResumeError(
                "Workflow protected native stage identity is incompatible"
            )
        if not request.policy.allow_local_recompute:
            raise DocumentWorkflowResumeError(
                "Workflow local stage identity is incompatible"
            )
        return None
    if (
        _plan_stage(plan, WorkflowStageKind.OCR_OR_AZURE).status
        is WorkflowStageStatus.PLANNED
    ):
        category, identity = _provider_identity_for_stage(
            plan,
            WorkflowStageKind.OCR_OR_AZURE,
        )
        if (
            ocr_stage.status is not WorkflowStageStatus.SKIPPED
            or ocr_stage.current_provider_usage
            or ocr_stage.retained_provider_usage
            or ocr_stage.current_cloud_attempts
            or ocr_stage.retained_cloud_attempts
        ) and (
            ocr_stage.provider_category is not category
            or ocr_stage.provider_identity != identity
        ):
            raise DocumentWorkflowResumeError(
                "Workflow Resume native Provider identity is incompatible"
            )
    retained = _NativeRetryHistory(
        usages=ocr_stage.retained_provider_usage + ocr_stage.current_provider_usage,
        attempts=ocr_stage.retained_cloud_attempts + ocr_stage.current_cloud_attempts,
    )
    all_completed = all(
        prior[kind].status
        in {WorkflowStageStatus.SUCCEEDED, WorkflowStageStatus.REUSED}
        or _is_local_ocr_quality_review_stage(prior[kind])
        for kind in active
    )
    if not all_completed:
        if quality_review:
            raise DocumentWorkflowResumeError(
                "Workflow quality Review artifact is unavailable"
            )
        blocked = _native_retry_block(ocr_stage, request=request)
        if blocked is not None:
            return blocked
        if (
            ocr_stage.provider_category
            is WorkflowProviderCategory.AZURE_DOCUMENT_INTELLIGENCE
            and retained.attempts
            and _cloud_retry_budget_exhausted(
                request.policy.azure_execution_policy,
                retained.attempts,
            )
        ):
            return _NativeResumeBlocked(
                prior=ocr_stage,
                code="native_retry_budget_exhausted",
                message="The cumulative native Provider retry budget is exhausted",
                retryable=False,
            )
        if (
            ocr_stage.provider_category
            is not WorkflowProviderCategory.AZURE_DOCUMENT_INTELLIGENCE
            and not request.policy.allow_local_recompute
        ):
            raise DocumentWorkflowResumeError(
                "Workflow local stage recompute is disabled"
            )
        return retained
    native_stage = prior[WorkflowStageKind.NATIVE_ANALYSIS]
    normalize_stage = prior[WorkflowStageKind.NORMALIZE]
    native_reference = _single_artifact_reference(
        native_stage,
        WorkflowArtifactKind.NATIVE_RESULT,
    )
    document_reference = _single_artifact_reference(
        normalize_stage,
        WorkflowArtifactKind.DOCUMENT,
    )
    native_required = plan.route is not WorkflowRoute.PDF_AZURE_FIRST
    if (native_required and native_reference is None) or (
        _route_produces_document(plan.route) and document_reference is None
    ):
        if quality_review:
            raise DocumentWorkflowResumeError(
                "Workflow quality Review artifact is unavailable"
            )
        blocked = _native_retry_block(ocr_stage, request=request)
        if blocked is not None:
            return blocked
        if (
            ocr_stage.provider_category
            is WorkflowProviderCategory.AZURE_DOCUMENT_INTELLIGENCE
            and retained.attempts
            and _cloud_retry_budget_exhausted(
                request.policy.azure_execution_policy,
                retained.attempts,
            )
        ):
            return _NativeResumeBlocked(
                prior=ocr_stage,
                code="native_retry_budget_exhausted",
                message="The cumulative native Provider retry budget is exhausted",
                retryable=False,
            )
        if (
            ocr_stage.provider_category
            is not WorkflowProviderCategory.AZURE_DOCUMENT_INTELLIGENCE
            and not request.policy.allow_local_recompute
        ):
            raise DocumentWorkflowResumeError(
                "Workflow local stage artifact is unavailable"
            )
        return retained
    route_identity = _analysis_route_identity(plan, selection)
    native = (
        None
        if native_reference is None
        else _load_resume_artifact(
            store,
            native_reference,
            kind=WorkflowArtifactKind.NATIVE_RESULT,
            plan=plan,
            request=request,
            stage_kind=WorkflowStageKind.NATIVE_ANALYSIS,
            expected_output_identity=cast("str", native_stage.output_identity),
            route_identity=route_identity,
        )
    )
    document = _load_resume_artifact(
        store,
        document_reference,
        kind=WorkflowArtifactKind.DOCUMENT,
        plan=plan,
        request=request,
        stage_kind=WorkflowStageKind.NORMALIZE,
        expected_output_identity=cast("str", normalize_stage.output_identity),
        route_identity=route_identity,
    )
    if (native_required and native is None) or (
        _route_produces_document(plan.route) and type(document) is not Document
    ):
        raise DocumentWorkflowResumeError("Workflow Resume artifacts are incomplete")
    stages = tuple(
        _reused_stage(plan, prior[kind])
        if kind in active
        else _skipped_result(plan, kind)
        for kind in kinds
    )
    return _NativeResume(
        native=cast("WorkflowNativeResult | None", native),
        document=cast("Document | None", document),
        stages=stages,
    )


def _persist_artifact(
    store: WorkflowArtifactStore | None,
    *,
    kind: WorkflowArtifactKind,
    value: object,
    plan: DocumentWorkflowPlan,
    request: DocumentWorkflowRequest,
    stage_kind: WorkflowStageKind,
    route_identity: str,
) -> tuple[WorkflowArtifactReference, ...]:
    if not request.output_policy.persist_intermediate_artifacts:
        return ()
    if store is None:
        raise DocumentWorkflowConfigurationError("Workflow Artifact Store is required")
    return (
        store_workflow_artifact(
            store,
            kind=kind,
            value=value,
            source=plan.source,
            tenant_scope_identity=request.tenant_scope_identity,
            stage_kind=stage_kind,
            stage_identity=_plan_stage(plan, stage_kind).stage_identity,
            route_identity=route_identity,
            max_bytes=request.output_policy.max_artifact_bytes,
        ),
    )


def _structured_extraction_stage_identity(
    plan: DocumentWorkflowPlan,
    request: DocumentWorkflowRequest,
    document: Document | None,
) -> tuple[str, str]:
    normalize_identity = _plan_stage(
        plan,
        WorkflowStageKind.NORMALIZE,
    ).stage_identity
    if request.extraction_mode is WorkflowExtractionMode.NONE:
        identity = workflow_fingerprint(
            "structured-extraction-stage",
            {
                "mode": "none",
                "normalize_stage_identity": normalize_identity,
                "sdk_version": __version__,
            },
        )
        return identity, identity
    if document is None or request.extraction_schema is None:
        raise DocumentWorkflowConfigurationError(
            "Workflow extraction requires a normalized Document"
        )
    document_identity = workflow_fingerprint(
        "structured-extraction-document",
        document.model_dump(mode="json"),
    )
    identity = workflow_fingerprint(
        "deterministic-structured-extraction-stage",
        {
            "document_fingerprint": document_identity,
            "options": (
                None
                if request.structured_extraction_options is None
                else request.structured_extraction_options.model_dump(mode="json")
            ),
            "schema": request.extraction_schema.model_dump(mode="json"),
            "sdk_version": __version__,
        },
    )
    return identity, workflow_fingerprint(
        "deterministic-extraction-route",
        {"sdk_version": __version__},
    )


def _execute_structured_extraction(
    document: Document,
    request: DocumentWorkflowRequest,
    *,
    intrinsic_quality_report: LocalOcrQualityReport | None = None,
    preprocessing_report: LocalOcrPreprocessingReport | None = None,
    intrinsic_provider_usage: ProviderUsage | None = None,
) -> _StructuredExtractionExecution:
    schema = request.extraction_schema
    if schema is None:
        raise DocumentWorkflowConfigurationError(
            "Workflow extraction schema is required"
        )
    result = (
        extract_structured_fields(
            document,
            schema,
            options=request.structured_extraction_options,
        )
        if intrinsic_quality_report is None
        else _extract_structured_fields_with_quality(
            document,
            schema,
            options=request.structured_extraction_options,
            intrinsic_quality_report=intrinsic_quality_report,
            provider_usage=intrinsic_provider_usage,
            preprocessing_report=preprocessing_report,
        )
    )
    if result.document != document:
        raise _WorkflowStructuredDocumentMismatchError
    return _StructuredExtractionExecution(result=result)


def _issue(
    kind: WorkflowStageKind,
    *,
    code: str,
    category: WorkflowIssueCategory,
    message: str,
    retryable: bool,
    count: int | None = None,
    provider_category: WorkflowProviderCategory | None = None,
    source: SourceReference | None = None,
) -> WorkflowStageIssue:
    return WorkflowStageIssue(
        code=code,
        category=category,
        message=message,
        retryable=retryable,
        count=count,
        stage_kind=kind,
        provider_category=provider_category,
        source=source,
    )


def _is_local_ocr_quality_review_stage(stage: WorkflowStageResult) -> bool:
    return (
        stage.status is WorkflowStageStatus.REVIEW_REQUIRED
        and sum(issue.code == _LOCAL_OCR_QUALITY_REVIEW_CODE for issue in stage.issues)
        == 1
    )


def _has_completed_local_ocr_quality_review(
    manifest: DocumentWorkflowManifest,
) -> bool:
    """Read only strictly revalidated final Manifest quality evidence."""
    summary = manifest.local_ocr_quality_summary
    owner = manifest.local_ocr_quality_owner_stage
    return (
        summary is not None
        and summary.decision is LocalOcrQualityDecision.FAIL
        and owner is not None
        and _is_local_ocr_quality_review_stage(_prior_stage(manifest, owner))
    )


def _with_local_ocr_quality_review(
    plan: DocumentWorkflowPlan,
    stage: WorkflowStageResult,
) -> WorkflowStageResult:
    """Project one final quality failure without discarding completed output."""
    issue = _issue(
        stage.kind,
        code=_LOCAL_OCR_QUALITY_REVIEW_CODE,
        category=WorkflowIssueCategory.VALIDATION,
        message=_LOCAL_OCR_QUALITY_REVIEW_MESSAGE,
        retryable=False,
        provider_category=stage.provider_category,
    )
    return _stage_result(
        plan,
        stage.kind,
        status=WorkflowStageStatus.REVIEW_REQUIRED,
        input_identity=stage.input_identity,
        output_identity=stage.output_identity,
        provider_category=stage.provider_category,
        provider_identity=stage.provider_identity,
        current_usage=stage.current_provider_usage,
        retained_usage=stage.retained_provider_usage,
        current_attempts=stage.current_cloud_attempts,
        retained_attempts=stage.retained_cloud_attempts,
        references=stage.artifact_references,
        issues=(*stage.issues, issue),
        reuse_eligible=stage.reuse_eligible,
    )


def _apply_local_ocr_quality_review(
    *,
    plan: DocumentWorkflowPlan,
    stages: tuple[WorkflowStageResult, ...],
    native: WorkflowNativeResult | None,
    structured: StructuredExtractionResult | None,
) -> tuple[WorkflowStageResult, ...]:
    """Apply the final authoritative quality decision to its existing stage."""
    quality_report, quality_owner = _workflow_local_ocr_quality(
        plan,
        native,
        structured,
    )
    if (
        quality_report is None
        or quality_report.summary.decision is not LocalOcrQualityDecision.FAIL
    ):
        return stages
    if quality_owner is None:
        raise DocumentWorkflowConfigurationError(
            "Workflow Local OCR quality owner is unavailable"
        )
    found_owner = False
    projected: list[WorkflowStageResult] = []
    for stage in stages:
        projected_stage = stage
        if stage.kind is quality_owner:
            found_owner = True
            if not _is_local_ocr_quality_review_stage(stage):
                projected_stage = _with_local_ocr_quality_review(plan, stage)
        projected.append(projected_stage)
    if not found_owner:
        raise DocumentWorkflowConfigurationError(
            "Workflow Local OCR quality owner is unavailable"
        )
    return tuple(projected)


def _stable_lower_level_issue_code(domain: str, value: str) -> str:
    digest = hashlib.sha256(
        f"document-sdk:workflow:{domain}:v1\0{value}".encode()
    ).hexdigest()[:24]
    return f"{domain}_{digest}"


def _analysis_issue_stage(result: DocumentAnalysisResult) -> WorkflowStageKind:
    analysis = result.analysis
    if type(analysis) is PdfDocumentAnalysis:
        return (
            WorkflowStageKind.OCR_OR_AZURE
            if analysis.processing_result is not None
            else WorkflowStageKind.NATIVE_ANALYSIS
        )
    if type(analysis) is ImageDocumentAnalysis:
        return (
            WorkflowStageKind.OCR_OR_AZURE
            if analysis.ocr_result is not None
            else WorkflowStageKind.NATIVE_ANALYSIS
        )
    return WorkflowStageKind.NATIVE_ANALYSIS


def _analysis_issues(
    result: DocumentAnalysisResult,
    *,
    plan: DocumentWorkflowPlan,
) -> tuple[WorkflowStageIssue, ...]:
    kind = _analysis_issue_stage(result)
    provider_category = (
        _plan_stage(plan, kind).provider_category
        if kind is WorkflowStageKind.OCR_OR_AZURE
        else None
    )
    normalized: list[WorkflowStageIssue] = []
    for supplied in result.issues:
        if type(supplied) is not ProcessingError:
            raise DocumentWorkflowConfigurationError(
                "Document analysis issue is invalid"
            )
        try:
            issue = _revalidate_model_instance_json(
                supplied,
                ProcessingError,
                "Document analysis issue is invalid",
            )
        except Exception:
            raise DocumentWorkflowConfigurationError(
                "Document analysis issue is invalid"
            ) from None
        normalized.append(
            _issue(
                kind,
                code=_stable_lower_level_issue_code(
                    "document_analysis_issue", issue.code
                ),
                category=(
                    WorkflowIssueCategory.PROVIDER
                    if provider_category is not None
                    else WorkflowIssueCategory.PROCESSING
                ),
                message="Document analysis completed with a non-fatal issue",
                retryable=issue.retryable,
                provider_category=provider_category,
                source=issue.source,
            )
        )
    for supplied_warning in result.warnings:
        if type(supplied_warning) is not ProcessingWarning:
            raise DocumentWorkflowConfigurationError(
                "Document analysis warning is invalid"
            )
        try:
            warning = _revalidate_model_instance_json(
                supplied_warning,
                ProcessingWarning,
                "Document analysis warning is invalid",
            )
        except Exception:
            raise DocumentWorkflowConfigurationError(
                "Document analysis warning is invalid"
            ) from None
        normalized.append(
            _issue(
                kind,
                code=_stable_lower_level_issue_code(
                    "document_analysis_warning", warning.code
                ),
                category=(
                    WorkflowIssueCategory.PROVIDER
                    if provider_category is not None
                    else WorkflowIssueCategory.PROCESSING
                ),
                message="Document analysis completed with a non-fatal warning",
                retryable=False,
                count=warning.count,
                provider_category=provider_category,
                source=warning.source,
            )
        )
    return tuple(normalized)


def _detection_issues(
    warnings: tuple[ProcessingWarning, ...],
) -> tuple[WorkflowStageIssue, ...]:
    """Project trusted content-detection warnings into durable stage evidence."""
    normalized: list[WorkflowStageIssue] = []
    for supplied in warnings:
        if type(supplied) is not ProcessingWarning:
            raise DocumentWorkflowConfigurationError(
                "Document detection warning is invalid"
            )
        try:
            warning = _revalidate_model_instance_json(
                supplied,
                ProcessingWarning,
                "Document detection warning is invalid",
            )
        except Exception:
            raise DocumentWorkflowConfigurationError(
                "Document detection warning is invalid"
            ) from None
        extension_mismatch = (
            warning.code == "document.extension_mismatch"
            and warning.category == "extension_mismatch"
        )
        normalized.append(
            _issue(
                WorkflowStageKind.DETECT,
                code=(
                    "document_extension_mismatch"
                    if extension_mismatch
                    else _stable_lower_level_issue_code(
                        "document_detection_warning", warning.code
                    )
                ),
                category=WorkflowIssueCategory.SOURCE,
                message=(
                    "Workflow source extension does not match detected content"
                    if extension_mismatch
                    else "Document detection completed with a non-fatal warning"
                ),
                retryable=False,
                count=warning.count,
                source=warning.source,
            )
        )
    return tuple(normalized)


def _structured_result_issues(
    result: StructuredExtractionResult,
) -> tuple[WorkflowStageIssue, ...]:
    issues = [
        _issue(
            WorkflowStageKind.STRUCTURED_EXTRACTION,
            code=_stable_lower_level_issue_code(
                "structured_extraction_issue", item.code
            ),
            category=WorkflowIssueCategory.VALIDATION,
            message="Structured extraction completed with a non-fatal issue",
            retryable=False,
        )
        for item in result.issues
    ]
    issues.extend(
        _issue(
            WorkflowStageKind.STRUCTURED_EXTRACTION,
            code=_stable_lower_level_issue_code(
                "structured_extraction_warning", warning.code
            ),
            category=WorkflowIssueCategory.VALIDATION,
            message="Structured extraction completed with a non-fatal warning",
            retryable=False,
            count=warning.count,
            source=warning.source,
        )
        for warning in result.warnings
    )
    return tuple(issues)


def _failure_evidence(
    error: BaseException,
) -> tuple[
    tuple[ProviderUsage, ...],
    tuple[CloudExecutionAttemptEvidence, ...],
]:
    if type(error) is _WorkflowSourceChangedError:
        return error.usages, error.attempts
    if type(error) is _WorkflowLocalProviderContractError:
        return error.usages, error.attempts
    if type(error) is _WorkflowStructuredDocumentMismatchError:
        return error.usages, error.attempts
    completed = read_completed_cloud_result(error)
    if completed is not None:
        usage, attempt = completed
        return (usage,), (attempt,)
    standalone_attempt = read_cloud_execution_attempt(error)
    local_usage = _attempt_usage(error)
    return (
        () if local_usage is None else (local_usage,),
        () if standalone_attempt is None else (standalone_attempt,),
    )


def _failure_category(error: BaseException, *, provider: bool) -> WorkflowIssueCategory:
    if type(error) is _WorkflowAzureImagePreflightError:
        return error.category
    if isinstance(error, DocumentWorkflowArtifactError):
        return WorkflowIssueCategory.ARTIFACT
    if isinstance(error, DocumentWorkflowResumeError):
        return WorkflowIssueCategory.RESUME
    name = type(error).__name__.casefold()
    if "limit" in name:
        return WorkflowIssueCategory.LIMIT
    if "unsupported" in name:
        return WorkflowIssueCategory.UNSUPPORTED
    return (
        WorkflowIssueCategory.PROVIDER if provider else WorkflowIssueCategory.PROCESSING
    )


def _protected_evidence(
    attempts: tuple[CloudExecutionAttemptEvidence, ...],
    usages: tuple[ProviderUsage, ...] = (),
) -> bool:
    return any(
        item.status in _PROTECTED_CLOUD_STATUSES for item in attempts
    ) or _protected_usage(usages)


def _protected_usage(usages: tuple[ProviderUsage, ...]) -> bool:
    return any(
        usage.cloud_submitted_operation_count
        or usage.cloud_paid_or_possibly_paid_operation_count
        or usage.paid_operation_count
        or usage.azure_operation_count
        for usage in usages
    )


def _detect_inspect_results(
    plan: DocumentWorkflowPlan,
    *,
    detection_issues: tuple[WorkflowStageIssue, ...] = (),
) -> tuple[WorkflowStageResult, WorkflowStageResult]:
    return (
        _stage_result(
            plan,
            WorkflowStageKind.DETECT,
            status=WorkflowStageStatus.SUCCEEDED,
            output_identity=workflow_fingerprint(
                "source-output",
                plan.source.model_dump(mode="json"),
            ),
            issues=detection_issues,
        ),
        _stage_result(
            plan,
            WorkflowStageKind.INSPECT,
            status=WorkflowStageStatus.SUCCEEDED,
            output_identity=workflow_fingerprint(
                "inspection-output",
                {
                    "document_format": plan.document_format.value,
                    "document_type": plan.document_type.value,
                    "source": plan.source.model_dump(mode="json"),
                },
            ),
        ),
    )


def _build_result(
    *,
    status: DocumentWorkflowStatus,
    plan: DocumentWorkflowPlan,
    request: DocumentWorkflowRequest,
    stages: tuple[WorkflowStageResult, ...],
    native: WorkflowNativeResult | None,
    document: Document | None,
    structured: StructuredExtractionResult | None,
    warnings: tuple[ProcessingWarning, ...],
    limitations: tuple[WorkflowLimitation, ...],
    excel_cell_count: int,
    truncated: bool,
) -> DocumentWorkflowResult:
    limitations = tuple(
        sorted({item.code: item for item in limitations}.values(), key=lambda x: x.code)
    )
    usage = workflow_usage_from_stages(stages)
    references = tuple(
        reference for stage in stages for reference in stage.artifact_references
    )
    issues = tuple(issue for stage in stages for issue in stage.issues)
    limitation_codes = tuple(item.code for item in limitations)
    quality_report, quality_owner = _workflow_local_ocr_quality(
        plan,
        native,
        structured,
    )
    quality_summary = None if quality_report is None else quality_report.summary
    quality_binding = None
    if quality_summary is not None:
        if quality_owner is None:
            raise DocumentWorkflowConfigurationError(
                "Workflow Local OCR quality owner is unavailable"
            )
        by_kind = {stage.kind: stage for stage in stages}
        ocr_stage = by_kind[WorkflowStageKind.OCR_OR_AZURE]
        owner_stage = by_kind[quality_owner]
        quality_binding = _local_ocr_quality_evidence_binding(
            summary=quality_summary,
            owner=quality_owner,
            document_type=plan.document_type,
            document_format=plan.document_format,
            request_identity=plan.request_identity,
            ocr_stage=ocr_stage,
            owner_stage=owner_stage,
            usage=_authoritative_local_ocr_quality_usage(
                quality_summary,
                ocr_stage,
            ),
        )
    manifest = DocumentWorkflowManifest(
        sdk_version=__version__,
        source=plan.source,
        tenant_scope_identity=request.tenant_scope_identity,
        document_type=plan.document_type,
        document_format=plan.document_format,
        request_identity=plan.request_identity,
        plan_identity=plan.plan_identity,
        workflow_identity=plan.workflow_identity,
        stages=stages,
        usage=usage,
        artifact_references=references,
        warnings=warnings,
        issues=issues,
        limitations=limitations,
        limitation_codes=limitation_codes,
        local_ocr_quality_summary=quality_summary,
        local_ocr_quality_owner_stage=quality_owner,
        local_ocr_quality_binding=quality_binding,
    )
    output_policy = request.output_policy
    included_native = native if output_policy.include_native_result else None
    included_document = document if output_policy.include_top_level_document else None
    included_structured = (
        structured if output_policy.include_structured_extraction else None
    )
    native_document_present = type(included_native) in {
        WorkflowPdfNativeResult,
        WorkflowDocxNativeResult,
    } or (
        type(included_native) is WorkflowImageNativeResult
        and included_native.analysis.ocr_result is not None
    )
    omitted: list[WorkflowArtifactKind] = []
    if native is not None and not output_policy.include_native_result:
        omitted.append(WorkflowArtifactKind.NATIVE_RESULT)
    if document is not None and not output_policy.include_top_level_document:
        omitted.append(WorkflowArtifactKind.DOCUMENT)
    if structured is not None and not output_policy.include_structured_extraction:
        omitted.append(WorkflowArtifactKind.STRUCTURED_EXTRACTION)
    output = WorkflowOutputEvidence(
        native_result_included=native is not None
        and output_policy.include_native_result,
        top_level_document_included=(
            document is not None and output_policy.include_top_level_document
        ),
        structured_extraction_included=(
            structured is not None and output_policy.include_structured_extraction
        ),
        document_content_present=(
            native_document_present
            or included_document is not None
            or included_structured is not None
        ),
        excel_mode=(
            output_policy.excel_mode
            if plan.document_type is DocumentType.EXCEL
            else None
        ),
        excel_cell_count=excel_cell_count,
        truncated=truncated,
        omitted_outputs=tuple(omitted),
        limitation_codes=limitation_codes,
    )
    return DocumentWorkflowResult(
        status=status,
        source=plan.source,
        detected_document_type=plan.document_type,
        detected_document_format=plan.document_format,
        plan=plan,
        stage_results=stages,
        native_result=included_native,
        document=included_document,
        structured_extraction=included_structured,
        usage=usage,
        warnings=warnings,
        issues=issues,
        limitations=limitations,
        output_evidence=output,
        manifest=manifest,
        artifact_references=references,
    )


def _unsupported_result(
    plan: DocumentWorkflowPlan,
    request: DocumentWorkflowRequest,
) -> DocumentWorkflowResult:
    selection = _ProviderSelection(
        ocr=None,
        identities=(),
        route_identities={},
    )
    plan = _bind_initial_plan(plan, request, selection)
    structured_extraction_identity = workflow_fingerprint(
        "unsupported-structured-extraction-stage",
        {
            "request_identity": plan.request_identity,
            "sdk_version": __version__,
            "source": plan.source.model_dump(mode="json"),
        },
    )
    plan = _finalize_bound_plan(
        plan,
        request,
        structured_extraction_stage_identity=structured_extraction_identity,
    )
    detect, inspect_result = _detect_inspect_results(plan)
    finalize_issue = _issue(
        WorkflowStageKind.FINALIZE,
        code="workflow_route_unsupported",
        category=WorkflowIssueCategory.UNSUPPORTED,
        message="The requested workflow route is not supported",
        retryable=False,
    )
    stages = (
        detect,
        inspect_result,
        _skipped_result(plan, WorkflowStageKind.NATIVE_ANALYSIS),
        _skipped_result(plan, WorkflowStageKind.OCR_OR_AZURE),
        _skipped_result(plan, WorkflowStageKind.NORMALIZE),
        _skipped_result(plan, WorkflowStageKind.STRUCTURED_EXTRACTION),
        _stage_result(
            plan,
            WorkflowStageKind.FINALIZE,
            status=WorkflowStageStatus.FAILED,
            issues=(finalize_issue,),
        ),
    )
    return _build_result(
        status=DocumentWorkflowStatus.FAILED,
        plan=plan,
        request=request,
        stages=stages,
        native=None,
        document=None,
        structured=None,
        warnings=(),
        limitations=plan.limitations,
        excel_cell_count=0,
        truncated=False,
    )


def _failed_native_result(
    *,
    error: BaseException,
    plan: DocumentWorkflowPlan,
    request: DocumentWorkflowRequest,
    retained_usage: tuple[ProviderUsage, ...] = (),
    retained_attempts: tuple[CloudExecutionAttemptEvidence, ...] = (),
) -> DocumentWorkflowResult:
    structured_extraction_identity = workflow_fingerprint(
        "unavailable-structured-extraction-stage",
        {
            "native_stage_identity": _plan_stage(
                plan,
                WorkflowStageKind.NATIVE_ANALYSIS,
            ).stage_identity,
            "sdk_version": __version__,
        },
    )
    plan = _finalize_bound_plan(
        plan,
        request,
        structured_extraction_stage_identity=structured_extraction_identity,
    )
    usages, attempts = _failure_evidence(error)
    ocr_planned = (
        _plan_stage(plan, WorkflowStageKind.OCR_OR_AZURE).status
        is WorkflowStageStatus.PLANNED
    )
    local_contract_failure = type(error) is _WorkflowLocalProviderContractError
    azure_image_preflight_failure = type(error) is _WorkflowAzureImagePreflightError
    provider_involved = bool(usages or attempts) or local_contract_failure
    failed_kind = (
        WorkflowStageKind.OCR_OR_AZURE
        if ocr_planned
        and (
            provider_involved
            or plan.route is WorkflowRoute.PDF_AZURE_FIRST
            or azure_image_preflight_failure
        )
        else WorkflowStageKind.NATIVE_ANALYSIS
    )
    failed_category, failed_identity = _provider_identity_for_stage(
        plan,
        failed_kind,
    )
    cumulative_attempts = retained_attempts + attempts
    cumulative_usage = retained_usage + usages
    protected = _protected_evidence(
        cumulative_attempts,
        cumulative_usage,
    )
    azure_category, azure_identity = _provider_identity_for_stage(
        plan,
        WorkflowStageKind.OCR_OR_AZURE,
    )
    protected_retryable = (
        protected
        and type(error) is not _WorkflowSourceChangedError
        and not local_contract_failure
        and azure_category is WorkflowProviderCategory.AZURE_DOCUMENT_INTELLIGENCE
        and request.policy.azure_execution_policy.allow_retry_possibly_paid
        and not _cloud_retry_budget_exhausted(
            request.policy.azure_execution_policy,
            cumulative_attempts,
        )
    )
    source_changed = type(error) is _WorkflowSourceChangedError
    azure_stage_failure = (
        failed_kind is WorkflowStageKind.OCR_OR_AZURE
        and failed_category is WorkflowProviderCategory.AZURE_DOCUMENT_INTELLIGENCE
    )
    failure_issue = _issue(
        failed_kind,
        code=(
            "source_changed"
            if source_changed
            else "local_ocr_provider_contract_failed"
            if local_contract_failure
            else "native_retry_budget_exhausted"
            if protected
            and request.policy.azure_execution_policy.allow_retry_possibly_paid
            and not protected_retryable
            else "provider_operation_requires_review"
            if protected
            else "azure_document_analysis_failed"
            if azure_stage_failure
            else "native_analysis_failed"
        ),
        category=(
            WorkflowIssueCategory.SOURCE
            if source_changed
            else _failure_category(
                error,
                provider=provider_involved or azure_stage_failure,
            )
        ),
        message=(
            "Workflow source changed during execution"
            if source_changed
            else "Workflow Local OCR Provider violated its local-only contract"
            if local_contract_failure
            else "A protected Provider operation requires review"
            if protected
            else "Azure document analysis failed"
            if azure_stage_failure
            else "Document native analysis failed"
        ),
        retryable=(
            protected_retryable
            if failed_kind is WorkflowStageKind.OCR_OR_AZURE
            else False
        ),
        provider_category=failed_category,
    )
    detect, inspect_result = _detect_inspect_results(plan)
    native = (
        _skipped_result(plan, WorkflowStageKind.NATIVE_ANALYSIS)
        if failed_kind is WorkflowStageKind.OCR_OR_AZURE
        else _stage_result(
            plan,
            WorkflowStageKind.NATIVE_ANALYSIS,
            status=WorkflowStageStatus.FAILED,
            issues=(failure_issue,),
        )
    )
    if failed_kind is WorkflowStageKind.OCR_OR_AZURE:
        ocr = _stage_result(
            plan,
            WorkflowStageKind.OCR_OR_AZURE,
            status=(
                WorkflowStageStatus.REVIEW_REQUIRED
                if protected
                else WorkflowStageStatus.FAILED
            ),
            provider_category=failed_category,
            provider_identity=failed_identity,
            current_usage=() if local_contract_failure else usages,
            retained_usage=retained_usage,
            current_attempts=() if local_contract_failure else attempts,
            retained_attempts=retained_attempts,
            issues=(failure_issue,),
            retry_eligible=failure_issue.retryable,
        )
    elif retained_usage or retained_attempts:
        retained_issue = (
            _issue(
                WorkflowStageKind.OCR_OR_AZURE,
                code=(
                    "native_retry_budget_exhausted"
                    if request.policy.azure_execution_policy.allow_retry_possibly_paid
                    and not protected_retryable
                    else "native_retry_pending_after_native_failure"
                    if protected_retryable
                    else "native_retry_requires_authorization"
                ),
                category=WorkflowIssueCategory.RESUME,
                message=(
                    "The cumulative native Provider retry budget is exhausted"
                    if request.policy.azure_execution_policy.allow_retry_possibly_paid
                    and not protected_retryable
                    else "Protected Provider history remains after native failure"
                    if protected_retryable
                    else "A protected native Provider operation requires review"
                ),
                retryable=protected_retryable,
                provider_category=azure_category,
            )
            if protected
            else None
        )
        ocr = _stage_result(
            plan,
            WorkflowStageKind.OCR_OR_AZURE,
            status=(
                WorkflowStageStatus.REVIEW_REQUIRED
                if protected
                else WorkflowStageStatus.FAILED
            ),
            provider_category=azure_category,
            provider_identity=azure_identity,
            retained_usage=retained_usage,
            retained_attempts=retained_attempts,
            issues=() if retained_issue is None else (retained_issue,),
            retry_eligible=(
                False if retained_issue is None else retained_issue.retryable
            ),
        )
    else:
        ocr = _skipped_result(plan, WorkflowStageKind.OCR_OR_AZURE)
    stages = (
        detect,
        inspect_result,
        native,
        ocr,
        _skipped_result(plan, WorkflowStageKind.NORMALIZE),
        _skipped_result(plan, WorkflowStageKind.STRUCTURED_EXTRACTION),
        _stage_result(
            plan,
            WorkflowStageKind.FINALIZE,
            status=WorkflowStageStatus.SUCCEEDED,
            output_identity=plan.workflow_identity,
        ),
    )
    return _build_result(
        status=(
            DocumentWorkflowStatus.REVIEW_REQUIRED
            if protected
            else DocumentWorkflowStatus.FAILED
        ),
        plan=plan,
        request=request,
        stages=stages,
        native=None,
        document=None,
        structured=None,
        warnings=(),
        limitations=plan.limitations,
        excel_cell_count=0,
        truncated=False,
    )


def _native_output_facts(
    native: WorkflowNativeResult | None,
    request: DocumentWorkflowRequest,
) -> tuple[int, tuple[WorkflowLimitation, ...], bool]:
    if type(native) is not WorkflowExcelNativeResult:
        return 0, (), False
    excel = native
    count = sum(len(item.data.cells) for item in excel.ranges)
    truncated = (
        request.output_policy.excel_mode is ExcelWorkflowOutputMode.FULL_IF_WITHIN_LIMIT
        and not excel.detail_complete
    )
    limitations = (
        (
            WorkflowLimitation(
                code="excel_detail_limit_reached",
                message="Excel full detail exceeds the explicit output limit",
            ),
        )
        if truncated
        else ()
    )
    return count, limitations, truncated


def _native_stage_results(
    *,
    plan: DocumentWorkflowPlan,
    execution: _NativeExecution,
    native_references: tuple[WorkflowArtifactReference, ...],
    document_references: tuple[WorkflowArtifactReference, ...],
    detection_issues: tuple[WorkflowStageIssue, ...] = (),
    retained_usage: tuple[ProviderUsage, ...] = (),
    retained_attempts: tuple[CloudExecutionAttemptEvidence, ...] = (),
) -> tuple[WorkflowStageResult, ...]:
    detect, inspect_result = _detect_inspect_results(
        plan,
        detection_issues=detection_issues,
    )
    if execution.native is None:
        native_identity = None
        native = _skipped_result(plan, WorkflowStageKind.NATIVE_ANALYSIS)
    else:
        native_identity = workflow_artifact_output_identity(
            WorkflowArtifactKind.NATIVE_RESULT,
            execution.native,
        )
        native = _stage_result(
            plan,
            WorkflowStageKind.NATIVE_ANALYSIS,
            status=WorkflowStageStatus.SUCCEEDED,
            output_identity=native_identity,
            references=native_references,
            issues=tuple(
                issue
                for issue in execution.issues
                if issue.stage_kind is WorkflowStageKind.NATIVE_ANALYSIS
            ),
            reuse_eligible=bool(native_references),
        )
    ocr_plan = _plan_stage(plan, WorkflowStageKind.OCR_OR_AZURE)
    if ocr_plan.status is WorkflowStageStatus.SKIPPED:
        ocr = _skipped_result(plan, WorkflowStageKind.OCR_OR_AZURE)
    else:
        category, identity = _provider_identity_for_stage(
            plan,
            WorkflowStageKind.OCR_OR_AZURE,
        )
        ocr = _stage_result(
            plan,
            WorkflowStageKind.OCR_OR_AZURE,
            status=WorkflowStageStatus.SUCCEEDED,
            output_identity=(
                native_identity
                if execution.document is None and native_identity is not None
                else workflow_artifact_output_identity(
                    WorkflowArtifactKind.DOCUMENT,
                    execution.document,
                )
            ),
            provider_category=category,
            provider_identity=identity,
            current_usage=execution.usages,
            retained_usage=retained_usage,
            current_attempts=execution.attempts,
            retained_attempts=retained_attempts,
            issues=tuple(
                issue
                for issue in execution.issues
                if issue.stage_kind is WorkflowStageKind.OCR_OR_AZURE
            ),
            reuse_eligible=bool(native_references or document_references),
        )
    normalize_plan = _plan_stage(plan, WorkflowStageKind.NORMALIZE)
    if normalize_plan.status is WorkflowStageStatus.SKIPPED:
        normalize = _skipped_result(plan, WorkflowStageKind.NORMALIZE)
    else:
        if execution.document is None:
            raise DocumentWorkflowConfigurationError(
                "Workflow normalized Document is missing"
            )
        normalize = _stage_result(
            plan,
            WorkflowStageKind.NORMALIZE,
            status=WorkflowStageStatus.SUCCEEDED,
            output_identity=workflow_artifact_output_identity(
                WorkflowArtifactKind.DOCUMENT,
                execution.document,
            ),
            references=document_references,
            reuse_eligible=bool(document_references),
        )
    return detect, inspect_result, native, ocr, normalize


def _native_artifact_failure_result(
    *,
    plan: DocumentWorkflowPlan,
    request: DocumentWorkflowRequest,
    execution: _NativeExecution,
    failed_stage_kind: WorkflowStageKind,
    native_references: tuple[WorkflowArtifactReference, ...],
    retained_usage: tuple[ProviderUsage, ...] = (),
    retained_attempts: tuple[CloudExecutionAttemptEvidence, ...] = (),
) -> DocumentWorkflowResult:
    structured_extraction_identity = workflow_fingerprint(
        "artifact-failed-structured-extraction-stage",
        {
            "failed_stage": failed_stage_kind.value,
            "sdk_version": __version__,
            "source": plan.source.model_dump(mode="json"),
        },
    )
    plan = _finalize_bound_plan(
        plan,
        request,
        structured_extraction_stage_identity=structured_extraction_identity,
    )
    protected = _protected_evidence(
        retained_attempts + execution.attempts,
        retained_usage + execution.usages,
    )
    failure_status: _FinalWorkflowStageStatus = (
        WorkflowStageStatus.REVIEW_REQUIRED if protected else WorkflowStageStatus.FAILED
    )
    issue = _issue(
        failed_stage_kind,
        code="artifact_persistence_failed",
        category=WorkflowIssueCategory.ARTIFACT,
        message="Workflow artifact persistence failed",
        retryable=False,
    )
    stages = list(
        _native_stage_results(
            plan=plan,
            execution=execution,
            native_references=native_references,
            document_references=(),
            retained_usage=retained_usage,
            retained_attempts=retained_attempts,
        )
    )
    failed_index = {
        WorkflowStageKind.NATIVE_ANALYSIS: 2,
        WorkflowStageKind.NORMALIZE: 4,
    }[failed_stage_kind]
    failed_value: object = execution.native
    if failed_stage_kind is WorkflowStageKind.NORMALIZE:
        if execution.document is None:
            raise DocumentWorkflowConfigurationError(
                "Workflow normalized Document is missing"
            )
        failed_value = execution.document
    stages[failed_index] = _stage_result(
        plan,
        failed_stage_kind,
        status=failure_status,
        output_identity=workflow_artifact_output_identity(
            (
                WorkflowArtifactKind.NATIVE_RESULT
                if failed_stage_kind is WorkflowStageKind.NATIVE_ANALYSIS
                else WorkflowArtifactKind.DOCUMENT
            ),
            failed_value,
        ),
        references=(
            native_references
            if failed_stage_kind is WorkflowStageKind.NATIVE_ANALYSIS
            else ()
        ),
        issues=(
            *(
                item
                for item in execution.issues
                if item.stage_kind is failed_stage_kind
            ),
            issue,
        ),
    )
    stages.extend(
        (
            _skipped_result(plan, WorkflowStageKind.STRUCTURED_EXTRACTION),
            _stage_result(
                plan,
                WorkflowStageKind.FINALIZE,
                status=WorkflowStageStatus.SUCCEEDED,
                output_identity=plan.workflow_identity,
            ),
        )
    )
    final_stages = _apply_local_ocr_quality_review(
        plan=plan,
        stages=tuple(stages),
        native=execution.native,
        structured=None,
    )
    return _build_result(
        status=(
            DocumentWorkflowStatus.REVIEW_REQUIRED
            if protected
            or any(
                stage.status is WorkflowStageStatus.REVIEW_REQUIRED
                for stage in final_stages
            )
            else DocumentWorkflowStatus.FAILED
        ),
        plan=plan,
        request=request,
        stages=final_stages,
        native=execution.native,
        document=execution.document,
        structured=None,
        warnings=execution.warnings,
        limitations=plan.limitations + execution.limitations,
        excel_cell_count=execution.excel_cell_count,
        truncated=execution.truncated,
    )


def _native_resume_blocked_result(
    *,
    plan: DocumentWorkflowPlan,
    request: DocumentWorkflowRequest,
    blocked: _NativeResumeBlocked,
    warnings: tuple[ProcessingWarning, ...],
) -> DocumentWorkflowResult:
    structured_extraction_identity = workflow_fingerprint(
        "protected-native-resume-structured-extraction-stage",
        {
            "native_stage_identity": blocked.prior.stage_identity,
            "source": plan.source.model_dump(mode="json"),
        },
    )
    plan = _finalize_bound_plan(
        plan,
        request,
        structured_extraction_stage_identity=structured_extraction_identity,
    )
    category, identity = _provider_identity_for_stage(
        plan,
        WorkflowStageKind.OCR_OR_AZURE,
    )
    issue = _issue(
        WorkflowStageKind.OCR_OR_AZURE,
        code=blocked.code,
        category=(
            WorkflowIssueCategory.PROVIDER
            if blocked.code == "local_ocr_provider_contract_failed"
            else WorkflowIssueCategory.RESUME
        ),
        message=blocked.message,
        retryable=blocked.retryable,
        provider_category=category,
    )
    detect, inspect_result = _detect_inspect_results(plan)
    blocked_stage = _stage_result(
        plan,
        WorkflowStageKind.OCR_OR_AZURE,
        status=WorkflowStageStatus.REVIEW_REQUIRED,
        input_identity=blocked.prior.input_identity,
        provider_category=category,
        provider_identity=identity,
        retained_usage=(
            blocked.prior.retained_provider_usage + blocked.prior.current_provider_usage
        ),
        retained_attempts=(
            blocked.prior.retained_cloud_attempts + blocked.prior.current_cloud_attempts
        ),
        issues=(issue,),
        retry_eligible=blocked.retryable,
    )
    stages = (
        detect,
        inspect_result,
        _skipped_result(plan, WorkflowStageKind.NATIVE_ANALYSIS),
        blocked_stage,
        _skipped_result(plan, WorkflowStageKind.NORMALIZE),
        _skipped_result(plan, WorkflowStageKind.STRUCTURED_EXTRACTION),
        _stage_result(
            plan,
            WorkflowStageKind.FINALIZE,
            status=WorkflowStageStatus.SUCCEEDED,
            output_identity=plan.workflow_identity,
        ),
    )
    return _build_result(
        status=DocumentWorkflowStatus.REVIEW_REQUIRED,
        plan=plan,
        request=request,
        stages=stages,
        native=None,
        document=None,
        structured=None,
        warnings=warnings,
        limitations=plan.limitations,
        excel_cell_count=0,
        truncated=False,
    )


def _same_structured_extraction_stage(
    manifest: DocumentWorkflowManifest | None,
    plan: DocumentWorkflowPlan,
) -> WorkflowStageResult | None:
    if manifest is None:
        return None
    prior = _prior_stage(manifest, WorkflowStageKind.STRUCTURED_EXTRACTION)
    if (
        prior.stage_identity
        != _plan_stage(
            plan,
            WorkflowStageKind.STRUCTURED_EXTRACTION,
        ).stage_identity
    ):
        return None
    if prior.provider_category is not None or prior.provider_identity is not None:
        raise DocumentWorkflowResumeError(
            "Workflow Resume Structured Extraction Provider evidence is incompatible"
        )
    return prior


def _load_structured_extraction_resume(
    prior: WorkflowStageResult,
    *,
    plan: DocumentWorkflowPlan,
    request: DocumentWorkflowRequest,
    document: Document,
    store: WorkflowArtifactStore | None,
    route_identity: str,
) -> tuple[StructuredExtractionResult, WorkflowStageResult] | None:
    if prior.status not in {
        WorkflowStageStatus.SUCCEEDED,
        WorkflowStageStatus.REUSED,
        WorkflowStageStatus.REVIEW_REQUIRED,
    }:
        return None
    if (
        prior.status is WorkflowStageStatus.REVIEW_REQUIRED
        and not _is_local_ocr_quality_review_stage(prior)
    ):
        return None
    reference = _single_artifact_reference(
        prior,
        WorkflowArtifactKind.STRUCTURED_EXTRACTION,
    )
    if reference is None:
        if _is_local_ocr_quality_review_stage(prior):
            raise DocumentWorkflowResumeError(
                "Workflow quality Review artifact is unavailable"
            )
        if _protected_stage_evidence(prior):
            return None
        if not request.policy.allow_local_recompute:
            raise DocumentWorkflowResumeError(
                "Workflow local Structured Extraction artifact is unavailable"
            )
        return None
    loaded = _load_resume_artifact(
        store,
        reference,
        kind=WorkflowArtifactKind.STRUCTURED_EXTRACTION,
        plan=plan,
        request=request,
        stage_kind=WorkflowStageKind.STRUCTURED_EXTRACTION,
        expected_output_identity=cast("str", prior.output_identity),
        route_identity=route_identity,
    )
    if type(loaded) is not StructuredExtractionResult or loaded.document != document:
        raise DocumentWorkflowResumeError(
            "Workflow Resume extraction artifact is inconsistent"
        )
    prior_structured_issues = tuple(
        issue for issue in prior.issues if issue.code != _LOCAL_OCR_QUALITY_REVIEW_CODE
    )
    if prior_structured_issues != _structured_result_issues(loaded):
        raise DocumentWorkflowResumeError(
            "Workflow Resume extraction issue evidence is inconsistent"
        )
    return loaded, _reused_stage(plan, prior)


def _structured_extraction_failure_stage(
    error: BaseException,
    *,
    plan: DocumentWorkflowPlan,
) -> WorkflowStageResult:
    issue = _issue(
        WorkflowStageKind.STRUCTURED_EXTRACTION,
        code="structured_extraction_failed",
        category=_failure_category(error, provider=False),
        message="Workflow Structured Extraction failed",
        retryable=False,
    )
    return _stage_result(
        plan,
        WorkflowStageKind.STRUCTURED_EXTRACTION,
        status=WorkflowStageStatus.FAILED,
        issues=(issue,),
        retry_eligible=False,
    )


def _completed_status(
    *,
    truncated: bool,
    limitations: tuple[WorkflowLimitation, ...],
    structured: StructuredExtractionResult | None,
    issues: tuple[WorkflowStageIssue, ...],
) -> DocumentWorkflowStatus:
    partial_codes = {"excel_detail_limit_reached", "ocr_candidates_not_processed"}
    if (
        truncated
        or any(item.code in partial_codes for item in limitations)
        or (structured is not None and not structured.complete)
        or issues
    ):
        return DocumentWorkflowStatus.PARTIAL
    return DocumentWorkflowStatus.SUCCEEDED


def _batch_source_identity_matches(
    source: Path,
    expected: WorkflowSourceIdentity,
) -> bool:
    """Recheck one Batch-owned expected identity without family processing."""
    try:
        mode = source.lstat().st_mode
    except OSError:
        return False
    if not stat.S_ISREG(mode) or stat.S_ISLNK(mode):
        return False
    try:
        actual = _raw_identity(source, max_bytes=expected.byte_size)
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception:
        return False
    return actual == (expected.sha256, expected.byte_size)


def _run_document_workflow_from_source(
    source: str | Path,
    request: DocumentWorkflowRequest,
    *,
    providers: DocumentWorkflowProviders,
    artifact_store: WorkflowArtifactStore | None = None,
    resume_manifest: DocumentWorkflowManifest | None = None,
    local_invocation_state: _LocalOcrInvocationState | None = None,
    expected_source_identity: WorkflowSourceIdentity | None = None,
    source_is_immutable: bool,
) -> DocumentWorkflowResult:
    """Run the Workflow against one caller path or private immutable source."""
    validated_request = _validated_request(request)
    validated_providers = _validated_providers(providers)
    source_path = Path(source)
    try:
        dry_plan, detection_warnings = _plan_document_workflow_with_warnings(
            source_path,
            validated_request,
            expected_source_identity=expected_source_identity,
            _source_is_immutable=source_is_immutable,
        )
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception:
        if expected_source_identity is not None and not _batch_source_identity_matches(
            source_path,
            expected_source_identity,
        ):
            raise DocumentSourceChangedError(
                "The Workflow Batch source changed before planning"
            ) from None
        raise
    if expected_source_identity is not None and (
        dry_plan.source != expected_source_identity
        or not _batch_source_identity_matches(
            source_path,
            expected_source_identity,
        )
    ):
        raise DocumentSourceChangedError(
            "The Workflow Batch source changed before execution"
        )
    detection_issues = _detection_issues(detection_warnings)
    validated_manifest = _validated_resume_manifest(
        resume_manifest,
        plan=dry_plan,
        request=validated_request,
    )
    has_resume_artifacts = bool(
        validated_manifest is not None and validated_manifest.artifact_references
    )
    store = _validate_artifact_store(
        artifact_store,
        required=(
            validated_request.output_policy.persist_intermediate_artifacts
            or has_resume_artifacts
        ),
    )
    if not dry_plan.supported:
        return _unsupported_result(dry_plan, validated_request)
    selection = _select_providers(
        dry_plan,
        validated_request,
        validated_providers,
    )
    plan = _bind_initial_plan(dry_plan, validated_request, selection)
    inspection: DocumentInspectionResult | None = None
    if plan.route not in {
        WorkflowRoute.PDF_AZURE_FIRST,
        WorkflowRoute.IMAGE_AZURE,
    }:
        try:
            inspection = (
                inspect_document(source_path)
                if expected_source_identity is None
                else _prepare_document(
                    source_path,
                    expected_identity=(
                        expected_source_identity.sha256,
                        expected_source_identity.byte_size,
                    ),
                ).inspection
            )
        except (KeyboardInterrupt, SystemExit, GeneratorExit):
            raise
        except Exception:
            if expected_source_identity is not None and not (
                _batch_source_identity_matches(
                    source_path,
                    expected_source_identity,
                )
            ):
                raise DocumentSourceChangedError(
                    "The Workflow Batch source changed before inspection"
                ) from None
            raise
        inspection_source = workflow_source_identity_from_descriptor(
            inspection.inspection.inspection.file
        )
        if inspection_source != plan.source:
            if expected_source_identity is not None:
                raise DocumentSourceChangedError(
                    "The Workflow Batch source changed after planning"
                )
            raise DocumentWorkflowResumeError("Workflow source changed after planning")
        if (
            inspection.envelope.document_type is not plan.document_type
            or inspection.envelope.document_format is not plan.document_format
        ):
            raise DocumentWorkflowResumeError("Workflow source changed after planning")
    native_resume_decision = _resume_native_execution(
        validated_manifest,
        plan=plan,
        request=validated_request,
        selection=selection,
        store=store,
    )
    if type(native_resume_decision) is _NativeResumeBlocked:
        return _native_resume_blocked_result(
            plan=plan,
            request=validated_request,
            blocked=native_resume_decision,
            warnings=(
                () if validated_manifest is None else validated_manifest.warnings
            ),
        )
    retry_history = (
        native_resume_decision
        if type(native_resume_decision) is _NativeRetryHistory
        else _NativeRetryHistory(usages=(), attempts=())
    )
    native_resume = (
        native_resume_decision
        if type(native_resume_decision) is _NativeResume
        else None
    )
    warnings: tuple[ProcessingWarning, ...] = ()
    if native_resume is None:
        try:
            execution = _execute_native(
                source_path,
                plan,
                validated_request,
                selection,
                local_invocation_state=local_invocation_state,
                expected_source_identity=expected_source_identity,
            )
        except (KeyboardInterrupt, SystemExit, GeneratorExit):
            raise
        except (
            DocumentWorkflowConfigurationError,
            ProviderConfigurationError,
        ):
            raise
        except DocumentSdkError as exc:
            if expected_source_identity is not None and isinstance(
                exc,
                DocumentSourceChangedError,
            ):
                raise
            if (
                local_invocation_state is not None
                and type(exc)
                in (LocalOcrLimitExceededError, LocalOcrPreprocessingLimitError)
                and isinstance(exc, LocalOcrLimitExceededError)
                and exc.limit_name in local_invocation_state.batch_narrowed_limit_names
            ):
                raise
            return _failed_native_result(
                error=exc,
                plan=plan,
                request=validated_request,
                retained_usage=retry_history.usages,
                retained_attempts=retry_history.attempts,
            )
        route_identity = _analysis_route_identity(plan, selection)
        native_references: tuple[WorkflowArtifactReference, ...]
        if execution.native is None:
            native_references = ()
        else:
            try:
                native_references = _persist_artifact(
                    store,
                    kind=WorkflowArtifactKind.NATIVE_RESULT,
                    value=execution.native,
                    plan=plan,
                    request=validated_request,
                    stage_kind=WorkflowStageKind.NATIVE_ANALYSIS,
                    route_identity=route_identity,
                )
            except DocumentWorkflowArtifactError:
                return _native_artifact_failure_result(
                    plan=plan,
                    request=validated_request,
                    execution=execution,
                    failed_stage_kind=WorkflowStageKind.NATIVE_ANALYSIS,
                    native_references=(),
                    retained_usage=retry_history.usages,
                    retained_attempts=retry_history.attempts,
                )
        try:
            document_references = (
                ()
                if execution.document is None
                else _persist_artifact(
                    store,
                    kind=WorkflowArtifactKind.DOCUMENT,
                    value=execution.document,
                    plan=plan,
                    request=validated_request,
                    stage_kind=WorkflowStageKind.NORMALIZE,
                    route_identity=route_identity,
                )
            )
        except DocumentWorkflowArtifactError:
            return _native_artifact_failure_result(
                plan=plan,
                request=validated_request,
                execution=execution,
                failed_stage_kind=WorkflowStageKind.NORMALIZE,
                native_references=native_references,
                retained_usage=retry_history.usages,
                retained_attempts=retry_history.attempts,
            )
        native_stages = _native_stage_results(
            plan=plan,
            execution=execution,
            native_references=native_references,
            document_references=document_references,
            detection_issues=detection_issues,
            retained_usage=retry_history.usages,
            retained_attempts=retry_history.attempts,
        )
        native = execution.native
        document = execution.document
        warnings = execution.warnings
        excel_cell_count = execution.excel_cell_count
        runtime_limitations = execution.limitations
        truncated = execution.truncated
    else:
        detect, inspect_result = _detect_inspect_results(
            plan,
            detection_issues=detection_issues,
        )
        native_stages = (detect, inspect_result, *native_resume.stages)
        native = native_resume.native
        document = native_resume.document
        warnings = validated_manifest.warnings if validated_manifest is not None else ()
        excel_cell_count, runtime_limitations, truncated = _native_output_facts(
            native,
            validated_request,
        )
    _validate_native_document_alignment(native, document)
    intrinsic_quality_report, preprocessing_report, intrinsic_provider_usage = (
        _native_local_ocr_quality_evidence(native)
    )
    if plan.route not in {
        WorkflowRoute.PDF_HYBRID_LOCAL,
        WorkflowRoute.IMAGE_LOCAL_OCR,
    }:
        intrinsic_quality_report = None
        preprocessing_report = None
        intrinsic_provider_usage = None
    structured_extraction_identity, structured_extraction_route_identity = (
        _structured_extraction_stage_identity(
            plan,
            validated_request,
            document,
        )
    )
    plan = _finalize_bound_plan(
        plan,
        validated_request,
        structured_extraction_stage_identity=structured_extraction_identity,
    )
    if validated_request.extraction_mode is WorkflowExtractionMode.NONE:
        structured_extraction_stage = _skipped_result(
            plan,
            WorkflowStageKind.STRUCTURED_EXTRACTION,
        )
        structured = None
    else:
        if document is None:
            raise DocumentWorkflowConfigurationError(
                "Workflow extraction requires a normalized Document"
            )
        prior_extraction = _same_structured_extraction_stage(validated_manifest, plan)
        resumed = (
            None
            if prior_extraction is None
            else _load_structured_extraction_resume(
                prior_extraction,
                plan=plan,
                request=validated_request,
                document=document,
                store=store,
                route_identity=structured_extraction_route_identity,
            )
        )
        if resumed is not None:
            structured, structured_extraction_stage = resumed
        else:
            if (
                prior_extraction is not None
                and not validated_request.policy.allow_local_recompute
            ):
                raise DocumentWorkflowResumeError(
                    "Workflow deterministic extraction recompute is disabled"
                )
            try:
                extracted = _execute_structured_extraction(
                    document,
                    validated_request,
                    intrinsic_quality_report=intrinsic_quality_report,
                    preprocessing_report=preprocessing_report,
                    intrinsic_provider_usage=intrinsic_provider_usage,
                )
            except (KeyboardInterrupt, SystemExit, GeneratorExit):
                raise
            except DocumentWorkflowConfigurationError:
                raise
            except DocumentSdkError as exc:
                structured_extraction_stage = _structured_extraction_failure_stage(
                    exc,
                    plan=plan,
                )
                structured = None
            else:
                try:
                    extraction_references = _persist_artifact(
                        store,
                        kind=WorkflowArtifactKind.STRUCTURED_EXTRACTION,
                        value=extracted.result,
                        plan=plan,
                        request=validated_request,
                        stage_kind=WorkflowStageKind.STRUCTURED_EXTRACTION,
                        route_identity=structured_extraction_route_identity,
                    )
                except DocumentWorkflowArtifactError:
                    artifact_issue = _issue(
                        WorkflowStageKind.STRUCTURED_EXTRACTION,
                        code="artifact_persistence_failed",
                        category=WorkflowIssueCategory.ARTIFACT,
                        message="Workflow artifact persistence failed",
                        retryable=False,
                    )
                    structured_extraction_stage = _stage_result(
                        plan,
                        WorkflowStageKind.STRUCTURED_EXTRACTION,
                        status=WorkflowStageStatus.FAILED,
                        output_identity=workflow_artifact_output_identity(
                            WorkflowArtifactKind.STRUCTURED_EXTRACTION,
                            extracted.result,
                        ),
                        issues=(
                            *_structured_result_issues(extracted.result),
                            artifact_issue,
                        ),
                    )
                else:
                    structured_extraction_stage = _stage_result(
                        plan,
                        WorkflowStageKind.STRUCTURED_EXTRACTION,
                        status=WorkflowStageStatus.SUCCEEDED,
                        output_identity=workflow_artifact_output_identity(
                            WorkflowArtifactKind.STRUCTURED_EXTRACTION,
                            extracted.result,
                        ),
                        issues=_structured_result_issues(extracted.result),
                        references=extraction_references,
                        reuse_eligible=bool(extraction_references),
                    )
                structured = extracted.result
    finalize = _stage_result(
        plan,
        WorkflowStageKind.FINALIZE,
        status=WorkflowStageStatus.SUCCEEDED,
        output_identity=plan.workflow_identity,
    )
    stages = _apply_local_ocr_quality_review(
        plan=plan,
        stages=(*native_stages, structured_extraction_stage, finalize),
        native=native,
        structured=structured,
    )
    workflow_issues = tuple(issue for stage in stages for issue in stage.issues)
    limitations = plan.limitations + runtime_limitations
    if any(stage.status is WorkflowStageStatus.REVIEW_REQUIRED for stage in stages):
        status = DocumentWorkflowStatus.REVIEW_REQUIRED
    elif structured_extraction_stage.status is WorkflowStageStatus.FAILED:
        status = DocumentWorkflowStatus.FAILED
    else:
        status = _completed_status(
            truncated=truncated,
            limitations=limitations,
            structured=structured,
            issues=workflow_issues,
        )
    return _build_result(
        status=status,
        plan=plan,
        request=validated_request,
        stages=stages,
        native=native,
        document=document,
        structured=structured,
        warnings=warnings,
        limitations=limitations,
        excel_cell_count=excel_cell_count,
        truncated=truncated,
    )


def _run_document_workflow(
    source: str | Path,
    request: DocumentWorkflowRequest,
    *,
    providers: DocumentWorkflowProviders,
    artifact_store: WorkflowArtifactStore | None = None,
    resume_manifest: DocumentWorkflowManifest | None = None,
    local_invocation_state: _LocalOcrInvocationState | None = None,
    expected_source_identity: WorkflowSourceIdentity | None = None,
) -> DocumentWorkflowResult:
    """Run a private Batch attempt from one expected-identity Snapshot."""
    if expected_source_identity is None:
        return _run_document_workflow_from_source(
            source,
            request,
            providers=providers,
            artifact_store=artifact_store,
            resume_manifest=resume_manifest,
            local_invocation_state=local_invocation_state,
            expected_source_identity=None,
            source_is_immutable=False,
        )
    expected_identity = (
        expected_source_identity.sha256,
        expected_source_identity.byte_size,
    )
    with _immutable_expected_source(Path(source), expected_identity) as snapshot:
        return _run_document_workflow_from_source(
            snapshot,
            request,
            providers=providers,
            artifact_store=artifact_store,
            resume_manifest=resume_manifest,
            local_invocation_state=local_invocation_state,
            expected_source_identity=expected_source_identity,
            source_is_immutable=True,
        )


def run_document_workflow(
    source: str | Path,
    request: DocumentWorkflowRequest,
    *,
    providers: DocumentWorkflowProviders,
    artifact_store: WorkflowArtifactStore | None = None,
    resume_manifest: DocumentWorkflowManifest | None = None,
) -> DocumentWorkflowResult:
    """Run one explicit, stage-aware workflow without implicit Provider selection."""
    return _run_document_workflow(
        source,
        request,
        providers=providers,
        artifact_store=artifact_store,
        resume_manifest=resume_manifest,
        local_invocation_state=None,
    )


def _intake_preplan_result(
    *,
    status: Literal[
        DocumentWorkflowIntakeStatus.FAILED,
        DocumentWorkflowIntakeStatus.REJECTED,
        DocumentWorkflowIntakeStatus.UNSUPPORTED,
    ],
    code: str,
    category: WorkflowIssueCategory,
    message: str,
) -> DocumentWorkflowIntakeResult:
    return DocumentWorkflowIntakeResult(
        status=status,
        issues=(
            DocumentWorkflowIntakeIssue(
                code=code,
                category=category,
                message=message,
                retryable=False,
            ),
        ),
    )


def _intake_preplan_exception_result(  # noqa: PLR0911
    error: BaseException,
    *,
    local_invocation_state: _LocalOcrInvocationState | None,
) -> DocumentWorkflowIntakeResult | None:
    """Map one already-caught typed pre-Plan failure without rereading input."""
    if isinstance(error, _UnsupportedDocumentIdentityError):
        if error.classification == "unsupported":
            return _intake_preplan_result(
                status=DocumentWorkflowIntakeStatus.UNSUPPORTED,
                code="document_type_unsupported",
                category=WorkflowIssueCategory.UNSUPPORTED,
                message="The input content is not supported",
            )
        if error.byte_size == 0:
            return _intake_preplan_result(
                status=DocumentWorkflowIntakeStatus.REJECTED,
                code="document_empty",
                category=WorkflowIssueCategory.SOURCE,
                message="The input file is empty",
            )
        return _intake_preplan_result(
            status=DocumentWorkflowIntakeStatus.REJECTED,
            code="document_container_rejected",
            category=WorkflowIssueCategory.VALIDATION,
            message="The input container failed deterministic safety validation",
        )
    if isinstance(
        error,
        (
            DocxUnsupportedPackageError,
            UnsupportedDocumentOperationError,
            UnsupportedDocumentTypeError,
            UnsupportedFileError,
            UnsupportedWorkbookFeatureError,
        ),
    ):
        return _intake_preplan_result(
            status=DocumentWorkflowIntakeStatus.UNSUPPORTED,
            code="document_type_unsupported",
            category=WorkflowIssueCategory.UNSUPPORTED,
            message="The input content is not supported",
        )
    if isinstance(error, EncryptedDocumentError):
        return _intake_preplan_result(
            status=DocumentWorkflowIntakeStatus.REJECTED,
            code="document_encrypted",
            category=WorkflowIssueCategory.VALIDATION,
            message="Encrypted input is not accepted",
        )
    if isinstance(
        error,
        (
            _DocumentIdentityLimitError,
            DocxResourceLimitError,
            ExcelCellLimitExceededError,
            ExcelPackageLimitError,
            ImageLimitExceededError,
            PdfLimitExceededError,
        ),
    ):
        return _intake_preplan_result(
            status=DocumentWorkflowIntakeStatus.REJECTED,
            code="document_resource_limit",
            category=WorkflowIssueCategory.LIMIT,
            message="The input exceeds a configured safety limit",
        )
    if isinstance(error, LocalOcrLimitExceededError):
        if local_invocation_state is not None:
            return None
        return _intake_preplan_result(
            status=DocumentWorkflowIntakeStatus.REJECTED,
            code="document_input_rejected",
            category=WorkflowIssueCategory.VALIDATION,
            message="The input failed deterministic safety validation",
        )
    if isinstance(error, DocumentSourceChangedError):
        return _intake_preplan_result(
            status=DocumentWorkflowIntakeStatus.REJECTED,
            code="document_source_changed",
            category=WorkflowIssueCategory.SOURCE,
            message="The input changed during deterministic validation",
        )
    if isinstance(error, DocumentTypeMismatchError):
        return _intake_preplan_result(
            status=DocumentWorkflowIntakeStatus.REJECTED,
            code="document_policy_rejected",
            category=WorkflowIssueCategory.VALIDATION,
            message="The input conflicts with the requested processing policy",
        )
    if isinstance(error, DocumentProcessingError):
        return _intake_preplan_result(
            status=DocumentWorkflowIntakeStatus.REJECTED,
            code="document_input_rejected",
            category=WorkflowIssueCategory.VALIDATION,
            message="The input failed deterministic safety validation",
        )
    return None


def _validate_intake_caller_inputs(
    request: DocumentWorkflowRequest,
    providers: DocumentWorkflowProviders,
    artifact_store: WorkflowArtifactStore | None,
    resume_manifest: DocumentWorkflowManifest | None,
) -> None:
    """Validate caller-owned runtime inputs before file outcome mapping."""
    validated_request = _validated_request(request)
    validated_providers = _validated_providers(providers)
    _validate_intake_provider_shapes(validated_request, validated_providers)
    validated_store = _validate_artifact_store_shape(artifact_store)
    _validated_resume_manifest_shape(resume_manifest)
    if (
        validated_store is None
        and validated_request.output_policy.persist_intermediate_artifacts
    ):
        raise DocumentWorkflowConfigurationError("Workflow Artifact Store is required")


def _run_document_workflow_intake(
    source: str | Path,
    request: DocumentWorkflowRequest,
    *,
    providers: DocumentWorkflowProviders,
    artifact_store: WorkflowArtifactStore | None = None,
    resume_manifest: DocumentWorkflowManifest | None = None,
    local_invocation_state: _LocalOcrInvocationState | None = None,
    expected_source_identity: WorkflowSourceIdentity | None = None,
) -> DocumentWorkflowIntakeResult:
    """Map one Workflow run while optionally carrying a private Batch budget."""
    try:
        if local_invocation_state is None and expected_source_identity is None:
            result = run_document_workflow(
                source,
                request,
                providers=providers,
                artifact_store=artifact_store,
                resume_manifest=resume_manifest,
            )
        else:
            result = _run_document_workflow(
                source,
                request,
                providers=providers,
                artifact_store=artifact_store,
                resume_manifest=resume_manifest,
                local_invocation_state=local_invocation_state,
                expected_source_identity=expected_source_identity,
            )
    except (
        _UnsupportedDocumentIdentityError,
        DocxUnsupportedPackageError,
        UnsupportedDocumentOperationError,
        UnsupportedDocumentTypeError,
        UnsupportedFileError,
        UnsupportedWorkbookFeatureError,
        EncryptedDocumentError,
        _DocumentIdentityLimitError,
        DocxResourceLimitError,
        ExcelCellLimitExceededError,
        ExcelPackageLimitError,
        ImageLimitExceededError,
        PdfLimitExceededError,
        LocalOcrLimitExceededError,
        DocumentSourceChangedError,
        DocumentTypeMismatchError,
        DocumentProcessingError,
    ) as exc:
        if expected_source_identity is not None and isinstance(
            exc,
            DocumentSourceChangedError,
        ):
            raise
        mapped = _intake_preplan_exception_result(
            exc,
            local_invocation_state=local_invocation_state,
        )
        if mapped is None:
            raise
        return mapped
    return DocumentWorkflowIntakeResult(
        sdk_version=result.manifest.sdk_version,
        status=_workflow_intake_status(result),
        source=result.source,
        detected_document_type=result.detected_document_type,
        detected_document_format=result.detected_document_format,
        workflow_result=result,
    )


def run_document_workflow_intake(
    source: str | Path,
    request: DocumentWorkflowRequest,
    *,
    providers: DocumentWorkflowProviders,
    artifact_store: WorkflowArtifactStore | None = None,
    resume_manifest: DocumentWorkflowManifest | None = None,
) -> DocumentWorkflowIntakeResult:
    """Return one stable outcome while preserving the existing Workflow contract."""
    _validate_intake_caller_inputs(
        request,
        providers,
        artifact_store,
        resume_manifest,
    )
    return _run_document_workflow_intake(
        source,
        request,
        providers=providers,
        artifact_store=artifact_store,
        resume_manifest=resume_manifest,
        local_invocation_state=None,
        expected_source_identity=None,
    )


def _run_document_workflow_intake_with_local_budget(
    source: str | Path,
    request: DocumentWorkflowRequest,
    *,
    providers: DocumentWorkflowProviders,
    artifact_store: WorkflowArtifactStore | None,
    local_invocation_state: _LocalOcrInvocationState | None,
    expected_source_identity: WorkflowSourceIdentity,
) -> DocumentWorkflowIntakeResult:
    """Run Intake with SDK-owned Batch source and Local budget context."""
    _validate_intake_caller_inputs(
        request,
        providers,
        artifact_store,
        None,
    )
    return _run_document_workflow_intake(
        source,
        request,
        providers=providers,
        artifact_store=artifact_store,
        resume_manifest=None,
        local_invocation_state=local_invocation_state,
        expected_source_identity=expected_source_identity,
    )


__all__ = [
    "DocumentWorkflowProviders",
    "run_document_workflow",
    "run_document_workflow_intake",
]

"""Caller-owned artifact boundary for stage-aware workflow Resume."""

# ruff: noqa: EM101, PLR0913, TRY003

from __future__ import annotations

import hashlib
import inspect
import json
from typing import Literal, Protocol, cast, runtime_checkable

from pydantic import TypeAdapter

from document_sdk.core import Document, FileDescriptor
from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.extraction import StructuredExtractionResult
from document_sdk.workflow.errors import DocumentWorkflowArtifactError
from document_sdk.workflow.models import (
    WORKFLOW_ARTIFACT_SERIALIZATION_VERSION,
    WorkflowArtifactKind,
    WorkflowArtifactReference,
    WorkflowDocxNativeResult,
    WorkflowExcelNativeResult,
    WorkflowImageNativeResult,
    WorkflowNativeResult,
    WorkflowPdfNativeResult,
    WorkflowSourceIdentity,
    WorkflowStageKind,
    workflow_fingerprint,
    workflow_source_identity_from_descriptor,
)

_NATIVE_RESULT_ADAPTER: TypeAdapter[WorkflowNativeResult] = TypeAdapter(
    WorkflowNativeResult
)
_ArtifactModelName = Literal[
    "Document",
    "WorkflowNativeResult",
    "StructuredExtractionResult",
]
_MEDIA_TYPE = "application/vnd.document-sdk.workflow+json"
_ARTIFACT_KEYS = frozenset(
    {
        "artifact_kind",
        "model_name",
        "output_identity",
        "payload",
        "route_identity",
        "serialization_version",
        "source",
        "stage_identity",
        "stage_kind",
        "tenant_scope_identity",
    }
)


@runtime_checkable
class WorkflowArtifactStore(Protocol):
    """Store and load bounded bytes under an opaque SDK-generated identifier."""

    def store(self, artifact_id: str, payload: bytes) -> None:
        """Persist exact bytes under artifact_id without interpreting content."""
        ...

    def load(self, artifact_id: str) -> bytes:
        """Return the exact bytes previously stored under artifact_id."""
        ...


def _artifact_model_name(
    kind: WorkflowArtifactKind,
) -> _ArtifactModelName:
    if kind is WorkflowArtifactKind.DOCUMENT:
        return "Document"
    if kind is WorkflowArtifactKind.NATIVE_RESULT:
        return "WorkflowNativeResult"
    return "StructuredExtractionResult"


def _artifact_payload(value: object, kind: WorkflowArtifactKind) -> dict[str, object]:
    if kind is WorkflowArtifactKind.DOCUMENT:
        if type(value) is not Document:
            raise DocumentWorkflowArtifactError("Workflow Document artifact is invalid")
        document = _revalidate_model_instance_json(
            value,
            Document,
            "Workflow Document artifact is invalid",
        )
        return cast("dict[str, object]", document.model_dump(mode="json"))
    if kind is WorkflowArtifactKind.STRUCTURED_EXTRACTION:
        if type(value) is not StructuredExtractionResult:
            raise DocumentWorkflowArtifactError(
                "Workflow extraction artifact is invalid"
            )
        extraction = _revalidate_model_instance_json(
            value,
            StructuredExtractionResult,
            "Workflow extraction artifact is invalid",
        )
        return cast(
            "dict[str, object]",
            extraction.model_dump(mode="json", by_alias=True),
        )
    if type(value) not in {
        WorkflowPdfNativeResult,
        WorkflowExcelNativeResult,
        WorkflowImageNativeResult,
        WorkflowDocxNativeResult,
    }:
        raise DocumentWorkflowArtifactError("Workflow native artifact is invalid")
    native = _NATIVE_RESULT_ADAPTER.validate_python(value)
    return cast("dict[str, object]", native.model_dump(mode="json"))


def _artifact_source_identity(value: object) -> WorkflowSourceIdentity:
    descriptor: FileDescriptor
    if type(value) is Document:
        descriptor = value.file
    elif type(value) is StructuredExtractionResult:
        descriptor = value.document.file
    elif type(value) is WorkflowPdfNativeResult:
        descriptor = value.analysis.document.file
    elif type(value) is WorkflowExcelNativeResult:
        descriptor = value.analysis.workbook.file
    elif type(value) is WorkflowImageNativeResult:
        descriptor = value.analysis.image.file
    elif type(value) is WorkflowDocxNativeResult:
        descriptor = value.analysis.docx.inspection.file
    else:
        raise DocumentWorkflowArtifactError("Workflow artifact model is invalid")
    try:
        return workflow_source_identity_from_descriptor(descriptor)
    except Exception as exc:  # noqa: BLE001 - stored source boundary is redacted.
        _raise_redacted_translation(
            exc,
            DocumentWorkflowArtifactError("Workflow artifact source is invalid"),
        )


def workflow_artifact_output_identity(
    kind: WorkflowArtifactKind,
    value: object,
) -> str:
    """Fingerprint the exact validated model payload stored for one stage."""
    domain = {
        WorkflowArtifactKind.NATIVE_RESULT: "native-output",
        WorkflowArtifactKind.DOCUMENT: "normalized-document",
        WorkflowArtifactKind.STRUCTURED_EXTRACTION: "structured-extraction",
    }[kind]
    return workflow_fingerprint(domain, _artifact_payload(value, kind))


def _canonical_artifact_bytes(
    *,
    kind: WorkflowArtifactKind,
    value: object,
    source: WorkflowSourceIdentity,
    tenant_scope_identity: str,
    stage_kind: WorkflowStageKind,
    stage_identity: str,
    route_identity: str,
) -> bytes:
    if _artifact_source_identity(value) != source:
        raise DocumentWorkflowArtifactError("Workflow artifact source is inconsistent")
    output_identity = workflow_artifact_output_identity(kind, value)
    envelope = {
        "artifact_kind": kind.value,
        "model_name": _artifact_model_name(kind),
        "output_identity": output_identity,
        "payload": _artifact_payload(value, kind),
        "route_identity": route_identity,
        "serialization_version": WORKFLOW_ARTIFACT_SERIALIZATION_VERSION,
        "source": source.model_dump(mode="json"),
        "stage_identity": stage_identity,
        "stage_kind": stage_kind.value,
        "tenant_scope_identity": tenant_scope_identity,
    }
    return json.dumps(
        envelope,
        allow_nan=False,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode()


def _artifact_id(
    *,
    kind: WorkflowArtifactKind,
    payload_sha256: str,
    source: WorkflowSourceIdentity,
    tenant_scope_identity: str,
    stage_identity: str,
    output_identity: str,
    route_identity: str,
) -> str:
    identity = json.dumps(
        {
            "kind": kind.value,
            "payload_sha256": payload_sha256,
            "output_identity": output_identity,
            "route_identity": route_identity,
            "source": source.model_dump(mode="json"),
            "stage_identity": stage_identity,
            "tenant_scope_identity": tenant_scope_identity,
        },
        separators=(",", ":"),
        sort_keys=True,
    ).encode()
    digest = hashlib.sha256(
        b"document-sdk:workflow-artifact-id:v1\0" + identity
    ).hexdigest()
    return f"wf-artifact-v1-{digest}"


def _store_method(store: object, name: str) -> object:
    try:
        method = inspect.getattr_static(store, name)
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception as exc:  # noqa: BLE001 - caller-owned store boundary.
        _raise_redacted_translation(
            exc,
            DocumentWorkflowArtifactError("Workflow Artifact Store is invalid"),
        )
    if not callable(method):
        raise DocumentWorkflowArtifactError("Workflow Artifact Store is invalid")
    return method


def _load_exact_bytes(store: WorkflowArtifactStore, artifact_id: str) -> bytes:
    _store_method(store, "load")
    try:
        payload = store.load(artifact_id)
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception as exc:  # noqa: BLE001 - caller-owned store boundary.
        _raise_redacted_translation(
            exc,
            DocumentWorkflowArtifactError("Workflow artifact could not be loaded"),
        )
    if type(payload) is not bytes:
        raise DocumentWorkflowArtifactError("Workflow artifact bytes are invalid")
    return payload


def store_workflow_artifact(
    store: WorkflowArtifactStore,
    *,
    kind: WorkflowArtifactKind,
    value: object,
    source: WorkflowSourceIdentity,
    tenant_scope_identity: str,
    stage_kind: WorkflowStageKind,
    stage_identity: str,
    route_identity: str,
    max_bytes: int,
) -> WorkflowArtifactReference:
    """Store and read back one exact artifact before returning trusted evidence."""
    payload = _canonical_artifact_bytes(
        kind=kind,
        value=value,
        source=source,
        tenant_scope_identity=tenant_scope_identity,
        stage_kind=stage_kind,
        stage_identity=stage_identity,
        route_identity=route_identity,
    )
    if len(payload) > max_bytes:
        raise DocumentWorkflowArtifactError("Workflow artifact exceeds its byte limit")
    payload_sha256 = hashlib.sha256(payload).hexdigest()
    output_identity = workflow_artifact_output_identity(kind, value)
    artifact_id = _artifact_id(
        kind=kind,
        payload_sha256=payload_sha256,
        source=source,
        tenant_scope_identity=tenant_scope_identity,
        stage_identity=stage_identity,
        output_identity=output_identity,
        route_identity=route_identity,
    )
    reference = WorkflowArtifactReference(
        artifact_id=artifact_id,
        kind=kind,
        sha256=payload_sha256,
        byte_count=len(payload),
        source=source,
        tenant_scope_identity=tenant_scope_identity,
        stage_kind=stage_kind,
        stage_identity=stage_identity,
        output_identity=output_identity,
        route_identity=route_identity,
        model_name=_artifact_model_name(kind),
    )
    _store_method(store, "store")
    try:
        store.store(artifact_id, payload)
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception as exc:  # noqa: BLE001 - caller-owned store boundary.
        _raise_redacted_translation(
            exc,
            DocumentWorkflowArtifactError("Workflow artifact could not be stored"),
        )
    if _load_exact_bytes(store, artifact_id) != payload:
        raise DocumentWorkflowArtifactError(
            "Workflow artifact read-back is inconsistent"
        )
    return reference


def _decode_payload(
    *,
    reference: WorkflowArtifactReference,
    payload: bytes,
) -> object:
    result: object
    try:
        envelope = json.loads(payload)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        _raise_redacted_translation(
            exc,
            DocumentWorkflowArtifactError("Workflow artifact JSON is invalid"),
        )
    if type(envelope) is not dict or frozenset(envelope) != _ARTIFACT_KEYS:
        raise DocumentWorkflowArtifactError("Workflow artifact envelope is invalid")
    expected = {
        "artifact_kind": reference.kind.value,
        "model_name": reference.model_name,
        "output_identity": reference.output_identity,
        "route_identity": reference.route_identity,
        "serialization_version": reference.serialization_version,
        "source": reference.source.model_dump(mode="json"),
        "stage_identity": reference.stage_identity,
        "stage_kind": reference.stage_kind.value,
        "tenant_scope_identity": reference.tenant_scope_identity,
    }
    if any(envelope.get(name) != value for name, value in expected.items()):
        raise DocumentWorkflowArtifactError("Workflow artifact binding is inconsistent")
    model_payload = envelope["payload"]
    try:
        canonical_payload = json.dumps(
            model_payload,
            allow_nan=False,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        )
        if reference.kind is WorkflowArtifactKind.DOCUMENT:
            result = Document.model_validate_json(canonical_payload)
        elif reference.kind is WorkflowArtifactKind.STRUCTURED_EXTRACTION:
            result = StructuredExtractionResult.model_validate_json(canonical_payload)
        else:
            result = _NATIVE_RESULT_ADAPTER.validate_json(canonical_payload)
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception as exc:  # noqa: BLE001 - stored model boundary is redacted.
        _raise_redacted_translation(
            exc,
            DocumentWorkflowArtifactError("Workflow artifact model is invalid"),
        )
    if _artifact_source_identity(result) != reference.source:
        raise DocumentWorkflowArtifactError("Workflow artifact source is inconsistent")
    if workflow_artifact_output_identity(reference.kind, result) != (
        reference.output_identity
    ):
        raise DocumentWorkflowArtifactError(
            "Workflow artifact output identity is inconsistent"
        )
    return result


def load_workflow_artifact(
    store: WorkflowArtifactStore,
    reference: WorkflowArtifactReference,
    *,
    expected_kind: WorkflowArtifactKind,
    source: WorkflowSourceIdentity,
    tenant_scope_identity: str,
    stage_kind: WorkflowStageKind,
    stage_identity: str,
    expected_output_identity: str,
    route_identity: str,
    max_bytes: int,
) -> object:
    """Verify every reference and byte binding before returning a trusted model."""
    if type(reference) is not WorkflowArtifactReference:
        raise DocumentWorkflowArtifactError("Workflow artifact reference is invalid")
    reference = _revalidate_model_instance_json(
        reference,
        WorkflowArtifactReference,
        "Workflow artifact reference is invalid",
    )
    if (
        reference.kind is not expected_kind
        or reference.source != source
        or reference.tenant_scope_identity != tenant_scope_identity
        or reference.stage_kind is not stage_kind
        or reference.stage_identity != stage_identity
        or reference.output_identity != expected_output_identity
        or reference.route_identity != route_identity
        or reference.byte_count > max_bytes
    ):
        raise DocumentWorkflowArtifactError(
            "Workflow artifact ownership is inconsistent"
        )
    payload = _load_exact_bytes(store, reference.artifact_id)
    if len(payload) != reference.byte_count:
        raise DocumentWorkflowArtifactError("Workflow artifact byte count is invalid")
    payload_sha256 = hashlib.sha256(payload).hexdigest()
    if payload_sha256 != reference.sha256:
        raise DocumentWorkflowArtifactError("Workflow artifact hash is invalid")
    expected_id = _artifact_id(
        kind=reference.kind,
        payload_sha256=payload_sha256,
        source=reference.source,
        tenant_scope_identity=reference.tenant_scope_identity,
        stage_identity=reference.stage_identity,
        output_identity=reference.output_identity,
        route_identity=reference.route_identity,
    )
    if expected_id != reference.artifact_id:
        raise DocumentWorkflowArtifactError("Workflow artifact ID is invalid")
    return _decode_payload(reference=reference, payload=payload)


__all__ = [
    "WorkflowArtifactStore",
    "load_workflow_artifact",
    "store_workflow_artifact",
    "workflow_artifact_output_identity",
]

"""Sanitized errors for the stage-aware one-file workflow."""

from document_sdk.core import DocumentSdkError

__all__ = [
    "DocumentWorkflowArtifactError",
    "DocumentWorkflowConfigurationError",
    "DocumentWorkflowError",
    "DocumentWorkflowResultValidationError",
    "DocumentWorkflowResumeError",
]


class DocumentWorkflowError(DocumentSdkError):
    """Base class for expected one-file workflow failures."""


class DocumentWorkflowConfigurationError(DocumentWorkflowError):
    """Raised when a workflow request or Provider bundle is inconsistent."""


class DocumentWorkflowArtifactError(DocumentWorkflowError):
    """Raised when a caller-owned artifact cannot be trusted or accessed."""


class DocumentWorkflowResumeError(DocumentWorkflowError):
    """Raised when prior stage evidence cannot be resumed safely."""


class DocumentWorkflowResultValidationError(DocumentWorkflowError):
    """Raised when public workflow evidence is inconsistent."""

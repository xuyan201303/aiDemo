"""Strict public models for the stage-aware one-file workflow."""

# ruff: noqa: C901, D102, EM101, PLR0912, TRY003

from __future__ import annotations

import hashlib
import json
from collections import Counter
from enum import StrEnum
from typing import Annotated, Literal, Self, cast

from pydantic import (
    ConfigDict,
    Field,
    SerializerFunctionWrapHandler,
    field_validator,
    model_serializer,
    model_validator,
)

from document_sdk import __version__
from document_sdk.core import (
    CloudExecutionAttemptEvidence,
    CloudExecutionAttemptStatus,
    CloudExecutionPolicy,
    Document,
    DocxSourceReference,
    ExcelSourceReference,
    FileDescriptor,
    ImageSourceReference,
    LocalOcrQualityDecision,
    LocalOcrQualityReport,
    LocalOcrQualitySummary,
    PdfSourceReference,
    ProcessingWarning,
    ProviderUsage,
    ProviderUsageTotals,
    SourceReference,
    WorksheetData,
)
from document_sdk.core._validation import (
    SanitizedPublicModel,
    _revalidate_model_instance_json,
)
from document_sdk.core.local_ocr_quality import (
    _local_ocr_quality_usage_matches,
    _validate_quality_report,
    _validate_quality_summary,
)
from document_sdk.document import (
    DocumentAnalysisOptions,
    DocumentFormat,
    DocumentType,
    DocxDocumentAnalysis,
    ExcelDocumentAnalysis,
    ImageDocumentAnalysis,
    PdfDocumentAnalysis,
)
from document_sdk.document.models import FORMAT_TYPES
from document_sdk.excel import WorkbookFeatureInventory
from document_sdk.extraction import (
    ExtractionSchema,
    StructuredExtractionOptions,
    StructuredExtractionResult,
)
from document_sdk.pipeline import HybridPdfAnalysisOptions
from document_sdk.workflow.errors import DocumentWorkflowResultValidationError

WORKFLOW_CONTRACT_VERSION: Literal["2"] = "2"
WORKFLOW_MANIFEST_VERSION: Literal["2"] = "2"
WORKFLOW_ARTIFACT_SERIALIZATION_VERSION: Literal["2"] = "2"
WORKFLOW_PDF_PREFLIGHT_MAX_PAGES = 100_000
_LOCAL_OCR_QUALITY_REVIEW_CODE = "local_ocr_quality_requires_review"
_LOCAL_OCR_QUALITY_REVIEW_MESSAGE = "Local OCR quality requires application review"

_StrictModel = ConfigDict(
    extra="forbid",
    frozen=True,
    hide_input_in_errors=True,
    strict=True,
    validate_default=True,
)
_Sha256 = Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]
_NonEmptyString = Annotated[str, Field(min_length=1, max_length=256)]
_SAFE_CODE_PATTERN = r"^[a-z][a-z0-9_]{0,127}$"
_SAFE_INTAKE_MESSAGE_PATTERN = r"^[A-Za-z0-9][A-Za-z0-9 .,'()_-]{0,255}$"
_STAGE_ORDER: tuple[WorkflowStageKind, ...]


class _WorkflowPublicModel(SanitizedPublicModel):
    """Public workflow model with one sanitized validation boundary."""

    model_config = _StrictModel
    _validation_error_type = DocumentWorkflowResultValidationError
    _validation_error_message = "Document workflow model validation failed"


class DocumentWorkflowStatus(StrEnum):
    """Final state of one workflow invocation."""

    SUCCEEDED = "succeeded"
    PARTIAL = "partial"
    FAILED = "failed"
    REVIEW_REQUIRED = "review_required"


class DocumentWorkflowIntakeStatus(StrEnum):
    """Stable outer outcome for one universal one-file intake invocation."""

    SUCCEEDED = "succeeded"
    PARTIAL = "partial"
    REVIEW_REQUIRED = "review_required"
    UNSUPPORTED = "unsupported"
    REJECTED = "rejected"
    FAILED = "failed"


class WorkflowStageKind(StrEnum):
    """Ordered, bounded one-file workflow stages."""

    DETECT = "detect"
    INSPECT = "inspect"
    NATIVE_ANALYSIS = "native_analysis"
    OCR_OR_AZURE = "ocr_or_azure"
    NORMALIZE = "normalize"
    STRUCTURED_EXTRACTION = "structured_extraction"
    FINALIZE = "finalize"


_STAGE_ORDER = (
    WorkflowStageKind.DETECT,
    WorkflowStageKind.INSPECT,
    WorkflowStageKind.NATIVE_ANALYSIS,
    WorkflowStageKind.OCR_OR_AZURE,
    WorkflowStageKind.NORMALIZE,
    WorkflowStageKind.STRUCTURED_EXTRACTION,
    WorkflowStageKind.FINALIZE,
)


class WorkflowStageStatus(StrEnum):
    """Lifecycle state for one planned stage."""

    PLANNED = "planned"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    SKIPPED = "skipped"
    REUSED = "reused"
    REVIEW_REQUIRED = "review_required"


_FinalWorkflowStageStatus = Literal[
    WorkflowStageStatus.SUCCEEDED,
    WorkflowStageStatus.FAILED,
    WorkflowStageStatus.SKIPPED,
    WorkflowStageStatus.REUSED,
    WorkflowStageStatus.REVIEW_REQUIRED,
]
_PROTECTED_CLOUD_ATTEMPT_STATUSES = frozenset(
    {
        CloudExecutionAttemptStatus.SUBMITTED,
        CloudExecutionAttemptStatus.POSSIBLY_PAID,
        CloudExecutionAttemptStatus.COMPLETED,
    }
)


class WorkflowOcrRoute(StrEnum):
    """Explicit OCR selection; no value performs Provider discovery."""

    NONE = "none"
    LOCAL = "local"
    AZURE = "azure"


class WorkflowPdfProcessingMode(StrEnum):
    """Explicit PDF workflow behavior with the v1.3 route kept as default."""

    COMPATIBILITY = "compatibility"
    AZURE_FIRST = "azure_first"


class WorkflowExtractionMode(StrEnum):
    """Optional extraction stage performed after Document normalization."""

    NONE = "none"
    DETERMINISTIC = "deterministic"


class WorkflowRoute(StrEnum):
    """Content-safe route selected from source facts and explicit request policy."""

    EXCEL_LOCAL = "excel_local"
    PDF_NATIVE = "pdf_native"
    PDF_HYBRID_LOCAL = "pdf_hybrid_local"
    PDF_HYBRID_AZURE = "pdf_hybrid_azure"
    PDF_AZURE_FIRST = "pdf_azure_first"
    IMAGE_INSPECTION = "image_inspection"
    IMAGE_LOCAL_OCR = "image_local_ocr"
    IMAGE_AZURE = "image_azure"
    DOCX_LOCAL = "docx_local"


class WorkflowOcrScope(StrEnum):
    """Observed OCR-candidate coverage without asserting physical page type."""

    NOT_APPLICABLE = "not_applicable"
    NONE = "none"
    SOME = "some"
    ALL = "all"
    WHOLE_DOCUMENT = "whole_document"


class WorkflowProviderCategory(StrEnum):
    """Provider category required by a planned stage."""

    LOCAL_OCR = "local_ocr"
    AZURE_DOCUMENT_INTELLIGENCE = "azure_document_intelligence"


class ExcelWorkflowOutputMode(StrEnum):
    """Bounded Excel detail included in the workflow's native result."""

    INSPECTION = "inspection"
    BOUNDED_RANGES = "bounded_ranges"
    FULL_IF_WITHIN_LIMIT = "full_if_within_limit"
    FORMAT_NATIVE_ONLY = "format_native_only"


class WorkflowArtifactKind(StrEnum):
    """Content-bearing model stored behind an opaque caller-owned key."""

    DOCUMENT = "document"
    NATIVE_RESULT = "native_result"
    STRUCTURED_EXTRACTION = "structured_extraction"


class WorkflowIssueCategory(StrEnum):
    """Bounded, content-safe failure and warning categories."""

    ARTIFACT = "artifact"
    CONFIGURATION = "configuration"
    LIMIT = "limit"
    PROCESSING = "processing"
    PROVIDER = "provider"
    RESUME = "resume"
    SOURCE = "source"
    UNSUPPORTED = "unsupported"
    VALIDATION = "validation"


def _canonical_fingerprint(domain: bytes, value: object) -> str:
    payload = json.dumps(
        value,
        allow_nan=False,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode()
    return hashlib.sha256(domain + b"\0" + payload).hexdigest()


def _exact_revalidate[ModelT: SanitizedPublicModel](
    value: object,
    expected_type: type[ModelT],
    message: str,
) -> ModelT:
    if type(value) is not expected_type:
        raise ValueError(message)
    return _revalidate_model_instance_json(value, expected_type, message)


def _safe_public_text(value: str) -> str:
    if (
        "\n" in value
        or "\r" in value
        or "\\" in value
        or "://" in value
        or value.startswith("/")
    ):
        raise ValueError("workflow public text contains unsafe evidence")
    return value


class WorkflowSourceIdentity(_WorkflowPublicModel):
    """Path-free identity for exact bytes and their safe file descriptor."""

    sha256: _Sha256
    byte_size: Annotated[int, Field(ge=0, le=2_000_000_000)]
    file_descriptor_identity: _Sha256


def workflow_source_identity_from_descriptor(
    value: FileDescriptor,
) -> WorkflowSourceIdentity:
    """Fingerprint every safe, result-affecting FileDescriptor field."""
    if type(value) is not FileDescriptor:
        raise ValueError("Workflow source descriptor is invalid")
    descriptor = _revalidate_model_instance_json(
        value,
        FileDescriptor,
        "Workflow source descriptor is invalid",
    )
    return WorkflowSourceIdentity(
        sha256=descriptor.fingerprint.value,
        byte_size=descriptor.size_bytes,
        file_descriptor_identity=_canonical_fingerprint(
            b"document-sdk:workflow:source-file-descriptor:v1",
            descriptor.model_dump(mode="json"),
        ),
    )


def _provider_usage_sequence(value: object) -> object:
    if type(value) not in {list, tuple}:
        return value
    sequence = cast("list[object] | tuple[object, ...]", value)
    return tuple(
        item
        if type(item) is ProviderUsage
        else ProviderUsage.model_validate_json(
            json.dumps(
                item,
                allow_nan=False,
                ensure_ascii=False,
                separators=(",", ":"),
                sort_keys=True,
            )
        )
        if type(item) is dict
        else item
        for item in sequence
    )


def _cloud_attempt_sequence(value: object) -> object:
    if type(value) not in {list, tuple}:
        return value
    sequence = cast("list[object] | tuple[object, ...]", value)
    return tuple(
        item
        if type(item) is CloudExecutionAttemptEvidence
        else CloudExecutionAttemptEvidence.model_validate_json(
            json.dumps(
                item,
                allow_nan=False,
                ensure_ascii=False,
                separators=(",", ":"),
                sort_keys=True,
            )
        )
        if type(item) is dict
        else item
        for item in sequence
    )


class WorkflowExcelRangeSelection(_WorkflowPublicModel):
    """One caller-bounded Excel range requested for native output."""

    sheet_name: Annotated[str, Field(min_length=1, max_length=31)]
    cell_range: Annotated[str, Field(min_length=1, max_length=64)]


class DocumentWorkflowPolicy(_WorkflowPublicModel):
    """Explicit local recompute and independent cloud authorization policies."""

    azure_execution_policy: CloudExecutionPolicy = Field(
        default_factory=CloudExecutionPolicy
    )
    allow_local_recompute: bool = True

    @model_validator(mode="after")
    def validate_policies(self) -> Self:
        policy = _revalidate_model_instance_json(
            self.azure_execution_policy,
            CloudExecutionPolicy,
            "Workflow cloud policy is invalid",
        )
        object.__setattr__(self, "azure_execution_policy", policy)
        return self


class DocumentWorkflowOutputPolicy(_WorkflowPublicModel):
    """Bound content-bearing result fields and intermediate artifact bytes."""

    include_native_result: bool = True
    include_top_level_document: bool = True
    include_structured_extraction: bool = True
    persist_intermediate_artifacts: bool = False
    max_artifact_bytes: Annotated[
        int,
        Field(ge=1, le=500_000_000),
    ] = 64 * 1024 * 1024
    excel_mode: ExcelWorkflowOutputMode = ExcelWorkflowOutputMode.INSPECTION
    excel_ranges: tuple[WorkflowExcelRangeSelection, ...] = ()
    max_excel_cells: Annotated[int, Field(ge=1, le=1_000_000)] = 100_000
    include_excel_feature_inventory: bool = False

    @field_validator("excel_ranges", mode="before")
    @classmethod
    def accept_json_ranges(cls, value: object) -> object:
        return tuple(value) if isinstance(value, list) else value

    @model_validator(mode="after")
    def validate_excel_bounds(self) -> Self:
        ranges = tuple(
            _exact_revalidate(
                item,
                WorkflowExcelRangeSelection,
                "Workflow Excel range selection is invalid",
            )
            for item in self.excel_ranges
        )
        object.__setattr__(self, "excel_ranges", ranges)
        keys = tuple(
            (item.sheet_name.casefold(), item.cell_range.casefold()) for item in ranges
        )
        if len(keys) != len(set(keys)):
            raise ValueError("Workflow Excel ranges must be unique")
        if self.excel_mode is ExcelWorkflowOutputMode.BOUNDED_RANGES:
            if not ranges:
                raise ValueError("Bounded Excel output requires explicit ranges")
        elif ranges:
            raise ValueError("Excel ranges require bounded-range output mode")
        return self


class DocumentWorkflowRequest(_WorkflowPublicModel):
    """Content-bearing request for one explicit stage-aware workflow."""

    tenant_scope_identity: _Sha256
    analysis_options: DocumentAnalysisOptions = Field(
        default_factory=DocumentAnalysisOptions
    )
    hybrid_pdf_options: HybridPdfAnalysisOptions | None = None
    pdf_processing_mode: WorkflowPdfProcessingMode = (
        WorkflowPdfProcessingMode.COMPATIBILITY
    )
    ocr_route: WorkflowOcrRoute = WorkflowOcrRoute.NONE
    extraction_mode: WorkflowExtractionMode = WorkflowExtractionMode.NONE
    extraction_schema: ExtractionSchema | None = None
    structured_extraction_options: StructuredExtractionOptions | None = None
    policy: DocumentWorkflowPolicy = Field(default_factory=DocumentWorkflowPolicy)
    output_policy: DocumentWorkflowOutputPolicy = Field(
        default_factory=DocumentWorkflowOutputPolicy
    )

    @model_validator(mode="after")
    def validate_request(self) -> Self:
        analysis_options = _revalidate_model_instance_json(
            self.analysis_options,
            DocumentAnalysisOptions,
            "Workflow analysis options are invalid",
        )
        if (
            analysis_options.structured_extraction_options is not None
            or analysis_options.azure_fallback_policy is not None
            or analysis_options.pdf_mode.value != "native"
            or analysis_options.hybrid_pdf_options is not None
        ):
            raise ValueError(
                "Workflow owns extraction and cloud routing options explicitly"
            )
        object.__setattr__(self, "analysis_options", analysis_options)
        if self.hybrid_pdf_options is not None:
            object.__setattr__(
                self,
                "hybrid_pdf_options",
                _revalidate_model_instance_json(
                    self.hybrid_pdf_options,
                    HybridPdfAnalysisOptions,
                    "Workflow Hybrid PDF options are invalid",
                ),
            )
        if self.pdf_processing_mode is WorkflowPdfProcessingMode.AZURE_FIRST and (
            self.ocr_route is not WorkflowOcrRoute.NONE
            or self.hybrid_pdf_options is not None
        ):
            raise ValueError(
                "Azure-first PDF processing cannot use compatibility OCR routing"
            )
        schema = self.extraction_schema
        if schema is not None:
            schema = _revalidate_model_instance_json(
                schema,
                ExtractionSchema,
                "Workflow extraction schema is invalid",
            )
            object.__setattr__(self, "extraction_schema", schema)
        structured = self.structured_extraction_options
        if structured is not None:
            structured = _revalidate_model_instance_json(
                structured,
                StructuredExtractionOptions,
                "Workflow deterministic extraction options are invalid",
            )
            object.__setattr__(self, "structured_extraction_options", structured)
        if self.extraction_mode is WorkflowExtractionMode.NONE:
            if schema is not None or structured is not None:
                raise ValueError("Extraction inputs require an extraction mode")
        elif schema is None:
            raise ValueError("Deterministic extraction request is inconsistent")
        return self

    def fingerprint(self) -> str:
        """Hash the complete request without exposing its content."""
        return _canonical_fingerprint(
            b"document-sdk:workflow-request:v1",
            self.model_dump(mode="json"),
        )


class WorkflowProviderRequirement(_WorkflowPublicModel):
    """Content-free declaration of one explicit runtime dependency."""

    category: WorkflowProviderCategory
    stage_kind: WorkflowStageKind
    required: Literal[True] = True


class WorkflowProviderIdentity(_WorkflowPublicModel):
    """Irreversible runtime Provider identity bound before credential access."""

    category: WorkflowProviderCategory
    fingerprint: _Sha256


class WorkflowLimitation(_WorkflowPublicModel):
    """Stable content-safe limitation evidence."""

    code: str = Field(pattern=_SAFE_CODE_PATTERN)
    message: _NonEmptyString

    @field_validator("message")
    @classmethod
    def validate_safe_message(cls, value: str) -> str:
        return _safe_public_text(value)


class WorkflowStageIssue(_WorkflowPublicModel):
    """Sanitized issue for one exact workflow stage."""

    code: str = Field(pattern=_SAFE_CODE_PATTERN)
    category: WorkflowIssueCategory
    message: _NonEmptyString
    retryable: bool
    count: Annotated[int | None, Field(ge=1)] = None
    stage_kind: WorkflowStageKind
    provider_category: WorkflowProviderCategory | None = None
    source: SourceReference | None = None

    @field_validator("source", mode="before")
    @classmethod
    def accept_source_json(cls, value: object) -> object:
        if type(value) is not dict:
            return value
        source_type = cast("dict[object, object]", value).get("source_type")
        if type(source_type) is not str:
            return value
        payload = json.dumps(
            value,
            allow_nan=False,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        )
        if source_type == "pdf":
            source: SourceReference = PdfSourceReference.model_validate_json(payload)
        elif source_type == "image":
            source = ImageSourceReference.model_validate_json(payload)
        elif source_type == "excel":
            source = ExcelSourceReference.model_validate_json(payload)
        elif source_type == "docx":
            source = DocxSourceReference.model_validate_json(payload)
        else:
            return value
        return source

    @field_validator("message")
    @classmethod
    def validate_safe_message(cls, value: str) -> str:
        return _safe_public_text(value)


class WorkflowStagePlan(_WorkflowPublicModel):
    """One content-free planned stage."""

    kind: WorkflowStageKind
    status: Literal[WorkflowStageStatus.PLANNED, WorkflowStageStatus.SKIPPED]
    stage_identity: _Sha256
    provider_category: WorkflowProviderCategory | None = None
    cloud_authorization_required: bool = False
    artifact_outputs: tuple[WorkflowArtifactKind, ...] = ()
    reason_code: str | None = Field(default=None, pattern=_SAFE_CODE_PATTERN)

    @field_validator("artifact_outputs", mode="before")
    @classmethod
    def accept_json_artifact_outputs(cls, value: object) -> object:
        return tuple(value) if isinstance(value, list) else value

    @model_validator(mode="after")
    def validate_stage_plan(self) -> Self:
        if len(self.artifact_outputs) != len(set(self.artifact_outputs)):
            raise ValueError("Workflow stage artifacts must be unique")
        if self.status is WorkflowStageStatus.SKIPPED:
            if self.provider_category is not None or self.cloud_authorization_required:
                raise ValueError("Skipped workflow stage cannot require a Provider")
            if self.reason_code is None:
                raise ValueError("Skipped workflow stage requires a reason")
        elif self.reason_code is not None:
            raise ValueError("Planned workflow stage cannot contain a skip reason")
        if (
            self.cloud_authorization_required
            and self.provider_category
            is not WorkflowProviderCategory.AZURE_DOCUMENT_INTELLIGENCE
        ):
            raise ValueError("Cloud authorization requires a cloud Provider")
        return self


class WorkflowPdfPreflight(_WorkflowPublicModel):
    """Content-free structural facts for one Azure-first PDF plan."""

    page_count: Annotated[int, Field(ge=1, le=WORKFLOW_PDF_PREFLIGHT_MAX_PAGES)]
    max_pages: Annotated[int, Field(ge=1, le=WORKFLOW_PDF_PREFLIGHT_MAX_PAGES)]
    max_input_bytes: Annotated[int, Field(ge=1, le=2_000_000_000)]
    original_whole_document: Literal[True] = True
    native_text_extracted: Literal[False] = False

    @model_validator(mode="after")
    def validate_page_limit(self) -> Self:
        if self.page_count > self.max_pages:
            raise ValueError("Workflow PDF page count exceeds its planned limit")
        return self


class DocumentWorkflowPlan(_WorkflowPublicModel):
    """Provider-free, content-safe plan built before credential resolution."""

    contract_version: Literal["2"] = WORKFLOW_CONTRACT_VERSION
    source: WorkflowSourceIdentity
    document_type: DocumentType
    document_format: DocumentFormat
    route: WorkflowRoute
    pdf_processing_mode: WorkflowPdfProcessingMode = (
        WorkflowPdfProcessingMode.COMPATIBILITY
    )
    pdf_preflight: WorkflowPdfPreflight | None = None
    ocr_scope: WorkflowOcrScope
    ocr_requested: bool
    azure_permitted: bool
    azure_required: bool
    extraction_mode: WorkflowExtractionMode
    request_identity: _Sha256
    plan_identity: _Sha256
    workflow_identity: _Sha256
    provider_requirements: tuple[WorkflowProviderRequirement, ...] = ()
    provider_identities: tuple[WorkflowProviderIdentity, ...] = ()
    required_artifacts: tuple[WorkflowArtifactKind, ...] = ()
    stages: tuple[WorkflowStagePlan, ...]
    supported: bool = True
    limitations: tuple[WorkflowLimitation, ...] = ()

    @field_validator(
        "provider_requirements",
        "provider_identities",
        "required_artifacts",
        "stages",
        "limitations",
        mode="before",
    )
    @classmethod
    def accept_json_arrays(cls, value: object) -> object:
        return tuple(value) if isinstance(value, list) else value

    @model_validator(mode="after")
    def validate_plan(self) -> Self:
        object.__setattr__(
            self,
            "source",
            _exact_revalidate(
                self.source,
                WorkflowSourceIdentity,
                "Workflow plan source identity is invalid",
            ),
        )
        if tuple(stage.kind for stage in self.stages) != _STAGE_ORDER:
            raise ValueError("Workflow plan stages must use canonical order")
        if len(self.required_artifacts) != len(set(self.required_artifacts)):
            raise ValueError("Workflow required artifacts must be unique")
        requirements = tuple(
            (item.category, item.stage_kind) for item in self.provider_requirements
        )
        if len(requirements) != len(set(requirements)):
            raise ValueError("Workflow Provider requirements must be unique")
        identity_categories = tuple(item.category for item in self.provider_identities)
        if identity_categories != tuple(sorted(set(identity_categories))):
            raise ValueError("Workflow Provider identities must be ordered and unique")
        if not set(identity_categories).issubset(
            {item.category for item in self.provider_requirements}
        ):
            raise ValueError("Workflow Provider identity was not required")
        if self.ocr_requested != (
            self.route
            in {
                WorkflowRoute.PDF_HYBRID_LOCAL,
                WorkflowRoute.PDF_HYBRID_AZURE,
                WorkflowRoute.PDF_AZURE_FIRST,
                WorkflowRoute.IMAGE_LOCAL_OCR,
                WorkflowRoute.IMAGE_AZURE,
            }
        ):
            raise ValueError("Workflow OCR route evidence is inconsistent")
        if self.azure_required != (
            self.route
            in {
                WorkflowRoute.PDF_HYBRID_AZURE,
                WorkflowRoute.PDF_AZURE_FIRST,
                WorkflowRoute.IMAGE_AZURE,
            }
            and not (
                self.route is WorkflowRoute.PDF_HYBRID_AZURE
                and self.ocr_scope is WorkflowOcrScope.NONE
            )
        ):
            raise ValueError("Workflow Azure route evidence is inconsistent")
        if self.route is WorkflowRoute.PDF_AZURE_FIRST:
            if (
                self.pdf_processing_mode is not WorkflowPdfProcessingMode.AZURE_FIRST
                or self.ocr_scope is not WorkflowOcrScope.WHOLE_DOCUMENT
                or type(self.pdf_preflight) is not WorkflowPdfPreflight
            ):
                raise ValueError("Azure-first PDF plan evidence is inconsistent")
            validated_preflight = _exact_revalidate(
                self.pdf_preflight,
                WorkflowPdfPreflight,
                "Workflow PDF preflight evidence is invalid",
            )
            object.__setattr__(self, "pdf_preflight", validated_preflight)
            if self.source.byte_size > validated_preflight.max_input_bytes:
                raise ValueError("Workflow source exceeds its PDF preflight byte limit")
        elif self.pdf_preflight is not None or (
            self.pdf_processing_mode is WorkflowPdfProcessingMode.AZURE_FIRST
            and self.supported
        ):
            raise ValueError("Compatibility workflow plan contains PDF mode evidence")
        ocr_stage = self.stages[_STAGE_ORDER.index(WorkflowStageKind.OCR_OR_AZURE)]
        ocr_is_noop = (
            self.route
            in {WorkflowRoute.PDF_HYBRID_LOCAL, WorkflowRoute.PDF_HYBRID_AZURE}
            and self.ocr_scope is WorkflowOcrScope.NONE
        )
        if ocr_is_noop and (
            ocr_stage.status is not WorkflowStageStatus.SKIPPED
            or ocr_stage.reason_code != "ocr_no_candidates"
            or any(
                stage_kind is WorkflowStageKind.OCR_OR_AZURE
                for _category, stage_kind in requirements
            )
            or any(
                category
                in {
                    WorkflowProviderCategory.LOCAL_OCR,
                    WorkflowProviderCategory.AZURE_DOCUMENT_INTELLIGENCE,
                }
                for category in identity_categories
            )
        ):
            raise ValueError("No-op PDF OCR plan evidence is inconsistent")
        if not self.supported and not self.limitations:
            raise ValueError("Unsupported workflow plan requires a limitation")
        return self


class WorkflowArtifactReference(_WorkflowPublicModel):
    """Content-free reference to one caller-owned serialized model artifact."""

    artifact_id: Annotated[str, Field(pattern=r"^wf-artifact-v1-[0-9a-f]{64}$")]
    kind: WorkflowArtifactKind
    media_type: Literal["application/vnd.document-sdk.workflow+json"] = (
        "application/vnd.document-sdk.workflow+json"
    )
    serialization_version: Literal["2"] = WORKFLOW_ARTIFACT_SERIALIZATION_VERSION
    sha256: _Sha256
    byte_count: Annotated[int, Field(ge=1, le=500_000_000)]
    source: WorkflowSourceIdentity
    tenant_scope_identity: _Sha256
    stage_kind: WorkflowStageKind
    stage_identity: _Sha256
    output_identity: _Sha256
    route_identity: _Sha256
    model_name: Literal[
        "Document",
        "WorkflowNativeResult",
        "StructuredExtractionResult",
    ]

    @model_validator(mode="after")
    def validate_source(self) -> Self:
        object.__setattr__(
            self,
            "source",
            _exact_revalidate(
                self.source,
                WorkflowSourceIdentity,
                "Workflow artifact source identity is invalid",
            ),
        )
        expected_stage = {
            WorkflowArtifactKind.NATIVE_RESULT: WorkflowStageKind.NATIVE_ANALYSIS,
            WorkflowArtifactKind.DOCUMENT: WorkflowStageKind.NORMALIZE,
            WorkflowArtifactKind.STRUCTURED_EXTRACTION: (
                WorkflowStageKind.STRUCTURED_EXTRACTION
            ),
        }[self.kind]
        expected_model = {
            WorkflowArtifactKind.NATIVE_RESULT: "WorkflowNativeResult",
            WorkflowArtifactKind.DOCUMENT: "Document",
            WorkflowArtifactKind.STRUCTURED_EXTRACTION: ("StructuredExtractionResult"),
        }[self.kind]
        if self.stage_kind is not expected_stage or self.model_name != expected_model:
            raise ValueError("Workflow artifact kind binding is inconsistent")
        return self


class WorkflowExcelRangeData(_WorkflowPublicModel):
    """One exact requested Excel range and its existing native SDK result."""

    selection: WorkflowExcelRangeSelection
    data: WorksheetData

    @model_validator(mode="after")
    def validate_range_data(self) -> Self:
        selection = _exact_revalidate(
            self.selection,
            WorkflowExcelRangeSelection,
            "Workflow Excel range selection is invalid",
        )
        data = _revalidate_model_instance_json(
            self.data,
            WorksheetData,
            "Workflow Excel range data is invalid",
        )
        object.__setattr__(self, "selection", selection)
        object.__setattr__(self, "data", data)
        if data.sheet_name != selection.sheet_name:
            raise ValueError("Workflow Excel range sheet is inconsistent")
        return self


class WorkflowPdfNativeResult(_WorkflowPublicModel):
    """Exact existing PDF analysis at the workflow native boundary."""

    kind: Literal["pdf"] = "pdf"
    analysis: PdfDocumentAnalysis

    @model_validator(mode="after")
    def validate_analysis(self) -> Self:
        object.__setattr__(
            self,
            "analysis",
            _exact_revalidate(
                self.analysis,
                PdfDocumentAnalysis,
                "Workflow PDF native result is invalid",
            ),
        )
        return self


class WorkflowExcelNativeResult(_WorkflowPublicModel):
    """Existing Excel inspection plus explicitly bounded existing native details."""

    kind: Literal["excel"] = "excel"
    analysis: ExcelDocumentAnalysis
    ranges: tuple[WorkflowExcelRangeData, ...] = ()
    feature_inventory: WorkbookFeatureInventory | None = None
    detail_complete: bool = False

    @field_validator("ranges", mode="before")
    @classmethod
    def accept_json_ranges(cls, value: object) -> object:
        return tuple(value) if isinstance(value, list) else value

    @model_validator(mode="after")
    def validate_analysis(self) -> Self:
        analysis = _exact_revalidate(
            self.analysis,
            ExcelDocumentAnalysis,
            "Workflow Excel native result is invalid",
        )
        ranges = tuple(
            _exact_revalidate(
                item,
                WorkflowExcelRangeData,
                "Workflow Excel range data is invalid",
            )
            for item in self.ranges
        )
        inventory = self.feature_inventory
        if inventory is not None:
            inventory = _revalidate_model_instance_json(
                inventory,
                WorkbookFeatureInventory,
                "Workflow Excel feature inventory is invalid",
            )
            if inventory.file != analysis.workbook.file:
                raise ValueError("Workflow Excel inventory source is inconsistent")
        if any(item.data.file != analysis.workbook.file for item in ranges):
            raise ValueError("Workflow Excel range source is inconsistent")
        object.__setattr__(self, "analysis", analysis)
        object.__setattr__(self, "ranges", ranges)
        object.__setattr__(self, "feature_inventory", inventory)
        return self


class WorkflowImageNativeResult(_WorkflowPublicModel):
    """Exact existing image/TIFF analysis at the workflow native boundary."""

    kind: Literal["image"] = "image"
    analysis: ImageDocumentAnalysis

    @model_validator(mode="after")
    def validate_analysis(self) -> Self:
        object.__setattr__(
            self,
            "analysis",
            _exact_revalidate(
                self.analysis,
                ImageDocumentAnalysis,
                "Workflow image native result is invalid",
            ),
        )
        return self


class WorkflowDocxNativeResult(_WorkflowPublicModel):
    """Exact existing DOCX analysis at the workflow native boundary."""

    kind: Literal["word"] = "word"
    analysis: DocxDocumentAnalysis

    @model_validator(mode="after")
    def validate_analysis(self) -> Self:
        object.__setattr__(
            self,
            "analysis",
            _exact_revalidate(
                self.analysis,
                DocxDocumentAnalysis,
                "Workflow DOCX native result is invalid",
            ),
        )
        return self


WorkflowNativeResult = Annotated[
    WorkflowPdfNativeResult
    | WorkflowExcelNativeResult
    | WorkflowImageNativeResult
    | WorkflowDocxNativeResult,
    Field(discriminator="kind"),
]


def _native_file_descriptor(value: WorkflowNativeResult) -> FileDescriptor:
    if type(value) is WorkflowPdfNativeResult:
        return value.analysis.document.file
    if type(value) is WorkflowExcelNativeResult:
        return value.analysis.workbook.file
    if type(value) is WorkflowImageNativeResult:
        return value.analysis.image.file
    if type(value) is WorkflowDocxNativeResult:
        return value.analysis.docx.inspection.file
    raise ValueError("Workflow native result type is invalid")


def _native_document(value: WorkflowNativeResult) -> Document | None:
    if type(value) is WorkflowPdfNativeResult:
        return value.analysis.document
    if type(value) is WorkflowImageNativeResult:
        result = value.analysis.ocr_result
        return None if result is None else result.data
    if type(value) is WorkflowDocxNativeResult:
        return value.analysis.docx.document
    if type(value) is WorkflowExcelNativeResult:
        return None
    raise ValueError("Workflow native result type is invalid")


def _native_local_ocr_quality_report(
    value: WorkflowNativeResult,
) -> LocalOcrQualityReport | None:
    """Return the trusted final Local OCR report embedded by native analysis."""
    report: LocalOcrQualityReport | None = None
    if type(value) is WorkflowPdfNativeResult:
        processing = value.analysis.processing_result
        if processing is not None:
            report = processing.metadata.local_ocr_quality_report
    elif type(value) is WorkflowImageNativeResult:
        processing = value.analysis.ocr_result
        if processing is not None:
            report = processing.metadata.local_ocr_quality_report
    if report is None:
        return None
    return _validate_quality_report(report)


def _local_ocr_quality_review_issues(
    stage: WorkflowStageResult,
) -> tuple[WorkflowStageIssue, ...]:
    return tuple(
        issue for issue in stage.issues if issue.code == _LOCAL_OCR_QUALITY_REVIEW_CODE
    )


def _is_exact_local_ocr_quality_review_issue(
    issue: WorkflowStageIssue,
    stage: WorkflowStageResult,
) -> bool:
    return (
        issue.code == _LOCAL_OCR_QUALITY_REVIEW_CODE
        and issue.category is WorkflowIssueCategory.VALIDATION
        and issue.message == _LOCAL_OCR_QUALITY_REVIEW_MESSAGE
        and not issue.retryable
        and issue.count is None
        and issue.source is None
        and issue.stage_kind is stage.kind
        and issue.provider_category is stage.provider_category
    )


class WorkflowStageResult(_WorkflowPublicModel):
    """Content-free lifecycle and operation evidence for one stage."""

    kind: WorkflowStageKind
    status: _FinalWorkflowStageStatus
    input_identity: _Sha256
    stage_identity: _Sha256
    output_identity: _Sha256 | None = None
    provider_category: WorkflowProviderCategory | None = None
    provider_identity: _Sha256 | None = None
    current_provider_usage: tuple[ProviderUsage, ...] = ()
    retained_provider_usage: tuple[ProviderUsage, ...] = ()
    current_cloud_attempts: tuple[CloudExecutionAttemptEvidence, ...] = ()
    retained_cloud_attempts: tuple[CloudExecutionAttemptEvidence, ...] = ()
    artifact_references: tuple[WorkflowArtifactReference, ...] = ()
    issues: tuple[WorkflowStageIssue, ...] = ()
    retry_eligible: bool = False
    reuse_eligible: bool = False

    @field_validator(
        "current_provider_usage",
        "retained_provider_usage",
        mode="before",
    )
    @classmethod
    def accept_provider_usage_json(cls, value: object) -> object:
        return _provider_usage_sequence(value)

    @field_validator(
        "current_cloud_attempts",
        "retained_cloud_attempts",
        mode="before",
    )
    @classmethod
    def accept_cloud_attempt_json(cls, value: object) -> object:
        return _cloud_attempt_sequence(value)

    @field_validator(
        "artifact_references",
        "issues",
        mode="before",
    )
    @classmethod
    def accept_json_arrays(cls, value: object) -> object:
        return tuple(value) if isinstance(value, list) else value

    @model_validator(mode="after")
    def validate_stage(self) -> Self:
        for field_name in ("current_provider_usage", "retained_provider_usage"):
            object.__setattr__(
                self,
                field_name,
                tuple(
                    _revalidate_model_instance_json(
                        item,
                        ProviderUsage,
                        "Workflow Provider usage is invalid",
                    )
                    for item in getattr(self, field_name)
                ),
            )
        for field_name in ("current_cloud_attempts", "retained_cloud_attempts"):
            object.__setattr__(
                self,
                field_name,
                tuple(
                    _revalidate_model_instance_json(
                        item,
                        CloudExecutionAttemptEvidence,
                        "Workflow cloud attempt is invalid",
                    )
                    for item in getattr(self, field_name)
                ),
            )
        references = tuple(
            _exact_revalidate(
                item,
                WorkflowArtifactReference,
                "Workflow artifact reference is invalid",
            )
            for item in self.artifact_references
        )
        issues = tuple(
            _exact_revalidate(
                item,
                WorkflowStageIssue,
                "Workflow stage issue is invalid",
            )
            for item in self.issues
        )
        object.__setattr__(self, "artifact_references", references)
        object.__setattr__(self, "issues", issues)
        if any(
            item.stage_kind is not self.kind
            or item.stage_identity != self.stage_identity
            or item.output_identity != self.output_identity
            for item in references
        ):
            raise ValueError("Workflow artifact stage output binding is inconsistent")
        if any(
            item.stage_kind is not self.kind
            or item.provider_category is not self.provider_category
            for item in issues
        ):
            raise ValueError("Workflow issue stage binding is inconsistent")
        if (
            self.status
            in {
                WorkflowStageStatus.SUCCEEDED,
                WorkflowStageStatus.REUSED,
            }
            and self.output_identity is None
        ):
            raise ValueError("Successful workflow stage requires output identity")
        if self.status is WorkflowStageStatus.SKIPPED and any(
            (
                self.output_identity is not None,
                self.provider_category is not None,
                self.provider_identity is not None,
                self.current_provider_usage,
                self.retained_provider_usage,
                self.current_cloud_attempts,
                self.retained_cloud_attempts,
                references,
                issues,
                self.retry_eligible,
                self.reuse_eligible,
            )
        ):
            raise ValueError("Skipped workflow stage contains operation evidence")
        if self.status is WorkflowStageStatus.REUSED and not self.reuse_eligible:
            raise ValueError("Reused workflow stage requires reusable evidence")
        if self.provider_category is None and (
            self.provider_identity is not None
            or self.current_provider_usage
            or self.retained_provider_usage
            or self.current_cloud_attempts
            or self.retained_cloud_attempts
        ):
            raise ValueError("Workflow Provider evidence requires a Provider category")
        _validate_workflow_stage_cloud_evidence(self)
        return self


def _cloud_usage_pair_key(usage: ProviderUsage) -> tuple[object, ...]:
    """Project the v1.1/v1.2 fields binding Usage to one cloud attempt."""
    return (
        usage.provider_name,
        usage.profile_id,
        usage.model_id,
        usage.api_version,
        usage.provider_resource_identity,
        usage.submitted_pages,
        usage.submitted_frames,
        usage.cloud_logical_operation_count,
        usage.cloud_submitted_operation_count,
        usage.cloud_paid_or_possibly_paid_operation_count,
        usage.cloud_transport_retry_count,
    )


def _cloud_attempt_pair_key(
    attempt: CloudExecutionAttemptEvidence,
) -> tuple[object, ...]:
    """Project the matching content-safe cloud-attempt fields."""
    return (
        attempt.provider_name,
        attempt.profile_id,
        attempt.model_id,
        attempt.api_version,
        attempt.provider_resource_identity,
        attempt.submitted_pages,
        attempt.submitted_frames,
        attempt.logical_operation_count,
        attempt.submitted_operation_count,
        attempt.paid_or_possibly_paid_operation_count,
        attempt.transport_retry_count,
    )


def _usage_requires_cloud_attempt(usage: ProviderUsage) -> bool:
    return bool(
        usage.provider_resource_identity
        or usage.azure_operation_count
        or usage.paid_operation_count
        or usage.cloud_logical_operation_count
        or usage.cloud_submitted_operation_count
        or usage.cloud_paid_or_possibly_paid_operation_count
        or usage.cloud_transport_retry_count
    )


def _validate_cloud_evidence_partition(
    usages: tuple[ProviderUsage, ...],
    attempts: tuple[CloudExecutionAttemptEvidence, ...],
) -> None:
    """Require occurrence-aware completed Usage/Attempt pairs."""
    cloud_usages = tuple(item for item in usages if _usage_requires_cloud_attempt(item))
    completed_attempts = tuple(
        item
        for item in attempts
        if item.status is CloudExecutionAttemptStatus.COMPLETED
    )
    usage_counts = Counter(_cloud_usage_pair_key(item) for item in cloud_usages)
    attempt_counts = Counter(
        _cloud_attempt_pair_key(item) for item in completed_attempts
    )
    if usage_counts != attempt_counts:
        raise ValueError("Workflow cloud Usage and Attempt evidence is inconsistent")

    attempts_by_key: dict[tuple[object, ...], list[CloudExecutionAttemptEvidence]] = {}
    for attempt in completed_attempts:
        attempts_by_key.setdefault(_cloud_attempt_pair_key(attempt), []).append(attempt)
    for usage in cloud_usages:
        key = _cloud_usage_pair_key(usage)
        attempt = attempts_by_key[key].pop()
        try:
            from document_sdk.ocr._azure_execution import (  # noqa: PLC0415
                _validated_completed_cloud_result,
            )

            _validated_completed_cloud_result(usage, attempt)
        except Exception as exc:  # noqa: BLE001 - sanitized workflow boundary.
            del exc
            raise ValueError(
                "Workflow cloud Usage and Attempt evidence is inconsistent"
            ) from None


def _validate_workflow_stage_cloud_evidence(stage: WorkflowStageResult) -> None:
    """Bind all current/retained cloud evidence to its exact Workflow stage."""
    current_usage = stage.current_provider_usage
    retained_usage = stage.retained_provider_usage
    current_attempts = stage.current_cloud_attempts
    retained_attempts = stage.retained_cloud_attempts
    _validate_cloud_evidence_partition(current_usage, current_attempts)
    _validate_cloud_evidence_partition(retained_usage, retained_attempts)

    all_usage = retained_usage + current_usage
    all_attempts = retained_attempts + current_attempts
    cloud_usage = tuple(
        item for item in all_usage if _usage_requires_cloud_attempt(item)
    )
    category = stage.provider_category
    if category is WorkflowProviderCategory.LOCAL_OCR:
        if cloud_usage or all_attempts:
            raise ValueError("Workflow Local OCR stage contains cloud evidence")
    elif (
        category is WorkflowProviderCategory.AZURE_DOCUMENT_INTELLIGENCE
        and stage.kind is not WorkflowStageKind.OCR_OR_AZURE
    ):
        raise ValueError("Workflow Azure evidence stage binding is inconsistent")

    if stage.status is WorkflowStageStatus.REUSED and (
        current_usage or current_attempts
    ):
        raise ValueError("Reused workflow stage contains current Provider evidence")
    if (
        category is WorkflowProviderCategory.AZURE_DOCUMENT_INTELLIGENCE
        and stage.status
        in {
            WorkflowStageStatus.SUCCEEDED,
            WorkflowStageStatus.REUSED,
        }
    ):
        expected_attempts = (
            retained_attempts
            if stage.status is WorkflowStageStatus.REUSED
            else current_attempts
        )
        if not any(
            item.status is CloudExecutionAttemptStatus.COMPLETED
            for item in expected_attempts
        ):
            raise ValueError("Successful cloud workflow stage lacks completed evidence")
    _validate_review_required_stage(stage)


def _has_protected_workflow_stage_evidence(stage: WorkflowStageResult) -> bool:
    attempts = stage.retained_cloud_attempts + stage.current_cloud_attempts
    usages = stage.retained_provider_usage + stage.current_provider_usage
    return any(
        item.status in _PROTECTED_CLOUD_ATTEMPT_STATUSES for item in attempts
    ) or any(
        item.cloud_submitted_operation_count
        or item.cloud_paid_or_possibly_paid_operation_count
        or item.paid_operation_count
        or item.azure_operation_count
        for item in usages
    )


def _validate_review_required_stage(stage: WorkflowStageResult) -> None:
    """Require one objective, content-safe reason for a final review state."""
    if stage.status is not WorkflowStageStatus.REVIEW_REQUIRED:
        return
    if not stage.issues:
        raise ValueError("Review-required workflow stage lacks a sanitized issue")
    category = stage.provider_category
    if category is WorkflowProviderCategory.AZURE_DOCUMENT_INTELLIGENCE:
        if (
            stage.provider_identity is None
            or not _has_protected_workflow_stage_evidence(stage)
        ):
            raise ValueError(
                "Review-required cloud workflow stage lacks protected evidence"
            )
        return
    if category is WorkflowProviderCategory.LOCAL_OCR:
        quality_issues = _local_ocr_quality_review_issues(stage)
        if quality_issues:
            if (
                stage.kind is not WorkflowStageKind.OCR_OR_AZURE
                or stage.provider_identity is None
                or stage.output_identity is None
                or stage.current_cloud_attempts
                or stage.retained_cloud_attempts
                or stage.retry_eligible
                or len(quality_issues) != 1
                or not _is_exact_local_ocr_quality_review_issue(
                    quality_issues[0], stage
                )
            ):
                raise ValueError("Local OCR quality review evidence is inconsistent")
            return
        exact_issue = stage.issues[0] if len(stage.issues) == 1 else None
        if (
            stage.kind is not WorkflowStageKind.OCR_OR_AZURE
            or stage.provider_identity is None
            or stage.output_identity is not None
            or stage.current_provider_usage
            or stage.retained_provider_usage
            or stage.current_cloud_attempts
            or stage.retained_cloud_attempts
            or stage.artifact_references
            or stage.retry_eligible
            or stage.reuse_eligible
            or exact_issue is None
            or exact_issue.code != "local_ocr_provider_contract_failed"
            or exact_issue.category is not WorkflowIssueCategory.PROVIDER
            or exact_issue.message
            != "Workflow Local OCR Provider violated its local-only contract"
            or exact_issue.retryable
            or exact_issue.count is not None
            or exact_issue.source is not None
        ):
            raise ValueError("Local OCR review evidence is inconsistent")
        return
    quality_issues = _local_ocr_quality_review_issues(stage)
    if quality_issues:
        if (
            stage.kind is not WorkflowStageKind.STRUCTURED_EXTRACTION
            or stage.output_identity is None
            or stage.current_provider_usage
            or stage.retained_provider_usage
            or stage.current_cloud_attempts
            or stage.retained_cloud_attempts
            or stage.retry_eligible
            or len(quality_issues) != 1
            or not _is_exact_local_ocr_quality_review_issue(quality_issues[0], stage)
        ):
            raise ValueError("Structured Local OCR quality review is inconsistent")
        return
    lifecycle_issues = tuple(
        issue
        for issue in stage.issues
        if issue.code == "artifact_persistence_failed"
        and issue.category is WorkflowIssueCategory.ARTIFACT
        and issue.message == "Workflow artifact persistence failed"
        and not issue.retryable
        and issue.count is None
        and issue.source is None
    )
    if (
        stage.kind
        not in {
            WorkflowStageKind.NATIVE_ANALYSIS,
            WorkflowStageKind.NORMALIZE,
        }
        or stage.output_identity is None
        or stage.artifact_references
        or stage.retry_eligible
        or stage.reuse_eligible
        or len(lifecycle_issues) != 1
    ):
        raise ValueError("Provider-free review evidence is inconsistent")


def _validate_final_stage_lifecycle(
    stages: tuple[WorkflowStageResult, ...],
) -> None:
    """Validate cross-stage dependencies for every provider-free review."""
    by_kind = {stage.kind: stage for stage in stages}
    for stage in stages:
        if (
            stage.status is not WorkflowStageStatus.REVIEW_REQUIRED
            or stage.provider_category is not None
            or _local_ocr_quality_review_issues(stage)
        ):
            continue
        dependency = by_kind.get(WorkflowStageKind.OCR_OR_AZURE)
        if (
            dependency is None
            or dependency.provider_category
            is not WorkflowProviderCategory.AZURE_DOCUMENT_INTELLIGENCE
            or dependency.status
            not in {
                WorkflowStageStatus.SUCCEEDED,
                WorkflowStageStatus.REUSED,
            }
            or dependency.output_identity is None
            or not _has_protected_workflow_stage_evidence(dependency)
            or (
                stage.kind is WorkflowStageKind.NORMALIZE
                and stage.output_identity != dependency.output_identity
            )
        ):
            raise ValueError("Provider-free review lacks protected dependency evidence")


def _cloud_logical_operation_key(
    stage: WorkflowStageResult,
    attempt: CloudExecutionAttemptEvidence,
) -> tuple[object, ...]:
    return (
        stage.stage_identity,
        attempt.provider_name,
        attempt.profile_id,
        attempt.provider_resource_identity,
        attempt.requested_entire_input,
        attempt.requested_pages,
        attempt.requested_frames,
    )


def _provider_usage_totals(
    stages: tuple[WorkflowStageResult, ...],
) -> ProviderUsageTotals:
    cloud_fields = {
        "cloud_logical_operation_count",
        "cloud_submitted_operation_count",
        "cloud_paid_or_possibly_paid_operation_count",
        "cloud_transport_retry_count",
    }
    field_names = tuple(ProviderUsageTotals.model_fields)
    direct_fields = tuple(name for name in field_names if name not in cloud_fields)
    totals = dict.fromkeys(field_names, 0)
    logical_keys: set[tuple[object, ...]] = set()
    for stage in stages:
        usages = stage.retained_provider_usage + stage.current_provider_usage
        attempts = stage.retained_cloud_attempts + stage.current_cloud_attempts
        for usage in usages:
            for name in direct_fields:
                totals[name] += getattr(usage, name)
        logical_keys.update(
            _cloud_logical_operation_key(stage, attempt) for attempt in attempts
        )
        for attempt in attempts:
            totals["cloud_submitted_operation_count"] += (
                attempt.submitted_operation_count
            )
            totals["cloud_paid_or_possibly_paid_operation_count"] += (
                attempt.paid_or_possibly_paid_operation_count
            )
            totals["cloud_transport_retry_count"] += attempt.transport_retry_count
    totals["cloud_logical_operation_count"] = len(logical_keys)
    return ProviderUsageTotals(**totals)


class WorkflowUsage(_WorkflowPublicModel):
    """Exact current/retained Provider history and aggregate operation totals."""

    current_provider_usage: tuple[ProviderUsage, ...] = ()
    retained_provider_usage: tuple[ProviderUsage, ...] = ()
    current_cloud_attempts: tuple[CloudExecutionAttemptEvidence, ...] = ()
    retained_cloud_attempts: tuple[CloudExecutionAttemptEvidence, ...] = ()
    totals: ProviderUsageTotals = Field(default_factory=ProviderUsageTotals)
    local_stage_operation_count: Annotated[int, Field(ge=0)] = 0
    reused_stage_count: Annotated[int, Field(ge=0)] = 0

    @field_validator(
        "current_provider_usage",
        "retained_provider_usage",
        mode="before",
    )
    @classmethod
    def accept_provider_usage_json(cls, value: object) -> object:
        return _provider_usage_sequence(value)

    @field_validator(
        "current_cloud_attempts",
        "retained_cloud_attempts",
        mode="before",
    )
    @classmethod
    def accept_cloud_attempt_json(cls, value: object) -> object:
        return _cloud_attempt_sequence(value)

    @model_validator(mode="after")
    def validate_cloud_evidence(self) -> Self:
        for field_name in ("current_provider_usage", "retained_provider_usage"):
            object.__setattr__(
                self,
                field_name,
                tuple(
                    _revalidate_model_instance_json(
                        item,
                        ProviderUsage,
                        "Workflow Provider usage is invalid",
                    )
                    for item in getattr(self, field_name)
                ),
            )
        for field_name in ("current_cloud_attempts", "retained_cloud_attempts"):
            object.__setattr__(
                self,
                field_name,
                tuple(
                    _revalidate_model_instance_json(
                        item,
                        CloudExecutionAttemptEvidence,
                        "Workflow cloud attempt is invalid",
                    )
                    for item in getattr(self, field_name)
                ),
            )
        if type(self.totals) is not ProviderUsageTotals:
            raise ValueError("Workflow Provider usage totals are invalid")
        object.__setattr__(
            self,
            "totals",
            _revalidate_model_instance_json(
                self.totals,
                ProviderUsageTotals,
                "Workflow Provider usage totals are invalid",
            ),
        )
        _validate_cloud_evidence_partition(
            self.current_provider_usage,
            self.current_cloud_attempts,
        )
        _validate_cloud_evidence_partition(
            self.retained_provider_usage,
            self.retained_cloud_attempts,
        )
        return self


class WorkflowOutputEvidence(_WorkflowPublicModel):
    """Content-free projection of included and deliberately omitted output."""

    native_result_included: bool
    top_level_document_included: bool
    structured_extraction_included: bool
    document_content_present: bool
    excel_mode: ExcelWorkflowOutputMode | None = None
    excel_cell_count: Annotated[int, Field(ge=0)] = 0
    truncated: bool = False
    omitted_outputs: tuple[WorkflowArtifactKind, ...] = ()
    limitation_codes: tuple[str, ...] = ()

    @field_validator("omitted_outputs", "limitation_codes", mode="before")
    @classmethod
    def accept_json_arrays(cls, value: object) -> object:
        return tuple(value) if isinstance(value, list) else value

    @model_validator(mode="after")
    def validate_output_evidence(self) -> Self:
        if len(self.omitted_outputs) != len(set(self.omitted_outputs)):
            raise ValueError("Workflow omitted outputs must be unique")
        if self.limitation_codes != tuple(sorted(set(self.limitation_codes))):
            raise ValueError("Workflow limitation codes must be sorted and unique")
        if self.excel_mode is None and self.excel_cell_count:
            raise ValueError("Excel output count requires an Excel output mode")
        if (
            self.top_level_document_included or self.structured_extraction_included
        ) and not self.document_content_present:
            raise ValueError("Workflow Document content evidence is inconsistent")
        return self


def _validate_local_ocr_quality_manifest_evidence(
    manifest: DocumentWorkflowManifest,
) -> None:
    """Bind one final content-free quality summary to its owning stage."""
    summary = manifest.local_ocr_quality_summary
    owner = manifest.local_ocr_quality_owner_stage
    quality_issues = tuple(
        (stage, issue)
        for stage in manifest.stages
        for issue in _local_ocr_quality_review_issues(stage)
    )
    if summary is None:
        if (
            owner is not None
            or manifest.local_ocr_quality_binding is not None
            or quality_issues
        ):
            raise ValueError("Workflow Local OCR quality evidence is incomplete")
        return
    summary = _validate_quality_summary(summary)
    object.__setattr__(manifest, "local_ocr_quality_summary", summary)
    if manifest.document_type not in {DocumentType.PDF, DocumentType.IMAGE}:
        raise ValueError("Workflow Local OCR quality source family is invalid")
    if manifest.document_type is DocumentType.PDF and summary.evaluated_frames:
        raise ValueError("Workflow PDF quality evidence contains image frames")
    if manifest.document_type is DocumentType.IMAGE and summary.evaluated_pages:
        raise ValueError("Workflow image quality evidence contains PDF pages")
    if owner is None or owner not in {
        WorkflowStageKind.OCR_OR_AZURE,
        WorkflowStageKind.STRUCTURED_EXTRACTION,
    }:
        raise ValueError("Workflow Local OCR quality owner is invalid")
    by_kind = {stage.kind: stage for stage in manifest.stages}
    ocr_stage = by_kind[WorkflowStageKind.OCR_OR_AZURE]
    owner_stage = by_kind[owner]
    if (
        ocr_stage.provider_category is not WorkflowProviderCategory.LOCAL_OCR
        or ocr_stage.provider_identity is None
        or ocr_stage.output_identity is None
        or ocr_stage.status
        not in {
            WorkflowStageStatus.SUCCEEDED,
            WorkflowStageStatus.REUSED,
            WorkflowStageStatus.REVIEW_REQUIRED,
        }
    ):
        raise ValueError("Workflow quality evidence lacks a completed Local OCR stage")
    authoritative_usage = _authoritative_local_ocr_quality_usage(
        summary,
        ocr_stage,
    )
    if owner is WorkflowStageKind.STRUCTURED_EXTRACTION:
        normal_owner = (
            owner_stage.provider_category is None
            and owner_stage.output_identity is not None
            and owner_stage.status
            in {
                WorkflowStageStatus.SUCCEEDED,
                WorkflowStageStatus.REUSED,
                WorkflowStageStatus.REVIEW_REQUIRED,
            }
        )
        if not normal_owner and not _is_structured_artifact_failure_owner(owner_stage):
            raise ValueError("Workflow structured quality owner is invalid")
    if summary.decision is LocalOcrQualityDecision.FAIL:
        if (
            owner_stage.status is not WorkflowStageStatus.REVIEW_REQUIRED
            or len(quality_issues) != 1
            or quality_issues[0][0].kind is not owner
            or not _is_exact_local_ocr_quality_review_issue(
                quality_issues[0][1], owner_stage
            )
        ):
            raise ValueError("Workflow failed Local OCR quality lacks exact review")
    elif quality_issues:
        raise ValueError("Workflow passing Local OCR quality contains review evidence")
    expected_binding = _local_ocr_quality_evidence_binding(
        summary=summary,
        owner=owner,
        document_type=manifest.document_type,
        document_format=manifest.document_format,
        request_identity=manifest.request_identity,
        ocr_stage=ocr_stage,
        owner_stage=owner_stage,
        usage=authoritative_usage,
    )
    if manifest.local_ocr_quality_binding != expected_binding:
        raise ValueError("Workflow Local OCR quality identity binding is inconsistent")


def _authoritative_local_ocr_quality_usage(
    summary: LocalOcrQualitySummary,
    ocr_stage: WorkflowStageResult,
) -> ProviderUsage:
    """Select one current or uniquely matching retained quality occurrence."""
    current_usage = tuple(
        item
        for item in ocr_stage.current_provider_usage
        if item.provider_name == "local_ocr"
    )
    retained_usage = tuple(
        item
        for item in ocr_stage.retained_provider_usage
        if item.provider_name == "local_ocr"
    )
    if len(current_usage) > 1:
        raise ValueError("Workflow Local OCR quality Usage is ambiguous")

    def matches_summary(usage: ProviderUsage) -> bool:
        return _local_ocr_quality_usage_matches(
            summary=summary,
            usage=usage,
            preprocessing_attempt_count=usage.local_preprocessing_attempt_count,
            preprocessing_operation_count=usage.local_preprocessing_operation_count,
            preprocessing_pixel_count=usage.local_preprocessing_pixel_count,
        )

    if current_usage:
        if not matches_summary(current_usage[0]):
            raise ValueError("Workflow Local OCR quality Usage binding is inconsistent")
        return current_usage[0]
    matching_retained_usage = tuple(
        item for item in retained_usage if matches_summary(item)
    )
    if len(matching_retained_usage) > 1:
        raise ValueError("Workflow Local OCR quality Usage is ambiguous")
    if not matching_retained_usage:
        raise ValueError("Workflow Local OCR quality Usage binding is inconsistent")
    return matching_retained_usage[0]


def _is_structured_artifact_failure_owner(stage: WorkflowStageResult) -> bool:
    """Recognize only the existing provider-free Structured Artifact failure."""
    artifact_issues = tuple(
        issue
        for issue in stage.issues
        if issue.code == "artifact_persistence_failed"
        and issue.category is WorkflowIssueCategory.ARTIFACT
        and issue.message == "Workflow artifact persistence failed"
        and not issue.retryable
        and issue.count is None
        and issue.stage_kind is WorkflowStageKind.STRUCTURED_EXTRACTION
        and issue.provider_category is None
        and issue.source is None
    )
    return (
        stage.kind is WorkflowStageKind.STRUCTURED_EXTRACTION
        and stage.status is WorkflowStageStatus.FAILED
        and stage.output_identity is not None
        and stage.provider_category is None
        and stage.provider_identity is None
        and not stage.current_provider_usage
        and not stage.retained_provider_usage
        and not stage.current_cloud_attempts
        and not stage.retained_cloud_attempts
        and not stage.artifact_references
        and not stage.retry_eligible
        and not stage.reuse_eligible
        and len(artifact_issues) == 1
    )


def _local_ocr_quality_evidence_binding(  # noqa: PLR0913 - exact evidence tuple.
    *,
    summary: LocalOcrQualitySummary,
    owner: WorkflowStageKind,
    document_type: DocumentType,
    document_format: DocumentFormat,
    request_identity: str,
    ocr_stage: WorkflowStageResult,
    owner_stage: WorkflowStageResult,
    usage: ProviderUsage,
) -> str:
    """Bind final quality policy and counts to content-free Workflow evidence."""
    return workflow_fingerprint(
        "local-ocr-quality-evidence-binding",
        {
            "document_format": document_format.value,
            "document_type": document_type.value,
            "local_ocr_output_identity": ocr_stage.output_identity,
            "local_ocr_provider_identity": ocr_stage.provider_identity,
            "owner_output_identity": owner_stage.output_identity,
            "owner_stage": owner.value,
            "provider_usage": usage.model_dump(mode="json"),
            "request_identity": request_identity,
            "summary": summary.model_dump(mode="json"),
        },
    )


class DocumentWorkflowManifest(_WorkflowPublicModel):
    """Content-free stage-aware Resume evidence for one exact source."""

    manifest_version: Literal["2"] = WORKFLOW_MANIFEST_VERSION
    contract_version: Literal["2"] = WORKFLOW_CONTRACT_VERSION
    sdk_version: _NonEmptyString
    source: WorkflowSourceIdentity
    tenant_scope_identity: _Sha256
    document_type: DocumentType
    document_format: DocumentFormat
    request_identity: _Sha256
    plan_identity: _Sha256
    workflow_identity: _Sha256
    stages: tuple[WorkflowStageResult, ...]
    usage: WorkflowUsage
    artifact_references: tuple[WorkflowArtifactReference, ...] = ()
    warnings: tuple[ProcessingWarning, ...] = ()
    issues: tuple[WorkflowStageIssue, ...] = ()
    limitations: tuple[WorkflowLimitation, ...] = ()
    limitation_codes: tuple[str, ...] = ()
    local_ocr_quality_summary: LocalOcrQualitySummary | None = None
    local_ocr_quality_owner_stage: WorkflowStageKind | None = None
    local_ocr_quality_binding: _Sha256 | None = None

    @model_serializer(mode="wrap")
    def serialize_optional_quality_evidence(
        self,
        handler: SerializerFunctionWrapHandler,
    ) -> dict[str, object]:
        """Keep quality-disabled Manifest JSON byte-shape compatible."""
        serialized = cast("dict[str, object]", handler(self))
        if self.local_ocr_quality_summary is None:
            serialized.pop("local_ocr_quality_summary", None)
            serialized.pop("local_ocr_quality_owner_stage", None)
            serialized.pop("local_ocr_quality_binding", None)
        return serialized

    @field_validator(
        "stages",
        "artifact_references",
        "warnings",
        "issues",
        "limitations",
        "limitation_codes",
        mode="before",
    )
    @classmethod
    def accept_json_arrays(cls, value: object) -> object:
        return tuple(value) if isinstance(value, list) else value

    @model_validator(mode="after")
    def validate_manifest(self) -> Self:
        if self.warnings:
            raise ValueError(
                "Workflow warnings must use sanitized stage issue evidence"
            )
        object.__setattr__(
            self,
            "source",
            _exact_revalidate(
                self.source,
                WorkflowSourceIdentity,
                "Workflow Manifest source identity is invalid",
            ),
        )
        stages = tuple(
            _exact_revalidate(
                stage,
                WorkflowStageResult,
                "Workflow Manifest stage evidence is invalid",
            )
            for stage in self.stages
        )
        object.__setattr__(self, "stages", stages)
        usage = _exact_revalidate(
            self.usage,
            WorkflowUsage,
            "Workflow Manifest usage evidence is invalid",
        )
        object.__setattr__(self, "usage", usage)
        if tuple(stage.kind for stage in self.stages) != _STAGE_ORDER:
            raise ValueError("Workflow Manifest stages must use canonical order")
        _validate_final_stage_lifecycle(self.stages)
        stage_refs = tuple(
            reference
            for stage in self.stages
            for reference in stage.artifact_references
        )
        if self.artifact_references != stage_refs:
            raise ValueError("Workflow Manifest artifact projection is inconsistent")
        stage_issues = tuple(issue for stage in self.stages for issue in stage.issues)
        if self.issues != stage_issues:
            raise ValueError("Workflow Manifest issue projection is inconsistent")
        if any(
            reference.source != self.source
            or reference.tenant_scope_identity != self.tenant_scope_identity
            for reference in self.artifact_references
        ):
            raise ValueError("Workflow Manifest artifact ownership is inconsistent")
        if self.limitation_codes != tuple(sorted(set(self.limitation_codes))):
            raise ValueError("Workflow Manifest limitations must be sorted and unique")
        limitations = tuple(
            _exact_revalidate(
                item,
                WorkflowLimitation,
                "Workflow Manifest limitation is invalid",
            )
            for item in self.limitations
        )
        object.__setattr__(self, "limitations", limitations)
        if tuple(item.code for item in limitations) != self.limitation_codes:
            raise ValueError("Workflow Manifest limitation projection is inconsistent")
        expected_usage = workflow_usage_from_stages(self.stages)
        if self.usage != expected_usage:
            raise ValueError("Workflow Manifest usage projection is inconsistent")
        _validate_local_ocr_quality_manifest_evidence(self)
        return self


def workflow_usage_from_stages(
    stages: tuple[WorkflowStageResult, ...],
) -> WorkflowUsage:
    """Aggregate exact stage evidence once without estimating provider cost."""
    stages = tuple(
        _exact_revalidate(
            stage,
            WorkflowStageResult,
            "Workflow stage evidence is invalid",
        )
        for stage in stages
    )
    current_usage = tuple(
        item for stage in stages for item in stage.current_provider_usage
    )
    retained_usage = tuple(
        item for stage in stages for item in stage.retained_provider_usage
    )
    current_attempts = tuple(
        item for stage in stages for item in stage.current_cloud_attempts
    )
    retained_attempts = tuple(
        item for stage in stages for item in stage.retained_cloud_attempts
    )
    return WorkflowUsage(
        current_provider_usage=current_usage,
        retained_provider_usage=retained_usage,
        current_cloud_attempts=current_attempts,
        retained_cloud_attempts=retained_attempts,
        totals=_provider_usage_totals(stages),
        local_stage_operation_count=sum(
            (
                stage.status is WorkflowStageStatus.SUCCEEDED
                or (
                    stage.status is WorkflowStageStatus.REVIEW_REQUIRED
                    and bool(_local_ocr_quality_review_issues(stage))
                )
            )
            and stage.provider_category is None
            and stage.kind is not WorkflowStageKind.FINALIZE
            for stage in stages
        ),
        reused_stage_count=sum(
            stage.status is WorkflowStageStatus.REUSED for stage in stages
        ),
    )


class DocumentWorkflowResult(_WorkflowPublicModel):
    """Stable content-bearing Option-B envelope for every supported family."""

    contract_version: Literal["2"] = WORKFLOW_CONTRACT_VERSION
    status: DocumentWorkflowStatus
    source: WorkflowSourceIdentity
    detected_document_type: DocumentType
    detected_document_format: DocumentFormat
    plan: DocumentWorkflowPlan
    stage_results: tuple[WorkflowStageResult, ...]
    native_result: WorkflowNativeResult | None = None
    document: Document | None = None
    structured_extraction: StructuredExtractionResult | None = None
    usage: WorkflowUsage
    warnings: tuple[ProcessingWarning, ...] = ()
    issues: tuple[WorkflowStageIssue, ...] = ()
    limitations: tuple[WorkflowLimitation, ...] = ()
    output_evidence: WorkflowOutputEvidence
    manifest: DocumentWorkflowManifest
    artifact_references: tuple[WorkflowArtifactReference, ...] = ()

    @field_validator(
        "stage_results",
        "warnings",
        "issues",
        "limitations",
        "artifact_references",
        mode="before",
    )
    @classmethod
    def accept_json_arrays(cls, value: object) -> object:
        return tuple(value) if isinstance(value, list) else value

    @model_validator(mode="after")
    def validate_result(self) -> Self:  # noqa: PLR0915
        object.__setattr__(
            self,
            "source",
            _exact_revalidate(
                self.source,
                WorkflowSourceIdentity,
                "Workflow result source identity is invalid",
            ),
        )
        stages = tuple(
            _exact_revalidate(
                stage,
                WorkflowStageResult,
                "Workflow result stage evidence is invalid",
            )
            for stage in self.stage_results
        )
        object.__setattr__(self, "stage_results", stages)
        object.__setattr__(
            self,
            "usage",
            _exact_revalidate(
                self.usage,
                WorkflowUsage,
                "Workflow result usage evidence is invalid",
            ),
        )
        object.__setattr__(
            self,
            "manifest",
            _exact_revalidate(
                self.manifest,
                DocumentWorkflowManifest,
                "Workflow result Manifest evidence is invalid",
            ),
        )
        if tuple(stage.kind for stage in self.stage_results) != _STAGE_ORDER:
            raise ValueError("Workflow result stages must use canonical order")
        if (
            self.source != self.plan.source
            or self.detected_document_type is not self.plan.document_type
            or self.detected_document_format is not self.plan.document_format
        ):
            raise ValueError("Workflow result plan identity is inconsistent")
        if self.manifest.stages != self.stage_results:
            raise ValueError("Workflow result Manifest stages are inconsistent")
        if (
            self.manifest.source != self.source
            or self.manifest.document_type is not self.detected_document_type
            or self.manifest.document_format is not self.detected_document_format
            or self.manifest.request_identity != self.plan.request_identity
            or self.manifest.plan_identity != self.plan.plan_identity
            or self.manifest.workflow_identity != self.plan.workflow_identity
        ):
            raise ValueError("Workflow result Manifest identity is inconsistent")
        if self.usage != self.manifest.usage:
            raise ValueError("Workflow result usage is inconsistent")
        if self.artifact_references != self.manifest.artifact_references:
            raise ValueError("Workflow result artifact projection is inconsistent")
        if self.issues != self.manifest.issues:
            raise ValueError("Workflow result issue projection is inconsistent")
        if self.warnings != self.manifest.warnings:
            raise ValueError("Workflow result warning projection is inconsistent")
        if self.limitations != self.manifest.limitations:
            raise ValueError("Workflow result limitation projection is inconsistent")
        if tuple(item.code for item in self.limitations) != tuple(
            self.manifest.limitation_codes
        ):
            raise ValueError("Workflow result limitations are inconsistent")
        native = self.native_result
        if native is not None and native.kind != self.detected_document_type.value:
            raise ValueError("Workflow native result family is inconsistent")
        if native is not None and (
            workflow_source_identity_from_descriptor(_native_file_descriptor(native))
            != self.source
        ):
            raise ValueError("Workflow native result source is inconsistent")
        if self.document is not None and (
            workflow_source_identity_from_descriptor(self.document.file) != self.source
        ):
            raise ValueError("Workflow Document source is inconsistent")
        structured: StructuredExtractionResult | None = None
        if self.structured_extraction is not None:
            structured = _revalidate_model_instance_json(
                self.structured_extraction,
                StructuredExtractionResult,
                "Workflow structured extraction result is invalid",
            )
            object.__setattr__(self, "structured_extraction", structured)
            if (
                workflow_source_identity_from_descriptor(structured.document.file)
                != self.source
            ):
                raise ValueError("Workflow extraction source is inconsistent")
        native_quality = (
            None if native is None else _native_local_ocr_quality_report(native)
        )
        structured_quality = (
            None
            if structured is None or structured.local_ocr_quality_report is None
            else _validate_quality_report(structured.local_ocr_quality_report)
        )
        quality_summary = self.manifest.local_ocr_quality_summary
        quality_owner = self.manifest.local_ocr_quality_owner_stage
        if quality_summary is None:
            if native_quality is not None or (
                structured_quality is not None
                and structured_quality.summary.decision
                is not LocalOcrQualityDecision.NOT_APPLICABLE
            ):
                raise ValueError("Workflow output quality evidence lacks a summary")
        elif quality_owner is WorkflowStageKind.OCR_OR_AZURE:
            if native is not None and (
                native_quality is None or native_quality.summary != quality_summary
            ):
                raise ValueError("Workflow native quality summary is inconsistent")
            if (
                structured_quality is not None
                and structured_quality.summary != quality_summary
            ):
                raise ValueError("Workflow carried quality summary is inconsistent")
        elif quality_owner is WorkflowStageKind.STRUCTURED_EXTRACTION:
            if structured is not None and (
                structured_quality is None
                or structured_quality.summary != quality_summary
            ):
                raise ValueError("Workflow structured quality summary is inconsistent")
            if native is not None and native_quality is None:
                raise ValueError("Workflow structured quality lacks Local OCR lineage")
            if (
                native_quality is not None
                and structured_quality is not None
                and (
                    structured_quality.policy.intrinsic
                    != native_quality.policy.intrinsic
                    or structured_quality.input_assessments
                    != native_quality.input_assessments
                )
            ):
                raise ValueError("Workflow structured quality lineage is inconsistent")
        native_document = None if native is None else _native_document(native)
        documents = tuple(
            item
            for item in (
                native_document,
                self.document,
                None if structured is None else structured.document,
            )
            if item is not None
        )
        if documents and any(item != documents[0] for item in documents[1:]):
            raise ValueError("Workflow embedded Documents are inconsistent")
        evidence = self.output_evidence
        if (
            evidence.native_result_included != (native is not None)
            or evidence.top_level_document_included != (self.document is not None)
            or evidence.structured_extraction_included
            != (self.structured_extraction is not None)
            or evidence.document_content_present != bool(documents)
        ):
            raise ValueError("Workflow output content evidence is inconsistent")
        has_review_required = any(
            stage.status is WorkflowStageStatus.REVIEW_REQUIRED
            for stage in self.stage_results
        )
        has_failed = any(
            stage.status is WorkflowStageStatus.FAILED for stage in self.stage_results
        )
        partial_justified = bool(
            self.issues
            or self.limitations
            or self.output_evidence.truncated
            or (structured is not None and not structured.complete)
        )
        if has_review_required and (
            self.status is not DocumentWorkflowStatus.REVIEW_REQUIRED
        ):
            raise ValueError("Protected workflow evidence requires review")
        if self.status is DocumentWorkflowStatus.SUCCEEDED and (
            has_review_required
            or has_failed
            or self.issues
            or self.output_evidence.truncated
            or (structured is not None and not structured.complete)
        ):
            raise ValueError("Succeeded workflow contains partial or failed evidence")
        if self.status is DocumentWorkflowStatus.PARTIAL and (
            has_review_required or has_failed or not partial_justified
        ):
            raise ValueError("Partial workflow status is not justified")
        if self.status is DocumentWorkflowStatus.FAILED and not self.issues:
            raise ValueError("Failed workflow requires a sanitized issue")
        if (
            self.status is DocumentWorkflowStatus.REVIEW_REQUIRED
            and not has_review_required
        ):
            raise ValueError("Review-required workflow lacks a protected stage")
        return self


class DocumentWorkflowIntakeIssue(_WorkflowPublicModel):
    """One bounded, stage-less issue emitted before a Workflow Plan exists."""

    code: str = Field(pattern=_SAFE_CODE_PATTERN)
    category: WorkflowIssueCategory
    message: str = Field(
        min_length=1,
        max_length=256,
        pattern=_SAFE_INTAKE_MESSAGE_PATTERN,
    )
    retryable: bool
    count: Annotated[int | None, Field(ge=1)] = None
    source: SourceReference | None = None

    @field_validator("source", mode="before")
    @classmethod
    def accept_source_json(cls, value: object) -> object:
        if type(value) is not dict:
            return value
        source_type = cast("dict[object, object]", value).get("source_type")
        if type(source_type) is not str:
            return value
        payload = json.dumps(
            value,
            allow_nan=False,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        )
        if source_type == "pdf":
            source: SourceReference = PdfSourceReference.model_validate_json(payload)
        elif source_type == "image":
            source = ImageSourceReference.model_validate_json(payload)
        elif source_type == "excel":
            source = ExcelSourceReference.model_validate_json(payload)
        elif source_type == "docx":
            source = DocxSourceReference.model_validate_json(payload)
        else:
            return value
        return source

    @field_validator("message")
    @classmethod
    def validate_safe_message(cls, value: str) -> str:
        return _safe_public_text(value)


def _workflow_intake_status(
    result: DocumentWorkflowResult,
) -> DocumentWorkflowIntakeStatus:
    if (
        not result.plan.supported
        and result.status is DocumentWorkflowStatus.FAILED
        and any(
            issue.category is WorkflowIssueCategory.UNSUPPORTED
            for issue in result.issues
        )
    ):
        return DocumentWorkflowIntakeStatus.UNSUPPORTED
    return {
        DocumentWorkflowStatus.SUCCEEDED: DocumentWorkflowIntakeStatus.SUCCEEDED,
        DocumentWorkflowStatus.PARTIAL: DocumentWorkflowIntakeStatus.PARTIAL,
        DocumentWorkflowStatus.REVIEW_REQUIRED: (
            DocumentWorkflowIntakeStatus.REVIEW_REQUIRED
        ),
        DocumentWorkflowStatus.FAILED: DocumentWorkflowIntakeStatus.FAILED,
    }[result.status]


def _intake_issue_key(issue: DocumentWorkflowIntakeIssue) -> str:
    return json.dumps(
        issue.model_dump(mode="json"),
        allow_nan=False,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    )


class DocumentWorkflowIntakeResult(_WorkflowPublicModel):
    """Minimal outer contract for one planned or pre-Plan file outcome."""

    contract_version: Literal["2"] = WORKFLOW_CONTRACT_VERSION
    sdk_version: _NonEmptyString = __version__
    status: DocumentWorkflowIntakeStatus
    source: WorkflowSourceIdentity | None = None
    detected_document_type: DocumentType | None = None
    detected_document_format: DocumentFormat | None = None
    workflow_result: DocumentWorkflowResult | None = None
    issues: tuple[DocumentWorkflowIntakeIssue, ...] = ()

    @field_validator("issues", mode="before")
    @classmethod
    def accept_json_issues(cls, value: object) -> object:
        return tuple(value) if isinstance(value, list) else value

    @field_validator("sdk_version")
    @classmethod
    def validate_safe_sdk_version(cls, value: str) -> str:
        return _safe_public_text(value)

    @model_validator(mode="after")
    def validate_intake_result(self) -> Self:
        issues = tuple(
            _exact_revalidate(
                issue,
                DocumentWorkflowIntakeIssue,
                "Workflow intake issue evidence is invalid",
            )
            for issue in self.issues
        )
        object.__setattr__(self, "issues", issues)
        if tuple(sorted(issues, key=_intake_issue_key)) != issues:
            raise ValueError("Workflow intake issues must use canonical order")
        if len({_intake_issue_key(issue) for issue in issues}) != len(issues):
            raise ValueError("Workflow intake issues must be unique")

        source = self.source
        if source is not None:
            source = _exact_revalidate(
                source,
                WorkflowSourceIdentity,
                "Workflow intake source identity is invalid",
            )
            object.__setattr__(self, "source", source)

        detected_type = self.detected_document_type
        detected_format = self.detected_document_format
        if (detected_type is None) != (detected_format is None):
            raise ValueError("Workflow intake detection evidence is incomplete")
        if (
            detected_type is not None
            and detected_format is not None
            and FORMAT_TYPES[detected_format] is not detected_type
        ):
            raise ValueError("Workflow intake detection evidence is inconsistent")

        result = self.workflow_result
        if result is None:
            if self.status not in {
                DocumentWorkflowIntakeStatus.UNSUPPORTED,
                DocumentWorkflowIntakeStatus.REJECTED,
                DocumentWorkflowIntakeStatus.FAILED,
            }:
                raise ValueError("Workflow intake success requires a Workflow result")
            if not issues:
                raise ValueError("Pre-Plan workflow intake outcome requires an issue")
            return self

        result = _exact_revalidate(
            result,
            DocumentWorkflowResult,
            "Nested Workflow intake result is invalid",
        )
        object.__setattr__(self, "workflow_result", result)
        if issues:
            raise ValueError("Planned workflow intake cannot duplicate nested issues")
        if source is None or source != result.source:
            raise ValueError("Workflow intake source conflicts with nested result")
        if (
            detected_type is not result.detected_document_type
            or detected_format is not result.detected_document_format
        ):
            raise ValueError("Workflow intake detection conflicts with nested result")
        if self.sdk_version != result.manifest.sdk_version:
            raise ValueError("Workflow intake SDK version conflicts with nested result")
        if self.status is not _workflow_intake_status(result):
            raise ValueError("Workflow intake status conflicts with nested result")
        return self


def workflow_fingerprint(domain: str, value: object) -> str:
    """Create one domain-separated canonical workflow identity."""
    if not domain or not domain.isascii():
        raise ValueError("workflow fingerprint domain is invalid")
    return _canonical_fingerprint(
        f"document-sdk:workflow:{domain}:v1".encode(),
        value,
    )


__all__ = [
    "WORKFLOW_ARTIFACT_SERIALIZATION_VERSION",
    "WORKFLOW_CONTRACT_VERSION",
    "WORKFLOW_MANIFEST_VERSION",
    "DocumentWorkflowIntakeIssue",
    "DocumentWorkflowIntakeResult",
    "DocumentWorkflowIntakeStatus",
    "DocumentWorkflowManifest",
    "DocumentWorkflowOutputPolicy",
    "DocumentWorkflowPlan",
    "DocumentWorkflowPolicy",
    "DocumentWorkflowRequest",
    "DocumentWorkflowResult",
    "DocumentWorkflowStatus",
    "ExcelWorkflowOutputMode",
    "WorkflowArtifactKind",
    "WorkflowArtifactReference",
    "WorkflowDocxNativeResult",
    "WorkflowExcelNativeResult",
    "WorkflowExcelRangeData",
    "WorkflowExcelRangeSelection",
    "WorkflowExtractionMode",
    "WorkflowImageNativeResult",
    "WorkflowIssueCategory",
    "WorkflowLimitation",
    "WorkflowNativeResult",
    "WorkflowOcrRoute",
    "WorkflowOcrScope",
    "WorkflowOutputEvidence",
    "WorkflowPdfNativeResult",
    "WorkflowPdfPreflight",
    "WorkflowPdfProcessingMode",
    "WorkflowProviderCategory",
    "WorkflowProviderIdentity",
    "WorkflowProviderRequirement",
    "WorkflowRoute",
    "WorkflowSourceIdentity",
    "WorkflowStageIssue",
    "WorkflowStageKind",
    "WorkflowStagePlan",
    "WorkflowStageResult",
    "WorkflowStageStatus",
    "WorkflowUsage",
    "workflow_fingerprint",
    "workflow_source_identity_from_descriptor",
    "workflow_usage_from_stages",
]

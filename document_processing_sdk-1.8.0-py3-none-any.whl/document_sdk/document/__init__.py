"""Provider-independent unified document entry points."""

from document_sdk.document.errors import (
    DocumentResultValidationError,
    DocumentSourceChangedError,
    DocumentTypeMismatchError,
    UnsupportedDocumentOperationError,
    UnsupportedDocumentTypeError,
)
from document_sdk.document.models import (
    DocumentAnalysisOptions,
    DocumentAnalysisResult,
    DocumentEnvelope,
    DocumentFormat,
    DocumentInspectionResult,
    DocumentProcessingManifest,
    DocumentType,
    DocumentTypeDetection,
    DocxDocumentAnalysis,
    DocxDocumentInspection,
    ExcelDocumentAnalysis,
    ImageDocumentAnalysis,
    PdfDocumentAnalysis,
)
from document_sdk.document.processing import (
    analyze_document,
    detect_document_type,
    inspect_document,
)

__all__ = [
    "DocumentAnalysisOptions",
    "DocumentAnalysisResult",
    "DocumentEnvelope",
    "DocumentFormat",
    "DocumentInspectionResult",
    "DocumentProcessingManifest",
    "DocumentResultValidationError",
    "DocumentSourceChangedError",
    "DocumentType",
    "DocumentTypeDetection",
    "DocumentTypeMismatchError",
    "DocxDocumentAnalysis",
    "DocxDocumentInspection",
    "ExcelDocumentAnalysis",
    "ImageDocumentAnalysis",
    "PdfDocumentAnalysis",
    "UnsupportedDocumentOperationError",
    "UnsupportedDocumentTypeError",
    "analyze_document",
    "detect_document_type",
    "inspect_document",
]

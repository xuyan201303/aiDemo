"""Strict provider-independent models for unified document processing."""

# ruff: noqa: C901, EM101, PLR0912, PLR0913, PLR2004, TC001, TRY003

from __future__ import annotations

import hashlib
import json
import unicodedata
from enum import StrEnum
from pathlib import PurePath, PurePosixPath
from typing import Annotated, Literal

from pydantic import ConfigDict, Field, model_validator

from document_sdk.core import (
    CloudExecutionAttemptEvidence,
    CloudExecutionAttemptStatus,
    Document,
    ImageInspection,
    ImageSourceReference,
    LocalOcrQualityDecision,
    LocalOcrQualityReport,
    LocalOcrQualitySummary,
    PdfInspection,
    PdfSourceReference,
    ProcessingError,
    ProcessingResult,
    ProcessingWarning,
    ProviderUsage,
    WorkbookInspection,
)
from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.local_ocr_quality import (
    _local_ocr_quality_usage_matches,
    _validate_provider_usage,
    _validate_quality_summary,
)
from document_sdk.document._validation import SanitizedPublicModel
from document_sdk.document.errors import DocumentResultValidationError
from document_sdk.docx import (
    DocxAnalysisOptions,
    DocxAnalysisResult,
    DocxInspection,
)
from document_sdk.extraction import (
    StructuredExtractionOptions,
    StructuredExtractionResult,
)
from document_sdk.ocr.fallback_models import (
    AzurePageFallbackPolicy,
    AzurePageFallbackReport,
    AzurePageFallbackStatus,
    _validate_azure_fallback_policy,
    _validate_azure_fallback_report,
)
from document_sdk.ocr.preprocessing_models import (
    LocalOcrPreprocessingReport,
    LocalOcrPreprocessingSummary,
    _validate_preprocessing_quality_lineage,
)
from document_sdk.pipeline import HybridPdfAnalysisOptions

_StrictModel = ConfigDict(
    extra="forbid",
    frozen=True,
    strict=False,
    validate_default=True,
    hide_input_in_errors=True,
)
NonEmptyString = Annotated[str, Field(min_length=1)]
Sha256 = Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]


class _PublicModel(SanitizedPublicModel):
    """Public Unified Document model with sanitized validation failures."""

    _validation_error_type = DocumentResultValidationError
    _validation_error_message = "Unified Document result validation failed"


class DocumentType(StrEnum):
    """Supported high-level document families."""

    PDF = "pdf"
    EXCEL = "excel"
    IMAGE = "image"
    WORD = "word"


class DocumentFormat(StrEnum):
    """Supported concrete content formats."""

    PDF = "pdf"
    XLSX = "xlsx"
    XLSM = "xlsm"
    PNG = "png"
    JPEG = "jpeg"
    TIFF = "tiff"
    WEBP = "webp"
    BMP = "bmp"
    DOCX = "docx"


FORMAT_TYPES: dict[DocumentFormat, DocumentType] = {
    DocumentFormat.PDF: DocumentType.PDF,
    DocumentFormat.XLSX: DocumentType.EXCEL,
    DocumentFormat.XLSM: DocumentType.EXCEL,
    DocumentFormat.PNG: DocumentType.IMAGE,
    DocumentFormat.JPEG: DocumentType.IMAGE,
    DocumentFormat.TIFF: DocumentType.IMAGE,
    DocumentFormat.WEBP: DocumentType.IMAGE,
    DocumentFormat.BMP: DocumentType.IMAGE,
    DocumentFormat.DOCX: DocumentType.WORD,
}
FORMAT_MEDIA_TYPES: dict[DocumentFormat, str] = {
    DocumentFormat.PDF: "application/pdf",
    DocumentFormat.XLSX: (
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    ),
    DocumentFormat.XLSM: "application/vnd.ms-excel.sheet.macroEnabled.12",
    DocumentFormat.PNG: "image/png",
    DocumentFormat.JPEG: "image/jpeg",
    DocumentFormat.TIFF: "image/tiff",
    DocumentFormat.WEBP: "image/webp",
    DocumentFormat.BMP: "image/bmp",
    DocumentFormat.DOCX: (
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    ),
}
FORMAT_EXTENSIONS: dict[DocumentFormat, frozenset[str]] = {
    DocumentFormat.PDF: frozenset({".pdf"}),
    DocumentFormat.XLSX: frozenset({".xlsx"}),
    DocumentFormat.XLSM: frozenset({".xlsm"}),
    DocumentFormat.PNG: frozenset({".png"}),
    DocumentFormat.JPEG: frozenset({".jpg", ".jpeg"}),
    DocumentFormat.TIFF: frozenset({".tif", ".tiff"}),
    DocumentFormat.WEBP: frozenset({".webp"}),
    DocumentFormat.BMP: frozenset({".bmp"}),
    DocumentFormat.DOCX: frozenset({".docx"}),
}
_OPERATION_NAMES = frozenset(
    {
        "detection",
        "docx_analysis",
        "hybrid_pdf",
        "inspection",
        "native_pdf",
        "ocr_provider",
        "structured_extraction",
    }
)


def _safe_basename(value: str) -> str:
    normalized = unicodedata.normalize("NFKC", value)
    if (
        not normalized
        or normalized in {".", ".."}
        or PurePath(normalized).is_absolute()
        or PurePosixPath(normalized).is_absolute()
        or "/" in normalized
        or "\\" in normalized
        or any(ord(character) < 32 or ord(character) == 127 for character in normalized)
    ):
        raise ValueError("source_name must be a safe basename")
    return normalized


def _unique_sorted_counts(counts: tuple[OperationCount, ...]) -> bool:
    names = tuple(count.name for count in counts)
    return names == tuple(sorted(set(names)))


def _schema_fingerprint(result: StructuredExtractionResult) -> str:
    return hashlib.sha256(
        result.schema_contract.model_dump_json(by_alias=True).encode()
    ).hexdigest()


def _canonical_document_result_fingerprint(
    result: DocumentAnalysisResult,
) -> str:
    """Fingerprint one complete result independently of mapping insertion order."""
    payload = json.dumps(
        result.model_dump(mode="json"),
        sort_keys=True,
        ensure_ascii=False,
        separators=(",", ":"),
    )
    return hashlib.sha256(payload.encode()).hexdigest()


def _validate_manifest_quality_evidence(
    *,
    document_type: DocumentType,
    quality: LocalOcrQualitySummary | None,
    usage: ProviderUsage | None,
    preprocessing: LocalOcrPreprocessingSummary | None = None,
) -> None:
    """Cross-check content-free quality evidence against its source family."""
    if quality is None:
        return
    if document_type in {DocumentType.EXCEL, DocumentType.WORD}:
        raise ValueError("Local OCR quality is unsupported for this document family")
    if document_type is DocumentType.PDF:
        if (
            quality.evaluated_frames
            or quality.failed_frames
            or quality.recommended_retry_frames
        ):
            raise ValueError("PDF Local OCR quality contains frame indexes")
        if not _local_ocr_quality_usage_matches(
            summary=quality,
            usage=usage,
            preprocessing_attempt_count=(
                0 if preprocessing is None else preprocessing.extra_attempt_count
            ),
            preprocessing_operation_count=(
                0 if preprocessing is None else preprocessing.extra_operation_count
            ),
            preprocessing_pixel_count=(
                0 if preprocessing is None else preprocessing.preprocessing_pixel_count
            ),
        ):
            raise ValueError("PDF Local OCR quality indexes are out of bounds")
        return
    if (
        quality.decision is LocalOcrQualityDecision.NOT_APPLICABLE
        or quality.evaluated_pages
        or quality.failed_pages
        or quality.recommended_retry_pages
        or not _local_ocr_quality_usage_matches(
            summary=quality,
            usage=usage,
            preprocessing_attempt_count=(
                0 if preprocessing is None else preprocessing.extra_attempt_count
            ),
            preprocessing_operation_count=(
                0 if preprocessing is None else preprocessing.extra_operation_count
            ),
            preprocessing_pixel_count=(
                0 if preprocessing is None else preprocessing.preprocessing_pixel_count
            ),
        )
    ):
        raise ValueError("Image Local OCR quality indexes are out of bounds")


class DocumentEnvelope(_PublicModel):
    """Safe immutable identity for the exact processed bytes."""

    model_config = _StrictModel

    document_type: DocumentType
    document_format: DocumentFormat
    media_type: NonEmptyString
    source_name: NonEmptyString
    sha256: Sha256
    byte_size: Annotated[int, Field(strict=True, ge=0)]
    sdk_version: NonEmptyString
    extension_mismatch: bool = False

    @model_validator(mode="after")
    def _consistent_identity(self) -> DocumentEnvelope:
        normalized = _safe_basename(self.source_name)
        if normalized != self.source_name:
            raise ValueError("source_name must already be Unicode NFKC normalized")
        if FORMAT_TYPES[self.document_format] is not self.document_type:
            raise ValueError("document_type and document_format are inconsistent")
        if FORMAT_MEDIA_TYPES[self.document_format] != self.media_type:
            raise ValueError("media_type and document_format are inconsistent")
        return self


class DocumentTypeDetection(_PublicModel):
    """Content-derived type detection with safe warnings."""

    model_config = _StrictModel

    envelope: DocumentEnvelope
    warnings: tuple[ProcessingWarning, ...] = ()

    @model_validator(mode="after")
    def _consistent_warnings(self) -> DocumentTypeDetection:
        codes = tuple(warning.code for warning in self.warnings)
        if len(codes) != len(set(codes)):
            raise ValueError("detection warning codes must be unique")
        has_mismatch = any(
            warning.category == "extension_mismatch" for warning in self.warnings
        )
        if has_mismatch != self.envelope.extension_mismatch:
            raise ValueError("extension mismatch warning evidence is inconsistent")
        return self


class PdfDocumentInspection(_PublicModel):
    """Typed PDF inspection payload."""

    model_config = _StrictModel

    kind: Literal["pdf"] = "pdf"
    inspection: PdfInspection


class ExcelDocumentInspection(_PublicModel):
    """Typed Excel inspection payload."""

    model_config = _StrictModel

    kind: Literal["excel"] = "excel"
    inspection: WorkbookInspection


class ImageDocumentInspection(_PublicModel):
    """Typed image inspection payload."""

    model_config = _StrictModel

    kind: Literal["image"] = "image"
    inspection: ImageInspection


class DocxDocumentInspection(_PublicModel):
    """Typed DOCX inspection payload."""

    model_config = _StrictModel

    kind: Literal["word"] = "word"
    inspection: DocxInspection


DocumentInspectionPayload = Annotated[
    PdfDocumentInspection
    | ExcelDocumentInspection
    | ImageDocumentInspection
    | DocxDocumentInspection,
    Field(discriminator="kind"),
]


def _descriptor_matches(
    envelope: DocumentEnvelope,
    *,
    filename: str,
    extension: str,
    mime_type: str,
    sha256: str,
    byte_size: int,
) -> bool:
    return (
        filename == envelope.source_name
        and extension in FORMAT_EXTENSIONS[envelope.document_format]
        and mime_type == envelope.media_type
        and sha256 == envelope.sha256
        and byte_size == envelope.byte_size
    )


class DocumentInspectionResult(_PublicModel):
    """Unified inspection result without backend objects or paths."""

    model_config = _StrictModel

    envelope: DocumentEnvelope
    inspection: DocumentInspectionPayload
    pdf_page_count: Annotated[int | None, Field(strict=True, ge=1)] = None
    excel_worksheet_count: Annotated[int | None, Field(strict=True, ge=0)] = None
    image_frame_count: Annotated[int | None, Field(strict=True, ge=1)] = None
    docx_block_count: Annotated[int | None, Field(strict=True, ge=0)] = None
    warnings: tuple[ProcessingWarning, ...] = ()

    @model_validator(mode="after")
    def _consistent_payload(self) -> DocumentInspectionResult:
        expected_kind = self.envelope.document_type.value
        if self.inspection.kind != expected_kind:
            raise ValueError("inspection payload and envelope type are inconsistent")
        counts = (
            self.pdf_page_count,
            self.excel_worksheet_count,
            self.image_frame_count,
            self.docx_block_count,
        )
        if sum(count is not None for count in counts) != 1:
            raise ValueError("exactly one family aggregate count is required")
        descriptor = self.inspection.inspection.file
        if not _descriptor_matches(
            self.envelope,
            filename=descriptor.filename,
            extension=descriptor.extension,
            mime_type=descriptor.mime_type,
            sha256=descriptor.fingerprint.value,
            byte_size=descriptor.size_bytes,
        ):
            raise ValueError("inspection descriptor and envelope are inconsistent")
        if isinstance(self.inspection, PdfDocumentInspection):
            if (
                self.pdf_page_count != self.inspection.inspection.page_count
                or self.excel_worksheet_count is not None
                or self.image_frame_count is not None
                or self.docx_block_count is not None
            ):
                raise ValueError("PDF aggregate count is inconsistent")
        elif isinstance(self.inspection, ExcelDocumentInspection):
            if (
                self.excel_worksheet_count != len(self.inspection.inspection.worksheets)
                or self.pdf_page_count is not None
                or self.image_frame_count is not None
                or self.docx_block_count is not None
            ):
                raise ValueError("Excel aggregate count is inconsistent")
        elif isinstance(self.inspection, ImageDocumentInspection) and (
            self.image_frame_count != self.inspection.inspection.frame_count
            or self.pdf_page_count is not None
            or self.excel_worksheet_count is not None
            or self.docx_block_count is not None
        ):
            raise ValueError("Image aggregate count is inconsistent")
        elif isinstance(self.inspection, DocxDocumentInspection) and (
            self.docx_block_count != self.inspection.inspection.block_count
            or self.pdf_page_count is not None
            or self.excel_worksheet_count is not None
            or self.image_frame_count is not None
        ):
            raise ValueError("DOCX aggregate count is inconsistent")
        return self


class PdfAnalysisMode(StrEnum):
    """Explicit local/native or local-first hybrid PDF route."""

    NATIVE = "native"
    HYBRID = "hybrid"


class DocumentAnalysisOptions(_PublicModel):
    """Cost-safe explicit unified analysis options."""

    model_config = _StrictModel

    pdf_mode: PdfAnalysisMode = PdfAnalysisMode.NATIVE
    hybrid_pdf_options: HybridPdfAnalysisOptions | None = None
    structured_extraction_options: StructuredExtractionOptions | None = None
    docx_options: DocxAnalysisOptions | None = None
    azure_fallback_policy: AzurePageFallbackPolicy | None = None

    @model_validator(mode="after")
    def _compatible_options(self) -> DocumentAnalysisOptions:
        if self.azure_fallback_policy is not None:
            object.__setattr__(
                self,
                "azure_fallback_policy",
                _validate_azure_fallback_policy(self.azure_fallback_policy),
            )
        if self.structured_extraction_options is not None:
            object.__setattr__(
                self,
                "structured_extraction_options",
                _revalidate_model_instance_json(
                    self.structured_extraction_options,
                    StructuredExtractionOptions,
                    "Structured extraction options are invalid",
                ),
            )
        if (
            self.pdf_mode is PdfAnalysisMode.NATIVE
            and self.hybrid_pdf_options is not None
        ):
            raise ValueError("hybrid_pdf_options require pdf_mode='hybrid'")
        return self


class PdfDocumentAnalysis(_PublicModel):
    """Typed PDF analysis retaining the complete existing result."""

    model_config = _StrictModel

    kind: Literal["pdf"] = "pdf"
    document: Document
    processing_result: ProcessingResult[Document] | None = None

    @model_validator(mode="after")
    def _pdf_sources(self) -> PdfDocumentAnalysis:
        if any(
            not isinstance(page.source, PdfSourceReference)
            for page in self.document.pages
        ):
            raise ValueError("PDF analysis contains a non-PDF page source")
        if (
            self.processing_result is not None
            and self.processing_result.data != self.document
        ):
            raise ValueError("PDF processing result and document are inconsistent")
        return self


class ExcelDocumentAnalysis(_PublicModel):
    """Typed Excel analysis retaining its native workbook inspection."""

    model_config = _StrictModel

    kind: Literal["excel"] = "excel"
    workbook: WorkbookInspection


class ImageDocumentAnalysis(_PublicModel):
    """Typed image analysis with optional explicit OCR result."""

    model_config = _StrictModel

    kind: Literal["image"] = "image"
    image: ImageInspection
    ocr_result: ProcessingResult[Document] | None = None

    @model_validator(mode="after")
    def _image_sources(self) -> ImageDocumentAnalysis:
        if (
            self.ocr_result is not None
            and self.ocr_result.data is not None
            and any(
                not isinstance(page.source, ImageSourceReference)
                for page in self.ocr_result.data.pages
            )
        ):
            raise ValueError("Image OCR contains a non-Image page source")
        return self


class DocxDocumentAnalysis(_PublicModel):
    """Typed DOCX analysis retaining structure and normalized Document."""

    model_config = _StrictModel

    kind: Literal["word"] = "word"
    docx: DocxAnalysisResult


DocumentAnalysisPayload = Annotated[
    PdfDocumentAnalysis
    | ExcelDocumentAnalysis
    | ImageDocumentAnalysis
    | DocxDocumentAnalysis,
    Field(discriminator="kind"),
]


class OperationCount(_PublicModel):
    """One deterministic safe operation counter."""

    model_config = _StrictModel

    name: NonEmptyString
    count: Annotated[int, Field(strict=True, ge=0)]


def _azure_breakdown_matches_report(
    report: AzurePageFallbackReport,
    usages: tuple[ProviderUsage, ...],
) -> bool:
    identity = report.provider_identity_summary
    indexes = report.submitted_pages or report.submitted_frames
    if len(usages) != len(indexes):
        return False
    for usage, index in zip(usages, indexes, strict=True):
        expected_pages = (index,) if report.submitted_pages else ()
        expected_frames = (index,) if report.submitted_frames else ()
        if (
            identity is None
            or usage.provider_name != identity.provider_name
            or usage.profile_id != identity.profile_id
            or usage.model_id != identity.model_id
            or usage.api_version != identity.api_version
            or usage.provider_resource_identity != identity.provider_resource_identity
            or usage.submitted_pages != expected_pages
            or usage.returned_pages != expected_pages
            or usage.submitted_frames != expected_frames
            or usage.returned_frames != expected_frames
            or usage.requested_features
            != tuple(feature.value for feature in report.requested_features)
            or usage.query_field_count != report.query_field_count
            or usage.local_operation_count
            or usage.azure_operation_count != 1
            or usage.paid_operation_count != 1
            or usage.cloud_logical_operation_count != 1
            or usage.cloud_submitted_operation_count != 1
            or usage.cloud_paid_or_possibly_paid_operation_count != 1
            or usage.cloud_transport_retry_count != 0
        ):
            return False
    return True


def _validated_cloud_attempts(
    attempts: tuple[CloudExecutionAttemptEvidence, ...],
    usages: tuple[ProviderUsage, ...],
) -> tuple[CloudExecutionAttemptEvidence, ...]:
    """Bind completed cloud attempts to actual Provider usage exactly once."""
    validated = tuple(
        _revalidate_model_instance_json(
            attempt,
            CloudExecutionAttemptEvidence,
            "Cloud execution attempt evidence is invalid",
        )
        for attempt in attempts
    )
    cloud_usages = tuple(
        usage for usage in usages if usage.cloud_logical_operation_count
    )
    if len(validated) != len(cloud_usages):
        raise ValueError("Cloud execution attempt cardinality is inconsistent")
    for attempt, usage in zip(validated, cloud_usages, strict=True):
        if (
            attempt.status is not CloudExecutionAttemptStatus.COMPLETED
            or attempt.provider_name != usage.provider_name
            or attempt.profile_id != usage.profile_id
            or attempt.model_id != usage.model_id
            or attempt.api_version != usage.api_version
            or attempt.provider_resource_identity != usage.provider_resource_identity
            or attempt.submitted_pages != usage.submitted_pages
            or attempt.submitted_frames != usage.submitted_frames
            or attempt.logical_operation_count != usage.cloud_logical_operation_count
            or attempt.submitted_operation_count
            != usage.cloud_submitted_operation_count
            or attempt.paid_or_possibly_paid_operation_count
            != usage.cloud_paid_or_possibly_paid_operation_count
            or attempt.transport_retry_count != usage.cloud_transport_retry_count
        ):
            raise ValueError("Cloud execution attempt and usage are inconsistent")
    return validated


def _partition_completed_fallback_cloud_attempts(
    report: AzurePageFallbackReport | None,
    attempts: tuple[CloudExecutionAttemptEvidence, ...],
) -> tuple[CloudExecutionAttemptEvidence, ...]:
    """Consume one completed fallback projection and return standalone attempts."""
    if report is None or report.status is AzurePageFallbackStatus.NOT_APPLICABLE:
        return attempts
    identity = report.provider_identity_summary
    indexes = report.submitted_pages or report.submitted_frames
    is_page = bool(report.submitted_pages)
    remaining = list(attempts)
    matched: list[CloudExecutionAttemptEvidence] = []
    for index in indexes:
        expected_pages = (index,) if is_page else ()
        expected_frames = () if is_page else (index,)
        candidates = tuple(
            attempt
            for attempt in remaining
            if (
                identity is not None
                and attempt.status is CloudExecutionAttemptStatus.COMPLETED
                and attempt.provider_name == identity.provider_name
                and attempt.profile_id == identity.profile_id
                and attempt.model_id == identity.model_id
                and attempt.api_version == identity.api_version
                and attempt.provider_resource_identity
                == identity.provider_resource_identity
                and not attempt.requested_entire_input
                and attempt.requested_pages == expected_pages
                and attempt.requested_frames == expected_frames
                and attempt.submitted_pages == expected_pages
                and attempt.submitted_frames == expected_frames
            )
        )
        if len(candidates) != 1:
            raise ValueError("Completed fallback cloud evidence is incomplete")
        matched_attempt = candidates[0]
        remaining.remove(matched_attempt)
        matched.append(matched_attempt)
    if sum(attempt.input_bytes for attempt in matched) != report.payload_byte_count:
        raise ValueError("Completed fallback cloud payload bytes are inconsistent")
    return tuple(remaining)


def _validate_direct_cloud_attempt_bindings(
    attempts: tuple[CloudExecutionAttemptEvidence, ...],
    *,
    document_type: DocumentType,
    pdf_page_count: int | None = None,
    image_frame_count: int | None = None,
    byte_size: int | None = None,
) -> None:
    """Bind standalone Direct attempts to one known source family and identity."""
    if not attempts:
        return
    for attempt in attempts:
        if document_type not in {DocumentType.PDF, DocumentType.IMAGE}:
            raise ValueError("Cloud execution is unsupported for this document family")
        preflight_unknown = (
            attempt.status is CloudExecutionAttemptStatus.NOT_SUBMITTED
            and attempt.input_bytes == 0
        )
        if document_type is DocumentType.PDF:
            if attempt.requested_frames or attempt.submitted_frames:
                raise ValueError("Direct PDF cloud attempt contains frame indexes")
            requested_indexes = attempt.requested_pages
            submitted_indexes = attempt.submitted_pages
            input_count = pdf_page_count
        else:
            if attempt.submitted_pages or (
                attempt.requested_pages and not preflight_unknown
            ):
                raise ValueError("Direct image cloud attempt contains page indexes")
            requested_indexes = attempt.requested_frames or attempt.requested_pages
            submitted_indexes = attempt.submitted_frames
            input_count = image_frame_count
        if input_count is not None and any(
            index > input_count for index in requested_indexes + submitted_indexes
        ):
            raise ValueError("Direct cloud attempt indexes are out of bounds")
        if attempt.submitted_operation_count:
            if byte_size is not None and attempt.input_bytes != byte_size:
                raise ValueError("Direct cloud attempt input bytes are inconsistent")
            if (
                attempt.requested_entire_input
                and input_count is not None
                and submitted_indexes != tuple(range(1, input_count + 1))
            ):
                raise ValueError("Direct entire-input cloud scope is incomplete")


class DocumentProcessingManifest(_PublicModel):
    """Content-free processing evidence for one document operation."""

    model_config = _StrictModel

    manifest_version: Literal["3"] = "3"
    source_sha256: Sha256
    sdk_version: NonEmptyString
    document_type: DocumentType
    document_format: DocumentFormat
    processing_fingerprint: Sha256
    schema_id: str | None = None
    schema_version: str | None = None
    schema_fingerprint: Sha256 | None = None
    provider_profile_id: str | None = None
    provider_usage: ProviderUsage | None = None
    provider_usage_breakdown: tuple[ProviderUsage, ...] = ()
    cloud_execution_attempts: tuple[CloudExecutionAttemptEvidence, ...] = ()
    local_ocr_quality_summary: LocalOcrQualitySummary | None = None
    local_ocr_preprocessing_summary: LocalOcrPreprocessingSummary | None = None
    azure_fallback_summary: AzurePageFallbackReport | None = None
    azure_fallback_policy_fingerprint: Sha256 | None = None
    operation_counts: tuple[OperationCount, ...] = ()

    @model_validator(mode="after")
    def _consistent_manifest(self) -> DocumentProcessingManifest:
        usage = _validate_provider_usage(self.provider_usage)
        object.__setattr__(self, "provider_usage", usage)
        breakdown = tuple(
            validated
            for item in self.provider_usage_breakdown
            if (validated := _validate_provider_usage(item)) is not None
        )
        object.__setattr__(self, "provider_usage_breakdown", breakdown)
        cloud_attempts = _validated_cloud_attempts(
            self.cloud_execution_attempts,
            breakdown or (() if usage is None else (usage,)),
        )
        object.__setattr__(self, "cloud_execution_attempts", cloud_attempts)
        if self.local_ocr_quality_summary is not None:
            object.__setattr__(
                self,
                "local_ocr_quality_summary",
                _validate_quality_summary(self.local_ocr_quality_summary),
            )
        if self.local_ocr_preprocessing_summary is not None:
            object.__setattr__(
                self,
                "local_ocr_preprocessing_summary",
                _revalidate_model_instance_json(
                    self.local_ocr_preprocessing_summary,
                    LocalOcrPreprocessingSummary,
                    "Local OCR preprocessing summary is invalid",
                ),
            )
        fallback = self.azure_fallback_summary
        if fallback is not None:
            fallback = _validate_azure_fallback_report(fallback)
            object.__setattr__(self, "azure_fallback_summary", fallback)
            if self.azure_fallback_policy_fingerprint != fallback.policy_fingerprint:
                raise ValueError("manifest fallback identity is inconsistent")
            expected_quality = (
                fallback.structured_recheck_summary
                if fallback.structured_recheck_performed
                else fallback.trigger_quality_summary
            )
            if self.local_ocr_quality_summary != expected_quality:
                raise ValueError("manifest fallback quality evidence is inconsistent")
        elif self.azure_fallback_policy_fingerprint is not None:
            raise ValueError("manifest fallback identity requires fallback evidence")
        standalone_cloud_attempts = _partition_completed_fallback_cloud_attempts(
            fallback,
            cloud_attempts,
        )
        _validate_direct_cloud_attempt_bindings(
            standalone_cloud_attempts,
            document_type=self.document_type,
        )
        if FORMAT_TYPES[self.document_format] is not self.document_type:
            raise ValueError("manifest type and format are inconsistent")
        if not _unique_sorted_counts(self.operation_counts):
            raise ValueError("operation counts must have unique sorted names")
        if any(
            count.name not in _OPERATION_NAMES or count.count != 1
            for count in self.operation_counts
        ):
            raise ValueError("operation counts contain unsupported evidence")
        schema_values = (
            self.schema_id,
            self.schema_version,
            self.schema_fingerprint,
        )
        if any(value is None for value in schema_values) and any(
            value is not None for value in schema_values
        ):
            raise ValueError(
                "schema manifest projections must be all present or absent"
            )
        if usage is not None and self.provider_profile_id != usage.profile_id:
            raise ValueError("manifest Provider usage profile is inconsistent")
        local_breakdown = () if usage is None else (usage,)
        if fallback is None:
            if breakdown not in ((), local_breakdown):
                raise ValueError("manifest Provider usage breakdown is inconsistent")
        elif fallback.status is AzurePageFallbackStatus.NOT_APPLICABLE:
            if breakdown != local_breakdown:
                raise ValueError("manifest Provider usage breakdown is inconsistent")
        elif (
            breakdown[: len(local_breakdown)] != local_breakdown
            or len(breakdown) - len(local_breakdown) != fallback.azure_operation_count
            or not _azure_breakdown_matches_report(
                fallback,
                breakdown[len(local_breakdown) :],
            )
        ):
            raise ValueError("manifest Azure usage breakdown is inconsistent")
        _validate_manifest_quality_evidence(
            document_type=self.document_type,
            quality=self.local_ocr_quality_summary,
            usage=usage,
            preprocessing=self.local_ocr_preprocessing_summary,
        )
        return self


def _validate_fallback_evidence(
    result: DocumentAnalysisResult,
    usage: ProviderUsage | None,
) -> None:
    """Cross-check Local and Azure usage without combining Provider identities."""
    breakdown = tuple(
        validated
        for item in result.provider_usage_breakdown
        if (validated := _validate_provider_usage(item)) is not None
    )
    object.__setattr__(result, "provider_usage_breakdown", breakdown)
    fallback = result.azure_fallback_report
    if fallback is not None:
        fallback = _validate_azure_fallback_report(fallback)
        object.__setattr__(result, "azure_fallback_report", fallback)
    local_breakdown = () if usage is None else (usage,)
    if fallback is None:
        if breakdown not in ((), local_breakdown):
            raise ValueError("Provider usage breakdown is inconsistent")
        return
    if result.local_ocr_quality_report is None:
        raise ValueError("Fallback and Local quality evidence are inconsistent")
    expected_quality = (
        fallback.structured_recheck_summary
        if fallback.structured_recheck_performed
        else fallback.trigger_quality_summary
    )
    if expected_quality != result.local_ocr_quality_report.summary:
        raise ValueError("Fallback trigger quality evidence is inconsistent")
    if fallback.status is AzurePageFallbackStatus.NOT_APPLICABLE:
        if breakdown != local_breakdown:
            raise ValueError("Not-applicable fallback usage is inconsistent")
        return
    azure_usages = breakdown[len(local_breakdown) :]
    if (
        breakdown[: len(local_breakdown)] != local_breakdown
        or len(azure_usages) != fallback.azure_operation_count
        or any(
            item.local_operation_count
            or item.azure_operation_count != 1
            or item.paid_operation_count != 1
            or item.cloud_logical_operation_count != 1
            or item.cloud_submitted_operation_count != 1
            or item.cloud_paid_or_possibly_paid_operation_count != 1
            or item.cloud_transport_retry_count != 0
            for item in azure_usages
        )
        or not _azure_breakdown_matches_report(fallback, azure_usages)
        or sum(len(item.submitted_pages) for item in azure_usages)
        != fallback.paid_page_count
        or sum(len(item.submitted_frames) for item in azure_usages)
        != fallback.paid_frame_count
    ):
        raise ValueError("Azure fallback usage breakdown is inconsistent")


class DocumentAnalysisResult(_PublicModel):
    """Unified analysis result preserving detailed family-specific evidence."""

    model_config = _StrictModel

    envelope: DocumentEnvelope
    inspection: DocumentInspectionResult
    analysis: DocumentAnalysisPayload
    structured_extraction: StructuredExtractionResult | None = None
    warnings: tuple[ProcessingWarning, ...] = ()
    issues: tuple[ProcessingError, ...] = ()
    provider_usage: ProviderUsage | None = None
    local_ocr_quality_report: LocalOcrQualityReport | None = None
    local_ocr_preprocessing_report: LocalOcrPreprocessingReport | None = None
    azure_fallback_report: AzurePageFallbackReport | None = None
    provider_usage_breakdown: tuple[ProviderUsage, ...] = ()
    cloud_execution_attempts: tuple[CloudExecutionAttemptEvidence, ...] = ()
    processing_manifest: DocumentProcessingManifest

    @model_validator(mode="after")
    def _consistent_result(  # noqa: PLR0915
        self,
    ) -> DocumentAnalysisResult:
        if self.structured_extraction is not None:
            object.__setattr__(
                self,
                "structured_extraction",
                _revalidate_model_instance_json(
                    self.structured_extraction,
                    StructuredExtractionResult,
                    "Structured extraction result is invalid",
                ),
            )
        usage = _validate_provider_usage(self.provider_usage)
        object.__setattr__(self, "provider_usage", usage)
        _validate_fallback_evidence(self, usage)
        cloud_attempts = _validated_cloud_attempts(
            self.cloud_execution_attempts,
            self.provider_usage_breakdown or (() if usage is None else (usage,)),
        )
        object.__setattr__(self, "cloud_execution_attempts", cloud_attempts)
        envelope = self.envelope
        manifest = self.processing_manifest
        analyzed_document: Document | None
        nested_provider_usage: ProviderUsage | None = None
        nested_cloud_attempts: tuple[CloudExecutionAttemptEvidence, ...] = ()
        expected_quality_report: LocalOcrQualityReport | None = None
        expected_preprocessing_report: LocalOcrPreprocessingReport | None = None
        if self.inspection.envelope != envelope:
            raise ValueError("analysis inspection and envelope are inconsistent")
        standalone_cloud_attempts = _partition_completed_fallback_cloud_attempts(
            self.azure_fallback_report,
            cloud_attempts,
        )
        _validate_direct_cloud_attempt_bindings(
            standalone_cloud_attempts,
            document_type=envelope.document_type,
            pdf_page_count=self.inspection.pdf_page_count,
            image_frame_count=self.inspection.image_frame_count,
            byte_size=envelope.byte_size,
        )
        if self.analysis.kind != envelope.document_type.value:
            raise ValueError("analysis payload and envelope type are inconsistent")
        if (
            manifest.source_sha256 != envelope.sha256
            or manifest.sdk_version != envelope.sdk_version
            or manifest.document_type is not envelope.document_type
            or manifest.document_format is not envelope.document_format
        ):
            raise ValueError("analysis manifest and envelope are inconsistent")
        if (
            manifest.provider_usage_breakdown != self.provider_usage_breakdown
            or manifest.cloud_execution_attempts != cloud_attempts
            or manifest.azure_fallback_summary != self.azure_fallback_report
            or manifest.azure_fallback_policy_fingerprint
            != (
                None
                if self.azure_fallback_report is None
                else self.azure_fallback_report.policy_fingerprint
            )
        ):
            raise ValueError("analysis fallback manifest evidence is inconsistent")
        if isinstance(self.analysis, PdfDocumentAnalysis):
            analyzed_document = self.analysis.document
            if self.analysis.processing_result is not None:
                nested_provider_usage = (
                    self.analysis.processing_result.metadata.provider_usage
                )
                expected_quality_report = (
                    self.analysis.processing_result.metadata.local_ocr_quality_report
                )
                processing_metadata = self.analysis.processing_result.metadata
                if processing_metadata.cloud_execution_attempt is not None:
                    nested_cloud_attempts = (
                        processing_metadata.cloud_execution_attempt,
                    )
                expected_preprocessing_report = (
                    processing_metadata.local_ocr_preprocessing_report
                )
            if (
                self.analysis.processing_result is not None
                and self.structured_extraction is not None
            ):
                raise ValueError("PDF Hybrid and Structured routes cannot be combined")
        elif isinstance(self.analysis, ImageDocumentAnalysis):
            if self.analysis.image != self.inspection.inspection.inspection:
                raise ValueError("Image analysis and inspection are inconsistent")
            analyzed_document = (
                None
                if self.analysis.ocr_result is None
                else self.analysis.ocr_result.data
            )
            if self.analysis.ocr_result is not None:
                nested_provider_usage = self.analysis.ocr_result.metadata.provider_usage
                if (
                    self.analysis.ocr_result.metadata.cloud_execution_attempt
                    is not None
                ):
                    nested_cloud_attempts = (
                        self.analysis.ocr_result.metadata.cloud_execution_attempt,
                    )
                expected_quality_report = (
                    self.analysis.ocr_result.metadata.local_ocr_quality_report
                )
                expected_preprocessing_report = (
                    self.analysis.ocr_result.metadata.local_ocr_preprocessing_report
                )
        elif isinstance(self.analysis, DocxDocumentAnalysis):
            if self.analysis.docx.inspection != self.inspection.inspection.inspection:
                raise ValueError("DOCX analysis and inspection are inconsistent")
            analyzed_document = self.analysis.docx.document
        else:
            if self.analysis.workbook != self.inspection.inspection.inspection:
                raise ValueError("Excel analysis and inspection are inconsistent")
            analyzed_document = None
        if analyzed_document is not None:
            descriptor = analyzed_document.file
            if not _descriptor_matches(
                envelope,
                filename=descriptor.filename,
                extension=descriptor.extension,
                mime_type=descriptor.mime_type,
                sha256=descriptor.fingerprint.value,
                byte_size=descriptor.size_bytes,
            ):
                raise ValueError("analysis document descriptor is inconsistent")
        if self.structured_extraction is not None:
            if envelope.document_type is DocumentType.EXCEL:
                raise ValueError("Structured Extraction is unsupported for Excel")
            if analyzed_document != self.structured_extraction.document:
                raise ValueError("Structured Extraction document is inconsistent")
            structured = self.structured_extraction
            structured_preprocessing = structured.local_ocr_preprocessing_report
            if expected_preprocessing_report is not None:
                if structured_preprocessing != expected_preprocessing_report:
                    raise ValueError("Structured preprocessing report is inconsistent")
            elif (
                isinstance(self.analysis, PdfDocumentAnalysis)
                and self.analysis.processing_result is None
            ):
                expected_preprocessing_report = structured_preprocessing
            elif structured_preprocessing is not None:
                raise ValueError("Structured preprocessing report is inconsistent")
            expected_quality_report = structured.local_ocr_quality_report
            structured_descriptor = structured.document.file
            if not _descriptor_matches(
                envelope,
                filename=structured_descriptor.filename,
                extension=structured_descriptor.extension,
                mime_type=structured_descriptor.mime_type,
                sha256=structured_descriptor.fingerprint.value,
                byte_size=structured_descriptor.size_bytes,
            ):
                raise ValueError(
                    "Structured Extraction document descriptor is inconsistent"
                )
            if (
                nested_provider_usage is not None
                and nested_provider_usage != structured.provider_usage
            ):
                raise ValueError("Structured Extraction Provider usage is inconsistent")
            nested_provider_usage = structured.provider_usage
            if structured.cloud_execution_attempt is not None:
                nested_cloud_attempts = (structured.cloud_execution_attempt,)
            if (
                manifest.schema_id != structured.schema_id
                or manifest.schema_version != structured.schema_version
                or manifest.schema_fingerprint != _schema_fingerprint(structured)
            ):
                raise ValueError("manifest schema projection is inconsistent")
        elif any(
            value is not None
            for value in (
                manifest.schema_id,
                manifest.schema_version,
                manifest.schema_fingerprint,
            )
        ):
            raise ValueError("manifest projects a schema without extraction")
        if expected_preprocessing_report is not None:
            if expected_quality_report is None:
                raise ValueError("Preprocessing quality lineage is incomplete")
            (
                expected_preprocessing_report,
                expected_quality_report,
            ) = _validate_preprocessing_quality_lineage(
                expected_preprocessing_report,
                expected_quality_report,
            )
        nested_provider_usage = _validate_provider_usage(nested_provider_usage)
        if usage != nested_provider_usage:
            raise ValueError("Provider usage and nested result are inconsistent")
        if cloud_attempts[: len(nested_cloud_attempts)] != nested_cloud_attempts:
            raise ValueError("Cloud attempt and nested result are inconsistent")
        if (
            self.azure_fallback_report is None
            and cloud_attempts != nested_cloud_attempts
        ):
            raise ValueError("Cloud attempt projection is inconsistent")
        if manifest.provider_usage != usage:
            raise ValueError("Provider usage and manifest projection are inconsistent")
        if usage is not None and manifest.provider_profile_id != usage.profile_id:
            raise ValueError("Provider usage and manifest profile are inconsistent")
        if self.local_ocr_quality_report != expected_quality_report:
            raise ValueError("Local OCR quality report projection is inconsistent")
        if self.local_ocr_preprocessing_report != expected_preprocessing_report:
            raise ValueError(
                "Local OCR preprocessing report projection is inconsistent"
            )
        expected_quality_summary = (
            None if expected_quality_report is None else expected_quality_report.summary
        )
        if manifest.local_ocr_quality_summary != expected_quality_summary:
            raise ValueError("Local OCR quality summary projection is inconsistent")
        expected_preprocessing_summary = (
            None
            if expected_preprocessing_report is None
            else expected_preprocessing_report.summary()
        )
        if manifest.local_ocr_preprocessing_summary != expected_preprocessing_summary:
            raise ValueError(
                "Local OCR preprocessing summary projection is inconsistent"
            )
        if isinstance(self.analysis, PdfDocumentAnalysis):
            processing = self.analysis.processing_result
            route_structured = self.structured_extraction
            if processing is None and route_structured is None:
                route_operation = "native_pdf"
                if (
                    manifest.provider_profile_id is not None
                    or self.provider_usage is not None
                ):
                    raise ValueError(
                        "Native PDF analysis cannot contain Provider evidence"
                    )
                expected_warnings = self.inspection.warnings
                expected_issues: tuple[ProcessingError, ...] = ()
            elif processing is not None:
                route_operation = "hybrid_pdf"
                expected_warnings = self.inspection.warnings + processing.warnings
                expected_issues = processing.errors
            else:
                route_operation = "structured_extraction"
                if route_structured is None:
                    raise ValueError("Structured PDF route evidence is incomplete")
                expected_warnings = self.inspection.warnings + route_structured.warnings
                expected_issues = ()
            expected_names = {"detection", "inspection", route_operation}
        elif isinstance(self.analysis, ImageDocumentAnalysis):
            expected_names = {"detection", "inspection"}
            ocr_result = self.analysis.ocr_result
            image_structured = self.structured_extraction
            if ocr_result is None and image_structured is None:
                if (
                    manifest.provider_profile_id is not None
                    or self.provider_usage is not None
                ):
                    raise ValueError(
                        "Local Image analysis cannot contain Provider evidence"
                    )
                expected_warnings = self.inspection.warnings
                expected_issues = ()
            elif ocr_result is None:
                raise ValueError("Image Structured Extraction requires OCR evidence")
            else:
                if ocr_result.data is None or manifest.provider_profile_id is None:
                    raise ValueError("Image OCR route evidence is inconsistent")
                expected_names.add("ocr_provider")
                expected_warnings = self.inspection.warnings + ocr_result.warnings
                if image_structured is not None:
                    if ocr_result.data != image_structured.document:
                        raise ValueError(
                            "Structured Image route evidence is inconsistent"
                        )
                    expected_names.add("structured_extraction")
                    expected_warnings += image_structured.warnings
                expected_issues = ocr_result.errors
        elif isinstance(self.analysis, ExcelDocumentAnalysis):
            if (
                self.structured_extraction is not None
                or manifest.provider_profile_id is not None
                or self.provider_usage is not None
            ):
                raise ValueError("Excel analysis cannot contain Provider evidence")
            expected_names = {"detection", "inspection"}
            expected_warnings = self.inspection.warnings
            expected_issues = ()
        else:
            if (
                manifest.provider_profile_id is not None
                or self.provider_usage is not None
            ):
                raise ValueError("DOCX analysis cannot contain Provider evidence")
            expected_names = {"detection", "inspection", "docx_analysis"}
            if self.structured_extraction is not None:
                expected_names.add("structured_extraction")
            expected_warnings = self.analysis.docx.warnings + (
                ()
                if self.structured_extraction is None
                else self.structured_extraction.warnings
            )
            expected_issues = self.analysis.docx.issues
        if self.warnings != expected_warnings:
            raise ValueError("top-level warning aggregation is inconsistent")
        if self.issues != expected_issues:
            raise ValueError("top-level issue aggregation is inconsistent")
        expected_counts = tuple(
            OperationCount(name=name, count=1) for name in sorted(expected_names)
        )
        if manifest.operation_counts != expected_counts:
            raise ValueError("route operation counts are inconsistent")
        return self

"""Sanitized errors for unified document processing."""

from document_sdk.core import DocumentSdkError
from document_sdk.core.errors import DocumentSourceChangedError

__all__ = [
    "DocumentResultValidationError",
    "DocumentSourceChangedError",
    "DocumentTypeMismatchError",
    "UnsupportedDocumentOperationError",
    "UnsupportedDocumentTypeError",
]


class UnsupportedDocumentTypeError(DocumentSdkError):
    """Raised when content is not one of the supported document families."""


class DocumentTypeMismatchError(DocumentSdkError):
    """Raised when a requested operation is incompatible with the content."""


class DocumentResultValidationError(DocumentSdkError):
    """Raised when public Unified Document evidence is inconsistent."""


class UnsupportedDocumentOperationError(DocumentSdkError):
    """Raised when a document family cannot perform a requested operation."""

"""Compatibility alias for the shared private exception sanitizer."""

from document_sdk.core._exceptions import redact_exception as _redact_exception

__all__ = ["_redact_exception"]

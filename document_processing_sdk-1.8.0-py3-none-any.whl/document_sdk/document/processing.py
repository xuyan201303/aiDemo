"""Unified content detection, prepared inspection, and analysis dispatch."""

# ruff: noqa: BLE001, C901, EM101, PLR0912, PLR0913, PLR0915, TC003, TRY003

from __future__ import annotations

import hashlib
import json
import os
import stat
import tempfile
import unicodedata
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal, cast

from document_sdk import __version__
from document_sdk.core import (
    LOCAL_OCR_QUALITY_ALGORITHM_VERSION,
    CloudExecutionAttemptEvidence,
    Document,
    DocumentProcessingError,
    DocumentSdkError,
    FileAccessError,
    FileDescriptor,
    FileFingerprint,
    ImageInspection,
    LocalOcrIntrinsicQualityPolicy,
    LocalOcrQualityIssueCode,
    LocalOcrQualityReport,
    LocalOcrQualitySummary,
    PdfInspection,
    ProcessingError,
    ProcessingResult,
    ProcessingWarning,
    ProviderUsage,
    WorkbookInspection,
)
from document_sdk.core._validation import _revalidate_model_instance_json
from document_sdk.core.errors import _raise_redacted_translation
from document_sdk.core.local_ocr_quality import (
    _validate_local_ocr_provider_quality_result,
    local_ocr_quality_identity,
)
from document_sdk.document._exceptions import _redact_exception
from document_sdk.document.errors import (
    DocumentSourceChangedError,
    DocumentTypeMismatchError,
    UnsupportedDocumentOperationError,
    UnsupportedDocumentTypeError,
)
from document_sdk.document.models import (
    FORMAT_EXTENSIONS,
    FORMAT_MEDIA_TYPES,
    DocumentAnalysisOptions,
    DocumentAnalysisResult,
    DocumentEnvelope,
    DocumentFormat,
    DocumentInspectionResult,
    DocumentProcessingManifest,
    DocumentType,
    DocumentTypeDetection,
    DocxDocumentAnalysis,
    DocxDocumentInspection,
    ExcelDocumentAnalysis,
    ExcelDocumentInspection,
    ImageDocumentAnalysis,
    ImageDocumentInspection,
    OperationCount,
    PdfAnalysisMode,
    PdfDocumentAnalysis,
    PdfDocumentInspection,
)
from document_sdk.docx import (
    DocxAnalysisResult,
    DocxInspection,
    DocxPackageInvalidError,
    DocxProcessingError,
    DocxProcessingLimits,
    DocxResourceLimitError,
    DocxUnsupportedPackageError,
    analyze_docx,
)
from document_sdk.docx._opc import OfficePackageKind, classify_ooxml_path
from document_sdk.excel import inspect_workbook
from document_sdk.extraction import (
    ExtractionSchema,
    ExtractionStrategy,
    StructuredExtractionOptions,
    StructuredExtractionResult,
    analyze_pdf_structured,
    extract_structured_fields,
)
from document_sdk.extraction.extraction import (
    _analyze_pdf_structured_prepared,
    _extract_structured_fields_with_quality,
    _revalidate_structured_extraction_result,
    _validate_local_quality_provider,
)
from document_sdk.image import ImageProcessingLimits, inspect_image
from document_sdk.ocr import OcrAnalysisOptions, OcrProvider
from document_sdk.ocr._azure_execution import attach_completed_cloud_result
from document_sdk.ocr._provider_boundary import (
    _invoke_ocr_provider_safely,
    _LocalOcrInvocationState,
    _read_provider_context_projection_safely,
    _read_provider_identity_safely,
    _revalidate_document_processing_result,
)
from document_sdk.ocr.fallback import (
    _apply_prepared_azure_page_fallback,
    _completed_fallback_attempt_evidence,
    _enforce_candidate_limits,
    _fallback_attempt_phase,
    _fallback_candidates,
    _is_actual_azure_provider,
)
from document_sdk.ocr.fallback_errors import (
    AzureFallbackConfigurationError,
    AzureFallbackInvalidResultError,
    AzureFallbackSourceChangedError,
)
from document_sdk.ocr.fallback_models import (
    AzureFallbackAttemptEvidence,
    AzurePageFallbackPolicy,
    AzurePageFallbackReport,
    AzurePageFallbackResult,
    AzurePageFallbackStatus,
    _validate_azure_fallback_policy,
    _validate_azure_fallback_report,
)
from document_sdk.ocr.preprocessing_models import (
    LocalOcrPreprocessingReport,
    _validate_preprocessing_quality_lineage,
)
from document_sdk.pdf import PdfProcessingLimits, extract_native_text, inspect_pdf
from document_sdk.pipeline import analyze_pdf_hybrid
from document_sdk.pipeline.hybrid_pdf import _analyze_pdf_hybrid_prepared

if TYPE_CHECKING:
    from document_sdk.ocr.local import LocalOcrProvider, _LocalOcrPreparedSource

_CHUNK_SIZE = 1024 * 1024
_MAX_QUERY_FIELDS = 20
_IMAGE_FORMATS = {
    "PNG": DocumentFormat.PNG,
    "JPEG": DocumentFormat.JPEG,
    "TIFF": DocumentFormat.TIFF,
    "WEBP": DocumentFormat.WEBP,
    "BMP": DocumentFormat.BMP,
}


@dataclass(frozen=True)
class _PreparedDocument:
    """Private runtime source plus safe validated detection and inspection."""

    source: Path
    detection: DocumentTypeDetection
    inspection: DocumentInspectionResult
    docx_analysis: DocxAnalysisResult | None = None
    local_ocr_source: _LocalOcrPreparedSource | None = None


@dataclass(frozen=True)
class _AzureFallbackPlan:
    """Content-free fallback routing evidence prepared before source copying."""

    source_kind: Literal["page", "frame"]
    candidates: tuple[int, ...]
    policy: AzurePageFallbackPolicy
    quality_summary: LocalOcrQualitySummary


class _DocumentIdentityLimitError(DocumentProcessingError):
    """Private signal for a bounded batch identity read."""

    def __init__(self, message: str, *, byte_size: int) -> None:
        super().__init__(message)
        self.byte_size = byte_size


class _UnsupportedDocumentIdentityError(UnsupportedDocumentTypeError):
    """Private intake-classified signal retaining only safe detection facts."""

    def __init__(
        self,
        message: str,
        *,
        sha256: str,
        byte_size: int,
        classification: Literal["rejected", "unsupported"],
    ) -> None:
        super().__init__(message)
        self.sha256 = sha256
        self.byte_size = byte_size
        self.classification = classification


class _RejectedOoxmlIdentityError(UnsupportedDocumentTypeError):
    """Private signal distinguishing malformed OPC from unsupported packages."""


def _warning(code: str, category: str, message: str) -> ProcessingWarning:
    return ProcessingWarning(code=code, category=category, message=message)


def _raw_identity(
    path: Path,
    *,
    max_bytes: int | None = None,
) -> tuple[str, int]:
    """Hash any regular local file without trusting its extension."""
    regular_source: bool | None = None
    try:
        regular_source = path.is_file()
    except Exception as exc:
        _redact_exception(exc)
    if regular_source is None:
        raise FileAccessError(
            "The document source could not be inspected safely"
        ) from OSError("redacted")
    if not regular_source:
        raise FileAccessError("The document source is not a regular file")
    digest = hashlib.sha256()
    byte_size = 0
    try:
        with path.open("rb") as stream:
            while chunk := stream.read(
                _CHUNK_SIZE
                if max_bytes is None
                else min(_CHUNK_SIZE, max_bytes - byte_size + 1)
            ):
                digest.update(chunk)
                byte_size += len(chunk)
                if max_bytes is not None and byte_size > max_bytes:
                    raise _DocumentIdentityLimitError(  # noqa: TRY301
                        "The document exceeds the configured identity byte limit",
                        byte_size=byte_size,
                    )
    except _DocumentIdentityLimitError:
        raise
    except Exception as exc:
        _redact_exception(exc)
    else:
        return digest.hexdigest(), byte_size
    raise FileAccessError("The document source could not be read safely") from OSError(
        "redacted"
    )


def _image_format_from_signature(signature: bytes) -> DocumentFormat | None:
    if signature.startswith(b"\x89PNG\r\n\x1a\n"):
        return DocumentFormat.PNG
    if signature.startswith(b"\xff\xd8\xff"):
        return DocumentFormat.JPEG
    if signature.startswith((b"II*\x00", b"MM\x00*")):
        return DocumentFormat.TIFF
    if signature.startswith(b"BM"):
        return DocumentFormat.BMP
    if signature.startswith(b"RIFF") and signature[8:12] == b"WEBP":
        return DocumentFormat.WEBP
    return None


@contextmanager
def _adapter_path(
    path: Path,
    document_format: DocumentFormat | None,
    expected_sha256: str,
    expected_size: int,
    *,
    always_snapshot: bool = False,
    snapshot_suffix: str | None = None,
) -> Iterator[Path]:
    """Yield a correctly suffixed same-byte snapshot when an adapter requires it."""
    if (
        not always_snapshot
        and document_format is not None
        and path.suffix.lower() in FORMAT_EXTENSIONS[document_format]
    ):
        yield path
        return
    if document_format is None and not always_snapshot:
        raise AssertionError("A generic adapter path must use a snapshot")
    if snapshot_suffix is not None:
        suffix = snapshot_suffix
    elif document_format is None:
        suffix = path.suffix or ".bin"
    else:
        suffix = min(FORMAT_EXTENSIONS[document_format])
    temporary: str | None = None
    primary_failure: BaseException | None = None
    setup_failed = False
    snapshot_ready = False
    consumer_started = False
    consumer_oserror = False
    cleanup_failed = False
    source_changed = False
    digest = hashlib.sha256()
    byte_size = 0
    mode = 0
    try:
        try:
            mode = path.lstat().st_mode
            if not stat.S_ISREG(mode) or stat.S_ISLNK(mode):
                raise DocumentSourceChangedError(  # noqa: TRY301
                    "The document source changed during snapshot creation"
                )
            with (
                path.open("rb") as source,
                tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as target,
            ):
                temporary = target.name
                while not source_changed:
                    allowed_bytes = min(
                        _CHUNK_SIZE,
                        expected_size - byte_size + 1,
                    )
                    chunk = source.read(allowed_bytes)
                    if not chunk:
                        break
                    if len(chunk) > allowed_bytes:
                        chunk = chunk[:allowed_bytes]
                        source_changed = True
                    digest.update(chunk)
                    byte_size += len(chunk)
                    target.write(chunk)
                    if byte_size > expected_size:
                        source_changed = True
                        break
                target.flush()
                os.fsync(target.fileno())
        except DocumentSourceChangedError:
            raise
        except Exception as exc:
            _redact_exception(exc)
            setup_failed = True
        snapshot_path = None if temporary is None else Path(temporary)
        if snapshot_path is None:
            setup_failed = True
        if not setup_failed and snapshot_path is not None:
            try:
                if (
                    source_changed
                    or digest.hexdigest() != expected_sha256
                    or byte_size != expected_size
                ):
                    raise DocumentSourceChangedError(  # noqa: TRY301
                        "The document source changed during snapshot creation"
                    )
                try:
                    mode = path.lstat().st_mode
                except Exception as exc:
                    _redact_exception(exc)
                    source_changed = True
                if source_changed or not stat.S_ISREG(mode) or stat.S_ISLNK(mode):
                    raise DocumentSourceChangedError(  # noqa: TRY301
                        "The document source changed during snapshot creation"
                    )
                snapshot_ready = True
                consumer_started = True
                yield snapshot_path
            except OSError as exc:
                _redact_exception(exc)
                consumer_oserror = True
            except BaseException as exc:
                primary_failure = exc
                raise
    finally:
        if temporary is not None:
            try:
                Path(temporary).unlink(missing_ok=True)
            except Exception as exc:
                _redact_exception(exc)
                cleanup_failed = True
                if primary_failure is not None:
                    primary_failure.add_note(
                        "Temporary document snapshot cleanup also failed safely."
                    )
    if setup_failed:
        raise FileAccessError(
            "The document snapshot could not be created safely"
        ) from OSError("redacted")
    if consumer_oserror:
        processing_failure = DocumentProcessingError(
            "Document processing through the verified snapshot failed safely"
        )
        if cleanup_failed:
            processing_failure.add_note(
                "Temporary document snapshot cleanup also failed safely."
            )
        raise processing_failure from OSError("redacted")
    if cleanup_failed:
        raise FileAccessError(
            "The document snapshot could not be cleaned up safely"
        ) from OSError("redacted")
    if snapshot_ready and not consumer_started:
        raise AssertionError("snapshot consumer was not started")


@contextmanager
def _immutable_expected_source(
    path: Path,
    expected_identity: tuple[str, int],
    *,
    max_bytes: int | None = None,
) -> Iterator[Path]:
    """Yield one verified private path while preserving the caller's basename."""
    expected_sha256, expected_size = expected_identity
    if max_bytes is not None and expected_size > max_bytes:
        raise _DocumentIdentityLimitError(
            "The document exceeds the configured identity byte limit",
            byte_size=expected_size,
        )
    try:
        private_root = tempfile.TemporaryDirectory(prefix="document-sdk-batch-source-")
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            FileAccessError("The document snapshot could not be created safely"),
        )
    primary_failure: BaseException | None = None
    cleanup_failed = False
    try:
        with _adapter_path(
            path,
            None,
            expected_sha256,
            expected_size,
            always_snapshot=True,
            snapshot_suffix=path.suffix or ".bin",
        ) as captured:
            snapshot = Path(private_root.name) / path.name
            try:
                captured.replace(snapshot)
            except Exception as exc:
                _raise_redacted_translation(
                    exc,
                    FileAccessError(
                        "The document snapshot could not be created safely"
                    ),
                )
            try:
                yield snapshot
            except BaseException as exc:
                primary_failure = exc
                raise
    except FileAccessError:
        source_matches = False
        try:
            mode = path.lstat().st_mode
            source_matches = (
                stat.S_ISREG(mode)
                and not stat.S_ISLNK(mode)
                and _raw_identity(path, max_bytes=expected_size) == expected_identity
            )
        except (KeyboardInterrupt, SystemExit, GeneratorExit):
            raise
        except Exception as exc:
            _redact_exception(exc)
        if not source_matches:
            raise DocumentSourceChangedError(
                "The document source changed during snapshot creation"
            ) from None
        raise
    finally:
        try:
            private_root.cleanup()
        except Exception as exc:
            _redact_exception(exc)
            cleanup_failed = True
            if primary_failure is not None:
                primary_failure.add_note(
                    "Temporary document snapshot cleanup also failed safely."
                )
    if cleanup_failed:
        raise FileAccessError(
            "The document snapshot could not be cleaned up safely"
        ) from OSError("redacted")


def _safe_descriptor(
    descriptor: FileDescriptor,
    envelope: DocumentEnvelope,
) -> FileDescriptor:
    return descriptor.model_copy(
        update={
            "filename": envelope.source_name,
            "extension": min(FORMAT_EXTENSIONS[envelope.document_format]),
            "mime_type": envelope.media_type,
            "size_bytes": envelope.byte_size,
            "fingerprint": FileFingerprint(value=envelope.sha256),
        }
    )


def _normalize_pdf(
    inspection: PdfInspection,
    envelope: DocumentEnvelope,
) -> PdfInspection:
    return inspection.model_copy(
        update={"file": _safe_descriptor(inspection.file, envelope)}
    )


def _normalize_excel(
    inspection: WorkbookInspection,
    envelope: DocumentEnvelope,
) -> WorkbookInspection:
    return inspection.model_copy(
        update={"file": _safe_descriptor(inspection.file, envelope)}
    )


def _normalize_image(
    inspection: ImageInspection,
    envelope: DocumentEnvelope,
) -> ImageInspection:
    return inspection.model_copy(
        update={"file": _safe_descriptor(inspection.file, envelope)}
    )


def _normalize_docx(
    inspection: DocxInspection,
    envelope: DocumentEnvelope,
) -> DocxInspection:
    return inspection.model_copy(
        update={"file": _safe_descriptor(inspection.file, envelope)}
    )


def _normalize_document(document: Document, envelope: DocumentEnvelope) -> Document:
    return document.model_copy(
        update={"file": _safe_descriptor(document.file, envelope)}
    )


def _ooxml_format(
    path: Path,
    *,
    limits: DocxProcessingLimits,
) -> DocumentFormat | None:
    """Classify through the exact bounded OPC contract used by Direct DOCX."""
    try:
        classification = classify_ooxml_path(
            path,
            limits=limits,
        )
    except DocxResourceLimitError:
        raise
    except DocxPackageInvalidError as exc:
        _raise_redacted_translation(
            exc,
            _RejectedOoxmlIdentityError(
                "The document container declarations are malformed or unsafe"
            ),
        )
    except DocxUnsupportedPackageError as exc:
        _raise_redacted_translation(
            exc,
            UnsupportedDocumentTypeError(
                "The document container declarations are unsafe or unsupported"
            ),
        )
    except DocxProcessingError as exc:
        _raise_redacted_translation(
            exc,
            DocumentProcessingError(
                "The document container could not be classified safely"
            ),
        )
    return {
        OfficePackageKind.DOCX: DocumentFormat.DOCX,
        OfficePackageKind.XLSX: DocumentFormat.XLSX,
        OfficePackageKind.XLSM: DocumentFormat.XLSM,
    }.get(classification.kind)


def _detection(
    path: Path,
    *,
    document_type: DocumentType,
    document_format: DocumentFormat,
    sha256: str,
    byte_size: int,
) -> DocumentTypeDetection:
    source_name = unicodedata.normalize("NFKC", path.name)
    mismatch = (
        Path(source_name).suffix.lower() not in FORMAT_EXTENSIONS[document_format]
    )
    envelope = DocumentEnvelope(
        document_type=document_type,
        document_format=document_format,
        media_type=FORMAT_MEDIA_TYPES[document_format],
        source_name=source_name,
        sha256=sha256,
        byte_size=byte_size,
        sdk_version=__version__,
        extension_mismatch=mismatch,
    )
    warnings = (
        (
            _warning(
                "document.extension_mismatch",
                "extension_mismatch",
                "The filename extension does not match the detected content.",
            ),
        )
        if mismatch
        else ()
    )
    return DocumentTypeDetection(envelope=envelope, warnings=warnings)


def _detect_identity(
    path: Path,
    *,
    expected_identity: tuple[str, int] | None = None,
    max_bytes: int | None = None,
    ooxml_limits: DocxProcessingLimits | None = None,
) -> DocumentTypeDetection:
    """Perform one cheap identity and content-family detection pass."""
    sha256, byte_size = _raw_identity(path, max_bytes=max_bytes)
    if expected_identity is not None and (sha256, byte_size) != expected_identity:
        raise DocumentSourceChangedError(
            "The document source changed before preparation"
        )
    if byte_size == 0:
        raise _UnsupportedDocumentIdentityError(
            "Empty documents are unsupported",
            sha256=sha256,
            byte_size=byte_size,
            classification="rejected",
        )
    signature = b""
    signature_ready = False
    try:
        with path.open("rb") as stream:
            signature = stream.read(16)
    except Exception as exc:
        _redact_exception(exc)
    else:
        signature_ready = True
    if not signature_ready:
        raise _UnsupportedDocumentIdentityError(
            "The document could not be read safely",
            sha256=sha256,
            byte_size=byte_size,
            classification="unsupported",
        ) from OSError("redacted")
    if signature.startswith(b"%PDF-"):
        return _detection(
            path,
            document_type=DocumentType.PDF,
            document_format=DocumentFormat.PDF,
            sha256=sha256,
            byte_size=byte_size,
        )
    if signature.startswith(b"PK\x03\x04"):
        document_format: DocumentFormat | None = None
        excel_format_ready = False
        try:
            document_format = _ooxml_format(
                path,
                limits=ooxml_limits or DocxProcessingLimits(),
            )
        except _RejectedOoxmlIdentityError as exc:
            _raise_redacted_translation(
                exc,
                _UnsupportedDocumentIdentityError(
                    "The document container is unsupported or corrupt",
                    sha256=sha256,
                    byte_size=byte_size,
                    classification="rejected",
                ),
            )
        except UnsupportedDocumentTypeError as exc:
            _redact_exception(exc)
        else:
            excel_format_ready = True
        if not excel_format_ready:
            raise _UnsupportedDocumentIdentityError(
                "The document container is unsupported or corrupt",
                sha256=sha256,
                byte_size=byte_size,
                classification="unsupported",
            ) from ValueError("redacted")
        if document_format is None:
            raise _UnsupportedDocumentIdentityError(
                "The document container is not a supported Office document",
                sha256=sha256,
                byte_size=byte_size,
                classification="unsupported",
            )
        return _detection(
            path,
            document_type=(
                DocumentType.WORD
                if document_format is DocumentFormat.DOCX
                else DocumentType.EXCEL
            ),
            document_format=document_format,
            sha256=sha256,
            byte_size=byte_size,
        )
    document_format = _image_format_from_signature(signature)
    if document_format is None:
        raise _UnsupportedDocumentIdentityError(
            "The document content is unsupported or corrupt",
            sha256=sha256,
            byte_size=byte_size,
            classification="unsupported",
        )
    return _detection(
        path,
        document_type=DocumentType.IMAGE,
        document_format=document_format,
        sha256=sha256,
        byte_size=byte_size,
    )


def _assert_source_unchanged(path: Path, envelope: DocumentEnvelope) -> None:
    if _raw_identity(path) != (envelope.sha256, envelope.byte_size):
        raise DocumentSourceChangedError(
            "The document source changed during processing"
        )


def _inspect_detected(
    path: Path,
    detection: DocumentTypeDetection,
    *,
    limits: object | None,
) -> DocumentInspectionResult:
    envelope = detection.envelope
    if envelope.document_type is DocumentType.PDF:
        with _adapter_path(
            path,
            envelope.document_format,
            envelope.sha256,
            envelope.byte_size,
        ) as adapter:
            pdf_inspection = _normalize_pdf(
                inspect_pdf(adapter, limits=limits),  # type: ignore[arg-type]
                envelope,
            )
        result = DocumentInspectionResult(
            envelope=envelope,
            inspection=PdfDocumentInspection(inspection=pdf_inspection),
            pdf_page_count=pdf_inspection.page_count,
            warnings=detection.warnings,
        )
    elif envelope.document_type is DocumentType.EXCEL:
        if limits is not None:
            raise DocumentTypeMismatchError(
                "Excel inspection does not accept the supplied limits"
            )
        with _adapter_path(
            path,
            envelope.document_format,
            envelope.sha256,
            envelope.byte_size,
        ) as adapter:
            workbook_inspection = _normalize_excel(inspect_workbook(adapter), envelope)
        result = DocumentInspectionResult(
            envelope=envelope,
            inspection=ExcelDocumentInspection(inspection=workbook_inspection),
            excel_worksheet_count=len(workbook_inspection.worksheets),
            warnings=detection.warnings,
        )
    elif envelope.document_type is DocumentType.WORD:
        result, _ = _analyze_docx_detected(
            path,
            detection,
            options=None,
            limits=limits,
        )
    else:
        image_ready = False
        raw_image: ImageInspection | None = None
        with _adapter_path(
            path,
            envelope.document_format,
            envelope.sha256,
            envelope.byte_size,
        ) as adapter:
            try:
                raw_image = inspect_image(
                    adapter,
                    limits=limits,  # type: ignore[arg-type]
                )
            except DocumentProcessingError:
                raise
            except Exception as exc:
                _redact_exception(exc)
            else:
                image_ready = True
            if not image_ready or raw_image is None:
                raise UnsupportedDocumentTypeError(
                    "The document content is unsupported or corrupt"
                ) from ValueError("redacted")
            image_inspection = _normalize_image(raw_image, envelope)
        if _IMAGE_FORMATS[image_inspection.format] is not envelope.document_format:
            raise DocumentTypeMismatchError(
                "Image signature and decoded format are inconsistent"
            )
        result = DocumentInspectionResult(
            envelope=envelope,
            inspection=ImageDocumentInspection(inspection=image_inspection),
            image_frame_count=image_inspection.frame_count,
            warnings=detection.warnings,
        )
    _assert_source_unchanged(path, envelope)
    return result


def _local_ocr_inspection_result(
    prepared_source: _LocalOcrPreparedSource,
) -> DocumentInspectionResult:
    """Project one Local-aware inspection into the Unified inspection model."""
    detection = prepared_source.detection
    envelope = detection.envelope
    if envelope.document_type is DocumentType.PDF and isinstance(
        prepared_source.inspection,
        PdfInspection,
    ):
        return DocumentInspectionResult(
            envelope=envelope,
            inspection=PdfDocumentInspection(inspection=prepared_source.inspection),
            pdf_page_count=prepared_source.inspection.page_count,
            warnings=detection.warnings,
        )
    if envelope.document_type is DocumentType.IMAGE and isinstance(
        prepared_source.inspection,
        ImageInspection,
    ):
        return DocumentInspectionResult(
            envelope=envelope,
            inspection=ImageDocumentInspection(inspection=prepared_source.inspection),
            image_frame_count=prepared_source.inspection.frame_count,
            warnings=detection.warnings,
        )
    raise DocumentTypeMismatchError(
        "The Local OCR prepared inspection is inconsistent"
    ) from ValueError("redacted")


def _analyze_docx_detected(
    path: Path,
    detection: DocumentTypeDetection,
    *,
    options: object | None,
    limits: object | None,
) -> tuple[DocumentInspectionResult, DocxAnalysisResult]:
    """Parse one detected DOCX once and retain both inspection and analysis."""
    envelope = detection.envelope
    with _adapter_path(
        path,
        envelope.document_format,
        envelope.sha256,
        envelope.byte_size,
    ) as adapter:
        raw_result = analyze_docx(
            adapter,
            options=options,  # type: ignore[arg-type]
            limits=limits,  # type: ignore[arg-type]
        )
    docx_inspection = _normalize_docx(raw_result.inspection, envelope)
    docx_warnings = tuple(
        warning
        for warning in raw_result.warnings
        if warning.category != "extension_mismatch"
    )
    combined_warnings = detection.warnings + docx_warnings
    docx_inspection = docx_inspection.model_copy(update={"warnings": combined_warnings})
    normalized_document = _normalize_document(raw_result.document, envelope)
    normalized_result = DocxAnalysisResult(
        inspection=docx_inspection,
        structure=raw_result.structure,
        document=normalized_document,
        warnings=combined_warnings,
        issues=raw_result.issues,
        processing_manifest=raw_result.processing_manifest,
    )
    inspection = DocumentInspectionResult(
        envelope=envelope,
        inspection=DocxDocumentInspection(inspection=docx_inspection),
        docx_block_count=docx_inspection.block_count,
        warnings=combined_warnings,
    )
    _assert_source_unchanged(path, envelope)
    return inspection, normalized_result


def _direct_image_options_valid(
    options: StructuredExtractionOptions | None,
) -> bool:
    if options is None:
        return True
    return (
        options.strategy is ExtractionStrategy.HYBRID_EXISTING
        and options.pages is None
        and options.locale is None
        and not options.features
    )


def _structured_quality_policy(
    options: DocumentAnalysisOptions,
) -> object | None:
    structured = options.structured_extraction_options
    return None if structured is None else structured.local_ocr_quality_policy


def _analysis_options_identity_payload(
    options: DocumentAnalysisOptions,
) -> dict[str, Any]:
    """Keep disabled quality absent from the pre-quality identity contract."""
    payload = cast(
        "dict[str, Any]",
        DocumentAnalysisOptions.__pydantic_serializer__.to_python(
            options,
            mode="json",
            round_trip=True,
            warnings="error",
        ),
    )
    structured = payload.get("structured_extraction_options")
    if (
        isinstance(structured, dict)
        and structured.get("local_ocr_quality_policy") is None
    ):
        structured.pop("local_ocr_quality_policy", None)
    return payload


def _local_quality_enabled(
    options: DocumentAnalysisOptions,
    ocr_provider: OcrProvider | None,
) -> bool:
    """Read only validated policy identity without consulting Provider Context."""
    from document_sdk.ocr.local import _local_ocr_quality_policy  # noqa: PLC0415

    return (
        _structured_quality_policy(options) is not None
        or _local_ocr_quality_policy(ocr_provider) is not None
    )


def _expected_local_quality_policy(
    provider: OcrProvider | None,
    *,
    enabled: bool,
) -> LocalOcrIntrinsicQualityPolicy | None:
    """Return the exact intrinsic policy expected from one Provider result."""
    from document_sdk.ocr.local import _local_ocr_quality_policy  # noqa: PLC0415

    policy = _local_ocr_quality_policy(provider)
    if policy is not None:
        return policy
    return LocalOcrIntrinsicQualityPolicy() if enabled else None


def _validate_quality_request_before_detection(
    *,
    options: DocumentAnalysisOptions,
    extraction_schema: ExtractionSchema | None,
    ocr_provider: OcrProvider | None,
) -> None:
    """Reject schema/provider quality conflicts before content detection."""
    structured = options.structured_extraction_options
    structured_policy = (
        None if structured is None else structured.local_ocr_quality_policy
    )
    if options.azure_fallback_policy is not None:
        from document_sdk.ocr.local import (  # noqa: PLC0415
            _is_local_ocr_provider_instance,
            _local_ocr_quality_policy,
        )

        if not _is_local_ocr_provider_instance(ocr_provider):
            raise AzureFallbackConfigurationError(
                "Azure fallback requires an explicit Local OCR Provider"
            )
        intrinsic_policy = _local_ocr_quality_policy(ocr_provider)
        if intrinsic_policy is None and (
            structured_policy is None or extraction_schema is None
        ):
            raise AzureFallbackConfigurationError(
                "Azure fallback requires an explicit Local OCR quality policy"
            )
        if structured_policy is not None and extraction_schema is None:
            raise AzureFallbackConfigurationError(
                "Structured Azure fallback quality requires an extraction schema"
            )
    if structured_policy is None:
        return
    if extraction_schema is None:
        from document_sdk.ocr.local_errors import (  # noqa: PLC0415
            LocalOcrQualityConfigurationError,
        )

        msg = "Structured Local OCR quality policy requires an extraction schema"
        raise LocalOcrQualityConfigurationError(msg)
    if structured is None:
        raise AzureFallbackConfigurationError(
            "Structured Local OCR quality configuration is incomplete"
        )
    _validate_local_quality_provider(structured, ocr_provider)


def _validate_request(
    document_type: DocumentType,
    *,
    options: DocumentAnalysisOptions,
    extraction_schema: ExtractionSchema | None,
    ocr_provider: OcrProvider | None,
) -> None:
    """Reject every ignored or conflicting option before Provider access."""
    has_schema = extraction_schema is not None
    quality_enabled = _local_quality_enabled(options, ocr_provider)
    if quality_enabled and document_type in {DocumentType.EXCEL, DocumentType.WORD}:
        from document_sdk.ocr.local_errors import (  # noqa: PLC0415
            LocalOcrQualityConfigurationError,
        )

        msg = "Local OCR quality policy is incompatible with this document family"
        raise LocalOcrQualityConfigurationError(msg)
    if document_type is not DocumentType.WORD and options.docx_options is not None:
        raise UnsupportedDocumentOperationError(
            "DOCX options are incompatible with this document family"
        )
    if document_type is DocumentType.PDF:
        if has_schema:
            if (
                options.pdf_mode is not PdfAnalysisMode.NATIVE
                or options.hybrid_pdf_options is not None
            ):
                raise UnsupportedDocumentOperationError(
                    "PDF structured extraction cannot combine unified "
                    "PDF routing options"
                )
            structured_options = (
                options.structured_extraction_options or StructuredExtractionOptions()
            )
            if (
                structured_options.strategy
                in {
                    ExtractionStrategy.PROVIDER_EXISTING,
                    ExtractionStrategy.PROVIDER_QUERY_FIELDS,
                }
                and ocr_provider is None
            ):
                raise UnsupportedDocumentOperationError(
                    "The selected PDF extraction strategy requires an OCR Provider"
                )
            if (
                structured_options.strategy is ExtractionStrategy.PROVIDER_QUERY_FIELDS
                and extraction_schema is not None
                and len(extraction_schema.fields) > _MAX_QUERY_FIELDS
            ):
                raise UnsupportedDocumentOperationError(
                    "The Query Fields schema exceeds the supported field limit"
                )
        else:
            if options.structured_extraction_options is not None:
                raise UnsupportedDocumentOperationError(
                    "Structured extraction options require an extraction schema"
                )
            if options.pdf_mode is PdfAnalysisMode.NATIVE and ocr_provider is not None:
                raise UnsupportedDocumentOperationError(
                    "Native PDF analysis cannot accept an OCR Provider"
                )
        return
    if options.pdf_mode is not PdfAnalysisMode.NATIVE or (
        options.hybrid_pdf_options is not None
    ):
        raise UnsupportedDocumentOperationError(
            "PDF routing options are incompatible with this document family"
        )
    if document_type is DocumentType.IMAGE:
        if not has_schema:
            if options.structured_extraction_options is not None:
                raise UnsupportedDocumentOperationError(
                    "Structured extraction options require an extraction schema"
                )
        else:
            if ocr_provider is None:
                raise UnsupportedDocumentOperationError(
                    "Image structured extraction requires an explicit OCR Provider"
                )
            if not _direct_image_options_valid(options.structured_extraction_options):
                raise UnsupportedDocumentOperationError(
                    "Image structured extraction options are incompatible "
                    "with direct extraction"
                )
        return
    if document_type is DocumentType.WORD:
        if options.pdf_mode is not PdfAnalysisMode.NATIVE or (
            options.hybrid_pdf_options is not None
        ):
            raise UnsupportedDocumentOperationError(
                "PDF routing options are incompatible with DOCX"
            )
        if ocr_provider is not None:
            raise UnsupportedDocumentOperationError(
                "DOCX analysis does not accept an OCR Provider"
            )
        if not has_schema and options.structured_extraction_options is not None:
            raise UnsupportedDocumentOperationError(
                "Structured extraction options require an extraction schema"
            )
        if has_schema and not _direct_image_options_valid(
            options.structured_extraction_options
        ):
            raise UnsupportedDocumentOperationError(
                "DOCX supports only local deterministic Structured Extraction"
            )
        return
    if (
        has_schema
        or ocr_provider is not None
        or options.structured_extraction_options is not None
    ):
        raise UnsupportedDocumentOperationError(
            "Excel does not accept OCR or structured extraction options"
        )


def _validated_docx_limits(
    limits: DocxProcessingLimits,
) -> DocxProcessingLimits:
    try:
        return _revalidate_model_instance_json(
            limits,
            DocxProcessingLimits,
            "DOCX processing limits are invalid",
        )
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            DocumentTypeMismatchError("DOCX processing limits are invalid"),
        )


def _validated_family_limits(
    limits: object | None,
) -> ImageProcessingLimits | PdfProcessingLimits | DocxProcessingLimits | None:
    """Rebuild one supported family limit before source detection or access."""
    if limits is None:
        return None
    stable_message = "Document processing limits are invalid"
    actual_type = type(limits)
    if not any(
        issubclass(actual_type, expected_type)
        for expected_type in (
            PdfProcessingLimits,
            ImageProcessingLimits,
            DocxProcessingLimits,
        )
    ):
        raise DocumentTypeMismatchError(stable_message) from ValueError("redacted")
    try:
        if issubclass(actual_type, PdfProcessingLimits):
            return _revalidate_model_instance_json(
                cast("PdfProcessingLimits", limits),
                PdfProcessingLimits,
                stable_message,
            )
        if issubclass(actual_type, ImageProcessingLimits):
            return _revalidate_model_instance_json(
                cast("ImageProcessingLimits", limits),
                ImageProcessingLimits,
                stable_message,
            )
        if issubclass(actual_type, DocxProcessingLimits):
            return _validated_docx_limits(cast("DocxProcessingLimits", limits))
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            DocumentTypeMismatchError(stable_message),
        )
    raise DocumentTypeMismatchError(stable_message) from ValueError("redacted")


def _validate_family_limits(
    document_type: DocumentType,
    limits: object | None,
) -> None:
    if limits is None:
        return
    expected: type[object] | None = {
        DocumentType.PDF: PdfProcessingLimits,
        DocumentType.IMAGE: ImageProcessingLimits,
        DocumentType.WORD: DocxProcessingLimits,
    }.get(document_type)
    if expected is None or type(limits) is not expected:
        raise DocumentTypeMismatchError(
            "The supplied processing limits do not match the document family"
        ) from ValueError("redacted")


def _ooxml_classification_limits(
    requested: DocxProcessingLimits | None,
) -> DocxProcessingLimits:
    """Keep shared OOXML family detection no stricter than SDK defaults."""
    defaults = DocxProcessingLimits()
    if requested is None:
        return defaults
    return defaults.model_copy(
        update={
            field_name: max(
                getattr(defaults, field_name),
                getattr(requested, field_name),
            )
            for field_name in (
                "max_package_members",
                "max_member_uncompressed_bytes",
                "max_total_uncompressed_bytes",
                "max_compression_ratio",
                "max_xml_part_bytes",
                "max_xml_parts",
                "max_total_xml_bytes",
                "max_xml_elements",
                "max_xml_depth",
                "max_relationships",
            )
        }
    )


def _prepare_local_ocr_source(
    provider: object,
    path: Path,
    detection: DocumentTypeDetection,
    *,
    limits: ImageProcessingLimits | PdfProcessingLimits | None,
    error_message: str,
) -> _LocalOcrPreparedSource:
    """Prepare through the base implementation without trusting subclass errors."""
    from document_sdk.ocr.local import LocalOcrProvider  # noqa: PLC0415

    try:
        return LocalOcrProvider._prepare_source(  # noqa: SLF001
            cast("LocalOcrProvider", provider),
            path,
            detection,
            limits=limits,
        )
    except Exception as exc:
        if type(provider) is LocalOcrProvider and issubclass(
            type(exc),
            DocumentSdkError,
        ):
            raise
        _raise_redacted_translation(exc, DocumentProcessingError(error_message))


def _prepare_document(
    path: Path,
    *,
    limits: object | None = None,
    expected_identity: tuple[str, int] | None = None,
    options: DocumentAnalysisOptions | None = None,
    extraction_schema: ExtractionSchema | None = None,
    ocr_provider: OcrProvider | None = None,
    max_identity_bytes: int | None = None,
) -> _PreparedDocument:
    validated_limits = _validated_family_limits(limits)
    requested_docx_limits = (
        validated_limits if type(validated_limits) is DocxProcessingLimits else None
    )
    classification_limits = _ooxml_classification_limits(requested_docx_limits)
    detection = _detect_identity(
        path,
        expected_identity=expected_identity,
        max_bytes=max_identity_bytes,
        ooxml_limits=classification_limits,
    )
    _validate_family_limits(detection.envelope.document_type, validated_limits)
    if options is not None:
        _validate_request(
            detection.envelope.document_type,
            options=options,
            extraction_schema=extraction_schema,
            ocr_provider=ocr_provider,
        )
    docx_analysis: DocxAnalysisResult | None = None
    local_ocr_source: _LocalOcrPreparedSource | None = None
    if detection.envelope.document_type is DocumentType.WORD:
        inspection, docx_analysis = _analyze_docx_detected(
            path,
            detection,
            options=None if options is None else options.docx_options,
            limits=requested_docx_limits or DocxProcessingLimits(),
        )
    elif detection.envelope.document_type in {DocumentType.PDF, DocumentType.IMAGE}:
        from document_sdk.ocr.local import (  # noqa: PLC0415
            _uses_local_ocr_prepared_route,
        )

        if _uses_local_ocr_prepared_route(ocr_provider):
            local_ocr_source = _prepare_local_ocr_source(
                ocr_provider,
                path,
                detection,
                limits=cast(
                    "ImageProcessingLimits | PdfProcessingLimits | None",
                    validated_limits,
                ),
                error_message="Local OCR source preparation failed",
            )
            inspection = _local_ocr_inspection_result(local_ocr_source)
        else:
            inspection = _inspect_detected(
                path,
                detection,
                limits=validated_limits,
            )
    else:
        inspection = _inspect_detected(path, detection, limits=validated_limits)
    return _PreparedDocument(
        source=path,
        detection=detection,
        inspection=inspection,
        docx_analysis=docx_analysis,
        local_ocr_source=local_ocr_source,
    )


def detect_document_type(path: Path) -> DocumentTypeDetection:
    """Detect and validate PDF, OOXML spreadsheet, or image content."""
    prepared = _prepare_document(path)
    return prepared.detection


def inspect_document(
    path: Path,
    *,
    limits: object | None = None,
) -> DocumentInspectionResult:
    """Inspect a detected family through its existing public inspection API."""
    return _prepare_document(path, limits=limits).inspection


def _provider_identity(
    provider: OcrProvider | None,
) -> tuple[str, str, str | None] | None:
    if provider is None:
        return None
    return _read_provider_identity_safely(
        provider,
        error=DocumentProcessingError("OCR Provider context metadata is invalid"),
    )


def _provider_resume_fingerprint(provider: OcrProvider | None) -> str | None:
    """Hash only safe immutable Provider configuration for processing identity."""
    if provider is None:
        return None
    projection = _read_provider_context_projection_safely(
        provider,
        error=DocumentProcessingError("OCR Provider processing identity is invalid"),
    )
    return projection.resume_fingerprint


def _validate_provider_result(
    result: object,
    *,
    identity: tuple[str, str, str | None],
    expected_local_quality_policy: LocalOcrIntrinsicQualityPolicy | None,
) -> ProcessingResult[Document]:
    result = _revalidate_document_processing_result(result)
    provider_name, profile_id, model_id = identity
    metadata = result.metadata
    if (
        metadata.provider_name != provider_name
        or metadata.profile_id != profile_id
        or metadata.model_id != model_id
    ):
        raise DocumentProcessingError("OCR Provider result identity is inconsistent")
    usage = metadata.provider_usage
    if usage is not None and (
        usage.provider_name != provider_name
        or usage.profile_id != profile_id
        or usage.model_id != model_id
    ):
        raise DocumentProcessingError("OCR Provider usage identity is inconsistent")
    try:
        _validate_local_ocr_provider_quality_result(
            report=metadata.local_ocr_quality_report,
            usage=usage,
            expected_policy=expected_local_quality_policy,
            preprocessing_report=metadata.local_ocr_preprocessing_report,
        )
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            DocumentProcessingError(
                "OCR Provider Local quality evidence is inconsistent"
            ),
        )
    return result


def _schema_fingerprint(schema: ExtractionSchema | None) -> str | None:
    if schema is None:
        return None
    serialized = ExtractionSchema.__pydantic_serializer__.to_json(
        schema,
        by_alias=True,
        round_trip=True,
        warnings="error",
    )
    return hashlib.sha256(serialized).hexdigest()


def _sorted_counts(counts: list[OperationCount]) -> tuple[OperationCount, ...]:
    return tuple(sorted(counts, key=lambda count: count.name))


def _processing_manifest(
    envelope: DocumentEnvelope,
    *,
    options: DocumentAnalysisOptions,
    schema: ExtractionSchema | None,
    provider_profile_id: str | None,
    provider_resume_fingerprint: str | None,
    provider_usage: ProviderUsage | None,
    provider_usage_breakdown: tuple[ProviderUsage, ...],
    cloud_execution_attempts: tuple[CloudExecutionAttemptEvidence, ...],
    local_ocr_quality_report: LocalOcrQualityReport | None,
    local_ocr_preprocessing_report: LocalOcrPreprocessingReport | None,
    azure_fallback_report: AzurePageFallbackReport | None,
    local_ocr_quality_enabled: bool,
    operation_counts: tuple[OperationCount, ...],
) -> DocumentProcessingManifest:
    schema_hash = _schema_fingerprint(schema)
    evidence = {
        "source_sha256": envelope.sha256,
        "sdk_version": __version__,
        "document_type": envelope.document_type.value,
        "document_format": envelope.document_format.value,
        "options": _analysis_options_identity_payload(options),
        "schema_id": None if schema is None else schema.schema_id,
        "schema_version": None if schema is None else schema.schema_version,
        "schema_fingerprint": schema_hash,
        "provider_profile_id": provider_profile_id,
        "provider_resume_fingerprint": provider_resume_fingerprint,
        "provider_usage": (
            None if provider_usage is None else provider_usage.model_dump(mode="json")
        ),
        "cloud_execution_attempts": [
            attempt.model_dump(mode="json") for attempt in cloud_execution_attempts
        ],
    }
    structured_quality_policy = (
        None
        if options.structured_extraction_options is None
        else options.structured_extraction_options.local_ocr_quality_policy
    )
    if structured_quality_policy is not None:
        evidence["local_ocr_quality_identity"] = local_ocr_quality_identity(
            intrinsic_policy=LocalOcrIntrinsicQualityPolicy(),
            structured_policy=structured_quality_policy,
        )
    elif local_ocr_quality_enabled:
        evidence["local_ocr_quality_algorithm_version"] = (
            LOCAL_OCR_QUALITY_ALGORITHM_VERSION
        )
    fingerprint = hashlib.sha256(
        json.dumps(evidence, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    return DocumentProcessingManifest(
        source_sha256=envelope.sha256,
        sdk_version=__version__,
        document_type=envelope.document_type,
        document_format=envelope.document_format,
        processing_fingerprint=fingerprint,
        schema_id=None if schema is None else schema.schema_id,
        schema_version=None if schema is None else schema.schema_version,
        schema_fingerprint=schema_hash,
        provider_profile_id=provider_profile_id,
        provider_usage=provider_usage,
        provider_usage_breakdown=provider_usage_breakdown,
        cloud_execution_attempts=cloud_execution_attempts,
        local_ocr_quality_summary=(
            None
            if local_ocr_quality_report is None
            else local_ocr_quality_report.summary
        ),
        local_ocr_preprocessing_summary=(
            None
            if local_ocr_preprocessing_report is None
            else local_ocr_preprocessing_report.summary()
        ),
        azure_fallback_summary=azure_fallback_report,
        azure_fallback_policy_fingerprint=(
            None
            if azure_fallback_report is None
            else azure_fallback_report.policy_fingerprint
        ),
        operation_counts=operation_counts,
    )


def _validated_azure_fallback_evidence(
    *,
    policy: AzurePageFallbackPolicy,
    quality_report: LocalOcrQualityReport,
    local_document: Document,
) -> tuple[AzurePageFallbackPolicy, LocalOcrQualityReport, Document]:
    """Losslessly revalidate every in-memory fallback input before source access."""
    try:
        validated_policy = _validate_azure_fallback_policy(policy)
        validated_quality = _revalidate_model_instance_json(
            quality_report,
            LocalOcrQualityReport,
            "Azure fallback quality report is invalid",
        )
        validated_document = _revalidate_model_instance_json(
            local_document,
            Document,
            "Azure fallback Local document is invalid",
        )
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            AzureFallbackInvalidResultError(
                "Azure fallback request evidence is invalid"
            ),
        )
    return validated_policy, validated_quality, validated_document


def _azure_fallback_plan(
    *,
    policy: AzurePageFallbackPolicy,
    quality_report: LocalOcrQualityReport,
    local_document: Document,
    azure_provider: object,
) -> _AzureFallbackPlan:
    """Plan bounded fallback indexes without retaining source or OCR content."""
    if not _is_actual_azure_provider(azure_provider):
        raise AzureFallbackConfigurationError(
            "Azure fallback requires an explicit built-in Azure Provider"
        )
    source_kind, candidates = _fallback_candidates(quality_report, local_document)
    _enforce_candidate_limits(
        kind=source_kind,
        count=len(candidates),
        policy=policy,
    )
    return _AzureFallbackPlan(
        source_kind=source_kind,
        candidates=candidates,
        policy=policy,
        quality_summary=quality_report.summary,
    )


def _attach_completed_cloud_result_safely(
    error: BaseException,
    usage: ProviderUsage | None,
    attempts: tuple[CloudExecutionAttemptEvidence, ...],
) -> None:
    """Retain only one validated completed direct-cloud result on a failure."""
    if usage is None or len(attempts) != 1:
        return
    try:
        attach_completed_cloud_result(error, usage, attempts[0])
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception:
        return


@contextmanager
def _preserve_completed_cloud_result(
    usage: ProviderUsage | None,
    attempts: tuple[CloudExecutionAttemptEvidence, ...],
) -> Iterator[None]:
    """Carry confirmed direct-cloud cost evidence across downstream failures."""
    try:
        yield
    except (KeyboardInterrupt, SystemExit, GeneratorExit):
        raise
    except Exception as exc:
        _attach_completed_cloud_result_safely(exc, usage, attempts)
        raise


def _analyze_prepared_document(
    prepared: _PreparedDocument,
    *,
    options: DocumentAnalysisOptions,
    extraction_schema: ExtractionSchema | None,
    ocr_provider: OcrProvider | None,
    azure_fallback_provider: object | None,
    limits: object | None,
    local_invocation_state: _LocalOcrInvocationState | None = None,
) -> DocumentAnalysisResult:
    """Analyze one already detected and inspected source without repeating either."""
    path = prepared.source
    inspection_result = prepared.inspection
    envelope = inspection_result.envelope
    _validate_request(
        envelope.document_type,
        options=options,
        extraction_schema=extraction_schema,
        ocr_provider=ocr_provider,
    )
    provider_identity = _provider_identity(ocr_provider)
    provider_resume_fingerprint = _provider_resume_fingerprint(ocr_provider)
    structured: StructuredExtractionResult | None = None
    warnings = inspection_result.warnings
    issues: tuple[ProcessingError, ...] = ()
    provider_usage: ProviderUsage | None = None
    local_ocr_quality_report: LocalOcrQualityReport | None = None
    local_ocr_preprocessing_report: LocalOcrPreprocessingReport | None = None
    azure_fallback_report: AzurePageFallbackReport | None = None
    completed_fallback: AzurePageFallbackResult | None = None
    completed_fallback_evidence: AzureFallbackAttemptEvidence | None = None
    provider_usage_breakdown: tuple[ProviderUsage, ...] = ()
    cloud_execution_attempts: tuple[CloudExecutionAttemptEvidence, ...] = ()
    local_ocr_quality_enabled = _local_quality_enabled(options, ocr_provider)
    operations: list[OperationCount] = [
        OperationCount(name="detection", count=1),
        OperationCount(name="inspection", count=1),
    ]
    analysis: (
        PdfDocumentAnalysis
        | ImageDocumentAnalysis
        | ExcelDocumentAnalysis
        | DocxDocumentAnalysis
    )

    if envelope.document_type is DocumentType.PDF:
        if extraction_schema is not None:
            with _adapter_path(
                path,
                envelope.document_format,
                envelope.sha256,
                envelope.byte_size,
                always_snapshot=ocr_provider is not None,
            ) as adapter:
                if ocr_provider is not None:
                    _assert_source_unchanged(path, envelope)
                if prepared.local_ocr_source is None:
                    structured = analyze_pdf_structured(
                        adapter,
                        extraction_schema,
                        ocr_provider=ocr_provider,
                        options=options.structured_extraction_options,
                        limits=limits,  # type: ignore[arg-type]
                    )
                else:
                    structured = _analyze_pdf_structured_prepared(
                        adapter,
                        extraction_schema,
                        inspection=cast(
                            "PdfInspection",
                            prepared.local_ocr_source.inspection,
                        ),
                        ocr_provider=ocr_provider,
                        options=options.structured_extraction_options,
                        limits=cast(
                            "PdfProcessingLimits",
                            prepared.local_ocr_source.inspection_limits,
                        ),
                        local_prepared_source=prepared.local_ocr_source,
                        local_invocation_state=local_invocation_state,
                    )
            provider_usage = structured.provider_usage
            if structured.cloud_execution_attempt is not None:
                cloud_execution_attempts = (structured.cloud_execution_attempt,)
            with _preserve_completed_cloud_result(
                provider_usage,
                cloud_execution_attempts,
            ):
                structured = _revalidate_structured_extraction_result(
                    structured.model_copy(
                        update={
                            "document": _normalize_document(
                                structured.document,
                                envelope,
                            )
                        }
                    )
                )
                analysis = PdfDocumentAnalysis(document=structured.document)
                warnings += structured.warnings
                local_ocr_quality_report = structured.local_ocr_quality_report
                local_ocr_preprocessing_report = (
                    structured.local_ocr_preprocessing_report
                )
                operations.append(OperationCount(name="structured_extraction", count=1))
        elif options.pdf_mode is PdfAnalysisMode.HYBRID:
            with _adapter_path(
                path,
                envelope.document_format,
                envelope.sha256,
                envelope.byte_size,
                always_snapshot=ocr_provider is not None,
            ) as adapter:
                if ocr_provider is not None:
                    _assert_source_unchanged(path, envelope)
                if prepared.local_ocr_source is None:
                    processing = analyze_pdf_hybrid(
                        adapter,
                        ocr_provider=ocr_provider,
                        options=options.hybrid_pdf_options,
                        limits=limits,  # type: ignore[arg-type]
                    )
                else:
                    processing = _analyze_pdf_hybrid_prepared(
                        adapter,
                        inspection=cast(
                            "PdfInspection",
                            prepared.local_ocr_source.inspection,
                        ),
                        ocr_provider=ocr_provider,
                        options=options.hybrid_pdf_options,
                        limits=cast(
                            "PdfProcessingLimits",
                            prepared.local_ocr_source.inspection_limits,
                        ),
                        local_prepared_source=prepared.local_ocr_source,
                        local_invocation_state=local_invocation_state,
                    )
            provider_usage = processing.metadata.provider_usage
            if processing.metadata.cloud_execution_attempt is not None:
                cloud_execution_attempts = (
                    processing.metadata.cloud_execution_attempt,
                )
            with _preserve_completed_cloud_result(
                provider_usage,
                cloud_execution_attempts,
            ):
                if processing.data is None:
                    raise DocumentProcessingError(
                        "Hybrid PDF analysis returned no document"
                    )
                normalized = _normalize_document(processing.data, envelope)
                processing = processing.model_copy(update={"data": normalized})
                analysis = PdfDocumentAnalysis(
                    document=normalized,
                    processing_result=processing,
                )
                warnings += processing.warnings
                issues = processing.errors
                local_ocr_quality_report = processing.metadata.local_ocr_quality_report
                local_ocr_preprocessing_report = (
                    processing.metadata.local_ocr_preprocessing_report
                )
                operations.append(OperationCount(name="hybrid_pdf", count=1))
        else:
            with _adapter_path(
                path,
                envelope.document_format,
                envelope.sha256,
                envelope.byte_size,
            ) as adapter:
                document = extract_native_text(
                    adapter,
                    limits=limits,  # type: ignore[arg-type]
                )
            analysis = PdfDocumentAnalysis(
                document=_normalize_document(document, envelope)
            )
            operations.append(OperationCount(name="native_pdf", count=1))
    elif envelope.document_type is DocumentType.IMAGE:
        image_payload = cast("ImageDocumentInspection", inspection_result.inspection)
        if extraction_schema is None and ocr_provider is None:
            analysis = ImageDocumentAnalysis(image=image_payload.inspection)
        else:
            if ocr_provider is None or provider_identity is None:
                raise UnsupportedDocumentOperationError(
                    "Image structured extraction requires an explicit OCR Provider"
                )
            _assert_source_unchanged(path, envelope)
            with _adapter_path(
                path,
                envelope.document_format,
                envelope.sha256,
                envelope.byte_size,
                always_snapshot=True,
            ) as adapter:
                _assert_source_unchanged(path, envelope)
                if prepared.local_ocr_source is None:
                    ocr_result = _invoke_ocr_provider_safely(
                        ocr_provider,
                        "analyze",
                        adapter,
                        options=OcrAnalysisOptions(),
                        error_message="Image OCR Provider analysis failed",
                    )
                else:
                    ocr_result = _invoke_ocr_provider_safely(
                        ocr_provider,
                        "_analyze_prepared",
                        adapter,
                        prepared.local_ocr_source,
                        options=OcrAnalysisOptions(),
                        usage_budget=None,
                        enable_quality=(
                            options.structured_extraction_options is not None
                            and (
                                options.structured_extraction_options.local_ocr_quality_policy
                                is not None
                            )
                        ),
                        error_message="Image OCR Provider analysis failed",
                        invocation_state=local_invocation_state,
                    )
            ocr_result = _validate_provider_result(
                ocr_result,
                identity=provider_identity,
                expected_local_quality_policy=_expected_local_quality_policy(
                    ocr_provider,
                    enabled=local_ocr_quality_enabled,
                ),
            )
            provider_usage = ocr_result.metadata.provider_usage
            if ocr_result.metadata.cloud_execution_attempt is not None:
                cloud_execution_attempts = (
                    ocr_result.metadata.cloud_execution_attempt,
                )
            with _preserve_completed_cloud_result(
                provider_usage,
                cloud_execution_attempts,
            ):
                if ocr_result.data is None:
                    raise DocumentProcessingError(
                        "Image OCR Provider returned no document"
                    )
                normalized = _normalize_document(ocr_result.data, envelope)
                ocr_result = ocr_result.model_copy(update={"data": normalized})
                local_ocr_quality_report = ocr_result.metadata.local_ocr_quality_report
                local_ocr_preprocessing_report = (
                    ocr_result.metadata.local_ocr_preprocessing_report
                )
                analysis = ImageDocumentAnalysis(
                    image=image_payload.inspection,
                    ocr_result=ocr_result,
                )
                warnings += ocr_result.warnings
                issues = ocr_result.errors
                operations.append(OperationCount(name="ocr_provider", count=1))
                if extraction_schema is not None:
                    structured = _extract_structured_fields_with_quality(
                        normalized,
                        extraction_schema,
                        options=options.structured_extraction_options,
                        intrinsic_quality_report=local_ocr_quality_report,
                        provider_usage=provider_usage,
                        preprocessing_report=local_ocr_preprocessing_report,
                    )
                    structured = _revalidate_structured_extraction_result(
                        structured.model_copy(
                            update={
                                "provider_usage": provider_usage,
                                "cloud_execution_attempt": (
                                    ocr_result.metadata.cloud_execution_attempt
                                ),
                                "local_ocr_preprocessing_report": (
                                    local_ocr_preprocessing_report
                                ),
                            }
                        )
                    )
                    warnings += structured.warnings
                    local_ocr_quality_report = structured.local_ocr_quality_report
                    operations.append(
                        OperationCount(name="structured_extraction", count=1)
                    )
    elif envelope.document_type is DocumentType.WORD:
        docx_result = prepared.docx_analysis
        if docx_result is None:
            raise DocumentProcessingError(
                "The prepared DOCX analysis evidence is incomplete"
            )
        docx_inspection_payload = cast(
            "DocxDocumentInspection", inspection_result.inspection
        )
        normalized_document = docx_result.document
        if docx_result.inspection != docx_inspection_payload.inspection:
            raise DocumentProcessingError(
                "The prepared DOCX inspection evidence is inconsistent"
            )
        if extraction_schema is not None:
            structured = extract_structured_fields(
                normalized_document,
                extraction_schema,
                options=options.structured_extraction_options,
            )
            warnings = inspection_result.warnings + structured.warnings
            operations.append(OperationCount(name="structured_extraction", count=1))
        else:
            warnings = inspection_result.warnings
        analysis = DocxDocumentAnalysis(docx=docx_result)
        operations.append(OperationCount(name="docx_analysis", count=1))
    else:
        excel_payload = cast("ExcelDocumentInspection", inspection_result.inspection)
        analysis = ExcelDocumentAnalysis(workbook=excel_payload.inspection)

    fallback_policy = options.azure_fallback_policy
    if fallback_policy is not None and local_ocr_quality_report is not None:
        if local_ocr_preprocessing_report is not None:
            try:
                (
                    local_ocr_preprocessing_report,
                    local_ocr_quality_report,
                ) = _validate_preprocessing_quality_lineage(
                    local_ocr_preprocessing_report,
                    local_ocr_quality_report,
                )
            except (KeyboardInterrupt, SystemExit, GeneratorExit):
                raise
            except Exception as exc:
                _raise_redacted_translation(
                    exc,
                    DocumentProcessingError(
                        "Fallback preprocessing quality evidence is inconsistent"
                    ),
                )
        if isinstance(analysis, PdfDocumentAnalysis):
            local_document = analysis.document
        elif isinstance(analysis, ImageDocumentAnalysis):
            if analysis.ocr_result is None or analysis.ocr_result.data is None:
                raise DocumentProcessingError(
                    "Image fallback requires a Local OCR document"
                )
            local_document = analysis.ocr_result.data
        else:
            raise AzureFallbackConfigurationError(
                "Azure fallback is unsupported for this document family"
            )
        (
            validated_fallback_policy,
            validated_fallback_quality,
            validated_local_document,
        ) = _validated_azure_fallback_evidence(
            policy=fallback_policy,
            quality_report=local_ocr_quality_report,
            local_document=local_document,
        )
        fallback_plan = _azure_fallback_plan(
            policy=validated_fallback_policy,
            quality_report=validated_fallback_quality,
            local_document=validated_local_document,
            azure_provider=azure_fallback_provider,
        )
        if fallback_plan.candidates:
            with _adapter_path(
                path,
                envelope.document_format,
                envelope.sha256,
                envelope.byte_size,
                always_snapshot=True,
            ) as fallback_source:
                fallback = _apply_prepared_azure_page_fallback(
                    fallback_source,
                    local_document=validated_local_document,
                    quality_report=validated_fallback_quality,
                    policy=validated_fallback_policy,
                    azure_provider=azure_fallback_provider,
                    pdf_limits=(
                        limits if type(limits) is PdfProcessingLimits else None
                    ),
                    image_limits=(
                        limits if type(limits) is ImageProcessingLimits else None
                    ),
                    source_verifier=lambda: _assert_source_unchanged(path, envelope),
                )
        else:
            _assert_source_unchanged(path, envelope)
            fallback = _apply_prepared_azure_page_fallback(
                path,
                local_document=validated_local_document,
                quality_report=validated_fallback_quality,
                policy=validated_fallback_policy,
                azure_provider=azure_fallback_provider,
                pdf_limits=limits if type(limits) is PdfProcessingLimits else None,
                image_limits=(
                    limits if type(limits) is ImageProcessingLimits else None
                ),
                source_verifier=lambda: _assert_source_unchanged(path, envelope),
            )
        azure_fallback_report = fallback.report
        if fallback.report.status is not AzurePageFallbackStatus.NOT_APPLICABLE:
            completed_fallback = fallback
            completed_fallback_evidence = _completed_fallback_attempt_evidence(fallback)
        provider_usage_breakdown = (
            () if provider_usage is None else (provider_usage,)
        ) + fallback.azure_provider_usage
        cloud_execution_attempts += fallback.cloud_execution_attempts
        if fallback.report.status is not AzurePageFallbackStatus.NOT_APPLICABLE:
            if completed_fallback_evidence is None:
                raise DocumentProcessingError(
                    "Completed fallback evidence is unavailable"
                )
            with _fallback_attempt_phase(
                completed_fallback_evidence,
                AzureFallbackInvalidResultError,
                "Completed fallback post-processing failed",
            ):
                if isinstance(analysis, PdfDocumentAnalysis):
                    processing_result = analysis.processing_result
                    if processing_result is not None:
                        processing_result = processing_result.model_copy(
                            update={"data": fallback.document}
                        )
                    analysis = analysis.model_copy(
                        update={
                            "document": fallback.document,
                            "processing_result": processing_result,
                        }
                    )
                else:
                    image_result = analysis.ocr_result
                    if image_result is None:
                        raise DocumentProcessingError(
                            "Image fallback evidence is incomplete"
                        )
                    analysis = analysis.model_copy(
                        update={
                            "ocr_result": image_result.model_copy(
                                update={"data": fallback.document}
                            )
                        }
                    )
                if structured is not None and extraction_schema is not None:
                    structured = _revalidate_structured_extraction_result(
                        _extract_structured_fields_with_quality(
                            fallback.document,
                            extraction_schema,
                            options=options.structured_extraction_options,
                            intrinsic_quality_report=local_ocr_quality_report,
                            provider_usage=provider_usage,
                            cloud_execution_attempt=(
                                None
                                if structured is None
                                else structured.cloud_execution_attempt
                            ),
                            preprocessing_report=local_ocr_preprocessing_report,
                        ).model_copy(
                            update={
                                "provider_usage": provider_usage,
                                "local_ocr_preprocessing_report": (
                                    local_ocr_preprocessing_report
                                ),
                            }
                        )
                    )
                    local_ocr_quality_report = structured.local_ocr_quality_report
                    final_quality = structured.local_ocr_quality_report
                    if final_quality is None:
                        raise DocumentProcessingError(
                            "Structured fallback quality evidence is incomplete"
                        )
                    unresolved_codes = {
                        LocalOcrQualityIssueCode.REQUIRED_FIELDS_MISSING,
                        LocalOcrQualityIssueCode.TABLE_INCOMPLETE,
                    }
                    resolved = not bool(
                        unresolved_codes.intersection(
                            final_quality.summary.reason_codes
                        )
                    )
                    if isinstance(analysis, ImageDocumentAnalysis):
                        image_ocr_result = analysis.ocr_result
                        warnings = (
                            inspection_result.warnings
                            + (
                                ()
                                if image_ocr_result is None
                                else image_ocr_result.warnings
                            )
                            + structured.warnings
                        )
                    else:
                        warnings = inspection_result.warnings + structured.warnings
                    status = (
                        AzurePageFallbackStatus.COMPLETED
                        if resolved
                        else AzurePageFallbackStatus.COMPLETED_UNRESOLVED_STRUCTURED
                    )
                    azure_fallback_report = fallback.report.model_copy(
                        update={
                            "status": status,
                            "structured_recheck_performed": True,
                            "structured_recheck_resolved": resolved,
                            "structured_recheck_summary": final_quality.summary,
                        }
                    )
                    azure_fallback_report = _validate_azure_fallback_report(
                        azure_fallback_report
                    )
    elif provider_usage is not None:
        provider_usage_breakdown = (provider_usage,)

    try:
        _assert_source_unchanged(path, envelope)
    except DocumentSourceChangedError as exc:
        if completed_fallback is None:
            _attach_completed_cloud_result_safely(
                exc,
                provider_usage,
                cloud_execution_attempts,
            )
            raise
        if completed_fallback_evidence is None:
            raise DocumentProcessingError(
                "Completed fallback evidence is unavailable"
            ) from None
        _raise_redacted_translation(
            exc,
            AzureFallbackSourceChangedError(
                "The fallback source changed before its result could be committed",
                attempt_evidence=completed_fallback_evidence,
            ),
        )
    profile_id = None if provider_identity is None else provider_identity[1]
    final_phase = (
        _preserve_completed_cloud_result(provider_usage, cloud_execution_attempts)
        if completed_fallback_evidence is None
        else _fallback_attempt_phase(
            completed_fallback_evidence,
            AzureFallbackInvalidResultError,
            "Completed fallback result commit failed",
        )
    )
    with final_phase:
        manifest = _processing_manifest(
            envelope,
            options=options,
            schema=extraction_schema,
            provider_profile_id=profile_id,
            provider_resume_fingerprint=provider_resume_fingerprint,
            provider_usage=provider_usage,
            provider_usage_breakdown=provider_usage_breakdown,
            cloud_execution_attempts=cloud_execution_attempts,
            local_ocr_quality_report=local_ocr_quality_report,
            local_ocr_preprocessing_report=local_ocr_preprocessing_report,
            azure_fallback_report=azure_fallback_report,
            local_ocr_quality_enabled=local_ocr_quality_enabled,
            operation_counts=_sorted_counts(operations),
        )
        return DocumentAnalysisResult(
            envelope=envelope,
            inspection=inspection_result,
            analysis=analysis,
            structured_extraction=structured,
            warnings=warnings,
            issues=issues,
            provider_usage=provider_usage,
            local_ocr_quality_report=local_ocr_quality_report,
            local_ocr_preprocessing_report=local_ocr_preprocessing_report,
            azure_fallback_report=azure_fallback_report,
            provider_usage_breakdown=provider_usage_breakdown,
            cloud_execution_attempts=cloud_execution_attempts,
            processing_manifest=manifest,
        )


def _analyze_document(
    path: Path,
    *,
    options: DocumentAnalysisOptions | None = None,
    extraction_schema: ExtractionSchema | None = None,
    ocr_provider: OcrProvider | None = None,
    azure_fallback_provider: object | None = None,
    limits: object | None = None,
    local_invocation_state: _LocalOcrInvocationState | None = None,
    expected_identity: tuple[str, int] | None = None,
) -> DocumentAnalysisResult:
    """Analyze one supported document with an optional private Local budget."""
    stable_message = "Document analysis request is invalid"
    try:
        effective_options = (
            DocumentAnalysisOptions()
            if options is None
            else _revalidate_model_instance_json(
                options,
                DocumentAnalysisOptions,
                stable_message,
            )
        )
        validated_schema = (
            None
            if extraction_schema is None
            else _revalidate_model_instance_json(
                extraction_schema,
                ExtractionSchema,
                stable_message,
            )
        )
        effective_limits = _validated_family_limits(limits)
    except Exception as exc:
        _raise_redacted_translation(
            exc,
            DocumentTypeMismatchError(stable_message),
        )
    _validate_quality_request_before_detection(
        options=effective_options,
        extraction_schema=validated_schema,
        ocr_provider=ocr_provider,
    )
    if effective_options.azure_fallback_policy is not None and (
        azure_fallback_provider is None
        or not _is_actual_azure_provider(azure_fallback_provider)
    ):
        raise AzureFallbackConfigurationError(
            "Azure fallback requires an explicit built-in Azure Provider"
        )
    prepared = _prepare_document(
        path,
        limits=effective_limits,
        expected_identity=expected_identity,
        options=effective_options,
        extraction_schema=validated_schema,
        ocr_provider=ocr_provider,
    )
    return _analyze_prepared_document(
        prepared,
        options=effective_options,
        extraction_schema=validated_schema,
        ocr_provider=ocr_provider,
        azure_fallback_provider=azure_fallback_provider,
        limits=effective_limits,
        local_invocation_state=local_invocation_state,
    )


def analyze_document(
    path: Path,
    *,
    options: DocumentAnalysisOptions | None = None,
    extraction_schema: ExtractionSchema | None = None,
    ocr_provider: OcrProvider | None = None,
    azure_fallback_provider: object | None = None,
    limits: object | None = None,
) -> DocumentAnalysisResult:
    """Analyze one supported document with local and Provider use kept explicit."""
    return _analyze_document(
        path,
        options=options,
        extraction_schema=extraction_schema,
        ocr_provider=ocr_provider,
        azure_fallback_provider=azure_fallback_provider,
        limits=limits,
        local_invocation_state=None,
    )

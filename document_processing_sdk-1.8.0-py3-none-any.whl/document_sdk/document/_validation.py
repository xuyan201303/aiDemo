"""Compatibility alias for shared sanitized public model validation."""

from document_sdk.core._validation import SanitizedPublicModel

__all__ = ["SanitizedPublicModel"]
